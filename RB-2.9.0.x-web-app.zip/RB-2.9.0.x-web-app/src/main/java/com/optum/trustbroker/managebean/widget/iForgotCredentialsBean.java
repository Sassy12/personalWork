package com.optum.trustbroker.managebean.widget;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.auditlogging.IDProofingAuditTypes;
import com.optum.trustbroker.auditlogging.IDProofingLoggingUtil;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.UuidUtil;
import com.optum.trustbroker.vo.AddressVO;
import com.optum.trustbroker.vo.ChallengeVerificationServiceRequest;
import com.optum.trustbroker.vo.IDProofingQuizServiceRequest;
import com.optum.trustbroker.vo.IDProofingQuizServiceResponse;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;

@ManagedBean(name = "iForgotCredentialsBean")
@ViewScoped
public class iForgotCredentialsBean extends AbstractBackingBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final BaseLogger LOGGER = new BaseLogger(ForgotCredentialsBean.class);

    private String firstName;

    private String lastName;

    private String emailId;

    private String phoneNumber;

    private String headerInfo;

    private String SELF_SERVICE_EMAIL_ID = "selfServiceEmailId";

    String securityQuesPage = "/views/forgotusernamesecurityquesverificationpage.xhtml?faces-redirect=true";

    String emailNotVerifiedPage = "/views/emailnotverifiedpage.xhtml?faces-redirect=true";

    String lostAccessToEmailPage = "/views/lostaccesstoemail.xhtml?faces-redirect=true";

    String userLockedPage = "/views/userlocked.xhtml?faces-redirect=true";

    String confirmationPage = "/views/forgotcredentialsconfirmationpage.xhtml?faces-redirect=true";

    private String accountrecoveryoptions = "/views/accountrecoveryoptionsw.xhtml?faces-redirect=true";

    private String emailErrorMsg;

    private String errorMsg;

    @PostConstruct
    public void init() {
        @SuppressWarnings("unchecked")
        Map<String, String> userDetailsMap = (HashMap<String, String>) getSessionAttribute(
                TrustBrokerWebAppConstants.USER_DETAILS_MAP);
        addRelyingPartyAlias((String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));

        addSessionAttribute(TrustBrokerWebAppConstants.RECOVERY_BY_EMAIL, getEmailId());
        addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);
        addSessionAttribute(TrustBrokerWebAppConstants.REGISTER_TYPE, "standAlone");
    }

    public String continueClicked() {

        if (StringUtils.isEmpty(getEmailId()) && StringUtils.isEmpty(getPhoneNumber())) {
            setErrorMsg(tbResources.getString("emailorphoneError"));
            return null;
        }

        if (!validateEmailFields()) {
            getFacesContext().addMessage("forgotUsernameForm:email",
                    new FacesMessage(tbResources.getString("invalidEmailAddress")));
            return null;
        }

        FacesContext context = getFacesContext();
        try {
            UserVO userVO = getUserProfile();
            if (userVO == null) {
                return null;
            }
            addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE,
                    TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW);

            addSessionAttribute("SELF_ACC_RECOVER_TYPE", TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW);
            ChallengeVerificationServiceRequest request = new ChallengeVerificationServiceRequest();
            request.setEmailUserName(true);
            request.setEmailAddress(this.emailId);
            UserVO uservo = new UserVO();
            uservo.setUuId(userVO.getUuId());
            uservo.setUserName(userVO.getUserName());

            request.setUserName(userVO.getUserName());
            request.setUser(uservo);
            return accountrecoveryoptions;

        } catch (OperationFailedException ex) {
            LOGGER.error("Error while verifying user details for user email {}",
                    new String[] {getEmailId(), TrustbrokerWebAppUtil.getUidFromError(ex)}, ex);
            if (null != ex.getErrorMessage()) {
                setErrorMsg(
                        ex.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo()));
            } else if (TrustBrokerConstants.USER_LOCKED.equals(ex.getMessage())) {
                getFacesContext().addMessage(null, new FacesMessage("User Locked."));
                LOGGER.info("ForgotCredentialsBean :: " + getEmailId() + " user has been locked ");
                return null;
            }
            if (MapUtils.isNotEmpty(ex.getErrorMessages())) {
                if (ex.getErrorMessages().containsKey("USR101")) {
                    context.addMessage("forgotUsernameForm:email",
                            new FacesMessage("Email Address provided does not match our records"));
                } else {
                    context.addMessage("forgotUsernameForm:email", new FacesMessage(ex.getMessage()));
                }
            } else {
                context.addMessage("forgotUsernameForm:email", new FacesMessage(ex.getMessage()));
            }
            return null;
        }
    }

    public String navToLoginpage() {
        return "/views/login.xhtml?faces-redirect=true";
    }

    public String continuePassword() {

        if (!validateEmailFields()) {
            getFacesContext().addMessage("forgotPasswordForm:email",
                    new FacesMessage(tbResources.getString("invalidEmailAddress")));
            return null;
        }
        if (StringUtils.isEmpty(getEmailId()) && StringUtils.isEmpty(getPhoneNumber())) {
            setErrorMsg(tbResources.getString("emailorphoneError"));
            return null;
        }
        FacesContext context = getFacesContext();
        try {
            UserVO userVO = getUserProfile();
            if (userVO == null) {
                return null;
            }

            addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE,
                    TrustBrokerWebAppConstants.FORGOT_PWD_FLOW);

            addSessionAttribute("SELF_ACC_RECOVER_TYPE", TrustBrokerWebAppConstants.FORGOT_PWD_FLOW);
        } catch (OperationFailedException ex) {
            LOGGER.error("Error while verifying user details for user email {}",
                    new String[] {getEmailId(), TrustbrokerWebAppUtil.getUidFromError(ex)}, ex);
            if (null != ex.getErrorMessage()) {
                setErrorMsg(
                        ex.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo()));
            } else if (ex.getMessage().equals(TrustBrokerConstants.USER_LOCKED)) {
                getFacesContext().addMessage(null, new FacesMessage("User Locked."));
                LOGGER.info("ForgotCredentialsBean :: " + getEmailId() + " user has been locked ");
                return null;
            }
            if (MapUtils.isNotEmpty(ex.getErrorMessages())) {
                if (ex.getErrorMessages().containsKey("USR101")) {
                    context.addMessage("forgotPasswordForm:email",
                            new FacesMessage("Email Address provided does not match our records"));
                } else {
                    context.addMessage("forgotPasswordForm:email", new FacesMessage(ex.getMessage()));
                }
            } else {
                context.addMessage("forgotPasswordForm:email", new FacesMessage(ex.getMessage()));
            }
            return null;
        }
        return accountrecoveryoptions;
    }

    public UserVO getUserProfile() throws OperationFailedException {

        UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
        UserVO userValueObject = new UserVO();
        userValueObject.setEmailAddress(getEmailId());
        userValueObject.setFirstName(getFirstName());
        userValueObject.setLastName(getLastName());
        userValueObject.setPhoneNumber(getPhoneNumber());
        userProfileServiceRequest.setUser(userValueObject);
        boolean userDuplicate = false;
        boolean userNotFound = false;
        UserRetrievalServiceResponse userRetrievalServiceResponse = null;
        UserProfileServiceResponse userProfileServiceResponse = null;
        // if phonenumber is empty

        // first last email and phone	
        userProfileServiceResponse = getContainer().getUserService().lookUpUserByEmailLabel(userValueObject,
                TrustBrokerConstants.EMAIL_TYPE_PRIMARY);
        if (userProfileServiceResponse.getExecutionStatus().getStatusCd()
                .equals(TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE)) {
            userDuplicate = true;
        } else if (TrustBrokerConstants.FAILURE_CODE_VALUE
                .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
            userProfileServiceResponse = getContainer().getUserService().lookUpUserByEmailLabel(userValueObject,
                    TrustBrokerConstants.EMAIL_TYPE_SECONDARY);
            if (TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE
                    .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                userDuplicate = true;
            } else if (TrustBrokerConstants.FAILURE_CODE_VALUE
                    .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                userNotFound = true;
            }
        }

        LOGGER.debug(
                "iForgotCredenialsean.getUserProfile()- after first query with first last email phone. result: userDuplicate: "
                        + userDuplicate + " userNotFound: " + userNotFound + " getPhoneNumber(): " + getPhoneNumber()
                        + " email: " + getEmailId() + " first: " + getFirstName() + " last: " + getLastName());

        //  only first  last email
        if ((userDuplicate || userNotFound) && StringUtils.isNotEmpty(getEmailId())) {
            //reset flags for another query
            userDuplicate = false;
            userNotFound = false;
            userValueObject.setPhoneNumber("");
            userProfileServiceResponse = getContainer().getUserService().lookUpUserByEmailLabel(userValueObject,
                    TrustBrokerConstants.EMAIL_TYPE_PRIMARY);
            if (TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE
                    .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                userDuplicate = true;
            } else if (TrustBrokerConstants.FAILURE_CODE_VALUE
                    .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                userProfileServiceResponse = getContainer().getUserService().lookUpUserByEmailLabel(userValueObject,
                        TrustBrokerConstants.EMAIL_TYPE_SECONDARY);
                if (TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE
                        .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                    userDuplicate = true;
                } else if (TrustBrokerConstants.FAILURE_CODE_VALUE
                        .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                    userNotFound = true;
                }
            }
            LOGGER.debug(
                    "iForgotCredenialsean.getUserProfile()- after second query with first last email. result: userDuplicate: "
                            + userDuplicate + " userNotFound: " + userNotFound);
        }

        // only first last phone
        if ((userDuplicate || userNotFound) && StringUtils.isNotEmpty(getPhoneNumber())) {

            //reset flags for another query
            userDuplicate = false;
            userNotFound = false;

            userValueObject.setPhoneNumber(getPhoneNumber());
            userValueObject.setEmailAddress("");
            userProfileServiceResponse = getContainer().getUserService().lookUpUserByEmailLabel(userValueObject,
                    TrustBrokerConstants.EMAIL_TYPE_PRIMARY);
            if (TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE
                    .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                userDuplicate = true;
            } else if (TrustBrokerConstants.FAILURE_CODE_VALUE
                    .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                userProfileServiceResponse = getContainer().getUserService().lookUpUserByEmailLabel(userValueObject,
                        TrustBrokerConstants.EMAIL_TYPE_SECONDARY);
                if (TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE
                        .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                    userDuplicate = true;
                } else if (TrustBrokerConstants.FAILURE_CODE_VALUE
                        .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
                    userNotFound = true;
                }
            }
            LOGGER.debug(
                    "iForgotCredenialsean.getUserProfile()- after third query with first last phone. result: userDuplicate: "
                            + userDuplicate + " userNotFound: " + userNotFound);
        }

        if (userNotFound) {
            SupportContactInfoVO sci = getSupportContactInfo();
            Object[] msgArguments = {sci.getContactComboText()};
            setErrorMsg(TBUtil.formatMessage(tbResources.getString("selfServiceInvalidActErr"), msgArguments));
            return null;
        }
        if (userDuplicate) {
            String multipleAcctErrorMsg = tbResources.getString("multipleAccountsMsg");
            if (StringUtils.isBlank(getPhoneNumber())) {
                multipleAcctErrorMsg = tbResources.getString("multipleAccountMsgEmptyPhone");
            }
            if (StringUtils.isBlank(getEmailId())) {
                multipleAcctErrorMsg = tbResources.getString("multipleAccountMsgEmptyEmail");
            }
            SupportContactInfoVO sci = getSupportContactInfo();
            Object[] msgArguments = {sci.getContactComboText()};
            setErrorMsg(TBUtil.formatMessage(multipleAcctErrorMsg, msgArguments));
            return null;
        }
        userRetrievalServiceResponse = getContainer().getUserService()
                .fetchUserProfile(userProfileServiceResponse.getUser().getUuId(), true, false);

        Map<String, String> userDetailsMap = new HashMap<String, String>();
        userDetailsMap.put("emailId", getEmailId());
        userDetailsMap.put("uuId", userRetrievalServiceResponse.getUser().getUuId());
        userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME, userRetrievalServiceResponse.getUser().getUserName());
        addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);

        UserVO userVO = userRetrievalServiceResponse.getUser();
        if (StringUtils.isNotBlank(userVO.getEmailAddress()) || !userVO.isPrimaryEmailUnique()) {
            UserChallengeQuestionServiceResponse userChallengeResp = null;
            try {
                userChallengeResp = getContainer().getUserService().getChallengeQuestions(userVO.getUuId(),
                        TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
            } catch (OperationFailedException ofe) {
                LOGGER.warn("Not able to fetch user challenge questions for user " + userDetailsMap, ofe);
            }

            if ((StringUtils.isNotBlank(userVO.getEmailAddress()) && userVO.isIsemailVerified()
                    && userVO.isPrimaryEmailUnique())
                    || (StringUtils.isNotBlank(userVO.getSecEmailAddress()) && userVO.isSecEmailVerified()
                            && userVO.isSecEmailUnique())
                    || (StringUtils.isNotBlank(userVO.getPhoneNumber()) && userVO.getIsPhoneVerified())
                    || (null != userChallengeResp
                            && CollectionUtils.isNotEmpty(userChallengeResp.getUserChallengeQuestions()))) {
                LOGGER.info("User already verified : " + userDetailsMap);
            } else {
                LOGGER.info("ForgotCredentialsBean | Email Address {} doesn't have any recovery methods",
                        new String[] {getEmailId()});
                generateAcctRecoveryNotUniqueError();
                return null;
            }
        } else {
            LOGGER.info("ForgotCredentialsBean | Email Address {} is not unique", new String[] {getEmailId()});
            generateAcctRecoveryNotUniqueError();
            return null;
        }

        return userVO;

    }

    /**
     * Gets the faces context
     * 
     * @return current FacesContext otherwise
     */
    @Override
    public FacesContext getFacesContext() {
        if (FacesContext.getCurrentInstance() != null) {
            return FacesContext.getCurrentInstance();
        }
        return super.getFacesContext();
    }

    public String lostAccessToEmail() {
        addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE, "lostMyEmailAccess");

        addSessionAttribute("SELF_ACC_RECOVER_TYPE", "lostMyEmailAccess");

        @SuppressWarnings("unchecked")
        Map<String, String> userDetails = (HashMap<String, String>) getSessionAttribute(
                TrustBrokerWebAppConstants.USER_DETAILS_MAP);
        addSessionAttribute(SELF_SERVICE_EMAIL_ID, userDetails.get("emailId"));
        UserRetrievalServiceResponse userRetrievalServiceResponse;
        try {
            userRetrievalServiceResponse = getContainer().getUserService()
                    .fetchUserProfile(userDetails.get(TrustBrokerWebAppConstants.USER_NAME), false, false);
        } catch (OperationFailedException ope) {
            LOGGER.error("Exception at lost access to email: {}",
                    new String[] {userDetails.get("emailId"), TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
            if (null != ope.getErrorMessage()) {
                setErrorMsg(
                        ope.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo()));
            }
            return null;
        }
        if (null != userRetrievalServiceResponse) {
            UserVO userVO = userRetrievalServiceResponse.getUser();
            LOGGER.debug(userVO.getUserName() + " exists at eSSO side");
            try {
                IDProofingQuizServiceRequest idProofingQuizServiceRequest = new IDProofingQuizServiceRequest();
                if (checkUserDataForIDProofing(userVO)) {
                    return null;
                }
                idProofingQuizServiceRequest.setUser(userVO);
                idProofingQuizServiceRequest
                        .setVerificationFlow(getContainer().getConfigProps().getProperty("basic_idp_verification_flow"));
                IDProofingQuizServiceResponse idProofingQuizServiceResponse = getContainer().getIdProofingService()
                        .generateQuiz(idProofingQuizServiceRequest);
                String executionStatusCd = idProofingQuizServiceResponse.getExecutionStatus().getStatusCd();
                LOGGER.debug("executionStatusCd code after generateQuiz call: " + executionStatusCd);

                boolean failed = false;
                if (TrustBrokerConstants.SYSTEM_ERROR_CODE_VALUE.equals(executionStatusCd)) {
                    String uid = UuidUtil.generateUid();
                    LOGGER.error("System Error: {}, while generating basic id quiz for user : {} ",
                            new String[] {idProofingQuizServiceResponse.getExecutionStatus().getStatusMessage(),
                                    userVO.getUserName(), uid});
                    SupportContactInfoVO sci = getSupportContactInfo();
                    Object[] msgArguments = {sci.getContactComboText(), uid};
                    setErrorMsg(TBUtil.formatMessage(tbResources.getString("systemError"), msgArguments));
                    failed = true;
                }
                if (TrustBrokerConstants.BAD_REQUEST_CODE_VALUE.equals(executionStatusCd)) {
                    LOGGER.error(
                            "Bad Request error: " + idProofingQuizServiceResponse.getExecutionStatus().getStatusMessage());
                    failed = true;
                }
                if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(executionStatusCd)) {
                    LOGGER.error("Failure error: " + idProofingQuizServiceResponse.getExecutionStatus().getStatusMessage());
                    failed = true;
                    SupportContactInfoVO sci = getSupportContactInfo();
                    Object[] msgArguments = {sci.getContactComboText()};
                    setErrorMsg(TBUtil.formatMessage(tbResources.getString("verifyIDInvalidAccount"), msgArguments));
                }

                IDProofingAuditTypes auditType = failed ? IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_FAIL
                        : IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_SUCCESS;
                IDProofingLoggingUtil.info(auditType, getRelyingPartyAppId(), userVO.getUserName(),
                        getErrorReasonCode(idProofingQuizServiceResponse.getExecutionStatus()),
                        "ForgotCredentialsBean:lostAccessToEmail()", getServletRequest());

                if (failed) {
                    return null;
                }

                addSessionAttribute(TrustBrokerWebAppConstants.ID_PROOFING_QUIZ,
                        idProofingQuizServiceResponse.getIdProofingQuizVO());
                return "/views/knowledgeBasedIdentification.xhtml?faces-redirect=true";
            } catch (OperationFailedException ope) {
                LOGGER.error("Exception while getting idproofing questions for user: {}",
                        new String[] {userVO.getUserName(), TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
                if (null != ope.getErrorMessage()) {
                    setErrorMsg(ope.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(),
                            getSupportContactInfo()));
                }
                return null;
            } catch (Exception e) {
                String uid = UuidUtil.generateUid();
                LOGGER.error("Error occured while generating questions using ID Proofing services for user {}",
                        new String[] {userVO.getUserName(), uid}, e);
                SupportContactInfoVO sci = getSupportContactInfo();
                Object[] msgArguments = {sci.getContactComboText(), uid};
                setErrorMsg(TBUtil.formatMessage(tbResources.getString("systemError"), msgArguments));
                return null;
            }

        }
        return lostAccessToEmailPage;
    }

    public String lostAccessToEmailForUnlock() {
        addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE, "unlockUserAccount");

        addSessionAttribute("SELF_ACC_RECOVER_TYPE", "unlockUserAccount");
        UserRetrievalServiceResponse userRetrievalServiceResponse;

        @SuppressWarnings("unchecked")
        Map<String, String> userDetails = (HashMap<String, String>) getSessionAttribute(
                TrustBrokerWebAppConstants.USER_DETAILS_MAP);
        addSessionAttribute(SELF_SERVICE_EMAIL_ID, userDetails.get("emailId"));
        try {
            userRetrievalServiceResponse = getContainer().getUserService()
                    .fetchUserProfile((userDetails.get(TrustBrokerWebAppConstants.USER_NAME)), false, false);
        } catch (OperationFailedException ope) {
            LOGGER.error("Exception at lost access to email: {}",
                    new String[] {userDetails.get("emailId"), TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
            if (null != ope.getErrorMessage()) {
                setErrorMsg(
                        ope.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo()));
            }
            return null;
        }
        if (null != userRetrievalServiceResponse) {
            UserVO userVO = userRetrievalServiceResponse.getUser();
            LOGGER.debug(userVO.getUserName() + " exists at eSSO side");
            try {
                IDProofingQuizServiceRequest idProofingQuizServiceRequest = new IDProofingQuizServiceRequest();
                if (checkUserDataForIDProofing(userVO)) {
                    return null;
                }
                idProofingQuizServiceRequest.setUser(userVO);
                idProofingQuizServiceRequest
                        .setVerificationFlow(getContainer().getConfigProps().getProperty("basic_idp_verification_flow"));
                IDProofingQuizServiceResponse idProofingQuizServiceResponse = getContainer().getIdProofingService()
                        .generateQuiz(idProofingQuizServiceRequest);
                String executionStatusCd = idProofingQuizServiceResponse.getExecutionStatus().getStatusCd();
                LOGGER.debug("executionStatusCd code after generateQuiz call: " + executionStatusCd);

                boolean failed = false;
                if (TrustBrokerConstants.SYSTEM_ERROR_CODE_VALUE.equals(executionStatusCd)) {
                    String uid = UuidUtil.generateUid();
                    LOGGER.error("System Error: {}, while generating basic id quiz for user : {} ",
                            new String[] {idProofingQuizServiceResponse.getExecutionStatus().getStatusMessage(),
                                    userVO.getUserName(), uid});
                    SupportContactInfoVO sci = getSupportContactInfo();
                    Object[] msgArguments = {sci.getContactComboText(), uid};
                    setErrorMsg(TBUtil.formatMessage(tbResources.getString("systemError"), msgArguments));
                    failed = true;
                }
                if (TrustBrokerConstants.BAD_REQUEST_CODE_VALUE.equals(executionStatusCd)) {
                    LOGGER.error(
                            "Bad Request error: " + idProofingQuizServiceResponse.getExecutionStatus().getStatusMessage());
                    failed = true;
                }
                if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(executionStatusCd)) {
                    LOGGER.error("Failure error: " + idProofingQuizServiceResponse.getExecutionStatus().getStatusMessage());
                    failed = true;
                    SupportContactInfoVO sci = getSupportContactInfo();
                    Object[] msgArguments = {sci.getContactComboText()};
                    setErrorMsg(TBUtil.formatMessage(tbResources.getString("verifyIDInvalidAccount"), msgArguments));
                }

                IDProofingAuditTypes auditType = failed ? IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_FAIL
                        : IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_SUCCESS;
                IDProofingLoggingUtil.info(auditType, getRelyingPartyAppId(), userVO.getUserName(),
                        getErrorReasonCode(idProofingQuizServiceResponse.getExecutionStatus()),
                        "ForgotCredentialsBean:lostAccessToEmail()", getServletRequest());

                if (failed) {
                    return null;
                }

                addSessionAttribute(TrustBrokerWebAppConstants.ID_PROOFING_QUIZ,
                        idProofingQuizServiceResponse.getIdProofingQuizVO());
                return "/views/knowledgeBasedIdentification.xhtml?faces-redirect=true";
            } catch (OperationFailedException ope) {
                LOGGER.error("Exception while getting idproofing questions for user: {}",
                        new String[] {userVO.getUserName(), TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
                if (null != ope.getErrorMessage()) {
                    setErrorMsg(ope.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(),
                            getSupportContactInfo()));
                }
                return null;
            } catch (Exception e) {
                String uid = UuidUtil.generateUid();
                LOGGER.error("Error occured while generating questions using ID Proofing services for user {}",
                        new String[] {userVO.getUserName(), uid}, e);
                SupportContactInfoVO sci = getSupportContactInfo();
                Object[] msgArguments = {sci.getContactComboText(), uid};
                setErrorMsg(TBUtil.formatMessage(tbResources.getString("systemError"), msgArguments));
                return null;
            }
        }
        return null;
    }

    public void checkEmailAddress(ValueChangeEvent event) {
        PhaseId phaseId = event.getPhaseId();
        if (phaseId.equals(PhaseId.ANY_PHASE)) {
            event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
            event.queue();
        } else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
            if (StringUtils.isNotEmpty(event.getNewValue().toString())) {
                boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
                LOGGER.debug("result value in email: " + result);
                if (!result) {
                    addFacesMessage(((UIComponent) event.getSource()).getClientId(),
                            tbResources.getString("invalidEmailAddress"));
                }
            }
        }
    }

    private boolean validateEmailFields() {
        boolean result = true;
        if (!TBUtil.validateEmailId(getEmailId())) {
            result = false;
        }
        return result;
    }

    private boolean checkUserDataForIDProofing(UserVO userVO) {
        LOGGER.debug("in checkUserDataForIDProofing method");
        List<String> missingData = new ArrayList<String>();
        if (StringUtils.isEmpty(userVO.getFirstName()))
            missingData.add("First Name");
        if (StringUtils.isEmpty(userVO.getLastName()))
            missingData.add("Last Name");
        if (null == userVO.getDob())
            missingData.add("Date of Birth");

        if (CollectionUtils.isNotEmpty(userVO.getAddresses())) {
            LOGGER.debug("user address is not null");
            AddressVO addressVO = userVO.getAddresses().get(0);
            if (StringUtils.isEmpty(addressVO.getStreetAddress())) {
                missingData.add("Street Address");
            }
            if (StringUtils.isEmpty(addressVO.getCity())) {
                missingData.add("City");
            }
            if (StringUtils.isEmpty(addressVO.getZip())) {
                missingData.add("Zip");
            }
            if (StringUtils.isEmpty(addressVO.getState())) {
                missingData.add("State");
            }
        } else {
            missingData.add("Home Address");
        }
        StringBuilder message = new StringBuilder();
        for (int i = 0; i < missingData.size() - 1; i++) {
            if (i == missingData.size() - 2) {
                message.append(missingData.get(i)).append(" and ");
            } else {
                message.append(missingData.get(i)).append(", ");
            }
        }

        if (missingData.size() > 0) {
            message.append(missingData.get(missingData.size() - 1));
        }

        SupportContactInfoVO sci = getSupportContactInfo();
        if (null != userVO.getDob() && !DateUtil.validateDate(DateUtil.formatDate(userVO.getDob(), "MM/dd/yyyy"))) {
            if (message.length() > 0) {
                message.append(", ");
            }
            message.append("Invalid Date of Birth");
        }
        Object[] msgArguments = {sci.getContactComboText(), message.toString()};
        setErrorMsg(TBUtil.formatMessage(tbResources.getString("selfServiceMissingDataMsgForIDP"), msgArguments));
        LOGGER.debug("checkUserDataForIDProofing() - " + message + " data is missing from " + userVO.getUserName());
        if (message.length() > 0) {
            return true;
        } else {
            return false;
        }
    }

    private void generateAcctRecoveryNotUniqueError() {
        SupportContactInfoVO sci = getSupportContactInfo();
        Object[] msgArguments = {sci.getContactComboText()};
        setErrorMsg(TBUtil.formatMessage(tbResources.getString("acctRecoveryNotUniqueErrorMsg"), msgArguments));
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getEmailId() {
        return emailId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String val) {
        phoneNumber = val;
    }

    public void setHeaderInfo(String headerInfo) {
        this.headerInfo = headerInfo;
    }

    public String getHeaderInfo() {
        return headerInfo;
    }

    private void addFacesMessage(String fieldId, String message) {
        getFacesContext().addMessage(fieldId, new FacesMessage(message));
    }

    /**
     * @param emailExistsMsgId the emailExistsMsgId to set
     */
    public void setEmailErrorMsg(String emailErrorMsg) {
        this.emailErrorMsg = emailErrorMsg;
    }

    /**
     * @return the emailExistsMsgId
     */
    public String getEmailErrorMsg() {
        return emailErrorMsg;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

}
