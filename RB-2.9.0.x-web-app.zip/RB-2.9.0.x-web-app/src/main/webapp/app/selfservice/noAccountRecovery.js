/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 * Author - skum200
 */
'use strict';
angular.module('indexApp').controller('noAccoutRecoveryController', noAccoutRecoveryController);

noAccoutRecoveryController.$inject =['$scope', '$http', 'messageData', '$state', 'currentWorkflowId'];
function noAccoutRecoveryController($scope, $http, messageData, $state, currentWorkflowId){
	
	$scope.currentWorkflowId = currentWorkflowId.data;
	$scope.message = messageData.message;
	
	if($scope.currentWorkflowId === 'forgotPwd'){
		$scope.noRecoveryTitle = "ACCT_N_VRFY_HEAD_RSTPWD";
	} else if($scope.currentWorkflowId === 'setUpSecurityQuestion'){
		$scope.noRecoveryTitle = "ACCT_N_VRFY_HEAD_SETSQA";
	} else if($scope.currentWorkflowId === 'forgotUserName'){
		$scope.noRecoveryTitle = "ACCT_N_VRFY_HEAD_USRNM";
	} else if($scope.currentWorkflowId === 'unlockUserAccount'){
		$scope.noRecoveryTitle = "ACCT_N_VRFY_HEAD_UNLK";
	}
	
	$scope.retBtn = "RET_SIGIN";
	
	$scope.returnSignInClick = function() {
		$state.go('login', {'prevState':'norecoveryoption'});
	};
}