/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 * 
 ***********************************************
 * Modification History
 * When          Who         Why
 * Jan 26, 2016  bmanna3        Initial version
 ****************************************************************/

package com.optum.trustbroker.controller.vo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * This VO is to store forgot user access credentials flow request information.
 * 
 * @author bmanna3
 */

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class ForgotAccessRequestVO {

        private String email;
        
        private String userName;
        
        private String firstName;
        
        private String lastName;
        
        private String recoveryType;
        
        private String dateOfBirth;
        
        private String mobilePhone;
        
        private String emailType;
        
        private String secAns1;
        
        private String secAns2;
        
        private String secAns3;
        
        /**
         * Default constructor.
         */
        public ForgotAccessRequestVO() {
        }

        /**
         * This method returns the email.
         * 
         * @return the email
         */
        public String getEmail() {
                return email;
        }

        /**
         * This method sets the given email value to email.
         * 
         * @param email
         *            the email to set
         */
        public void setEmail(String email) {
                this.email = email;
        }

        /**
         * This method returns the userName.
         * 
         * @return the userName
         */
        public String getUserName() {
                return userName;
        }

        /**
         * This method sets the given userName value to userName.
         * 
         * @param userName
         *            the userName to set
         */
        public void setUserName(String userName) {
                this.userName = userName;
        }

        /**
         * This method returns the firstName.
         * 
         * @return the firstName
         */
        public String getFirstName() {
                return firstName;
        }

        /**
         * This method sets the given firstName value to firstName.
         * 
         * @param firstName
         *            the firstName to set
         */
        public void setFirstName(String firstName) {
                this.firstName = firstName;
        }

        /**
         * This method returns the lastName.
         * 
         * @return the lastName
         */
        public String getLastName() {
                return lastName;
        }

        /**
         * This method sets the given lastName value to lastName.
         * 
         * @param lastName
         *            the lastName to set
         */
        public void setLastName(String lastName) {
                this.lastName = lastName;
        }

        /**
         * This method returns the recoveryType.
         * 
         * @return the recoveryType
         */
        public String getRecoveryType() {
                return recoveryType;
        }

        /**
         * This method sets the given recoveryType value to recoveryType.
         * 
         * @param recoveryType
         *            the recoveryType to set
         */
        public void setRecoveryType(String recoveryType) {
                this.recoveryType = recoveryType;
        }
			
		public String getEmailType() {
			return emailType;
		}

		public void setEmailType(String emailType) {
			this.emailType = emailType;
		}

        /**
         * This method returns the dateOfBirth.
         *
         * @return the dateOfBirth
         */
        public String getDateOfBirth() {
            return dateOfBirth;
        }

        /**
         * This method sets the given dateOfBirth value to dateOfBirth.
         *
         * @param dateOfBirth the dateOfBirth to set
         */
        public void setDateOfBirth(String dateOfBirth) {
            this.dateOfBirth = dateOfBirth;
        }

        /**
         * This method returns the mobilePhone.
         *
         * @return the mobilePhone
         */
        public String getMobilePhone() {
            return mobilePhone;
        }

        /**
         * This method sets the given mobilePhone value to mobilePhone.
         *
         * @param mobilePhone the mobilePhone to set
         */
        public void setMobilePhone(String mobilePhone) {
            this.mobilePhone = mobilePhone;
        }

		/**
		 * @return the secAns1
		 */
		public String getSecAns1() {
			return secAns1;
		}

		/**
		 * @param secAns1 the secAns1 to set
		 */
		public void setSecAns1(String secAns1) {
			this.secAns1 = secAns1;
		}

		/**
		 * @return the secAns2
		 */
		public String getSecAns2() {
			return secAns2;
		}

		/**
		 * @param secAns2 the secAns2 to set
		 */
		public void setSecAns2(String secAns2) {
			this.secAns2 = secAns2;
		}

		/**
		 * @return the secAns3
		 */
		public String getSecAns3() {
			return secAns3;
		}

		/**
		 * @param secAns3 the secAns3 to set
		 */
		public void setSecAns3(String secAns3) {
			this.secAns3 = secAns3;
		}
}

		
