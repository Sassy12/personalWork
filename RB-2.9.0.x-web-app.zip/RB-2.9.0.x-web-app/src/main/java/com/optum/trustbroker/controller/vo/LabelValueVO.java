package com.optum.trustbroker.controller.vo;

public class LabelValueVO implements Comparable {
	
	private String label;
	private String value;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	@Override
	public int compareTo(Object obj) {
		if(obj instanceof LabelValueVO) {
			LabelValueVO labelValueVO = (LabelValueVO) obj;
			return getValue().compareTo(labelValueVO.getValue());
		}
		return 0;
	}
	
}
