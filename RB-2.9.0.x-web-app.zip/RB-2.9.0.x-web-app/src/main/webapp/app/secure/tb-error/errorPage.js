'use strict';
var tbApp = angular.module('tbApp');
tbApp.controller('errorPageController', ['$scope', 'errorData', '$window','$state', '$stateParams','AnalyticsService','HelpObj', function($scope, errorData, $window, $state, $stateParams,AnalyticsService, HelpObj){
	
	HelpObj.setHelpObj({url:'../webHelp/Default_CSH.htm#Optum ID CSH/entry_1041_Unable_to_Display_Page_Error_page.htm'});
	
	//assigning error message to scope
	$scope.errorMessageInfo = errorData.data.message;
	var getElement = angular.element('#errorMessage');
	getElement.html($scope.errorMessageInfo);
	
	pageDataLayer.content.pageName="unabletodisplaypage";
    pageDataLayer.content.siteSectionL1="";
	
    if(typeof _satellite !== "undefined"){
        _satellite.track('trackPageView');
    }
    
    AnalyticsService.postErrorPageInfo($stateParams.errorCode);
	
	//function for navigating back to login page
	$scope.navigateToLogin = function() {
		$window.location= "/tb/app/index.html";
	};
}]);