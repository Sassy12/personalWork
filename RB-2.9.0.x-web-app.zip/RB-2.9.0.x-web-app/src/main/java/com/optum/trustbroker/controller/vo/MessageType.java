package com.optum.trustbroker.controller.vo;

public enum MessageType {

	ERROR,SUCCESS,VERIFIED,EXPIRED, NOTFOUND;
}
