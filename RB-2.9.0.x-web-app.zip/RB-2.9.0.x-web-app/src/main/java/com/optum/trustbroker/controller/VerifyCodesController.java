package com.optum.trustbroker.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.ImmutableMap;
import com.optum.trustbroker.aa.web.actions.SetDeviceDetailsAction;
import com.optum.trustbroker.aa.web.helpers.DeviceHelper;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.controller.vo.VerifyCodesCtx;
import com.optum.trustbroker.controller.vo.VerifyCodesVO;
import com.optum.trustbroker.helpers.UserHelper;
import com.optum.trustbroker.service.UserVerifyCodesService;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.UserVerifyCodesServiceResponse;
import com.optum.trustbroker.vo.VerificationCodeResponse;

@Path(TBConstants.VERIFY_CODES_CONTROLLER_PATH)
public class VerifyCodesController extends BaseController {

    private static final String PRIM_EMAIL_FIELD_ID = "code";

    private static final String PHONE_FIELD_ID = "phoneErr";

    /** logger for this class. */
    private static final Logger LOG = Logger.getLogger(VerifyCodesController.class);

    @Autowired
    private DeviceHelper deviceHelper;

    @Autowired
    private SetDeviceDetailsAction setDeviceDetailsAction;

    @Autowired
    public UserVerifyCodesService userVerifyCodesService;

    /**
     * required for initial check for sending code to respective communication
     * channel(PHONE,PRIMARY_EMAIL,SECONDARY_EMAIL)
     * 
     * @param ctx
     * @param request
     * @return {@link VerifyCodesVO}
     */
    @Path(TBConstants.VERIFY_CODES_CHECKFOR_PREVERIFICATION)
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public VerifyCodesVO checkForPreVerification(VerifyCodesCtx ctx, @Context HttpServletRequest request) {

        // getting rpappid and target from context
        WebApplicationContext webAppCtx = WebApplicationContextHolder.getContext();
        UserVO vo = ctx.getUserVO();
        ctx.setUserVO(null);
        String rpAppID = webAppCtx.getSessionAttribute(TrustBrokerConstants.RELYING_APP_ID_PARAM);
        String rpTargetUrl = webAppCtx.getSessionAttribute(TrustBrokerConstants.TARGET);
        RpAppVO appVO = new RpAppVO();
        appVO.setAppId(rpAppID);
        appVO.setTargetURL(rpTargetUrl);
        VerifyCodesVO codeVO = new VerifyCodesVO();

        // for seting the masked email to be shown on UI.
        String email = null;
        String maskedEmail = null;

        // If it is email confirmation post login. Then we need to send email
        // once and removing current work flow as on page refresh we don't want
        // to send email again.
        if (WorkflowConstants.EMAIL_CONFIRMATION_POST_LOGIN.equalsIgnoreCase(webAppCtx.getcurrentWorkflowId())) {
            //ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
            webAppCtx.removeCurrentWorkflowAndAttributes();
        }

        UserVO currUserVO = getCurrentUser();

        if (currUserVO == null && vo != null) {

            currUserVO = vo;

        }

        final boolean primaryEmailVerifiable = isCommChannelVerifiable(ctx, currUserVO, CommunicationChannel.PRIMARY_EMAIL);
        final boolean secondaryEmailVerifiable = isCommChannelVerifiable(ctx, currUserVO,
                CommunicationChannel.SECONDARY_EMAIL);
        final boolean phoneVerifiable = isCommChannelVerifiable(ctx, currUserVO, CommunicationChannel.PHONE);

        if (!primaryEmailVerifiable && !secondaryEmailVerifiable && !phoneVerifiable) {
            codeVO.setNextState(ctx.getNextView());
            return codeVO;
        }
        UserVerifyCodesServiceResponse response = null;
        if (primaryEmailVerifiable) {
            //if the primary email is not verified. checks if the existing code is expired 
            response = getverifyCodes(currUserVO.getUuId(), currUserVO.getEmailAddress(),
                    CommunicationChannel.PRIMARY_EMAIL);
            if (TrustbrokerWebAppUtil.checkExpiredRespStatus(response)) {
                //if code expired, adds it to channel list to send a new code
                if (!containsChannel(ctx.getSendChannels(), CommunicationChannel.PRIMARY_EMAIL.name())) {
                    ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
                }
                updateExpiredStatus(response, codeVO);
            }
        }
        if (secondaryEmailVerifiable) {
            //if the sec email is not verified. checks if the existing code is expired 
            response = getverifyCodes(currUserVO.getUuId(), currUserVO.getSecEmailAddress(),
                    CommunicationChannel.SECONDARY_EMAIL);
            if (TrustbrokerWebAppUtil.checkExpiredRespStatus(response)) {
                //if code expired, adds it to channel list to send a new code
                if (!containsChannel(ctx.getSendChannels(), CommunicationChannel.SECONDARY_EMAIL.name())) {
                    ctx.getSendChannels().add(CommunicationChannel.SECONDARY_EMAIL);
                }
                updateExpiredStatus(response, codeVO);
            }
        }

        if (ctx.getChann() != null && ctx.getSendChannels().size() == 0) {
            if (ctx.getChann() == CommunicationChannel.PRIMARY_EMAIL) {

                email = currUserVO.getEmailAddress();

            } else if (ctx.getChann() == CommunicationChannel.SECONDARY_EMAIL) {

                email = currUserVO.getSecEmailAddress();

            }
        }
        try {

            for (CommunicationChannel channel : ctx.getSendChannels()) {
                if (channel == CommunicationChannel.PRIMARY_EMAIL) {
                    if (primaryEmailVerifiable) {
                        email = currUserVO.getEmailAddress();
                        sendCode(ctx, currUserVO, request, appVO, CommunicationChannel.PRIMARY_EMAIL);
                    }
                } else if (channel == CommunicationChannel.PHONE) {
                    if (phoneVerifiable) {
                        sendCode(ctx, currUserVO, request, appVO, CommunicationChannel.PHONE);
                    }
                } else if (channel == CommunicationChannel.SECONDARY_EMAIL && secondaryEmailVerifiable) {
                    email = currUserVO.getSecEmailAddress();
                    sendCode(ctx, currUserVO, request, appVO, CommunicationChannel.SECONDARY_EMAIL);
                }
            }

            maskedEmail = TBUtil.emailMask(email);
            codeVO.setMaskedEmail(maskedEmail);

            ctx.getSendChannels().clear();

            return codeVO;
        } catch (OperationFailedException e) {
            LOG.error("Exception :", e);
            return codeVO;
        }
    }

    /**
     *  This method is to get existing verification code for the given user email
     *  
     * @param uuid String
     * @param email String
     * @param commChannel CommunicationChannel
     * @return UserVerifyCodesServiceResponse
     */
    private UserVerifyCodesServiceResponse getverifyCodes(String uuid, String email, CommunicationChannel commChannel) {
        UserVerifyCodesServiceResponse verifyCodeResponse = userVerifyCodesService.getUserVerifyCodes(uuid, email,
                commChannel.name());
        return verifyCodeResponse;
    }

    /**
     * This method is to update the given value object if the service response
     * is expired
     * 
     * @param response UserVerifyCodesServiceResponse
     * @param codeVO VerifyCodesVO
     */
    private void updateExpiredStatus(UserVerifyCodesServiceResponse response, VerifyCodesVO codeVO) {
        if (TrustbrokerWebAppUtil.checkExpiredRespStatus(response)) {
            codeVO.setStatus("EXPIRED");
        }
    }

    /**
     * This method is to check if the given channel type exists in 
     * the given channel list.
     * 
     * @param channels List<CommunicationChannel>
     * @param channelType String
     * @return boolean
     */
    private boolean containsChannel(List<CommunicationChannel> channels, String channelType) {
        boolean channelExists = false;
        if (channels != null && !channels.isEmpty()) {
            Iterator<CommunicationChannel> channelItr = channels.iterator();
            while (channelItr.hasNext()) {
                if (channelItr.next().name().equalsIgnoreCase(channelType)) {
                    channelExists = true;
                    break;
                }
            }
        }
        return channelExists;
    }

    /**
     * used for resending code to respective communication
     * channel((PHONE,PRIMARY_EMAIL,SECONDARY_EMAIL))
     * 
     * @param ctx
     * @param request
     * @return Map&ltString, String&gt
     */
    @Path(TBConstants.VERIFY_CODES_RESEND_EMAIL)
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, String> resendPrimaryEmail(VerifyCodesCtx ctx, @Context HttpServletRequest request) {

        String code = null;
        ctx.setUserVO(null);
        Map<String, String> resentMsgSuccMap = new HashMap<String, String>();
        // getting rpappid and target from context
        WebApplicationContext webAppCtx = WebApplicationContextHolder.getContext();
        String rpAppID = webAppCtx.getSessionAttribute(TrustBrokerConstants.RELYING_APP_ID_PARAM);
        String rpTargetUrl = webAppCtx.getSessionAttribute(TrustBrokerConstants.TARGET);
        RpAppVO appVO = new RpAppVO();
        appVO.setAppId(rpAppID);
        appVO.setTargetURL(rpTargetUrl);

        // code for sending verification code to respective communication
        // channel
        UserVO currUserVO = getWebApplicationCommonUtilities().getCurrentUserDetailsFromWebApplicationContext();
        CommunicationChannel channel = ctx.getChann();

        if (CommunicationChannel.PRIMARY_EMAIL == channel || CommunicationChannel.SECONDARY_EMAIL == channel) {
            code = sendCode(ctx, currUserVO, request, appVO, channel);
            resentMsgSuccMap.put("resentEmailCode", verifyCodes.getString("resendEmailNextGen"));
        } else if (CommunicationChannel.PHONE == ctx.getChann()) {
            code = sendCode(ctx, currUserVO, request, appVO, CommunicationChannel.PHONE);
            resentMsgSuccMap.put("resentPhCode", getBundle().getString("mobileCodeResendmsg"));
        }

        if (ctx.isAutoVerify()) {
            ctx.getPrePopulatedCodes().put(channel, code);
        }
        return resentMsgSuccMap;
    }

    /**
     * verifies the code that was sent ot the user through mobile or email and
     * successfully updates the communication channel as verified for the user
     * 
     * @param ctx
     * @return {@link VerifyCodesVO}
     */
    @Path(TBConstants.VERIFY_PHONECODES_VERIFY)
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public VerifyCodesVO verifyPhoneCode(VerifyCodesCtx ctx) {

        UserVO currUserVO = getWebApplicationCommonUtilities().getCurrentUserDetailsFromWebApplicationContext();

        VerifyCodesVO codesVO = new VerifyCodesVO();

        if (!currUserVO.getIsPhoneVerified() && isCommChannelVerifiable(ctx, currUserVO, CommunicationChannel.PHONE)) {
            try {
                final String phoneCode = ctx.getPrimaryCode().trim();
                Map<String, String> errorMap = validateField(phoneCode, PHONE_FIELD_ID);
                boolean errorExists = MapUtils.isNotEmpty(errorMap);
                if (errorExists) {
                    codesVO.setErrorMap(errorMap);
                } else {
                    VerificationCodeResponse respVerify = userService.verifyChannel(CommunicationChannel.PHONE, phoneCode,
                            StringUtils.EMPTY);

                    if (TrustbrokerWebAppUtil.checkResponseStatus(respVerify)) {
                        WebApplicationContext webApplicationContext = WebApplicationContextHolder.getContext();
                        webApplicationContext.setSessionAttribute(TrustBrokerWebAppConstants.SKIP_RECOVERY_EVENT, "true");
                    }

                    LOG.debug("phone verification response status: " + respVerify.getExecutionStatus().getStatusCd());
                }
            } catch (OperationFailedException e) {
                LOG.error(" phone verification failed", e);
                Map<String, String> errMap = checkVerificationError(e, PHONE_FIELD_ID);
                if (MapUtils.isNotEmpty(errMap)) {
                    codesVO.setErrorMap(errMap);
                }
            }
        }
        return codesVO;
    }

    /**
     * used for verifying code sent to primary email as a Communication channel
     * 
     * @param ctx
     * @return VerifyCodesVO
     */
    @Path(TBConstants.VERIFY_CODES_VERIFY)
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public VerifyCodesVO verify(VerifyCodesCtx ctx) {

        UserVO userVO = getCurrentUser();
        VerifyCodesVO codesVO = new VerifyCodesVO();
        boolean isError = false;
        CommunicationChannel channel = ctx.getChann();

        if (isCommChannelVerifiable(ctx, userVO, channel)) {
            /*
             * The usual flow where the user will key-in his confirmation code
             */
            try {
                Map<String, String> errorMap = validateField(ctx.getPrimaryCode(), PRIM_EMAIL_FIELD_ID);
                boolean errorExists = MapUtils.isNotEmpty(errorMap);
                if (errorExists) {
                    codesVO.setErrorMap(errorMap);
                    isError = true;
                } else {
                    VerificationCodeResponse respVerify = userService.verifyChannel(channel, ctx.getPrimaryCode(), "");
                    if (!TrustbrokerWebAppUtil.checkResponseStatus(respVerify)) {
                        isError = true;
                        Map<String, String> errMap = new HashMap<String, String>();
                        errMap.put(PRIM_EMAIL_FIELD_ID, respVerify.getReasonMessage());
                        codesVO.setErrorMap(errMap);
                    } else {
                        WebApplicationContext webApplicationContext = WebApplicationContextHolder.getContext();
                        webApplicationContext.setSessionAttribute(TrustBrokerWebAppConstants.SKIP_RECOVERY_EVENT, "true");
                    }
                }
            } catch (OperationFailedException e) {
                LOG.error("email verification failed", e);
                Map<String, String> errMap = checkVerificationError(e, PRIM_EMAIL_FIELD_ID);

                if (MapUtils.isNotEmpty(errMap)) {
                    isError = true;
                    codesVO.setErrorMap(errMap);
                }
            }
        } else if ((channel == CommunicationChannel.PRIMARY_EMAIL && userVO.isIsemailVerified())
                || (channel == CommunicationChannel.SECONDARY_EMAIL && userVO.isSecEmailVerified())) {
            /*
             * This path will be taken when the user came to confirm/verify
             * email flow but went back and confirmed/verified his email through
             * verification link that is shared along with confirmation code.
             * When the user submits the form again from confirm email flow, we
             * should take user to next screen for incorrect or blank code
             */
            LOG.info("email already confirmed/verified through another flow");
            isError = false;
        } else {
            LOG.error("channel sent in request is not verifiable");
            throw new OperationFailedException("channel not verifiable");
        }

        if (isError) {
            return codesVO;
        }
        codesVO.setNextState(ctx.getNextView());

        return codesVO;
    }

    /**
     * This method is used for details about current recovery option that needs
     * to be confirmed/verified. This is called when the user reloads his page
     * and the existing context is cleared or when the context while doing a
     * state transition to confirm email flow.
     *
     * @return VerifyCodesCtx
     */
    @Path(value = "/createVerifyCodesCtx")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public VerifyCodesCtx getVerifyCodesCtx() {

        UserVO userVO = getWebApplicationCommonUtilities().getCurrentUserDetailsFromWebApplicationContext();
        CommunicationChannel channel = null;
        VerifyCodesCtx ctx = null;
        String optionValue = null;
        String maskedEmail = null;

        if (StringUtils.isNotBlank(userVO.getEmailAddress()) && !userVO.isIsemailVerified()) {
            channel = CommunicationChannel.PRIMARY_EMAIL;
            optionValue = userVO.getEmailAddress();

        } else {
            String optionToVerify = getWebApplicationCommonUtilities().getRecoveryOptionToVerify(userVO);
            if (TrustBrokerWebAppConstants.OPTION_MOBILE.equals(optionToVerify)) {
                channel = CommunicationChannel.PHONE;
                optionValue = userVO.getPhoneNumber();
            } else if (TrustBrokerWebAppConstants.OPTION_SECONDARY_EMAIL.equals(optionToVerify)) {
                channel = CommunicationChannel.SECONDARY_EMAIL;
                optionValue = userVO.getSecEmailAddress();
            }
        }
        maskedEmail = TBUtil.emailMask(optionValue);
        if (channel != null) {
            ctx = new VerifyCodesCtx();
            ctx.getViewChannels().add(channel);
            ctx.setChann(channel);
            ctx.setOptionValue(optionValue);
            ctx.setNextView(TBConstants.CONGRATULATIONS);
            ctx.setMaskedEmail(maskedEmail);

            /*
             * code is stored in DB only before sending an email to user. If the
             * email is not received, same code can be re-used from DB. If the
             * user is already sent an email once, avoid sending multiple emails
             * until requested by the user specifically with resend email link
             */
            String verificationCode = userService.getVerificationCode(channel, optionValue, userVO.getUuId());
            if (verificationCode == null) {
                ctx.getSendChannels().add(channel);
            }
        }

        return ctx;
    }

    /**
     * This method mainly deals with validation of verification code(checks if
     * they are empty or they are numbers)
     * 
     * @param value
     * @param fieldId
     * @return Map&ltString, String&gt
     */
    private Map<String, String> validateField(String value, String fieldId) {
        Map<String, String> errorMap = new HashMap<String, String>();
        Map<String, String> completeErrorMap = ImmutableMap.of(PRIM_EMAIL_FIELD_ID, "primEmailReqErr", PHONE_FIELD_ID,
                "phneCodeReqErr");
        String field = null;

        if (StringUtils.isEmpty(value)) {
            // When value is empty, adding the corresponding error message
            field = completeErrorMap.get(fieldId);
            errorMap.put(fieldId, tbResources.getString(field));
        } else if (!NumberUtils.isDigits(value)) {
            // When values is Non Digit, adding the corresponding error message
            errorMap.put(fieldId, tbResources.getString(getInvalidConfErrKey(fieldId)));
        }
        return errorMap;
    }

    /** This method gets the modified fields for  verification options 
     * 
     *  @return Response
     * */
    @Path(value = "/getModifiedFields")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getModifiedFields() {

        Response response = null;

        WebApplicationContext ctx = WebApplicationContextHolder.getContext();

        Map<String, String> modifiedFields = null;
        String primary = ctx.getWorkflowAttribute(WorkflowConstants.WORKFLOW_MANAGE_ID_VERIFY_OPTIONS,
                WorkflowConstants.WORKFLOW_ATTRIBUTE_EMAIL);
        String secondary = ctx.getWorkflowAttribute(WorkflowConstants.WORKFLOW_MANAGE_ID_VERIFY_OPTIONS,
                WorkflowConstants.WORKFLOW_ATTRIBUTE_SEC_EMAIL);
        String mobile = ctx.getWorkflowAttribute(WorkflowConstants.WORKFLOW_MANAGE_ID_VERIFY_OPTIONS,
                WorkflowConstants.WORKFLOW_ATTRIBUTE_MOBILE_NUMBER);
        if (primary != null || secondary != null || mobile != null) {
            modifiedFields = new HashMap<>();
            if (primary != null)
                modifiedFields.put(UserHelper.PRIMARY_EMAIL, primary);
            if (secondary != null)
                modifiedFields.put(UserHelper.SECONDARY_EMAIL, secondary);
            if (mobile != null)
                modifiedFields.put(UserHelper.MOBILE, mobile);
        }

        response = Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(modifiedFields).build();
        return response;
    }

    /** This method clears workflow */
    @Path(value = "/clearworkflow")
    @GET
    public void clearWorkflow() {
        WebApplicationContextHolder.getContext().removeCurrentWorkflowAndAttributes();
    }

    private String getInvalidConfErrKey(String fieldId) {
        String invCodeMsgKey = null;
        if (PRIM_EMAIL_FIELD_ID.equals(fieldId)) {
            invCodeMsgKey = "invalidCodeConfrmEmail";
        } else if (PHONE_FIELD_ID.equals(fieldId)) {
            invCodeMsgKey = "invalidMobileOTPNextGen";
        }
        return invCodeMsgKey;
    }

    private Map<String, String> checkVerificationError(OperationFailedException e, String fieldId) {
        Map<String, String> errMap = new HashMap<String, String>();
        Map<String, String> errMsgs = e.getErrorMessages();
        if (MapUtils.isEmpty(errMsgs) && e.getCause() != null) {
            errMsgs = ((OperationFailedException) e.getCause()).getErrorMessages();
        }
        if (errMsgs != null) {
            StringTokenizer essoErrorCodes = new StringTokenizer(tbResources.getString("ESSO_VERF_ERR_CODES"), ";");
            while (essoErrorCodes.hasMoreTokens()) {
                if (errMsgs.containsKey(essoErrorCodes.nextToken())) {
                    errMap.put(fieldId, tbResources.getString(getInvalidConfErrKey(fieldId)));
                    return errMap;
                }
            }
        }
        return errMap;
    }

    // optimised code by merging 3 private methods into one
    private boolean isCommChannelVerifiable(VerifyCodesCtx ctx, UserVO userVO, CommunicationChannel chann) {
        if (userVO != null) {
            switch (chann) {
                case PRIMARY_EMAIL: {
                    if (!userVO.isIsemailVerified() && checkIfChannelExists(ctx, chann)) {
                        return true;
                    }
                    break;
                }
                case SECONDARY_EMAIL: {
                    if (!userVO.isSecEmailVerified() && checkIfChannelExists(ctx, chann)) {
                        return true;
                    }
                    break;
                }
                case PHONE: {
                    if (!userVO.getIsPhoneVerified() && checkIfChannelExists(ctx, chann)) {
                        return true;
                    }
                    break;
                }
            }
        }
        return false;
    }

    private boolean checkIfChannelExists(VerifyCodesCtx ctx, CommunicationChannel chann) {
        for (CommunicationChannel channel : ctx.getViewChannels()) {
            if (channel == chann) {
                return true;
            }
        }
        return false;
    }

    private String sendCode(VerifyCodesCtx ctx, UserVO currUserVO, HttpServletRequest request, RpAppVO appVO,
            CommunicationChannel chann) {
        VerificationCodeResponse resp = null;
        resp = userService.sendVerificationCode(getVerificationCodeRequest(chann, currUserVO, request, appVO));
        String code = resp.getCode();
        if (ctx.isAutoVerify()) {
            ctx.getPrePopulatedCodes().put(chann, code);
        }
        return code;
    }

    public DeviceHelper getDeviceHelper() {
        return deviceHelper;
    }

    public void setDeviceHelper(DeviceHelper deviceHelper) {
        this.deviceHelper = deviceHelper;
    }

    public void setSetDeviceDetailsAction(SetDeviceDetailsAction setDeviceDetailsAction) {
        this.setDeviceDetailsAction = setDeviceDetailsAction;
    }

    public SetDeviceDetailsAction getSetDeviceDetailsAction() {
        return setDeviceDetailsAction;
    }

    public UserVerifyCodesService getUserVerifyCodesService() {
        return userVerifyCodesService;
    }

    public void setUserVerifyCodesService(UserVerifyCodesService userVerifyCodesService) {
        this.userVerifyCodesService = userVerifyCodesService;
    }
}
