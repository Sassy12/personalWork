'use strict';

var commonApp = angular.module('common.modules');

/* Defining the controllers on common module as the state is
   re-used between pre-login and post-login flows */

commonApp.controller('verifyController', ['$scope', 'verifyService', '$state', 'LanguageService', '$stateParams', '$translate', 'trustbrokerAriaService', '$timeout', 'uitkLiveRegionService', '$rootScope', 'HelpObj','initialData',
function($scope, verifyService, $state, LanguageService, $stateParams, $translate, trustbrokerAriaService, $timeout, uitkLiveRegionService, $rootScope, HelpObj,initialData) {

    $timeout(function() {
        angular.element(document.getElementById('confirmCode_input')).attr("aria-required", "true");
    }, 200);

    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1004_Confirm_Your_Email_Address.htm' });

    $scope.confirmCodeValidation = true;
    $scope.confirmCodeShow = false;
    $scope.confirmLinkShow = true;
    $scope.primEmailError = '';
    $scope.emailCode = "";
    //$scope.showEmailResentMessage = '';
    $scope.resendEmailSent=false;
    $scope.emailCdExpired = false;

    $scope.resendPrimEmailDescribedBy = "primary email confirmation";
    $scope.enterConfirmationCodeDescribedBy = "enter my confirmation code";
    $scope.updateEmailAddressDescribedBy = "update email address";

    var emailMsg = '',
        msgType = '';

    $scope.verifySecEmail = false;
    
    //incase of normal page navigation data related to masked email will be in initial data
    if(initialData && initialData.data.maskedEmail){    	
    	$scope.maskedEmail=initialData.data.maskedEmail;    	
    }else{    	
    	//incase of page reload, the masked email value will be obtained from verifyCodesCtx as initialData will be null    	
    	if($stateParams && $stateParams.verifyCodesCtx.optionValue){    	
    		$scope.maskedEmail=$stateParams.verifyCodesCtx.optionValue;    		
    	}    	
    }
       
    if(initialData && initialData.data.status && initialData.data.status === 'EXPIRED'){  
        $scope.emailCdExpired = true;
    }
    if ($stateParams.verifyCodesCtx && $stateParams.verifyCodesCtx.chann === 'SECONDARY_EMAIL') {
        $scope.verifySecEmail = true;
        emailMsg = '<span class="tk-margin-top-halft" translate="infoContentForVerification"></span>';
        $scope.pageHeader = $translate.instant('verifyEmailHeader');
        msgType = 'success';
        pageDataLayer.content.pageName = "confirmSecondaryEmailAddress";
    } else {
        emailMsg = '<span class="tk-margin-top-halft" translate="informativeContentForConfirmation"></span>';
        $scope.pageHeader = $translate.instant('confirmEmailHeader');
        msgType = 'information';
        pageDataLayer.content.pageName = "confirmEmailAddress";
    }

    if (typeof _satellite !== "undefined") {
        _satellite.track('trackPageView');
    }

    /*var emailMsgModel = {
        animationTime: 1,
        autoFadeOut: false,
        content: emailMsg,
        headingLevel: '2',
        id: 'confirmEmailAddressId',
        messageRole: 'alert',
        messageType: msgType,
        position: 'inline',
        visible: true
    };

    $scope.confirmEmailAddressModel = emailMsgModel;*/
    $scope.updatedEmailSent = "";

    if ($stateParams.fromState === "updateEmailAddress") {
        $scope.updatedEmailSent = $translate.instant('updtdEmailSent');
    }

    $scope.setFieldValidity = function(inputid, spanid) {
        $scope.showPwdErr = true;

        $timeout(function() {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        }, 300);
    };

    $scope.resendEmail = function () {
        var serviceResponse = {};
        $scope.updatedEmailSent = "";
        //$scope.showEmailResentMessage = "";
        //$scope.confirmEmailAddressModel.content = emailMsg;
        
        $scope.errMsgBasedOnResendEmail=false;
        angular.element("#confirmCode_input").val("");

        verifyService.resendPrimaryEmail($stateParams.verifyCodesCtx).then(function (success) {
            serviceResponse = success;
            //$scope.showEmailResentMessage = serviceResponse.data.resentEmailCode;
            //$scope.confirmEmailAddressModel.content = '<p id="emailResentMsgId">' + serviceResponse.data.resentEmailCode + '</p>' + emailMsg;
            
            $scope.resendEmailSent=true;
            $scope.resendEmailMsg=serviceResponse.data.resentEmailCode;
            
            $timeout(function() {
            $('#resendEmailAddressMsgId').focus();
            }, 300);
        });

    };

    $scope.showConfirmCodeBox = function() {
        $scope.confirmCodeShow = true;
        $scope.confirmLinkShow = false;

        $timeout(function() {
            angular.element("#confirmCode_input").focus();
        }, 100);
    };

    $scope.stateChangeWithInfo = function() {
        var verifyCodesVO = {};
        verifyCodesVO.ctx = $stateParams.verifyCodesCtx;

        if ($scope.verifySecEmail) {
            verifyCodesVO.channel = "SECONDARY_EMAIL";
        } else {
            verifyCodesVO.channel = "PRIMARY_EMAIL";
        }

        verifyService.setupEmailUpdateWorkflow(verifyCodesVO.channel).then(function() {
            $state.go("updateEmailAddress", {
                'vo': verifyCodesVO,
                'emailShared': $stateParams.emailShared
            });
        });

    };

    $scope.hideConfirmCodeBox = function() {
        $scope.confirmCodeShow = false;
        $scope.confirmLinkShow = true;
        $scope.primEmailError = "";

        $timeout(function() {
            $('#confirmEmailHeader').focus();
        }, 300);
    };

    $scope.rectifyErrMessage = function(event) {
        if (event.keyCode !== 9) {
            $scope.primEmailError = "";
        }
    };

    // submit method of form-confirmCode_form
    $scope.verify = function() {
       // $scope.showEmailResentMessage = '';
        $scope.primEmailError = "";
        $scope.updatedEmailSent = "";
        //$scope.confirmEmailAddressModel.content = emailMsg;
        var confirmationEmailCode = angular.element("#confirmCode_input").val();

        /* removing user info from context. Actual user info will be derived from SM session. */
        $stateParams.verifyCodesCtx.userVO = null;
        $stateParams.verifyCodesCtx.primaryCode = confirmationEmailCode;

        // service method for rest service call
        verifyService.verify($stateParams.verifyCodesCtx).then(function(success) {
            if (success.data.nextState === "congratulations") {
                if ($scope.verifySecEmail) {
                    $state.go("congratulations", { 'flowName': 'secEmailVerification' });
                } else {
                    $state.go("congratulations");
                }
            }

            var errorMap = success.data.errorMap;

            if (errorMap) {
                if ("code" in errorMap) {
                	$scope.errMsgBasedOnResendEmail=true;
                    $scope.primEmailError = success.data.errorMap.code;
                    if($scope.emailCdExpired) {
                    	$scope.primEmailError = $translate.instant("expiredCdErrMsg");
                    }
                    angular.element(document.getElementById('confirmCode_input')).attr('aria-describedby', 'confirmCodeId_err');

                    $timeout(function() {
                        angular.element("#confirmCode_input").focus();
                    }, 100);
                    $scope.setFieldValidity('confirmCode_input','confirmCodeId_err');
                }
                $rootScope.fireErrorTracker = true;
            }
        });
    };
}]);
