package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.AddTrusetedDeviceRequest;
import com.optum.trustbroker.vo.AddTrustedDeviceResponse;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.VerificationCodeResponse;
import com.uhg.iam.commons.beans.DeviceDetails;

/**
 * Manages the generation and verification of codes sent to email addresses and phones that require TB to validate the user has access to these
 * devices.
 *
 * The session object "VerifyCodesContext" must be populated for this bean to work.
 *
 * @author nvaneps
 */
@ManagedBean(name = "verifyCodesBean")
@ViewScoped
public class VerifyCodesBean extends AbstractBackingBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final BaseLogger logger = new BaseLogger(VerifyCodesBean.class);
	public static final String VERIFY_CODES_VIEW_SNIPPET = "/views/snippets/verifycodesbox.xhtml";
	public static final String VERIFY_CODES_VIEW = "/views/verifycodes.jsf?faces-redirect=true";
	
	private static final String PRIM_EMAIL_FIELD_ID = "verifyCodesId:primaryEmailCodeTextId";
	private static final String SEC_EMAIL_FIELD_ID = "verifyCodesId:secondaryEmailCodeTextId";
	private static final String PHONE_FIELD_ID = "verifyCodesId:phoneCodeTextId";
		
	private String primaryEmailCode;
	private String secondaryEmailCode;
	private String phoneCode;
	private StringBuilder alertBuilder;
	private String registerDevice;
	private String devicePrint;
	private VerifyCodesContext ctx;
	private boolean showPrmEmail;
	private boolean showSecEmail;
	private String infoMessage;
	//private boolean prmEmailTxtDisabled;
	//private boolean secEmailTxtDisabled;
	

	@PostConstruct
	public void postConstruct() {
		setCtx((VerifyCodesContext) getSessionAttribute(VerifyCodesContext.SESSION_NAME));
		primaryEmailCode = "";
		secondaryEmailCode = "";
		phoneCode = "";
		alertBuilder = new StringBuilder();
		//pwd = "";
		registerDevice = "No";
		devicePrint = "";
		setInfoMessage(null);
		// skip view if there is nothing to do
		if (!isPrimaryEmailVerifiable() && !isSecondaryEmailVerifiable() && !isPhoneVerifiable()) {
			removeSessionAttribute(VerifyCodesContext.SESSION_NAME);
			setCurrentUserVO(getCtx().getUserVO());
			redirectToView(getCtx().getNextView());
		}

		try {
			for (CommunicationChannel channel : getCtx().getSendChannels()) {
				if (channel == CommunicationChannel.PRIMARY_EMAIL) {
					if (isPrimaryEmailVerifiable()) {
						sendPrimaryEmailCode();
					}
				}
				else if (channel == CommunicationChannel.SECONDARY_EMAIL) {
					if (isSecondaryEmailVerifiable()) {
						sendSecondaryEmailCode();
					}
				}
				else if (channel == CommunicationChannel.PHONE) {
					if (isPhoneVerifiable()) {
						sendPhoneCode();
					}
				}
			}
			getCtx().getSendChannels().clear();			

			for (Entry<CommunicationChannel, String> code : ctx.getPrePopulatedCodes().entrySet()) {
				if (code.getKey() == CommunicationChannel.PRIMARY_EMAIL) {
					primaryEmailCode = code.getValue();
				}
				else if (code.getKey() == CommunicationChannel.SECONDARY_EMAIL) {
					secondaryEmailCode = code.getValue();
				}
				else if (code.getKey() == CommunicationChannel.PHONE) {
					phoneCode = code.getValue();
				}
			}
			if (getCtx().isAutoVerify()) {
				//pwd = getCtx().getUserVO().getPassword();
				verify();
			}
		}
		catch (OperationFailedException e) {
			setAlert(extractErrorMessageFromOFE(e));
		}
	}

	public void verify() {
		synchronized (getCtx()) {
			// TODO setLength(0)?
			alertBuilder = new StringBuilder();
			setInfoMessage(null);
			StringBuilder systemError = new StringBuilder();
			UserVO userVO = getUserProfileInfo();
			boolean isError = false;
			if(userVO != null) {
				UserVO ctxUserVO = getCtx().getUserVO();
				ctxUserVO.setIsemailVerified(userVO.isIsemailVerified());
				ctxUserVO.setPrimaryEmailUnique(userVO.isPrimaryEmailUnique());
				ctxUserVO.setSecEmailVerified(userVO.isSecEmailVerified());
				ctxUserVO.setSecEmailUnique(userVO.isSecEmailUnique());
			}
			if ((userVO == null || !userVO.isIsemailVerified()) && isPrimaryEmailVerifiable()) {
				try {
					if(validateField(primaryEmailCode, PRIM_EMAIL_FIELD_ID)) {
						VerificationCodeResponse respVerify = container.getUserService().verifyChannel(CommunicationChannel.PRIMARY_EMAIL,
								primaryEmailCode, "");
						if (respVerify.getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
							getCtx().getUserVO().setIsemailVerified(true);
							getCtx().getUserVO().setPrimaryEmailUnique(respVerify.isUniqueStatusPostVerification());
						}
						else {
							alertBuilder.append(tbResources.getString("emailVerificationFailed"));
						}
					} else {
						isError = true;
					}
				}
				catch (OperationFailedException e) {
					logger.error("primary email verification failed", e);
					if(checkVerificationError(e, PRIM_EMAIL_FIELD_ID)) {
						isError = true;
					} else {
						alertBuilder.append(tbResources.getString("emailVerificationFailed"));
						systemError.append(extractErrorMessageFromOFE(e));
					}
				}
			}

			if ((userVO == null || !userVO.isSecEmailVerified()) && isSecondaryEmailVerifiable()) {
				try {
					if(validateField(secondaryEmailCode, SEC_EMAIL_FIELD_ID)) {					
						VerificationCodeResponse respVerify = container.getUserService().verifyChannel(CommunicationChannel.SECONDARY_EMAIL,
								secondaryEmailCode, "");
						if (respVerify.getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
							getCtx().getUserVO().setSecEmailVerified(true);
							getCtx().getUserVO().setSecEmailUnique(respVerify.isUniqueStatusPostVerification());
						}
						else {
							if (alertBuilder.length() > 0) {
								alertBuilder.append("\n\n");
							}
							alertBuilder.append(tbResources.getString("secondaryEmailVerificationFailed"));
						}
					} else {
						isError = true;
					}
				}
				catch (OperationFailedException e) {
					logger.error("secondary email verification failed", e);
					if(checkVerificationError(e, SEC_EMAIL_FIELD_ID)) {
						isError = true;
					}  else {
						if (alertBuilder.length() > 0) {
							alertBuilder.append("\n\n");
						}
						alertBuilder.append(tbResources.getString("secondaryEmailVerificationFailed"));
						if (systemError.indexOf(e.getErrorMessage().getCode()) == -1) {
							if (systemError.length() > 0) {
								systemError.append("\n\n");
							}
							systemError.append(extractErrorMessageFromOFE(e));
						}
					}
				}
			}

			if (logger.isDebugEnabled()) {
				logger.debug("is phone verifiable: " + isPhoneVerifiable());
			}
			if (isPhoneVerifiable()) {
				try {
					if(validateField(phoneCode, PHONE_FIELD_ID)) {
						VerificationCodeResponse respVerify = container.getUserService().verifyChannel(CommunicationChannel.PHONE, phoneCode, "");
						if (logger.isDebugEnabled()) {
							logger.debug("phone verification response status: " + respVerify.getExecutionStatus().getStatusCd());
						}
						if (respVerify.getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
							getCtx().getUserVO().setIsPhoneVerified(true);
						}
						else {
							if (alertBuilder.length() > 0) {
								alertBuilder.append("\n\n");
							}
							alertBuilder.append(tbResources.getString("phoneVerificationFailed"));
						}
					} else {
						isError = true;
					}
				}
				catch (OperationFailedException e) {
					logger.error("phone verification failed", e);
					if(checkVerificationError(e, PHONE_FIELD_ID)) {
						isError = true;
					} else {
						if (alertBuilder.length() > 0) {
							alertBuilder.append("\n\n");
						}
						alertBuilder.append(tbResources.getString("phoneVerificationFailed"));
						if (systemError.indexOf(e.getErrorMessage().getCode()) == -1) {
							if (systemError.length() > 0) {
								systemError.append("\n\n");
							}
							systemError.append(extractErrorMessageFromOFE(e));
						}
					}
				}
			}
				
			if (isError || alertBuilder.length() > 0) {
				if (systemError.length() > 0) {
					alertBuilder.append("\n\n").append(systemError);
				}
				return;
			}

			if ("Yes".equalsIgnoreCase(registerDevice)) {
				DeviceDetails deviceDetails = new DeviceDetails();
				deviceDetails.setDevicePrint(devicePrint);
				container.getDeviceHelper().build(getServletRequest(), deviceDetails);
				AddTrusetedDeviceRequest request = new AddTrusetedDeviceRequest();
				request.setUser(getCtx().getUserVO());
				request.setDeviceDetails(deviceDetails);
				AddTrustedDeviceResponse respAdd = container.getUserService().addTrustedDevice(request);
				container.getSetDeviceDetailsAction().setDeviceCookie(getServletRequest(), getServletResponse(), respAdd.getDeviceTokenCookie());
				container.getSetDeviceDetailsAction().setFSOToken(getServletRequest(), TrustbrokerWebAppUtil.encodeURL(respAdd.getDeviceTokenFSO()));
			}

			removeSessionAttribute(VerifyCodesContext.SESSION_NAME);
			setCurrentUserVO(getCtx().getUserVO());
			redirectToView(getCtx().getNextView());
		}
	}

	public void sendPrimaryEmailCode() {
		String code = sendCode(CommunicationChannel.PRIMARY_EMAIL);
		if (ctx.isAutoVerify()) {
			ctx.getPrePopulatedCodes().put(CommunicationChannel.PRIMARY_EMAIL, code);
		}
	}

	public void sendSecondaryEmailCode() {
		String code = sendCode(CommunicationChannel.SECONDARY_EMAIL);
		if (ctx.isAutoVerify()) {
			ctx.getPrePopulatedCodes().put(CommunicationChannel.SECONDARY_EMAIL, code);
		}
	}

	public void sendPhoneCode() {
		String code = sendCode(CommunicationChannel.PHONE);
		if (ctx.isAutoVerify()) {
			ctx.getPrePopulatedCodes().put(CommunicationChannel.PHONE, code);
		}
	}

	public void resendPrimaryEmailCode() {
		addMessageToFlash("newconfirmationmsg", null);
		setInfoMessage(verifyCodes.getString("primaryEmailVerificationResent"));
		String code = sendCode(CommunicationChannel.PRIMARY_EMAIL);
		if (ctx.isAutoVerify()) {
			ctx.getPrePopulatedCodes().put(CommunicationChannel.PRIMARY_EMAIL, code);
		}
	}

	public void resendSecondaryEmailCode() {
		addMessageToFlash("newconfirmationmsg", null);
		setInfoMessage(verifyCodes.getString("secondaryEmailVerificationResent"));
		String code = sendCode(CommunicationChannel.SECONDARY_EMAIL);
		if (ctx.isAutoVerify()) {
			ctx.getPrePopulatedCodes().put(CommunicationChannel.SECONDARY_EMAIL, code);
		}
	}

	public void resendPhoneCode() {
		setInfoMessage(tbResources.getString("phoneVerificationSent"));
		String code = sendCode(CommunicationChannel.PHONE);
		if (ctx.isAutoVerify()) {
			ctx.getPrePopulatedCodes().put(CommunicationChannel.PHONE, code);
		}
	}

	public String updatePrimaryEmail() {
		ctx.setUpdateChannel(CommunicationChannel.PRIMARY_EMAIL);
		return VerifyCodesUpdateBean.VERIFY_CODES_UPDATE_VIEW;
	}

	public String updateSecondaryEmail() {
		ctx.setUpdateChannel(CommunicationChannel.SECONDARY_EMAIL);
		return VerifyCodesUpdateBean.VERIFY_CODES_UPDATE_VIEW;
	}

	public String updatePhone() {
		ctx.setUpdateChannel(CommunicationChannel.PHONE);
		return VerifyCodesUpdateBean.VERIFY_CODES_UPDATE_VIEW;
	}

	private String sendCode(CommunicationChannel channel) {
		VerificationCodeResponse resp = container.getUserService().sendVerificationCode(
				getVerificationCodeRequest(channel, getCtx().getUserVO()));
		if(getCtx().isExpiredResent()) {
                    setInfoMessage(tbResources.getString("emailVerfOldGenSentMsg"));
                }
		return resp.getCode();
	}

	public String getRegisterDevice() {
		return registerDevice;
	}

	public void setRegisterDevice(String registerDevice) {
		this.registerDevice = registerDevice;
	}

	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	public String getPrimaryEmailCode() {
		return primaryEmailCode;
	}

	public void setPrimaryEmailCode(String primaryEmailCode) {
		this.primaryEmailCode = primaryEmailCode;
	}

	public String getSecondaryEmailCode() {
		return secondaryEmailCode;
	}

	public void setSecondaryEmailCode(String secondaryEmailCode) {
		this.secondaryEmailCode = secondaryEmailCode;
	}

	public String getPhoneCode() {
		return phoneCode;
	}

	public void setPhoneCode(String phoneCode) {
		this.phoneCode = phoneCode;
	}

	public String getAlert() {
		return alertBuilder.toString();
	}

	public void setAlert(String alert) {
		this.alertBuilder = new StringBuilder(alert);
	}

	public String getInfoMessage() {
		return infoMessage;
	}

	public void setInfoMessage(String infoMessage) {
		this.infoMessage = infoMessage;
	}

	public boolean isPrimaryEmailVerifiable() {
		if (ctx != null && ctx.getUserVO() != null && !ctx.getUserVO().isIsemailVerified()) {
			for (CommunicationChannel channel : getCtx().getViewChannels()) {
				if (channel == CommunicationChannel.PRIMARY_EMAIL) {
					return true;
				}
			}
		}
		return false;
	}

	public void setPrimaryEmailVerifiable(boolean primaryEmailVerifiable) {
	}

	public boolean isSecondaryEmailVerifiable() {
		if (ctx != null && ctx.getUserVO() != null && !ctx.getUserVO().isSecEmailVerified()) {
			for (CommunicationChannel channel : getCtx().getViewChannels()) {
				if (channel == CommunicationChannel.SECONDARY_EMAIL) {
					return true;
				}
			}
		}
		return false;
	}

	public void setSecondaryEmailVerifiable(boolean secondaryEmailVerifiable) {
	}

	public boolean isPhoneVerifiable() {
		if (ctx != null && ctx.getUserVO() != null && !ctx.getUserVO().getIsPhoneVerified()) {
			for (CommunicationChannel channel : getCtx().getViewChannels()) {
				if (channel == CommunicationChannel.PHONE) {
					return true;
				}
			}
		}
		return false;
	}

	public void setPhoneVerifiable(boolean phoneVerifiable) {
	}

	public VerifyCodesContext getCtx() {
		return ctx;
	}

	public void setCtx(VerifyCodesContext ctx) {
		this.ctx = ctx;
	}
	
	public void checkPrimaryEmailCode(ValueChangeEvent event) {
		validateField(event, PRIM_EMAIL_FIELD_ID);		
	}
	
	public void checkSecEmailCode(ValueChangeEvent event) {
		validateField(event, SEC_EMAIL_FIELD_ID);		
	}
	
	public void checkPhoneConfCode(ValueChangeEvent event) {
		validateField(event, PHONE_FIELD_ID);		
	}
	
	private void validateField(ValueChangeEvent event, String fieldId) {
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			String value = event.getNewValue().toString();
			validateField(value, fieldId);			
		}
	}
	
	private boolean validateField(String value, String fieldId) {	
		if(StringUtils.isEmpty(value)) {
			String invCodeMsgKey = "emailConfrmCodeRequired";
			if(PHONE_FIELD_ID.equals(fieldId)) {
				invCodeMsgKey = "confirmationCodeRequired";
			}			
			addFacesMessage(fieldId, tbResources.getString(invCodeMsgKey));
			return false;
		} else if( !NumberUtils.isDigits(value)) {
			addFacesMessage(fieldId, tbResources.getString(getInvalidConfErrKey(fieldId)));
			return false;
		}
		return true;
	}
	
	private void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}
	
		
	private boolean checkVerificationError(OperationFailedException e, String fieldId) {
		Map errMsgs = e.getErrorMessages();
		if((errMsgs == null || errMsgs.isEmpty()) && e.getCause() != null) {
			errMsgs = ((OperationFailedException)e.getCause()).getErrorMessages();
		}
		if(errMsgs != null) {
			StringTokenizer essoErrorCodes = new StringTokenizer(tbResources.getString("ESSO_VERF_ERR_CODES"), ";");
			while(essoErrorCodes.hasMoreTokens()) {
				if(errMsgs.containsKey(essoErrorCodes.nextToken())) {
					addFacesMessage(fieldId, tbResources.getString(getInvalidConfErrKey(fieldId)));
					return true;
				}
			}
		}
		return false;
	}
	
	private String getInvalidConfErrKey(String fieldId) {
		String invCodeMsgKey = "invalidConfrmCodeMsg";
		if(getCtx().isExpiredResent()) {
		    invCodeMsgKey = "emailVerfOldGenErrMsg";
		}
		if(PHONE_FIELD_ID.equals(fieldId)) {
			invCodeMsgKey = "invPhnConfrmCodeMsg";
		}
		return invCodeMsgKey;
	}
	
	public boolean isShowPrmEmail() {
		return showPrmEmail;
	}

	public void setShowPrmEmail(boolean showPrmEmail) {
		this.showPrmEmail = showPrmEmail;
	}

	public boolean isShowSecEmail() {
		return showSecEmail;
	}

	public void setShowSecEmail(boolean showSecEmail) {
		this.showSecEmail = showSecEmail;
	}

	/*public boolean isPrmEmailTxtDisabled() {
		return prmEmailTxtDisabled;
	}

	public void setPrmEmailTxtDisabled(boolean prmEmailTxtDisabled) {
		this.prmEmailTxtDisabled = prmEmailTxtDisabled;
	}
	
	public boolean isSecEmailTxtDisabled() {
		return secEmailTxtDisabled;
	}

	public void setSecEmailTxtDisabled(boolean secEmailTxtDisabled) {
		this.secEmailTxtDisabled = secEmailTxtDisabled;
	}*/

/*	public void checkPrmEmailVerified(ValueChangeEvent event) {
		//check if email is verified
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			//if(isPrmEmailConfInd()) {
			if((Boolean)event.getNewValue()) {
				UserVO userVO = getUserProfileInfo();
				if(userVO != null && userVO.isIsemailVerified()) {
					setPrmEmailTxtDisabled(true);
				} else {
					setPrmEmailTxtDisabled(false);
					setPrmEmailConfInd(false);
					addFacesMessage(PRIM_EMAIL_FIELD_ID, tbResources.getString("emailLnkNotCnrmMsg"));
				}
			} else{
				setPrmEmailTxtDisabled(false);
			}
		}
	}
	
	public void checkPrmEmailVerified() {
		//check if email is verified
		String confId = null;		
		Map params = getServletRequest().getParameterMap();
		if(params.get("verifyCodesId:cbox") != null) {
			confId = ((String[]) params.get("verifyCodesId:cbox"))[0];
		}			
		boolean prmConfId = Boolean.parseBoolean(confId);
		//if(isPrmEmailConfInd()) {
		if(prmConfId) {
			UserVO userVO = getUserProfileInfo();
			if(userVO != null && userVO.isIsemailVerified()) {
				setPrmEmailTxtDisabled(true);		
				setPrmEmailConfInd(true);
				addFacesMessage(PRIM_EMAIL_FIELD_ID, "");
			} else {
				setPrmEmailTxtDisabled(false);
				setPrmEmailConfInd(false);
				addFacesMessage(PRIM_EMAIL_FIELD_ID, tbResources.getString("emailLnkNotCnrmMsg"));
			}			
		} else{
			setPrmEmailTxtDisabled(false);
			setPrmEmailConfInd(false);
			addFacesMessage(PRIM_EMAIL_FIELD_ID, "");
		}		
		return;
	}
	
	public void checkSecEmailVerified(ValueChangeEvent event) {
		//check if secondary email is verified
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			//if(isSecEmailConfInd()) {
			if((Boolean)event.getNewValue()) {
				UserVO userVO = getUserProfileInfo();
				if(userVO != null && userVO.isSecEmailVerified()) {
					setSecEmailTxtDisabled(true);
				} else {
					setSecEmailTxtDisabled(false);
					setSecEmailConfInd(false);
					addFacesMessage(SEC_EMAIL_FIELD_ID, tbResources.getString("emailLnkNotCnrmMsg"));
				}
			} else{
				setSecEmailTxtDisabled(false);
			}
		}
	}
	
	public void checkSecEmailVerified() {
		//check if secondary email is verified
		String confId = null;		
		Map params = getServletRequest().getParameterMap();
		if(params.get("verifyCodesId:cbox") != null) {
			confId = ((String[]) params.get("verifyCodesId:cbox"))[0];
		}			
		boolean secConfId = Boolean.parseBoolean(confId);
		//if(isSecEmailConfInd()) {
		if(secConfId) {
			UserVO userVO = getUserProfileInfo();
			if(userVO != null && userVO.isSecEmailVerified()) {
				setSecEmailTxtDisabled(true);
				setSecEmailConfInd(true);
				addFacesMessage(SEC_EMAIL_FIELD_ID, "");
			} else {
				setSecEmailTxtDisabled(false);
				setSecEmailConfInd(false);
				addFacesMessage(SEC_EMAIL_FIELD_ID, tbResources.getString("emailLnkNotCnrmMsg"));
			}
		} else{
			setSecEmailTxtDisabled(false);
			setSecEmailConfInd(false);
			addFacesMessage(SEC_EMAIL_FIELD_ID, "");
		}		
	}*/
	
	private UserVO getUserProfileInfo() {
		UserVO userVO = null;
		try {
			UserRetrievalServiceResponse response = getContainer().getUserService().
					fetchUserProfile(getCtx().getUserVO().getUserName(), false, false);
			userVO = response.getUser();
		} catch(OperationFailedException of) {
			logger.error("Exception getting user profile:", of);
		}
		return userVO;
	}
	
	public String getFmtPrmEmail() {
		String email = "";
		if(getCtx() != null && getCtx().getUserVO() != null 
				&& getCtx().getUserVO().getEmailAddress() != null) {
			email = getCtx().getUserVO().getEmailAddress();
			email = TBUtil.emailMask(email);
		}
		return email;
	}
	
	public String getFmtSecEmail() {
		String email = "";
		if(getCtx() != null && getCtx().getUserVO() != null 
				&& getCtx().getUserVO().getSecEmailAddress() != null) {
			email = getCtx().getUserVO().getSecEmailAddress();
			email = TBUtil.emailMask(email);
		}
		return email;
	}
}