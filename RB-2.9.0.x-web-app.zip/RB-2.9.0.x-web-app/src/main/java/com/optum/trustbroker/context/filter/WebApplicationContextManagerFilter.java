/*
 * Copyright (C) 2016 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.context.filter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Properties;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.http.CookieConfiguration;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.uhg.iam.alps.common.crypto.CryptAgent;

/**
 * A filter bean that manages the creation and cleanup of the web application
 * context during the execution of the application.
 *
 * @author Sachin Kumar
 * @version 1.0
 */
public class WebApplicationContextManagerFilter implements Filter {

    public static final String OID_COOKIE = "oid_data";

    private static CryptAgent cryptAgent;
    
    private static Properties configProps;

    private transient ApplicationContext applicationContext;

    private CookieConfiguration cookieConfiguration;

    private static final BaseLogger logger = new BaseLogger(WebApplicationContextManagerFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.applicationContext = WebApplicationContextUtils
                .getRequiredWebApplicationContext(filterConfig.getServletContext());
        cryptAgent = (CryptAgent) this.applicationContext.getBean("cryptAgent");
        cookieConfiguration = this.applicationContext.getBean(CookieConfiguration.class);
        configProps = (Properties) this.applicationContext.getBean("configProps");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {

        // initialize the application context
        WebApplicationContext ctx = loadContext((HttpServletRequest) servletRequest);

        // store context data
        WebApplicationContextHolder.setContext(ctx);

        try {

            ResponseCookieWrapper response = new ResponseCookieWrapper((HttpServletResponse) servletResponse);
            filterChain.doFilter(servletRequest, response);

            byte[] bytes = response.getByteArray();

            //Check if session data is dirty
            if (ctx.isDirty()) {
                Cookie cookie = createOIDCookie();
                if (cookie != null) {
                    String host = servletRequest.getServerName();
                    String domain = host.indexOf(".") >= 0 ? host.substring(host.indexOf(".")) : null;
                    // default cookie domain being configured for this response
                    TBUtil.addCookieByHeader((HttpServletResponse) servletResponse, cookie.getName(), cookie.getValue(),
                            domain, cookieConfiguration.isUseSecureCookies(), cookieConfiguration.getCookiePath(),
                            cookieConfiguration.isUseHttpOnlyCookies());
                }
            }

            // write buffered output to response stream
            if (response.isSendRedirect()) {
            	String redirectURL = Boolean.parseBoolean(configProps.getProperty("local_client")) ? "/tb" + response.getSendRedirectLocation() : configProps.getProperty("optumid.hostname") + response.getSendRedirectLocation();
                ((HttpServletResponse) servletResponse).sendRedirect(redirectURL);
            } else {
                // write buffered output to response stream
                servletResponse.getOutputStream().write(bytes);
                if (response.isFlushed()) {
                    servletResponse.flushBuffer();
                }
            }
        } finally {
            // cleanup the context
            WebApplicationContextHolder.clearContext();
        }
    }

    /**
     * Creates the context from cookie and parameter values
     * 
     * @param request
     * @return {@link WebApplicationContext}
     */
    public WebApplicationContext loadContext(HttpServletRequest request) {
        WebApplicationContext ctx = null;

        try {

            //First read session state details if available in cookie
            String oidCookieValue = null;
            Cookie cookies[] = request.getCookies();
            if (cookies != null) {
                for (int i = 0; i < cookies.length; i += 1) {
                    if (OID_COOKIE.equals(cookies[i].getName())) {
                        oidCookieValue = cookies[i].getValue();
                        break;
                    }
                }
            }

            if (oidCookieValue != null) {
                oidCookieValue = URLDecoder.decode(oidCookieValue, "UTF-8");
                Map<String, String> sessionAttributes = cryptAgent.getAttributesFromToken(oidCookieValue, true);
                ctx = new WebApplicationContext(sessionAttributes);
            } else {
                // Initialize the context if not available
                ctx = new WebApplicationContext();
            }

            //Session attributes - check if the RP context is part of parameters, then replace previous values from state if context is different.
            String relyingAppId = request.getParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
            String relyingAppURL = request.getParameter(TrustBrokerWebAppConstants.TARGET);
            logger.debug("relyingAppId: " + relyingAppId + " & relyingAppURL : " + relyingAppURL);

            if (StringUtils.isNotBlank(relyingAppId) && StringUtils.isNotBlank(relyingAppURL)) {
                ctx.setSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, relyingAppId);
                ctx.setSessionAttribute(TrustBrokerWebAppConstants.TARGET,
                        clearSMEncodingOnTargetIfAvailable(relyingAppURL));
            }
        } catch (Exception ex) {
            logger.error("Exception occured in loading context : ", ex);
        }

        // Return empty WebApplicationContext instead of null for safety.
        return ctx != null ? ctx : new WebApplicationContext();
    }

    private Cookie createOIDCookie() {
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        Cookie cookie = null;

        if (ctx != null) {
            try {
                String stateToken = cryptAgent.createToken(ctx.getSessionAttributes());
                stateToken = URLEncoder.encode(stateToken, "UTF-8");
                cookie = new Cookie(OID_COOKIE, stateToken);
            } catch (UnsupportedEncodingException e) {
                logger.error("Encoding issue for state token cookie", e);
            }
        }

        return cookie;
    }

    /**
     * Clear the SM encoding characters from target before validating domain.
     * @param target
     * @return
     */
    private String clearSMEncodingOnTargetIfAvailable(String target) {
        String targetParam = target;
        targetParam = targetParam.replace("-SM-", "");
        targetParam = targetParam.replace("$SM$", "");
        targetParam = targetParam.replace("--", "-");
        targetParam = targetParam.replace("-:", ":");
        targetParam = targetParam.replace("-/", "/");

        return targetParam;
    }

    @Override
    public void destroy() {

    }

    public CookieConfiguration getCookieConfiguration() {
        return cookieConfiguration;
    }

    public void setCookieConfiguration(CookieConfiguration cookieConfiguration) {
        this.cookieConfiguration = cookieConfiguration;
    }

}
