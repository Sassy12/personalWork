package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;

import com.optum.trustbroker.enums.DirectAddressPrimary;
import com.optum.trustbroker.enums.DirectAddressStatus;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.UuidUtil;
import com.optum.trustbroker.vo.AttributeVO;
import com.optum.trustbroker.vo.DirectAddressVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.TagVO;
import com.optum.trustbroker.vo.UserTagServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceResponse;

@ManagedBean(name = "directAddressBean")
@ViewScoped
public class DirectAddressBean extends AbstractBackingBean implements Serializable {
	private static final long serialVersionUID = 1L;
	//protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");
	private List<DirectAddressVO> directAddressVOList;
	private DirectAddressVO selectedDirectAddressVO;
	private boolean disablePrimary;
	private final String PRIMARY_Y = DirectAddressPrimary.Y.name();
	private final String PRIMARY_N = DirectAddressPrimary.N.name();
	private final String STATUS_ACTIVE = DirectAddressStatus.Active.name();
	private final String STATUS_INACTIVE = DirectAddressStatus.InActive.name();
	private String successMsg;
	private String errorMessage;


	public List<DirectAddressVO> getDirectAddressVOList() {
		return directAddressVOList;
	}

	public void setDirectAddressVOList(List<DirectAddressVO> directAddressVOList) {
		this.directAddressVOList = directAddressVOList;
	}

	public DirectAddressVO getSelectedDirectAddressVO() {
		return selectedDirectAddressVO;
	}

	public void setSelectedDirectAddressVO(
			DirectAddressVO selectedDirectAddressVO) {
		this.selectedDirectAddressVO = selectedDirectAddressVO;
	}

	public boolean isDisablePrimary() {
		return disablePrimary;
	}

	public void setDisablePrimary(boolean disablePrimary) {
		this.disablePrimary = disablePrimary;
	}

	public String getSuccessMsg() {
		return successMsg;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@PostConstruct
	public void init() {
		addRelyingPartyRequestParam(
				TrustBrokerWebAppConstants.TARGET,
				TrustBrokerWebAppConstants.RELYING_APP_URL_PROF,
				getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true
						: false);
		addRelyingPartyRequestParam(
				TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM,
				TrustBrokerWebAppConstants.RELYING_APP_ID,
				getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true
						: false);
		addRelyingPartyAlias(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)!=null? 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString():null);
		addSessionAttribute(TrustBrokerWebAppConstants.ACTION,
				TrustBrokerWebAppConstants.DIRECT_ADDRESS);
		setDisablePrimary(true);
		directAddressVOList = new ArrayList<DirectAddressVO>();
		UserTagServiceRequest request = buildUserTagServiceRequest(
				getCurrentUserVO().getUuId(), TrustBrokerWebAppConstants.DIRECT_EMAIL_ADDRESS);
		UserTagServiceResponse response = container.getUserTagService()
				.querySpecificUserTag(request);
		populateDirectAddressData(response.getTagVOList());
	}

	private void populateDirectAddressData(List<TagVO> tagVOList) {
		if (null != tagVOList && tagVOList.size() > 0) {
			for (TagVO eSSOTagVO : tagVOList) {
				DirectAddressVO directAddressVO = new DirectAddressVO();
				directAddressVO.setUserTagId(eSSOTagVO.getUserTagId());
				for (AttributeVO attrVO : eSSOTagVO.getAttributeVOList()) {
					if ("value".equalsIgnoreCase(attrVO.getName()))
						directAddressVO.setValue(attrVO.getValue());
					if ("status".equalsIgnoreCase(attrVO.getName()))
						directAddressVO.setStatus(STATUS_ACTIVE
								.equalsIgnoreCase(attrVO.getValue()) ? "Y"
								: "N");
					if ("primary".equalsIgnoreCase(attrVO.getName())) {
						if (StringUtils.isBlank(attrVO.getValue())
								&& tagVOList.size() == 1)
							directAddressVO.setPrimary(PRIMARY_Y);
						else
							directAddressVO.setPrimary(PRIMARY_Y
									.equalsIgnoreCase(attrVO.getValue()) ? "Y"
									: "N");
					}
				}
				directAddressVOList.add(directAddressVO);
			}
		}
	}

	public String setPrimary() {
		setSuccessMsg("");
		setErrorMessage("");
		List<TagVO> tagVOList = new ArrayList<TagVO>();
		try {
			updatePrimaryFlag();

			for (DirectAddressVO directAddrVO : directAddressVOList) {
				TagVO tagVO = new TagVO();
				tagVO.setName(TrustBrokerWebAppConstants.DIRECT_EMAIL_ADDRESS);
				tagVO.setUserTagId(directAddrVO.getUserTagId());
				List<AttributeVO> attrVOList = new ArrayList<AttributeVO>();

				AttributeVO valueAttrVO = new AttributeVO();
				valueAttrVO.setName("VALUE");
				valueAttrVO.setValue(directAddrVO.getValue());
				attrVOList.add(valueAttrVO);

				AttributeVO statusAttrVO = new AttributeVO();
				statusAttrVO.setName("STATUS");
				statusAttrVO.setValue("Y".equalsIgnoreCase(directAddrVO
						.getStatus()) ? STATUS_ACTIVE : STATUS_INACTIVE);
				attrVOList.add(statusAttrVO);

				AttributeVO primaryAttrVO = new AttributeVO();
				primaryAttrVO.setName("PRIMARY");
				primaryAttrVO.setValue("Y".equalsIgnoreCase(directAddrVO
						.getPrimary()) ? PRIMARY_Y : PRIMARY_N);
				attrVOList.add(primaryAttrVO);
				tagVO.setAttributeVOList(attrVOList);
				tagVOList.add(tagVO);
			}
			UserTagServiceRequest request = buildUserTagServiceRequest(
					getCurrentUserVO().getUuId(), TrustBrokerWebAppConstants.DIRECT_EMAIL_ADDRESS);
			request.setTagVOList(tagVOList);
			UserTagServiceResponse response = container.getUserTagService()
					.updateUserTag(request);
			logger.debug(response.getExecutionStatus().getStatusMessage());
			if (response.getExecutionStatus().getStatusCd()
					.equalsIgnoreCase(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
				
					setSuccessMsg(tbResources.getString("updateDASuccess"));
			}
		}
		catch (OperationFailedException ofe) {
			setErrorMessage(ofe.getMessage());
			return null;
		}
		catch (Exception e) {
			String uid = UuidUtil.generateUid();
			logger.error("Error occured during updating direct address to user {}", new String[]{getCurrentUserVO().getUserName(),uid},e);
			SupportContactInfoVO sci = getSupportContactInfo();
			Object[] msgArguments = {sci.getEmailAddress(), sci.getPhoneNumber(), sci.getName(), uid};
			setErrorMessage(TBUtil.formatMessage(tbResources.getString("updateDAFailure"), msgArguments));
			return null;
		}

		setDisablePrimary(true);
		directAddressVOList = new ArrayList<DirectAddressVO>();
		UserTagServiceRequest request = buildUserTagServiceRequest(
				getCurrentUserVO().getUuId(), TrustBrokerWebAppConstants.DIRECT_EMAIL_ADDRESS);
		UserTagServiceResponse response = container.getUserTagService()
				.querySpecificUserTag(request);
		populateDirectAddressData(response.getTagVOList());
		return null;
	}

	private void updatePrimaryFlag() {
		for (DirectAddressVO directAddressVO : directAddressVOList) {
			if (directAddressVO.getValue().equalsIgnoreCase(
					selectedDirectAddressVO.getValue()))
				directAddressVO.setPrimary("Y");
			else
				directAddressVO.setPrimary("N");
		}
	}

	public void onRowSelect(SelectEvent event) {
		setDisablePrimary(true);
		if ("Y".equalsIgnoreCase(selectedDirectAddressVO.getStatus())
				&& "N".equalsIgnoreCase(selectedDirectAddressVO.getPrimary()))
			setDisablePrimary(false);
	}

	public void onRowUnSelect(UnselectEvent event) {
		setDisablePrimary(true);
	}

	public String cancel() {
	
		return "/secure/home?faces-redirect=true";		
	}

}
