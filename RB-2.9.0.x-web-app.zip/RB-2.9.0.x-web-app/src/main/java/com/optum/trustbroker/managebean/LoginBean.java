package com.optum.trustbroker.managebean;

import java.io.IOException;
import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.extensions.FilteredRequest;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBHttpUtils;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.ExecutionStatus;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RPAppDomainVO;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserAuthorizationRequest;
import com.optum.trustbroker.vo.UserChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.commons.beans.EmailDetail;
import com.uhg.iam.commons.utils.ValidationUtilities;

@ManagedBean(name = "loginBean")
@ViewScoped
public class LoginBean extends AbstractBackingBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private BaseLogger logger = new BaseLogger(LoginBean.class);
	private static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");
	
	private static final String SIGN_IN_PAGE_VIEW_ID = tbResources.getString("SignInPageViewId");
	private static final String LOGOUT_PAGE = tbResources.getString("LogOutPage");

	String userUnlockSuccess = "/views/userunlocksuccess.xhtml?faces-redirect=true";
	String vaildSignInPage = "/secure/home.xhtml?faces-redirect=true";
	String forgotUserNamePage = "/views/forgotusernamepage.xhtml?faces-redirect=true";
	String forgotPwdPage = "/views/forgotpasswordpage.xhtml?faces-redirect=true";
	String loginPage = "/views/login.xhtml?faces-redirect=true";
    String loginUrl = "/views/login.jsf";
    String registrationPage = "/views/userregistration.xhtml?faces-redirect=true";
	private String action = "/siteminderagent/forms/login.fcc";
	private String targetUrl = "/tb/secure/home.jsf";
	private String accountrecoveryoptions = "/views/accountrecoveryoptions.xhtml?faces-redirect=true";
    private String termsAndConditionContent;
	private String pwdChangeSuccessMsg;
	private String localenv = "false";
	private String relyingPartyTargetURL = null;
	private String errorMsg = null;
	private String duplicateAccountErrorMsg = null;
	private String relyingAppErroMsg = null;
	private String relyingAppstatusMsg=null;
	private String emailVerifiedSuccessMsg=null;
	private boolean unlockAccount;
	private String username;
	private String password;
	private String emailMsg;
	private String emailId;
	private  boolean showRegistration=true;
	private String forgotUserNameForgotPwd="/views/forgotUserNameForgotEmail.xhtml?faces-redirect=true";

	public void preRenderView() {
        // stop execution for Ajax calls
        try {
            if (FacesContext.getCurrentInstance().isPostback()) {
                return;
            }
        }
        catch (Exception e) {
            // ignore
        }
        // makes sure init is called before any rendering
        init();
	}


//	@PostConstruct
	public void init() {

        if (!initOpenIdConnectForEntry(loginUrl)) {
            return;
        }

		// start - localizing strings for debug
		String requestRelyingAppIdParam = getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);// RP App id
		String requestEncrypt = getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT);//Not required
		String requestFailReason = getRequestParameter(TrustBrokerWebAppConstants.LOGIN_FAIL_REASON);//Reason to navigate to login - Locked, incorrect credentials, time out
		String requestUserId = getRequestParameter(TrustBrokerWebAppConstants.USER_ID); // Not required
		String headerUserName = getServletRequest().getHeader(TrustBrokerWebAppConstants.SM_USER_NM_HEADER); // Step Up use case- Leave it
		String requestTarget = getRequestParameter(TrustBrokerWebAppConstants.TARGET); // Target URL
		String requestUnalteredTarget = getRequestParameter(FilteredRequest.UNALTERED_PARAM_NAME); // Leav it
		String viewId = getFacesContext().getViewRoot().getViewId();
		String requestReason = getRequestParameter("reason");//Duplicate to LOGIN_FAIL_REASON
		if (logger.isDebugEnabled()) {
			logger.debug("request relying app id param", requestRelyingAppIdParam);
			logger.debug("request encrypt", requestEncrypt);
			logger.debug("request fail reason", requestFailReason);
			logger.debug("request user id", requestUserId);
			logger.debug("header user name", headerUserName);
			logger.debug("request target", requestTarget);
			logger.debug("request unaltered target", requestUnalteredTarget);
			logger.debug("view id", viewId);
		}
		// end - localizing strings for debug

		setErrorMsg("");
		setUnlockAccount(false);
		
		setRpSuppParam(requestRelyingAppIdParam, requestEncrypt);//Not required
		checkIfRPRedirectRequired(); // Not required
		showRegistrationButtonIfRequired();//Leave it for now
		
		//Clear if any previous session values
		clearPrevSessionValues(); // Leave
		
		if (TBUtil.isLocalEnv()) { // Leave
			localenv = "true";
		}
		
		HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
		Cookie cookies[] = request.getCookies();
		String smresponsecode = "0";
		String smusrmsg = "0";
		String lockedUserID = "";
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (logger.isDebugEnabled()) {
					logger.debug("cookie name: ", cookies[i].getName());
					logger.debug("cookie value: ", cookies[i].getValue());
					logger.debug("cookie path: ", cookies[i].getPath());
					logger.debug("cookie domain: ", cookies[i].getDomain());
				}
				if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_RESPONSE_CODE)) {
					// Read cookie SMRESPONSECODE value
					smresponsecode = cookies[i].getValue();
					deleteCookie(cookies[i]);
				}
				else if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_USER_MSG)) {
					smusrmsg = cookies[i].getValue();
					deleteCookie(cookies[i]);
				}
				else if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_USERID)) {
					lockedUserID = cookies[i].getValue();
					deleteCookie(cookies[i]);
				}
			}
		}
		//Leave it for later
		if (StringUtils.isBlank(this.username) && StringUtils.isNotBlank(headerUserName) &&
				getSessionAttribute(TrustBrokerWebAppConstants.AUTH_STEP_UP) != null){
			this.username = headerUserName;
		}

		if (StringUtils.isBlank(lockedUserID) && StringUtils.isNotBlank(requestUserId)) {
			lockedUserID = requestUserId;
		}
		
		if (TrustBrokerWebAppConstants.REASON_ACCOUNT_VERIFIED.equalsIgnoreCase(requestFailReason)){
			emailVerifiedSuccessMsg = tbResources.getString("emailVerifiedSuccess");
		}

		if (TrustBrokerWebAppConstants.REASON_PWD_LOCKED.equalsIgnoreCase(requestFailReason) || 
				TrustBrokerWebAppConstants.REASON_RSA_LOCKED.equalsIgnoreCase(requestFailReason)) {
			errorMsg = TrustBrokerWebAppConstants.REASON_PWD_LOCKED.equalsIgnoreCase(requestFailReason) ? 
					tbResources.getString("accountLockMsg") : tbResources.getString("suspendMsg");
			
			if (StringUtils.isNotBlank(lockedUserID)){
				setUnlockAccount(true);
				addUserDetailMapToSession(lockedUserID);
				SecurityLoggingUtil.warn("User Login", SecurityEventType.E3_DISABLE, getServletRequest(), lockedUserID,
						"Security Audit Event|CreateUserSession:FAILED| User session denied | Account Disabled, LoginBean:init()",
						SecurityEventResult.FAILURE, getRelyingPartyAppId(), SecuritySubEventType.E3_DISABLE_LDAP);
				
				String result = unlockUserAccount();
				if(result != null && result.equalsIgnoreCase(accountrecoveryoptions)){
					redirectToView("/views/accountrecoveryoptions.jsf");
					return;
				}
			}
		} else if (TrustBrokerWebAppConstants.REASON_SESSION_TIMEOUT_1.equalsIgnoreCase(requestFailReason)) {
			errorMsg = "Your session has timed out. Please login again.";
		} else if (TrustBrokerWebAppConstants.REASON_SESSION_TIMEOUT_2.equalsIgnoreCase(requestFailReason)) {
			errorMsg = "Your session has timed out. Please try again.";
		} else if (!"0".equals(smresponsecode)) {
			
			if ("2".equals(smresponsecode) && TrustBrokerWebAppConstants.SM_LOGIN_FAILED_USR_MSG.equalsIgnoreCase(smusrmsg)) {
				if (StringUtils.isNotEmpty(lockedUserID)) {
				 	
					UserVO userVO = container.getUserService().fetchUserProfile(lockedUserID, false, true).getUser();
					
					if(!userVO.getAaStatus().equals(TrustBrokerConstants.AA_LOCK_STATUS) && ((userVO.getUserChallengeQuestions()==null) || 
							(userVO.getUserChallengeQuestions()!=null && userVO.getUserChallengeQuestions().size()==0))){
						addUserDetailMapToSession(lockedUserID);
						redirectToView("/views/sentauthorizationcodesqa.jsf");
						return;
					}
					
					errorMsg = tbResources.getString("suspendMsg");
					addUserDetailMapToSession(lockedUserID);
					SecurityLoggingUtil.warn("User Login", SecurityEventType.E3_DISABLE, getServletRequest(), lockedUserID,
							"Security Audit Event|CreateUserSession:FAILED| User session denied | Account Suspended, LoginBean:init()",
							SecurityEventResult.FAILURE, getRelyingPartyAppId(), SecuritySubEventType.E3_DISABLE_RSA);
					
					setUnlockAccount(true);
					
					String result = unlockUserAccount();
					if(result != null && result.equalsIgnoreCase(accountrecoveryoptions)){
						redirectToView("/views/accountrecoveryoptions.jsf");
						return;
					}
				}
			}
			else if ("1".equals(smresponsecode) || "2".equals(smresponsecode)){
				if(getSessionAttribute(TrustBrokerWebAppConstants.AUTH_STEP_UP) != null){
					errorMsg = "Please provide correct password";
				} else  errorMsg = "Invalid Username/Email or Password";
				
				if(StringUtils.isNotBlank(lockedUserID)){
					SecurityLoggingUtil.warn("User Login", SecurityEventType.E4, getServletRequest(), lockedUserID != null ? lockedUserID: "",
							"Security Audit Event|CreateUserSession:FAILED| User session denied | Incorrect username or password specified, LoginBean:init()",
							SecurityEventResult.FAILURE, getRelyingPartyAppId(), null);
				}
			}
			else if ("3".equals(smresponsecode)){
				errorMsg = "You are not authorized";
			}
			
		}
		
		if(errorMsg != null && !"".equals(errorMsg)) logger.error("User Login Error | Message -'{}' | User {}", new String[]{errorMsg, lockedUserID});

		if (isSessionAttributeExists(TrustBrokerWebAppConstants.PWD_CHANGE_MSG)) {
			setPwdChangeSuccessMsg((String) getSessionAttribute(TrustBrokerWebAppConstants.PWD_CHANGE_MSG));
			removeSessionAttribute(TrustBrokerWebAppConstants.PWD_CHANGE_MSG);
		}
		
		//TO-DO, This block needs a review whether it is required or not as per recent changes for filtered request.
		if (viewId != null && viewId.toUpperCase().startsWith(SIGN_IN_PAGE_VIEW_ID.toUpperCase())){
			//Keep same session variables as is if target URL contains -SM- (Site minder redirected URL). Otherwise clear out everything.
			if ((requestTarget == null && requestReason == null) 
					|| (requestTarget != null && !requestUnalteredTarget.contains("-SM-")
					&& !requestUnalteredTarget.contains("$SM$")) && "0".equals(smresponsecode)) {
				clearSessionAttributes(new String[]{TrustBrokerWebAppConstants.RELYING_APP_URL,
						TrustBrokerWebAppConstants.RELYING_APP_ID, TrustBrokerWebAppConstants.RELYING_APP_URL_PROF,
						TrustBrokerWebAppConstants.ACTION, TrustBrokerWebAppConstants.STATUS,
						TrustBrokerWebAppConstants.TERMS_CONDITON_ACCEPTED, TrustBrokerWebAppConstants.CURRENT_USER, 
						TrustBrokerWebAppConstants.LOGIN_TARGET, TrustBrokerWebAppConstants.RP_LOGO_NAME, 
						TrustBrokerWebAppConstants.AUTH_STEP_UP});
//				addLoginTarget();
				addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE);
			}
			
			setRpSuppParam(requestRelyingAppIdParam, requestEncrypt);
			if (StringUtils.isNotBlank(requestTarget) && StringUtils.isNotBlank(requestRelyingAppIdParam) &&
					"0".equals(smresponsecode)) {
				captureRelyingPartyInfo(requestEncrypt != null ? true:false);
				processRelyingPartyInfo();
			}
			else if (requestTarget != null && requestRelyingAppIdParam == null && "0".equals(smresponsecode)) {
				processRelyingPartyInfoForUpdateProfile();
			}
			addLoginTarget();
		}
	}
	
	private void checkIfRPRedirectRequired(){
		if(getRequestParameter(TrustBrokerWebAppConstants.RP_APP_REDIRECT_PARAM) != null && isParamContainsRelyingPartyInfo()){
			captureRelyingPartyInfo(false);
			String relyingPartyTargetURL = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null ? 
					(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) : 
						(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);
			String invitationToken = (String)getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE);
			relyingPartyTargetURL = invitationToken != null ? (relyingPartyTargetURL + "?" + TrustBrokerWebAppConstants.INVITATION_CODE 
					+ "=" + invitationToken) : relyingPartyTargetURL; 
			relyingPartyTargetURL =  constructRedirectUrl(relyingPartyTargetURL);
			
			if(null != getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA)){
				relyingPartyTargetURL = HttpUtils.addParameterToURL(relyingPartyTargetURL, 
						TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_LOGOUT_OPERATION, TrustBrokerWebAppConstants.LOGOUT);
			}
			
			if (logger.isDebugEnabled()) {
				logger.debug("redirecting to: " + relyingPartyTargetURL);
			}
			redirectionNonsso(relyingPartyTargetURL, 
					(String)getSessionAttribute(TrustBrokerWebAppConstants.ACTION),
					(String)getSessionAttribute(TrustBrokerWebAppConstants.STATUS),
					(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			
			clearSessionAttributes(new String[]{TrustBrokerWebAppConstants.RELYING_APP_URL, TrustBrokerWebAppConstants.RELYING_APP_URL_PROF, 
					TrustBrokerWebAppConstants.ACTION, TrustBrokerWebAppConstants.STATUS});
		}
	}
	
	private void showRegistrationButtonIfRequired(){
		String showRegStr=getRequestParameter(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP);
		if(showRegStr == null)
			showRegStr=getRequestParameter(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP.toUpperCase());
		if(showRegStr == null)
			showRegStr=getRequestParameter(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP_ALT);
		if(showRegStr == null)
			showRegStr=getRequestParameter(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP_ALT.toUpperCase());
		if(showRegStr!=null ){	
			addSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP, showRegStr);
			if( TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP_VAL .equalsIgnoreCase( showRegStr ))
	           setShowRegistration(false);
			logger.debug("LoginBean.init() - set session attribute for showRegistration. session attribute: " 
					+ getSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP));
	    }
	}
	
	private void addLoginTarget(){
		if(!isSessionAttributeExists(TrustBrokerWebAppConstants.LOGIN_TARGET)){
			addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, 
					HttpUtils.addParameterToURL(targetUrl, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, 
							TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE));
		}
	}
	
	private void processRelyingPartyInfoForUpdateProfile(){
		String target = getRequestParameter(TrustBrokerWebAppConstants.TARGET);
		
		try{
			logger.debug("LoginBean:processRelyingPartyInfoForUpdateProfile() url captured in case of profile update {}", 
					new String[]{target});
			
			URI targetURL = URI.create(target);
			String hostURI = targetURL.getPath();
			String queryString = targetURL.getQuery();
			
			if(hostURI != null && (hostURI.contains(tbResources.getString("updateProfileURI")) ||
					hostURI.contains(tbResources.getString("changePasswordURI")) ||
					hostURI.contains(tbResources.getString("updateSecurityQuestion"))) && 
					TrustbrokerWebAppUtil.isQueryContainsRelyingPartyContext(queryString)){
				
				for (String param : queryString.split("&")) {
			        String pair[] = param.split("=");
			        String key = URLDecoder.decode(pair[0], "UTF-8");
			        String value = "";
			        if (pair.length > 1) {
			            value = URLDecoder.decode(pair[1], "UTF-8");
			        }
			        
			        if(key.equals(TrustBrokerWebAppConstants.TARGET) && StringUtils.isNotBlank(value)){
			        	addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL, value);
			        	logger.debug("LoginBean:processRelyingPartyInfoForUpdateProfile() target url parsed {}:", 
								new String[]{value});
			        } else if(key.equals(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) && StringUtils.isNotBlank(value)){
			        	logger.debug("LoginBean:processRelyingPartyInfoForUpdateProfile() relyingAppId parsed {}:", 
								new String[]{value});
			        	addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, value);
			        }
			    }
				
				this.targetUrl = targetURL.getPath();
				addSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET, this.targetUrl); //In case user goes through self-service, preserve it.
				this.username = getServletRequest().getHeader(TrustBrokerWebAppConstants.SM_USER_NM_HEADER);
				logger.debug("LoginBean:processRelyingPartyInfoForUpdateProfile() SM Login target URL set to {} and current user name from header", 
						new String[]{targetURL.getPath(), this.username});
				
				if(StringUtils.isNotBlank(this.username)){
					addSessionAttribute(TrustBrokerWebAppConstants.AUTH_STEP_UP, tbResources.getString("updateProfileOTPMsg"));
				}
				processRelyingPartyInfo();
			}
		}catch(Exception ex){
			//Eat up the exception
		}
	}
	
	@SuppressWarnings("unchecked")
	public void sendAuthLink() throws IOException {
		Map<String, String> userDetailMap = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		String userName = userDetailMap.get(TrustBrokerWebAppConstants.USER_NAME);
		UserVO userVO = container.getUserService().fetchUserProfile(userName, false, true).getUser();
		userVO.setCreatedBy(getRelyingPartyName());
		String rpAppId = getRelyingPartyAppId();
		UserAuthorizationRequest userAuthorizationRequest = generateAuthorizationRequest(userVO);
		container.getUserService().sendAuthCodeToUser(userAuthorizationRequest, TrustBrokerConstants.SQA, rpAppId,
				true, getUrlLogoOptumId(), getUrlLogoRelyingParty());
		SecurityLoggingUtil.info("SQA Missing ",SecurityEventType.E3_CREATE,getServletRequest(),userVO.getUserName(),	
				"Security Audit Event|SQA Missing authorization code :SUCCESS|Authorization Code sent to User, LoginBean:init()",
						SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_CREATE_AUTH_CODE);
		redirectToView("/views/sentauthorizationcodesqa.jsf");
	}
	
	private void processRelyingPartyInfo(){
		String relyingAppId = getRelyingPartyAppId();
		relyingPartyTargetURL =  (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		SupportContactInfoVO sci = getSupportContactInfo();
		
		if (relyingAppId != null) {
			RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);

			if (relyingPartyAppVO == null){
				relyingAppErroMsg = TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J003).getEndUserMessage(
						container.getErrorMessageSource(), sci);
        setRpSuppParam(getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT));
			} else if (StringUtils.isNotBlank(relyingPartyTargetURL)) {
				addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
				try {
					String rpDomainName = TBUtil.getDomainName(relyingPartyTargetURL);
					boolean isdomainValid=false;
					if(relyingPartyAppVO.getRpAppDomains()!=null&&relyingPartyAppVO.getRpAppDomains().size()>0)
						isdomainValid=isDomainValid(relyingPartyAppVO.getRpAppDomains(),rpDomainName);
					
					if (relyingPartyAppVO!=null && !isdomainValid && (relyingPartyAppVO.getStatusId().intValue() == TrustBrokerConstants.ACTIVE_STATUS)){
						relyingAppErroMsg = TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J002).getEndUserMessage(
								container.getErrorMessageSource(), sci);
					}
					
					if (relyingPartyAppVO.getStatusId() == TrustBrokerConstants.SUSPENDED.intValue()) {
						relyingAppstatusMsg = TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J004).getEndUserMessage(
								container.getErrorMessageSource(), sci);
						if (relyingPartyAppVO.getApplicationName().length() > 0)
							relyingAppstatusMsg += "</br></br></br>" +tbResources.getString("denialMessage1") + " " + 
									relyingPartyAppVO.getApplicationName() + " " + tbResources.getString("denialMessage2");
						else
							relyingAppstatusMsg += "</br></br></br>" + tbResources.getString("denialMessage");
					}
					else if (relyingPartyAppVO.getStatusId() == TrustBrokerConstants.DEACTIVE_STATUS.intValue()) {
						relyingAppErroMsg=TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J005).getEndUserMessage(
								container.getErrorMessageSource(), sci);
					}
					else if(StringUtils.isBlank(relyingPartyAppVO.getPartnerId())) {
						relyingAppErroMsg = TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J001).getEndUserMessage(
								container.getErrorMessageSource(), sci);
					}
				}
				catch (URISyntaxException e) {
					logger.error(e.getMessage());
				}
			}
			
			if(StringUtils.isNotBlank(relyingAppErroMsg) || StringUtils.isNotBlank(relyingAppstatusMsg)){
				clearSessionAttributes(new String[]{TrustBrokerWebAppConstants.RELYING_APP_URL, TrustBrokerWebAppConstants.RELYING_APP_ID});
			}else{
				addSessionAttribute(TrustBrokerWebAppConstants.RP_LOGO_NAME, relyingPartyAppVO.getRpLogoFileName());
				removeSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET);
				
				if(getSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET) != null) {
					this.targetUrl = (String)getSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET);
				}


                // this logic should be common and not here!
                String loginTarget
                        = TBHttpUtils.addParametersToUrl(this.targetUrl,
                                                         TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, relyingPartyAppVO.getAlias(),
                                                         TrustBrokerWebAppConstants.TARGET,  (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL),
                                                         TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, relyingAppId);

                @SuppressWarnings("unchecked")
                Map<String, String> mOidData = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
                if (mOidData != null) {
                    String oidData = container.getCryptAgentUtil().getCryptAgent().createToken(mOidData);
                    loginTarget
                            = TBHttpUtils.addParametersToUrl(loginTarget,
                                                             TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA, oidData);
                }

				addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, loginTarget);
			}
		}
	}
	
	public boolean isDomainValid(List<RPAppDomainVO> domains,String domainName){
		return TBUtil.isDomainValid(domains, domainName);
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username.trim();
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password.trim();
	}

	/**
	 * Request Handler[POST] for login page.
	 *
	 * The form fields are validated and authenticate method is called.
	 *
	 *
	 * @return the string - valid sign in navigation page URL if authentication
	 *         is success. otherwise returns null [appropriate face error
	 *         message is set]
	 */
	@RequestMapping(method = RequestMethod.POST)
	public String doNavigation() {
		logger.debug("com.optum.trustbroker.managebean.LoginBean.doNavigation() :Email check"+emailId);
		UserProfileServiceRequest userProfileServiceRequest = null;
		
		String navPage = fetchUserProfile(emailId);
		
		if (StringUtils.isEmpty(navPage) && validateEmailId(emailId)) {
			try {
				logger.debug("com.optum.trustbroker.managebean.LoginBean.checkEmail(ValueChangeEvent) :Valid Email "+emailId);
				userProfileServiceRequest = new UserProfileServiceRequest();
				UserVO userVO = new UserVO();
				userVO.setEmailAddress(emailId);
				userProfileServiceRequest.setUser(userVO);
				this.username = container.getUserService().getUserNameDetailByEmail(userProfileServiceRequest);
			} catch (OperationFailedException exception) {
				logger.debug("com.optum.trustbroker.managebean.LoginBean.checkEmail(ValueChangeEvent) :Error  "+emailId);
				this.username = "";
				if(exception.getErrorMessage().getCode().equals(TrustBrokerConstants.OPT_00A0012)){
					errorMsg = tbResources.getString("duplicateAccount");
				}else {
					errorMsg = "No user record was found with this email. Please verify your email address and try again.";
				}
				return null;
			}
		} else {
			this.username = emailId;
		}
		
		logger.info("LoginBean::doNavigation()");

		if (!validateLoginFields()) {
			return null;
		}

		return navPage;
	}

	/**
	 * This is for local environment login only, and is not part of any env login.
	 * @param username
	 * @return
	 */
	private String fetchUserProfile(String username) {
		FacesContext context = getFacesContext();
		UserRetrievalServiceResponse userRetrievalResponse = null;
		ExecutionStatus executionStatus = null;
		UserVO user = null;

		try {
			userRetrievalResponse = container.getUserService().fetchUserDetailsForSession(username);
		} catch (OperationFailedException exception) {
			// TODO NoClassDefFoundError looks like I logged in incorrectly when I haven't
			logger.error("LoginBean::fetchUserProfile()::Failed to fetch profile "+ username, exception);
			setUsername("");
			setErrorMsg("");
			context.addMessage(null, new FacesMessage("Invalid Username/Email or Password"));
			return null;
		}

		executionStatus = userRetrievalResponse.getExecutionStatus();
		user = userRetrievalResponse.getUser();

		if (executionStatus.getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE) && user != null) {
			setCurrentUserVO(user);
			return getHomePageURIWithAlias();
		} else {
			logger.info("LoginBean::fetchUserProfile()::ExecutionStatus" + TrustBrokerConstants.FAILURE_CODE_VALUE);
			setUsername("");
			context.addMessage(null, new FacesMessage("Invalid Username/Email or Password "));
			setErrorMsg("");
			return null;
		}
	}

	/**
	 * Server side form fields validation.
	 *
	 * @return true - if the validation is success. returns false otherwise
	 */
	public boolean validateLoginFields() {
		logger.info("LoginBean::validateLoginFields()");
		FacesContext context = getFacesContext();

		if (getUsername().equals("")) {
			context.addMessage(null, new FacesMessage(
					"Invalid Username/Email or Password "));
			context.addMessage(null, new FacesMessage("Reminder: Username and Password are case sensitive"));
			setErrorMsg("");
			return false;
		}

		if (getPassword().equals("")) {
			context.addMessage(null, new FacesMessage(
					"Invalid Username/Email or Password"));
			setErrorMsg("");
			return false;
		}

		return true;
	}


	@RequestMapping(method = RequestMethod.GET)
	public String register() {
		removeSessionAttribute("warnmsg");
        String registriongUrl = constructURLWithRPParams(this.registrationPage);
		if(!isSessionContainsRelyingPartyInfo()){
		   getSessionMap().put("registerType", "standAlone");
		}
        return registriongUrl;
	}

	public boolean validateUserNameField() {
		if (getUsername().equals("")) {
			getFacesContext()
					.addMessage(
							null,
							new FacesMessage(
									"Type in the username and click Forgot Password link."));
			setErrorMsg("");
			return false;
		}

		return true;
	}

	/**
	 * Gets the faces context
	 *
	 * @return current FacesContext otherwise
	 */
	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	public String forgotUserNameClicked() {
		removeSessionWithoutRelyingPartyInfo();
		return forgotUserNamePage;
	}
   public String forgotUserNameForgotPwdClicked(){
	   
	   removeSessionWithoutRelyingPartyInfo();
	   return forgotUserNameForgotPwd;
   }
	public String signInClicked() {
		return loginPage;
	}

	public String forgotPasswordClicked() {
		removeSessionWithoutRelyingPartyInfo();
		return forgotPwdPage;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public String getLocalenv() {
		return localenv;
	}

	public void setLocalenv(String localenv) {
		this.localenv = localenv;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getRelyingAppErroMsg() {
		return relyingAppErroMsg;
	}

	public void setRelyingAppErroMsg(String relyingAppErroMsg) {
		this.relyingAppErroMsg = relyingAppErroMsg;
	}
	
	public boolean isUnlockAccount() {
		return unlockAccount;
	}

	public void setUnlockAccount(boolean unlockAccount) {
		this.unlockAccount = unlockAccount;
	}

	@RequestMapping(method = RequestMethod.POST)
	public String signOut(){
		String loggedInUser = null;

		if(getCurrentUserVO() != null) {
			loggedInUser = getCurrentUserVO().getUserName();
			logger.debug("LoginBean:: "+loggedInUser+" Signed out from application");
		}

		String relyintPartyRedirectionParams = getRelyingPartyRedirectionParameters();
		
		if(getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_TOKEN_ENCODED) != null 
				&& StringUtils.isNotBlank(relyintPartyRedirectionParams)){
			relyintPartyRedirectionParams += "&" +TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA + "=" +
					(String)getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_TOKEN_ENCODED);
		}
		
		getFacesContext().getExternalContext().invalidateSession();

		if(loggedInUser != null){
			SecurityLoggingUtil.info("User Login", SecurityEventType.E1_TERMINATE, getServletRequest(), loggedInUser,
					"Security Audit Event|TerminateUserSession:SUCCESS | User session TERMINATED, LoginBean:signOut()",
					SecurityEventResult.SUCCESS, getRelyingPartyAppId(), null);
		}
		
		return relyintPartyRedirectionParams != null ? (LOGOUT_PAGE + "&" + relyintPartyRedirectionParams + "&" +
						TrustBrokerWebAppConstants.RP_APP_REDIRECT_PARAM + "=true") : LOGOUT_PAGE;
	}

	public String unlockUserAccount() {
		addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE, TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK);
		addSessionAttribute("SELF_ACC_RECOVER_TYPE", TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK);
		removeSessionAttribute(TrustBrokerWebAppConstants.RECOVERY_BY_EMAIL);

		@SuppressWarnings("unchecked")
		Map<String, String> userDetails = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		
		UserVO userVO = null;
		try {
			userVO = container.getUserService().fetchUserProfile((userDetails.get(TrustBrokerWebAppConstants.USER_NAME)), false, true).getUser();
			userDetails.put("emailId", userVO.getEmailAddress());
			userDetails.put("uuId", userVO.getUuId());
			String mobilePhone = null;
			boolean mobilePhoneVerified = false;
			if (StringUtils.isNotBlank(userVO.getPhoneNumber())) {
				mobilePhone = userVO.getPhoneNumber();
				mobilePhoneVerified = userVO.getIsPhoneVerified();
			}
			boolean userHasSecQuestions = false;
			if (!TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(userVO.getAaStatus())) {
				try {
					UserChallengeQuestionServiceResponse userChallengeResp = getContainer().getUserService().getChallengeQuestions(userVO.getUuId(),
							TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
					if (null != userChallengeResp && null != userChallengeResp.getUserChallengeQuestions() &&
							userChallengeResp.getUserChallengeQuestions().size() > 0) {
						userHasSecQuestions = true;
					} 
				}
				catch(OperationFailedException ofe) {
					logger.error("failure getting challenge questions", ofe);
				}
			}
			if((StringUtils.isNotBlank(userVO.getEmailAddress()) && userVO.isIsemailVerified() && userVO.isPrimaryEmailUnique()) 
					|| (StringUtils.isNotBlank(userVO.getSecEmailAddress()) && userVO.isSecEmailVerified() && userVO.isSecEmailUnique())
				|| (StringUtils.isNotBlank(mobilePhone) && mobilePhoneVerified) || (userHasSecQuestions)) 
				return accountrecoveryoptions;
			else {
				setErrorMsg(TBUtil.formatMessage(tbResources.getString("acctNotVerifiedMsg"), 
						new String[]{getSupportContactInfo().getContactComboText()}));
				setUnlockAccount(false);
				return null;
			}
			
		}
		catch(OperationFailedException ofe) {
			logger.error("Exception while fetching the user details for user {}", 
					new String[]{userDetails.get(TrustBrokerWebAppConstants.USER_NAME), 
					TrustbrokerWebAppUtil.getUidFromError(ofe)} , ofe);
			logger.error("unlock user account exception details", ofe);
			return loginPage + "&" + getRelyingPartyRedirectionParameters();
		}
		catch (Exception e) {
			logger.error("unlock user account exception details", e);
			return loginPage + "&" + getRelyingPartyRedirectionParameters();
		}
	}

	public boolean getShowRegistration(){
		setShowRegistrationFromSession();
		return showRegistration;
	}
	public void setShowRegistration(boolean val){
		showRegistration=val;
	}

	public void setShowRegistrationFromSession(){
		String showRegStr = (String)getSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP);
		if( TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP_VAL.equals(showRegStr))
		    showRegistration=false;
	}

	public void actionListener(ActionEvent event) {
		emailId = getServletRequest().getParameter("EMAIL");
		UserProfileServiceRequest userProfileServiceRequest = null;
		duplicateAccountErrorMsg = null;
		errorMsg = null;
		UserVO userVO = null;
		try {
			//check if user with given user name exists by checking user uuid
			String uuid = container.getUserService().getUserUuid(emailId);
			if(!StringUtils.isEmpty(uuid)) {
				this.username = emailId;
			} else {
				//If the username is valid email address, get username for the email else just return the entered username value
				if (TBUtil.validateEmailId(emailId)) {
					try {
						userProfileServiceRequest = new UserProfileServiceRequest();
						userVO = new UserVO();
						userVO.setEmailAddress(emailId);
						userProfileServiceRequest.setUser(userVO);
						this.username = container.getUserService().getUserNameDetailByEmail(userProfileServiceRequest);
					} catch (OperationFailedException exception) {
						logger.error("Error while fetching user details by email id ", emailId);
						this.username = "";
						if(exception.getErrorMessage().getCode().equals(TrustBrokerConstants.OPT_00A0012)){
							duplicateAccountErrorMsg = tbResources.getString("duplicateAccount");
						}else {
							errorMsg = "No user record was found with this email. Please verify your email address and try again.";
						}
					}
				}  else {
					this.username = emailId;
				}
			}
			
		} catch (Exception exception) {
			logger.error("Error while fetching user details by username ", emailId);
			this.username = emailId;
		}
		
	}
	
	public String onlineSecurity(){
		addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE, TrustBrokerWebAppConstants.ONLINE_SECURITY_FLOW);
		
		addSessionAttribute("SELF_ACC_RECOVER_TYPE", TrustBrokerWebAppConstants.ONLINE_SECURITY_FLOW);
		return accountrecoveryoptions;
	}
	
	public static boolean validateEmailId(String enteredEmailId) {
		if (enteredEmailId != null && !enteredEmailId.equals("")) {
			EmailDetail emailDetail = new EmailDetail();
			emailDetail.setEmailAddress(enteredEmailId);
			emailDetail.setLabel("EMAIL");
			try {
				ValidationUtilities.isValidEmail(emailDetail);
			}
			catch (Exception e) {
				return false;
			}
		}
		return true;
	}
	
	private String constructRedirectUrl(String targetUrl)
	{
				
		if(null != getSessionAttribute("showDOB") && (Boolean) getSessionAttribute("showDOB")) {
			targetUrl = targetUrl.contains("?") ? targetUrl + "&" : targetUrl + "?";
			targetUrl = "dobupdated=y" ;
		}
		if(null != getSessionAttribute("showAddress") && (Boolean) getSessionAttribute("showAddress")) {
			targetUrl = targetUrl.contains("?") ? targetUrl + "&" : targetUrl + "?";
			targetUrl = "addressupdated=y" ;
		}
		if(null != getSessionAttribute("showMobilePhone") && (Boolean) getSessionAttribute("showMobilePhone")) {
			targetUrl = targetUrl.contains("?") ? targetUrl + "&" : targetUrl + "?";
			targetUrl = "mobilephoneupdated=y" ;
		}
		if(null != getSessionAttribute("ShowEmail") && (Boolean) getSessionAttribute("ShowEmail")) {
			targetUrl = targetUrl.contains("?") ? targetUrl + "&" : targetUrl + "?";
			targetUrl = "emailupdated=y" ;
		}
		
		return targetUrl;
	}

	public String getDuplicateAccountErrorMsg() {
		return duplicateAccountErrorMsg;
	}

	public void setDuplicateAccountErrorMsg(String duplicateAccountErrorMsg) {
		this.duplicateAccountErrorMsg = duplicateAccountErrorMsg;
	}

	private void clearPrevSessionValues() {
		removeSessionAttribute(TrustBrokerWebAppConstants.SKIP_VERIFY_FLOW);
		removeSessionAttribute("SKIP_VERIFY_FLOW_REGISTRATION");
	}

	public String getEmailVerifiedSuccessMsg() {
		return emailVerifiedSuccessMsg;
	}

	public void setEmailVerifiedSuccessMsg(String emailVerifiedSuccessMsg) {
		this.emailVerifiedSuccessMsg = emailVerifiedSuccessMsg;
	}
	
	public String getEmailMsg() {
		return emailMsg;
	}

	public void setEmailMsg(String emailMsg) {
		this.emailMsg = emailMsg;
	}
	
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPwdChangeSuccessMsg() {
		return pwdChangeSuccessMsg;
	}

	public void setPwdChangeSuccessMsg(String pwdChangeSuccessMsg) {
		this.pwdChangeSuccessMsg = pwdChangeSuccessMsg;
	}

	public String getRelyingAppstatusMsg() {
		return relyingAppstatusMsg;
	}

	public void setRelyingAppstatusMsg(String relyingAppstatusMsg) {
		this.relyingAppstatusMsg = relyingAppstatusMsg;
	}
	
	
	public String getTermsAndConditionContent() {
		if (StringUtils.isEmpty(termsAndConditionContent)) {
			termsAndConditionContent = getTermsAndConditionsText();
		}
		return termsAndConditionContent;
	}

	public void setTermsAndConditionContent(String termsAndConditionContent) {
		this.termsAndConditionContent = termsAndConditionContent;
	}

	
	
}
