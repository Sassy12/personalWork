package com.optum.trustbroker.util;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.ApplicationContextHolder;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.context.filter.WebApplicationContextManagerFilter;
import com.optum.trustbroker.controller.vo.StepupContextVO;
import com.optum.trustbroker.domain.UserPreference;
import com.optum.trustbroker.esso.sso.SsoContext;
import com.optum.trustbroker.esso.sso.utils.SsoUtils;
import com.optum.trustbroker.managebean.UserStepUpContext;
import com.optum.trustbroker.message.ErrorMessage;
import com.optum.trustbroker.service.ConfigurationService;
import com.optum.trustbroker.service.InvitationService;
import com.optum.trustbroker.service.ReferenceService;
import com.optum.trustbroker.service.RelyingPartyAppService;
import com.optum.trustbroker.service.TagService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.service.UserTagService;
import com.optum.trustbroker.vo.AttributeVO;
import com.optum.trustbroker.vo.InvitationServiceRequest;
import com.optum.trustbroker.vo.InvitationServiceResponse;
import com.optum.trustbroker.vo.InvitationVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.StatusVO;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.TagServiceRequest;
import com.optum.trustbroker.vo.TagServiceResponse;
import com.optum.trustbroker.vo.TagVO;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserTagServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.alps.common.Attribute;
import com.uhg.iam.alps.common.DefaultUser;
import com.uhg.iam.alps.common.User;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.alps.sso.SsoRequest;
import com.uhg.iam.alps.sso.SsoService;
import com.uhg.iam.esso.schemas.xsd._2013._12.AuthenticationType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

/**
 * Common utilities file to access the application context manager.
 *
 * @author Sachin Kumar
 * @version 1.0
 */
@Component
public class WebApplicationCommonUtilities {

	@Autowired
	private TagService tagService;

	@Autowired
	private Properties configProps;

	@Autowired
	private UserService userService;

	@Autowired
	private UserTagService userTagService;

	@Autowired
	private ReferenceService referenceService;

	@Autowired
	private ConfigurationService configService;

	@Autowired
	private InvitationService invitationService;

	@Autowired
	public SsoService providerDelegatingSsoService;

	@Autowired
	private RelyingPartyAppService relyingPartyAppService;

	@Autowired
	private ResourceBundleMessageSource tb_service_errorMessageResource;

	public static final String COPPA_REQD_NO_IND = "N";
	public static final String EMAIL_CONFM_REQD_NO_IND = "N";

	private static final BaseLogger LOGGER = new BaseLogger(WebApplicationCommonUtilities.class);

	/**
	 * Get the relying party application details if available within the
	 * context. Otherwise returns a null value object.
	 * 
	 * @return {@link RelyingPartyAppVO}
	 */
	public RelyingPartyAppVO getRelyingPartyApplicationDetailsFromContext() {
		RelyingPartyAppVO relyingPartyApplicationVO = null;
		String relyingPartyApplicationIdentifier = null;

		WebApplicationContext ctx = WebApplicationContextHolder.getContext();

		if (ctx != null) {
			relyingPartyApplicationIdentifier = ctx
					.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
		}

		if (StringUtils.isBlank(relyingPartyApplicationIdentifier)
				&& SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
			try {
				relyingPartyApplicationIdentifier = ApplicationContextHolder.getContext().retrieve(SsoContext.class)
						.getDestinationApp();
				LOGGER.debug("Loaded RP ID '{}' from '{}'",
						new Object[] {
								relyingPartyApplicationIdentifier != null ? relyingPartyApplicationIdentifier : null,
								SsoContext.class.getSimpleName() });
			} catch (Exception ex) {
				LOGGER.error("Failed to obtain RP ID from SSO broker request", ex);
			}
		}

		if (StringUtils.isNotBlank(relyingPartyApplicationIdentifier)) {
			relyingPartyApplicationVO = getRelyingPartyAppService()
					.fetchRelyingPartyAppByAppId(relyingPartyApplicationIdentifier);
		}

		return relyingPartyApplicationVO;
	}

	/**
	 * Get the contact details either for relying party if available within
	 * context otherwise stand alone application.
	 * 
	 * @param isCompleteInfo
	 *            , to specify whether to return email and phone number or just
	 *            phone number details.
	 * @return {@link SupportContactInfoVO}
	 */
	public SupportContactInfoVO getApplicationSupportContactInformation(Boolean isCompleteInfo) {
		RelyingPartyAppVO relyingPartyApplicationVO = null;

		relyingPartyApplicationVO = getRelyingPartyApplicationDetailsFromContext();

		if (isCompleteInfo) {
			return TBUtil.getSupportContactInfo(relyingPartyApplicationVO);
		} else {
			return TBUtil.getSupportContactPhoneNumber(relyingPartyApplicationVO);
		}

	}

	/**
	 * Get the current user details from web application context, if not found
	 * then redirect to error page. This method must be used only for post login
	 * scenarios as the user information is available post login only.
	 * 
	 * @return UserVO object.
	 */
	public UserVO getCurrentUserDetailsFromWebApplicationContext() {

		String userName = "";
		UserVO userVO = null;
		WebApplicationContext ctx = WebApplicationContextHolder.getContext();

		if ((ctx != null && StringUtils.isNotBlank(ctx.getRequestAttribute(TrustBrokerWebAppConstants.USER_ID)))
				|| TBUtil.isLocalEnv()) {
			userName = ctx.getRequestAttribute(TrustBrokerWebAppConstants.USER_ID);
			// To add user name from local login
			if (TBUtil.isLocalEnv() && StringUtils.isBlank(userName)) {
				userName = ctx.getSessionAttribute(TrustBrokerWebAppConstants.USERNAME_LOCAL);
			}
			//In registration flow, username_local is not available.
			if (StringUtils.isBlank(userName)) {

				return userVO;
			}
			try {
				UserRetrievalServiceResponse userRetrievalResponse = getUserService()
						.fetchUserDetailsForSession(userName);

				if (userRetrievalResponse != null && userRetrievalResponse.getUser() != null
						&& TrustBrokerConstants.SUCCESS_CODE_VALUE
								.equals(userRetrievalResponse.getExecutionStatus().getStatusCd())) {
					userVO = userRetrievalResponse.getUser();
				} else {
					// Handle user not found use case
					addErrorDetailsToSession(TrustBrokerConstants.OPT_00A003, null);
				}
			} catch (OperationFailedException ex) {
				LOGGER.error("Error while retrieving the user from context.", ex);
				if (ex.getErrorMessage() != null && ex.getErrorMessage().getCode() != null) {
					addErrorDetailsToSession(ex.getErrorMessage().getCode(), ex);
				} else {
					addErrorDetailsToSession(TrustBrokerConstants.OPT_00Z000, ex);
				}
			}
		} else {
			// handle no header information case
			addErrorDetailsToSession(TrustBrokerConstants.OPT_00C001, null);
		}

		return userVO;
	}

	/**
	 * Write the error details to state cookie to refer from error page during
	 * service call.
	 * 
	 * @param response
	 * @param errorCode
	 * @param th
	 */
	private ErrorMessage addErrorDetailsToSession(String errorCode, Throwable th) {
		WebApplicationContext ctx = WebApplicationContextHolder.getContext();
		ErrorMessage errorMessage = TrustBrokerUtil.getErrorMessage(errorCode);
		LOGGER.error(errorMessage.getTechnicalUserMesssage(tb_service_errorMessageResource), th);
		ctx.setRequestAttribute(TrustBrokerWebAppConstants.ERROR_CD, errorMessage.getCode());
		ctx.setRequestAttribute(TrustBrokerWebAppConstants.ERROR_UID, errorMessage.getUid());
		return errorMessage;
	}

	/**
	 * Redirect to relying party target URL with specified partner identifier.
	 * 
     * @param userVO
     * @param request
     * @param response
     * @return 
	 */
	public boolean redirectUserBackToRelyingPartyApplication(UserVO userVO, HttpServletRequest request,
			HttpServletResponse response) {

		try {
			String targetURL = WebApplicationContextHolder.getContext()
					.getSessionAttribute(TrustBrokerWebAppConstants.TARGET);

			if (targetURL == null && SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
				try {
					targetURL = ApplicationContextHolder.getContext().retrieve(SsoContext.class)
							.getTargetDestinationUrl();
					LOGGER.debug("Loaded final destination URL '{}' from '{}'", new Object[] {
							targetURL != null ? targetURL : null, SsoContext.class.getSimpleName() });
				} catch (Exception ex) {
					LOGGER.error("Failed to obtain target final destination url for SSO broker request", ex);
				}
			}

			RelyingPartyAppVO relyingPartyAppVO = this.getRelyingPartyApplicationDetailsFromContext();
			String partnerID;

			if (relyingPartyAppVO != null) {
				partnerID = relyingPartyAppVO.getPartnerId();
			} else {
				partnerID = TrustBrokerWebAppConstants.DEFAULT_PARTNER_ID;
			}

			deleteSessionContextCookie(request, response);// Delete cookie first
															// before
															// redirection
															// request

			SsoRequest ssoRequest = new SsoRequest(request, response);
			User user = new DefaultUser(userVO.getUserName()); // Always set
																// User's
																// userName
			ssoRequest.setUser(user);
			ssoRequest.setDestinationUrl(targetURL);

			if (SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
				SsoContext ssoCtx = ApplicationContextHolder.getContext().retrieve(SsoContext.class); // null-safe
																										// since
																										// we
																										// just
																										// figured
																										// its
																										// a
																										// SSO
																										// broker
																										// request
				Set<Attribute> ssoAttrs = ssoCtx.getOutboundRelayedSsoAttributes();
				if (CollectionUtils.isNotEmpty(ssoAttrs)) {
					LOGGER.debug("Setting Attributes for SSO to: {}, attributes size: {}",
							new Object[] { partnerID, ssoAttrs.size() });
					ssoRequest.getUser().setAttributes(ssoAttrs);
				}
			}

			LOGGER.debug("Redirecting to relying party with partner id={} and url {} " + "for user = {}",
					new String[] { partnerID, targetURL, userVO.getUserName() });

			this.providerDelegatingSsoService.doSso(partnerID, ssoRequest);
		} catch (Exception e) {
			ErrorMessage msg = addErrorDetailsToSession(TrustBrokerConstants.OPT_00E002, e);
			LOGGER.error("Redirection method Exception in alps sdk redirection for user {} - {}",
					new String[] { userVO.getUserName(), msg.getUid() }, e);
			// handle invalid session later
			return false;
		}
		return true;
	}

	/**
	 * Delete the session cookie before redirection to relying parties.
	 */
	private void deleteSessionContextCookie(HttpServletRequest request, HttpServletResponse response) {
       // prevent filter from adding same cookie
       WebApplicationContext ctx = WebApplicationContextHolder.getContext();
       if (ctx != null) {
           ctx.setDirty(false);
       }
		String host = request.getServerName();
		String domain = host.indexOf(".") >= 0 ? host.substring(host.indexOf(".")) : null;
		Cookie stateCookie = new Cookie(WebApplicationContextManagerFilter.OID_COOKIE, "");
		if (domain != null) {
			stateCookie.setDomain(domain);
		}
		stateCookie.setMaxAge(0);
		stateCookie.setPath("/");
      stateCookie.setValue(null);
		response.addCookie(stateCookie);
	}

	/**
	 * Check if primary email confirmation is required based upon user profile
	 * attributes and relying party profile configuration.
	 * 
	 * @param userVO
	 *            current logged in user value object.
	 * @param relyingPartyAppVO
	 *            current relying party context value object.
	 * 
	 * @return return true if email confirmation required based on profile
	 *         attributes and relying party configuration.
	 */
	public boolean checkIfPrimaryEmailConfirmationRequiredForUser(UserVO userVO, RelyingPartyAppVO relyingPartyAppVO) {
		if (StringUtils.isNotBlank(userVO.getEmailAddress()) && !userVO.isIsemailVerified()
				&& (TBUtil.isProdEnv() || !(relyingPartyAppVO != null
						&& EMAIL_CONFM_REQD_NO_IND.equalsIgnoreCase(relyingPartyAppVO.getEmailconfirmreqd())))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check if the step up required for a user based on relying party
	 * configuration and user profile attributes.
	 * 
	 * @param userVO
	 *            current user session value object.
	 * @param relyingPartyAppVO
	 *            relying party application value object.
	 * @return {@link UserStepUpContext} object with step up context details.
	 */
	public StepupContextVO getUserStepUpcontext(UserVO userVO, RelyingPartyAppVO relyingPartyAppVO,
			boolean isCoppaRequired, boolean isUserMigrated) {
		StepupContextVO stepUpContext = new StepupContextVO();

		List<UserChallengeQuestionVO> securityQuesList = userVO.getUserChallengeQuestions();

		if (relyingPartyAppVO != null) {

			String tierId = null;
			QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
			queryRelyingPartyResponse = this.getConfigService().queryRelyingParty(relyingPartyAppVO.getAlias());
			List<AuthenticationType> authenticationTypes = null;
			if (queryRelyingPartyResponse != null && queryRelyingPartyResponse.getRelyingParty() != null) {
				RelyingParty rp = queryRelyingPartyResponse.getRelyingParty();
				if (rp.getTiers() != null && rp.getTiers().size() > 0) {
					TierConfig tierConfig = rp.getTiers().get(0);
					tierId = tierConfig.getTierId();
					authenticationTypes = tierConfig.getAuthenticationTypes();
				}
			}

			if (securityQuesList == null || securityQuesList.isEmpty()) {
				stepUpContext.setUserProfileHasSecQuestions(false);
				if (authenticationTypes != null && !authenticationTypes.isEmpty()) {
					for (Iterator<AuthenticationType> iterator = authenticationTypes.iterator(); iterator.hasNext();) {
						AuthenticationType authenticationType = iterator.next();
						if (TrustBrokerConstants.SECURITY_QUESTIONS.equalsIgnoreCase(authenticationType.value())) {
							stepUpContext.setSecQuestionRequired(true);
							stepUpContext.setShowSecQuestions(true);
							break;
						}
					}
				}

			}

			if (StringUtils.isNotBlank(tierId)) {
				QueryTierResponse queryTierResponse = new QueryTierResponse();
				queryTierResponse = this.getConfigService().queryTier(tierId);
				if (queryTierResponse != null && queryTierResponse.getTierDefinition() != null) {
					List<TierAttribute> tierAttributes = queryTierResponse.getTierDefinition().getTierAttributes();
					for (Iterator<TierAttribute> iterator = tierAttributes.iterator(); iterator.hasNext();) {
						TierAttribute tierAttribute = iterator.next();
						if (TrustBrokerConstants.DATE_OF_BIRTH.equalsIgnoreCase(tierAttribute.getName())
								&& userVO.getDob() == null) {
							if (tierAttribute.isMandatory()) {
								stepUpContext.setDobRequired(true);
								stepUpContext.setCoppaRequired(isCoppaRequired);
								stepUpContext.setShowDob(true);
							}
						} else if (TrustBrokerConstants.EMAIL_ADDRESS.equalsIgnoreCase(tierAttribute.getName())) {
							stepUpContext.setEmailUnique(tierAttribute.isUnique());
							stepUpContext.setEmailMandatory(tierAttribute.isMandatory());
							stepUpContext.setShowEmail(checkIfEmailRequiredOnStepUp(true, tierAttribute.isUnique(),
									tierAttribute.isMandatory(), userVO, isUserMigrated));
						}
					}
				}
			}
		}

		if (securityQuesList != null && !securityQuesList.isEmpty()) {
			// Adding that user already has security questions in the context
			stepUpContext.setUserProfileHasSecQuestions(true);
		} else {
			stepUpContext.setUserProfileHasSecQuestions(false);
		}

		// Blank email is now removed. Empty email profiles must have email now.
		if (StringUtils.isEmpty(userVO.getEmailAddress())) {
			stepUpContext.setShowEmail(true);
			stepUpContext.setEmailMandatory(true);
		}

		// When user doesnt have SQA. Also No Email and No SQA is already shown
		// for stepup.
		if (!stepUpContext.isUserProfileHasSecQuestions() && !stepUpContext.isShowSecQuestions()
				&& !stepUpContext.isShowEmail()) {
			// To check if SQA required due to a shared Email Case or No Account
			// Recovery options are present.
			if (checkIfSQARequiredAccordingToUserProfile(userVO)) {
				stepUpContext.setSecQuestionRequired(true);
				stepUpContext.setShowSecQuestions(true);
			}
		}

		// Check if COPPA required
		if (!TrustBrokerConstants.STATUS_YES.equalsIgnoreCase(userVO.getIsCoppaAccepted()) && userVO.getDob() == null
				&& isCoppaRequired && !stepUpContext.isShowDob()) {
			stepUpContext.setCoppaRequired(isCoppaRequired);
			stepUpContext.setShowYOB(true);
		}
		stepUpContext.setMigratedUser(userVO.isMigratedUser());
		if (userVO.isMigratedUser()) {
			stepUpContext.setShowPassword(userVO.isPasswordChangeRequired());
			stepUpContext.setShowUserName(userVO.isUserNameChangeRequired());
		}
		return stepUpContext;
	}

	/**
	 * Check if recovery option needs to verified by the user based on profile
	 * attributes.
	 * 
	 * @param userVO
	 *            current user value object.
	 *
	 * @return String name of the recovery option that requires verification.
	 */
	public String getRecoveryOptionToVerify(UserVO userVO) {

		LOGGER.debug("inside getRecoveryOptionToVerify");
		String optionToVerify = null;
		List<UserPreference> userPreferences = userService.getPreferences(userVO.getUuId(), null);
		UserPreference mobilePreference = null;
		UserPreference emailPreference = null;
		if (userPreferences != null && !userPreferences.isEmpty()) {
			for (UserPreference preference : userPreferences) {
				if (preference.getPreferenceType().equals(TrustBrokerWebAppConstants.PREFERENCE_MOBILE)) {
					mobilePreference = preference;
				} else {
					emailPreference = preference;
				}
			}
		}

		boolean verifyMobile = false;
		if (StringUtils.isNotBlank(userVO.getPhoneNumber()) && !userVO.getIsPhoneVerified()) {

			LOGGER.debug("mobile number on profile ", userVO.getPhoneNumber());
			if (mobilePreference != null) {
				if (mobilePreference.getCount() >= 5 || compareWithToday(mobilePreference.getExpirationDate())) {
					verifyMobile = true;
				}
			} else {
				verifyMobile = true;
			}
		}

		boolean verifyEmail = false;
		if (!verifyMobile) {
			if (StringUtils.isNotBlank(userVO.getSecEmailAddress()) && !userVO.isSecEmailVerified()) {

				LOGGER.debug("secondary email on profile ", userVO.getSecEmailAddress());
				boolean emailShared = userService.isEmailExistsWithOtherUser(userVO.getSecEmailAddress(),
						userVO.getUserName());
				if (!emailShared) {

					if (emailPreference != null) {
						if (emailPreference.getCount() >= 5 || compareWithToday(emailPreference.getExpirationDate())) {
							verifyEmail = true;
						}
					} else {
						verifyEmail = true;
					}
				}
			}
		}

		if (verifyMobile) {
			optionToVerify = TrustBrokerWebAppConstants.OPTION_MOBILE;
		} else if (verifyEmail) {
			optionToVerify = TrustBrokerWebAppConstants.OPTION_SECONDARY_EMAIL;
		}

		if (optionToVerify != null) {
			LOGGER.debug("recovery option to verify ", optionToVerify);
		}

		return optionToVerify;
	}

	/**
	 * This method checks if email is required during step up process based on
	 * profile attributes and relying party configuration.
	 * 
	 * @param isRpContextAvailable
	 *            parameter to specify if relying party context available.
	 * @param isUniqueEmailRequired
	 *            parameter to specify if unique email required.
	 * @param isEmailMandatory
	 *            parameter to specify if email is mandatory.
	 * @param userVO
	 *            user value object.
	 * @return true if email is required otherwise false.
	 */
	private boolean checkIfEmailRequiredOnStepUp(boolean isRpContextAvailable, boolean isUniqueEmailRequired,
			boolean isEmailMandatory, UserVO userVO, boolean isUserMigrated) {
		boolean status = false;

		if (isRpContextAvailable) {
			if ((userVO.getEmailAddress() == null && isEmailMandatory)
					|| (userVO.getEmailAddress() != null && userVO.isIsemailVerified() && !userVO.isPrimaryEmailUnique()
							&& isUniqueEmailRequired && !isUserMigrated)) {
				status = true;
			} else if (userVO.isMigratedUser() && userVO.getEmailAddress() != null && !userVO.isIsemailVerified()
					&& isUniqueEmailRequired && this.getUserService().isEmailExists(userVO.getEmailAddress())) {
				status = true;
			}else if(userVO.getEmailAddress() != null && !TBUtil.validateEmailId(userVO.getEmailAddress())){
				//The case when email validations got changed and an old user now needs to step up
				status = true;
			}
		}

		return status;
	}

	/**
	 * This method checks if SQAs is required during step up process based on
	 * profile attributes.
	 * 
	 * 
	 * @param userVO
	 *            user value object.
	 * @return true if SQA is required otherwise false.
	 */
	private boolean checkIfSQARequiredAccordingToUserProfile(UserVO userVO) {
		boolean status = false;
		// Email is shared(and verified) and no Security Questions is present on
		// the userprofile
		if (userVO.getEmailAddress() != null && userVO.isIsemailVerified() && !userVO.isPrimaryEmailUnique()) {
			status = true;
		}
		// migrated user has unverified email but it would become shared after
		// migration and doesnt have SQA
		else if (userVO.getEmailAddress() != null && userVO.isMigratedUser()
				&& this.getUserService().isEmailExistsWithOtherUser(userVO.getEmailAddress(), userVO.getUserName())) {
			status = true;
		}

		return status;
	}

	/**
	 * Update user invitation to registered if not updated already.
	 * 
	 * @param userVO
	 *            current user value object.
	 */
	public void updateUserInvitaionIfAvailableWithinContext(UserVO userVO) {
		String invitationToken = WebApplicationContextHolder.getContext()
				.getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE);
		String relyingAppId = WebApplicationContextHolder.getContext()
				.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);

		try {
			if (invitationToken == null || relyingAppId == null) {
				return;
			}

			InvitationServiceResponse invitationServiceResponse = this.getInvitationService()
					.getInvitationByTokenAndRelyingAppId(invitationToken, relyingAppId);
			InvitationVO invitationVO = invitationServiceResponse.getInvitationVO();

			if (invitationVO != null) {
				invitationVO.setInvtnAccptdDttm(DateUtil.getInstance().getCurrentDate());
				invitationVO.setInvtnToUsr(userVO.getUserId());

				StatusVO status = this.getReferenceService()
						.fetchStatusByStatusState(PropertyLoader.getInstance().getPortalConfigValue("REGISTERED"));

				if (status != null) {
					invitationVO.setInvtnStts(status);
				}

				InvitationServiceRequest request = new InvitationServiceRequest();
				request.setInvitationVO(invitationVO);
				getInvitationService().updateInvitation(request);
				associateInvitedTag(invitationVO, userVO);
			}
		} catch (Exception ex) {
			LOGGER.error("updateUserInvitaionIfAvailable() | Error while updating the invitation", ex);
		}
	}

	/**
	 * Associate the invited tag to the user since user is coming through
	 * invitation request only.
	 */
	public boolean associateInvitedTag(InvitationVO invitationVO, UserVO userVO) {
		boolean result = true;
		try {
			if (invitationVO != null) {

				String invTagCode = getConfigProps().getProperty("invited_tag_code");
				TagServiceRequest request = new TagServiceRequest();
				TagVO invitedTagVO = new TagVO();
				invitedTagVO.setTagCode(invTagCode);
				request.setTagVO(invitedTagVO);
				TagServiceResponse response = getTagService().getTagByTagCode(request);

				if (TrustbrokerWebAppUtil.checkResponseStatus(response)) {
					boolean isInvitegUserTagMappingExists = false;
					try {
						String invTagName = response.getTagVO().getName();
						UserTagServiceResponse resp = getUserTagService()
								.querySpecificUserTag(buildUserTagServiceRequest(userVO.getUuId(), invTagName));
						if (TrustbrokerWebAppUtil.checkResponseStatus(response)) {

							if (null != resp.getTagVOList() && resp.getTagVOList().size() > 0) {
								isInvitegUserTagMappingExists = isInvUsrTagExist(resp.getTagVOList(), invTagName,
										invitationVO);
							}

							if (!isInvitegUserTagMappingExists) {

								UserTagServiceRequest userTagServiceRequest = buildInvUserTagRequest(userVO.getUuId(),
										invTagName, invitationVO);
								getUserTagService().addUserTag(userTagServiceRequest, null);
							}
							WebApplicationContextHolder.getContext()
									.removeSessionAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_INVITATION);
						}
					} catch (OperationFailedException ope) {
						LOGGER.error("Associating the invitation failed for user {}", ope);
					}
				}
			}
		} catch (Exception exception) {
			LOGGER.error(
					"HomeBean:onPreinitialize() | Error while associating the user to invitation tag:" + exception);
		}
		return result;
	}

	/**
	 * This method is to check whether the new uer invitation tag to be created
	 * already exists for the user in the given tag list.
	 * 
	 * @param tagVOList
	 *            List&lt;TagVO&gt;
	 * @param invitationTagName
	 *            String
	 * @param invitationVO
	 *            InvitationVO
	 * @return boolean
	 */
	private boolean isInvUsrTagExist(List<TagVO> tagVOList, String invitationTagName, InvitationVO invitationVO) {
		boolean usgTagExists = false;
		if (tagVOList != null && !tagVOList.isEmpty()) {
			TagVO tagVO = null;
			Iterator<TagVO> tagVOItr = tagVOList.iterator();

			Iterator<AttributeVO> tagAttrVOItr = null;
			AttributeVO attrVO = null;
			String attrToRPId = null;
			String attrFromRPId = null;
			String dirInvFlag = null;
			final String toRPIDAttrNm = getConfigProps()
					.getProperty(TrustBrokerWebAppConstants.INV_TAG_TO_APP_ATTR_KEY);
			final String fromRPIDAttrNm = getConfigProps()
					.getProperty(TrustBrokerWebAppConstants.INV_TAG_FRM_APP_ATTR_KEY);
			final String dirInvAttrNm = getConfigProps()
					.getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_KEY);
			final String directInviteYesFlag = getConfigProps()
					.getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_YES_FLG);
			final String directInviteNoFlag = getConfigProps()
					.getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_NO_FLG);
			// Loop through the tag list got from esso for the user
			while (tagVOItr.hasNext()) {
				attrToRPId = null;
				attrFromRPId = null;
				dirInvFlag = null;
				tagVO = tagVOItr.next();
				if (invitationTagName.equalsIgnoreCase(tagVO.getName()) && tagVO.getAttributeVOList() != null) {
					tagAttrVOItr = tagVO.getAttributeVOList().iterator();
					// Loop through tag attributes to get the from app, to app
					// and direct invite flag attributes
					while (tagAttrVOItr.hasNext()) {
						attrVO = tagAttrVOItr.next();
						if (toRPIDAttrNm.equals(attrVO.getName())) {
							attrToRPId = attrVO.getValue();
						} else if (fromRPIDAttrNm.equals(attrVO.getName())) {
							attrFromRPId = attrVO.getValue();
						} else if (dirInvAttrNm.equals(attrVO.getName())) {
							dirInvFlag = attrVO.getValue();
						}
					}
					// If direct invites is Yes, then check if the to app id (RP
					// id) exists
					if (directInviteYesFlag.equalsIgnoreCase(dirInvFlag) && attrToRPId != null
							&& attrToRPId.equals(invitationVO.getRpAppId())
							&& StringUtils.isBlank(invitationVO.getCreatedByRPAppId())) {
						usgTagExists = true;
						break;
						//// If direct invites is No, then check if the to app
						//// id (RP id) and from app id (created by app id)
						//// exists
					} else if (directInviteNoFlag.equalsIgnoreCase(dirInvFlag) && attrToRPId != null
							&& attrToRPId.equals(invitationVO.getRpAppId()) && attrFromRPId != null
							&& attrFromRPId.equals(invitationVO.getCreatedByRPAppId())) {
						usgTagExists = true;
						break;
					}
				}
			}
		}

		return usgTagExists;
	}

	/**
	 * Build the user tag service request object.
	 * 
	 * @param uuid
	 *            - User UUID.
	 * @param tagName
	 *            - Tag name.
	 * 
	 * @return User tag service request object.
	 */
	public UserTagServiceRequest buildUserTagServiceRequest(String uuid, String tagName) {
		UserTagServiceRequest userTagServiceRequest = new UserTagServiceRequest();
		if (null != tagName) {
			userTagServiceRequest.setTagName(tagName);
		}
		UserVO userVO = new UserVO();
		userVO.setUuId(uuid);
		userTagServiceRequest.setUser(userVO);
		return userTagServiceRequest;
	}

	/**
	 * This method is to build the user tag service request object from the
	 * given parameters. The tag attributes are built from the invitation object
	 * 
	 * @param uuid
	 *            String
	 * @param tagName
	 *            String
	 * @param invitationVO
	 *            InvitationVO
	 * @return UserTagServiceRequest
	 */
	private UserTagServiceRequest buildInvUserTagRequest(String uuid, String tagName, InvitationVO invitationVO) {
		UserTagServiceRequest userTagServiceRequest = buildUserTagServiceRequest(uuid, tagName);

		if (invitationVO != null) {
			TagVO tagVO = new TagVO();
			tagVO.setTagCode(tagName);

			List<AttributeVO> attrVOList = new ArrayList<AttributeVO>();
			AttributeVO attrVO = new AttributeVO();
			attrVO.setName(getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_TO_APP_ATTR_KEY));
			attrVO.setValue(invitationVO.getRpAppId());
			attrVOList.add(attrVO);

			attrVO = new AttributeVO();
			String directInviteFlag = null;
			if (StringUtils.isBlank(invitationVO.getCreatedByRPAppId())) {
				directInviteFlag = getConfigProps()
						.getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_YES_FLG);
				attrVO.setName(getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_FRM_APP_ATTR_KEY));
				attrVO.setValue(invitationVO.getRpAppId());
			} else {
				directInviteFlag = getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_NO_FLG);
				attrVO.setName(getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_FRM_APP_ATTR_KEY));
				attrVO.setValue(invitationVO.getCreatedByRPAppId());
			}
			attrVOList.add(attrVO);

			attrVO = new AttributeVO();
			attrVO.setName(getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_KEY));
			attrVO.setValue(directInviteFlag);
			attrVOList.add(attrVO);

			tagVO.setAttributeVOList(attrVOList);
			List<TagVO> tagVOList = new ArrayList<TagVO>();
			tagVOList.add(tagVO);
			userTagServiceRequest.setTagVOList(tagVOList);
		}
		return userTagServiceRequest;
	}

	/**
	 * Check if relying party context is available.
	 * 
	 * @return true if relying party context is available otherwise false.
	 */
	public boolean checkRelyingPartyContext() {

		WebApplicationContext ctx = WebApplicationContextHolder.getContext();

		if (ctx != null
				&& StringUtils.isNotBlank(ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM))) {
			return true;
		}

		return false;
	}

	/**
	 * Redirect to another view.
	 * 
	 * @param response
	 *            HTTP response object.
	 * 
	 * @return
	 */
	public boolean redirectToErrorPage(HttpServletResponse response, String viewUrl) {
		try {
			WebApplicationContext ctx = WebApplicationContextHolder.getContext();
			viewUrl = HttpUtils.addParameterToURL(viewUrl, TrustBrokerWebAppConstants.ERROR_CD,
					ctx.getRequestAttribute(TrustBrokerWebAppConstants.ERROR_CD));
			viewUrl = HttpUtils.addParameterToURL(viewUrl, TrustBrokerWebAppConstants.ERROR_UID,
					ctx.getRequestAttribute(TrustBrokerWebAppConstants.ERROR_UID));
			response.sendRedirect(viewUrl);
			return true;
		} catch (IOException ioEx) {
			LOGGER.error("Error while redirectingt internally", ioEx);
		}
		return false;
	}

	public boolean redirectToCoppaErrorPage(HttpServletResponse response, String viewUrl) {
		addErrorDetailsToSession(TrustBrokerConstants.OPT_00K000, null);
		return redirectToErrorPage(response, viewUrl);
	}

	private boolean compareWithToday(Date date2) {

		if (date2 == null) {
			return false;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime().after(date2);
	}

	public RelyingPartyAppService getRelyingPartyAppService() {
		return relyingPartyAppService;
	}

	public void setRelyingPartyAppService(RelyingPartyAppService relyingPartyAppService) {
		this.relyingPartyAppService = relyingPartyAppService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public ConfigurationService getConfigService() {
		return configService;
	}

	public void setConfigService(ConfigurationService configService) {
		this.configService = configService;
	}

	public SsoService getProviderDelegatingSsoService() {
		return providerDelegatingSsoService;
	}

	public void setProviderDelegatingSsoService(SsoService providerDelegatingSsoService) {
		this.providerDelegatingSsoService = providerDelegatingSsoService;
	}

	public InvitationService getInvitationService() {
		return invitationService;
	}

	public void setInvitationService(InvitationService invitationService) {
		this.invitationService = invitationService;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}

	public ResourceBundleMessageSource getTb_service_errorMessageResource() {
		return tb_service_errorMessageResource;
	}

	public void setTb_service_errorMessageResource(ResourceBundleMessageSource tb_service_errorMessageResource) {
		this.tb_service_errorMessageResource = tb_service_errorMessageResource;
	}

	public TagService getTagService() {
		return tagService;
	}

	public void setTagService(TagService tagService) {
		this.tagService = tagService;
	}

	public Properties getConfigProps() {
		return configProps;
	}

	public void setConfigProps(Properties configProps) {
		this.configProps = configProps;
	}

	public UserTagService getUserTagService() {
		return userTagService;
	}

	public void setUserTagService(UserTagService userTagService) {
		this.userTagService = userTagService;
	}
}
