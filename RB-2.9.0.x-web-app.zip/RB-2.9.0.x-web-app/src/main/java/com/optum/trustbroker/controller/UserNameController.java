package com.optum.trustbroker.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.WebApplicationCommonUtilities;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@Path(TBConstants.USERNAME_CONTROLLER_PATH)
public class UserNameController extends BaseController {

    private static final Logger LOG = Logger.getLogger(UserNameController.class);

    @Autowired
    private UserService userService = null;

    @Autowired
    private WebApplicationCommonUtilities webApplicationCommonUtilities;

    @GET
    @Path(value = "/signoutuser")
    @Produces(MediaType.APPLICATION_JSON)
    public Response signOutUser(@Context HttpServletRequest request) {

        LOG.debug("signing out user.");
        HttpSession session = request.getSession(false);

        session.invalidate();

        WebApplicationContextHolder.getContext().removeTempSessionAttributes();

        String status = HttpStatus.OK.toString();
        Response response = Response.status(201).entity(status).build();
        
        //relying party and user info for audit logging
        String rpAppId=null;
        RelyingPartyAppVO rpVO =getRPAppInfo();
        if(rpVO != null)
        	rpAppId = rpVO.getApplicationId();
        String actorId="";
        UserVO  userVO= webApplicationCommonUtilities.getCurrentUserDetailsFromWebApplicationContext();
        if (userVO != null)
        	actorId = userVO.getUserName();
        //SecurityLoggingUtil.info("User Login", SecurityEventType.E1_TERMINATE, request, actorId,
        //        "Security Audit Event|TerminateUserSession:SUCCESS | User session TERMINATED, LoginBean:signOut()",
        //        SecurityEventResult.SUCCESS, rpAppId, null);
       
        SecurityLoggingUtil.info(SecurityLoggingUtil.buildAuditLogRequestVO("User Login",SecurityEventType.E1_TERMINATE,
       			request, actorId, "Security Audit Event|TerminateUserSession:SUCCESS | User session TERMINATED, LoginBean:signOut()", 
       			SecurityEventResult.SUCCESS, 
       			rpAppId, null));
       
        
        return response;

    }

    @GET
    @Path(value = "/getRPInfo")
    @Produces(MediaType.APPLICATION_JSON)
    public RelyingPartyAppVO getRPAppInfo() {
        RelyingPartyAppVO rpVO = new RelyingPartyAppVO();
        rpVO.setApplicationId(StringUtils.EMPTY);

        RelyingPartyAppVO relyingPartyVO = webApplicationCommonUtilities.getRelyingPartyApplicationDetailsFromContext();
        if (relyingPartyVO != null) {
            rpVO.setApplicationId(relyingPartyVO.getApplicationId());
        }
        LOG.debug(" relyingPartyVO: " + relyingPartyVO + "rpVO appid " + rpVO.getApplicationId());

        return rpVO;
    }

    /**
     * This method returns the UserService
     * 
     * @return the userService
     */
    @Override
    public UserService getUserService() {
        return userService;
    }

    /**
     * This method sets the given userService value to
     * userService
     * 
     * @param userService
     *            the userService to set
     */
    @Override
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @Override
    public WebApplicationCommonUtilities getWebApplicationCommonUtilities() {
        return webApplicationCommonUtilities;
    }

    @Override
    public void setWebApplicationCommonUtilities(WebApplicationCommonUtilities webApplicationCommonUtilities) {
        this.webApplicationCommonUtilities = webApplicationCommonUtilities;
    }

}