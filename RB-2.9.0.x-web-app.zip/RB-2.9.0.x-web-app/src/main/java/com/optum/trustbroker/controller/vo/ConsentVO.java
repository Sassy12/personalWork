package com.optum.trustbroker.controller.vo;

public class ConsentVO {
	private String rpAppName;
	private boolean showDob;
	
	public String getRpAppName() {
		return rpAppName;
	}
	public void setRpAppName(String rpAppName) {
		this.rpAppName = rpAppName;
	}
	public boolean isShowDob() {
		return showDob;
	}
	public void setShowDob(boolean showDob) {
		this.showDob = showDob;
	}
	
	
}
