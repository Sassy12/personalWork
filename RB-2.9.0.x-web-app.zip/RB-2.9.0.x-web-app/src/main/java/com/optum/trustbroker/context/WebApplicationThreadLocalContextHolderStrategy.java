/*
 * Copyright (C) 2016 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.context;

/**
 * Represents a ThreadLocal based ContextHolderStrategy.
 * This implementation supports both standard ThreadLocal and
 * InheritableThreadLocal usage.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
class WebApplicationThreadLocalContextHolderStrategy implements WebApplicationContextHolderStrategy {
    // would normally be static, but to simplify implementation and to allow
    // for a single implementation class I made it an instance variable
    private ThreadLocal<WebApplicationContext> contextHolder;

    WebApplicationThreadLocalContextHolderStrategy() {
        this(false);
    }
    WebApplicationThreadLocalContextHolderStrategy(boolean useInheritable) {
        contextHolder
            = useInheritable ? new InheritableThreadLocal<WebApplicationContext>()
                             : new ThreadLocal<WebApplicationContext>();
    }


    /**
     * Returns the current context.
     *
     * @return The current context.
     */
    @Override
    public WebApplicationContext getContext() {
        return contextHolder.get();
    }

    /**
     * Clears the current context.
     */
    @Override
    public void clearContext() {
        contextHolder.remove();
    }

    /**
     * Stores the specified context using the
     * strategy represented by this instance.
     *
     * @param context The context being stored.
     */
    @Override
    public void setContext(WebApplicationContext context) {
        contextHolder.set(context);
    }
}
