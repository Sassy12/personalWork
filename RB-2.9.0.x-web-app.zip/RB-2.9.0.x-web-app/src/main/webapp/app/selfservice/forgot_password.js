/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 *
 ***********************************************
 * Modification History
 * When          Who         Why
 * Feb 02, 2016  bmanna3	Initial version
 ****************************************************************/

(function () {

	'use strict';

	var module = angular.module('indexApp');

	module.controller('forgotPwdController', ['$scope', '$state', '$timeout' , 'trustbrokerAriaService', 'LanguageService', 'forgotAccessService', 'AnalyticsService', '$rootScope', 'HelpObj',
		function($scope , $state, $timeout, trustbrokerAriaService, LanguageService, forgotAccessService, AnalyticsService, $rootScope, HelpObj){

			HelpObj.setHelpObj({url:'../webHelp/Default_CSH.htm#Optum ID CSH/entry_1021_Forgot_Optum_ID_or_Password.htm'});
			$scope.hideInput = true;
			$scope.hideEmailText = true;
			$scope.hideUserNameText = true;
			$scope.selectionChangedToRadio1 = false;
			$scope.selectionChangedToRadio2 = true;
			$scope.emailErrorMsg = '';
			$scope.usernameErrorMsg = '';
			$scope.userNameError = false;
			$scope.userEmailError = false;
			LanguageService.doTranslate("selfservice");
			$scope.accountSearchCount=0;
			$scope.disableNext=false;
			$scope.forgotUsernameInital = true;
			$scope.errorMessageModel = {
				id : 'errorMessage',
				messageType : 'error',
				messageRole : 'alert',
				content : '',
				visible : false,
				position: 'inline',
				headingLevel : '2',
				animationTime: 1
			};
		
			
			
			$scope.forgotPassword = function() {
				//angular.element('#userNameText_input').focus();
				
				//$scope.errorMessageModel.visible = false;
				//$scope.setFieldDefaults();
				$scope.hideEmailText = true;
				$scope.hideUserNameText = false;
				$scope.selectionChangedToRadio1 = false;
				$scope.selectionChangedToRadio2 = true;
				$scope.email = '';
				$scope.emailErrorMsg = '';
				$scope.userNameError = false;
				$scope.userEmailError = false;
			};

			$scope.disableContents = function() {
				$scope.forgotUsernameInital = true;
				document.getElementById("forgotPasswordLabelSpan").style.color = "#333";
				//document.getElementById("emailLabelSpan").style.color = "grey";
				//document.getElementById('findUsrwMoreInfoLink').style.color="grey";
				//document.getElementById('findUsrwMoreInfoLink').style.cursor="default";
			//	document.getElementById('findUsrwMoreInfoLink').style.pointerEvents= "none";
			//	document.getElementById('findUsrwMoreInfoLink').style.textDecoration= "none";
			//	document.getElementById("findUsrwMoreInfoLink").tabIndex = "-1";


			};


			
			$scope.setFieldDefaults = function() {
				//$scope.errorMessageModel.visible = false;
				$scope.userNameError = false;
				$scope.userEmailError = false;
				// $scope.errorMessageModel.content = '';
			};
			
			$scope.onUserNameKeyup = function() {
				if ($scope.forgotPwdForm.userName) {
					if(!$scope.userNameError) {
						$scope.userNameError = false;
						$scope.userEmailError = false;
					}
				}
			};
			$scope.setFieldValidity = function(inputid, spanid){
				trustbrokerAriaService.setFieldValidity(inputid, spanid);
			};
			$scope.disableNextButton = function(){
				$scope.errorMessageModel.content = '<span translate="disablePageFogPwdMsg"></span>';
				$scope.errorMessageModel.visible = true;
				$scope.disableNext=true;
				//For WCAG
				$timeout(function() {
					angular.element('#errorMessage').focus();

				}, 300);
				//To enable the field after 2 mins
				$timeout(function() {
					$state.reload();
				}, 120000);
			};
			$scope.disableNextButtonWarning = function(){
				$scope.errorMessageModel.content = '<span translate="disablePageWarningMsg"></span>';
				$scope.errorMessageModel.visible = true;
				//For WCAG
				$timeout(function() {
					angular.element('#errorMessage').focus();
				}, 300);
			};
			$scope.setAriaInvalid = function(){
				
				trustbrokerAriaService.setAriaInvalid('userNameText_input',null);
			};
			$scope.nextScreen = function() {
				$scope.emailErrorMsg = '';
				$scope.usernameErrorMsg = '';
				$scope.validateProcess();
			};
			$scope.validateProcess = function() {
				
			   if ($scope.selectionChangedToRadio2 && ($scope.userName === '' || $scope.userName === undefined)) {
					$scope.usernameNotEntered();
					$scope.ariaUpdate();
					$rootScope.fireErrorTracker = true;
				}else{
					$scope.findUser();
				}
			};
			$scope.findUser = function() {
				var recoveryType = $scope.getRecoveryType();
				var postData = { 'recoveryType': recoveryType, 'email' : $scope.email, 'userName' :  $scope.userName };
				forgotAccessService.getUserEmailType(postData).then(function(response){
					var responseVO =  response.data;
					var status = responseVO.status;
					if(status) {
						if(responseVO.uniqueEmail) {
							$state.go('forgotCredByIdentity',{userinfo: {'userName': responseVO.userName}});
						} else {
								$state.go("findpwdwmoreinfo");
						}
					}  else if(!status){
						if(responseVO.invalidRecoveryOptns) {
							$state.go("norecoveryoption");
						} else {
							$scope.processErrMsgs(responseVO);
							$rootScope.fireErrorTracker = true;
						}
					}
				});
			};
			$scope.processErrMsgs = function(responseVO) {

				var messages = responseVO.messages;
				
				$scope.errorMessageModel.content = '<span>'+messages.formerr+'</span>';
				$scope.errorMessageModel.visible = true;
				var emailErr = messages.emailerr;
				var usernameErr =  messages.usernameerr;
				$scope.userEmailError = false;
				$scope.userNameError = false;
				
				if(usernameErr !== '' && usernameErr !== undefined) {
					$scope.usernameErrorMsg = usernameErr;
					$scope.userNameError = true;
				}
				else {
					//NEED TO VERIFY THIS WITH NEW DESIGN AND MAX CHARACTER LENGTH ERROR (FOR NOW WORKING FINE)
					$('#userNameText_input').removeAttr('aria-describedby');
				}
				if(!emailErr && !usernameErr){
					$scope.accountSearchCount++;
					//pageDataLayer.content.siteErrorFields = "";
					//pageDataLayer.content.siteErrorType = "wrong credentials entered";
					AnalyticsService.postErrorTrackInfo("wrong credentials entered", "");
				}
				$scope.ariaUpdate();
				if($scope.accountSearchCount===4){
					$scope.disableNextButtonWarning();
				}
				if($scope.accountSearchCount>=5){
					$scope.disableNextButton();
				}
			};
			$scope.ariaUpdate = function() {
				var FIELDS =[];
				if($scope.userNameError) {
					FIELDS=[{fld:"userNameText_input",msg:"userNameId_err"}];
				}else{
					$timeout(function() {
						angular.element('#errorMessage').focus();
					}, 300);
				}
				if(FIELDS.length > 0) {
					$timeout(function() {
						trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
						$scope.formErrorIsHidden = false;  }, 300);
				}
				return;
			};
			
			$scope.usernameNotEntered = function() {
				$scope.usernameErrorMsg = 'FgtUsrPwdCreUnmRqdMsg';
				$scope.errorMessageModel.content = '<span translate="FgtUsrPwdCrePwdErrMsg"></span>';
				$scope.errorMessageModel.visible = true;
				$scope.userNameError = true;
			};
			$scope.getRecoveryType = function() {
				var recoveryType = '';
				if($scope.selectionChangedToRadio2) {
					recoveryType = "ForgotPwd";
				}
				return recoveryType;
			};
			$scope.navFindUsrwMoreInfo = function() {
				if(!$scope.selectionChangedToRadio2){
					$state.go("findusrwmoreinfo");
				}
			};
			$scope.cancelNav = function() {
				$state.go("login");
			};
		}]);

})();