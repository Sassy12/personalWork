'use strict';

angular.module('tbApp').controller('StepupCtrl', ['$scope', '$rootScope', '$timeout', '$state', 'trustbrokerAriaService', 'LanguageService', '$translate', 'StepupService', 'stepupVO', '$window', 'uitkLiveRegionService', 'HelpObj', StepupCtrl]);

function StepupCtrl($scope, $rootScope, $timeout, $state, trustbrokerAriaService, LanguageService, $translate, StepupService, stepupVO, $window, uitkLiveRegionService, HelpObj) {
    LanguageService.doTranslate('stepup');

    var initData = stepupVO.data;

    $scope.isMigration = undefined !== initData.stepupContext.migratedUser ? initData.stepupContext.migratedUser : false;
    $scope.showEmail = undefined !== initData.stepupContext.showEmail ? initData.stepupContext.showEmail : false;
    $scope.showUsername = undefined !== initData.stepupContext.showUserName ? initData.stepupContext.showUserName : false;
    $scope.showPassword = undefined !== initData.stepupContext.showPassword ? initData.stepupContext.showPassword : false;
    $scope.oldUsername = undefined !== initData.userInfoVO.userName ? initData.userInfoVO.userName : '';
    $scope.showDOB = undefined !== initData.stepupContext.showDob ? initData.stepupContext.showDob : false;
    $scope.showYOB = undefined !== initData.stepupContext.showYOB ? initData.stepupContext.showYOB : false;
    $scope.showSQA = undefined !== initData.stepupContext.showSecQuestions ? initData.stepupContext.showSecQuestions : false;
    $scope.firstName = undefined !== initData.userInfoVO.firstName ? initData.userInfoVO.firstName : '';
    $scope.lastName = undefined !== initData.userInfoVO.lastName ? initData.userInfoVO.lastName : '';
    $scope.alreadyHasSecQuestions = initData.stepupContext.userProfileHasSecQuestions ? initData.stepupContext.userProfileHasSecQuestions : false;

    // For analytics
    if ($scope.isMigration && $state.current.name === "stepup") {
        pageDataLayer.content.pageName = "additionalinformation";
        pageDataLayer.content.siteSectionL1 = "youroptumID";
        HelpObj.setHelpObj({ url: '../../webHelp/Default_CSH.htm#Optum ID CSH/entry_1012_Update_Your_Account_for_Optum_ID_Migration.htm' });
    } else if ($state.current.name === "stepup") {
        pageDataLayer.content.pageName = "additionalinformation";
        pageDataLayer.content.siteSectionL1 = "signin";
        HelpObj.setHelpObj({ url: '../../webHelp/Default_CSH.htm#Optum ID CSH/entry_1011_Sign_In_Additional_Information_Step_up.htm' });
    }

    if (typeof _satellite !== "undefined") {
        _satellite.track('trackPageView');
    }
    
    if(window.screen.width <= 420) {
    	$scope.tooltipvalue = "tooltip-placement=left";
    } else {
    	$scope.tooltipvalue = "";
    }

    $scope.coppaCount = 0;

    $scope.showSecQuestionBasedonSharedEmail = false;

    
    $scope.unameRulesMet = 0;
    $scope.showPwdErr = false;
    $scope.userSuggestionsArray = [];
    $scope.showUserNameSuggestions = false;

    $scope.status = {
        'secQues1Valid': false,
        'secQues2Valid': false,
        'secQues3Valid': false
    };
    //date of birth configurations
    $scope.dobViewModel = {
        	required:true,
        	invalid: false,
        	labelledBy: 'dateOfBirthLabelId',
        	displayAgeInformation:false,
        	textFieldClassName: 'tk-height-2t',
        	enableValidation: false,
        	requiredMessage: 'dateOfBirthReq',
            invalidFormatMessage: 'invalidDateFormat',
            invalidDateMessage: 'invalidDate',
            dobInvalidFutureMessage: 'futureDate',
            invalidYearMessage: 'invalidYear',
            maxYear: new Date().getFullYear()
    };

    // For WCAG: Adding tooltip describedBy in our new username component
    $timeout(function() {
        angular.element(document.getElementById('userNameId_input')).attr("aria-describedby", "userNameTipId");
    }, 300);

    var select = {
        label: $translate.instant('select'),
        value: ''
    };

    /* UITK 3.7 update */
    var allQuestions = [];

    if (undefined !== initData.userInfoVO.securityQuestionVO) {
        angular.forEach(initData.userInfoVO.securityQuestionVO.questions, function(securityQues) {
            this.push({
                label: securityQues.label,
                value: securityQues.value
            });
        }, allQuestions);
    }
    allQuestions.unshift(select);

    $scope.secList1 = $scope.secList2 = $scope.secList3 = allQuestions;
    $scope.secQues1 = $scope.secQues2 = $scope.secQues3 = allQuestions[0];

    $scope.questionSelected = function(index) {
        $timeout(function() {
            var i = 0;
            var questionsLen = allQuestions.length;

            // Filter Question one when question 2 or 3 are changed
            if (index !== '1') {
                i = 0;
                $scope.secList1 = [];

                for (var key1index = 0; key1index < questionsLen; key1index++) {
                    if (allQuestions[key1index] === allQuestions[0]) {
                        $scope.secList1[i] = allQuestions[key1index];
                        i++;
                    } else if (!(allQuestions[key1index].label === $scope.secQues2.label || allQuestions[key1index].label === $scope.secQues3.label)) {
                        $scope.secList1[i] = allQuestions[key1index];
                        i++;
                    }
                }
            }

            // Filter Question two when question 1 or 3 are changed
            if (index !== '2') {
                i = 0;
                $scope.secList2 = [];

                for (var key2index = 0; key2index < questionsLen; key2index++) {
                    if (allQuestions[key2index] === allQuestions[0]) {
                        $scope.secList2[i] = allQuestions[key2index];
                        i++;
                    } else if (!(allQuestions[key2index].label === $scope.secQues1.label || allQuestions[key2index].label === $scope.secQues3.label)) {
                        $scope.secList2[i] = allQuestions[key2index];
                        i++;
                    }
                }
            }

            // Filter Question three when question 1 or 2 are changed
            if (index !== '3') {
                i = 0;
                $scope.secList3 = [];

                for (var key3index = 0; key3index < questionsLen; key3index++) {
                    if (allQuestions[key3index] === allQuestions[0]) {
                        $scope.secList3[i] = allQuestions[key3index];
                        i++;
                    } else if (!(allQuestions[key3index].label === $scope.secQues1.label || allQuestions[key3index].label === $scope.secQues2.label)) {
                        $scope.secList3[i] = allQuestions[key3index];
                        i++;
                    }
                }
            }
        }, 300);
    };
    /* END: UITK 3.7 update */

    $scope.validateSecAnsText = function(event) {
        return validators.validateSecAns(event);
    };

    //function for setting field validity (WCAG)
    $scope.setFieldValidity = function(inputid, spanid) {
        $scope.showPwdErr = true;
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        }, 300);
    };
    //model configurations for error messages 
    $scope.errorMessageModel = {
        animationTime: 1,
        ariaAttributes: true,
        content: '<span translate="genericFormError"></span>',
        headingLevel: '2',
        id: 'errorMessage',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };
    //model configurations for success messages 
    $scope.successMessageModel = {
        animationTime: 1,
        ariaAttributes: true,
        autoFadeOut: false,
        content: '<span translate="migrationSuccessMessage"></span>',
        headingLevel: '2',
        id: 'Success',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: true
    };
    //user name(optum id) validations
    $scope.userNameRulesValidation = function() {
        var validationRules = validators.userNameValidation($scope.userName);
        var previousRulesMet = $scope.unameRulesMet;
        $scope.unameLengthValidation = validationRules.unameLengthValidation;
        $scope.unameLetterValidation = validationRules.unameLetterValidation;
        $scope.unamespCharacterValidation = validationRules.unamespCharacterValidation;
        $scope.unameSpaceValidation = validationRules.unameSpaceValidation;
        $scope.unameRulesMet = validationRules.unameRulesMet;

        // For WCAG
        if (previousRulesMet !== $scope.unameRulesMet) {
            if ($scope.unameRulesMet === 4) {
                uitkLiveRegionService.alertMessage($translate.instant('UsernameValidAlert'));
            } else {
                uitkLiveRegionService.alertMessage($translate.instant('UsernameNotValidAlert') + $scope.unameRulesMet + $translate.instant('UsernameNumberMetAlert'));
            }
        }
    };
    //password field and confirm password field match validations
    $scope.pwdMatchValidation = function() {
        if ($scope.newPassword === undefined || $scope.newPassword === "") {
            return true;
        }

        if ($scope.confirmPassword === undefined || $scope.confirmPassword === "") {
            return true;
        }

        if ($scope.newPassword !== $scope.confirmPassword) {
            return false;
        } else {
            return true;
        }
    };

    //email validaitons
    $scope.validateEmail = function() {
        if ($scope.stepupForm.emailAddress !== "") {
            var postData = {
                emailAddress: $scope.emailAddress,
                rpAppVO: initData.userInfoVO.rpAppVO
            };

            StepupService.validateEmail(postData).then(function(response) {
                $scope.showSecQuestionBasedonSharedEmail = false;
                $scope.sharedEmailNotificationMsg = "";

                if (undefined !== response.data.errorMap && Object.keys(response.data.errorMap).length > 0) {
                    $scope.emailAddressErrorMsg = response.data.errorMap.email;
                    $scope.showSecQuestionBasedonSharedEmail = response.data.showSecQuestionBasedonSharedEmail;
                    $scope.sharedEmailNotificationMsg = "";
                } else {
                    $scope.emailAddressErrorMsg = "";
                }

                if (undefined !== response.data.notificationMap && Object.keys(response.data.notificationMap).length > 0) {
                    $scope.sharedEmailNotificationMsg = response.data.notificationMap.sharedEmail;
                    $scope.showSecQuestionBasedonSharedEmail = response.data.showSecQuestionBasedonSharedEmail;

                    // This is added to fix uitk bug where default label is getting removed on hide and show
                    // if($scope.secList1.length!==allQuestions.length){
                    //     $scope.secList1.unshift(select);
                    // }

                    // if($scope.secList2.length!==allQuestions.length){
                    //     $scope.secList2.unshift(select);
                    // }

                    // if($scope.secList3.length!==allQuestions.length){
                    //     $scope.secList3.unshift(select);
                    // }

                    $scope.emailAddressErrorMsg = "";
                }
            });
        }
    };

    $scope.userNameChanged = function() {
        $scope.showUserNameSuggestions = false;

        if (undefined === $scope.userName) {
            $scope.userNameErrorMsg = '';
        }
    };

    $scope.validateUserName = function() {
        $scope.setFieldValidity("userNameId_input", "userNameId_err");
        $scope.setFieldValidity("userNameId_input", "userNameId_info");

        $scope.userNameErrorMsg = '';

        if (undefined !== $scope.userName && $scope.userName !== "") {

            if ($scope.unameRulesMet !== 4 && $scope.unameRulesMet !== 0) {
                $scope.userNameErrorMsg = $translate.instant('usernameMustMeetRequirement');
                $scope.showUserNameSuggestions = false;
                return;
            } else {
                $scope.userNameErrorMsg = '';
            }

            var postData = {
                userName: $scope.userName,
                firstName: $scope.firstName,
                lastName: $scope.lastName
            };

            StepupService.validateUserName(postData).then(function(response) {
                if (undefined === response.data.userNameSuggestionsList && Object.keys(response.data.errorMap).length === 0) {
                    $scope.showUserNameSuggestions = false;
                } else if (undefined !== response.data.errorMap && undefined !== response.data.errorMap.userName) {
                    $scope.userNameErrorMsg = response.data.errorMap.userName;
                    $scope.showUserNameSuggestions = false;
                } else if (undefined !== response.data.userNameSuggestionsList && response.data.userNameSuggestionsList.length > 0 && !$scope.showUserNameSuggestions) {
                    $scope.userSuggestionsInfoMsg = $translate.instant('userNameSuggMsg');
                    $scope.selectOptumIdMsg = $translate.instant('selectOptumIdMsg');
                    var suggestions = [];

                    angular.forEach(response.data.userNameSuggestionsList, function(uNameSuggestion) {
                        this.push({
                            label: uNameSuggestion + " ",
                            value: uNameSuggestion
                        });
                    }, suggestions);

                    $scope.userSuggestionsArray = suggestions;
                    $scope.showUserNameSuggestions = true;
                    $scope.userNameErrorMsg = "";

                    $timeout(function() {
                        angular.element(document.getElementById('userNameId_input')).attr("aria-describedby", "userNameId_info userNameId_suggestions");
                    }, 300);
                }
            });
        } else {
            $scope.showUserNameSuggestions = false;
        }
    };

    $scope.validateYOBFormat = function() {
        var yobValue = $scope.yob;
        $scope.yobErrorMsg = "";

        if (yobValue !== "") {
            if (!validators.checkIfEmpty(yobValue) && (isNaN(yobValue) || yobValue.length !== 4)) {
                $scope.yobErrorMsg = $translate.instant('yobFormatErrorMsg');
            } else if (!validators.isValidYOB($scope.yob)) {
                $scope.yobErrorMsg = $translate.instant('invalidYear');
            }
        }
    };

    $scope.validateDateField = function() {
        if ($scope.showDOB === true) {
        	var dateErrorMsg = validators.isValidDate($scope.dobViewModel);
        	if(!validators.checkIfEmpty(dateErrorMsg)) {
        		$scope.dobError = $translate.instant(dateErrorMsg);
        		return;
        	}
        }
        $scope.dobError = '';
        return;
    };
    
    // Remove errors which came from server on key press
    $scope.removeServerError = function(field) {
        if (field === 'email' && $scope.emailAddressErrorMsg) {
            $scope.emailAddressErrorMsg = '';
        }

        if (field === 'username' && $scope.userNameErrorMsg && $scope.unameRulesMet === 4) {
            $scope.userNameErrorMsg = '';
        }

        if (field === 'password' && $scope.serverPassError) {
            $scope.serverPassError = '';
        }

        if (field === 'yob' && $scope.yobErrorMsg) {
            $scope.yobErrorMsg = '';
        }

        if (field === 'secAns1' && $scope.secAns1ErrorMsg) {
            $scope.secAns1ErrorMsg = '';
        }

        if (field === 'secAns2' && $scope.secAns2ErrorMsg) {
            $scope.secAns2ErrorMsg = '';
        }

        if (field === 'secAns3' && $scope.secAns3ErrorMsg) {
            $scope.secAns3ErrorMsg = '';
        }
    };

    $scope.onCancel = function() {
        $window.location = '/tb/app/index.html';
    };

    // function for navigating to next screen
    $scope.goToRpHomePage = function() {
        $window.location = '/tb/app/secure/home.do';
    };
    //invoking function on submit
    $scope.next = function() {
        // For putting focus and setting WCAG properties
        var FIELDS = [
            { fld: "emailAddressId_input",      msg: "emailAddressId_err" },
            { fld: "userNameId_input",          msg: "userNameId_err" },
            { fld: "userNameId_input",          msg: "userNameId_info" },
            { fld: "newPasswordId_input",         msg: "newPasswordId_err" },
            { fld: "confirmPasswdId_input",     msg: "confirmPasswdId_err" },
            { fld: "dob_id_dob",                msg: "dobId_err" },
            { fld: "yobId_input",               msg: "yobId_errMsg" },
            { fld: "secQues1Id",                msg: "secQuestionOneId_err" },
            { fld: "secAnswerOneId_input",      msg: "secAnswerOneId_err" },
            { fld: "secAnswerOneId_input",      msg: "secAnswer1ValidationError" },
            { fld: "secQues2Id",                msg: "secQuestionTwoId_err" },
            { fld: "secAnswerTwoId_input",      msg: "secAnswerTwoId_err" },
            { fld: "secAnswerTwoId_input",      msg: "secAnswer2ValidationError" },
            { fld: "secQues3Id",                msg: "secQuestionThreeId_err" },
            { fld: "secAnswerThreeId_input",    msg: "secAnswerThreeId_err" },
            { fld: "secAnswerThreeId_input",    msg: "secAnswer3ValidationError" }
        ];

        $scope.validateDateField();

        // validation for all required values
        if ($scope.stepupForm.$invalid) {
            $scope.errorMessageModel.visible = true;
            $rootScope.fireErrorTracker = true;

            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);

            return;
        }

        if ($scope.emailAddressErrorMsg || $scope.userNameErrorMsg || $scope.dobError || $scope.yobErrorMsg) {
            $rootScope.fireErrorTracker = true;
            $scope.errorMessageModel.visible = true;

            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);

            return;
        }

        if (!$scope.pwdMatchValidation()) {
            $scope.errorMessageModel.visible = true;

            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);

            $rootScope.fireErrorTracker = true;
            return;
        }

        if (($scope.showSQA || $scope.showSecQuestionBasedonSharedEmail) && !$scope.alreadyHasSecQuestions) {
            if (!$scope.status.secQues1Valid || !$scope.status.secQues2Valid || !$scope.status.secQues3Valid) {
                $scope.errorMessageModel.visible = true;

                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                }, 300);

                $rootScope.fireErrorTracker = true;
                return;
            }
        }

        var postData = initData;

        postData.userInfoVO.coppaCount = $scope.coppaCount;

        if ($scope.showEmail) {
            postData.userInfoVO.emailAddress = $scope.emailAddress;
        }

        if ($scope.showUsername) {
            postData.userInfoVO.userName = $scope.userName;
        }

        if ($scope.showPassword) {
            postData.userInfoVO.pwd = $scope.newPassword;
            postData.userInfoVO.confirmPwd = $scope.confirmPassword;
        }

        if ($scope.showDOB) {
            postData.userInfoVO.dateOfBirth = angular.element('#dob_id_dob').val();
        }

        if ($scope.showYOB) {
            postData.userInfoVO.yearOfBirth = $scope.yob;
        }

        if (($scope.showSQA || $scope.showSecQuestionBasedonSharedEmail) && !$scope.alreadyHasSecQuestions) {
            postData.userInfoVO.securityQuestionVO.questionOne = $scope.secQues1.value;
            postData.userInfoVO.securityQuestionVO.questionTwo = $scope.secQues2.value;
            postData.userInfoVO.securityQuestionVO.questionThree = $scope.secQues3.value;
            postData.userInfoVO.securityQuestionVO.ansOne = $scope.secAnswerOne;
            postData.userInfoVO.securityQuestionVO.ansTwo = $scope.secAnswerTwo;
            postData.userInfoVO.securityQuestionVO.ansThree = $scope.secAnswerThree;
        }
        //if client side validations passes, service call is made
        StepupService.stepupUser(postData).then(function(responseData) {
            if (undefined !== responseData.data.errorMap && Object.keys(responseData.data.errorMap).length !== 0) {
                var errorMap = responseData.data.errorMap;
                $scope.errorMessageModel.visible = true;

                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    $rootScope.fireErrorTracker = true;
                }, 300);

                $scope.emailAddressErrorMsg = undefined !== errorMap.email ? errorMap.email : "";
                $scope.userNameErrorMsg = undefined !== errorMap.userName ? errorMap.userName : "";
                $scope.serverPassError = undefined !== errorMap.pwd ? errorMap.pwd : "";
                $rootScope.$emit('serverError', {msg: $scope.serverPassError});		//emitting server side error
                $scope.dobError = undefined !== errorMap.dobErrorMsg ? errorMap.dobErrorMsg : "";
                $scope.yobErrorMsg = undefined !== errorMap.yobErrorMsg ? errorMap.yobErrorMsg : "";
                $scope.secAns1ErrorMsg = undefined !== errorMap.secAns1ErrorMsg ? errorMap.secAns1ErrorMsg : "";
                $scope.secAns2ErrorMsg = undefined !== errorMap.secAns2ErrorMsg ? errorMap.secAns2ErrorMsg : "";
                $scope.secAns3ErrorMsg = undefined !== errorMap.secAns3ErrorMsg ? errorMap.secAns3ErrorMsg : "";

                // For Coppa
                $scope.coppaCount = undefined !== errorMap.coppaCount ? errorMap.coppaCount : $scope.coppaCount;
            } else {
                // Success flow
                $window.location = '/tb/app/secure/home.do';
            }
        });
    };
}
