(function() {
    'use strict';

    var module = angular.module('indexApp');

    module.controller('verifyIdentityBySecQuestionsCtrl', ['$scope', '$state', 'LanguageService', '$stateParams', '$timeout', 'forgotAccessService', 'trustbrokerAriaService', 'forgotAccessResponseVO', '$rootScope', 'AnalyticsService', 'HelpObj',
    function($scope, $state, LanguageService, $stateParams, $timeout, forgotAccessService, trustbrokerAriaService, forgotAccessResponseVO, $rootScope, AnalyticsService, HelpObj) {

        HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1022_Verify_Your_Identity_Sec_Questions.htm' });

        var responseVO = forgotAccessResponseVO.data;
        $scope.userName = forgotAccessResponseVO.data.userName;
        $scope.emailList = [];
        $scope.showSecurityQuestionOption = false;
        $scope.displaySQ1ErrorMessage = false;
        $scope.displaySQ2ErrorMessage = false;
        $scope.displaySQ3ErrorMessage = false;
        $scope.requestTypeForgotUserName = false;
        $scope.requestTypeForgotPwd = false;
        $scope.requestTypeSetupSecurityQuestions = false;
        $scope.requestTypeAccountUnlock = false;
        $scope.requestType = "";
        $scope.data = {};
        $scope.returnToVerifyIdentity = false;
        
        $scope.isEmailVerified = false;
        $scope.isSecEmailVerified = false;
        $scope.isPhoneVerified = false;

        $scope.errorMessageModel = {
            animationTime: 1,
            content: '',
            headingLevel: '2',
            id: 'errorMessage',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: false
        };


        $scope.setSQDetailsInThePage = function(responseVO) {
            $scope.showSecurityQuestionOption = true;
            $scope.question1 = responseVO.secQuestion1;
            $scope.question2 = responseVO.secQuestion2;
            $scope.question3 = responseVO.secQuestion3;
            $scope.setradioButtonCheckedForSecQuestion = true;
            $scope.setradioButtonForSecQuestionActive = true;
        };

        $scope.requestType = responseVO.requestType;
        $scope.recoveryType = responseVO.recoveryType;


        if (responseVO.primaryEmailVerified) {
            $scope.returnToVerifyIdentity = true;
            $scope.isEmailVerified = true;
            
        }

        if (responseVO.secondaryEmailVerified) {
            $scope.returnToVerifyIdentity = true;
            $scope.isSecEmailVerified = true;
        }

        if (responseVO.phoneVerified) {
            $scope.returnToVerifyIdentity = true;
            $scope.isPhoneVerified = true;
        }

        if (responseVO.secQuestionAvailable) {
            $scope.setSQDetailsInThePage(responseVO);
        }

        if ($scope.showSecurityQuestionOption) {
            $scope.displaySecurityQuestionblock = true;
        }

        pageDataLayer.content.pageName = "verifyYourIdentityUsingSecurityQuestions";

        if ($scope.requestType === 'forgotUserName') {
            $scope.requestTypeForgotUserName = true;
            pageDataLayer.content.siteSectionL1 = "findoptumid";
        } else if ($scope.requestType === 'forgotPwd') {
            $scope.requestTypeForgotPwd = true;
            pageDataLayer.content.siteSectionL1 = "resetpassword";
        } else if ($scope.requestType === 'setUpSecurityQuestion') {
            $scope.requestTypeSetupSecurityQuestions = true;
            $scope.showSecurityQuestionOption = false;
            $scope.displaySecurityQuestionblock = false;
            pageDataLayer.content.siteSectionL1 = "setsecurityquestions";
        } else if ($scope.requestType === 'unlockUserAccount') {
            $scope.requestTypeAccountUnlock = true;
            pageDataLayer.content.siteSectionL1 = "accountlocked";
        }

        if (typeof _satellite !== "undefined") {
            _satellite.track('trackPageView');
        }

        // Controller initialization ends
        $scope.radioButtonOptionChanged = false;
        $scope.submittedWithError = false;
        $scope.accountRecoveryoptionChosed = 0;
        $scope.accountRecoveryRadioButtonClicked = false;
        var data = $scope.data;

        $scope.onKeyUp = function(fieldId, errorId, fldErrFlag, fldErrMsg) {
            var fldValue = angular.element("#" + fieldId).val();

            if (fldValue !== '' && fldValue !== undefined) {
                trustbrokerAriaService.removeDescribedByAttribute(fieldId, errorId);
                $scope[fldErrFlag] = false;
            } else if ($scope[fldErrMsg] !== "" && $scope[fldErrMsg] !== undefined) {
                trustbrokerAriaService.appendDescribedByAttribute(fieldId, errorId);
                $scope[fldErrFlag] = true;
            }
        };

        $scope.setFieldValidity = function(inputid, spanid) {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        };

        LanguageService.doTranslate("selfservice");

        $scope.goToLogin = function() {
            $state.go('login');
        };

        $scope.retLinkClick = function($event) {
            $event.preventDefault();
            $state.go("forgotCredByIdentity", { userinfo: { 'userName': $scope.userName } });
        };
        
        $scope.nextScreen = function() {
            $scope.secQuestionValidationProcess();
        };

        $scope.secQuestionValidationProcess = function() {
            $scope.noValidationError = true;

            if (data.securityQuestion1 === '' || data.securityQuestion1 === undefined) {
                $scope.securityQuestion1IsEmpty();
            }

            if (data.securityQuestion2 === '' || data.securityQuestion2 === undefined) {
                $scope.securityQuestion2IsEmpty();
            }

            if ($scope.displaySQ1ErrorMessage || $scope.displaySQ2ErrorMessage) {
                $scope.ariaUpdate();
            }

            if ($scope.displaySQ1ErrorMessage && $scope.displaySQ2ErrorMessage) {
                $scope.formLevelErrorMessagesForAllRequired();
                $rootScope.fireErrorTracker = true;
            }

            if ($scope.noValidationError) {
                $scope.verifySecurityQuestion();
            }
        };
        $scope.verifySecurityQuestion = function() {
            var postData = { "recoveryType": "secQuestion", "userName": $scope.userName, "secAns1": data.securityQuestion1, "secAns2": data.securityQuestion2 };
            
            forgotAccessService.displayUserNameByVerifyingSecurityQuestion(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;
     
                if (status && $scope.requestType === 'forgotUserName') {
                    AnalyticsService.postRecoveryTypeInfo("username", "securityQuestions");
                    $state.go("login", { 'prevState': 'displayUserNameSuccessViaSQ', 'userName': $scope.userName });
                } else if (status && ($scope.requestType === 'forgotPwd' || $scope.requestType === 'unlockUserAccount')) {
                    if ($scope.requestType === 'forgotPwd') {
                        AnalyticsService.postRecoveryTypeInfo("password", "securityQuestions");
                    }
                    $state.go("resetPassword", { 'userName': $scope.userName });
                } else if (!status && responseVO.accountLockedStatus === "LOCKED") {
                    $scope.accountLockProcess(responseVO);
                } else {
                    $scope.processErrorMessages(responseVO);
                }
            });
        };

        $scope.accountLockProcess = function(responseVO) {
            if (!$scope.isEmailVerified && !$scope.isSecEmailVerified && !$scope.isPhoneVerified) {
                $state.go('norecoveryoption');
            } else if ($scope.isEmailVerified) {
                $scope.processErrorMessages(responseVO);
            } else if ($scope.isSecEmailVerified) {
                $scope.processErrorMessages(responseVO);
            } else if ($scope.isPhoneVerified) {
                $scope.processErrorMessages(responseVO);
            }
        };

        $scope.processErrorMessages = function(responseVO) {
            var messages = responseVO.messages;
            var secAnswer1Req = messages.secAnswer1ReqErrorMsg,
                secAnswer2Req = messages.secAnswer2ReqErrorMsg,
                secAnswer3Req = messages.secAnswer3ReqErrorMsg,
                secAnswersMisMatch = messages.secAnswersMisMatch,
                secAnswersMisMatchAccLockedSamePage = messages.secAnswersMisMatchAccLockedSamepage;

            if (messages.formerr !== undefined) {
                $scope.errorMessageModel.content = '<span>' + messages.formerr + '</span>';
                $scope.errorMessageModel.visible = true;
                $rootScope.fireErrorTracker = true;
            }

            if (secAnswer1Req !== '' && secAnswer1Req !== undefined) {
                $scope.securityAnswer1IsRequired();
            }

            if (secAnswer2Req !== '' && secAnswer2Req !== undefined) {
                $scope.securityAnswer2IsRequired();
            }

            if (secAnswer3Req !== '' && secAnswer3Req !== undefined) {
                $scope.securityAnswer3IsRequired();
            }

            if (secAnswersMisMatch !== '' && secAnswersMisMatch !== undefined) {
                data.securityQuestion1 = "";
                data.securityQuestion2 = "";
                data.securityQuestion3 = "";
                $scope.errorMessageModel.content = '<span>' + secAnswersMisMatch + '</span>';
                $scope.errorMessageModel.visible = true;
                AnalyticsService.postErrorTrackInfo("wrong security answers provided", "");
            }

            if (secAnswersMisMatchAccLockedSamePage !== '' && secAnswersMisMatchAccLockedSamePage !== undefined) {
                AnalyticsService.postErrorTrackInfo("security questions locked due to exceeded attempts", "");
                forgotAccessService.isErrorFlag(true);
                $state.go("forgotCredByIdentity", { userinfo: { 'userName': $scope.userName } });
            }
            $scope.ariaUpdate();
        };

        $scope.securityAnswer1IsRequired = function() {
            $scope.securityQuestion1Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.displaySQ1ErrorMessage = true;
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.secAnswer1ReqErrorMsg = "secAnswer1ReqErrorMsg";
        };

        $scope.securityAnswer2IsRequired = function() {
            $scope.securityQuestion2Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.displaySQ2ErrorMessage = true;
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.secAnswer2ReqErrorMsg = "secAnswer2ReqErrorMsg";
        };

        $scope.securityAnswer3IsRequired = function() {
            $scope.securityQuestion3Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.displaySQ3ErrorMessage = true;
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.secAnswer3ReqErrorMsg = "secAnswer3ReqErrorMsg";
        };

       

        $scope.securityQuestion1IsEmpty = function() {
            $scope.securityQuestion1Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.formLevelErrorMessages();
            $scope.noValidationError = false;
            $scope.displaySQ1ErrorMessage = true;
            $scope.secAnswer1ReqErrorMsg = "secAnswer1ReqErrorMsg";
        };

        $scope.securityQuestion2IsEmpty = function() {
            $scope.securityQuestion2Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.formLevelErrorMessages();
            $scope.noValidationError = false;
            $scope.displaySQ2ErrorMessage = true;
            $scope.secAnswer2ReqErrorMsg = "secAnswer2ReqErrorMsg";
        };

        $scope.securityQuestion3IsEmpty = function() {
            $scope.securityQuestion3Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.formLevelErrorMessages();
            $scope.noValidationError = false;
            $scope.displaySQ3ErrorMessage = true;
            $scope.secAnswer3ReqErrorMsg = "secAnswer3ReqErrorMsg";
        };

        $scope.formLevelErrorMessages = function() {
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.submittedWithError = true;
        };

        $scope.formLevelErrorMessagesForAllRequired = function() {
            if ($scope.requestType === 'forgotUserName') {
                $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessageForUserName"></span>';
            } else {
                $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage"></span>';
            }

            $scope.errorMessageModel.visible = true;
            $scope.submittedWithError = true;
        };

        $scope.ariaUpdate = function() {
            var FIELDS = [];
            var ind = 0;

            if ($scope.displaySQ1ErrorMessage) {
                FIELDS[ind] = { fld: "securityQuestion1_input", msg: "securityQuestion1Id_err" };
                ind++;
            }

            if ($scope.displaySQ2ErrorMessage) {
                FIELDS[ind] = { fld: "securityQuestion2_input", msg: "securityQuestion2Id_err" };
                ind++;
            }

            if ($scope.displaySQ3ErrorMessage) {
                FIELDS[ind] = { fld: "securityQuestion3_input", msg: "securityQuestion3Id_err" };
                ind++;
            }

            if (FIELDS.length > 0) {
                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    $scope.formErrorIsHidden = false;
                }, 300);
            }

            return;
        };
    }]);
})();
