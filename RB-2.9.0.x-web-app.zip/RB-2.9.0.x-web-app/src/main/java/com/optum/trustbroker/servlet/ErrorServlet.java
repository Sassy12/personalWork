/*
 * Copyright (C) 2015 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.optum.trustbroker.util.RelyingPartyAppUtil;
import com.optum.trustbroker.vo.RelyingPartyAppVO;

/**
 */
public class ErrorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private String urlOldGenMissing;
    private String urlNewGenMissing;
    private String urlOldGenForbidden;
    private String urlNewGenForbidden;
    private String urlOldGenInternal;
    private String urlNewGenInternal;
    private RelyingPartyAppUtil relyingPartyAppUtil;

    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        super.init(servletConfig);
        WebApplicationContext ctx = WebApplicationContextUtils
            .getRequiredWebApplicationContext(servletConfig.getServletContext());
        if (ctx == null) {
            throw new ServletException("couldn't get spring context");
        }
        urlOldGenMissing = (String) ctx.getBean("urlOldGenMissing");
        if (urlOldGenMissing == null) {
            throw new ServletException(
                "couldn't get urlOldGenMissing from spring context");
        }
        urlNewGenMissing = (String) ctx.getBean("urlNewGenMissing");
        if (urlNewGenMissing == null) {
            throw new ServletException(
                "couldn't get urlNewGenMissing from spring context");
        }
        urlOldGenForbidden = (String) ctx.getBean("urlOldGenForbidden");
        if (urlOldGenForbidden == null) {
            throw new ServletException(
                "couldn't get urlOldGenForbidden from spring context");
        }
        urlNewGenForbidden = (String) ctx.getBean("urlNewGenForbidden");
        if (urlNewGenForbidden == null) {
            throw new ServletException(
                "couldn't get urlOldGenMissing from spring context");
        }
        urlOldGenInternal = (String) ctx.getBean("urlOldGenInternal");
        if (urlOldGenInternal == null) {
            throw new ServletException(
                "couldn't get urlOldGenInternal from spring context");
        }
        urlNewGenInternal = (String) ctx.getBean("urlNewGenInternal");
        if (urlNewGenInternal == null) {
            throw new ServletException(
                "couldn't get urlNewGenInternal from spring context");
        }
        relyingPartyAppUtil = (RelyingPartyAppUtil) ctx.getBean("relyingPartyAppUtil");
        if (relyingPartyAppUtil == null) {
            throw new ServletException("couldn't get relyingPartyAppUtil from spring context");
        }
    }

    /**
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RelyingPartyAppVO rpApp = relyingPartyAppUtil.getRelyingParty(req, resp);
        String status = req.getParameter("status");
        if (relyingPartyAppUtil.isNextGen(rpApp)) {
            if (StringUtils.equals("403", status)) {
                forward(urlNewGenForbidden, req, resp);
            }
            else if (StringUtils.equals("404", status)) {
                forward(urlNewGenMissing, req, resp);
            }
            else {
                forward(urlNewGenInternal, req, resp);
            }
        }
        else if (StringUtils.equals("403", status)) {
            forward(urlOldGenForbidden, req, resp);
        }
        else if (StringUtils.equals("404", status)) {
            forward(urlOldGenMissing, req, resp);
        }
        else {
            forward(urlOldGenInternal, req, resp);
        }
        // make sure that this request is not cached.
        resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        resp.setHeader("Pragma", "no-cache");
        resp.setHeader("Expires", "0");
    }

    private void forward(String path, HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher dispatcher = req.getRequestDispatcher(path);
        dispatcher.forward(req, resp);
    }
}