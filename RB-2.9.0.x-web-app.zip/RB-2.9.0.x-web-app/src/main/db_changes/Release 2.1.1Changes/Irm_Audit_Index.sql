create index irmaudit_actor_activity on IRM_AUDIT_LOGS (actor_id, activity);
