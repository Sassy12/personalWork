package com.optum.trustbroker.managebean;
/*
 **Use Cases**
1.	User clicks a link from previous email account which was associated with user account earlier but now a different email exists on user account.
2.	User clicks a previous link from email and not the recent one and email is not verified.
3.	User clicks a previous link from email and not the recent one and email is already verified.
4.	User clicks the most recent link from email and email is already verified (Link is already used).
5.	User clicks the most recent link from email and email is not verified. -Success scenario
6.	If user clicks the link which was associated with a user account that has been deleted from the system.
7.	If user clicks the link which is missing the verification details or link is wrong copy pasted in browser. 
*/

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.controller.vo.ConfirmationEmailVO;
import com.optum.trustbroker.controller.vo.MessageType;
import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.message.MessageUtils;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.UserVerifyCdCtxVO;
import com.optum.trustbroker.vo.UserVerifyCodesServiceResponse;
import com.optum.trustbroker.vo.UserVerifyCodesVO;
import com.optum.trustbroker.vo.VerificationCodeRequest;
import com.optum.trustbroker.vo.VerificationCodeResponse;
import com.uhg.iam.alps.common.http.HttpUtils;

@ManagedBean(name = "confirmationEmailBean")
@ViewScoped
public class ConfirmationEmailBean extends AbstractBackingBean implements Serializable {

	private static final long serialVersionUID = 1L;
	BaseLogger logger = new BaseLogger(ConfirmationEmailBean.class);

	private String errorMsg;
	private String loginURL = "/views/login.jsf?faces-redirect=true";
	
	Map<String, String> verificationDetils;
	
	private UserVO verificationUserVO;
	private UserVerifyCodesVO userVerifyCodesVO;
	private SupportContactInfoVO sci;
	
	private boolean emailVerifiedSuccess;
	private boolean displayResendBtn;
	private boolean displayContinueBtn;
	private String alert;
	private CommunicationChannel commChannel;
	private String successMessage;
	private String sendCodeText;
	private boolean iFrameRequest;
	private boolean iFrameRPRedirectionNotReq;
	private boolean expiredResent;
	
	public void verifyEmailViaLink() {
		
		if (FacesContext.getCurrentInstance().isPostback()){
			return;
		}

		sci = getSupportContactInfo();
		
		String verificationToken = getRequestParameter(TrustBrokerConstants.VERIFICATION_DETAILS);
		
		if (StringUtils.isNotEmpty(verificationToken)) {

			try {
				verificationDetils = getContainer().getCryptAgentUtil().getCryptAgent().getAttributesFromToken(verificationToken,true);
				
				UserVerifyCodesServiceResponse verifyCodeResponse = getContainer().getUserVerifyCodesService().
					getUserVerifyCodesByRequestToken(verificationDetils.get(TrustBrokerConstants.REQUEST_TOKEN));
				
				addRPDetailsFromVerificationDetailsContext(verifyCodeResponse.getUserVerifyCodesVO());
				
				UserRetrievalServiceResponse response = getContainer().getUserService().fetchUserProfile(
						verificationDetils.get(TrustBrokerConstants.USER_UUID), true, false);
				verificationUserVO = response.getUser();
				
				commChannel = getCommunicationChannel();
				String verificationEmail = verificationDetils.get(TrustBrokerConstants.USER_EMAIL);
				
				if(TrustbrokerWebAppUtil.checkResponseStatus(verifyCodeResponse)){
                                    
                                    userVerifyCodesVO = verifyCodeResponse.getUserVerifyCodesVO();
                                    if(null != userVerifyCodesVO) {
                                            checkForiFrameRequest(userVerifyCodesVO);
                                    }
                                    if((CommunicationChannel.SECONDARY_EMAIL == commChannel && verificationUserVO.isSecEmailVerified()) ||
                                                    (CommunicationChannel.PRIMARY_EMAIL == commChannel && verificationUserVO.isIsemailVerified())){
                                            getContainer().getUserVerifyCodesService().deleteUserVerifyCodes(verifyCodeResponse.getUserVerifyCodesVO().getUserVerifyCdId());
                                            nextActionOnVerification();
                                            return;
                                    }
                                    
                                    // Case 5 - Success case when user has not been verified.
                                    verifyEmail(); 
                                    return;
                                } else if (TrustbrokerWebAppUtil.checkExpiredRespStatus(verifyCodeResponse)) {
                                    sendAnotherCode();
                                    String maskedEmail = TBUtil.emailMask(verificationEmail);                       
                                    setSuccessMessage(StringUtils.replace(
                                            tbResources.getString("emailVerfnOldGenExpMsg"), "{0}", maskedEmail));                                    
                                    setExpiredResent(true);
                                                                                                                                                                                    
                                }  else if(!TrustbrokerWebAppUtil.checkResponseStatus(verifyCodeResponse)){
				  //Details not found, user might have been verified already earlier and record do not exist
					//Case - If email was changed recently on user account and previous email do not exist 
					// (Primary or Secondary depending upon verification type) 					
					
					if(CommunicationChannel.PRIMARY_EMAIL == commChannel){						
						//Case 1
						processVerificationIfDetailsNotFound(verificationUserVO.getEmailAddress(), 
								verificationEmail, verificationUserVO.isIsemailVerified());
					} else if (CommunicationChannel.SECONDARY_EMAIL == commChannel){ 						
						//Case 1
						processVerificationIfDetailsNotFound(verificationUserVO.getSecEmailAddress(), 
								verificationEmail, verificationUserVO.isSecEmailVerified());
					}
				} 
				
			} catch (OperationFailedException ofe) {
				logger.error("Error while verifying email with verification token {}, error code - {}", 
						new String[]{verificationToken,TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
				if(ofe.getErrorMessage() != null && ofe.getErrorMessage().getCode().equalsIgnoreCase(TrustBrokerConstants.OPT_00A003)){
					//Case 6 - User not found
					setErrorMsg(TBUtil.formatMessage(tbResources.getString("linkExpiredOrVerifyDetailsMissing"), 
							new String[]{sci.getContactComboText()}));
				} else {
					setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(), sci) 
							: ofe.getMessage());
				}
			} catch(Exception ex){
				String referenceCode = MessageUtils.getErrorUid();
				logger.error("Unexpected error while verifying email, error code - {}", new String[]{referenceCode}, ex);
				setErrorMsg(TBUtil.formatMessage(tbResources.getString("verifysystemException"), 
						new String[]{sci.getContactComboText(), referenceCode}));
			}
		}
		else {
			String referenceCode = MessageUtils.getErrorUid();
			logger.error("Verification details missing in URL or not properly encoded - {}", new String[]{referenceCode});
			setErrorMsg(TBUtil.formatMessage(tbResources.getString("linkExpiredOrVerifyDetailsMissing"), 
					new String[]{sci.getContactComboText()})); //Case 7
		}
	}
	
	private void checkForiFrameRequest(UserVerifyCodesVO userVerifyCodesVO) {
		List<UserVerifyCdCtxVO> userVerifyCdCtxVOList = userVerifyCodesVO.getUserVerifyCdCtxVO();
		if(null != userVerifyCdCtxVOList) {
			for(UserVerifyCdCtxVO userVerifyCdCtxVO : userVerifyCdCtxVOList) {
				if(TrustBrokerConstants.IFRAMEREQUEST.equalsIgnoreCase(userVerifyCdCtxVO.getCtxName()) 
						&& TrustBrokerConstants.STATUS_YES.equalsIgnoreCase(userVerifyCdCtxVO.getCtxValue())) { 
					iFrameRequest = true;
				}
				else if(TrustBrokerConstants.IFRAMEREDIRECTIONNOTREQ.equalsIgnoreCase(userVerifyCdCtxVO.getCtxName()) 
						&& TrustBrokerConstants.STATUS_YES.equalsIgnoreCase(userVerifyCdCtxVO.getCtxValue()))
					iFrameRPRedirectionNotReq = true;
			}
		}
	}

	private void processVerificationIfDetailsNotFound(String currentEmail, String verificationEmail, boolean isCurrentEmailVerified){
		if((StringUtils.isBlank(currentEmail) ||  (!currentEmail.equalsIgnoreCase(verificationEmail)))){
			setErrorMsg(TBUtil.formatMessage(tbResources.getString("emailNotExistOnProfile"), 
					new String[]{sci.getContactComboText()}));
		} else if(isCurrentEmailVerified){ //Case 3 and 4
			emailVerifiedSuccess = true;
			setSuccessMessage(TBUtil.formatMessage(tbResources.getString("emailAlreadyVerifiedSuccess"), new String[]{sci.getContactComboText()}));
			//nextActionOnVerification();
		} else if(!isCurrentEmailVerified){ //Case 2
			if(checkIfVerificationDetailsExists(currentEmail)){
				setErrorMsg(TBUtil.formatMessage(tbResources.getString("emailVerificationFailedOldCode"), 
						new String[]{TBUtil.emailMask(currentEmail)}));
				sendCodeText = tbResources.getString("resendCode");
			} else {
				setErrorMsg(TBUtil.formatMessage(tbResources.getString("emailVerificationFailedNoCode"), 
						new String[]{TBUtil.emailMask(currentEmail)}));
				sendCodeText = tbResources.getString("sendMeNewCode");
			}
			displayResendBtn = true;
		}
	}
	
	private boolean checkIfVerificationDetailsExists(String currentEmail){
		UserVerifyCodesServiceResponse response = getContainer().getUserVerifyCodesService().getUserVerifyCodes(
				verificationUserVO.getUuId(), currentEmail, commChannel.toString());
		return TrustbrokerWebAppUtil.checkResponseStatus(response); 
	}
	
	private void verifyEmail(){
		
		try{
			
			VerificationCodeResponse respVerify = container.getUserService().verifyChannel(commChannel, userVerifyCodesVO.getCode(), "");
			
			if (respVerify.getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
				emailVerifiedSuccess = true;
				setSuccessMessage(tbResources.getString("emailVerifiedSuccessOnLink"));
				UserVO userVO = getCurrentUserVO();
				UserVO userVONew = null;
				if(null != userVO){
					try {
						userVONew = (UserVO) BeanUtils.cloneBean(userVO);
					} catch (Exception e) {
						userVONew = userVO;
					} 		
					if(commChannel == CommunicationChannel.PRIMARY_EMAIL){
						userVONew.setIsemailVerified(true);
						userVONew.setPrimaryEmailUnique(respVerify.isUniqueStatusPostVerification());
					} else if(commChannel == CommunicationChannel.SECONDARY_EMAIL){ 
						userVONew.setSecEmailVerified(true);
						userVONew.setSecEmailUnique(respVerify.isUniqueStatusPostVerification());
					}
					setCurrentUserVO(userVONew);
				}
				
				nextActionOnVerification();
				
			} else{
				emailVerifiedSuccess = false;
				displayContinueBtn = false;
				setErrorMsg(tbResources.getString("emailVerificationFailedEsso"));
			}
		}
		catch (OperationFailedException e) {
			logger.error("secondary email verification failed", e);
			if (checkVerificationError(e)) {
				return;
			}
			setErrorMsg(TBUtil.formatMessage(tbResources.getString("linkExpiredOrVerifyDetailsMissing"), 
					new String[]{getSupportContactInfo().getContactComboText()}));
		}
	}
	
	private void nextActionOnVerification(){
		if (!isActiveSMSessionForUser(verificationUserVO.getUserName())) {
			if(!iFrameRequest) {
				loginURL = HttpUtils.addParameterToURL(loginURL, TrustBrokerWebAppConstants.LOGIN_FAIL_REASON, 
					TrustBrokerWebAppConstants.REASON_ACCOUNT_VERIFIED);
				loginURL = constructURLWithRPParams(loginURL);
				redirectToView(loginURL);
			} else if(iFrameRequest && !iFrameRPRedirectionNotReq) {
				displayContinueBtn = true;
			} else if(iFrameRequest && iFrameRPRedirectionNotReq)
				setSuccessMessage(tbResources.getString("emailVerifiedFromProfile"));
		} else if(iFrameRequest && iFrameRPRedirectionNotReq) {
			setSuccessMessage(tbResources.getString("emailVerifiedFromProfile"));
			displayContinueBtn = false;
		}
		else displayContinueBtn = true;
	}
	
	public void sendAnotherCode(){
		try {
			container.getUserService().sendVerificationCode(getVerificationCodeRequest(commChannel, verificationUserVO));
			alert = tbResources.getString("confirmationCodeSent");
			displayResendBtn = false;
			setErrorMsg(null);
		}
		catch(OperationFailedException ofe){
			setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(
					container.getErrorMessageSource(), sci) : ofe.getMessage());
		}
	}
	
	public void continueToApplication() {
		
		String redirectURI = "";
		String rpTargetURL = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL)!= null ? 
				(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL):
					(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);
		if (isActiveSMSessionForUser(verificationUserVO.getUserName())) {
			if(!iFrameRequest) {
				redirectURI = getHomePageURIWithAlias();
			} else if(iFrameRPRedirectionNotReq) {
				redirect(rpTargetURL);
			}
		} else {
			if(!iFrameRequest) {
			redirectURI = "/views/login.jsf?faces-redirect=true";
			redirectURI = HttpUtils.addParameterToURL(redirectURI, TrustBrokerWebAppConstants.LOGIN_FAIL_REASON, 
					TrustBrokerWebAppConstants.REASON_ACCOUNT_VERIFIED);
			} else 
				redirect(rpTargetURL);
		}
		
		redirectURI = constructURLWithRPParams(redirectURI);
		redirectToView(redirectURI);
	}
	
	private void addRPDetailsFromVerificationDetailsContext(UserVerifyCodesVO userVerifyCodeDetails){
		
		if(null != userVerifyCodeDetails && null!= userVerifyCodeDetails.getUserVerifyCdCtxVO()){
			for(UserVerifyCdCtxVO usrVerifyCdCtx: userVerifyCodeDetails.getUserVerifyCdCtxVO()){
			        if(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA.
			                equals(usrVerifyCdCtx.getCtxName())) {
			            addSessionAttribute(usrVerifyCdCtx.getCtxName(), 
			                    getOIDParamsFromToken(usrVerifyCdCtx.getCtxValue()));
			        } else {
				    addSessionAttribute(usrVerifyCdCtx.getCtxName(), usrVerifyCdCtx.getCtxValue());		
			        }
			}
		}
		
		addRelyingPartySettingsToSession();
		
		sci = getSupportContactInfo();
	}
	
	private CommunicationChannel getCommunicationChannel(){
		
		if(CommunicationChannel.PRIMARY_EMAIL.toString().equals(verificationDetils.get(TrustBrokerConstants.VERIFICATION_TYPE))){
			commChannel = CommunicationChannel.PRIMARY_EMAIL;
		} else if(CommunicationChannel.SECONDARY_EMAIL.toString().equals(verificationDetils.get(TrustBrokerConstants.VERIFICATION_TYPE))){
			commChannel = CommunicationChannel.SECONDARY_EMAIL;
		}
		
		return commChannel;
	}
	
	private boolean checkVerificationError(OperationFailedException e) {
		Map<String, String> errMsgs = e.getErrorMessages();
		if ((errMsgs == null || errMsgs.isEmpty()) && e.getCause() != null) {
			errMsgs = ((OperationFailedException)e.getCause()).getErrorMessages();
		}
		if (errMsgs != null && (errMsgs.containsKey("EMAIL_VERIFICATION_CODE_MISMATCH") ||
				errMsgs.containsKey("PHN_NO_VERIFICATION_CODE_MISMATCH") ||
				errMsgs.containsKey("VERIFICATION_CODE_EXPIRED") ||
				errMsgs.containsKey("VALIDATION_ERROR")) ) {
			setErrorMsg(TBUtil.formatMessage(tbResources.getString("linkExpiredOrVerifyDetailsMissing"), 
					new String[]{getSupportContactInfo().getContactComboText()}));
			return true;
		}
		return false;
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public boolean isEmailVerifiedSuccess() {
		return emailVerifiedSuccess;
	}

	public void setEmailVerifiedSuccess(boolean emailVerifiedSuccess) {
		this.emailVerifiedSuccess = emailVerifiedSuccess;
	}
	
	public boolean isDisplayResendBtn() {
		return displayResendBtn;
	}

	public void setDisplayResendBtn(boolean displayResendBtn) {
		this.displayResendBtn = displayResendBtn;
	}

	public boolean isDisplayContinueBtn() {
		return displayContinueBtn;
	}

	public void setDisplayContinueBtn(boolean displayContinueBtn) {
		this.displayContinueBtn = displayContinueBtn;
	}

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public String getSendCodeText() {
		return sendCodeText;
	}

	public void setSendCodeText(String sendCodeText) {
		this.sendCodeText = sendCodeText;
	}

	public boolean isiFrameRequest() {
		return iFrameRequest;
	}

	public void setiFrameRequest(boolean iFrameRequest) {
		this.iFrameRequest = iFrameRequest;
	}

	public boolean isiFrameRPRedirectionNotReq() {
		return iFrameRPRedirectionNotReq;
	}

	public void setiFrameRPRedirectionNotReq(boolean iFrameRPRedirectionNotReq) {
		this.iFrameRPRedirectionNotReq = iFrameRPRedirectionNotReq;
	}

    /**
     * This method returns the expiredResent.
     *
     * @return the expiredResent
     */
    public boolean isExpiredResent() {
        return expiredResent;
    }

    /**
     * This method sets the given expiredResent value to expiredResent.
     *
     * @param expiredResent the expiredResent to set
     */
    public void setExpiredResent(boolean expiredResent) {
        this.expiredResent = expiredResent;
    }
	

}
