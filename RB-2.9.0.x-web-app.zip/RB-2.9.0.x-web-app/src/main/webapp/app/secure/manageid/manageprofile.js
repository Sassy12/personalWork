(function() {
    'use strict';

    var tbApp = angular.module('tbApp');

    tbApp.controller('TabsController', TabsController);
    tbApp.controller('ProfileInfoController', ProfileInfoController);

    TabsController.$inject = ['$scope', '$translate', 'ProfileService', '$state', '$timeout', '$window', '$rootScope'];

    function TabsController($scope, $translate, ProfileService, $state, $timeout, $window, $rootScope) {

        var index = ProfileService.getTabIndex();
        var rpURL = '';

        $scope.showModal = false;
        $scope.tabsModel = {
            selectedIndex: index || 0,
            id: 'profiletabs',
            ariaLabel: 'Tab Panel',
            tabs: [{
                title: $translate.instant('profileInfo'),
                templateurl: '/profile-tab.html',
                disabled: false
            }, {
                title: $translate.instant('changePwd'),
                templateurl: '/changepwd-tab.html',
                disabled: false
            }, {
                title: $translate.instant('verificationOptions'),
                templateurl: '/verificationoptions-tab.html',
                disabled: false
            }]
        };

        ProfileService.saveTabModel($scope.tabsModel);
        ProfileService.saveTabScope($scope);

        $timeout(function () {
            var tabScope = angular.element('#profiletabs').isolateScope();

            if (tabScope) {
                /* cache the original handler in a different function */
                tabScope.originalClickHandler = tabScope.selectTab;

                /* re-define the original handler */
                tabScope.selectTab = function (pane, index) {
                    /* if user is clicking on the same tab header do nothing */
                    if(index === ProfileService.getTabIndex()){
                        return;
                    }
                    var changesDetected = checkStateAndShowDialog();
                    ProfileService.saveTempTabIndex(index);

                    if (!changesDetected) {
                        tabScope.originalClickHandler(pane, index);
                    }
                };
            }
        });

        function checkStateAndShowDialog(rpModal){
            var container = angular.element('#profiletabs_tab_tabpanel > div');

            /* This might be invoked as part of initial page load as well.
             * Check for unsaved changes only when the view is initialized properly
             * and bound to some controller */

            var changesDetected = false;

            if (container && container.controller()) {
                var controller = container.controller();
                changesDetected = controller.checkForUnsavedChanges();

                if (rpModal) {
                    $scope.showRPInfo = true;
                } else {
                    $scope.showRPInfo = false;
                }

                $scope.showModal = changesDetected;
            }

            return changesDetected;
        }

        $scope.onDialogOpen = function () {
            $('#unsavedPopupId').focus();
        };

        $scope.onDialogClose = function() {
            var currentTab = ProfileService.getTabIndex();

            // when the user exits the modal (choosing to stay on current tab), we set focus back to current tab
            $timeout(function () {
                angular.element('#profiletabs_tab' + currentTab + '_tab').focus();
            }, 300);
        };

        $scope.$watch(function () {
            return $scope.tabsModel.selectedIndex;
        }, function (newVal) {
            switch (newVal) {
                case 0: {
                    $state.go('profile.profileinfo');
                    break;
                }
                case 1: {
                    $state.go('profile.changepwd');
                    break;
                }
                case 2: {
                    $state.go('profile.verifyoptions');
                    break;
                }
                default: {
                    $state.go('profile.profileinfo');
                    break;
                }
            }
        });

        var rpDetails = ProfileService.getRPDetailsFromCache();

        if (rpDetails && rpDetails.rpContext) {
            rpURL = rpDetails.rpContext.targetURL;
            $scope.showRpLink = true;
            $scope.rpLinkText = $translate.instant('returnToRp', { 'rpName': rpDetails.rpContext.applicationName });
        }

        $scope.onContinue = function (event) {
            event.preventDefault();

            var rpDialog = $scope.showRPInfo;

            if (rpDialog) {
                $scope.showModal = false;
                $window.location.href = rpURL;
            } else {
                var index = ProfileService.getTempTabIndex();

                // handle continue action differently for first tab alone during cancelFlow
                if (ProfileService.cancelFlow) {
                    ProfileService.cancelFlow = false;
                    $rootScope.$emit('tabreset');
                } else {
                    ProfileService.updateTabIndex(index);

                    // when the user selects "continue", we set focus back to current tab
                    $timeout(function () {
                        angular.element('#profiletabs_tab' + index + '_tab').focus();
                    }, 300);
                }

                $scope.showModal = false;
            }
        };

        $scope.gotoRP = function ($event) {
            $event.preventDefault();
            var changesDetected = checkStateAndShowDialog(true);

            if (!changesDetected) {
                $window.location.href = rpURL;
            }
        };

        $scope.continuetoRP = function () {
            $window.location.href = rpURL;
        };
        
    }

    ProfileInfoController.$inject = ['$scope',
                                     'ProfileService',
                                     '$translate',
                                     '$timeout',
                                     '$rootScope',
                                     '$window',
                                     'HelpObj',
                                     'trustbrokerAriaService'];

    function ProfileInfoController($scope,
                                   ProfileService,
                                   $translate,
                                   $timeout,
                                   $rootScope,
                                   $window,
                                   HelpObj,
                                   trustbrokerAriaService) {

        HelpObj.setHelpObj({ url: '../../webHelp/Default_CSH.htm#Optum ID CSH/entry_1014_Manage_Your_Optum_ID.htm' });
        $scope.constants = $rootScope.constants;
        $scope.fireErrorTracker = $rootScope.fireErrorTracker;
        $scope.trackError = $rootScope.trackError;

        if (pageDataLayer) {
            pageDataLayer.content.pageName = "updateuserprofile";
            pageDataLayer.content.siteSectionL1 = "";
        }

        if (typeof _satellite !== "undefined") {
            _satellite.track('trackPageView');
        }

        var self = this;
        self.previousDate = '';
        self.formChanged = false;
        self.processing = false;

        var pageData = null;
        var select = {
            label: $translate.instant('select'),
            value: ''
        };

        $scope.states = [select];

        var errorMarkups = {
            'pristine': [
                '<span>',
                $translate.instant('pristineError'),
                '</span>'
            ].join(''),
            'review': [
                '<span>',
                $translate.instant('formErrorsNote'),
                '</span>'
            ].join('')
        };

        $scope.maxlength = 10;
        $scope.isTablet = false;
        $scope.dataUpdated = false;

        if (navigator.userAgent.match(/iPad/i) === 'iPad' || navigator.userAgent.match(/Android/i) === 'Android') {
            $scope.isTablet = true;
        }

        $scope.successMessageModel = {
            animationTime: 1,
            ariaAttributes: true,
            autoFadeOut: false,
            content: '<span translate="updateSuccess"></span>',
            id: 'Success',
            messageRole: 'alert',
            messageType: 'success',
            position: 'inline',
            visible: true
        };

        $scope.errorMessageModel = {
            animationTime: 1,
            ariaAttributes: true,
            autoFadeOut: false,
            content: errorMarkups.pristine,
            headingLevel: '2',
            id: 'Error',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: true
        };

        $scope.notificationMsgModel = {
            animationTime: 1,
            ariaAttributes: true,
            autoFadeOut: false,
            content: '<span translate="profileUptoDate"></span>',
            id: 'Profile_Form_Notification',
            messageRole: 'alert',
            messageType: 'information',
            position: 'inline',
            visible: true
        };

        $scope.addressFieldsErrorModel = {
            animationTime: 1,
            ariaAttributes: true,
            autoFadeOut: false,
            content: '<span translate="addressFieldsError"></span>',
            headingLevel: '2',
            id: 'addressError',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: true
        };

        $rootScope.$on('tabreset',function () {
            resetTab();
        });

        ProfileService.getProfileInfo().then(function(response) {
            pageData = response;
            var profile = pageData.profile;
            // reset all undefined values to empty
            profile.middleName = profile.middleName || '';
            profile.prefix = profile.prefix || '';
            profile.suffix = profile.suffix || '';
            profile.city = profile.city || '';
            profile.homeAddress = profile.homeAddress || '';
            profile.zip = profile.zip || '';

            $scope.data = angular.copy(profile);
            self.previousDate = profile.dateOfBirth || '';
            
            if (pageData.rpContext) {
                $scope.dobReq = pageData.rpContext.showDob;
            }
            
            $scope.dobViewModel = {
                	invalid: false,
                	displayAgeInformation:false,
                	labelledBy:'dobLblId', 
                	textFieldClassName: 'tk-height-2t tk-width-10t',
                	enableValidation: false,
                	requiredMessage: 'dateOfBirthReq',
                    invalidFormatMessage: 'invalidDateFormat',
                    invalidDateMessage: 'invalidDate',
                    dobInvalidFutureMessage: 'futureDate',
                    invalidYearMessage: 'invalidYear',
                    maxYear: new Date().getFullYear()
            };
            
            if($scope.dobReq) {
            	$scope.dobViewModel.required = true;
            } else {
            	$scope.dobViewModel.required = false;
            }

            initializeStates();

            /* when coming from verification options tab,
             * show success msg if requested during state transition */
            if (ProfileService.showSuccessMsg) {
                $scope.showSuccess = true;
                ProfileService.showSuccessMsg = false;
            }
        });
        
        function resetTab() {
            $scope.data = angular.copy(pageData.profile);
            initializeStates();

            $scope.showSuccess = false;
            $scope.showError = false;
            $scope.serverErrors = {};
            $scope.errors = {};

            // when tab is reset, set focus to tab0 (first tab)
            $timeout(function() {
                angular.element('#profiletabs_tab0_tab').focus();
            }, 300);
        }

        function initializeStates() {
            var states = angular.copy(pageData.states);

            states.sort(function (obj1, obj2) {
                var label1 = obj1.label,
                    label2 = obj2.label;

                if (label1 < label2) {
                    return -1;
                }
                if (label1 > label2) {
                    return 1;
                }
                // labels must be equal
                return 0;
            }).unshift(select);

            $scope.states = states;
            var currentState = pageData.profile.state;

            states.forEach(function (stateObj) {
                if (stateObj.value === currentState) {
                    $scope.data.selectedState = stateObj;
                }
            });
        }

        $scope.onCancel = function($event) {
            if (self.checkForUnsavedChanges()) {
                $event.preventDefault();
                ProfileService.cancelFlow = true;
                ProfileService.showModal();
                return false;
            }

            $scope.profile_form.$submitted = false;
            self.formChanged = false;

            if (pageData.rpContext && pageData.rpContext.targetURL) {
                $window.location.href = pageData.rpContext.targetURL;
            } else {
                resetTab();
            }
        };

        $scope.onNameChange = function(fldName) {
            $scope.data[fldName] = trimName($scope.data[fldName]);
        };

        $scope.setFieldValidity = function(inputid, spanid) {
            $timeout(function() {
                trustbrokerAriaService.setFieldValidity(inputid, spanid);
            }, 300);
        };

        $scope.validateDateField = function(dateString, errors, dobRequired) {
            if (dobRequired || !validators.checkIfEmpty(dateString)) {
            	var dateErrorMsg = validators.isValidDate($scope.dobViewModel);
            	if(!validators.checkIfEmpty(dateErrorMsg)) {
            		$scope.dobError = $translate.instant(dateErrorMsg);
            		errors.dobErr = true;
            		return;
            	}
            }

            errors.dobErr = false;
            $scope.dobError = '';
        };

        $scope.saveDetails = function(profileData) {

            var dateString = angular.element('#dobId_dob').val();

            var FIELDS = [
                { fld: "firstNameId_input",     msg: "firstNameId_err" },
                { fld: "middleNameId_input",    msg: "middleNameId_err" },
                { fld: "lastNameId_input",      msg: "lastNameId_err" },
                { fld: "dobId_dob",             msg: "dobId_err" },
                { fld: "zipcodeId_input",       msg: "zipcodeId_err" }
            ];

            self.formChanged = checkStateChange(profileData, pageData.profile, dateString);

            $scope.showSuccess = false;
            $scope.showError = false;
            $scope.serverErrors = {};

            if ($scope.errors) {
                $scope.errors.addressFieldsError = false;
            }

            if (!self.formChanged) {
                $scope.showUpToDateMsg = true;
                self.processing = false;

                // Fire error tracker is to send a webanalytics event
                $rootScope.fireErrorTracker = true;

                $timeout(function() {
                    angular.element('#Profile_Form_Notification').focus();
                }, 300);

                return;
            } else if (self.processing) {
                // Fire error tracker is to send a webanalytics event
                $rootScope.fireErrorTracker = true;
                return;
            } else {
                self.processing = true;
            }

            $scope.showUpToDateMsg = false;

            var errors = {};

            validateNameFields(profileData, errors);
            $scope.validateDateField(dateString, errors, $scope.dobReq);
            validateAddressFields(profileData, errors);

            var hasErrors = false,
                prop;

            for (prop in errors) {
                if (errors[prop] === true) {
                    hasErrors = true;
                    break;
                }
            }

            $scope.errors = errors;

            if (hasErrors || $scope.profile_form.$invalid) {
                $scope.errorMessageModel.content = errorMarkups.review;

                if (!$scope.errors.addressFieldsError) {
                    $scope.showError = true;
                } else {
                    $timeout(function() {
                        angular.element('#addressError').focus();
                    });
                }

                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                }, 200);

                self.processing = false;

                // Fire error tracker is to send a webanalytics event
                $rootScope.fireErrorTracker = true;
                return;
            }

            var postData = angular.copy(profileData);
            postData.dateOfBirth = dateString;
            postData.middleName = profileData.middleName || '';

            if (profileData.selectedState && !validators.checkIfEmpty(profileData.selectedState.value)) {
                postData.state = profileData.selectedState.value;
            } else {
                postData.state = '';
            }

            delete postData.selectedState;

            ProfileService.updateProfileInfo(postData).then(function(response) {
                self.formChanged = false;
                self.processing = false;
                $scope.profile_form.$submitted = false;

                if (response.data.status === 'success') {
                    pageData.profile = angular.copy(postData);
                    $scope.showSuccess = true;

                    $timeout(function() {
                        angular.element('#Success').focus();
                    }, 300);
                } else {
                    $scope.showSuccess = false;
                }
            }, function(error) {
                self.formChanged = false;
                self.processing = false;
                $scope.showError = true;
                var errorData = error.data;

                if (errorData.errorMap) {
                    var map = errorData.errorMap,
                        prop,
                        serverErrors = {};

                    for (prop in map) {
                        if (map.hasOwnProperty(prop) && prop !== 'addressFieldsError') {
                            var errorKey = map[prop];
                            var translatedMsg = $translate.instant(errorKey);

                            if (translatedMsg !== errorKey) {
                                serverErrors[prop] = translatedMsg;
                            } else {
                                serverErrors[prop] = errorKey;
                            }
                        }
                    }

                    if ('addressFieldsError' in map) {
                        $scope.errors.addressFieldsError = true;
                        $scope.showError = false;

                        $timeout(function() {
                            angular.element('#addressError').focus();
                        }, 300);
                    } else {
                        $scope.errorMessageModel.content = errorMarkups.review;
                    }

                    $scope.serverErrors = serverErrors;

                    if ($scope.serverErrors && $scope.serverErrors.dob) {
                        $scope.dobError = $scope.serverErrors.dob;
                    }

                    $timeout(function() {
                        trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    }, 300);
                } else if ('message' in errorData) {
                    $scope.errorMessageModel.content = ['<span>', errorData.message, '</span>'].join('');

                    $timeout(function() {
                        angular.element('#Error').focus();
                    }, 300);
                }

                // Fire error tracker is to send a webanalytics event
                $rootScope.fireErrorTracker = true;
            });
        };

        function checkStateChange(viewState, prevState, dateValue) {
            var stateValue = '';

            if (viewState.selectedState && !validators.checkIfEmpty(viewState.selectedState.value)) {
                stateValue = viewState.selectedState.value;
            }

            if (dateValue !== self.previousDate) {
                self.previousDate = dateValue;
                return true;
            } else if (stateValue !== prevState.state) {
                return true;
            }

            viewState.middleName = viewState.middleName || '';

            var fields = ['firstName', 'middleName', 'lastName', 'suffix', 'prefix', 'homeAddress', 'zip', 'city'];

            var count = 0,
                fldName;

            for (count; count < fields.length; count++) {
                fldName = fields[count];

                if (viewState[fldName] !== prevState[fldName]) {
                    return true;
                }
            }

            return false;
        }

        this.checkForUnsavedChanges = function () {
            return checkStateChange($scope.data, pageData.profile, $scope.dobViewModel.dateText);
        };
    }

    function validateAddressFields(profileData, errors) {
        var allOrNone = ['homeAddress', 'zip', 'city'];
        var empties = 0,
            notEmpties = 0;

        allOrNone.forEach(function(field) {
            if (validators.checkIfEmpty(profileData[field])) {
                empties++;
            } else {
                notEmpties++;
            }
        });

        if (profileData.selectedState && !validators.checkIfEmpty(profileData.selectedState.value)) {
            notEmpties++;
        } else {
            empties++;
        }

        if (notEmpties >= 1 && Math.abs(empties - notEmpties) < 4) {
            errors.addressFieldsError = true;
        }

        if (!errors.addressFieldsError) {
            var zipCode = profileData.zip;

            if (!validators.checkIfEmpty(zipCode) && (isNaN(zipCode) || !(zipCode.length === 5 || zipCode.length === 9))) {
                errors.zipCodeError = true;
            }
        }
    }

    function validateNameFields(profileData, errors) {

        if (validators.checkIfEmpty(profileData.firstName)) {
            errors.firstNameReqError = true;
        } else {
            if (profileData.firstName.length > 50) {
                errors.firstNameLenError = true;
            }
        }

        if (validators.checkIfEmpty(profileData.lastName)) {
            errors.lastNameReqError = true;
        } else {
            if (profileData.lastName.length > 50) {
                errors.lastNameLenError = true;
            }
        }

        if (!validators.checkIfEmpty(profileData.middleName) && profileData.middleName.length > 50) {
            errors.middleNameLenError = true;
        }

    }

    function trimName(name) {
        if (name) {
            return name.trim().replace(/\s+/g, ' ');
        } else {
            return '';
        }
    }

})();
