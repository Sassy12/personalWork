/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 *
 */
'use strict';
angular.module('indexApp').service('ResetPasswordService',['$http', ResetPasswordService]);

function ResetPasswordService($http){

		this.getUsernameFromAuthCode = function(authCode){
			   var promise = $http.post('/tb/services/rest/commonController/getUsernameFromAuthCode', authCode);
			      promise.success(function(data) {
			    	  return data;
			      });
			      return promise;
		};

		this.submitForm =function(formData){
			return $http.post('/tb/services/rest/resetPassword/resetSecurityCredentials', formData);
		};
		
		this.resendEmailToUser = function(userInfo){
			return $http.post('/tb/services/rest/resetPassword/resendEmail', userInfo);
		};
		this.validateAuthCode = function(authCode){
            return $http.post('/tb/services/rest/resetPassword/validateAuthCode', authCode);
        };
}