-- SQL query to add SUB_EVENT_CODE to irm_audit_logs table
ALTER TABLE irm_audit_logs ADD SUB_EVENT_CODE varchar2(50);

-- Authorization Code sent to User - E3_CREATE and E3_CREATE_AUTH_CODE
select count(*) from irm_audit_logs where message like '%Authorization Code sent to User%';
update irm_audit_logs set EVENT_CODE='E3_CREATE', SUB_EVENT_CODE='E3_CREATE_AUTH_CODE' where message like '%Authorization Code sent to User%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_CREATE' and SUB_EVENT_CODE='E3_CREATE_AUTH_CODE';

-- Security Audit Event|TerminateUserSession:SUCCESS | User session TERMINATED, LoginBean:signOut() - E1_TERMINATE
select count(*) from irm_audit_logs where message like '%Security Audit Event|TerminateUserSession:SUCCESS | User session TERMINATED, LoginBean:signOut()%';
update irm_audit_logs set EVENT_CODE='E1_TERMINATE' where message like '%Security Audit Event|TerminateUserSession:SUCCESS | User session TERMINATED, LoginBean:signOut()%';
select count(*) from irm_audit_logs where EVENT_CODE='E1_TERMINATE';

-- Security Audit Event|ModifyUserEmail:SUCCESS | User secondary email add , AccountSupportBean:next() - E3_CREATE and	E3_CREATE_EMAIL
select count(*) from irm_audit_logs where message like '%Security Audit Event|ModifyUserEmail:SUCCESS | User secondary email add , AccountSupportBean:next()%';
update irm_audit_logs set EVENT_CODE='E3_CREATE', SUB_EVENT_CODE='E3_CREATE_EMAIL' where message like '%Security Audit Event|ModifyUserEmail:SUCCESS | User secondary email add , AccountSupportBean:next()%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_CREATE' and SUB_EVENT_CODE='E3_CREATE_EMAIL';

-- Confirmation code email resent or sent - E3_CREATE, E3_CREATE_EMAIL_CODE
select count(*) from irm_audit_logs where REGEXP_LIKE (message, 'Confirmation code email (resent|sent)');
update irm_audit_logs set EVENT_CODE='E3_CREATE', SUB_EVENT_CODE='E3_CREATE_EMAIL_CODE' where REGEXP_LIKE (message, 'Confirmation code email (resent|sent)');
select count(*) from irm_audit_logs where EVENT_CODE='E3_CREATE' and SUB_EVENT_CODE='E3_CREATE_EMAIL_CODE';


-- User Registration - E3_CREATE, E3_CREATE_USER
select count(*) from irm_audit_logs where message like '%RegisterUser:SUCCESS | User Registered%';
update irm_audit_logs set EVENT_CODE='E3_CREATE', SUB_EVENT_CODE='E3_CREATE_USER' where message like '%RegisterUser:SUCCESS | User Registered%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_CREATE' and SUB_EVENT_CODE='E3_CREATE_USER';

-- Delete Secondary Email from Admin Application - E3_DELETE, E3_DELETE_EMAIL
select count(*) from irm_audit_logs where message like '%ModifyUserEmail:SUCCESS | User secondary email delete%';
update irm_audit_logs set EVENT_CODE='E3_DELETE', SUB_EVENT_CODE='E3_DELETE_EMAIL' where message like '%ModifyUserEmail:SUCCESS | User secondary email delete%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_DELETE' and SUB_EVENT_CODE='E3_DELETE_EMAIL';

-- Delete User from Admin Application - E3_DELETE, E3_DELETE_USER
select count(*) from irm_audit_logs where message like '%RemoveUserAccount:SUCCESS | User account removed%';
update irm_audit_logs set EVENT_CODE='E3_DELETE', SUB_EVENT_CODE='E3_DELETE_USER' where message like '%RemoveUserAccount:SUCCESS | User account removed%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_DELETE' and SUB_EVENT_CODE='E3_DELETE_USER';

-- LDAP Lock - E3_DISABLE, E3_DISABLE_LDAP
select count(*) from irm_audit_logs where message like '%User session denied | Account Disabled%';
update irm_audit_logs set EVENT_CODE='E3_DISABLE', SUB_EVENT_CODE='E3_DISABLE_LDAP' where message like '%User session denied | Account Disabled%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_DISABLE' and SUB_EVENT_CODE='E3_DISABLE_LDAP';

-- RSA Lock - E3_DISABLE, E3_DISABLE_RSA
select count(*) from irm_audit_logs where message like '%User session denied | Account Suspended%';
update irm_audit_logs set EVENT_CODE='E3_DISABLE', SUB_EVENT_CODE='E3_DISABLE_RSA' where message like '%User session denied | Account Suspended%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_DISABLE' and SUB_EVENT_CODE='E3_DISABLE_RSA';

-- Modify Security Questions - E3_MODIFY, E3_MODIFY_SECURITY_QUESTIONS
select count(*) from irm_audit_logs where message like '%ModifyUserSecurityQuestions:SUCCESS | User Security Questions Modified%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_SECURITY_QUESTIONS' where message like '%ModifyUserSecurityQuestions:SUCCESS | User Security Questions Modified%';
select count(*) from irm_audit_logs where message like '%setSecurityQuestions:SUCCESS|Authorization Code Processed%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_SECURITY_QUESTIONS' where message like '%setSecurityQuestions:SUCCESS|Authorization Code Processed%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_MODIFY' and SUB_EVENT_CODE='E3_MODIFY_SECURITY_QUESTIONS';

-- Modify Profile - E3_MODIFY, E3_MODIFY_PROFILE
select count(*) from irm_audit_logs where message like '%ModifyUserProfile:SUCCESS | User Profile Modified%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_PROFILE' where message like '%ModifyUserProfile:SUCCESS | User Profile Modified%';
select count(*) from irm_audit_logs where message like '%ResetSecuirty Credentials :SUCCESS|Authorization Code Processed%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_PROFILE' where message like '%ResetSecuirty Credentials :SUCCESS|Authorization Code Processed%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_MODIFY' and SUB_EVENT_CODE='E3_MODIFY_PROFILE';

-- Modify Password - E3_MODIFY, E3_MODIFY_PASSWORD
select count(*) from irm_audit_logs where message like '%ModifyUserPassword:SUCCESS | User Account Password Modified%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_PASSWORD' where message like '%ModifyUserPassword:SUCCESS | User Account Password Modified%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_MODIFY' and SUB_EVENT_CODE='E3_MODIFY_PASSWORD';

-- Modify Email - E3_MODIFY, E3_MODIFY_EMAIL
select count(*) from irm_audit_logs where message like '%ConfirmationEmailUpdate:SUCCESS%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_EMAIL' where message like '%ConfirmationEmailUpdate:SUCCESS%';
select count(*) from irm_audit_logs where message like '%ProfileEmailUpdate:SUCCESS%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_EMAIL' where message like '%ProfileEmailUpdate:SUCCESS%';
select count(*) from irm_audit_logs where message like '%RegistrationEmailUpdate:SUCCESS%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_EMAIL' where message like '%RegistrationEmailUpdate:SUCCESS%';
select count(*) from irm_audit_logs where message like '%ModifyUserEmail:SUCCESS | User primary email modify%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_EMAIL' where message like '%ModifyUserEmail:SUCCESS | User primary email modify%';
select count(*) from irm_audit_logs where message like '%ModifyUserEmail:SUCCESS | User secondary email modify%';
update irm_audit_logs set EVENT_CODE='E3_MODIFY', SUB_EVENT_CODE='E3_MODIFY_EMAIL' where message like '%ModifyUserEmail:SUCCESS | User secondary email modify%';
select count(*) from irm_audit_logs where EVENT_CODE='E3_MODIFY' and SUB_EVENT_CODE='E3_MODIFY_EMAIL';

-- Invalid Username Password - Updating the Event_Code from E1_CREATE to E4
select count(*) from irm_audit_logs where message like '%User session denied | Incorrect username or password specified%';
update irm_audit_logs set EVENT_CODE='E4' where message like '%User session denied | Incorrect username or password specified%';
select count(*) from irm_audit_logs where EVENT_CODE='E4';

-- Updating events for Identify Proofing audits - Updating the Event_Code from E1_CREATE to E7_INVOKE
select count(*) from irm_audit_logs where message like '%identity proofing process%';
update irm_audit_logs set event_code='E7_INVOKE' where message like '%identity proofing process%';
select count(*) from irm_audit_logs where message like '%identity proffing process%';
update irm_audit_logs set event_code='E7_INVOKE' where message like '%identity proffing process%';
select count(*) from irm_audit_logs where event_code='E7_INVOKE';