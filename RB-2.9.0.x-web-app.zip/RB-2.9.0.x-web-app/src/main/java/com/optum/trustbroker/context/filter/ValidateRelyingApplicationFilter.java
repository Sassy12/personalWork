package com.optum.trustbroker.context.filter;

import java.io.IOException;
import java.net.URISyntaxException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.service.RelyingPartyAppService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.uhg.iam.alps.common.crypto.CryptAgent;

/**
 * A filter that validates the relying party application domain.
 *
 * @author Sachin Kumar
 * @version 1.0
 */
public class ValidateRelyingApplicationFilter implements Filter {

    private static final BaseLogger logger = new BaseLogger(ValidateRelyingApplicationFilter.class);

    public static final String OID_COOKIE = "oid_data";

    public static final String X_FRAME_OPTIONS = "X-FRAME-OPTIONS";

    private static final String ERROR_INVALID_RP_ID = "invalidRPappId";
    private static final String ERROR_INVALID_RP_DOMAIN = "invalidRPappDomain";
    private static final String ERROR_URL = "/tb/app/index.html#/genErrorPage?errorCode=";

    private CryptAgent cryptAgent;

    private ApplicationContext applicationContext;

    private RelyingPartyAppService relyingPartyAppService;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.applicationContext = WebApplicationContextUtils
                .getRequiredWebApplicationContext(filterConfig.getServletContext());
        cryptAgent = (CryptAgent) this.applicationContext.getBean("cryptAgent");
        relyingPartyAppService = (RelyingPartyAppService) this.applicationContext.getBean("relyingPartyAppService");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        try {
            HttpServletResponse res = (HttpServletResponse) response;
            HttpServletRequest req = (HttpServletRequest) request;

            boolean encryptInd = req.getParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true : false;
            String target = getRequestParam(req, TrustBrokerWebAppConstants.TARGET, encryptInd);
            String rpAppId = getRequestParam(req, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, encryptInd);

            if (StringUtils.isNotBlank(target) && StringUtils.isNotBlank(rpAppId)) {
                target = clearSMEncodingOnTargetIfAvalable(target);
                String errorCode = checkRelyingPartyDetails(rpAppId, target);
                if (errorCode == null) {
                    res.addHeader(X_FRAME_OPTIONS, "ALLOW-FROM " + TBUtil.getURIWithPort(target));
                } else {
                    WebApplicationContextHolder.clearContext();
                    deleteSessionStateCookie((HttpServletRequest) request, (HttpServletResponse) response);
                    String redirectURL = ERROR_URL + errorCode;
                    res.sendRedirect(redirectURL);
                    return;
                }
            } else {
                res.addHeader(X_FRAME_OPTIONS, "SAMEORIGIN");
            }

            chain.doFilter(request, response);
        } catch (Exception ex) {
            logger.error(
                    "Validate Relying Appliction filter | Error while applying filter chaining and setting X-FRAME-OPTIONS",
                    ex);
        }
    }

    /**
     * Check if relying party target has a trusted domain with OptumID
     *
     * @param relyingAppId - Relying party identifier
     * @param targetURL - target URL
     * @return
     */
    private String checkRelyingPartyDetails(String relyingAppId, String targetURL) {

        String errorCode = null;
        RelyingPartyAppVO relyingPartyAppVO = relyingPartyAppService.fetchRelyingPartyAppByAppId(relyingAppId);

        if (relyingPartyAppVO == null || TrustBrokerConstants.ACTIVE_STATUS != relyingPartyAppVO.getStatusId()) {
            errorCode = ERROR_INVALID_RP_ID;
        } else {
            if (CollectionUtils.isNotEmpty(relyingPartyAppVO.getRpAppDomains())) {
                boolean domainValid = false;
                String rpDomainName = null;
                try {
                    rpDomainName = TBUtil.getDomainName(targetURL);
                    domainValid = TBUtil.isDomainValid(relyingPartyAppVO.getRpAppDomains(), rpDomainName);
                } catch (URISyntaxException ex) {
                    //Eat up the exception
                    domainValid = false;
                    logger.error("URL decoding error during domain validation.", ex);
                }

                if(!domainValid){
                    errorCode = ERROR_INVALID_RP_DOMAIN;
                }
            } else {
                errorCode = ERROR_INVALID_RP_DOMAIN;
            }
        }

        return errorCode;
    }

    /**
     * Get the request parameters value and decrypt if it has an encrypted parameter flag.
     * @param req
     * @param name
     * @param decryptReqd
     * @return
     */
    private String getRequestParam(HttpServletRequest req, String name, boolean decryptReqd) {

        String paramValue = req.getParameter(name);

        if (decryptReqd && cryptAgent != null) {
            paramValue = cryptAgent.decrypt(paramValue);
        }

        return paramValue;
    }

    /**
     * Clear the SM encoding characters from target before validating domain.
     * @param target parameter
     * @return
     */
    private String clearSMEncodingOnTargetIfAvalable(String target) {
        String targetParam = target;
        targetParam = targetParam.replace("-SM-", "");
        targetParam = targetParam.replace("$SM$", "");
        targetParam = targetParam.replace("--", "-");
        targetParam = targetParam.replace("-:", ":");
        targetParam = targetParam.replace("-/", "/");

        return targetParam;
    }

    /**
     * Delete the session state cookie.
     * @param request
     * @param response
     */
    protected void deleteSessionStateCookie(HttpServletRequest request, HttpServletResponse response) {
        String host = request.getServerName();
        String domain = host.indexOf(".") >= 0 ? host.substring(host.indexOf(".")) : host;

        Cookie cookies[] = request.getCookies();
        Cookie cookie = null;
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                if (OID_COOKIE.equals(cookies[i].getName())) {
                    cookie = cookies[i];
                    break;
                }
            }
        }

        if (cookie != null) {
            cookie.setDomain(domain);
            cookie.setMaxAge(0);
            cookie.setPath("/");
            response.addCookie(cookie);
        }
    }

    @Override
    public void destroy() {}

}
