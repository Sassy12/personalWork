package com.optum.trustbroker.controller.vo;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class ResponseVO implements Serializable {

	private String status;
	private String responseCode;
	private ErrorResponseVO errorResponse;
	private Map<String,String> errorMap;
	private Map<String,String> notificationMap;
	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public ErrorResponseVO getErrorResponse() {
		return errorResponse;
	}
	public void setErrorResponse(ErrorResponseVO errorResponse) {
		this.errorResponse = errorResponse;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Map<String, String> getErrorMap() {
		if (errorMap == null) {
			errorMap = new HashMap<String, String>();
		}
		return errorMap;
	}
	public void setErrorMap(Map<String, String> errorMap) {
		this.errorMap = errorMap;
	}
	public Map<String, String> getNotificationMap() {
		if (notificationMap == null) {
			notificationMap = new HashMap<String, String>();
		}
		return notificationMap;
	}
	public void setNotificationMap(Map<String, String> notificationMap) {
		this.notificationMap = notificationMap;
	}
	
	
	public void addErrorMessage(String key, String value) {
		if (errorMap == null) {
			errorMap = new HashMap<String, String>();
		}
		errorMap.put(key, value);
	}

	public void addNotificationMessage(String key, String value) {
		if (notificationMap == null) {
			notificationMap = new HashMap<String, String>();
		}
		notificationMap.put(key, value);
	}
	
}
