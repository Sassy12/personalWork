/*
 * Copyright (C) 2012 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.context;

/**
 * Represents a strategy for holding the current
 * web service  context.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
public interface WebApplicationContextHolderStrategy {
    /**
     * Returns the current context.
     *
     * @return The current context.
     */
    public WebApplicationContext getContext();

    /**
     * Clears the current context.
     */
    public void clearContext();

    /**
     * Stores the specified context using the
     * strategy represented by this instance.
     *
     * @param context The context being stored.
     */
    public void setContext(WebApplicationContext context);
}
