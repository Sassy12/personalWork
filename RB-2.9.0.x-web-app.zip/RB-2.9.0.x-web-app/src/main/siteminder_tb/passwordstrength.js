
 var charLenght;
 var upperCase;
 var lowerCase;
 var numeric;
 
 function  getStrength(pwd, checks, username){
	  
	   var minLength=8;
	   var maxLength=100;
	   var upperPresent=false;
	   var lowerPresent=false;
	   var numberPresent=false;
	   var isEmpty=false;
	   var incorrectLength=false;
	   
	   if(!String.prototype.trim){  
	       pwd = strTrim(pwd);     
	   }else
	       pwd = pwd.trim();
	   
	   if(pwd =="")
	     isEmpty=true;
	   
	   var array = new Array(127);
	   for(i=0; i <=127; i++)
	     array[i]=0;
	  
	  
	   for(i=0;i<pwd.length;i++){
	    var a = pwd.charAt(i).charCodeAt(0);
	     if(a > -1 && a<= 126 ){ //non ascii actually not allowed
	        if(a>=65 && a<=90)
	            upperPresent = true;
	        else  if(a>=97 && a<=122)
	            lowerPresent=true;
	        else if(a>=48 && a<=57)
	            numberPresent =true;
	            
	        array[a] = array[a]+1;
	     }
	   }
	   
	  if (pwd.length < minLength){
	     incorrectLength=true;
	   }
	   
	   if (pwd.length > maxLength){
		     incorrectLength=true;
	   }
	  
	   checks[0] = incorrectLength;
	   checks[1] = lowerPresent;
	   checks[2] = upperPresent;
	   checks[3] = numberPresent;
	   checks[4] = isEmpty;
	   
	 };
 
	 var oldPassHtmlText;
	 
  function displayPasswordRules( pwdFieldId, popUpId, username){
      
    var fntSz="";
    if (navigator.appName == 'Microsoft Internet Explorer'){
       fntSz=" font-size: 12px;";

       if (isIE () && isIE () < 9)
    	   fntSz= "font-size: 10px; margin-top: -22px; width: 178px; !important";      
    }

    var popUp = document.getElementById(popUpId);
    var password =  document.getElementById(pwdFieldId).value;
    var checks = new Array(false,false,false,false,false,false,false,false,false,false,false);
    getStrength(password, checks, username);
    
    var htmlText = '<div class="oxnamevalidate" style="display: block;'+fntSz+'"><div style="border:1px solid black;border-radius: 11px;" > <ul role="presentation">';
    //var spanRuleFailText='<span class="met"></span>';
   // var spanRulePassText='<span class="not met"></span>';
    var spanRuleFailText='<img style="margin-top: -5px;vertical-align:middle;" src="white_icon.jpg" alt="" >';
    var spanRulePassText='<img style="margin-top: -5px;vertical-align:middle;" alt="" src="green_check_icon.jpg" >';

    var validTrue = '&#160;<span class="oui-a11y-hidden">&#160;met </span></span> ';
    var validFalse = '&#160;<span class="oui-a11y-hidden">&#160;not met </span></span> ';    
    var incorrectLength =  checks[0];
    var lowerPresent = checks[1];
    var upperPresent = checks[2];
    var numberPresent = checks[3];
    var isEmpty = checks[4];
   
    var validMsg0=validFalse;
    var validMsg1=validFalse;
    var validMsg2=validFalse;
    var validMsg3=validFalse; 	
    
    htmlText +='<li id="rule"><span class="ruletext">Your password must have: </span></li>';

    htmlText +='<li id="rule0" class="ux-pwd-rules-li">';
    htmlText += (incorrectLength) ? spanRuleFailText : spanRulePassText;
    if( !incorrectLength)
     validMsg0 = validTrue;
    if(password == ""){validMsg0="";}
    htmlText += '<span class="ruletext" style="margin-left: 7px;">8 characters or more </span>'+validMsg0+'</li>';
    
    htmlText +='<li id="rule1" class="ux-pwd-rules-li">'; 
    if( upperPresent)
     validMsg1 = validTrue;    
    htmlText += (!(upperPresent)) ? spanRuleFailText : spanRulePassText;
    if(password == ""){validMsg1="";}
    htmlText += '<span class="ruletext" style="margin-left: 7px;">One capital letter </span>'+validMsg1+'</li>';
    
    htmlText +='<li id="rule2" class="ux-pwd-rules-li">';
    if( lowerPresent)
     validMsg2 = validTrue;   
    htmlText += ((!lowerPresent)) ? spanRuleFailText : spanRulePassText; 
    if(password == ""){validMsg2="";}
    htmlText += '<span class="ruletext" style="margin-left: 7px;">One lowercase letter </span>'+validMsg2+'</li>';
    
    htmlText +='<li id="rule3" class="ux-pwd-rules-li">';
    if( numberPresent)
     validMsg3 = validTrue;
    htmlText += ((!numberPresent)) ? spanRuleFailText : spanRulePassText;
    if(password == ""){validMsg3="";}
    htmlText += '<span class="ruletext" style="margin-left: 7px;">One number </span>'+validMsg3+'</li>';
    
    popUp.style.display = 'block';
    
    if(oldPassHtmlText!=htmlText || !oldPassHtmlText ){
    	popUp.innerHTML = htmlText;
    	oldPassHtmlText=htmlText;
    }
 	
  }
  
  function hidePasswordRules( popUpId) {
	if(document.getElementById(popUpId).innerHTML != ""){
		 oldPassHtmlText = null;
		 document.getElementById(popUpId).innerHTML = "";
	}else
		setTimeout(function() {
			 oldPassHtmlText = null;
			 document.getElementById(popUpId).innerHTML = "";
		}, 200);
  }
  function strTrim(x) {
	    return x.replace(/^\s+|\s+$/gm,'');
  }

  function isIE () {
    var myNav = navigator.userAgent.toLowerCase();
    return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
  }