/*******************************************************************************
 * Copyright (c) 2012 Optum - All Rights Reserved.
 ******************************************************************************/
package com.optum.trustbroker.managebean.widget;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.ingenix.uitoolkit.pojos.AbsBackingBean;
import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.context.ApplicationContextHolder;
import com.optum.trustbroker.esso.sso.SsoContext;
import com.optum.trustbroker.esso.sso.SsoDestinationDeterminationStrategy;
import com.optum.trustbroker.esso.sso.utils.SsoUtils;
import com.optum.trustbroker.exceptions.ExceptionUtility;
import com.optum.trustbroker.managebean.ApplicationContainer;
import com.optum.trustbroker.managebean.RequestFilterTokenBean;
import com.optum.trustbroker.managebean.UserStepUpContext;
import com.optum.trustbroker.message.ErrorMessage;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.ExecutionStatus;
import com.optum.trustbroker.vo.InvitationServiceRequest;
import com.optum.trustbroker.vo.InvitationVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.StatusVO;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserAuthorizationRequest;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserTagServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.VerificationCodeRequest;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.common.Attribute;
import com.uhg.iam.alps.common.DefaultUser;
import com.uhg.iam.alps.common.User;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.alps.sso.SsoRequest;
import com.uhg.iam.esso.schemas.xsd._2013._12.AuthenticationType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

public abstract class AbstractBackingBean extends AbsBackingBean {

    protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");

    protected static final ResourceBundle verifyCodes = ResourceBundle.getBundle("verifyCodesResources");

    private static final BaseLogger LOGGER = new BaseLogger(AbstractBackingBean.class);

    @ManagedProperty("#{container}")
    protected ApplicationContainer container;
    
    @ManagedProperty("#{requestFilterTokenBean}")
	private RequestFilterTokenBean rtn;

    public final String COPPA_REQD_NO_IND = "N";

    public final String EMAIL_CONFM_REQD_NO_IND = "N";

    String sensitiveDataErrormsgpage = "/views/errorpagesensitivedata.jsf";

    public final String PWD_INVALID_SPL_CHAR = "&";

    protected boolean questionsRequired;

    protected boolean dobRequired;

    protected String alias;
    
    private String csrfToken;
    
    
    public ApplicationContainer getContainer() {
        return container;
    }

    public void setContainer(ApplicationContainer container) {
        this.container = container;
    }

    public UserVO getCurrentUserVO() {
        UserVO user = null;
        if (isSessionAttributeExists(TrustBrokerWebAppConstants.CURRENT_USER)) {
            user = (UserVO) getSessionAttribute(TrustBrokerWebAppConstants.CURRENT_USER);
        }
        return user;
    }

    public void setCurrentUserVO(UserVO currentUserVO) {
        if (null != currentUserVO) {
            addSessionAttribute(TrustBrokerWebAppConstants.CURRENT_USER, currentUserVO);
        }
    }

    public HttpServletRequest getServletRequest() {
        return (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
    }

    public HttpServletResponse getServletResponse() {
        return (HttpServletResponse) getFacesContext().getExternalContext().getResponse();
    }

    protected void setRpSuppParam(String rpAppId, String needsDecrypt) {
        if (needsDecrypt != null) {
            rpAppId = container.getCryptAgentUtil().doDecryption(rpAppId);
        }
        if (getSessionAttribute("SupportRPId") == null && rpAppId != null) {
            addSessionAttribute("SupportRPId", rpAppId);
        }
    }

    @Override
    public FacesContext getFacesContext() {
        if (FacesContext.getCurrentInstance() != null) {
            return FacesContext.getCurrentInstance();
        } else {
            if (super.getFacesContext() != null) {
                return super.getFacesContext();
            }
        }
        return super.getFacesContext();
    }

    public String getUrlLogoOptumId() {
        return constructURL("/images/lockup-product-name-lg.png");
    }

    public String getToolTipLogoOptumId() {
        return "Optum ID";
    }

    public RelyingPartyAppVO getRelyingPartyApp() {
        String rpAppId = getRelyingPartyAppId();
        if (rpAppId != null) {
            return container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpAppId);
        }
        return null;
    }

    public String getUrlLogoRelyingParty() {
        RelyingPartyAppVO rpApp = getRelyingPartyApp();
        if (rpApp != null && rpApp.getUploadedImageVO() != null && rpApp.getUploadedImageVO().getBytes() != null) {
            return constructURL("/dispimage?appID=" + rpApp.getApplicationId());
        }
        return null;
    }

    public String getToolTipLogoRelyingParty() {
        return "Optum ID";
    }

    public boolean isSessionAttributeExists(String attributeName) {
        return getSessionMap().containsKey(attributeName);
    }

    public boolean isRequestParamExists(String paramName) {
        return StringUtils.isNotBlank(getRequestParameter(paramName));
    }

    public Object getSessionAttribute(String attributeName) {
        Object attributeValue = null;
        if (getSessionMap().containsKey(attributeName) && getSessionMap().get(attributeName) != null
                && !"".equals(getSessionMap().get(attributeName))) {
            attributeValue = getSessionMap().get(attributeName);
        }

        // ================================================================================================
        // gtyagi1: PHEW! another hack just because Relying Party APP ID is fetched from 
        // so many places so really can't elegantly counter it, for now just put an ugly check
        // here! Why are we dumping everything to session like that? for obtaining relying
        // party APP URL, we at minimum had one method in this base class where we changed
        if (attributeValue == null && StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.RELYING_APP_ID, attributeName)
                && SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
            try {
                attributeValue = ApplicationContextHolder.getContext().retrieve(SsoContext.class).getDestinationApp();
                LOGGER.debug("Loaded RP ID '{}' from '{}'", new Object[] {
                        attributeValue != null ? attributeValue.toString() : null, SsoContext.class.getSimpleName()});
            } catch (Exception ex) {
                LOGGER.error("Failed to obtain RP ID from SSO broker request", ex);
            }
        } else if (attributeValue == null
                && StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.RELYING_APP_URL, attributeName)
                && SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
            try {
                attributeValue = ApplicationContextHolder.getContext().retrieve(SsoContext.class).getTargetDestinationUrl();
                LOGGER.debug("Loaded final destination URL '{}' from '{}'", new Object[] {
                        attributeValue != null ? attributeValue.toString() : null, SsoContext.class.getSimpleName()});
            } catch (Exception ex) {
                LOGGER.error("Failed to obtain target final destination url for SSO broker request", ex);
            }
        } else if (attributeValue == null
                && StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, attributeName)
                && SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
            try {
                attributeValue = ApplicationContextHolder.getContext()
                        .retrieve(SsoDestinationDeterminationStrategy.APPLICATION_CONTEXT_SSO_DESTINATION_RP_KEY,
                                RelyingPartyAppVO.class)
                        .getAlias();
                LOGGER.debug("Loaded {} as - '{}' from '{}'",
                        new Object[] {TrustBrokerWebAppConstants.RELYING_APP_ALIAS,
                                attributeValue != null ? attributeValue.toString() : null,
                                SsoContext.class.getSimpleName()});
            } catch (Exception ex) {
                LOGGER.error("Failed to obtain target final destination url for SSO broker request", ex);
            }
        }
        // ================================================================================================

        return attributeValue;
    }

    public void addSessionAttribute(String attributeName, Object attributeValue) {
        getSessionMap().put(attributeName, attributeValue);
    }

    public void removeSessionAttribute(String attributeName) {

        getSessionMap().remove(attributeName);
    }

    public void clearSessionAttributes(String[] attributes) {

        for (String attributeName : attributes) {
            removeSessionAttribute(attributeName);
        }
    }

    public String getRequestParameter(String attributeName) {
        String attributeValue = getServletRequest().getParameter(attributeName);
        return StringUtils.isNotBlank(attributeValue) ? attributeValue : null;
    }

    public String getRequestParameterCaseInsensitive(String attributeName) {
        String attributeValue = getRequestParameter(attributeName);
        if (attributeValue == null) {
            attributeValue = getRequestParameter(StringUtils.upperCase(attributeName));
        }
        return attributeValue;
    }

    public void addRelyingPartyRequestParam(String paramName, String mappingName, Boolean decryptionRequired) {
        String attributeValue = getRequestParameter(paramName);
        if (attributeValue != null)
            addSessionAttribute(mappingName, attributeValue);
    }

    public void addRelyingPartyAlias(String relyingAppId) {
        if (StringUtils.isEmpty(relyingAppId))
            return;
        RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService()
                .fetchRelyingPartyAppByAppId(relyingAppId);
        if (relyingPartyAppVO != null)
            addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());

    }

    public void captureRelyingPartyInfo(Boolean decryptionRequired) {
        //Moved the capturing relying party info logic over here so that decryption can be performed at one single place.
        String relyingPartyTargetURL = getRequestParameter(TrustBrokerWebAppConstants.TARGET);
        if (relyingPartyTargetURL != null && decryptionRequired) {
            relyingPartyTargetURL = container.getCryptAgentUtil().doDecryption(relyingPartyTargetURL);
        }

        if (relyingPartyTargetURL != null) {
            //relyingPartyTargetURL = removeSMDataFromURL(relyingPartyTargetURL);
            addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL, relyingPartyTargetURL);
            LOGGER.debug(
                    "AbstractBackingBean:postConstruct | Capturing relying party target url information | Relying party URL ='"
                            + relyingPartyTargetURL + "'");
        }

        if (isRequestParamExists(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM)) {
            String relyingAppId = getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);

            if (decryptionRequired) {
                relyingAppId = container.getCryptAgentUtil().doDecryption(relyingAppId);
                if (relyingAppId != null) {
                    addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, relyingAppId);
                }
            } else {
                addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, relyingAppId);
            }

            RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService()
                    .fetchRelyingPartyAppByAppId(relyingAppId);
            if (relyingPartyAppVO != null) {
                addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
            }
            LOGGER.debug(
                    "AbstractBackingBean:postConstruct | Capturing relying party app id information | Relying party ID ='"
                            + relyingAppId + "'");
        }

        if (isRequestParamExists(TrustBrokerWebAppConstants.FIRST_NAME_PARAM)) {
            String firstName = getRequestParameter(TrustBrokerWebAppConstants.FIRST_NAME_PARAM);
            if (decryptionRequired) {
                firstName = container.getCryptAgentUtil().doDecryption(firstName);
                if (firstName != null)
                    addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM, firstName);
            } else {
                addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM, firstName);
            }
        }

        if (isRequestParamExists(TrustBrokerWebAppConstants.LAST_NAME_PARAM)) {
            String lastName = getRequestParameter(TrustBrokerWebAppConstants.LAST_NAME_PARAM);
            if (decryptionRequired) {
                lastName = container.getCryptAgentUtil().doDecryption(lastName);
                if (lastName != null) {
                    addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM, lastName);
                }
            } else {
                addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM, lastName);
            }
        }

        String email = getRequestParameter(TrustBrokerWebAppConstants.EMAIL_PARAM);
        if (StringUtils.isNotBlank(email)) {
            if (decryptionRequired) {
                email = container.getCryptAgentUtil().doDecryption(email);
                if (email != null) {
                    addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL, email);
                }
            } else {
                addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL, email);
            }
        }
        // jchowda:Changes related to pre verify email address from RP by on demand bases.
        String userdetailMapString = getRequestParameter(TrustBrokerWebAppConstants.USER_DETAIL);
        if (StringUtils.isNotBlank(userdetailMapString)) {
            if (decryptionRequired) {
                Map<String, String> userDetailsMap = container.getCryptAgentUtil().getCryptAgent()
                        .getAttributesFromToken(userdetailMapString, true);
                if (MapUtils.isNotEmpty(userDetailsMap)) {
                    if (StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.PRE_VERIFY_KEY))
                            && StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.EMAIL_PARAM))) {
                        addSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL,
                                userDetailsMap.get(TrustBrokerWebAppConstants.EMAIL_PARAM));
                    }
                    if (StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.FIRST_NAME_PARAM))) {
                        addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM,
                                userDetailsMap.get(TrustBrokerWebAppConstants.FIRST_NAME_PARAM));
                    }
                    if (StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.LAST_NAME_PARAM))) {
                        addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM,
                                userDetailsMap.get(TrustBrokerWebAppConstants.LAST_NAME_PARAM));
                    }
                    if (StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.EMAIL_PARAM))) {
                        addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL,
                                userDetailsMap.get(TrustBrokerWebAppConstants.EMAIL_PARAM));
                    }
                }
            } else {
                redirectToView(sensitiveDataErrormsgpage);
            }
        } else {
            removeSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL);
        }
        //End  jchowda.		
        String inbs = getRequestParameter(TrustBrokerWebAppConstants.INBOUND_SSO);
        if (inbs != null && (decryptionRequired
                ? container.getCryptAgentUtil().doDecryption(inbs).equalsIgnoreCase(TrustBrokerConstants.STATUS_YES)
                : inbs.equalsIgnoreCase(TrustBrokerConstants.STATUS_YES))) {

            if (email != null) {
                addSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO, email);
            } else {
                addSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO, email);
            }
        }
        if (getRequestParameter(TrustBrokerWebAppConstants.ACTION) != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.ACTION, getRequestParameter(TrustBrokerWebAppConstants.ACTION));
        }

        if (getRequestParameter(TrustBrokerWebAppConstants.STATUS) != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.STATUS, getRequestParameter(TrustBrokerWebAppConstants.STATUS));
        }

        if (getRequestParameter(TrustBrokerWebAppConstants.INVITATION_CODE) != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE,
                    getRequestParameter(TrustBrokerWebAppConstants.INVITATION_CODE));
        }
        if (getRequestParameter(TrustBrokerWebAppConstants.EMAIL_MODOFIED) != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.EMAIL_MODOFIED,
                    getRequestParameter(TrustBrokerWebAppConstants.EMAIL_MODOFIED));
        }
    }

    protected String removeSMDataFromURL(String relyingPartyTargetURL) {
        relyingPartyTargetURL = relyingPartyTargetURL.replace("-SM-", "");
        relyingPartyTargetURL = relyingPartyTargetURL.replace("$SM$", "");
        relyingPartyTargetURL = relyingPartyTargetURL.replace("--", "-");
        relyingPartyTargetURL = relyingPartyTargetURL.replace("-:", ":");
        relyingPartyTargetURL = relyingPartyTargetURL.replace("-/", "/");

        return relyingPartyTargetURL;
    }

    /**
     * This method redirects to relying party application.
     * 
     * @param targetUrl target where need to redirect the application.
     * @param action if there was any specified action performed before redirection. 
     * @param status status of the action (success/failure).
     * @param rpAppIdentifier relying party application identifier.
     * @return
     */
    public String redirectToRelyingParty(String targetUrl, String action, String status, String rpAppIdentifier) {
        String relyingPartySuccessUrl = targetUrl;

        if (action != null) {
            targetUrl = targetUrl.contains("?") ? targetUrl + "&" : targetUrl + "?";
            relyingPartySuccessUrl = targetUrl + TrustBrokerWebAppConstants.ACTION + "=" + action + "&"
                    + TrustBrokerWebAppConstants.STATUS + "="
                    + (status != null ? status : TrustBrokerWebAppConstants.CANCEL);
        }

        LOGGER.debug(
                "AbstractBackingBean:redirectToRelyingParty() | Initiating redirection process for relying party: {} and user: {}",
                new String[] {rpAppIdentifier, getCurrentUserVO().getUserName()});

        String partnerId = null;
        try {
            if (StringUtils.isNotEmpty(rpAppIdentifier)) {
                partnerId = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpAppIdentifier)
                        .getPartnerId();
            }
            redirection(relyingPartySuccessUrl, partnerId);
        } catch (Exception e) {
            LOGGER.error(
                    "AbstractBackingBean:redirectToRelyingParty() | Redirecting to relying party Failed | User Name={} "
                            + "Partner ID={} Target URL={}",
                    new String[] {getCurrentUserVO().getUserName(), partnerId, relyingPartySuccessUrl}, e);
        }

        return null;
    }

    /**
     * Redirect to relying party target URL with specified partner identifier.
     * @param url target URL where need to redirect.
     * @param partnerId partner identifier.
     */
    public boolean redirection(String url, String partnerId) {
        String userName = null;
        try {

            if (StringUtils.isEmpty(partnerId)) {
                LOGGER.error("AstractBackingBean:redirection | Redirection Failure | Partner ID is blank for target {}",
                        new String[] {url});
                return false;
            }

            HttpServletRequest httpServletRequest = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
            HttpServletResponse httpServletResponse = (HttpServletResponse) getFacesContext().getExternalContext()
                    .getResponse();
            SsoRequest ssoRequest = new SsoRequest(httpServletRequest, httpServletResponse);
            userName = getCurrentUserVO().getUserName();
            User user = new DefaultUser(userName); // Always set User's userName
            ssoRequest.setUser(user);
            ssoRequest.setDestinationUrl(url);

            // ==================================================================================================================
            // gtyagi1: 2/4/2014 - START: introduce a little check for SSO Broker requests and relay 
            // ==================================================================================================================			
            if (SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
                SsoContext ssoCtx = ApplicationContextHolder.getContext().retrieve(SsoContext.class); // null-safe since we just figured its a SSO broker request
                Set<Attribute> ssoAttrs = ssoCtx.getOutboundRelayedSsoAttributes();
                if (CollectionUtils.isNotEmpty(ssoAttrs)) {
                    LOGGER.debug("Setting Attributes for SSO to: {}, attributes size: {}",
                            new Object[] {partnerId, ssoAttrs.size()});
                    ssoRequest.getUser().setAttributes(ssoAttrs);
                }
            }
            // ==================================================================================================================
            // gtyagi1: 2/4/2014 - FINISH: introduce a little check for SSO Broker requests and relay 
            // ==================================================================================================================	
            removeSessionData();
            LOGGER.debug("AbstractBackingBean:redirection() | Redirecting to relying party with partner id={} and url {} "
                    + "for user = {}", new String[] {partnerId, url, userName});

            container.providerDelegatingSsoService.doSso(partnerId, ssoRequest);
            getFacesContext().responseComplete();
        } catch (Exception e) {
            ErrorMessage msg = TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00E002);
            LOGGER.error(
                    "AstractBackingBean:redirection | Redirection method Exception in alps sdk redirection for user {} - {}",
                    new String[] {userName, msg.getUid()}, e);
            handleInvalidSession(msg, e);
            return false;
        }
        return true;
    }

    /**
     * This method redirects to relying party without performing SSO operation.
     * 
     * @param targetUrl target where need to redirect the application.
     * @param action if there was any specified action performed before redirection. 
     * @param status status of the action (success/failure).
     * @param rpAppIdentifier relying party application identifier.
     */
    public void redirectionNonSso(String targetUrl, String action, String status, String rpId) {
        String relyingPartySuccessUrl = targetUrl;

        if (action != null && status != null) {
            targetUrl = targetUrl.contains("?") ? targetUrl + "&" : targetUrl + "?";

            relyingPartySuccessUrl = targetUrl + TrustBrokerWebAppConstants.ACTION + "=" + action + "&"
                    + TrustBrokerWebAppConstants.STATUS + "=" + status;
        }

        HttpServletResponse httpServletResponse = (HttpServletResponse) getFacesContext().getExternalContext().getResponse();
        container.getRedirectingHttpResponseExecutorImpl().handle(relyingPartySuccessUrl, null, httpServletResponse);
    }

    /**
     * Checks if there is any active SM session using session cookie.
     * @return active session flag.
     */
    protected boolean isActiveSMSession() {

        Cookie cookies[] = getServletRequest().getCookies();
        String smsession = "";

        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_SESSION)) {
                    smsession = cookies[i].getValue();
                    LOGGER.debug("LoginBean::SMSESSION", smsession);
                    break;
                }
            }
        }

        return (StringUtils.isNotBlank(smsession) && !"LOGGEDOFF".equals(smsession)) ? true : false;
    }

    protected UserTagServiceResponse addTagToUser(String uuid, String tagName, String idpVerificationCode) {
        UserTagServiceRequest request = buildUserTagServiceRequest(uuid, tagName);
        return container.getUserTagService().addUserTag(request, idpVerificationCode);
    }

    protected void deleteCookie(Cookie cookie) {
        HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
        HttpServletResponse response = (HttpServletResponse) getFacesContext().getExternalContext().getResponse();

        try {
            String host = request.getServerName();
            String domain = host.substring(host.indexOf("."));
            cookie.setPath("/");
            cookie.setDomain(domain);
            LOGGER.debug("AbstractBackingBean:deleteCookie() | Host = {}, Cookie={}, Path={}",
                    new String[] {host, cookie.toString(), cookie.getPath()});
        } catch (Exception ex) {
            //Eat up this exception.
        }

        cookie.setMaxAge(0);
        response.addCookie(cookie);
    }

    protected UserAuthorizationRequest generateAuthorizationRequest(UserVO userVO) {
        UserAuthorizationRequest userAuthorizationRequest = new UserAuthorizationRequest();
        userAuthorizationRequest.setUser(userVO);
        HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
        String resetAccountURL = TBUtil.generateContextPath(request) + "/views/resetaccount.jsf";
        if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null
                && getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null) {
            String url = "?" + TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM + "="
                    + getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) + "&"
                    + TrustBrokerWebAppConstants.TARGET + "="
                    + getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) + "&authCode=";
            resetAccountURL += url;
        } else {
            resetAccountURL += "?authCode=";
        }
        userAuthorizationRequest.setResetAccountLink(resetAccountURL);
        return userAuthorizationRequest;
    }

    public boolean isEmailConfirmationRequired() {
        boolean status = true;

        /*try{
        	SystemParameterVO sysParamVO = container.getReferenceService().fetchSystemParameter(TrustBrokerWebAppConstants.EMAIL_CONFIRMATION_REQUIRED);
        	if(sysParamVO != null && !TrustBrokerWebAppConstants.YES.equalsIgnoreCase(sysParamVO.getSystemParameterValue())){
        		status = false;
        	}
        }catch(OperationFailedException opEx){
        	logger.error("AstractBackingBean:isEmailConfirmationRequired | Error while fetching email confirmation system parameter values", opEx);
        }*/
        String rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
        if (rpAppId != null) {
            RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpAppId);
            if (relyingPartyAppVO != null
                    && EMAIL_CONFM_REQD_NO_IND.equalsIgnoreCase(relyingPartyAppVO.getEmailconfirmreqd())) {
                status = false;
            }
        }
        return status;
    }

    public void addMessageToFlash(String key, String message) {
        getFacesContext().getExternalContext().getFlash().put(key, message);
    }

    public boolean isSessionContainsRelyingPartyInfo() {
        return ((getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null
                && getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null)
                || (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null
                        && getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF) != null));
    }

    public boolean isParamContainsRelyingPartyInfo() {
        return ((getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null
                && getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) != null));
    }

    public String getRelyingPartyRedirectionParameters() {
        String relyintPartyRedirectionURL = null;
        String relyingPartyId = null;
        String relyingPartyTargetURL = null;
        String invitationToken = null;
        if (isSessionContainsRelyingPartyInfo()) {
            relyingPartyId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
            relyingPartyTargetURL = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null
                    ? (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL)
                    : (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);

            if (relyingPartyTargetURL.contains(TrustBrokerWebAppConstants.INVITATION_CODE)) {
                invitationToken = relyingPartyTargetURL.substring(relyingPartyTargetURL.indexOf("=") + 1);
                relyingPartyTargetURL = relyingPartyTargetURL.substring(0, relyingPartyTargetURL.indexOf("?"));
            }

            if (getSessionAttribute(TrustBrokerWebAppConstants.ACTION) != null) {
                relyingPartyTargetURL = relyingPartyTargetURL + "&" + TrustBrokerWebAppConstants.ACTION + "="
                        + getSessionAttribute(TrustBrokerWebAppConstants.ACTION) + "&" + TrustBrokerWebAppConstants.STATUS
                        + "="
                        + (getSessionAttribute(TrustBrokerWebAppConstants.STATUS) != null
                                ? getSessionAttribute(TrustBrokerWebAppConstants.STATUS)
                                : TrustBrokerWebAppConstants.CANCEL);
            }

            relyintPartyRedirectionURL = TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM + "=" + relyingPartyId + "&"
                    + TrustBrokerWebAppConstants.TARGET + "=" + relyingPartyTargetURL;
            relyintPartyRedirectionURL = invitationToken != null
                    ? (relyintPartyRedirectionURL + "&" + TrustBrokerWebAppConstants.INVITATION_CODE + "=" + invitationToken)
                    : relyintPartyRedirectionURL;
        }

        return relyintPartyRedirectionURL;
    }

    protected String getRelyingPartyRedirectionURL(boolean... addInvitationCode) {
        String relyintPartyRedirectionURL = null;

        relyintPartyRedirectionURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
        if (null == relyintPartyRedirectionURL)
            relyintPartyRedirectionURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);

        // ==================================================================================================================
        // gtyagi1: no elegant way to set this explicitly since everything is being dumped to session directly now
        // by current application, just put a little fallback and check for SSO operation
        if (StringUtils.isBlank(relyintPartyRedirectionURL)
                && SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
            try {
                relyintPartyRedirectionURL = ApplicationContextHolder.getContext().retrieve(SsoContext.class)
                        .getTargetDestinationUrl();
                LOGGER.debug("Loaded final destination URL '{}' from '{}'",
                        new Object[] {relyintPartyRedirectionURL, SsoContext.class.getSimpleName()});
            } catch (Exception ex) {
                LOGGER.error("Failed to obtain target final destination url for SSO broker request", ex);
            }
        }
        // ==================================================================================================================		

        if (getSessionAttribute(TrustBrokerWebAppConstants.ACTION) != null) {
            relyintPartyRedirectionURL = HttpUtils.addParameterToURL(relyintPartyRedirectionURL,
                    TrustBrokerWebAppConstants.ACTION, (String) getSessionAttribute(TrustBrokerWebAppConstants.ACTION));
            relyintPartyRedirectionURL = HttpUtils.addParameterToURL(relyintPartyRedirectionURL,
                    TrustBrokerWebAppConstants.STATUS,
                    ((String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS) != null
                            ? (String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS)
                            : TrustBrokerWebAppConstants.CANCEL));
        }

        if (addInvitationCode != null && addInvitationCode.length > 0 && addInvitationCode[0]
                && getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE) != null) {
            relyintPartyRedirectionURL = HttpUtils.addParameterToURL(relyintPartyRedirectionURL,
                    TrustBrokerWebAppConstants.INVITATION_CODE,
                    (String) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE));
        }

        return relyintPartyRedirectionURL;
    }

    protected void removeSessionWithoutRelyingPartyInfo() {
        String rpTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
        String relyingPartyApplicationId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
        String action = (String) getSessionAttribute(TrustBrokerWebAppConstants.ACTION);
        String status = (String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS);
        String relyingPartyAlias = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS);
        String showRegistrationStr = (String) getSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP);
        String smTarget = (String) getSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET);
        String loginTarget = (String) getSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET);
        String CSRF_ID = (String) getSessionAttribute("CSRF_ID");
        getSessionMap().clear();
        
        if (CSRF_ID != null) {
            addSessionAttribute("CSRF_ID", CSRF_ID);
        }

        if (rpTargetURL != null && relyingPartyApplicationId != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL, rpTargetURL);
            addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, relyingPartyApplicationId);
            //Preserve session attributes as well.
            getServletRequest().getSession().setAttribute(TrustBrokerWebAppConstants.TARGET, rpTargetURL);
            getServletRequest().getSession().setAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM,
                    relyingPartyApplicationId);
        }

        if (action != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.ACTION, action);
        }
        if (status != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.STATUS, status);
        }
        if (smTarget != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET, smTarget);
        }
        if (relyingPartyAlias != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAlias);
        }
        if (showRegistrationStr != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP, showRegistrationStr);
        }
        if (loginTarget != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, loginTarget);
        }
    }

    public UserTagServiceRequest buildUserTagServiceRequest(String uuid, String tagName) {
        UserTagServiceRequest userTagServiceRequest = new UserTagServiceRequest();
        if (null != tagName)
            userTagServiceRequest.setTagName(tagName);
        UserVO userVO = new UserVO();
        userVO.setUuId(uuid);
        userTagServiceRequest.setUser(userVO);
        return userTagServiceRequest;
    }

    public String getErrorReasonCode(ExecutionStatus exStatus) {
        String errorReasonCD = "";

        if (exStatus.getStatusCodesList() != null) {
            for (String code : exStatus.getStatusCodesList()) {
                errorReasonCD += code + ",";
            }
        }
        if (errorReasonCD.length() > 0) {
            errorReasonCD = errorReasonCD.substring(0, errorReasonCD.length() - 1);
        }
        return errorReasonCD;
    }

    public boolean removeSessionData() {
        try {
            getServletRequest().getSession(false).invalidate();
        } catch (Exception ex) {
            LOGGER.error("AbstractBackingBean:removeSessionData() | Error while removing session data", ex);
            return false;
        }
        return true;
    }

    public SupportContactInfoVO getSupportContactInfo() {
        RelyingPartyAppVO rpApp = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(getRelyingPartyAppId());
        return TBUtil.getSupportContactInfo(rpApp);
    }

    protected void handleInvalidSession(ErrorMessage errorMessage, Throwable th) {
        if (errorMessage == null)
            return;
        String redirectURI = constructURLWithRPParams(tbResources.getString("LogOutPage"));
        LOGGER.error(errorMessage.getTechnicalUserMesssage(container.getErrorMessageSource()), th);
        SupportContactInfoVO sci = getSupportContactInfo();
        removeSessionData();
        try {
            addSessionAttribute(TrustBrokerWebAppConstants.ERROR,
                    errorMessage.getEndUserMessage(container.getErrorMessageSource(), sci));
        } catch (Exception ex) {
            LOGGER.error("AbstractBackingBean:handleInvalidSession() | Error while adding session attribute", ex);
        }
        redirectToView(redirectURI);
    }

    public String extractErrorMessageFromOFE(OperationFailedException ofe) {
        return ExceptionUtility.extractErrorMessageFromOFE(ofe, container.getErrorMessageSource(), getSessionMap(),
                container.getRelyingPartyAppService());
    }

    protected void updateUserInvitaion(UserVO userVO) {
        try {

            InvitationVO invitationVO = (InvitationVO) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION);
            if (invitationVO != null) {
                invitationVO.setInvtnAccptdDttm(DateUtil.getInstance().getCurrentDate());
                invitationVO.setInvtnToUsr(userVO.getUserId());

                StatusVO status = container.getReferenceService()
                        .fetchStatusByStatusState(PropertyLoader.getInstance().getPortalConfigValue("REGISTERED"));
                if (status != null)
                    invitationVO.setInvtnStts(status);

                InvitationServiceRequest request = new InvitationServiceRequest();
                request.setInvitationVO(invitationVO);
                container.getInvitationService().updateInvitation(request);
            }
        } catch (Exception ex) {
            LOGGER.error("UserRegistrationBean:updateUserInvitaion() | Error while updating the invitation", ex);
        }
    }

    /**
     * This method redirects to the specified view.
     * 
     * @param viewURI is the URI of view where redirection is required.
     */
    public boolean redirectToView(String viewURI) {
        try {
            getFacesContext().getExternalContext()
                    .redirect(getFacesContext().getExternalContext().getRequestContextPath() + viewURI);
            return true;
        } catch (IOException ioEx) {
            LOGGER.error("AbstractBackingBean:redirectToView() | Error while redirecting to view: {}",
                    new String[] {viewURI}, ioEx);
            return false;
        }
    }

    public boolean redirect(String url) {
        try {
            getFacesContext().getExternalContext().redirect(url);
            return true;
        } catch (IOException ioEx) {
            LOGGER.error("AbstractBackingBean:redirectToView() | Error while redirecting to view: {}", new String[] {url},
                    ioEx);
            return false;
        }
    }

    /**
     * Returns the relying party application identifier if exists in session.
     * 
     * @return relying party app identifier.
     */
    public String getRelyingPartyAppId() {
        String appId = null;
        if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null
                && !"".equals(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID))) {
            appId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
        }
        return appId;
    }

    public String getRelyingPartyApAlias(boolean... skipDefaultAlias) {
        String alias = null;

        if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS) != null
                && !"".equals(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS))) {
            alias = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS);
        }

        if (skipDefaultAlias.length > 0 && skipDefaultAlias[0]
                && TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE.equals(alias)) {
            alias = null;
        }
        return alias;
    }

    public String constructURL(String view) {
        HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
        try {
            URL url = new URL(request.getRequestURL().toString());
            int port = url.getPort();
            LOGGER.debug("hsreq scheme: " + request.getScheme());
            LOGGER.debug("hsreq server port: " + request.getServerPort());
            LOGGER.debug("url: " + request.getRequestURL());
            LOGGER.debug("url protocol: " + url.getProtocol());
            LOGGER.debug("url port: " + port);
            if (port == -1) {
                return url.getProtocol() + "://" + url.getHost() + request.getContextPath() + view;
            } else {
                return url.getProtocol() + "://" + url.getHost() + ":" + port + request.getContextPath() + view;
            }
        } catch (MalformedURLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public String constructConfirmationUrlWithParams(UserVO userVO, String confirmationUrl, boolean addUpdateProfileParam) {
        String verificationDetails = "";
        String inbSSO = (String) getSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO); // Inbound SSO scenario
        if (inbSSO != null)
            inbSSO = TrustbrokerWebAppUtil.encodeURL(container.getCryptAgentUtil().getCryptAgent().encrypt(inbSSO));

        if (StringUtils.isNotBlank(userVO.getEmailAddress()) && StringUtils.isNotBlank(userVO.getUuId())) {
            Map<String, String> userDetails = new HashMap<String, String>();
            userDetails.put(TrustBrokerWebAppConstants.KEY_USER_UUID, userVO.getUuId());
            userDetails.put(TrustBrokerWebAppConstants.KEY_USER_EMAIL, userVO.getEmailAddress());
            verificationDetails = container.getCryptAgentUtil().getCryptAgent().createToken(userDetails);
        } else {
            verificationDetails = "{0}";
        }

        if (!"{0}".equals(verificationDetails)) {
            try {
                verificationDetails = URLEncoder.encode(verificationDetails, "UTF-8");
            } catch (UnsupportedEncodingException ex) {
                //Eat up the exception
                LOGGER.error("Error while encoding verification details", ex);
            }
        }

        if ((getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null
                || getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF) != null)
                && getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null) {

            String target = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null
                    ? getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL).toString()
                    : getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF).toString();
            String url = "?" + TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM + "="
                    + getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) + "&"
                    + TrustBrokerWebAppConstants.TARGET + "=" + target + "&" + TrustBrokerConstants.VERIFICATION_DETAILS
                    + "=" + verificationDetails
                    + (addUpdateProfileParam
                            ? ("&" + TrustBrokerWebAppConstants.ACTION + "=" + TrustBrokerWebAppConstants.UPDATE_PROFILE
                                    + "&" + TrustBrokerWebAppConstants.STATUS + "=" + TrustBrokerWebAppConstants.SUCCESS)
                            : "")
                    + (inbSSO != null ? ("&" + TrustBrokerWebAppConstants.INBOUND_SSO + "=" + inbSSO) : "")
                    + "&VerifyEmailCode=";
            confirmationUrl += url;
        } else {
            confirmationUrl += "?" + (TrustBrokerConstants.VERIFICATION_DETAILS + "=" + verificationDetails
                    + (inbSSO != null ? ("&" + TrustBrokerWebAppConstants.INBOUND_SSO + "=" + inbSSO) : "")
                    + "&VerifyEmailCode=");
        }

        return confirmationUrl;
    }

    public String getRelyingPartyName() {
        String rpName = "";
        String rpId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
        if (rpId != null) {
            RelyingPartyAppVO rpApp = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpId);
            if (rpApp != null) {
                rpName = rpApp.getApplicationName();
            }
        }
        return rpName;
    }

    public boolean getRelyPartyOrigin() {
        boolean isRelyPartyOrigin = false;
        if ((getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF) != null
                && getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null)
                || (getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null
                        && getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) != null)) {
            isRelyPartyOrigin = true;
        }
        return isRelyPartyOrigin;
    }

    public boolean isQuestionsRequired() {
        return questionsRequired;
    }

    public void setQuestionsRequired(boolean questionsRequired) {
        this.questionsRequired = questionsRequired;
    }

    public boolean isDobRequired() {
        return dobRequired;
    }

    public void setDobRequired(boolean dobRequired) {
        this.dobRequired = dobRequired;
    }

    protected void getRPRegProfileAATypeinfo() {

        if (getRelyPartyOrigin()) {
            QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
            queryRelyingPartyResponse = container.getConfigService()
                    .queryRelyingParty(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS).toString());
            if (queryRelyingPartyResponse != null && queryRelyingPartyResponse.getRelyingParty() != null) {
                RelyingParty relyParty = queryRelyingPartyResponse.getRelyingParty();
                if (null != relyParty) {

                    if (relyParty.getTiers() != null && !relyParty.getTiers().isEmpty()) {

                        //String tierId = relyParty.getTiers().get(0);
                        TierConfig tierConfig = relyParty.getTiers().get(0);

                        List<AuthenticationType> authenticationTypes = tierConfig.getAuthenticationTypes();
                        if (authenticationTypes != null && !authenticationTypes.isEmpty()) {
                            Iterator<AuthenticationType> authTypeItr = authenticationTypes.iterator();
                            AuthenticationType authenticationType = null;
                            while (authTypeItr.hasNext()) {
                                authenticationType = (AuthenticationType) authTypeItr.next();
                                if (AuthenticationType.SECURITY_QUESTIONS.toString()
                                        .equalsIgnoreCase(authenticationType.value())) {
                                    questionsRequired = true;
                                }
                            }
                        }

                        QueryTierResponse queryTierResponse = container.getConfigService().queryTier(tierConfig.getTierId());
                        if (queryTierResponse != null && queryTierResponse.getTierDefinition() != null) {
                            List<TierAttribute> tierAttributes = queryTierResponse.getTierDefinition().getTierAttributes();
                            Iterator<TierAttribute> tierAttrItr = tierAttributes.iterator();
                            TierAttribute tierAttribute = null;
                            while (tierAttrItr.hasNext()) {
                                tierAttribute = (TierAttribute) tierAttrItr.next();
                                if (TrustBrokerConstants.DATE_OF_BIRTH.equalsIgnoreCase(tierAttribute.getName())
                                        && tierAttribute.isMandatory()) {
                                    dobRequired = true;
                                }
                            }
                        }
                    }

                }
            }
        } else {
            questionsRequired = false;
            dobRequired = false;
        }
    }

    public UserVO getUserByEmail(String email) {
        LOGGER.debug("getUserByEmail email: " + email);
        UserVO userVO = null;
        try {
            UserRetrievalServiceResponse response = container.getUserService().fetchUserProfileByEmail(email);
            if (response != null)
                userVO = response.getUser();
        } catch (Exception e) {
            LOGGER.debug("getUserByEmail() exception: ", e);
            return null;
        }
        return userVO;
    }

    protected String getWidgetHomeURIWithAlias() {
        String homePageURI = getURIWithAlias("/securew/homew.jsf");
        return homePageURI;
    }

    private String getURIWithAlias(String homePageURI) {
        String alias = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS);

        if (StringUtils.isBlank(alias)) {
            alias = TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE;
        }

        homePageURI = HttpUtils.addParameterToURL(homePageURI, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, alias);
        homePageURI = HttpUtils.addParameterToURL(homePageURI, "faces-redirect", "true");
        return homePageURI;
    }

    protected void createUserSession() {
        getSessionMap().put("usernameFromRequestHeader",
                getServletRequest().getHeader(TrustBrokerWebAppConstants.USER_NM_HEADER));

        String usernameFromRequestHeader = (String) getSessionMap().get("usernameFromRequestHeader");
        if (usernameFromRequestHeader == null && getCurrentUserVO() == null) {
            handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00C001), null);
            return;
        }

        if (getCurrentUserVO() == null || (getCurrentUserVO() != null && usernameFromRequestHeader != null
                && !getCurrentUserVO().getUserName().equals(usernameFromRequestHeader))) {
            clearSessionAttributes(new String[] {"termsAndConditionAccepted", "currentUserVO"});
            UserRetrievalServiceResponse userRetrievalResponse = null;
            try {

                userRetrievalResponse = container.getUserService().fetchUserDetailsForSession(usernameFromRequestHeader);

                if (userRetrievalResponse != null && userRetrievalResponse.getUser() != null && userRetrievalResponse
                        .getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
                    setCurrentUserVO(userRetrievalResponse.getUser());
                    SecurityLoggingUtil.info("User Login", SecurityEventType.E1_CREATE, getServletRequest(),
                            getCurrentUserVO().getUserName(),
                            "Security Audit Event|CreateUserSession:SUCCESS | User has established session, AbstractBackingBean:createUserSession()",
                            SecurityEventResult.SUCCESS, getRelyingPartyAppId(), null);
                } else {
                    handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00A003), null);
                    return;
                }

                if (!checkIfUserCoppaCompliant())
                    handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00K000), null);
                return;

            } catch (OperationFailedException exception) {
                handleInvalidSession(exception.getErrorMessage(), exception);
                return;
            }
        }
    }

    private boolean checkIfUserCoppaCompliant() {
        boolean coppaValdnReqd = true;
        String rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
        if (rpAppId != null) {
            RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpAppId);
            //Coppa will be required by default unless configured as N for relying party 
            if (relyingPartyAppVO != null && COPPA_REQD_NO_IND.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
                coppaValdnReqd = false;
            }
        }
        if (!coppaValdnReqd || TrustBrokerConstants.STATUS_YES.equalsIgnoreCase(getCurrentUserVO().getIsCoppaAccepted())) {
            return true;
        } else if (getCurrentUserVO().getDob() != null) {
            int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userMinAgeLimit"));
            return !DateUtil.validateAge(getCurrentUserVO().getDob(), minAgeLimit);
        }
        return true;
    }

    protected RelyingPartyAppVO getRelingAppByAlias(String alias) {
        return container.getRelyingPartyAppService().getRelyingPartyAppByAlias(alias);
    }

    protected void getCurrentUserDetails() {
        if (!TBUtil.isLocalEnv()) {
            createUserSession();
        }
    }

    protected void checkifStepUpRequiredForCOPPA(boolean coppaValdnReqd) {
        UserStepUpContext stepUpCtxt = getUserStepUpContext(false);

        if (!TrustBrokerConstants.STATUS_YES.equalsIgnoreCase(getCurrentUserVO().getIsCoppaAccepted())
                && getCurrentUserVO().getDob() == null && coppaValdnReqd && !stepUpCtxt.isShowDob()) {
            stepUpCtxt.setCoppaRequired(coppaValdnReqd);
            stepUpCtxt.setShowYOB(true);
            addSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME, stepUpCtxt);
        }
    }

    /**
     * This method is to update the updateUserVO obj from userVO with user terms, privacy policy and copaa info.
     * 
     * @param userVO
     * @param updateUserVO
     */
    protected void updUserRepoObj(UserVO userVO, UserVO updateUserVO) {
        updateUserVO.setUserId(userVO.getUserId());
        updateUserVO.setUuId(userVO.getUuId());
        updateUserVO.setUserRoleCd(userVO.getUserRoleCd());

        updateUserVO.setIsTncAccepted(userVO.getIsTncAccepted());
        updateUserVO.setTncAgreementVersion(userVO.getTncAgreementVersion());
        updateUserVO.setTncAgreedTs(userVO.getTncAgreedTs());
        updateUserVO.setIdentityProofingId(userVO.getIdentityProofingId());
        updateUserVO.setIsPriPolyAccepted(userVO.getIsPriPolyAccepted());
        updateUserVO.setPrivPolyAgreementVersion(userVO.getPrivPolyAgreementVersion());
        updateUserVO.setPriPolyyAgreedTs(userVO.getPriPolyyAgreedTs());
        updateUserVO.setIsCoppaAccepted(userVO.getIsCoppaAccepted());
    }

    public String constructURLWithRPParams(String targetURL) {
        if (isSessionContainsRelyingPartyInfo()) {
            targetURL = HttpUtils.addParameterToURL(targetURL, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM,
                    (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
            String target = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null
                    ? (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL)
                    : (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);
            targetURL = HttpUtils.addParameterToURL(targetURL, TrustBrokerWebAppConstants.TARGET, target);
        }

        if (getSessionAttribute(TrustBrokerConstants.INVITATION_CODE) != null) {
            targetURL = HttpUtils.addParameterToURL(targetURL, TrustBrokerWebAppConstants.INVITATION_CODE,
                    (String) getSessionAttribute(TrustBrokerConstants.INVITATION_CODE));
        }
        return targetURL;
    }

    protected VerificationCodeRequest getVerificationCodeRequest(CommunicationChannel channel, UserVO userVO,
            boolean iFrameRedirectionNotReq) {
        VerificationCodeRequest req = new VerificationCodeRequest();
        req.setChannel(channel);
        req.setUser(userVO);
        req.setUrlLogoOptumId(getUrlLogoOptumId());
        req.setUrlLogoRelyingParty(getUrlLogoRelyingParty());
        req.setRemoteAddress(getServletRequest().getRemoteAddr());
        req.setLocalAddress(getServletRequest().getLocalAddr());
        req.setSessionId(getServletRequest().getSession().getId());
        if (isSessionContainsRelyingPartyInfo()) {
            req.setUrlRelyingApp(getRelyingPartyRedirectionURL(false));
            req.setRpAppId(getRelyingPartyAppId());
        }
        req.setiFrameRequest(true);
        req.setiFrameRedirectionNotReq(iFrameRedirectionNotReq);
        if (isSessionAttributeExists(TrustBrokerWebAppConstants.INVITATION_CODE)) {
            req.setInvitationCode((String) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE));
        }
        req.setUrlVerification(constructURL(tbResources.getString(TrustBrokerConstants.VERIFICATION_URL)));
        return req;
    }

    /**
     * Checks if there is any active SM session using session cookie.
     * @return active session flag.
     */
    protected boolean isActiveSMSessionForUser(String userName) {

        Cookie cookies[] = getServletRequest().getCookies();
        String smsession = "";

        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_SESSION)) {
                    smsession = cookies[i].getValue();
                    break;
                }
            }
        }

        LOGGER.debug("Inside isActiveSession, cookie {} and userid {}",
                new String[] {(StringUtils.isNotBlank(smsession) ? "true" : "false"), userName});
        return (StringUtils.isNotBlank(smsession) && !"LOGGEDOFF".equals(smsession)) ? true : false;
    }

    //In case if request is redirected to other server post login then it might not have reference to RP so capture RP details again. 
    protected void reCaptureRPDetails() {
        if (isParamContainsRelyingPartyInfo() && !isSessionContainsRelyingPartyInfo()) {
            LOGGER.debug(
                    "HomeBean:onPreinitialize() | Session do not contain relying party data but exist with parameters: "
                            + "APP ID - {}, Target - {}",
                    new String[] {getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),
                            getRequestParameter(TrustBrokerWebAppConstants.TARGET)});
            captureRelyingPartyInfo(getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true : false);
        }
    }

    public boolean isSessionContainsRPInfoForLogin() {
        return (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null
                && getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null);
    }

    protected UserStepUpContext getUserStepUpContext(boolean addToSession) {
        UserStepUpContext userStepUpContext = (UserStepUpContext) getSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME);

        if (null == userStepUpContext) {
            userStepUpContext = new UserStepUpContext();
            if (addToSession)
                addSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME, userStepUpContext);
        }

        return userStepUpContext;
    }

    public boolean checkIfUserAccountRecoveryRequired() {

        if (getSessionAttribute(TrustBrokerWebAppConstants.SKIP_VERIFY_FLOW) == null
                && getSessionAttribute("SKIP_VERIFY_FLOW_REGISTRATION") == null
                && (TBUtil.isProdEnv() || isEmailConfirmationRequired())) {

            UserVO currentUserVO = getCurrentUserVO();

            List<UserChallengeQuestionVO> securityQuesList = currentUserVO.getUserChallengeQuestions();

            //Check if there is a recovery method available on profile.
            if ((StringUtils.isNotBlank(currentUserVO.getPhoneNumber()) && currentUserVO.getIsPhoneVerified())
                    || (StringUtils.isNotBlank(currentUserVO.getSecEmailAddress()) && currentUserVO.isSecEmailUnique())
                    || !(securityQuesList == null || securityQuesList.isEmpty())
                    || (StringUtils.isNotBlank(currentUserVO.getEmailAddress()) && (currentUserVO.isPrimaryEmailUnique()
                            || !container.getUserService().isEmailExists(currentUserVO.getEmailAddress())))) {
                return false;
            } else
                return true;
        } else {
            return false;
        }

        /*if(getSessionAttribute(TrustBrokerWebAppConstants.SKIP_VERIFY_FLOW) == null
        		&& getSessionAttribute("SKIP_VERIFY_FLOW_REGISTRATION") == null  
        	 && (TBUtil.isProdEnv() || isEmailConfirmationRequired())){	
        	
        	List<UserChallengeQuestionVO> securityQuesList = getCurrentUserVO().getUserChallengeQuestions();
        	
        	//Check if there is a recovery method available on profile.
        	if ((StringUtils.isNotBlank(getCurrentUserVO().getPhoneNumber()) && getCurrentUserVO().getIsPhoneVerified())
        			|| (StringUtils.isNotBlank(getCurrentUserVO().getSecEmailAddress()) && getCurrentUserVO().isSecEmailUnique()) 
        			|| !(securityQuesList == null || securityQuesList.isEmpty()) 
        			|| (StringUtils.isNotBlank(getCurrentUserVO().getEmailAddress()) && (getCurrentUserVO().isPrimaryEmailUnique() ||
        					!container.getUserService().isEmailExists(getCurrentUserVO().getEmailAddress()))) ) {
        		return false;
        	} else return true;
        } else{
        	return false;
        }*/

    }

    protected boolean isUserEmailShared(String email) {
        boolean userEmailShared = false;
        try {
            if (container.getUserService().isEmailExists(email)) {
                userEmailShared = true;
            }
        } catch (OperationFailedException ofe) {
            LOGGER.error("UserRegistrationBean:isUserEmailShared | Error checking duplicate email", ofe);
        }
        return userEmailShared;
    }

    /**
     * This method is used to check if user email is shared or not
     * 
     * @param email String
     * @return boolean
     */
    protected boolean isEmailExistsWithOtherUser(String email) {
        boolean userEmailShared = false;
        try {
            if (container.getUserService().isEmailExistsWithOtherUser(email, getCurrentUserVO().getUserName())) {
                userEmailShared = true;
            }
        } catch (OperationFailedException ofe) {
            LOGGER.error("UserRegistrationBean:isUserEmailShared | Error checking duplicate email", ofe);
        }
        return userEmailShared;
    }

    public String getCsrfToken() {
		String aCsrfId = getRtn().getCsrfId();
		String sCsrfId = (String) getSessionAttribute("CSRF_ID");
		String csrfId;
		
		if(aCsrfId != null){
			addSessionAttribute("CSRF_ID", aCsrfId);
			csrfId = aCsrfId;
		} else if(sCsrfId != null){
			getRtn().setCsrfId(sCsrfId);
			csrfId = sCsrfId;
		} else {
			SecureRandom random = new SecureRandom();
			csrfId = new BigInteger(130, random).toString(32);
			
			addSessionAttribute("CSRF_ID", csrfId);
			getRtn().setCsrfId(csrfId);
		}
		
			
		java.util.Date date = new java.util.Date();
		long ts = date.getTime();
		String nCsrfId = csrfId + ":"+ ts;
		
		setCsrfToken(nCsrfId);
		return csrfToken;
	}

	public void setCsrfToken(String csrfToken) {
		this.csrfToken = csrfToken;
	}
	
	public RequestFilterTokenBean getRtn() {
		return rtn;
	}

	public void setRtn(RequestFilterTokenBean rtn) {
		this.rtn = rtn;
	}

}