package com.optum.trustbroker.managebean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.IrmLoggingUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

/**
 * Manages the generation and verification of codes sent to email addresses and phones that require TB to validate the user has access to these
 * devices.
 *
 * @author nvaneps
 */
@ManagedBean(name = "verifyCodesUpdateBean")
@ViewScoped
public class VerifyCodesUpdateBean extends AbstractBackingBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final BaseLogger logger = new BaseLogger(VerifyCodesUpdateBean.class);
	public static final String VERIFY_CODES_UPDATE_VIEW = "/views/verifycodesupdate.jsf?faces-redirect=true";

	//private boolean primaryEmailUpdate;
	//private boolean secondaryEmailUpdate;
	//private boolean phoneUpdate;
	private String channelValue;
	private String channelValueRepeat;
	private String alert;
	private String originalValue;

	private VerifyCodesContext ctx;

	@PostConstruct
	public void postConstruct() {
		ctx = (VerifyCodesContext) getSessionAttribute(VerifyCodesContext.SESSION_NAME);
		if (isPrimaryEmailUpdate()) {
			channelValue = ctx.getUserVO().getEmailAddress();
			channelValueRepeat = ctx.getUserVO().getEmailAddress();
		}
		else if (isSecondaryEmailUpdate()) {
			channelValue = ctx.getUserVO().getSecEmailAddress();
			channelValueRepeat = ctx.getUserVO().getSecEmailAddress();
		}
		else if (isPhoneUpdate()) {
			channelValue = ctx.getUserVO().getPhoneNumber();
			channelValueRepeat = ctx.getUserVO().getPhoneNumber();
		}
		originalValue = channelValue;
	}

	public String noThanks() {
		return VerifyCodesBean.VERIFY_CODES_VIEW;
	}

	public void update() {
		if (isPrimaryEmailUpdate()) {
			updatePrimaryEmail();
		}
		else if (isSecondaryEmailUpdate()) {
			updateSecondaryEmail();
		}
		else if (isPhoneUpdate()) {
			updatePhone();
		}
	}

	private void logUserEmailUpdate(String msg, UserVO userVO, String email, String activity) {
		msg = "Security Audit Event|" + msg + "## uuid: ^^" + userVO.getUuId() + "!!";
		IrmLoggingUtil.info(activity, SecurityEventType.E3_MODIFY, getServletRequest().getRemoteAddr(),
				getServletRequest().getLocalAddr(), getServletRequest().getSession().getId(),
				userVO.getUserName(), msg, SecurityEventResult.SUCCESS, getRelyingPartyAppId(), email, "", SecuritySubEventType.E3_MODIFY_EMAIL);
	}

	private void updatePrimaryEmail() {
		if (validateEmail()) {
			try {
				if(StringUtils.isNotBlank(ctx.getUserVO().getSecEmailAddress()) && ctx.getUserVO().getSecEmailAddress().equalsIgnoreCase(getChannelValue())) {
						setAlert(tbResources.getString("primaryEmailValidation"));
						return;
				}
				
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
				ctx.getUserVO().setEmailAddress(getChannelValue());
				userProfileServiceRequest.setUser(ctx.getUserVO());
				UserVO essoUserVO = container.getUserService().fetchUserProfile(ctx.getUserVO().getUuId(), true, true).getUser();
				userProfileServiceRequest.setOldUser(essoUserVO);
				container.getUserService().modifyUser(userProfileServiceRequest, false);
				if (!ctx.getUserVO().getEmailAddress().equalsIgnoreCase(essoUserVO.getEmailAddress())) {
					String rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
					// courtesy email
					container.getUserService().sendUserEmailUpdInfo(essoUserVO.getEmailAddress(), ctx.getUserVO(), rpAppId,
							getUrlLogoOptumId(), getUrlLogoRelyingParty());
					logUserEmailUpdate(TrustBrokerWebAppConstants.REGN_CONF_EMAIL_UPD_MSG + "VerifyCodesUpdateBean.updatePrimaryEmail()",
							ctx.getUserVO(), essoUserVO.getEmailAddress(), TrustBrokerConstants.CONFRM_EMAIL_UPD_ACTIVITY);
				}
				ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
				addMessageToFlash("newconfirmationmsg", tbResources.getString("primaryEmailVerificationSent"));
				redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
			}
			catch (OperationFailedException exception) {
				logger.error("exception while updating the primary email during user registration - {}",
						new String[]{TrustbrokerWebAppUtil.getUidFromError(exception)}, exception);
				logger.error(exception);
				String error = extractErrorMessageFromOFE(exception);
				if (null != error) {
					setAlert(error);
				}
				else {
					setAlert(tbResources.getString("emailVerificationFailed"));
				}
			}
		}
	}

	private void updateSecondaryEmail() {
		if (validateEmail()) {
			try {
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
				ctx.getUserVO().setSecEmailAddress(getChannelValue());
				userProfileServiceRequest.setUser(ctx.getUserVO());
				UserVO essoUserVO = container.getUserService().fetchUserProfile(ctx.getUserVO().getUuId(), true, true).getUser();
				userProfileServiceRequest.setOldUser(essoUserVO);
				container.getUserService().modifyUser(userProfileServiceRequest, false);
				if (!ctx.getUserVO().getSecEmailAddress().equalsIgnoreCase(essoUserVO.getSecEmailAddress())) {
					String rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
					// courtesy email
					container.getUserService().sendUserEmailUpdInfo(essoUserVO.getSecEmailAddress(), ctx.getUserVO(), rpAppId,
							getUrlLogoOptumId(), getUrlLogoRelyingParty());
					logUserEmailUpdate(TrustBrokerWebAppConstants.REGN_CONF_EMAIL_UPD_MSG + "VerifyCodesUpdateBean.updateSecondaryEmail()",
							ctx.getUserVO(), essoUserVO.getEmailAddress(), TrustBrokerConstants.CONFRM_EMAIL_UPD_ACTIVITY);
				}
				ctx.getSendChannels().add(CommunicationChannel.SECONDARY_EMAIL);
				addMessageToFlash("newconfirmationmsg", tbResources.getString("secondaryEmailVerificationSent"));
				redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
			}
			catch (OperationFailedException exception) {
				logger.error("exception while updating the secondary email during user registration - {}",
						new String[]{TrustbrokerWebAppUtil.getUidFromError(exception)}, exception);
				logger.error(exception);
				String error = extractErrorMessageFromOFE(exception);
				if (null != error) {
					setAlert(error);
				}
				else {
					setAlert(tbResources.getString("emailVerificationFailed"));
				}
			}
		}
	}

	private void updatePhone() {
		if (validatePhone()) {
			try {
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
				ctx.getUserVO().setPhoneNumber(getChannelValue());
				userProfileServiceRequest.setUser(ctx.getUserVO());
				UserVO essoUserVO = container.getUserService().fetchUserProfile(ctx.getUserVO().getUuId(), true, true).getUser();
				userProfileServiceRequest.setUser(essoUserVO);
				container.getUserService().modifyUser(userProfileServiceRequest, false);
				if (!ctx.getUserVO().getPhoneNumber().equalsIgnoreCase(essoUserVO.getPhoneNumber())) {
					String rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
					// courtesy text
					// TODO
					//container.getUserService().sendUserEmailUpdInfo(essoUserVO.getPhoneNumber(), ctx.getUserVO(), rpAppId);
					logUserEmailUpdate(TrustBrokerWebAppConstants.REGN_CONF_PHONE_UPD_MSG + "VerifyCodesUpdateBean.updatePhone()",
							ctx.getUserVO(), essoUserVO.getEmailAddress(), TrustBrokerConstants.CONFRM_EMAIL_UPD_ACTIVITY);
				}
				ctx.getSendChannels().add(CommunicationChannel.PHONE);
				addMessageToFlash("newconfirmationmsg", tbResources.getString("phoneVerificationSent"));
				redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
			}
			catch (OperationFailedException exception) {
				logger.error("exception while updating the phone during user registration - {}",
						new String[]{TrustbrokerWebAppUtil.getUidFromError(exception)}, exception);
				logger.error(exception);
				String error = extractErrorMessageFromOFE(exception);
				if (null != error) {
					setAlert(error);
				}
				else {
					setAlert(tbResources.getString("phoneVerificationFailed"));
				}
			}
		}
	}

	private boolean validateEmail() {
		String lower = getChannelValue().toLowerCase();
		String lowerRepeat = getChannelValueRepeat().toLowerCase();
		
		if(StringUtils.isBlank(lower) || StringUtils.isBlank(lowerRepeat)){
			setAlert(tbResources.getString("emailRequired"));
			
			if(StringUtils.isBlank(lower) && StringUtils.isBlank(lowerRepeat)) {
				getFacesContext().addMessage("channelValueTextId", new FacesMessage(tbResources.getString("valueRequired")));
				getFacesContext().addMessage("channelValueRepeatTextId", new FacesMessage(tbResources.getString("valueRequired")));
			} else if(StringUtils.isBlank(lower)){
				getFacesContext().addMessage("channelValueTextId", new FacesMessage(tbResources.getString("valueRequired")));
			} else if(StringUtils.isBlank(lowerRepeat)){
				setAlert(tbResources.getString("emailConfirmRequired"));
				getFacesContext().addMessage("channelValueRepeatTextId", new FacesMessage(tbResources.getString("valueRequired")));
			}
			return false;
		}
			
		if (!lower.equals(lowerRepeat)) {
			setAlert(tbResources.getString("emailMustBeSameForm"));
			getFacesContext().addMessage("channelValueRepeatTextId", new FacesMessage(tbResources.getString("emailMustBeSameField")));
			return false;
		}
		
		if (lower.equalsIgnoreCase(originalValue)) {
			setAlert(tbResources.getString("emailUnaltered"));
			return false;
		}
		
		if (!TBUtil.validateEmailId(lower)) {
			setAlert(tbResources.getString("formatErrorForm"));
			getFacesContext().addMessage("channelValueTextId", new FacesMessage(tbResources.getString("formatErrorField")));
			return false;
		}
		
		if (container.getUserService().isEmailExists(lower)) {
			setAlert(tbResources.getString("emailAlreadyExists"));
			return false;
		}
		
		return true;
	}

	private boolean validatePhone() {
		String lower = getChannelValue().toLowerCase();
		String lowerRepeat = getChannelValueRepeat().toLowerCase();
		
		if(StringUtils.isBlank(lower) || StringUtils.isBlank(lowerRepeat)){
			setAlert(tbResources.getString("phoneRequired"));
			
			if(StringUtils.isBlank(lower) && StringUtils.isBlank(lowerRepeat)) {
				getFacesContext().addMessage("channelValueTextId", new FacesMessage(tbResources.getString("valueRequired")));
				getFacesContext().addMessage("channelValueRepeatTextId", new FacesMessage(tbResources.getString("valueRequired")));
			} else if(StringUtils.isBlank(lower)){
				getFacesContext().addMessage("channelValueTextId", new FacesMessage(tbResources.getString("valueRequired")));
			} else if(StringUtils.isBlank(lowerRepeat)){
				setAlert(tbResources.getString("phoneConfirmRequired"));
				getFacesContext().addMessage("channelValueRepeatTextId", new FacesMessage(tbResources.getString("valueRequired")));
			}
			return false;
		}
		
		if (!lower.equals(lowerRepeat)) {
			setAlert(tbResources.getString("phoneMustBeSameForm"));
			getFacesContext().addMessage("channelValueRepeatTextId", new FacesMessage(tbResources.getString("phoneMustBeSameField")));
			return false;
		}
		if (lower.equalsIgnoreCase(originalValue)) {
			setAlert(tbResources.getString("phoneUnaltered"));
			return false;
		}
		if (!TBUtil.validPhoneNumber(lower)) {
			setAlert(tbResources.getString("invalidPhone"));
			getFacesContext().addMessage("channelValueTextId", new FacesMessage(tbResources.getString("formatErrorPhoneField")));
			return false;
		}
		return true;
	}

	public boolean isPrimaryEmailUpdate() {
		return ctx.getUpdateChannel() == CommunicationChannel.PRIMARY_EMAIL;
	}

	public void setPrimaryEmailUpdate(boolean primaryEmailUpdate) {
	}

	public boolean isSecondaryEmailUpdate() {
		return ctx.getUpdateChannel() == CommunicationChannel.SECONDARY_EMAIL;
	}

	public void setSecondaryEmailUpdate(boolean secondaryEmailUpdate) {
	}

	public boolean isPhoneUpdate() {
		return ctx.getUpdateChannel() == CommunicationChannel.PHONE;
	}

	public void setPhoneUpdate(boolean phoneUpdate) {
	}

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

	public String getChannelValue() {
		return channelValue;
	}

	public void setChannelValue(String channelValue) {
		this.channelValue = channelValue;
	}

	public String getChannelValueRepeat() {
		return channelValueRepeat;
	}

	public void setChannelValueRepeat(String channelValueRepeat) {
		this.channelValueRepeat = channelValueRepeat;
	}
}
