DROP TABLE user_migration_data;

-- DROP INDEX IDX_user_migration_data_1 ON user_migration_data;

-- DROP INDEX IDX_user_migration_data_2 ON user_migration_data;

-- DROP TRIGGER TRG_MGN_USR_DTA_UUIDS_INSERT;

-- DROP TRIGGER TRG_MGN_USR_DTA_UUIDS_UPDATE;

DROP SEQUENCE SEQ_MGN_DTA_ID; 

ALTER TABLE tb_user DROP COLUMN MIGRATED_USER;

ALTER TABLE tb_user DROP COLUMN IS_COPPA_ACCEPTED;

DROP PROCEDURE migrate_users;