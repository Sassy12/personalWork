'use strict';
(function(){

	var tbApp = angular.module('tbApp');

	tbApp.service("VerifyRecoveryOptionsService", VerifyRecoveryOptionsService);

	VerifyRecoveryOptionsService.$inject = ['$http'];

	function VerifyRecoveryOptionsService($http) {

		var URL_GET_RECOVERY_OPTIONS = '/tb/services/secure/rest/verifyrecoveryoptions';
		var serviceCache = {};

		this.getRecoveryOptions = function () {

			return $http.get(URL_GET_RECOVERY_OPTIONS);
		};

		this.savePreferences = function (postData) {

			return $http({
				method: 'POST',
				url: URL_GET_RECOVERY_OPTIONS,
				data: $.param(postData),
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			});

		};

		this.saveRecoveryOptionsData = function(responseData){

			serviceCache.pageData = responseData;
		};

		this.getRecoveryOptionsData = function(){

			return serviceCache.pageData;
		};

	}

})();

