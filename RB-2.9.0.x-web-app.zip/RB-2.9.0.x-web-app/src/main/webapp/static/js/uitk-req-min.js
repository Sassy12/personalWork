/*
 *** DO NOT MODIFY THE COPYRIGHT HEADER MANUALLY ***
 * Copyright (c) Optum 2015 - All Rights Reserved.
 *** Release process will update accordingly ***
 * @version 3.8.0
 */
angular.module('uitk.component.uitkSlideAnimation',[])
.directive(
            "uitkSlideShow",
            function() {
                
                function link( $scope, element, attributes ) {
                    var expression = attributes.uitkSlideShow;  // truthy expression to watch.
                    var durationType = parseInt(attributes.uitkSlideShowDuration, 10);
                    var duration = (angular.element.isNumeric(durationType))? durationType: ( attributes.uitkSlideShowDuration || "fast" ); // default duration to fast if slide show duration is not provided.
                   
                   
                    
                    //default display of the element based on the link time value of the model we are watching.
                    
                    if ( ! $scope.$eval( expression ) ) {
                        element.hide();
                    }
                    
                    //watch for the expression 
                    $scope.$watch(
                        expression,
                        function( newValue ) {
                            if ( newValue ) {
                                element
                                    .stop( true, true )
                                    .slideDown( duration );
                            // Hide element.
                            } else {
                                element
                                    .stop( true, true )
                                    .slideUp( duration );
                            }
                        }
                    );
                }

                // Return the directive configuration.
                return({
                    link: link,
                    restrict: "A"
                });

            }
        );


 


/*
 *** DO NOT MODIFY THE COPYRIGHT HEADER MANUALLY ***
 *** Release process will update accordingly ***
 * Copyright (c) Optum 2015 - All Rights Reserved.
 * @version 3.8.0
 */
(function () {
    var EventsProto = function (scope, emit, broadcast, internalBroadcast) {
        this.scope = scope;
        this.emit = emit;
        this.broadcast = broadcast;
        this.internalBroadcast = internalBroadcast;
    };

    /**
     * uitkEvents wraps broadcasting service to purpose of controlling if on or off.
     */
    var uitkEvents = function (uitkConsumerConfigs, $rootScope, $log) {
        //NOTE: $on is not implemented here since it doesn't effect the configs

        var supressLog = (uitkConsumerConfigs.LOGCONFIG.errorLevel === 'test');

        //check to see if all events are turn off.
        if (!uitkConsumerConfigs.USEEVENTS.all) {
            return { setScope: function () { return false; } };
        }
        //define the scope
        var scope = $rootScope;
        /**
         * quick short hand
         * @param {object} object
         * @returns {string} 
         */
        var toString = function (object) {
            function replacer(key, value) {
                if (key && key.startsWith && (key.startsWith("$") || key === "parent" || key === "children")) {
                    return "---";
                }
                return value;
            };

            var str = JSON.stringify(object, replacer);

            return str;
            //return angular.toJson(object);
        };
        /**
         * if in verbose or debug mode show additional info
         * @param {object} object
         * @returns {string} 
         */
        var debugging = function (object) {
            if ("verbose" === uitkConsumerConfigs.LOGCONFIG.errorLevel || "debug" === uitkConsumerConfigs.LOGCONFIG.errorLevel) {
                return toString(object); //angular.toJson(object);
            } else {
                return "";
            }
        };

        /**
        * braodcast 
        * @param {string} componentName - The name of the component one is broadcasting as.
        * @param {string} name - name of the event to broadcast
        * @param {*} args - Optional one or more arguments which will be passed onto the event listeners
        * @param {*} debugDetails - additional verbose info passed in about how component is being used. 
        */
        var emit = function (componentName, name, args, debugDetails) {
            if (!uitkConsumerConfigs.USEEVENTS[componentName]) {
                return null;//broadcast for this componentsName is disabled.
            }

            if (!supressLog) {
                $log.info(componentName, " Emit event: ", name, toString(args), debugging(debugDetails));
            }
            return scope.$emit(name, args);
        };

        /**
         * braodcast 
         * @param {string} componentName - The name of the component one is broadcasting as.
         * @param {string} name - name of the event to broadcast
         * @param {*} args - Optional one or more arguments which will be passed onto the event listeners
         * @param {*} debugDetails - additional verbose info passed in about how component is being used. 
         */
        var broadcast = function (componentName, name, args, debugDetails) {
            if (!uitkConsumerConfigs.USEEVENTS[componentName]) {
                return null;//broadcast for this componentsName is disabled.
            }
            if (!supressLog) {
                $log.info(componentName, " Broadcast event: ", name, toString(args), debugging(debugDetails));
            }
            return scope.$broadcast(name, args);
        };
        /**
      * Force braodcast or emit
      * @param {string} braodcast or emit - the action to broadcast
      * @param {string} name - name of the event to broadcast
      * @param {*} args - Optional one or more arguments which will be passed onto the event listeners
      * @param {*} debugDetails - additional verbose info passed in about how component is being used. 
      */
        var internalBroadcast = function (BEName, name, args, debugDetails) {
            if (!supressLog) {
                $log.info(BEName + " event: ", name, toString(args), debugging(debugDetails));
            }
            if (BEName === 'broadcast') {
                return scope.$broadcast(name, args);
            } else {
                return scope.$emit(name, args);
            }
        };

        /**
         * scope to be used by broadcast service.
         * @param {object} scope
         */
        var setScope = function (targetScope) {
            scope = targetScope || $rootScope;
            //$log.info("Event scope set: ", toString(scope));
            return new EventsProto(scope, emit, broadcast, internalBroadcast);
        };
        return { setScope: setScope };
    };
    uitkEvents.$inject = ["uitkConsumerConfigs", "$rootScope", "$log"];

    /**
     * Make use of log4javacript to be used to overwrite $log
     * @returns {object} 
     */
    var uitkLogServiceProvider = function () {
        //no execption if log4javascript is not included.
        if (typeof log4javascript === "undefined") {
            return null;
        }

        var logger = log4javascript.getLogger();
        log4javascript.setShowStackTraces(true);
        var logLevelMap = {
            'all': log4javascript.Level.ALL,
            'fatal': log4javascript.Level.FATAL,
            'error': log4javascript.Level.ERROR,
            'warn': log4javascript.Level.WARN,
            'info': log4javascript.Level.INFO,
            'debug': log4javascript.Level.DEBUG,
            'trace': log4javascript.Level.TRACE,
            'off': log4javascript.Level.OFF
        };

        function registerAppendersForLogLevel(appenders, logLevel) {
            appenders.forEach(function (appender) {
                switch (appender.appender) {
                    case "AjaxAppender":
                        var ajaxAppender = new log4javascript.AjaxAppender(appender.loggingServiceUrl);
                        ajaxAppender.setThreshold(logLevelMap[logLevel]);
                        ajaxAppender.setLayout(new log4javascript.JsonLayout(false, true));
                        ajaxAppender.addHeader("Content-Type", "application/json;charset=utf-8");
                        ajaxAppender.addHeader("X-CSRF-HEADER", "X-CSRF-TOKEN");
                        ajaxAppender.addHeader("X-CSRF-PARAM", "_csrf");
                        ajaxAppender.addHeader("X-CSRF-TOKEN", window.csrfToken);
                        logger.addAppender(ajaxAppender);
                        break;
                    case "AlertAppender":
                    case "PopUpAppender":
                    case "InPageAppender":
                    case "BrowserConsoleAppender":
                        var appenderInstance = Object.create(log4javascript[appender.appender].prototype);
                        appenderInstance.constructor.apply(appenderInstance, []);
                        appenderInstance.setThreshold(logLevelMap[logLevel]);
                        if (appender.pattern) {
                            appenderInstance.setLayout(new log4javascript.PatternLayout(appender.pattern));
                        }
                        logger.addAppender(appenderInstance);

                        break;
                    default:
                        var errorAppender = {
                            name: "InvalidAppenderException",
                            message: "Log Appender '" + appender.appender + "' not supported."
                        };
                        console.error(errorAppender);
                }
            });
        }

        return {
            registerAppendersForLogLevel: registerAppendersForLogLevel,
            getLogger: function () {
                return logger;
            }
        };
    };

    /**
     * Implentation to use log4javascript overloading $log of angularjs 
     * @param {object} uitkLogServiceProvider
     * @param {object} $injector
     * @returns {object} 
     */
    var $logOverload = function (uitkLogServiceProvider, uitkConsumerConfigs) {
        //TODO: Add support for server strings [support of log4js] and console objects.
        //This may require us to look at appenders for log4js and if console, display the object otherwise display the string.
        //this must work with exceptionService. 
        /**
         * set the configs for log4js
         * @param {object} uitkLogConfig
         * @returns {object}  
         */
        this.setLogConfigs = function (uitkLogConfig) {
            //log4javacript is not enabled use basic log
            if (typeof uitkLogServiceProvider.registerAppendersForLogLevel === 'undefined')
                return console;

            //loop through all configs of log4js and register configs. 
            for (var logLevel in uitkLogConfig) {
                if (uitkLogConfig.hasOwnProperty(logLevel)) {
                    uitkLogServiceProvider.registerAppendersForLogLevel(uitkLogConfig[logLevel], logLevel);
                }
            }

            //set log object to be returned. 
            var log = {};
            //get all registered loggers. 
            var logger = uitkLogServiceProvider.getLogger();
            //find registered loggers and init the level called.
            ['fatal', 'error', 'warn', 'info', 'debug', 'trace'].forEach(function (currentLogLevel) {
                //make sure currentlogLevel is a string
                var logLevel = currentLogLevel.toString();
                //set properties on log by logLevel
                log[logLevel] = console.log;
                //execute logLevel called
                log[logLevel] = function () {
                    logger[logLevel].apply(logger, Array.prototype.slice.call(arguments));
                };
            });
            return log;
        };
        return this.setLogConfigs(uitkConsumerConfigs.LOGCONFIG.log4javascriptConfig);
    };
    $logOverload.$inject = ["uitkLogServiceProvider", "uitkConsumerConfigs"];

    var uitkTools = function ($log) {
        var _this = this;
        _this.RandomId = function (length) {
            var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');
            if (!length) {
                length = Math.floor(Math.random() * chars.length);
            }
            var str = '';
            for (var i = 0; i < length; i++) {
                str += chars[Math.floor(Math.random() * chars.length)];
            }
            return str;
        };

        _this.ComponentId = function (id, viewModel, element, name) {
            if (_.isUndefined(viewModel)) {
                $log.error("model provided is undefined " + name);
                return '';
            }

            var checkViewModel = function (id) {
                if (id) {
                    element.attr("id", id);
                    return true;
                }
                return false;
            };

            var checkAttribute = function (id) {
                if (id) {
                    return true;
                }
                return false;
            }
         
            if (!checkViewModel(viewModel.id)) {
                if (!checkAttribute(id)) {
                    $log.warn("No unique id has been provided for component " + name);
                    var uniqueId = _this.RandomId(5);
                    element.attr("id", uniqueId);
                    return uniqueId;
                }
            }
            return id;
        };
    };
    uitkTools.$inject = ['$log'];

    /*
     * Exception service for UITK which will translate message in user selected language and throw exception
     * This service will check if tranlsation module is present in app or not.
     */
    var uitkExceptionService = function ($injector) {

        var throwException = function (name, message) {

            var pascalFilter;

            if ($injector.has('$translate')) {
                pascalFilter = $injector.get('$translate');
                pascalFilter(message).then(function (data) {
                    throw {
                        name: name,
                        message: data
                    };
                }, function () {
                    throw {
                        name: name,
                        message: message
                    };
                });
            }
            else {
                throw {
                    name: name,
                    message: message
                };
            }
        };
        return {
            throwException: throwException
        }
    };

    uitkExceptionService.$inject = ["$injector"];

    /*
     * Translate filter for UITK which will check if angular-translate is available or not.
     */
    var uitkTranslateFilter = function ($filter, $log, uitkConsumerConfigs) {
        var pascalFilter;
        var supressLog = (uitkConsumerConfigs.LOGCONFIG.errorLevel === 'test');
        try {
            pascalFilter = $filter('translate');
        } catch (exception) {
            if (!supressLog) {
                $log.info("No translate filter defined: " + exception);
            }
            
        }

        return function (inputStr) {
            return pascalFilter ? pascalFilter(inputStr) : inputStr;
        }
    };

    uitkTranslateFilter.$inject = ["$filter", "$log", "uitkConsumerConfigs"];

    /*
     * This service is used to create dynamic live region and announce the message
     */
    var uitkLiveRegionService = function ($timeout, $document) {
        var timerB = null;
        var alertMessage = function (message, alertOff) {
            var div = document.createElement("div");
            angular.element(div).attr("id", "announceThisLive");
            angular.element(div).attr("role", "alert");
            angular.element(div).attr("aria-live", "polite");
            angular.element(div).attr("aria-relevant", "additions");
            angular.element(div).attr("aria-atomic", "false");
            angular.element(div).attr("class", "oui-a11y-hidden");
            if (angular.element("#announceThisLive").length === 0) {
                $document.find('body').append(div);
            }

            $timeout(function () {
                angular.element("#announceThisLive").html("");
                angular.element("#announceThisLive").append("<div>" + message + "</div>");
            }, 100);
            if (timerB) {
                $timeout.cancel(timerB);
            }
            timerB = $timeout(function () {
                angular.element("body #announceThisLive").attr("aria-live", "off");
                angular.element("body #announceThisLive").attr("role", "presentation");
                $timeout(function () {
                    angular.element("body #announceThisLive").remove();
                }, 100);
            }, 5000);
        };
        return {
            alertMessage: alertMessage
        }
    };

    /*
     * The purpose of this directive is to allow only numbers.
     * @return transformedInput
     */
    var uitkNumbersOnly = function() {
        function link(scope, element, attr, ngModelCtrl) {
            function userInput(input) {
                if (input) {
                    //Replace all other characters with empty string
                    var transformedInput = input.replace(/[^0-9]/g, '');

                    if (transformedInput !== input) {
                        ngModelCtrl.$setViewValue(transformedInput); //Update the view value
                        ngModelCtrl.$render(); //Called as view needs to be updated
                    }
                    //Return transformedInput
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(userInput);
        };

        return {
            restrict: 'EA',
            require: 'ngModel', // get a hold of NgModelController
            link: link
        };
    };

    uitkLiveRegionService.$inject = ["$timeout", "$document"];

    /**
     * @author Clint Small -> for dev questions :)
     * @module {uitk.uitkConfigs} This is configuration set for entire toolkit and can be adjusted for application requirements. 
     * This module will provide global tools required by the toolkit 
     */
    angular.module("uitk.uitkUtility", ["uitk.uitkConfigs"])
    .service("uitkEvents", uitkEvents)
    .service("uitkLogServiceProvider", uitkLogServiceProvider)
    .service("uitkExceptionService", uitkExceptionService)
    .service("$log", $logOverload)
    .service("uitkTools", uitkTools)
    .service("uitkLiveRegionService", uitkLiveRegionService)
    .filter("uitkTranslate", uitkTranslateFilter)
    .directive("uitkNumbersOnly", uitkNumbersOnly);
})();

/*
 *** DO NOT MODIFY THE COPYRIGHT HEADER MANUALLY ***
 *** Release process will update accordingly ***
 * Copyright (c) Optum 2015 - All Rights Reserved.
 * @version 3.8.0
 */
(function () {
    'use strict';

    var uitkConsumerConfigs = function () {
        //################################################-CONFIGS STATIC OBJECT-###############################
        var configs = {
            LOGCONFIG: {
                //set the error level to be used by the $log factory. See uitk-logger for error levels, set to info/test/debug for internal debugging
                errorLevel: "test",
                //log4javascript configuration for logging.
                log4javascriptConfig: {
                    'error': [
                             /*{
                                 appender: 'AjaxAppender'
                                 //todo: Specify the url if you are saving errors.
                                 //loggingServiceUrl: "/" + location.href.split('/')[3] + "/log"
                             },*/
                             {
                                 appender: 'BrowserConsoleAppender',
                                 pattern: "[%-5p] %d %c - %m%n"
                             }
                    ],
                    'all': [
                                 {
                                     appender: 'BrowserConsoleAppender',
                                     pattern: "[%-5p] %d %c - %m%n"
                                 }
                    ]
                }
            },
            USEEVENTS: { //control whether events are used globally or individually. Option set to give end-consumer maximum flexibility.
                all: true,
                accordion: true,
                authorization: true,
                autocomplete: true,
                button: true,
                calendar: true,
                checkboxGroup: true,
                dialog: true,
                dialogProgressBar: true,
                dynamicTable: true,
                fileUpload: true,
                footer: true,
                globalNavigation: true,
                grids: true,
                header: true,
                help: true,
                label: true,
                license: true,
                message: true,
                multiSelectDropdown: true,
                panel: true,
                phiConfirmation: true,
                picklist: true,
                primaryNavigation: true,
                progressBar: true,
                radioSelectGroup: true,
                secondaryNavigation: true,
                sessionTimeout: true,
                settingMenu: true,
                singleSelectDropdown: true,
                tabs: true,
                textarea: true,
                texteditor: true,
                textfield: true,
                tooltip: true,
                tree: true,
                verticalNavigation: true,
                formLayout:true

            }, //when true events will be broadcast by all components.
            SUPPORTEDBROWSERS : {
                'Internet Explorer': [9,10,11],
                'Chrome' : [48],
                'Firefox': [38,44],
                'iPad'   : [1,2,3,4,5,6,7,8,9],
                'Opera'  : [28],
                'Safari' : [8]
            },
            UNSUPPORTEDBROWSERS : {
                'Internet Explorer':[4,5,6,7,8],
                'Safari': [4]
            }

        }
        //################################################-CONFIGS GET/SET METHODS-###############################
        /**
         * 
         * @param {string} level - info/verbose/debug
         */
        this.setErrorLevel = function (level) {
            configs.LOGCONFIG.errorLevel = level;
        }

        /**
         * Set supported and unsupported browsers
         * @param supportedBrowsers
         * @param unsupportedBrowsers
         */
        this.setBrowsers = function(supportedBrowsers, unsupportedBrowsers) {
            if ( _.isObject(supportedBrowsers) ) {
                configs.SUPPORTEDBROWSERS = supportedBrowsers;
            }
            if ( _.isObject(unsupportedBrowsers) ) {
                configs.UNSUPPORTEDBROWSERS = unsupportedBrowsers;
            }
        }

        /**
         * 
         * @param {object} log4javascriptConfig - appenders defined by log4javascript errorlevel info/warn/debug/fatal/error
         */
        this.setLog4JavaScriptConfig = function (log4javascriptConfig) {
            configs.LOGCONFIG.log4javascriptConfig = log4javascriptConfig;
        }

        /**
         * 
         * @param {string} component - name of component to be changed
         * @param {bool} state - true/false
         */
        this.setEventActiveByComponent = function (component,state) {
            configs.USEEVENTS[component] = state;
        }
        this.$get = function () {
            return configs
        }
        return this;
    }

    angular.module('uitk.uitkConfigs', [])
    .provider('uitkConsumerConfigs', uitkConsumerConfigs);
})();
/*
 *** DO NOT MODIFY THE COPYRIGHT HEADER MANUALLY ***
 * Copyright (c) Optum 2015 - All Rights Reserved.
 *** Release process will update accordingly ***
 * @version 3.8.0
 */
angular.module('uitk.component.uitkNavigable',[])
.directive('uitkNavigable', ["$parse", function($parse){
	
    function link($scope, $element, $attrs) {
       
		var isNavigable = true;
		if($attrs.uitkNavigable){
		    isNavigable = $parse($attrs.uitkNavigable)($scope) ? true : false;
     	}
        $scope.keysToTrigger = ($attrs.keyCodes) ? JSON.parse($attrs.keyCodes) : [];
		if (isNavigable) {
			$element.attr('tabindex', 0);
			if($element.attr('ng-click')) {
				var fn = $parse($element.attr('ng-click'));
				$element.on('keydown', function (event) {
				    if (event.which === 13 || event.which === 32 || angular.element.inArray(event.which, $scope.keysToTrigger) > -1) { // enter or space key is pressed
						$scope.$apply(function() {fn($scope, {$event:event});});
						event.preventDefault();
					}
				});
			}
		}
	}
	
	return {
		restrict : 'A',
		replace : false,
		scope : false,
		link : link
	};
}]);
/*
 *** DO NOT MODIFY THE COPYRIGHT HEADER MANUALLY ***
 * Copyright (c) Optum 2015 - All Rights Reserved.
 *** Release process will update accordingly ***
 * @version 3.8.0
 */
angular.module('uitk.component.busyIndicator', ['uitk.component.uitkNavigable','uitk.uitkUtility'])
.factory('httpInterceptor', ["$q", "$rootScope", function ($q, $rootScope) {

    return {
        request: function (config) {
        	var screenNumber = $rootScope.currentScreenNumber;
        	config.headers['screenNumber'] = screenNumber;
            $rootScope.$broadcast("busy_indicator",{type:"request",url:config.url, screenNumber: screenNumber});
            return config || $q.when(config);
        },
        response: function (response) {
        	$rootScope.$broadcast("busy_indicator",{type:"response",url:response.config.url, screenNumber: response.config.headers.screenNumber});
        	return response || $q.when(response);
        },
        responseError: function (response) {
        	$rootScope.$broadcast("busy_indicator",{type:"responseError",url:response.config.url, screenNumber: response.config.headers.screenNumber});
            return $q.reject(response);
        }
    };
}])
.config(["$httpProvider", function ($httpProvider) {
    $httpProvider.interceptors.push('httpInterceptor');
}])
.run(["$rootScope", function($rootScope){
	$rootScope.currentScreenNumber = 1;
}])
.directive("uitkBusyIndicator", ["$timeout", "$document", "$rootScope", "uitkExceptionService", function ($timeout, $document, $rootScope, uitkExceptionService) {

    function link($scope, $element) {
    	$scope.requestCount = 0;
    	$scope.focusedElement = null;
    	$scope.visibility = "false";

        if(!_.isNumber($scope.model.busyIndicatorDelay)){
            uitkExceptionService.throwException("NumberFormatException", "busyIndicatorDelay should be a number");
        }

        if(_.isUndefined($scope.model.busyIndicatorDelay)){
            $scope.model.busyIndicatorDelay = 5;
        }
    	
    	$scope.eventHandlerFunction = function(event) {
			if($scope.requestCount > 0 && !event.ctrlKey && !event.altKey){
				event.stopPropagation();
				return false;
			}
		}
    	
    	$rootScope.$on("$routeChangeSuccess", function() {
    		$rootScope.currentScreenNumber++;
    		$scope.requestCount = 0;
    	});
    	
        $scope.$on("busy_indicator", function (event, parameter) {

        	var timeoutFunc = function(){
    			if($scope.requestCount > 0 && parameter.screenNumber === $rootScope.currentScreenNumber){
    				if(!$scope.focusedElement){
    					$scope.focusedElement = $(':focus');
    				}
    				$scope.visibility = "true";
    				$element.show(); 
    				$(".tk-wrapper").attr("aria-hidden", "true");
    				$("footer").attr("aria-hidden", "true");
    				$element.attr("aria-hidden", "false");
    				$timeout(function(){
    					$document.find('#busyIndicatorImage-'+$scope.id).focus();	
    				},1000);
					
    				$document.bind('keydown', $scope.eventHandlerFunction);
    			}
    		}
        	
        	if(($scope.model.excludeUrl && !$scope.model.excludeUrl(parameter.url)) || !$scope.model.excludeUrl){
	        	if(parameter.type === 'request' ){
	        		$scope.requestCount++;
	        		$timeout(timeoutFunc,$scope.model.busyIndicatorDelay * 1000);
	        	}
	        	
	        	if((parameter.type === 'response' || parameter.type === 'responseError') 
	        			&& parameter.screenNumber === $rootScope.currentScreenNumber && (--$scope.requestCount) === 0) {

	        		$element.hide();
	        		$scope.visibility = "false";
	        		$(".tk-wrapper").attr("aria-hidden", "false");
	        		$("footer").attr("aria-hidden", "false");
	        		$element.attr("aria-hidden", "true");
	        		$document.unbind('keydown', $scope.eventHandlerFunction);
	        		if($scope.focusedElement){
	        			$scope.focusedElement.focus();
	        			$scope.focusedElement = null;
	        		}
	        	}
        	}
        });
        
        $scope.genRandomString = function( length ) {                
            var possible    = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            var temp        = '';
            for( var i=0; i < length; i++ ) {
                 temp += possible.charAt( Math.floor( Math.random() * possible.length ));
            }
            return temp;
        };
        
        $scope.id = $scope.genRandomString(5);
    };
	
	return {
		restrict : 'E',
		link : link,
		replace : true,
		scope : {
			model : '='
		},
		template : 	['<div ng-if="visibility === \'true\'" aria-hidden="true">',
		           	 '	<div class="uitk-busyindicator-overlay"></div>',
		           	 '	<div id="busyIndicatorBox-{{$parent.id}}" role="alert" aria-live="assertive" class="uitk-busyindicator-dialog"',
		           	 ' 	  aria-labelledby="busyIndicatorHeading-{{$parent.id}}" aria-describedby="busyIndicatorMoreInfo-{{$parent.id}}">',
		           	 '	  <div class="uitk-busyindicator-content-wrapper">',
		           	 '		<img id="busyIndicatorImage-{{$parent.id}}" ng-src="{{$parent.model.imageUrl}}" tabindex="-1"',
		           	 ' 		  aria-labelledby="busyIndicatorHeading-{{$parent.id}}" aria-describedby="busyIndicatorMoreInfo-{{$parent.id}}" />',
		           	 '		<h2 id="busyIndicatorHeading-{{$parent.id}}" class="uitk-busyindicator-message">{{"Information Loading" | translate}}</h2>',
		           	 '		<div id="busyIndicatorMoreInfo-{{$parent.$parent.id}}" class="tk-busy-txt" ng-if="$parent.model.text">{{$parent.$parent.model.text}}</div>',
		           	 '	  </div>',
		           	 '	</div>',
		           	 '</div>'].join('')
	}
}]);
/*
 * Copyright (c) Optum 2015 - All Rights Reserved.
 */

(function () {

    /**
     *
     * @returns {{restrict: string, transclude: boolean, scope: {heading: string, tkOptions: string}, controller: Function, template: string}}
     */
    var uitkApi = function($window) {
        return {
            restrict: 'E',
            transclude: true,
            scope: {heading: '@',tkOptions:'='},
            controller: ["$scope", function($scope) {

                var panels = $scope.panels = [];

                $scope.tkOptions = $scope.tkOptions || {};
                if($scope.tkOptions.showHomeQaLink === undefined){
                    $scope.tkOptions.showHomeQaLink = true;
                }

                $scope.select = function(panel) {
                    angular.forEach(panels, function(panel) {
                        panel.selected = false;
                    });
                    panel.selected = true;
                };

                this.addPanel = function(panel) {
                    if (panels.length === 0) {
                        $scope.select(panel);
                    }
                    panels.push(panel);
                };

                //Checks if demo page is home-qa.html or home-qa-dev.html, based on that it will set url
                $scope.relativePathPrefix = "../../";
                $scope.url = "../../home-dev.html";
                if($window.location.pathname.indexOf("/dist") > -1){
                    $scope.relativePathPrefix = "../../../";
                    $scope.url = "../../../home-qa.html";
                }
            }],
            template:
            '<link rel="stylesheet" ng-href="{{relativePathPrefix}}uitk-core/css/uitk_dev-only.css" >'+
            '<h1>{{heading}}</h1>' +
            '<a ng-href="{{url}}" class="tk-margin-bottom-1t" ng-show="tkOptions.showHomeQaLink">Go to home page</a>' +
            '<div class="tk-api"><a ng-repeat="panel in panels" href="" ng-class="{\'tk-api-selected\':panel.selected}" ng-click="select(panel)">{{panel.label}}</a></div>'
            +'<div ng-transclude></div>'
        };
    };
    uitkApi.$inject = ["$window"];

    /**
     *
     * @returns {{require: string, restrict: string, transclude: boolean, scope: {label: string}, link: Function, template: string}}
     */
    var uitkApiPanel = function() {
        return {
            require: '^uitkApi',
            restrict: 'E',
            transclude: true,
            scope: {
                label: '@'
            },
            link: function(scope, element, attrs, aCtrl) {
                aCtrl.addPanel(scope);
            },
            template: '<div ng-show="selected" ng-transclude></div>'
        };
    };

    /**
     *
     * @returns {{restrict: string, scope: {heading: string, items: string}, template: string}}
     */
    var uitkApiGrid = function() {
        return {
            restrict: 'E',
            scope: {heading:'@', items: '='},
            template:
            '<div class="tk-padding-bottom-1t">'+
            '<h3>{{heading}}</h3>'+
            '<div class="tk-data-table-container">'+
            '  <table>'+
            '    <thead>'+
            '      <tr>'+
            '        <th>Attribute</th>'+
            '        <th>Value</th>'+
            '        <th>Required</th>'+
            '        <th>Description</th>'+
            '      </tr>'+
            '    </thead>'+
            '    <tbody>'+
            '      <tr ng-repeat="a in items">'+
            '        <th scope="row">{{a.attrib}}</td>'+
            '        <td>{{a.txt}}</td>'+
            '        <td>{{a.req}}</td>'+
            '        <td>{{a.desc}}</td>'+
            '      </tr>'+
            '    </tbody>'+
            '  </table>'+
            '</div>'+
            '</div>'
        };
    };

    angular.module('uitk.api', [])
        .directive('uitkApi', uitkApi)
        .directive('uitkApiPanel', uitkApiPanel)
        .directive('uitkApiGrid', uitkApiGrid)
})();
/*
 * Copyright (c) Optum 2015 - All Rights Reserved.
 */

var maxlengthApp = angular.module('uitk.maxlength',[]);
maxlengthApp.directive('uitkMaxlength', [function() {
		return {
			restrict: 'A',
			require: 'ngModel',
			link: function (scope, elem, attrs, ctrl) {
				attrs.$set("ngTrim", "false");
                var maxlength = parseInt(attrs.uitkMaxlength, 10);
                ctrl.$parsers.push(function (value) {
                    if (value.length > maxlength)
                    {
                        value = value.substr(0, maxlength);
                        ctrl.$setViewValue(value);
                        ctrl.$render();
                    }
                    return value;
                });
			}
		};
}]);
angular.module('uitk.component.header', ['uitk.component.uitkNavigable','uitk.uitkUtility'])
.directive('uitkHeader', ["$location", function($location) {
	function controller($scope){
		$scope.redirectUrl = function(){
			if($scope.url){
				if($scope.url[0] === '#'){
					$location.path($scope.url.substring(1));
				}
				else{
					window.location = $scope.url;
				}
			}
		}
	}
	controller.$inject = ["$scope"];;

	    return {
      restrict: 'E',
      transclude: true,
      scope: {
    	  logo: "@",
    	  url: "@",
    	  altText: "@"

          },
      template: '<header class="tk-head" role="banner"><div class="tk-head-logo"><a ng-click="redirectUrl()" ng-href="{{url}}"><img ng-src="{{logo}}" alt="{{altText | uitkTranslate}}" /></a></div><div ng-transclude></div></header>',
      replace: true,
     controller: controller

          };
}]);


angular.module('uitk.component.uitkHelp',['uitk.uitkUtility'])
.factory('HelpObj', function () {
    var helpObj = {url:'#'};
    return {
      setHelpObj: function(help) {
    	  helpObj = help;
      },
      getHelpObj: function() {
    	  return helpObj;
      }
   };
})
.directive('uitkHelp', function(){
	return {
		restrict : 'E',
		replace : true,
		transclude : true,
		scope : true,
		controller:["$scope", "HelpObj", function($scope,HelpObj){
			var openHelpWindow = function(helpLink) {
				var helpWindow = window.open(helpLink,'webHelp','height=600,width=600,left=400px,top=200px,resizable=yes,toolbar=yes,location=yes');
				helpWindow.focus();
			};
			$scope.helpLinkInvoked = function(){
				var helpObj = HelpObj.getHelpObj();
				openHelpWindow(helpObj.url);
			}
		}],
		template : '<li>'
			+'<a href="javascript:void(0)" ng-click="helpLinkInvoked()" tabindex="0" title="opens in new window">'
			+'	<span class="cux-icon-help"></span>'
			+'<span>{{"Help" | uitkTranslate}}</span>'
			+'</a></li>'};

		});

angular.module('uitk.component.uitkAccordion', ['uitk.component.uitkSlideAnimation', 'uitk.component.uitkNavigable'])
.directive(
		'uitkAccordion',
		["$timeout", "toggleActiveContent", function ($timeout, toggleActiveContent) {
			return {
				restrict: "E",
				replace: true,
				scope: {
					model: '='
				},
				link: function (scope, element) {
					scope.selectedIndex = 0;
					scope.model.panels.forEach(function (panelItem, index) {
						if (panelItem.open === true) {
							scope.selectedIndex = index;
						}
					});
					element.on('keydown', function (event) {
						if (event.keyCode >= 37 && event.keyCode <= 40) {
							var selectorIndex = angular.element(event.target).data('panel-index');
							if (event.keyCode === 38 || event.keyCode === 37) { 
								if (selectorIndex > 0) {
									angular.element("#panel" + (selectorIndex - 1) + "_header").focus();
								}
							} else {
								if (scope.selectedIndex < scope.model.panels.length) {
									angular.element("#panel" + (selectorIndex + 1) + "_header").focus();
								}
							}
						}

					});

					scope.togglePanel = function (panelIndex, event) {

						scope.selectedIndex = panelIndex;

						event.stopPropagation();
						scope.model.panels.forEach(function (panel, key) {
							if (key !== panelIndex) {
								panel.open = false;
							}
						});
						scope.selectedPanel = scope.model.panels[panelIndex];
						scope.selectedPanel.open = !scope.selectedPanel.open;
						if (scope.selectedPanel.open) {
							$timeout(function () {
								toggleActiveContent.toggleActive(element, 'tk-acrd-content-container', panelIndex);
							}, 0);
						}
					};
					scope.isOpenTab = function (tabIndex) {
					    var selectedPanel = scope.model.panels[tabIndex];
						return selectedPanel.open;
					};

					scope.onLinkClick = function (panelItem, panelIndex, event) {
					    event.stopPropagation();  
						if (panelItem.links[panelIndex].callBack) panelItem.links[panelIndex].callBack.call();
					}

				},
				template: ['<div role="tablist" class="tk-acrd" aria-describedby="tablist-desc" >',
                            '<div>' +
                            '   <div class="oui-a11y-hidden" id="tablist-desc" aria-hidden="true" tabindex="-1">Panel headers may have related links, Press Tab to access while header has focus.</div>' +
                            '   <div class="oui-a11y-hidden" id="tablist-desc-short" aria-hidden="true" tabindex="-1">This header has links.</div>' +
                            '	<div id="panel{{$index}}_header" data-panel-index="{{$index}}" ng-repeat-start="panelItem in model.panels" ',
							'		class="tk-acrd-header" ng-class="{\'tk-acrd-header-links\':(( panelItem.links.length)?true:false)}"',
							'		ng-click="togglePanel($index,$event); "  role="tab" uitk-navigable="" ',
                            '       ng-style="{\'width\': \'{{panelItem.width}}\'}" ',
							'		aria-selected="{{panelItem.open}}" aria-expanded="{{panelItem.open}}" aria-controls="panel{{$index}}_content" aria-describedby="{{(panelItem.links.length)?\'tablist-desc-short\':\'\'}}" > ',
							'		<h2 class="tk-acrd-header-color"> ',
							'			<span ng-class="{\'cux-icon-carrot_down\' : panelItem.open, \'cux-icon-carrot_right\': !panelItem.open}"></span><span>{{panelItem.title}}</span> ',
							'		 </h2></div>',
							'   <div class="tk-acrd-header-cont">',
							'		<ul class="tk-header-options"> ',
							'			<li ng-repeat="panelLinks in panelItem.links" class="liclass"> ',
							'				<a ng-if="!panelLinks.disabled" ng-click="onLinkClick(panelItem, $index, $event)" href="" uitk-accordion-compile-link=\'panelLinks\' uitk-navigable="" ></a> ',
							'				<span ng-if=\'panelLinks.disabled\' class="tk-acrd-panel-disabled-link" uitk-accordion-compile-link=\'panelLinks\' aria-disabled="true" tabindex="0" role="link" ></span> ',
							'			</li> ',
							'		</ul> ',
							'   </div>',
							'	<div id="panel{{$index}}_content" class="tk-acrd-content-container" tabindex="-1" ng-repeat-end',
							'		uitk-slide-show="isOpenTab($index)"  ng-class="{\'tk-acrd-content-container-links\':(( panelItem.links.length)?true:false)}"',
							'		uitk-slide-show-duration="500" role="tabpanel" aria-hidden="{{!panelItem.open}}" ',
							'		aria-labelledby="panel{{$index}}_header" ng-style="{\'width\':\'{{panelItem.width}}\'} "> ',
							'		<span class="oui-a11y-hidden">{{panelItem.title}} Content</span> ',
							'		<div class="tk-acrd-content" tyle="width:{{panelItem.width}}, padding: 1.083rem;" >' +
                            '        <div ng-style="{\'max-height\':\'{{panelItem.height}}\'}"><ng-include src="panelItem.templateUrl">' +
                            '       </ng-include></div> </div>',
							'	</div>		 ',
							' </div> ',
						' </div>'].join('')
			}
		}]).factory("toggleActiveContent", function () {
			return {
				toggleActive: function (element, contentClass, panelIndex) {
					if (angular.isNumber(panelIndex)) {
						angular.element('div.' + contentClass, element).removeClass("content-active");
						angular.element('div#panel' + panelIndex + '_content.' + contentClass, element).focus().addClass("content-active");
					}

				}
			}

		})
.directive('uitkAccordionCompileLink', ["$compile", function ($compile) {
	return function ($scope, $element) {
		$compile($scope.panelLinks.text)($scope, function (clone) {
			if (!clone.selector) {
				$element.prepend(clone);
			}
			else {
				$element.prepend(clone.selector);
			}
		});
	};
}]);



angular.module("uitk.component.uitkAccordion").run(["$templateCache", function($templateCache) {$templateCache.put("template/uitkAccordionTpl.html","<div role=\"tabslist\" class=\"tk-acrd\" >\r\n	<div ng-repeat=\"p in viewModel.panels\">		\r\n		<div id=\"panel{{$index}}_header\"\r\n			class=\"tk-acrd-header tk-acrd-header-w-actions\"\r\n			ng-click=\"toggleAccorPanel($index)\" ng-keydown=\"onKeyDown($event, $index)\" role=\"tab\" tabindex=\"0\" \r\n			aria-expanded=\"{{p.open}}\" aria-controls=\"panel{{$index}}_header\">\r\n			<h2 class=\"tk-acrd-header-color\">\r\n				<span ng-class=\"{\'cux-icon-carrot_down\' : p.open, \'cux-icon-carrot_right\': !p.open}\"></span><span>{{p.title}}</span>\r\n			</h2>\r\n			<ul>\r\n				<li ng-repeat=\"l in p.links\" class=\"liclass\">\r\n					<a ng-if=\"!l.disabled\" ng-click=\"onLinkClick(p, $index, $event)\" href=\"\" uitk-accordion-compile-link=\'l\'></a>\r\n					<span ng-if=\'l.disabled\'class=\"tk-acrd-panel-disabled-link\" uitk-accordion-compile-link=\'l\'></span>\r\n				</li>\r\n			</ul>\r\n		</div>\r\n		<div id=\"panel{{$index}}_content\" class=\"tk-acrd-content-container\"\r\n			uitk-slide-show=\"isOpenTab($index)\"\r\n			uitk-slide-show-duration=\"2000\" role=\"tabpanel\" aria-hidden=\"{{!p.open}}\"\r\n			aria-labelledby=\"panel{{$index}}_header\" tabindex=\"-1\">\r\n			<span class=\"oui-a11y-hidden\" tabindex=\"-1\">{{p.title}} Content</span>\r\n			<div class=\"tk-acrd-content\" tabindex=\"-1\"><ng-include src=\"p.templateUrl\"></ng-include></div>\r\n		</div>		\r\n	</div>\r\n</div>\r\n");}]);
angular.module('uitk.component.uitkButton',[])
.directive('uitkButton', function(){
	return {
		restrict : 'E',
		replace : true,
		scope : true,
		link: function($scope,$element,$attrs){
			$scope.enableDefault = $attrs["enableDefault"];
			$scope.customClass = $attrs["customClass"];

						if(navigator.userAgent.match(/iPad/i) === 'iPad' || navigator.userAgent.match(/Android/i) === 'Android'){
				$scope.isTablet = 'true';
				$element.bind('touchstart', function() {
					$element.addClass('tk-btn-active');
	            });

								$element.bind('touchend', function() {
					$element.removeClass('tk-btn-active');
	            });
			}
		},

				template: "<input class=\"{{enableDefault == 'true' ? 'tk-btn-default-action' : 'tk-btn'}} {{isTablet == 'true' ? 'tk-btn-tablet' : ''}}  {{customClass}} \"  ></input> "
	};
})
.directive('uitkBtnDisabled',["$timeout", function($timeout){
	return {
		restrict : 'A',
		scope : true,
		link : function(scope,element,attributes){
			scope.isDisabled = false;

			element[0].addEventListener('click', function (event) {
				if(!scope.isDisabled){
					event.preventDefault();
			        event.stopImmediatePropagation();
				}
			}, true);


			if(attributes.uitkBtnDisabled === 'true'){
				$timeout(function(){
					disableButton();
				});
			}
			else if(attributes.uitkBtnDisabled === 'false'){
				enableButton();				
			}
			else {
				scope.$watch(attributes.uitkBtnDisabled, function (value){
	                if(value === true){
	                	$timeout(function(){
	                		disableButton();
	                	});
	                }
	                else if(value === false){
	                	enableButton();	                	
	                } else if(value === undefined) {
	                	scope.isDisabled = true;
	                }
	            });	
			}

			function enableButton(){
				element.removeClass('tk-btn-disabled');
				element.attr('aria-disabled','false');
				scope.isDisabled = true;
			}

			function disableButton(){
				element.addClass('tk-btn-disabled');
				element.attr('aria-disabled','true');
				scope.isDisabled = false;

							}
		}
	}
}]);


(function () {

    var uitkDynamicTableService = function ($compile, $rootScope, $timeout) {
        return {
            render: function (model) {
                var isolatedScope = $rootScope.$new(true);
                model.isExporting = true;
                isolatedScope.exportModel = model;
                $timeout(function () {
                    isolatedScope.$destroy();
                }, 500);
                return $compile("<uitk:dynamic-table view-model='exportModel'></uitk:dynamic-table>")(isolatedScope);
            }
        };
    };

    var uitkDynamicTable = function ($timeout, uitkDynamicTableService, uitkDynamicTableExporter, $filter, uitkExceptionService, columnCombinations, uitkLiveRegionService) {
        function controller($scope, tableSortEnum, uitkEvents, $attrs, uitkTools, $element) {
            if ($scope.viewModel) {
                $scope.model = $scope.viewModel;
            }

            $scope.usingCRUD = false;
            if ($scope.model.crudOptions) {
                if (!_.has($scope.model.crudOptions, 'notificationMessage') || !_.has($scope.model.crudOptions, 'saveRecord')) {
                    uitkExceptionService.throwException("CRUDOptionsException", "notificationMessage (message object) and saveRecord (call back function that returns a promise) are required when using crudOptions on viewModel");
                } else {
                    $scope.usingCRUD = true;
                    $scope.model.columnInput = {};
                }
            }

            $scope.componentId = uitkTools.ComponentId($attrs.id, $scope.model, $element, 'Dynamic Table');
            $scope.page = {'pageNumber': 0};

            $scope.preLoadedData = [];
            $scope.model.originalRecords = [];
            $scope.model.selectedRecords = [];
            $scope.model.record = [];
            $scope.model.selectedRecordCount = 0;

            $scope.customOnSortIsDefined = ($scope.model.onSort) ? true : false;
            $scope.customOnSearchIsDefined = ($scope.model.onSearch) ? true : false;
            $scope.customOnPaginateIsDefined = ($scope.model.onPaginate) ? true : false;
            $scope.customOnEditRowIsDefined = ($scope.model.onEditRow) ? true : false;

            if ($scope.model.records.length > 0 && !$scope.model.isExporting) {
                $scope.preLoadedData = _.clone($scope.model.records);
                $scope.model.records = [];
                $scope.model.totalRecordsCount = 0;
            }

            function getSearchConditions() {
                var searchConditions = $scope.model.columns.reduce(function (conditions, column) {
                    if (column.enableSearch === true && column.searchInput) {
                        conditions.searchBy.push(column.columnId);
                        conditions.searchInput.push(column.searchInput);
                    }
                    return conditions;
                }, { searchBy: [], searchInput: [] });
                return searchConditions.searchBy.length > 0 ? searchConditions : {};
            }

            function getSortConditions(columnId) {
                if(typeof columnId === "object" || $scope.model.isMultiSortApplied){ 
                    return _.cloneDeep($scope.model.multiSortColumns, true);
                }
                else if (columnId) { 
                    var sortColumn = _.find($scope.model.columns, { columnId: columnId });
                    var currentSortState = sortColumn.sortOrder;
                    $scope.model.columns.forEach(function (column) {
                        column.sortOrder = 0;
                    });
                    sortColumn.sortOrder = currentSortState === 0 ? 1 : -currentSortState;
                    return { 'sortBy': [columnId], 'sortOrder': [sortColumn.sortOrder] };
                }
                else {
                    var sortedColumn = _.find($scope.model.columns, function (column) {
                        return column.sortable === true && column.sortOrder !== 0;
                    });
                    return sortedColumn ? {
                        'sortBy': [sortedColumn.columnId],
                        'sortOrder': [sortedColumn.sortOrder]
                    } : {};
                }
            }
            function getPaginationParams(requestedPageNumber) {
                if (_.isObject($scope.model.pagination)) {
                    $scope.model.pagination.currentPageNumber = requestedPageNumber;
                    $scope.page.pageNumber = requestedPageNumber;
                    return { 'pageNumber': requestedPageNumber, 'recordsPerPage': $scope.table.recordsPerPage() };
                }
                else {
                    return {};
                }
            }

            function getQueryForAllConditions(requestedPageNumber, sortColumn) {
                return _.assign(getPaginationParams(requestedPageNumber), getSortConditions(sortColumn), getSearchConditions());
            }


            $scope.model.onChange = $scope.model.onChange || function (filterConditions) {
                uitkEvents.setScope($scope).emit('dynamicTable', $scope.componentId + '-controller-onChange', filterConditions);


                if ($scope.preLoadedData.length > 0) {
                    $scope.model.records = $scope.preLoadedData;
                    $scope.model.totalRecordsCount = $scope.preLoadedData.length;
                }

                if ($scope.updateOriginalRecords === true) {
                    $scope.model.records = _.clone($scope.model.originalRecords);
                    $scope.model.totalRecordsCount = $scope.model.records.length;
                    $scope.updateOriginalRecords = false;
                }


                if ($scope.model.originalRecords.length === 0) {
                    $scope.model.originalRecords = _.clone($scope.model.records);
                }


                if ($scope.customOnSortIsDefined === false) {
                    $scope.table.onSortEvent(filterConditions);
                }
                if ($scope.customOnPaginateIsDefined === false) {
                    $scope.table.onPaginateEvent(filterConditions);
                }
                if ($scope.customOnSearchIsDefined === false) {
                    $scope.table.onSearchEvent(filterConditions);
                }
            };


            $scope.model.onSort = $scope.model.onSort || function (columnId) {
                $scope.model.isMultiSortApplied = false;
                $scope.model.onChange(getQueryForAllConditions(1, columnId));
            };

            $scope.model.onRowSelect = $scope.model.onRowSelect || function (event, record, selected) {
                if ($scope.model.enableMultiSelect) {
                    $scope.model.onChange(getQueryForAllConditions($scope.model.pagination.currentPageNumber), $scope.table.onRowSelectEvent(event, record, selected));
                }
            };

            $scope.model.onSelectAllRows = $scope.model.onSelectAllRows || function (selectAll) {
                if ($scope.model.enableMultiSelect) {
                    $scope.model.onChange(getQueryForAllConditions($scope.model.pagination.currentPageNumber), $scope.table.onSelectAllRowsEvent(selectAll));
                }
            };

            $scope.model.onPaginate = $scope.model.onPaginate || function (requestedPageNumber) {
                $scope.page.pageNumberError = false;
                $scope.model.onChange(getQueryForAllConditions(requestedPageNumber));
            };

            $scope.model.onSearch = $scope.model.onSearch || function () {
                if($scope.model.loadPersistedModel !== true){
                    $scope.model.onChange(getQueryForAllConditions(1));
                }
            };

            $scope.model.onMultiSort = $scope.model.onMultiSort || function () {
                $scope.model.onChange(getQueryForAllConditions(1, $scope.model.multiSortColumns));
            };

            $scope.model.onLoad = $scope.model.onLoad || function (refresh) {

                if($scope.model.loadPersistedModel && typeof $scope.model.getPersistedModel == 'function'){
                    loadViewModel();
                }
                else {
                    if (refresh) {
                        $scope.model.onChange(_.assign({ refresh: true }, getQueryForAllConditions($scope.model.pagination ? $scope.model.pagination.currentPageNumber : 0)));
                    } else {
                        $scope.model.onChange(getQueryForAllConditions(1));
                    }
                }
                return refresh;
            };

            $scope.model.getPersistingModel = function(){
                var persistingModel = {
                    componentId : $scope.componentId
                };
                var that = this;
                _.forEach(['pagination','isMultiSortApplied','multiSortColumns'], function(property){
                    if(!_.isUndefined(that[property])){
                        persistingModel[property] = _.cloneDeep(that[property]);
                    }
                });
                persistingModel.columns = [];
                _.forEach(that.columns, function(column){
                    var persistingModelColumn = {};
                    _.forEach(['columnId','sortOrder','sortable','layoutOrder','enableSearch','searchInput','showColumnInTable'], function(property){
                        if(!_.isUndefined(column[property])){
                            persistingModelColumn[property] = column[property];
                        }
                    });
                    persistingModel.columns.push(persistingModelColumn);
                });
                return persistingModel;
            }

            function loadViewModel(){
                var persistedViewModel = $scope.model.getPersistedModel($scope.componentId);
                persistedViewModel.$promise.then(function(result){
                    if(result.pagination){
                        for(property in result.pagination){
                            $scope.model.pagination[property] = result.pagination[property];
                        }
                    }
                    if(result.columns){
                        _.forEach($scope.model.columns, function(column){
                            var persistedColumn = _.find(result.columns ,function(obj) { return obj.columnId === column.columnId; });
                            if(persistedColumn){
                                _.forEach(['sortOrder','sortable','layoutOrder','enableSearch','searchInput','showColumnInTable'], function(property){
                                    column[property] = persistedColumn[property];
                                });
                            }
                        });
                    }

                    $scope.model.isMultiSortApplied = result.isMultiSortApplied;
                    if(result.multiSortColumns){
                        $scope.model.multiSortColumns = _.cloneDeep(result.multiSortColumns);
                    }
                    $timeout(function(){
                        $scope.model.loadPersistedModel = false;
                        $scope.model.onChange(_.assign({ refresh: true }, getQueryForAllConditions($scope.model.pagination ? $scope.model.pagination.currentPageNumber : 0)));
                    });
                });
            }

            $scope.table = {
                onSortEvent: function (filterCondition) {

                    var filteredData = _.clone($scope.model.originalRecords).slice();

                    if (filterCondition.sortBy && filterCondition.sortBy.length > 0) {
                        filterCondition.sortBy.forEach(function (sortByField, index) { 
                            var sortOrder = filterCondition.sortOrder[index];
                            var colOption = _.find($scope.model.columns, 'combination'); 

                            if ( typeof colOption !== 'undefined' ) {
                                var combinedColumnId = colOption.columnId;
                                if (combinedColumnId === sortByField && sortOrder) {
                                    filteredData = _.sortBy(filteredData, function (row) {
                                        return columnCombinations(colOption.combination, row);
                                    });
                                    filteredData = sortOrder === -1 ? filteredData.reverse() : filteredData;
                                } else if (sortByField && sortOrder) {
                                    filteredData = _.sortBy(filteredData, sortByField);
                                    filteredData = sortOrder === -1 ? filteredData.reverse() : filteredData;
                                }
                            }
                            else {
                                if (sortByField && sortOrder) {
                                    filteredData = _.sortBy(filteredData, sortByField);
                                    filteredData = sortOrder === -1 ? filteredData.reverse() : filteredData;
                                }
                            }

                        });

                        $scope.model.totalRecordsCount = filteredData.length;
                        $scope.model.records = filteredData;
                    }
                },
                onSearchEvent: function (filterCondition) {
                    var filteredData = _.clone($scope.model.originalRecords).slice();

                    if (filterCondition.searchBy && filterCondition.searchBy.length > 0) {

                        filterCondition.searchBy.forEach(function (searchByItem, index) {
                            var searchExact = false,
                                searchType = 'exact',
                                columnToSearchByType = _.find($scope.model.columns, { searchByItemType: searchType });

                            if (typeof columnToSearchByType != 'undefined') {
                                searchExact = searchByItem.toLowerCase() === columnToSearchByType.columnId && columnToSearchByType.searchByItemType === searchType;
                            }

                            if (searchExact) {
                                filteredData = filteredData.filter(function (record) {
                                    return record[searchByItem].toLowerCase() === filterCondition.searchInput[index].toLowerCase();
                                });
                            } else { 
                                filteredData = filteredData.filter(function (record) {
                                    return _.includes(record[searchByItem].toLowerCase(), filterCondition.searchInput[index].toLowerCase());
                                });
                            }
                        });

                        $scope.model.totalRecordsCount = filteredData.length;
                        $scope.model.records = filteredData;
                    }
                },
                onRowSelectEvent: function (event, record, selected) {
                    var model = $scope.model, availableRecords = _.clone($scope.model.originalRecords).slice(), allSelected = true;

                    if (typeof selected === 'undefined') {
                        if (event.target.tagName === 'A' || event.target.tagName === 'INPUT') {
                            return;
                        }
                        record.selected = !record.selected;
                    }

                    var itemAlreadyExists = _.some(model.selectedRecords, function (item) {
                        return item === record;
                    });

                    if (itemAlreadyExists) {
                        model.selectedRecords.splice(record, 1);
                    } else {
                        model.selectedRecords.push(record);
                    }

                    if (availableRecords.length !== model.selectedRecords.length) {
                        allSelected = false;
                    } else {
                        allSelected = true;
                    }
                    model.selectAllChecked = allSelected;
                    model.totalRecordsCount = availableRecords.length;
                    model.records = availableRecords;
                    model.selectedRecordCount = model.selectedRecords.length;
                },
                onSelectAllRowsEvent: function (selectAll) {
                    var model = $scope.model, availableRecords = _.clone($scope.model.originalRecords).slice();
                    model.selectedRecords = [];

                    for (var row = 0 ; row < availableRecords.length ; row++) {
                        if (selectAll) {
                            availableRecords[row].selected = true;
                            model.selectedRecords.push(availableRecords[row]);
                        } else {
                            if (availableRecords[row].selected) {
                                availableRecords[row].selected = false;
                                model.selectedRecords = [];
                            }
                        }
                    }
                    model.totalRecordsCount = availableRecords.length;
                    model.records = availableRecords;
                    model.selectedRecordCount = model.selectedRecords.length;
                },
                onPaginateEvent: function (filterCondition) {

                    var filteredData = _.clone($scope.model.records).slice();
                    if (filterCondition.pageNumber && filterCondition.recordsPerPage) {
                        $scope.model.records = filteredData.splice(filterCondition.pageNumber > 1 ? ((filterCondition.pageNumber - 1) * filterCondition.recordsPerPage) : 0, filterCondition.recordsPerPage);
                    };

                },
                showPagination: function () {
                    return $scope.model.pagination;
                },
                recordsPerPage: function () {
                    return $scope.model.pagination ? $scope.model.pagination.recordsPerPage : $scope.model.totalRecordsCount;
                },
                totalPagesCount: function () {
                    var quotient = parseInt($scope.model.totalRecordsCount / $scope.table.recordsPerPage(), 10);
                    var remainder = ((($scope.model.totalRecordsCount === 0 ? 1 : $scope.model.totalRecordsCount) % $scope.table.recordsPerPage()) > 0 ? 1 : 0);
                    return quotient + remainder;
                },
                hasPreviousPage: function () {
                    return $scope.model.pagination.currentPageNumber === 1 ? false : true;
                },
                previousPageNumber: function () {
                    return $scope.model.pagination.currentPageNumber - 1;
                },
                hasNextPage: function () {
                    return this.totalPagesCount() !== $scope.model.pagination.currentPageNumber;
                },
                nextPageNumber: function () {
                    return $scope.model.pagination.currentPageNumber + 1;
                },
                lastPageNumber: function () {
                    return this.totalPagesCount();
                },
                sortOrderDescription: function (sortOrder) {
                    switch (sortOrder) {
                        case -1:
                            return tableSortEnum.DECENDING;
                        case 1:
                            return tableSortEnum.ASCENDING;
                        default:
                            return tableSortEnum.NONE;
                    }
                },
                clearAllFilters: function () {
                    ['pagination', 'columns', 'clearAllFilters'].forEach(function (attr) {
                        if ($scope.model.__init__[attr] && $scope.model.__init__[attr] instanceof Array) {
                            $scope.model.__init__[attr].forEach(function (el, index) {
                                for (var prop in el) {
                                    if (attr === 'columns' && prop !== 'layoutOrder') {
                                        $scope.model[attr][index][prop] = $scope.model.__init__[attr][index][prop];
                                    }
                                }
                            });
                        } else if ($scope.model.__init__[attr] && $scope.model.__init__[attr] instanceof Object) {
                            for (var prop in $scope.model.__init__[attr])
                                $scope.model[attr][prop] = $scope.model.__init__[attr][prop];
                        } else if ($scope.model.__init__[attr]) {
                            $scope.model[attr] = $scope.model.__init__[attr];
                        }
                    });
                    $scope.model.onChange(getQueryForAllConditions(1));
                },

                export: function () {
                    var filterConditions = _.assign(getSortConditions(), getSearchConditions());
                    filterConditions.pageNumber = 1;
                    filterConditions.recordsPerPage = $scope.model.totalRecordsCount;
                    $scope.model.onExport(filterConditions, function (result, fileName) {
                        var model = angular.copy($scope.model);
                        model.pagination = { currentPageNumber: 1, recordsPerPage: $scope.model.totalRecordsCount };
                        model.records = result.records;
                        model.totalRecordsCount = result.totalRecordsCount;
                        _.remove(model.columns, function (currentColumn) {
                            return currentColumn.excludeFromExport;
                        });
                        var content = uitkDynamicTableService.render(model);

                        $timeout(function () {
                            uitkDynamicTableExporter(content, fileName);
                        });
                        return model;
                    });
                },
                exportNestedData: function () {
                    var filterConditions = _.assign(getSortConditions(), getSearchConditions());
                    filterConditions.pageNumber = 1;
                    filterConditions.recordsPerPage = $scope.model.totalRecordsCount;
                    $scope.model.onExportNestedData(filterConditions);
                    return filterConditions;
                }
            };

            if (_.isObject($scope.model.pagination)) {
                $scope.model.pagination.currentPageNumber = $scope.model.pagination.currentPageNumber || 1;
                $scope.model.pagination.paginationWindow = $scope.model.pagination.paginationWindow || 5;
                $scope.model.pagination.recordsPerPage = $scope.model.pagination.recordsPerPage || 10;
                $scope.model.pagination.recordsPerPageChoices = $scope.model.pagination.recordsPerPageChoices || [10, 25, 50, 75, 100];
            }

            $scope.model.records = $scope.model.records || [];

            $scope.model.columns.forEach(function (column) {
                if (column.enableSearch === true) {
                    var columnIdRef = column.columnId;
                    column.searchInput = column.searchInput ? column.searchInput : '';
                    $scope.$watch(function ($scope) {
                        var col = _.find($scope.model.columns, { columnId: columnIdRef });
                        if (col) {
                            return col.searchInput;
                        }
                    }, _.after(2, $scope.model.onSearch));
                }
                if (column.sortable === true && !_.includes([1, 0, -1], column.sortOrder)) {
                    column.sortOrder = 0;
                }
            });

            if (!$scope.model.__init__) { 
                $scope.model.__init__ = {};
                ['pagination', 'columns', 'clearAllFilters','multiSortColumns'].forEach(function (attr) {
                    if ($scope.model[attr]) {
                        $scope.model.__init__[attr] = angular.copy($scope.model[attr]);
                    }
                });

                if ($scope.model.__init__.pagination && $scope.model.__init__.pagination.recordsPerPage) {
                    delete $scope.model.__init__.pagination.recordsPerPage;
                }
            }

            $scope.isRowsSelected = false;
            if ($scope.model) {
                $scope.$watch('model.selectedRecordCount', function (value) {
                    if (value > 0) {
                        $scope.isRowsSelected = true;
                    } else {
                        $scope.isRowsSelected = false;
                    }
                }, true);
            }
        }
        controller.$inject = ["$scope", "tableSortEnum", "uitkEvents", "$attrs", "uitkTools", "$element"];

        function link($scope, $element) {

            if ($element[0].id) {
                $scope.rowsDropdownId = $element[0].id + "_rppOptions";
            }

            if (!_.isEqual($scope.model.columns, _.uniq($scope.model.columns, 'columnId'))) {
                $element.html('Error : DuplicateColumnIdException');
                uitkExceptionService.throwException(
                    'DuplicateColumnIdException',
                    'Duplicate column id names found'
                );
            }
            var sortedColumnCount = _.filter($scope.model.columns, function (column) {
                return column.sortable === true && column.sortOrder !== 0;
            }).length;
            if (sortedColumnCount > 1) {
                $element.html('Error : MultipleColumnSortConfigurationError');
                uitkExceptionService.throwException(
                    'MultipleColumnSortConfigurationError',
                     'Use multiSortColumns for multi column sort'
                );
            }

            var allowedDataType = ['character', 'number', 'date', 'text', 'icon', 'checkbox'];
            _.forEach($scope.model.columns, function (column) {
                if (column.dataType && !_.includes(allowedDataType, column.dataType)) {
                    uitkExceptionService.throwException(
                        'DataTypeNotSupportedException',
                        column.dataType + ' is not supported'
                    );
                }
            });

            if ($scope.model.records.length === 0) {
                $scope.model.onLoad(true);
            }

            if ($scope.model.pagination) {
                $scope.pageNumberIsBad = function (pageNumber) {
                    return pageNumber != $scope.model.pagination.currentPageNumber && pageNumber < 0;
                };
                $scope.isPageNumberIsGood = function (pageNumber) {
                    return pageNumber != $scope.model.pagination.currentPageNumber && pageNumber > 0;
                };
                $scope.isPageNumberEqualToCurrent = function (pageNumber) {
                    return pageNumber === $scope.model.pagination.currentPageNumber;
                };

                $scope.page.pageNumber = $scope.model.pagination.currentPageNumber;
                $scope.page.pageNumberDescribedBy = $scope.componentId+'_pageNumber';

            };


            $scope.showTableOptions = $scope.model.clearAllFilters === true || $scope.model.onExport || $scope.model.onExportNestedData || ($scope.model.links && $scope.model.links.length !== 0);
            $scope.isFiltersClear = $scope.model.clearAllFilters === true;

            $scope.isFiltersApplied = function(){
                var filterApplied = false;
                _.forEach($scope.model.columns, function(column){
                    if(column.searchInput !== "" && column.searchInput !== undefined){
                        filterApplied = true;
                        return false;
                    }

                });
                return filterApplied;
            };
            $scope.isColumnSortable = function (column) {
                return column.sortable === true;
            };
            $scope.sortOrderEqualTo = function (column, order) {
                switch (order) {
                    case 1:
                        return column.sortOrder === order;
                        break;
                    case -1:
                        return column.sortOrder === order;
                        break;
                    case 0:
                        return column.sortOrder === order;
                        break;
                    default:
                        return column.sortOrder !== 0;
                        break;
                }
            };

            $scope.isMultiSortColumn = function(column) {
                var returnFlag = false;
                if($scope.model.isMultiSortApplied){
                    _.forEach($scope.model.multiSortColumns.sortBy, function(sortByColumn){
                        if(sortByColumn === column.columnId){
                            returnFlag = true;
                            return false;
                        }
                    });
                }
                return returnFlag;
            };

            $scope.multiSortOrderEqualTo = function (column, order) {
                var returnFlag = false;
                _.forEach($scope.model.multiSortColumns.sortBy, function(sortByColumn, index){
                    if(sortByColumn === column.columnId && $scope.model.multiSortColumns.sortOrder[index] === order){
                        returnFlag = true;
                        return false;
                    }
                });
                return returnFlag;
            };

            $scope.pageNumberEvent = function(event) {
                var key = event.keyCode || event.which;
                var pageNumber;

                if($scope.page.pageNumber) {
                    pageNumber = parseInt($scope.page.pageNumber, 10);
                }

                if(key == 13 || event.type === "blur") {
                    if(pageNumber === undefined || pageNumber < 1 || pageNumber > $scope.table.totalPagesCount()) {
                        $scope.page.pageNumberError = true;
                        $scope.page.pageNumberDescribedBy = $scope.componentId+'_pageError';
                        uitkLiveRegionService.alertMessage("Enter a valid number, one that is in the page range", true);
                        return;
                    } else {
                        $scope.page.pageNumberError = false;
                        $scope.page.pageNumberDescribedBy = $scope.componentId+'_pageNumber';
                        if(pageNumber != $scope.model.pagination.currentPageNumber) {
                            $scope.model.onPaginate(pageNumber);
                            uitkLiveRegionService.alertMessage("showing page "+$scope.page.pageNumber+"of "+$scope.table.totalPagesCount(), true);
                        }
                    }
                }
            };

            $scope.rowSelectedandEditing = $scope.model.onRowSelect && $scope.customOnEditRowIsDefined || $scope.usingCRUD;


            if ($scope.model.fixedHeader) {
                var $uitk_table, $uitk_table_ths, $uitk_table_lastRow, offsetTop, offsetBottom;

                $(window).scroll(
                    function () {
                        if (!$uitk_table) {
                            $uitk_table = angular.element("#" + $scope.componentId + " .tk-dtbl").first();
                            $uitk_table_ths = angular.element($uitk_table).find("th");
                            $uitk_table_lastRow = angular.element($uitk_table, "tbody > tr:last-child > td:first-child");
                            offsetTop = angular.element($uitk_table).offset().top;
                            offsetBottom = angular.element($uitk_table_lastRow).offset().top + angular.element($uitk_table_lastRow).outerHeight();
                        }

                        var winScroll = $(window).scrollTop();

                        if (winScroll - offsetTop > 0 && winScroll < offsetBottom) {
                            $uitk_table_ths.css({
                                "position": "relative",
                                "top": (winScroll - offsetTop - 1),
                                "background-color": "#f3f3f3",
                                "z-index": 2
                            });
                        } else {
                            $uitk_table_ths.css("top", 0);
                        }
                    }
                );
            }

            _.each($scope.model.columns, function(column){
                if(column.showAlways === undefined){
                    column.showAlways = false;
                }
                if(column.showColumnInTable === undefined){
                    column.showColumnInTable = true;
                }
                return column;
            });

        }

        return {
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
                model: '=',
                viewModel: '='
            },
            controller: controller,
            link: link,
            templateUrl: function (element, attrs) {
                return attrs.templateUrl || 'template/uitk-dynamic-table.html';
            }

        };
    };

    uitkDynamicTableService.$inject = ['$compile', '$rootScope', '$timeout'];
    uitkDynamicTable.$inject = ['$timeout', 'uitkDynamicTableService', 'uitkDynamicTableExporter', '$filter', 'uitkExceptionService', 'columnCombinations', 'uitkLiveRegionService'];

    angular.module('uitk.component.uitkDynamicTable', [
		'uitk.component.uitkNavigable',
		'uitk.component.ngCsv',
        'uitk.uitkUtility','uitk.component.uitkRadioGroup','uitk.component.uitkSelect'])
	.factory('uitkDynamicTableService', uitkDynamicTableService)
	.directive('uitkDynamicTable', uitkDynamicTable)
    .constant('tableSortEnum', {
        DECENDING: 'descending',
        ASCENDING: 'ascending',
        NONE: 'none'
    });

})();
(function() {
var uitkDynamicTableColumnDraggable = function ($parse,$timeout,uitkEvents) {
    function link($scope, $element, $attrs) {
        var isDraggable = false;
        if ($attrs.uitkDynamicTableColumnDraggable) {
            isDraggable = $parse($attrs.uitkDynamicTableColumnDraggable)($scope) ? true : false;
        }
        function croReleaseDraggingState(event) {
            var diff = new Date() - event.data.time;
            if (diff < 200) {
                $timeout.cancel(event.data.startDragging);
            } else {
                releaseDraggingState($(event.data.$th));
            }
        }
        function preventTextSelection() {
            return false;
        }
        function supportsTransitions() {
            var b = document.body || document.documentElement,
                s = b.style,
                p = 'transition';

            if (typeof s[p] === 'string') {
                return true;
            }

            var v = ['Moz', 'webkit', 'Webkit', 'Khtml', 'O', 'Ms'];
            p = p.charAt(0).toUpperCase() + p.substr(1);

            for (var i = 0; i < v.length; i++) {
                if (typeof s[v[i] + p] === 'string') {
                    return true;
                }
            }

            return false;
        }

        if (isDraggable) {

            $element.on("mousedown", function (event) {
                var $that = $(this);
                $timeout.cancel(startDragging);
                var time = new Date(); 
                var columnModel = _.find($scope.model.columns, {columnId: $(this).attr("aria-label")});

                                var startDragging = $timeout(function () {
                    if (!columnModel.resizeInProgress) {
                        setDraggingState($that, event);
                    }
                }, 200);

                $("body").on("mouseup",
                    {
                        $th: $that,
                        time: time,
                        startDragging: startDragging
                    },
                    croReleaseDraggingState);
            });
        }

        var thCoordinatesX = [];
        var thCoordinatesY = [];

        function setInitialState($th) {
            $th.parents("tr").find(".tk-dtbl-cro-dragging").remove();
            $th.parents("tr").find(".tk-dtbl-cro-ghost-overlay").remove();
            $th.parents("tr").find("th").removeClass("tk-dtbl-cro-ghost");
            $("body").off("mouseup", croReleaseDraggingState);
            $("body").removeClass("tk-dtbl-cro-invalid-target");
            $("*").off("selectstart", preventTextSelection)
        }

        function setDraggingState($th, event) {

            var $ghost = $("<table class='tk-dtbl tk-dtbl-cro-dragging tk-dtbl-cro-no-transition'><thead><tr></tr></thead></table>");
            var $content = $th.clone();
            var $siblings = $th.siblings("th");
            $ghost.find("tr").append($content);
            $th.prepend($ghost);
            $th.addClass("tk-dtbl-cro-ghost");
            var offset = $ghost.offset();

            $content.css("height", $th.height());

            $ghost.css("top", 0);
            $ghost.css("left", 0);

            var $overlay = $("<div class='tk-dtbl-cro-ghost-overlay'></div>");
            $overlay.width($th.innerWidth());
            $overlay.height($th.innerHeight());
            $overlay.insertAfter($ghost);

            $("body").addClass("oui-util-non-selectable-text tk-dtbl-cro-invalid-target");

            $ghost.focus();

            var horizontalDelta = event.pageX - offset.left;
            $th.attr("data-cro-cursor-delta", horizontalDelta);

            var verticalDelta = event.pageY - offset.top;
            $th.attr("data-cro-cursor-delta-y", verticalDelta);

            $("body").on("mousemove", {
                $th: $th
            }, draggingState)

            $ghost.on("transitionend", function () {
                $ghost.addClass("tk-dtbl-cro-no-transition");
            })

            $("*").on("selectstart", preventTextSelection);

            for (var i = 0; i < $siblings.length; i++) {
                thCoordinatesX[i] = $siblings.eq(i).offset().left;
            }
            thCoordinatesX[thCoordinatesX.length] = $siblings.last().offset().left + $siblings.last().outerWidth();
            thCoordinatesY[0] = $th.offset().top;
            thCoordinatesY[1] = $th.offset().top + $th.outerHeight();

            if (!supportsTransitions()) {
                $ghost.trigger("transitionend");
            }
        }

        function releaseDraggingState($th) {

            var $ghost = $th.find(".tk-dtbl-cro-dragging");

            $("body").removeClass("oui-util-non-selectable-text");
            $ghost.removeClass("tk-dtbl-cro-no-transition");

            $("body").off("mousemove", draggingState);


            if ($th.siblings(".tk-dtbl-cro-target-before").length > 0) {
                var $target = $th.siblings(".tk-dtbl-cro-target-before").first();
                var newLeft = 0;
                var leftToRight = ($target.offset().left > $th.offset().left) ? true : false;
                if (leftToRight) {
                    newLeft = ($target.offset().left - $th.offset().left - $th.outerWidth());
                } else {
                    newLeft = ($target.offset().left - $th.offset().left);
                }
                $ghost.css({
                    "top": 0,
                    "left": newLeft
                })
                $ghost.on("transitionend", function () {
                    moveColumn($th, $target, true); 
                    setInitialState($th);
                    removeTargets();
                    $("[data-cro-cursor-delta]").removeAttr("data-cro-cursor-delta");
                    $("[data-cro-cursor-delta]").removeAttr("data-cro-cursor-delta-y");
                });
            } else if ($th.siblings(".tk-dtbl-cro-target-after").length > 0) {
                $target = $th.siblings(".tk-dtbl-cro-target-after").first();
                newLeft = 0;
                leftToRight = ($target.offset().left > $th.offset().left) ? true : false;
                if (leftToRight) {
                    newLeft = ($target.offset().left - $th.offset().left + $target.outerWidth() - $th.outerWidth());
                } else {
                    newLeft = ($target.offset().left - $th.offset().left + $target.outerWidth());
                }
                $ghost.css({
                    "top": 0,
                    "left": newLeft
                })
                $ghost.on("transitionend", function () {
                    moveColumn($th, $target, false); 
                    setInitialState($th);
                    removeTargets();
                    $("[data-cro-cursor-delta]").removeAttr("data-cro-cursor-delta");
                })
            } else {
                $ghost.css({
                    "left": 0,
                    "top": 0
                });
                $ghost.on("transitionend", function () {
                    setInitialState($th);
                    $("[data-cro-cursor-delta]").removeAttr("data-cro-cursor-delta");
                });

                if (parseInt($ghost.css("left"), 10) === 0 &&
                    parseInt($ghost.css("top"), 10) === 0) {
                    $ghost.trigger("transitionend");
                }
            }

            if (!supportsTransitions()) {
                $ghost.trigger("transitionend");
            }
        }

        function draggingState(event) {
            var $th = event.data.$th;

            var $ghost = $th.find(".tk-dtbl-cro-dragging");
            var newLeft = event.pageX - $th.offset().left - $th.attr("data-cro-cursor-delta");
            var newTop = event.pageY - $th.offset().top - $th.attr("data-cro-cursor-delta-y");
            $ghost.css("left", newLeft);
            $ghost.css("top", newTop);

            var x = event.pageX;
            var y = event.pageY;
            if ((x > thCoordinatesX[0]) &&
                (x < thCoordinatesX[thCoordinatesX.length - 1]) &&
                (y > thCoordinatesY[0]) &&
                (y < thCoordinatesY[thCoordinatesY.length - 1])) {
                var i = 0;
                while (x > thCoordinatesX[i]) {
                    i++;
                }
                --i;
                potentialTargetEntry($th.siblings("th").eq(i), $th, x);
            } else {
                removeTargets();
            }
        }
        function potentialTargetEntry($th, $og, x) {

            var midpoint = .5 * $th.innerWidth();
            midpoint += $th.offset().left;
            var before = (x < midpoint) ? true : false;

            if ((before && $th.prev("th.tk-dtbl-cro-ghost").length > 0) ||
                (!before && $th.next("th.tk-dtbl-cro-ghost").length > 0)) {
                removeTargets();
                return;
            }

            var classToAdd = (before) ? "tk-dtbl-cro-target-before" : "tk-dtbl-cro-target-after";
            if ((before && $og.hasClass("tk-dtbl-cro-target-before")) ||
                (!before && $og.hasClass("tk-dtbl-cro-target-after"))) {
                return;
            }
            removeTargets();
            $th.addClass(classToAdd);
            if ($th.find(".tk-dtbl-cro-target").length < 1) {
                var $target = $("<div class='tk-dtbl-cro-target'></div>");
                $target.height($th.innerHeight());
                $th.prepend($target);
            }
        }

        function removeTargets() {
            $(".tk-dtbl-cro-target-after, .tk-dtbl-cro-target-before").removeClass("tk-dtbl-cro-target-after tk-dtbl-cro-target-before");
            $(".tk-dtbl-cro-target").remove();
        }

        function moveColumn($th, $target, before) {

            var draggedColumn = _.find($scope.model.columns, {columnId: $($th).attr("aria-label")});
            var dropColumn = _.find($scope.model.columns, {columnId: $($target).attr("aria-label")});
            var dropColumnLayoutOrder = dropColumn.layoutOrder;
            var componentId = $scope.$parent.componentId;

            $scope.$apply(function () {
                if (dropColumnLayoutOrder >= 1 && draggedColumn.layoutOrder > dropColumn.layoutOrder && !before) { 
                    dropColumnLayoutOrder++;
                } else if (dropColumnLayoutOrder <= $scope.model.columns.length && draggedColumn.layoutOrder < dropColumn.layoutOrder && before) { 
                    dropColumnLayoutOrder--;
                }

                if (draggedColumn.layoutOrder > dropColumn.layoutOrder) {
                    $scope.model.columns.forEach(function (column) {
                        if (column.layoutOrder >= dropColumnLayoutOrder && column.layoutOrder < draggedColumn.layoutOrder) {
                            column.layoutOrder++;
                        }
                    });
                } else if (draggedColumn.layoutOrder < dropColumn.layoutOrder) {
                    $scope.model.columns.forEach(function (column) {
                        if (column.layoutOrder <= dropColumnLayoutOrder && column.layoutOrder > draggedColumn.layoutOrder) {
                            column.layoutOrder--;
                        }
                    });
                }

                draggedColumn.layoutOrder = dropColumnLayoutOrder;
            });

            uitkEvents.setScope().internalBroadcast("broadcast", componentId+"-dragColumns");
        }
        function guh() {
            $("*").removeAttr("ng-class ng-repeat ng-attr-style");
        }


    }

    return {
        restrict: 'A',
        replace: false,
        scope: false,
        link: link
    };
};

uitkDynamicTableColumnDraggable.$inject = ['$parse','$timeout','uitkEvents'];

angular.module('uitk.component.uitkDynamicTable')
    .directive('uitkDynamicTableColumnDraggable', uitkDynamicTableColumnDraggable);

})();

(function () {

    var uitkCompileLabel = function ($compile) {
        return function ($scope, $element) {
            $compile($scope.column.label)($scope, function (clone) {
                if (!clone.selector) {
                    $element.append(clone);
                } else {
                    $element.append(clone.selector);
                }
            });
        };
    };

    var uitkCompileCellTemplate = function ($compile) {
        var compiledTemplate = _.memoize(function (value) {
            return $compile(value);
        });

        return function ($scope, $element, $attrs) {
            if (angular.isDefined($scope.link)) {
                if(typeof $scope.link==='string') {
                    $compile($scope.link)($scope, function (clone) {
                        $element.append(clone);
                    });
                } else {
                    var cur = '<a tabindex=0 href="' + $scope.link.href
                        + '" title="' + $scope.link.title
                        + '" ng-click="' + $scope.link.click + '">'
                        + $scope.link.text + '</a>';
                    var comp = $compile(cur)($scope);
                    $element.append(comp);
                }
            }
            else if (angular.isUndefined($scope.currentRecord)) { 
                compiledTemplate($scope.column[$attrs.uitkCompileCellTemplate])($scope, function (clone) {
                    $element.append(clone);
                });
            }
            else { 
                $scope.record = $scope.currentRecord;
                compiledTemplate($scope.model.rowTemplate)($scope, function (clone) {
                    $element.append(clone);
                });
            }
        };
    };

    var uitkResizableColumn = function ($document, $timeout) {
        function link($scope, $element) {
            var column = $element.parent();
            var table = column.parent().parent().parent(); 
            var padding = 20  + 2 ;
            var startX = 0, tableWidth = 0;
            var min_width = 0;
            var columnModel = _.find($scope.model.columns, { columnId: $scope.column.columnId });
            columnModel.resizeInProgress = false;
            columnModel.setWidth = function (width) {
                column.css({ 'width': width + 'px' });
            };
            columnModel.getWidth = function () {
                return parseInt(column.css('width'), 10);
            };
            columnModel.isWidthModifiable = function (width) {
                return width > min_width;
            };

            $timeout(function () {
                if($.isFunction(column.innerWidth)) {
                    column.css({ 'width': (column.innerWidth()) + 'px' });
                }

                min_width = (column.prop('offsetWidth') - padding) / 2;
            });

            $element.on('mousedown', function (event) {
                event.preventDefault();
                startX = event.screenX;
                column = $element.parent();
                table = column.parent().parent().parent(); 
                min_width = (column.prop('offsetWidth') - padding) / 2;
                tableWidth = table.prop('offsetWidth');
                $document.on('mousemove', mousemove);
                $document.on('mouseup', mouseup);
                $scope.$apply(function () {
                    columnModel.resizeInProgress = true;
                });

            });

            function mousemove(event) {
                var cursorChangedBy = (event.screenX - startX);
                var width = parseInt(column.css('width'), 10) + cursorChangedBy;
                var nextColumnModel = _.chain($scope.model.columns).filter(function (col) {
                    return col.layoutOrder > columnModel.layoutOrder;
                }).min('layoutOrder').value();
                if (width > min_width && nextColumnModel.isWidthModifiable(nextColumnModel.getWidth() - cursorChangedBy)) {
                    nextColumnModel.setWidth(nextColumnModel.getWidth() - cursorChangedBy);
                    columnModel.setWidth(width);
                    table.css({ 'width': tableWidth + 'px' });
                    startX = event.screenX;
                }
            }

            function mouseup() {
                $scope.$apply(function () {
                    columnModel.resizeInProgress = false;
                });
                $document.off('mousemove', mousemove);
                $document.off('mouseup', mouseup);
            }
        }

        return {
            scope: false,
            link: link
        };
    };

    var uitkSelectable = function ($parse) {

        function link($scope, $element, $attrs) {
            var isSelectable = true;
            if ($attrs.uitkSelectable) {
                isSelectable = $parse($attrs.uitkSelectable)($scope) ? true : false;
            }
            if (isSelectable) {
                $element.attr('tabindex', 0);
                if ($element.attr('ng-click')) {
                    var fn = $parse($element.attr('ng-click'));
                    $element.on('keydown', keydownHandler(fn));
                    $element.on('keyup', keyupHandler(fn));
                }
            }
        };

        function keydownHandler(event, fn) {
            if (event.which === 13 || event.which === 32) { 
                $scope.$apply(function () {
                    fn($scope, { $event: event });
                });
            }
            if (event.which === 32) {
                event.preventDefault();
            }
        };

        function keyupHandler(event, fn) {
            if (event.which === 32) { 
                $scope.$apply(function () {
                    fn($scope, { $event: event });
                });
                event.preventDefault();
            }
        };

        return {
            restrict: 'A',
            replace: false,
            scope: false,
            link: link
        };
    };


    var uitkDrawerContent = function (drawerSlide, $filter) {

        function link($scope, $element) {

            var rowUniqueId = $scope.componentId + '_' + ((typeof $scope.rowRecord !== 'undefined') ? $scope.rowRecord.index : '');

            $scope.model.recordOperationInProgress = false;

            $scope.$on(rowUniqueId + "-openDrawer", function (e, v) {
                drawerSlide($element);
            });

            $scope.$on(rowUniqueId + "-closeDrawer", function (e, v) {
                drawerSlide($element, true);
            });


        };

        return {
            restrict: 'A',
            replace: true,
            scope: {
                model: "=",
                componentId: "=",
                isEditing: "=",
                rowRecord: '='
            },
            templateUrl: "template/openDrawerContent.html",
            link: link
        };
    };


    var uitkDrawerAction = function (drawerSlide, uitkEvents, $log, columnCombinations) {
        function link($scope, $element) {

            var rowUniqueId = $scope.componentId + '_' + ((typeof $scope.rowRecord !== 'undefined') ? $scope.rowRecord.index : '');
            $scope.$on(rowUniqueId + "-openDrawer", function (e, v) {
                drawerSlide($element);
            });

            $scope.$on(rowUniqueId + "-closeDrawer", function (e, v) {
                drawerSlide($element, true);
            });

            $scope.model.recordOperationInProgress = false;

            var resetColumnInputError = function () {
                $scope.model.columnInput.error = {};
            };

            var resetColumns = function (record) {
                angular.forEach($scope.model.columns, function (e, i) {
                    if ( _.isObject(record) ) {
                        if (e.combination) {
                            if (e.combination.length > 0) {
                                $scope.model.columnInput[e.columnId] = columnCombinations(e.combination,record);
                            }
                        } else {
                            $scope.model.columnInput[e.columnId] = record[e.columnId];
                        };
                    }
                    else {
                        $scope.model.columnInput[e.columnId] = "";
                    }

                });
                resetColumnInputError();
            };

            var saveAndUpdateRecord = function($scope, actualRecord) {
                var _model = $scope.model;

                var val = function (e) {
                    var validate = (e.validationPattern);
                    if (typeof validate !== 'undefined') { 
                        validate = validate.test(_model.columnInput[e.columnId].toString());
                    } else {
                        validate = true;
                    }
                    return validate;
                };

                angular.forEach(_model.columns, function (e, i) {
                    delete _model.columnInput.error[e.columnId];
                    if (typeof e.validationPattern !== 'undefined' && _.isEmpty(_model.columnInput[e.columnId].toString()) || (_model.columnInput[e.columnId] && !val(e))) {
                        _model.columnInput.error[e.columnId] = true;
                    }
                });

                if (_.isEmpty(_model.columnInput.error)) {
                    if (!_model.crudOptions.saveRecord) {
                        $log.warn("saveRecord method not provided on viewModel. (Note:saveRecord should return a promise.)");
                        return null;
                    }
                    var prommiseToSave = _model.crudOptions.saveRecord(_model.columnInput);
                    if (typeof prommiseToSave.then !== 'function') {
                        $log.warn("No promise was provided therefore no external saving");
                        return null;
                    }

                    prommiseToSave.then(function (recordInfo) {
                        if (recordInfo.record === null) {
                            if (_model.crudOptions.notificationMessage) {
                                _model.crudOptions.notificationMessage.content = "<span>" + recordInfo.message + "</span>";
                                _model.crudOptions.notificationMessage.messageType = "error";
                                _model.crudOptions.notificationMessage.visible = true;
                            }
                            return null;
                        }

                        if (_model.crudOptions.notificationMessage) {
                            _model.crudOptions.notificationMessage.content = "<span>" + recordInfo.message + "</span>";
                            _model.crudOptions.notificationMessage.visible = true;
                        }

                        resetColumns();

                        uitkEvents.setScope().internalBroadcast("broadcast", _model.recordUniqueId + "-closeDrawer", _model.recordUniqueId);

                        if ( typeof (actualRecord) === 'undefined' ) { 
                            _model.originalRecords.push(recordInfo.record);
                        }
                        else {
                            var foundIdx = _.findIndex(_model.originalRecords, actualRecord);

                            if ( foundIdx > -1 ) {
                                _model.originalRecords[foundIdx] = recordInfo.record;
                            }
                            else {
                                _model.originalRecords.push(recordInfo.record);
                            }
                        }
                        $scope.updateOriginalRecords = true;
                        _model.onLoad(true);
                        _model.recordOperationInProgress = false;
                    }, function (reason) {
                    });
                }
                return true;
            };

            var deleteRecord = function($scope, actualRecord) {
                var _model = $scope.model;

                _model.recordOperationInProgress = true;

                var foundIdx = _.findIndex(_model.originalRecords, actualRecord);

                if ( foundIdx > -1 ) { 
                    var removedArray = _.pullAt(_model.originalRecords, foundIdx);
                    if (!_model.crudOptions.deleteRecord) {
                        $log.warn("deleteRecord method not provided on viewModel. (Note:deleteRecord should return a promise.)");
                        return null;
                    }
                    var prommiseToDelete = _model.crudOptions.deleteRecord(actualRecord);
                    if (typeof prommiseToDelete.then !== 'function') {
                        $log.warn("No promise was provided therefore no external saving");
                        return null;
                    }

                    prommiseToDelete.then(function (recordInfo) {
                        if (recordInfo.record === null) {
                            if (_model.crudOptions.notificationMessage) {
                                _model.crudOptions.notificationMessage.content = "<span>" + recordInfo.message + "</span>";
                                _model.crudOptions.notificationMessage.messageType = "error";
                                _model.crudOptions.notificationMessage.visible = true;
                            }
                            return null;
                        }

                        if (_model.crudOptions.notificationMessage) {
                            _model.crudOptions.notificationMessage.content = "<span>" + recordInfo.message + "</span>";
                            _model.crudOptions.notificationMessage.visible = true;
                        }
                    }, function (reason) {
                    });

                    _model.modalShown = false;

                    _model.onLoad(true);
                    _model.recordOperationInProgress = false;

                }
            };

            $scope.model.openDrawer = $scope.model.openDrawer || function (record) {
                resetColumns();
                if ($scope.model.recordOperationInProgress) {
                    $scope.model.showErrorMessage();
                    return;
                }

                var recordUniqueId = rowUniqueId;
                if ( typeof record !== 'undefined' ) {
                    recordUniqueId = $scope.componentId + '_' + record.index;
                }
                $scope.model.recordUniqueId = recordUniqueId;

                uitkEvents.setScope().internalBroadcast("broadcast", recordUniqueId + "-openDrawer", recordUniqueId);

                resetColumnInputError();
                if (_.isObject(record)) {
                    resetColumns(record);

                    record.hideRecord = true;

                    $scope.isEditing = true;
                }
                else {
                    $scope.isEditing = false;
                }

                $scope.model.recordOperationInProgress = true;
                return true;
            };

            $scope.model.modifyRow = function (isEditing, isCancelling,record, event) {
                if (isCancelling) {
                    if (isEditing) {
                       return $scope.model.onEditRowCancel(record, event);
                    } else {
                        return $scope.model.onAddRowCancel();
                    }
                }
                else {
                    if (isEditing) {
                        return $scope.model.onEditRow(record, event);
                    } else {
                        return $scope.model.onAddRow();
                    }
                }
            };

            $scope.model.onEditRow = $scope.model.onEditRow || function (record) {
                saveAndUpdateRecord($scope, record);
                record.hideRecord = false;
                return true;
            };

            $scope.model.onAddRow = $scope.model.onAddRow || function () {
               return saveAndUpdateRecord($scope);
            };

            $scope.model.onAddRowCancel = $scope.model.onAddRowCancel || function () {
                resetColumns();
                uitkEvents.setScope().internalBroadcast("broadcast", $scope.model.recordUniqueId + "-closeDrawer", $scope.model.recordUniqueId);
                $scope.model.recordOperationInProgress = false;
                return true;
            };

            $scope.model.onEditRowCancel = $scope.model.onEditRowCancel || function(record) {
                resetColumns(record);
                uitkEvents.setScope().internalBroadcast("broadcast", $scope.model.recordUniqueId + "-closeDrawer", $scope.model.recordUniqueId);
                $scope.model.recordOperationInProgress = false;
                record.hideRecord = false;
                return true;
            };

            $scope.model.onDelete = $scope.model.onDelete || function(record) {
                if ($scope.model.recordOperationInProgress) {
                    $scope.model.showErrorMessage();
                    return;
                }

                $scope.model.modalShown = true;
                if ($scope.model.selectedRecords.length == 0 && _.isObject(record) ) {
                    $scope.model.record = record;
                }
                return true;
            };

            $scope.model.onDeleteConfirm = function() {

                if ( $scope.model.selectedRecords.length > 0 ) {
                    angular.forEach($scope.model.selectedRecords, function(key, value) {
                        deleteRecord($scope, key);
                    });
                    $scope.model.selectedRecords = [];
                }
                else {
                    if (_.isObject($scope.model.record) ) {
                        deleteRecord($scope, $scope.model.record);
                    }
                    else {
                        $scope.model.modalShown = false;
                    }
                }
                return true;
            }

            $scope.model.onDeleteCancel = function() {
                $scope.model.modalShown = false;
                return true;
            };
        };

        return {
            restrict: 'A',
            replace: true,
            scope: {
                model: "=",
                componentId: "=",
                isEditing: "=",
                rowRecord: '='
            },
            templateUrl: "template/openDrawerAction.html",
            link: link
        };
    };

    var uitkMultiSortDrawerContent = function (drawerSlide) {

        function link($scope, $element) {

            $scope.dropDownItems = [];

            $scope.textRadioItems = [ {
                label : 'A to Z',
                value : 'ascending'
            },{
                label : 'Z to A',
                value : 'descending'
            }];

            $scope.numberRadioItems = [ {
                label : '0 to 9',
                value : 'ascending'
            },{
                label : '9 to 0',
                value : 'descending'
            }];

            $scope.dateRadioItems = [ {
                label : 'Newest to Oldest',
                value : 'ascending'
            },{
                label : 'Oldest to Newest',
                value : 'descending'
            }];

            $scope.addAnotherColumn = function(){
                var multiSortColumn = {
                    sortOrder: 0
                };
                $scope.model.multiSortColumnsInDrawer ? $scope.model.multiSortColumnsInDrawer.push(multiSortColumn) : $scope.model.multiSortColumnsInDrawer = [multiSortColumn];
            };

            $scope.removeColumn = function(index) {
                $scope.model.multiSortColumnsInDrawer.splice(index, 1);
            };

            var componentId = $scope.componentId;

            $scope.$on(componentId + "-openMultiSortDrawer", function (e, v) {
                $scope.initMultiSortDrawer();
                drawerSlide($element);
            });

            $scope.$on(componentId + "-closeMultiSortDrawer", function (e, v) {
                drawerSlide($element, true);
            });

            $scope.restoreDefault = function(){

                $scope.model.multiSortColumnsInDrawer = [];
                if($scope.model.__init__.multiSortColumns && $scope.model.__init__.multiSortColumns.sortBy){
                    _.forEach($scope.model.__init__.multiSortColumns.sortBy, function(obj, index){
                        var selectedIndex = _.findIndex($scope.dropDownItems, function(object){
                            return object.value == obj;
                        });
                        $scope.model.multiSortColumnsInDrawer.push({
                            selectedColumn : $scope.dropDownItems[selectedIndex],
                            sortOrder : $scope.model.__init__.multiSortColumns.sortOrder[index] === 1? 0 : 1
                        });
                    });
                }

                if($scope.model.multiSortColumnsInDrawer.length === 0){
                    var newColumn = {
                        selectedColumn : $scope.dropDownItems[0],
                        sortOrder : 0
                    };
                    $scope.model.multiSortColumnsInDrawer = [newColumn];
                }
            };

            $scope.initMultiSortDrawer = function () {

                $scope.dropDownItems = [];
                _.each(_.sortBy($scope.model.columns,'layoutOrder'), function(column){
                    if(column.sortable == false && column.showColumnInTable == true ){
                        $scope.dropDownItems.push({'label':column.label + " (not sortable)", value:column.columnId, isDisabled:true, dataType:column.dataType});
                    }
                    else if(column.showColumnInTable == true){
                        $scope.dropDownItems.push({'label':column.label, value:column.columnId, dataType:column.dataType});
                    }

                });

                $scope.model.multiSortColumnsInDrawer = [];
                if($scope.model.multiSortColumns && $scope.model.multiSortColumns.sortBy){
                    _.forEach($scope.model.multiSortColumns.sortBy, function(obj, index){
                        var selectedIndex = _.findIndex($scope.dropDownItems, function(object){
                            return object.value == obj;
                        });
                        $scope.model.multiSortColumnsInDrawer.push({
                           selectedColumn : $scope.dropDownItems[selectedIndex],
                           sortOrder : $scope.model.multiSortColumns.sortOrder[index] === 1? 0 : 1
                        });
                    });
                }

                if($scope.model.multiSortColumnsInDrawer.length === 0){
                    var newColumn = {
                        selectedColumn : $scope.dropDownItems[0],
                        sortOrder : 0
                    };
                    $scope.model.multiSortColumnsInDrawer = [newColumn];
                }
            };

        };

        return {
            restrict: 'A',
            replace: true,
            scope: {
                model: "=",
                componentId: "="
            },
            templateUrl: "template/multiSortDrawerContent.html",
            link: link
        };
    };

    var uitkMultiSortDrawerAction = function (drawerSlide, uitkEvents) {

        function link($scope, $element) {

            var componentId = $scope.componentId;

            $scope.$on(componentId + "-openMultiSortDrawer", function (e, v) {
                drawerSlide($element);
            });

            $scope.$on(componentId + "-closeMultiSortDrawer", function (e, v) {
                drawerSlide($element, true);
            });

            $scope.model.openMultiSortDrawer = $scope.model.openMultiSortDrawer || function(event){

                if ($scope.model.recordOperationInProgress) {
                    if(typeof $scope.model.showErrorMessage == 'function'){
                        $scope.model.showErrorMessage();
                    }
                    return;
                }
                uitkEvents.setScope().internalBroadcast("broadcast",componentId + "-openMultiSortDrawer");

                $scope.model.recordOperationInProgress = true;
                return true;
            };

            $scope.model.closeMultiSortDrawer = $scope.model.closeMultiSortDrawer || function(event){
                uitkEvents.setScope().internalBroadcast("broadcast",componentId + "-closeMultiSortDrawer");

                $scope.model.recordOperationInProgress = false;
                return true;
            };

            $scope.model.saveMultiSortColumns = $scope.model.saveMultiSortColumns || function() {

                var sortBy = [];
                var sortOrder = [];
                _.forEach($scope.model.multiSortColumnsInDrawer, function(obj){
                    sortBy.push(obj.selectedColumn.value);
                    sortOrder.push(obj.sortOrder === 0 ? 1 : -1); 
                });
                $scope.model.multiSortColumns = {sortBy : sortBy, sortOrder: sortOrder};
                $scope.model.multiSortColumnsInDrawer = {};


                if(!$scope.model.isMultiSortApplied){
                    $scope.model.isMultiSortApplied = true;
                    _.forEach($scope.model.columns, function(column){
                       if(column.sortOrder === -1 || column.sortOrder === 1){
                           column.sortOrder = 0;
                       }
                    });
                }
                $scope.model.onMultiSort();

                if(typeof $scope.model.showSuccessMessage == 'function'){
                    $scope.model.showSuccessMessage('Your column sort preference were successfully saved.');
                }
                $scope.model.closeMultiSortDrawer();
            };

        };

        return {
            restrict: 'A',
            replace: true,
            scope: {
                model: "=",
                componentId: "="
            },
            templateUrl: "template/multiSortDrawerAction.html",
            link: link
        };
    };

    var uitkShowHideColumnsDrawerContent = function (drawerSlide, $filter) {

        function link($scope, $element) {
            var componentId = $scope.componentId;

            $scope.$on(componentId + "-openShowHideColumnsDrawer", function (e, v) {
                drawerSlide($element);
            });

            $scope.$on(componentId + "-closeShowHideColumnsDrawer", function (e, v) {
                drawerSlide($element, true);
            });

            $scope.$on(componentId + "-dragColumns", function (e, v) {
                $scope.model.showHideFilterColumns = angular.copy($scope.model.columns);
            });

            var orderBy = $filter('orderBy');
            $scope.order = function(predicate) {
                $scope.predicate = predicate;
                $scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
                $scope.columnsList = orderBy($scope.columnsList, predicate, $scope.reverse);
            };

            $scope.model.showHideFilterColumns = angular.copy($scope.model.columns);


            var resetFilterColumns = angular.copy($scope.model.columns);

            $scope.restoreDefault = function(){
                $scope.model.columns = angular.copy(resetFilterColumns);
            }

        };

        return {
            restrict: 'A',
            replace: true,
            scope: {
                model: "=",
                componentId: "=",
                isEditing: "="
            },
            templateUrl: "template/openColumnsDrawerContent.html",
            link: link
        };
    };

    var uitkShowHideColumnsDrawerAction = function (drawerSlide, uitkEvents) {

        function link($scope, $element) {
            var componentId = $scope.componentId;

            $scope.$on(componentId + "-openShowHideColumnsDrawer", function (e, v) {
                drawerSlide($element);
            });

            $scope.$on(componentId + "-closeShowHideColumnsDrawer", function (e, v) {
                drawerSlide($element, true);
            });

            $scope.model.openShowHideColumnsDrawer = $scope.model.openShowHideColumnsDrawer || function (record) {

                angular.element('.tk-dtbl-reorderable-columns').css('width','auto');
                angular.element('.tk-dtbl-reorderable-columns > tr > th').css('width','auto');

                uitkEvents.setScope().internalBroadcast("broadcast", componentId + "-openShowHideColumnsDrawer");

                $scope.model.recordOperationInProgress = true;
                return true;
            };

            $scope.model.showHideColumnDrawerCancel = $scope.model.showHideColumnDrawerCancel || function () {
                uitkEvents.setScope().internalBroadcast("broadcast", componentId + "-closeShowHideColumnsDrawer");
                $scope.model.recordOperationInProgress = false;
                return true;
            };

            $scope.model.modifyColumn = $scope.model.modifyColumn || function (isCancelling, event) {

                if (isCancelling) {
                    $scope.model.columns = angular.copy($scope.model.showHideFilterColumns);

                                    }
                else {
                    $scope.model.showHideFilterColumns = angular.copy($scope.model.columns);
                    if(typeof $scope.model.showSuccessMessage == 'function'){
                        $scope.model.showSuccessMessage('Your column preferences were successfully changed. Drag columns left or right to change the order displayed.');
                    }
                    uitkEvents.setScope().internalBroadcast("broadcast",componentId + "-showHideColumns");
                }
                return $scope.model.showHideColumnDrawerCancel();
            };

        };

        return {
            restrict: 'A',
            replace: true,
            scope: {
                model: "=",
                componentId: "=",
                isEditing: "="
            },
            templateUrl: "template/openColumnsDrawerAction.html",
            link: link
        };
    };



    var drawerSlide = function () {
        return function ($element, slidingUp) {
            var ele = angular.element("td > div", $element);
            if (slidingUp) {
                angular.element(ele).slideUp(400, "linear", function () {
                    angular.element(ele).slideUp(400, "linear", function () {
                        angular.element("a:first", ele).focus();
                    });
                });
            } else {
                angular.element(ele).slideDown(400, "linear", function () {
                    angular.element(ele).slideDown(400, "linear", function () {
                        angular.element("input:first", ele).focus();
                    });
                });
            }

        }
    };

    var displayColumnFilter = function() {
          return function(columns) {
            var filtered = [];
            _.each(columns, function(column) {
              if(column.showColumnInTable) {
                filtered.push(column);
              }
            });
            return filtered;
          };
      }


        var columnCombinations = function () {
        return function (list, record) {

            var result = "";
            angular.forEach(list, function (value, index) {
                var pat = /\{(.*)\}/i
                var newVal = value.match(pat);
                if (newVal.length > 0) {
                    var recordPiece = value.replace(newVal[0], record[newVal[1]]);
                    result += recordPiece; 
                }
            });
            return result;
        }
    };

    uitkMultiSortDrawerContent.$inject = ["drawerSlide"];
    uitkMultiSortDrawerAction.$inject = ["drawerSlide","uitkEvents"];

    uitkShowHideColumnsDrawerContent.$inject = ["drawerSlide", "$filter"];
    uitkShowHideColumnsDrawerAction.$inject = ["drawerSlide", "uitkEvents"];

    uitkDrawerAction.$inject = ["drawerSlide", "uitkEvents", "$log", "columnCombinations"];
    uitkDrawerContent.$inject = ["drawerSlide","$filter"];

    uitkCompileLabel.$inject = ['$compile'];
    uitkCompileCellTemplate.$inject = ['$compile'];

    uitkResizableColumn.$inject = ['$document', '$timeout'];
    uitkSelectable.$inject = ['$parse'];

    angular.module('uitk.component.uitkDynamicTable')
        .filter("displayColumnFilter",displayColumnFilter)
        .directive('uitkCompileLabel', uitkCompileLabel)
        .directive('uitkCompileCellTemplate', uitkCompileCellTemplate)
        .directive('uitkResizableColumn', uitkResizableColumn)
        .directive('uitkSelectable', uitkSelectable)
        .directive('uitkDrawerContent', uitkDrawerContent)
        .directive('uitkDrawerAction', uitkDrawerAction)
        .directive('uitkMultiSortDrawerContent', uitkMultiSortDrawerContent)
        .directive('uitkMultiSortDrawerAction', uitkMultiSortDrawerAction)
        .directive('uitkShowHideColumnsDrawerContent', uitkShowHideColumnsDrawerContent)
        .directive('uitkShowHideColumnsDrawerAction', uitkShowHideColumnsDrawerAction).factory('drawerSlide', drawerSlide).factory('columnCombinations', columnCombinations);

    angular.module('uitk.component.uitkDynamicTableDirective', []);
})();

(function() {

var uitkDynamicTableRowDraggable = function ($parse,$timeout, uitkEvents) {

    function link($scope, $element, $attrs) {
        var isDraggable = false;
        if ($attrs.uitkDynamicTableRowDraggable) {
            isDraggable = $parse($attrs.uitkDynamicTableRowDraggable)($scope) ? true : false;
        }

        function croReleaseDraggingState(event) {
            var diff = new Date() - event.data.time;
            if (diff < 200) {
                $timeout.cancel(event.data.startDragging);
            } else {
                releaseDraggingState(event, $(event.data.$tr), $(event.data.$originalTr));
            }
        }

        function supportsTransitions() {
            var b = document.body || document.documentElement,
                s = b.style,
                p = 'transition';

            if (typeof s[p] === 'string') {
                return true;
            }

            var v = ['Moz', 'webkit', 'Webkit', 'Khtml', 'O', 'Ms'];
            p = p.charAt(0).toUpperCase() + p.substr(1);

            for (var i = 0; i < v.length; i++) {
                if (typeof s[v[i] + p] === 'string') {
                    return true;
                }
            }

            return false;
        }

        if (isDraggable) {
            $element.on("mousedown", function (event) {
                if($(event.target).is("a")){
                    return;
                }
                var $that = $(this);
                $timeout.cancel(startDragging);
                var time = new Date(); 

                var startDragging = $timeout(function () {
                    $scope.offsetTop = $that.offset().top - $that.parent().parent().offset().top;
                    setDraggingState($that, event);
                }, 200);

                $("body").on("mouseup",
                    function(){
                        var diff = new Date() - time;
                        if(diff < 200){
                            $timeout.cancel(startDragging);
                        }
                    });
            });
        }

        var trCoordinatesX = [];
        var trCoordinatesY = [];

        function setDraggingState($tr, event) {
            var $ghost = $tr.clone(true);
            var $siblings = $tr.parent().children();
            var $originals = $tr.children();
            $ghost.children().each(function(index)
            {
                $(this).width($originals.eq(index).width());
                return $ghost;
            });
            $ghost.addClass("tk-row-drag");
            $($ghost).insertBefore($tr);
            $("body").on("mouseup",
                    {
                        $tr: $ghost,
                        $originalTr: $tr
                    },
                    croReleaseDraggingState);

            $tr.addClass("tk-dtbl-cro-ghost");
            var offset = $ghost.offset();

            $ghost.css("height", $tr.height());

            $ghost.css("top", event.pageY - offset.top);
            $ghost.css("left", 0);

            $("body").addClass("oui-util-non-selectable-text tk-dtbl-cro-invalid-target");

            $ghost.focus();

            var horizontalDelta = event.pageX - offset.left;
            $ghost.attr("data-cro-cursor-delta", horizontalDelta);

            var verticalDelta = event.pageY - offset.top;
            $ghost.attr("data-cro-cursor-delta-y", verticalDelta);

            $("body").on("mousemove", {
                $tr: $ghost
            }, draggingState)

            $ghost.on("transitionend", function () {
                $ghost.addClass("tk-dtbl-cro-no-transition");
            })

            $("*").on("selectstart", function(){return false;});

            for (var i = 0; i < $siblings.length; i++) {
                trCoordinatesY[i] = $siblings.eq(i).offset().top;
            }
            trCoordinatesY[trCoordinatesY.length] = $siblings.last().offset().top + $siblings.last().outerHeight();
            trCoordinatesX[0] = $tr.offset().left;
            trCoordinatesX[1] = $tr.offset().left + $tr.outerWidth();

            if (!supportsTransitions()) {
                $ghost.trigger("transitionend");
            }
        }

        function releaseDraggingState(event, $ghost, $originalTr) {
            var $tr = event.data.$tr;
            $("body").off("mousemove", draggingState);
            $("body").off("mouseup", croReleaseDraggingState);

            $ghost.children().each(function(index)
            {
                $(this).removeAttr("style");
                return $ghost;
            });

            $ghost.removeAttr("style");
            $ghost.removeClass("tk-row-drag");

            $ghost.remove();
            $originalTr.removeClass("tk-dtbl-cro-ghost");

            var y = event.pageY;

            if ((y > trCoordinatesY[0]) && ( y < trCoordinatesY[trCoordinatesY.length - 1])) {
                var i = 0;
                while (y > trCoordinatesY[i]) {
                    i++;
                };
                i--;
                var middle = (trCoordinatesY[i] + trCoordinatesY[i+1]) / 2
                if(y < middle){
                    moveRow($scope.index, (i-6));
                }
                else{
                    moveRow($scope.index, (i-6+1));
                }
            }
            $("body").removeClass("oui-util-non-selectable-text tk-dtbl-cro-invalid-target");

            if (!supportsTransitions()) {
                $ghost.trigger("transitionend");
            }
        }

        function moveRow(startPosition, endPosition){
            $scope.$apply(function () {
                uitkEvents.setScope().internalBroadcast("broadcast", $scope.componentId+"-dragRows", {startPosition:startPosition, endPosition:endPosition});
                $scope.model.records.splice(endPosition, 0, $scope.model.records[startPosition]);
                if (startPosition < endPosition) {
                    $scope.model.records.splice(startPosition, 1);
                }
                else if (startPosition > endPosition) {
                    $scope.model.records.splice(startPosition + 1, 1);
                }
            });
        }

        function draggingState(event) {
            var $tr = event.data.$tr;
            var $ghost = $tr;
            var newTop = event.pageY - $tr.parent().parent().offset().top;
            $ghost.css("left", 0);
            $ghost.css("top", newTop);
        }
    }

    return {
        restrict: 'A',
        replace: false,
        scope: {
            model: '=',
            index: '=',
            componentId: '@'
        },
        link: link

    };
};

uitkDynamicTableRowDraggable.$inject = ['$parse','$timeout','uitkEvents'];

angular.module('uitk.component.uitkDynamicTable')
    .directive('uitkDynamicTableRowDraggable', uitkDynamicTableRowDraggable);

})();
angular.module("uitk.component.uitkDynamicTable").run(["$templateCache", function($templateCache) {$templateCache.put("template/multiSortDrawerAction.html","<tr class=\"tk-dtbl-add-row-buttons\">\n    <td colspan=\"{{model.columns.length}}\" role=\"presentation\">\n        <div class=\"tk-dtbl-add-row-button-constrainer tk-drawer-action-buttons\" ng-class=\"{edit:isEditing,add:!isEditing}\">\n            <div class=\"tk-dtbl-add-row-button-container\">\n                <span class=\"tk-dtbl-add-row-button-trim\"></span>\n                <span class=\"tk-dtbl-add-row-button-notch\">\n                    <input type=\"button\" class=\"tk-btn-default-action tk-width-10t\" ng-click=\"model.saveMultiSortColumns(model.multiSortColumnsInDrawer, $event)\"\n                           value=\"Save\" role=\"button\" aria-label=\"Save changes Multi Sort\" />\n                    <input type=\"button\" class=\"tk-btn-default-action tk-width-10t\"\n                            value=\"Cancel\" role=\"button\" ng-click=\"model.closeMultiSortDrawer($event)\"\n                           aria-label=\"Cancel changes to multi sort\" />\n                </span>\n            </div>\n        </div>\n    </td>\n</tr>\n");
$templateCache.put("template/multiSortDrawerContent.html","<tr class=\"tk-dtbl-multi-sort-row tk-dtbl-header-row\">\n    <td colspan=\"{{model.columns.length}}\">\n        <div class=\"tk-multi-sort-container\">\n        <div>\n            <span translate>Choose column(s) to sort</span>\n            <a class=\"restore-default\" href=\"\" ng-click=\"restoreDefault();\"><span class=\"cux-icon-undo\"></span> <span translate>Restore Default Sort Order</span></a>\n        </div>\n        <div class=\"column-container\">\n            <table>\n                <tr ng-repeat=\"multiSortColumn in model.multiSortColumnsInDrawer\" >\n                    <td ng-if=\"$first\" translate>Sort by</td>\n                    <td ng-if=\"!$first\" translate>Then by</td>\n                    <td><uitk:select item-list=\"dropDownItems\" selected-value=\"multiSortColumn.selectedColumn\"></uitk:select></td>\n                    <td class=\"tk-sorted-column-data\" ng-if=\"multiSortColumn.selectedColumn.dataType === \'text\' || multiSortColumn.selectedColumn.dataType === \'character\'\"><uitk:radio class=\"oui-rfrm-checkboxes\" item-list=\'textRadioItems\' group-name=\'sortOrderGroup{{$index}}\' model-value=\'multiSortColumn.sortOrder\'></uitk:radio></td>\n                    <td class=\"tk-sorted-column-data\" ng-if=\"multiSortColumn.selectedColumn.dataType === \'number\'\"><uitk:radio class=\"oui-rfrm-checkboxes\" item-list=\'numberRadioItems\' group-name=\'sortOrderGroup{{$index}}\' model-value=\'multiSortColumn.sortOrder\'></uitk:radio></td>\n                    <td class=\"tk-sorted-column-data\" ng-if=\"multiSortColumn.selectedColumn.dataType === \'date\'\"><uitk:radio class=\"oui-rfrm-checkboxes\" item-list=\'dateRadioItems\' group-name=\'sortOrderGroup{{$index}}\' model-value=\'multiSortColumn.sortOrder\'></uitk:radio></td>\n                    <td><a ng-if=\"!$first\" href=\"\" ng-click=\"removeColumn($index);\"><span class=\"cux-icon-remove\"></span> <span translate>Remove</span></a></td>\n                </tr>\n            </table>\n        </div>\n        <div class=\"add-column\">\n            <span ng-click=\"addAnotherColumn();\"><a href=\"\"><span class=\"cux-icon-add2\"></span> <span translate>Add another sort column</span></a></span>\n        </div>\n        </div>\n    </td>\n</tr>");
$templateCache.put("template/openColumnsDrawerAction.html","<tr class=\"tk-dtbl-add-row-buttons\">\n    <td colspan=\"{{model.columns.length}}\" role=\"presentation\">\n        <div class=\"tk-dtbl-add-row-button-constrainer tk-show-hide-action\" ng-class=\"{edit:isEditing,add:!isEditing}\">\n            <div class=\"tk-dtbl-add-row-button-container\">\n                <span class=\"tk-dtbl-add-row-button-trim\"></span>\n                <span class=\"tk-dtbl-add-row-button-notch\">\n                    <input type=\"button\" class=\"tk-btn-default-action tk-width-10t\" ng-click=\"model.modifyColumn(false, $event)\" value=\"Save\" role=\"button\" aria-label=\"{{(isEditing)?\'Save changes to record\':\'Create new record\'}}\" />\n                    <input type=\"button\" class=\"tk-btn-default-action tk-width-10t\" ng-click=\"model.modifyColumn(true, $event)\" value=\"Cancel\" role=\"button\" aria-label=\"{{(isEditing)?\'Reset or Cancel changes to record\':\'Cancel new record creation\'}}\" />\n                </span>\n            </div>\n        </div>\n    </td>\n</tr>\n");
$templateCache.put("template/openColumnsDrawerContent.html","<tr class=\"tk-dtbl-add-row tk-dtbl-header-row\">\n    <td colspan=\"{{model.columns.length}}\">\n        <div class=\"tk-dtbl-add-row-constrainer tk-show-hide-container\">\n        	<div class=\"tk-filter-container\">\n	        	<div class=\"tk-grid\">\n	            	<div class=\"tk-col-1-4\" translate>Select columns to make them show/hide.</div>\n	            	<div class=\"tk-col-3-4 tk-text-align-right\"><a ng-click=\"restoreDefault();\" class=\"restore-default\"><span class=\"cux-icon-undo\"></span> <span translate>Restore Defaults</span></a></div>\n	            </div>\n	        	<div class=\"tk-grid\">\n	            	<div class=\"tk-col-1-4\">\n	            		<div><span translate>Sort by: Column Order</span> | <a ng-click=\"order(\'label\')\" translate>Alphanumeric</a></div>\n	            		<div class=\"oui-util-scroll-vertical filterColumnsList\">\n	            			<ul class=\"sortoptions\">\n					          <li ng-repeat=\"option in model.columns | orderBy:predicate:reverse\" ng-class=\"{\'tk-show-hide-column-selected\' : (option.showColumnInTable && !option.showAlways)}\">\n					            <input type=\"checkbox\" ng-model=\"option.showColumnInTable\" ng-style=\"{\'visibility\': !option.showAlways?\'visible\':\'hidden\'}\">\n					            <label>{{option.label}} <span ng-if=\"option.showAlways\">(always visible)</span></label>\n					          </li>\n					        </ul>\n	            		</div>\n	            	</div>\n	            	<div class=\"tk-col-3-4\"></div>\n	            </div>\n            </div>\n        </div>\n    </td>\n</tr>\n");
$templateCache.put("template/openDrawerAction.html","<tr class=\"tk-dtbl-add-row-buttons\">\n    <td colspan=\"{{model.columns.length}}\" role=\"presentation\">\n        <div class=\"tk-dtbl-add-row-button-constrainer\" ng-class=\"{edit:isEditing,add:!isEditing}\">\n            <div class=\"tk-dtbl-add-row-button-container\">\n                <span class=\"tk-dtbl-add-row-button-trim\"></span>\n                <span class=\"tk-dtbl-add-row-button-notch\">\n                    <input type=\"button\" class=\"tk-btn-default-action tk-width-10t\" ng-click=\"model.modifyRow(isEditing,false,rowRecord, $event)\"\n                           value=\"Save\" role=\"button\" aria-label=\"{{(isEditing)?\'Save changes to record\':\'Create new record\'}}\" />\n                    <input type=\"button\" class=\"tk-btn-default-action tk-width-10t\"\n                           ng-click=\"model.modifyRow(isEditing,true,rowRecord, $event)\" value=\"Cancel\" role=\"button\"\n                           aria-label=\"{{(isEditing)?\'Reset or Cancel changes to record\':\'Cancel new record creation\'}}\" />\n                </span>\n            </div>\n        </div>\n    </td>\n</tr>\n");
$templateCache.put("template/openDrawerContent.html","<tr class=\"tk-dtbl-add-row tk-dtbl-header-row\">\n    <td ng-repeat=\"column in model.columns | displayColumnFilter | orderBy:\'layoutOrder\'\">\n        <div class=\"tk-dtbl-add-row-constrainer\" ng-class=\"{edit:isEditing,add:!isEditing}\" >\n            <div ng-if=\"$index == 0\"  class=\"tk-dtbl-add-row-container\">\n                <span class=\"tk-dtbl-add-row-required\"  uitk-compile-cell-template=\"inputTemplate\"> </span>\n            </div>\n\n            <div ng-if=\"$index > 0\"  class=\"tk-dtbl-add-row-container\"  uitk-compile-cell-template=\"inputTemplate\">\n\n            </div>\n\n        </div>\n    </td>\n</tr>\n");
$templateCache.put("template/uitk-dynamic-table.html","<div class=\"tk-dtbl-container\">\n    <span ng-if=\"table.showPagination()\" aria-label=\"total number of records\"> {{ \"Total Records:\" | uitkTranslate}} {{ model.totalRecordsCount }} </span>\n    <span class=\"oui-a11y-hidden\" id=\"{{componentId}}_pageNumber\"> showing page {{page.pageNumber}} of {{table.totalPagesCount()}}</span>\n        <div ng-if=\"table.showPagination()\" class=\"pagination\" role=\"paginator\" ng-class=\"{ \'tk-pageinput-error-display\' : page.pageNumberError }\">\n            <label style=\"font-weight: normal;\" for=\"{{rowsDropdownId}}\">{{ \"Show\" | uitkTranslate}}</label>\n            <select id=\"{{rowsDropdownId}}\" ng-model=\"model.pagination.recordsPerPage\" ng-change=\"model.onPaginate(1)\"\n                    ng-disabled=\"model.totalRecordsCount === 0\"\n                    ng-options=\"value for value in model.pagination.recordsPerPageChoices\" aria-label=\"number of records per page\">\n            </select> {{ \"per page\" | uitkTranslate}}\n            <ul>\n                <li>\n                    <a href=\"\" ng-if=\"table.hasPreviousPage()\" ng-click=\"model.onPaginate(1)\" uitk-navigable  title=\"First Page\">\n                        <span class=\"cux-icon-rewind\"></span> {{ \"First\" | uitkTranslate}}\n                    </a>\n                    <span ng-if=\"!table.hasPreviousPage()\" class=\"cux-icon-rewind\" aria-disabled=\"true\"></span>\n                    <span ng-if=\"!table.hasPreviousPage()\" aria-disabled=\"true\"> {{ \"First\" | uitkTranslate}} </span>\n                </li>\n                <li>\n                    <a href=\"\" ng-if=\"table.hasPreviousPage()\" ng-click=\"model.onPaginate(table.previousPageNumber())\"\n                       uitk-navigable  title=\"Previous Page\">\n                        <span class=\"cux-icon-carrot_left\"></span> {{ \"Previous\" | uitkTranslate}}\n                    </a>\n                    <span ng-if=\"!table.hasPreviousPage()\" class=\"cux-icon-carrot_left\" aria-disabled=\"true\"></span>\n                    <span ng-if=\"!table.hasPreviousPage()\" aria-disabled=\"true\">{{ \"Previous\" | uitkTranslate}}</span>\n                </li>\n            </ul>\n            <span class=\"tk-pageinput\">\n                <label style=\"font-weight: normal;\" for=\"{{componentId}}_pageInput\"> {{ \"Page\" | uitkTranslate}} </label>\n                <input type=\'text\' id=\"{{componentId}}_pageInput\" ng-model=\"page.pageNumber\" ng-class=\"{ \'tk-pageinput-error\' : page.pageNumberError }\" class=\'tk-width-3t tk-text-align-right\' uitk-navigable uitk-numbers-only\n                       aria-required=\"true\" aria-invalid=\"{{page.pageNumberError}}\"  aria-describedby=\"{{page.pageNumberDescribedBy}}\" ng-keydown=\"pageNumberEvent($event)\" ng-blur=\"pageNumberEvent($event)\"/>\n                <span> {{ \"of\" | uitkTranslate}} {{table.totalPagesCount()}}</span>\n                <div class=\"tk-pageerror-message\" aria-hidden=\"{{page.pageNumberError}}\" id=\"{{componentId}}_pageError\" aria-describedby=\"Enter a valid number, one that is in the page range.\" id=\"{{componentId}}_pageNumberError\" ng-if=\"page.pageNumberError\">Enter a valid number, one that is in the page range.</div>\n            </span>\n            <ul>\n                <li>\n                    <a href=\"\" ng-if=\"table.hasNextPage()\" ng-click=\"model.onPaginate(table.nextPageNumber())\"\n                       uitk-navigable title=\"Next Page\">\n                        {{ \"Next\" | uitkTranslate}} <span class=\"cux-icon-carrot_right\"></span>\n                    </a>\n                    <span ng-if=\"!table.hasNextPage()\" aria-disabled=\"true\"> {{ \"Next\" | uitkTranslate}} </span>\n                    <span ng-if=\"!table.hasNextPage()\" class=\"cux-icon-carrot_right\" aria-disabled=\"true\"></span>\n                </li>\n                <li>\n                    <a href=\"\" ng-if=\"table.hasNextPage()\" ng-click=\"model.onPaginate(table.lastPageNumber())\"\n                       uitk-navigable title=\"Last Page\">\n                        {{ \"Last\" | uitkTranslate}} <span class=\"cux-icon-forward\"> </span>\n                    </a>\n                    <span ng-if=\"!table.hasNextPage()\" aria-disabled=\"true\"> {{ \"Last\" | uitkTranslate}} </span>\n                    <span ng-if=\"!table.hasNextPage()\" class=\"cux-icon-forward\" aria-disabled=\"true\"></span>\n                </li>\n            </ul>\n        </div>\n\n    <ul ng-if=\"showTableOptions\"\n        class=\"table-action-container\">\n        <li ng-if=\"isFiltersClear\">\n            <a href=\"\" ng-if=\"isFiltersApplied()\" ng-click=\"table.clearAllFilters()\"><span class=\"cux-icon-filter\"></span> {{\"Clear All Filters\" | uitkTranslate}}</a>\n            <span href=\"\" ng-if=\"!isFiltersApplied()\" aria-role=\"button\" aria-disabled=\"true\"><span class=\"cux-icon-filter\"></span> {{\"Clear All Filters\" | uitkTranslate}}</span>\n        </li>\n\n        <li ng-if=\"model.onExport\">\n            <a href=\"\" title=\"Export to CSV\" ng-click=\"table.export()\"><span class=\"cux-icon-export\"></span> {{\"Export (CSV)\" | uitkTranslate}}</a>\n        </li>\n\n        <li ng-if=\"model.onExportNestedData\">\n            <a href=\"\" title=\"Export to Excel\" ng-click=\"table.exportNestedData()\"><span class=\"cux-icon-export\"></span> {{\"Export (Excel)\" | uitkTranslate}}</a>\n        </li>\n\n        <li ng-repeat=\"link in model.links\" uitk-compile-cell-template=\"link\"></li>\n    </ul>\n\n    <table class=\"tk-dtbl tk-dtbl-reorderable-columns\" role=\"grid\"\n           ng-class=\"{ \'tk-dtbl-expandable\' : model.rowTemplate }\" >\n        <thead>\n        <tr>\n            <th ng-repeat=\"column in model.columns | displayColumnFilter | orderBy:\'layoutOrder\'\"\n                ng-class=\"{\'tk-dtbl-non-reorderable-column-cursor\':!column.draggable, \'tk-dtbl-cell-dotted-right-border\' : column.resizeInProgress, \'tk-dtbl-cro-target-border\' : column.dropInProgress, \'tk-hide-column\': column.cellName === \'multiSelectColumn\' && !model.enableMultiSelect }\"\n                uitk-dynamic-table-column-draggable=\"{{column.draggable}}\"\n                \n                ng-attr-style=\"{{column.style}}\"\n                aria-label=\"{{column.columnId}}\" aria-sort=\"{{ table.sortOrderDescription(column.sortOrder) }}\"\n                align=\"{{column.align}}\">\n                <span ng-if=\"!model.rowTemplate\" uitk-resizable-column ng-class=\"{\'resizable\' : !$last }\">&nbsp;</span>\n                <a ng-if=\"isColumnSortable(column) && (!isMultiSortColumn(column))\" uitk-navigable=\"isColumnSortable(column)\"\n                   class=\"tk-dtbl-as-table-cell {{column.dataType}}\" ng-click=\"model.onSort(column.columnId)\" >\n                    <span class=\"overflow\" uitk-compile-label=\"column.label\">  </span>\n                    <span ng-class=\"{ \'cux-icon-carrot_up\' : sortOrderEqualTo(column,1), \'cux-icon-carrot_down\': sortOrderEqualTo(column,-1),\'cux-icon-sort\' : column.sortable && sortOrderEqualTo(column,0) }\">\n                    </span>\n\n                    <span ng-if=\"sortOrderEqualTo(column,\'not 0\')\" class=\"oui-a11y-hidden\" > , (sorted {{ table.sortOrderDescription(column.sortOrder) }})</span>\n                    <span ng-if=\"sortOrderEqualTo(column,0)\" class=\"oui-a11y-hidden\" > , (sortable)</span>\n                </a>\n                <a ng-if=\"isColumnSortable(column) && (isMultiSortColumn(column))\" uitk-navigable=\"isColumnSortable(column)&& isMultiSortColumn(column)\"\n                   class=\"tk-dtbl-as-table-cell {{column.dataType}}\" aria-disabled=\"true\">\n                    <span class=\"overflow\" uitk-compile-label=\"column.label\">  </span>\n                    <span ng-class=\"{ \'cux-icon-carrot_up\' : multiSortOrderEqualTo(column,1), \'cux-icon-carrot_down\': multiSortOrderEqualTo(column,-1)}\">\n                    </span>\n                </a>\n\n\n                <span ng-if=\"!column.sortable\" class=\"tk-dtbl-as-table-cell {{column.dataType}}\"\n                      uitk-compile-label=\"column.label\"></span>\n                <div ng-if=\"column.cellHeaderTemplate\" uitk-compile-cell-template=\"cellHeaderTemplate\"> </div>\n            </th>\n        </tr>\n        </thead>\n\n        <tbody ng-if=\"!model.rowTemplate && model.totalRecordsCount !== 0\">\n\n        <!-- Begins Show/Hide Columns -->\n        <tr uitk-show-hide-columns-drawer-content model=\"model\" component-id=\"componentId\"></tr>\n        <tr uitk-show-hide-columns-drawer-action model=\"model\" component-id=\"componentId\"></tr>\n        <!-- Ends Show/Hide Columns -->\n\n        <!-- Begins multiSelectDrawer -->\n        <tr uitk-multi-sort-drawer-content model=\"model\" component-id=\"componentId\"></tr>\n        <tr uitk-multi-sort-drawer-action model=\"model\" component-id=\"componentId\"></tr>\n\n        <!-- Begins onAddRow -->\n        <tr uitk-drawer-content model=\"model\" component-id=\"componentId\"></tr>\n        <tr uitk-drawer-action model=\"model\" component-id=\"componentId\"></tr>\n        <!-- Ends onAddRow -->\n        <tr ng-if=\"!model.onRowSelect\" ng-repeat=\"record in model.records | limitTo : table.recordsPerPage()\" role=\"row\">\n            <td uitk-compile-cell-template=\"cellTemplate\"\n                ng-repeat=\"column in model.columns | displayColumnFilter | orderBy:\'layoutOrder\'\"\n                ng-class=\"{ \'tk-dtbl-cell-dotted-right-border\' : column.resizeInProgress }\" align=\"{{column.align}}\"\n                class=\"tk-dtbl-cell {{column.dataType}}\">\n            </td>\n        </tr>\n        <tr ng-if=\"model.onRowSelect && !customOnEditRowIsDefined && !usingCRUD\" class=\"tk-row-order\" id=\"row_{{$index}}\" ng-repeat=\"record in model.records | limitTo : table.recordsPerPage()\"\n            ng-class=\"{\'tk-row-highlight\': record.selected, \'tk-dtbl-reorderable-row-cursor\': model.rowDraggable}\"\n            aria-selected=\"{{record.selected}}\" role=\"row\" aria-label=\"{{record.firstName}} {{record.lastName}}\"\n            ng-click=\"model.onRowSelect($event, record);\" uitk-selectable uitk-dynamic-table-row-draggable=\"model.rowDraggable\" model=\"model\" index=\"$index\" component-id=\"{{componentId}}\">\n            <td uitk-compile-cell-template=\"cellTemplate\"\n                ng-repeat=\"column in model.columns | displayColumnFilter | orderBy:\'layoutOrder\'\"  align=\"{{column.align}}\"\n                ng-class=\"{ \'tk-dtbl-cell-dotted-right-border\' : column.resizeInProgress }\"\n                class=\"tk-dtbl-cell {{column.dataType}}\">\n            </td>\n        </tr>\n\n        <tr ng-if=\"rowSelectedandEditing\" ng-hide=\"record.hideRecord\" id=\"{{componentId+\'_\'+$index}}\"\n            ng-repeat-start=\"record in model.records | limitTo : table.recordsPerPage()\" ng-init=\"record.index =$index;\"\n            ng-class=\"{\'tk-row-highlight\': record.selected}\" aria-selected=\"{{record.selected}}\"\n            aria-label=\"{{record.firstName}} {{record.lastName}}\"\n            role=\"row\" ng-click=\"model.onRowSelect($event, record);\" uitk-selectable>\n            <td uitk-compile-cell-template=\"cellTemplate\"\n                ng-repeat=\"column in model.columns | displayColumnFilter | orderBy:\'layoutOrder\'\"  align=\"{{column.align}}\"\n                ng-class=\"{ \'tk-dtbl-cell-dotted-right-border\' : column.resizeInProgress, \'tk-hide-column\': column.cellName === \'multiSelectColumn\' && !model.enableMultiSelect }\"\n                class=\"tk-dtbl-cell {{column.dataType}}\">\n            </td>\n        </tr>\n        <!-- Begins onEditRow -->\n        <tr ng-if=\"rowSelectedandEditing\" uitk-drawer-content model=\"model\" component-id=\"componentId\" is-editing=\"true\" row-record=\"record\"  ></tr>\n        <tr ng-show=\"model.recordOperationInProgress\" ng-if=\"rowSelectedandEditing\" uitk-drawer-action model=\"model\" component-id=\"componentId\" is-editing=\"true\" row-record=\"record\" ng-repeat-end></tr>\n        <!-- Ends onEditRow -->\n\n        </tbody>\n\n        <tbody ng-if=\"model.rowTemplate && model.totalRecordsCount !== 0\">\n        <tr uitk-compile-cell-template ng-repeat=\"currentRecord in model.records | limitTo : table.recordsPerPage()\">\n        </tr>\n        </tbody>\n\n        <tbody ng-if=\"model.totalRecordsCount === 0\">\n        <tr class=\"tk-dtbl-add-row tk-dtbl-header-row\">\n            <td ng-repeat=\"column in model.columns | orderBy:\'layoutOrder\'\">\n                <div class=\"tk-dtbl-add-row-constrainer\">\n                    <div ng-if=\"$index == 0\"  class=\"tk-dtbl-add-row-container\">\n                        <span class=\"tk-dtbl-add-row-required\"  uitk-compile-cell-template=\"inputTemplate\"> </span>\n                    </div>\n\n                    <div ng-if=\"$index > 0\"  class=\"tk-dtbl-add-row-container\" uitk-compile-cell-template=\"inputTemplate\">\n                    </div>\n                </div>\n            </td>\n        </tr>\n\n        <tr class=\"tk-dtbl-add-row-buttons tk-dtbl-header-row\">\n            <td colspan=\"{{model.columns.length}}\" role=\"presentation\">\n                <div class=\"tk-dtbl-add-row-button-constrainer\">\n                    <div class=\"tk-dtbl-add-row-button-container\">\n                        <span class=\"tk-dtbl-add-row-button-trim\"></span>\n                        <span class=\"tk-dtbl-add-row-button-notch\">\n                            <input type=\"button\" class=\"tk-btn-default-action tk-width-10t\" ng-click=\"model.onAddRow()\"\n                                   value=\"Save\" role=\"button\" aria-label=\"Create new record\" />\n                            <input type=\"button\" class=\"tk-btn-default-action tk-width-10t\" ng-click=\"model.onAddRowCancel()\"\n                                   value=\"Cancel\" role=\"button\" aria-label=\"Cancel new record creation\" />\n                        </span>\n                    </div>\n                </div>\n            </td>\n        </tr>\n\n        <tr>\n            <td colspan=\"{{model.columns.length}}\" class=\"tk-dtbl-cell tk-dtbl-no-records\">\n                {{ \"No records found.\" | uitkTranslate }}\n            </td>\n        </tr>\n        </tbody>\n    </table>\n\n    <!-- Confirm modal dialog for delete -->\n    <uitk:dialog ng-if=\"model.modalShown\" dialog-id=\'deleteDialog\' dialog-role=\'dialog\'\n                 header-text=\'Confirm Delete\' show=\'model.modalShown\' default-width=\'45%\'\n                 default-height=\"51%\" call-back-hide=\'model.onDeleteCancel()\'>\n\n        <span>Are you sure you want to delete record(s)? This action can\'t be undone. </span>\n        <br/>\n\n        <uitk:button type=\"button\" style=\"float:left;\" value=\"Delete\"\n                     enable-default=\"true\"\n                     ng-click=\"model.onDeleteConfirm();\"\n                     custom-class=\'uitk-width-6t uitk-btn-close-dialog\'></uitk:button>\n\n        <uitk:button type=\"button\" style=\"float:left;\" value=\"Cancel\"\n                     enable-default=\"true\"\n                     onclick=\"document.getElementById(\'deleteDialog_closeLink\').click();\"\n\n                     custom-class=\'uitk-width-6t uitk-btn-close-dialog\'></uitk:button>\n    </uitk:dialog>\n</div>");}]);
angular.module('uitk.component.uitkErrorHandler', ['uitk.component.uitkDialog'])
.factory('uitkErrorHandlerModel', function(){
  return {
    show  : false,
    header : 'Error',
    message : "Error has occured"
  };
})
.factory('uitkErrorHandlerHttpInterceptor', ["$q", "uitkErrorHandlerModel", function($q, uitkErrorHandlerModel){
  return {
    requestError : function(rejection) {
      uitkErrorHandlerModel.show = true;
      uitkErrorHandlerModel.message = "HTTP Request Error";
      return $q.reject(rejection);
    },
    responseError : function(rejection) {
      uitkErrorHandlerModel.show = true;
      uitkErrorHandlerModel.message = "HTTP Response Error";
      return $q.reject(rejection);
    }
  };
}])
.directive('uitkErrorHandler', ["uitkErrorHandlerModel", function(uitkErrorHandlerModel){

  function link($scope) {
    $scope.model = uitkErrorHandlerModel;

    $scope.closeModal = function() {
      $scope.model.show = false;
    };
  }

  return {
    restrict : 'E',
    replace : true,
    link : link,
    scope : true,
    template :
    [
     "<div> ",
     "  <uitk:dialog dialog-id='uitkErrorHandlerPopUp' dialog-role='dialog' ",
     "               header-text='{{model.header}}' show='model.show' ng-if='model.show' default-width='30%' default-height='20%'>",
     "  {{model.message}} ",
     "  </uitk:dialog>",
     "</div> "
    ].join('')
  };
}])
.config(["$provide", "$httpProvider", function ($provide, $httpProvider) {
  $provide.decorator("$exceptionHandler", ['$delegate', 'uitkErrorHandlerModel', function($delegate, uitkErrorHandlerModel) {
    return function(exception, cause) {
      uitkErrorHandlerModel.show = true;
      uitkErrorHandlerModel.message = exception.stack;
      $delegate(exception, cause);
    };
  }]);
  $httpProvider.interceptors.push('uitkErrorHandlerHttpInterceptor');
}]);

angular.module('uitk.component.uitkFooter', ['uitk.component.uitkNavigable'])
.directive('uitkFooter', ["$filter", "$compile", function($filter, $compile) {
    return {
      restrict: 'E',
      replace: true,
      transclude : true,
      link : function($scope) {
    	  $scope.currentYear = new Date().getFullYear();
          angular.element('footer > div').prepend($compile('<p> &copy; '+$scope.currentYear+' Optum, <span translate>Inc.</span> <span translate>All rights reserved.</span></p>')($scope));

      },
      template: '<footer role="contentinfo"><div ng-transclude ></div></footer>'
    };
}])
.directive('uitkFooterLinks', function(){
	return {
		restrict : 'E',
		replace : true,
		transclude : true,
		template : '<ul class="tk-foot-links" ng-transclude> </ul>'
	};
})

.directive('uitkFooterLink', function(){
	return {
		restrict : 'E',
		replace : true,
		scope : {
			url : '@',
			tkLabel : '@',
			tkDisabled : '=',
			tkTarget : '@',
			linkInfoForReader : '@' 
		},
		link: function(scope, element) {
			var tkTarget = scope.tkTarget;
			scope.disabledA11y = true;
	        if(tkTarget) {
	        	scope.tkTargetWindow = "_"+tkTarget;
	        	if(tkTarget === "blank"){
	        		scope.disabledA11y = false;
	        	}
	        }
		},
		template : [
					'<li>',
					'	<a ng-if="!tkDisabled" href="{{url}}" target="{{tkTargetWindow}}">{{tkLabel}} <span ng-if="!disabledA11y" class="oui-a11y-hidden">{{linkInfoForReader}}</span></a>',
					'   <span ng-if="tkDisabled" class="tk-foot-link-disabled">{{tkLabel}}</span>',
					'</li>'
		           ].join('')
	};
})
.directive('uitkFooterText', function(){
	return {
		restrict : 'E',
		replace : true,
		transclude : true, 
		template: '<p class="tk-foot-text" ng-transclude ></p>'
	};
});

angular.module('uitk.component.uitkGlobalNavigation', ['uitk.component.uitkSlideAnimation', 'uitk.component.uitkNavigable','uitk.uitkUtility'])
.directive('uitkGlobalNavigation', ["$document", function($document){

		function controller($scope, uitkTools, $attrs, $element){
		$scope.name = "GlobalNavigation";
		$scope.links = [];

		$scope.addLink = function(link) {
			$scope.links.push(link);
		}

	}
	controller.$inject = ["$scope", "uitkTools", "$attrs", "$element"];

	function link($scope, $element, $attrs, ctrl, $transclude){

				 $scope.setSelectedUrl = function(scope){$scope.selectedUrl = scope;};

		 		 $scope.getSelectedUrl = function(){return $scope.selectedUrl;};


		$transclude($scope, function(content) {
			$element.append(content);
		});
		 $document.on("click", function ($event) {
			 if(!$event.target.keepGlobalDropdownFlag){
				 $scope.$apply(function(){
					 $scope.hideAllMenus();
				 });
			 }
	     });

		 		 $scope.hideAllMenus = function(){
				 var linkWithDropDowns = $scope.links;
				 while(linkWithDropDowns.length > 0) {
					 linkWithDropDowns = linkWithDropDowns.filter(function(link){ return link.hasOwnProperty('dropDown') }); 
					 var allDropdownUnderLink = linkWithDropDowns.map(function(link){ return link.dropDown; }); 
					 allDropdownUnderLink.forEach(function(dropDown) { dropDown.menuVisible = false; }) 
					 linkWithDropDowns = allDropdownUnderLink
					 						.filter(function(dropDown){ return dropDown.hasOwnProperty('links') })
					 						.map(function(dropDown){ return dropDown.links; })
					 						.reduce(function(allLink, links){ return allLink.concat(links);}, []);
				 }

				 				 if($scope.getSelectedUrl()){
						$scope.getSelectedUrl().selected = false;
				}
		 };
	}

		return {
		restrict : 'E',
		replace : true,
		transclude : true,
		scope : true,
		template : "<ul class='tk-gnav'></ul>",
		controller : controller,
		link : link
	};
}])
.directive('uitkGlobalNavigationPlainText', function(){
	function controller($scope, uitkTools, $attrs, $element){
		$scope.plainText = '';

		$scope.addPlainText = function(text) {
			$scope.plainText = text;
		}
	}
	controller.$inject = ["$scope", "uitkTools", "$attrs", "$element"];
	function link($scope, $element, $attrs, ctrl, $transclude){
		["textTemplate","profileName"].forEach(function(attr) {
			$scope[attr] = $attrs[attr];
		});
		$scope.addPlainText($scope);
		$transclude($scope, function() {
			$element.find('div').replaceWith($scope.textTemplate);
		});
	}

	return {
		restrict : 'E',
		replace : true,
		transclude : true,
		require : '^uitkGlobalNavigation',
		scope : true,
		templateUrl: function (element, attrs) {
			return attrs.templateUrl || 'template/plainTextContent.html';
		},
		link : link,
		controller: controller
	};
})
.directive('uitkGlobalNavigationLink', ["$timeout", "$location", "$sce", "uitkExceptionService", function($timeout, $location,$sce, uitkExceptionService){

		function controller($scope, uitkEvents, $attrs, $element, uitkTools){

			if($scope.url && $scope.hasSubMenu) {
			   uitkExceptionService.throwException("UnsupportedLinkException","Link cannot have both URL and HasSubMenu attributes");
			}

				$scope.hrefPlaceHolder = function() {
		};

		$scope.addDropDown = function(dropDown) {
			$scope.dropDown = dropDown;
		}





				$scope.expandMenuOrRedirectToLink = function($event){
			$scope.$eval($scope.callbackFunction);

			$event.target.keepGlobalDropdownFlag = true;

			if($scope.$parent.hasOwnProperty('name') && $scope.name === "GlobalNavigation"){
				if($scope.getSelectedUrl()){
					$scope.getSelectedUrl().selected = false;
				}
				$scope.setSelectedUrl($scope);
				$scope.selected = true;
			}

			var linksWithDropDown = $scope.links.filter(function(link) { return link !== $scope; }).filter(function(link){ return link.hasOwnProperty('dropDown');});
			linksWithDropDown.forEach(function(link) {

				link.dropDown.links.forEach(function(link) {

					if(link.dropDown) {
						link.dropDown.menuVisible = false;
					}
				});
				link.dropDown.menuVisible = false;
			});
			if($scope.hasOwnProperty('dropDown')) {
				$scope.dropDown.menuVisible = !$scope.dropDown.menuVisible;
				if($scope.dropDown.menuVisible) {
					$scope.dropDown.links[0].setOnFocus();
				}
				else {
					$scope.dropDown.links.forEach(function(dropDown) {
						dropDown.dropDown.menuVisible = false;
					});

					if($scope.getSelectedUrl()){
						$scope.getSelectedUrl().selected = false;
					}
				}
			}

			if($scope.url){
				if($scope.url[0] === '#'){
					$location.path($scope.url.substring(1));
				}
				else {
					window.location = $scope.url;
				}

			}

			if($scope.callbackFunction !== undefined){
				$scope.hideAllMenus();
			}
		};

				$scope.hasChildSubMenu = function() {
			return $scope.hasOwnProperty('dropDown') ? true :false;
		}


				$scope.hasExpanded = function(){
			if(!$scope.hasOwnProperty('dropDown'))
			{
				return undefined;
			}
			return $scope.dropDown.menuVisible;
		}

		$scope.hideParentMenu = function(event){
			if(event.which === 27) {
				var focus = $scope.$parent.setOnFocus();
				if($scope.$parent.hasChildSubMenu()) {
					if(focus instanceof Function) {
						$scope.$parent.setOnFocus();
						$scope.dropDown.menuVisible = false;
					} else {
						$scope.$parent.$parent.setOnFocus();
						$scope.$parent.dropDown.menuVisible = false;
					}
				}
			}
			if(event.which === 9) {
				if(!event.shiftKey && $scope.hasOwnProperty('lastLinkInDropDown') && $scope.lastLinkInDropDown && !$scope.hasOwnProperty('dropDown')){
					$scope.dropDown.menuVisible = false;

					if($scope.$parent.$parent.$parent.hasOwnProperty('name') && $scope.getSelectedUrl()){
						$scope.getSelectedUrl().selected = false;
					}

					if($scope.$parent.lastLinkInDropDown) {
						$scope.$parent.$parent.$parent.menuVisible= false;
						if($scope.$parent.$parent.$parent.$parent.$parent.hasOwnProperty('name') && $scope.getSelectedUrl()){
							$scope.getSelectedUrl().selected = false;
						}
					}
				} else if(!event.shiftKey && $scope.hasOwnProperty('lastLinkInDropDown') && !$scope.lastLinkInDropDown && !$scope.dropDown.menuVisible) {  
					$scope.$parent.dropDown.menuVisible = false;
					if($scope.$parent.$parent.$parent.hasOwnProperty('name') && $scope.getSelectedUrl()){
						$scope.getSelectedUrl().selected = false;
					}
				} else if(event.shiftKey && $scope.hasOwnProperty('firstLinkInDropDown') && $scope.firstLinkInDropDown ) {

					$scope.$parent.menuVisible = false;

					if($scope.$parent.$parent.$parent.hasOwnProperty('name') && $scope.getSelectedUrl()){
						$scope.getSelectedUrl().selected = false;
					}
				}
				else if(!event.shiftKey && $scope.hasOwnProperty('lastLinkInDropDown') && $scope.lastLinkInDropDown) {
					$scope.$parent.menuVisible = false;
				}
			}
 		};

 			    $scope.getTrustedTextTemplate = function() {
            return $sce.trustAsHtml($scope.textTemplate);
        };
 	}
 	controller.$inject = ["$scope", "uitkEvents", "$attrs", "$element", "uitkTools"];


	function link($scope, $element, $attrs, ctrl, $transclude){
	    [ "textTemplate", "url" , "disableLink", "hasSubMenu", "profileName","callbackFunction"].forEach (function(attr) { $scope[attr] = $attrs[attr]; } );
		$scope.setOnFocus = function() { 
			$timeout(function(){
				$element.find('a')[0].focus();
			}, 750);
		};
	    $scope.addLink($scope);

	    $transclude($scope, function(content) {
			$element.find('div').replaceWith(content);
		});
	}

		return {
		restrict : 'E',
		replace : true,
		transclude : true,
		require : '^uitkGlobalNavigation',
		scope : true,
		templateUrl: function (element, attrs) {
			return attrs.templateUrl || 'template/linkContent.html';
		},
		controller : controller,
		link : link
	};
}])
.directive('uitkGlobalNavigationDropDown', function(){
	function controller($scope, uitkTools, $attrs, $element){
		$scope.links = [];
		$scope.menuVisible = false;
		$scope.menuPosition = false;
		$scope.addLink = function(link) {
			$scope.links.push(link);
		}
	}
	controller.$inject = ["$scope", "uitkTools", "$attrs", "$element"];

	function link($scope, $element, $attrs, ctrl, $transclude){
		$scope.addDropDown($scope);
		$transclude($scope, function(content) {
			$element.append(content);
		});

		var nonDisabledLinks = $scope.links.filter(function(link){ return !link.disableLink});
		var firstNonDisabledLink = nonDisabledLinks[0];
		firstNonDisabledLink.firstLinkInDropDown = true;
		var lastNonDisabledLink = nonDisabledLinks[nonDisabledLinks.length - 1];
		lastNonDisabledLink.lastLinkInDropDown = true;

				$scope.checkMenuPosition = function(){
			var elementRightPosition = $element[0].getBoundingClientRect().right;
			var elementWidth = $element[0].getBoundingClientRect().width;
			var screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
			if(screenWidth < elementRightPosition + elementWidth){
				$scope.dropDown.links.forEach(function(link){if(link.hasOwnProperty('dropDown')){link.dropDown.menuPosition = true;}})
			}
		}
	}

		return {
		restrict : 'E',
		replace : true,
		transclude : true,
		require : '^uitkGlobalNavigationLink',
		scope : true,
		templateUrl: function (element, attrs) {
			return attrs.templateUrl || 'template/dropDownContent.html';
		},
		controller : controller,
		link : link
	};
})
.directive('uitkCompileTextTemplate', ["$compile", function ($compile) {
	  return function($scope, $element) {
		  $compile($scope.textTemplate)($scope, function(clone){
	    	if(!clone.selector) {
			  $element.append(clone);
	    	} else {
	    		$element.append(clone.selector);
	    	}
	    });
	  };
}]);
angular.module("uitk.component.uitkGlobalNavigation").run(["$templateCache", function($templateCache) {$templateCache.put("template/dropDownContent.html","<ul ng-class=\'{\"menuVisible\": menuVisible, \"tk-gnav-to-the-left\": menuPosition}\' uitk-slide-show=\'menuVisible\' uitk-slide-show-duration=\'500\'></ul>");
$templateCache.put("template/linkContent.html","<li ng-class=\"{\'hasSubMenu\': hasSubMenu || hasChildSubMenu() ,\'disabled\': disableLink}\">\n    <a href=\"javascript:void(0)\" ng-class=\"{\'select-active\': selected}\" uitk-navigable=\"disableLink !== \'true\'\" ng-if=\"disableLink !== \'true\'\" ng-click=\"expandMenuOrRedirectToLink($event)\" ng-keydown=\"hideParentMenu($event)\">\n        <span ng-if=\"profileName\" ng-class=\"{\'cux-icon-person\': profileName}\" aria-hidden=\"true\"></span>\n        <span uitk-compile-text-template=\"textTemplate\"></span>\n        <span ng-if=\"hasSubMenu || hasChildSubMenu()\">\n            <span class=\"oui-a11y-hidden\">Has Submenu.</span>\n            <span aria-hidden=\"true\">\n                <span ng-if=\"hasSubMenu\">\n                    <span class=\"cux-icon-carrot_down\"></span>\n                </span>\n                <span ng-if=\"hasChildSubMenu() && !hasSubMenu\">\n                    <span class=\"cux-icon-carrot_right\"></span>\n                </span>\n            </span>\n            <span class=\"oui-a11y-hidden\">\n                <span ng-if=\"!hasExpanded()\">Collapsed</span>\n                <span ng-if=\"hasExpanded()\">Expanded</span>\n            </span>\n        </span>\n    </a>\n    <a href=\"javascript:void(0)\" ng-click=\"$event.stopPropagation();\" ng-if=\"disableLink === \'true\'\" ng-class=\"{\'disabled\': disableLink}\" aria-disabled=\"{{disableLink}}\" uitk-compile-text-template=\"textTemplate\"></a>\n    <div></div>\n</li>");
$templateCache.put("template/plainTextContent.html","<li class=\'tk-nav-text\'>\n    <span>\n        <span ng-if=\'profileName\' ng-class=\'{\"cux-icon-person\": profileName}\' aria-hidden=\'true\'></span>\n        <div uitk-compile-text-template=\'textTemplate\'></div>\n    </span>\n</li>");}]);
/*
 *** DO NOT MODIFY THE COPYRIGHT HEADER MANUALLY ***
 *** Release process will update accordingly ***
 * Copyright (c) Optum 2015 - All Rights Reserved.
 * @version 3.4.0
 */
angular.module('uitk.component.uitkInputMasking',['pascalprecht.translate'])
.directive('uitkInputmask', ['$filter', function($filter) {	
	return {		
		restrict: 'E',
		replace : true,
		scope: {
			model: '=',
			mask: '@',
			showTip: '=',
			compId: '@'
		},
		
		link: function (scope, element, attributes) {
			scope.extraClasses = attributes['styleClass'];
			switch(scope.mask) {
		    case 'phone':
		    	if(scope.showTip) {
		    		element[0].querySelector('div.tk-input-masking-assistivetext').innerHTML='555-555-5555';
		    	}
		        break;
		    case 'zip':
		    	if(scope.showTip) {
		    		element[0].querySelector('div.tk-input-masking-assistivetext').innerHTML='55555-5555';
		    	}
		        break;
		    case 'ssn':
		    	if(scope.showTip) {
		    		element[0].querySelector('div.tk-input-masking-assistivetext').innerHTML='555-55-5555';
		    	}
		        break;			    
			}
			// scope.inputValue is the value of input element used in template
			scope.inputValue = scope.model;
			scope.$watch('inputValue', function(value, oldValue) {
				var filterType = '';
				switch(scope.mask) {
			    case 'phone':
			    	filterType = 'phonenumber';
			        break;
			    case 'zip':
			        filterType = 'zipcode';
			        break;
			    case 'ssn':
			        filterType = 'ssnnumber';
			        break;			    
				}
				value = String(value);
				var number = value.replace(/[^0-9-]+/g, '');
				scope.inputValue = $filter(filterType)(number);
				scope.model = scope.inputValue;
			});
		},
		
		template: "<div class='tk-input-masking-margin'><input type='text' id='{{compId}}' class='tk-input-masking {{extraClasses}}' aria-describedby='{{compId}}_tip' ng-model='inputValue'/>" +
				"<div ng-show='showTip' id='{{compId}}_tip' class='tk-input-masking-assistivetext'></div>" +
				"</div>",
	};
}])

.filter('phonenumber', function() {
    //Format phonenumber as: xxx-xxx-xxxx 
    return function (number) {
    	var tempNumber = number.replace(/-/g, '');
        if (!tempNumber) { return ''; }
        
        var formattedNumber = String(tempNumber);

		// ###-###-#### 
		var area = tempNumber.substring(0,3);
		var front = tempNumber.substring(3, 6);
		var end = tempNumber.substring(6, 10);
		
		if (front) {
			formattedNumber = (area + "-" + front);	
		}
		if (end) {
			formattedNumber += ("-" + end);
		}
		
		if(formattedNumber.length == 3 && number.length == 4 && number.charAt(3) == '-') {
			formattedNumber += "-";
		}
		if(formattedNumber.length == 7 && number.length == 8 && number.charAt(7) == '-') {
			formattedNumber += "-";
		}
		return formattedNumber;
    };
})

.filter('zipcode', function() {
    //Format zip code as: xxxxx-xxxx 
    return function (number) {
    	
    	var tempNumber = number.replace(/-/g, '');
        if (!tempNumber) { return ''; }
        
        var formattedNumber = String(tempNumber);

		// #####-#### 		
		var front = tempNumber.substring(0, 5);
		var end = tempNumber.substring(5, 9);

		if (end) {
			formattedNumber = (front + "-" + end);	
		}
		
		if(formattedNumber.length == 5 && number.length == 6 && number.charAt(5) == '-') {
			formattedNumber += "-";
		}
		return formattedNumber;
    };
})

.filter('ssnnumber', function() {
    //Format SSN number as: xxx-xx-xxxx 
    return function (number) {
    	
    	var tempNumber = number.replace(/-/g, '');
        if (!tempNumber) { return ''; }
        
        var formattedNumber = String(tempNumber);

		// ###-##-#### 
		var front = tempNumber.substring(0,3);
		var mid = tempNumber.substring(3, 5);
		var end = tempNumber.substring(5, 9);

		if (mid) {
			formattedNumber = (front + "-" + mid);	
		}
		if (end) {
			formattedNumber += ("-" + end);
		}
		
		if(formattedNumber.length == 3 && number.length == 4 && number.charAt(3) == '-') {
			formattedNumber += "-";
		}
		if(formattedNumber.length == 6 && number.length == 7 && number.charAt(6) == '-') {
			formattedNumber += "-";
		}
		
		return formattedNumber;
    };
});


	
angular.module('uitk.component.uitkLabel',[])
.directive('uitkLabel', function(){
	return {
		restrict : 'E',
		replace : true,
		transclude: true,
		scope : true,
		link : function($scope, $element, $attr, ctrl, transclude) {
			$scope['required'] =  $attr['required'];
			transclude(function(content) {
				$element.find('div').replaceWith(content);
			});

		},
		template: "<label class='tk-labl'><div></div><span ng-if='required' class='oui-a11y-hidden'>, required.</span><span ng-class='{\"cux-icon-asterisk\": required}' aria-hidden='true'></span> " +
				"</label>"
	};
});
var dialogApp = angular.module('uitk.component.uitkDialog',['uitk.component.uitkNavigable','uitk.uitkUtility']);
var x = window.innerWidth/2, y = window.innerHeight/2;

dialogApp.directive('uitkDialog', ["$timeout", "$document", function($timeout,$document) {
    var ESC_KEY_CODE = 27,
        SPACE_KEY_CODE = 32,
        ENTER_KEY_CODE = 13;
    var KEY_BOARD_NAV_CLOSE_TIME = 250;
    return {
        restrict: 'E',
        scope: {
            show: '=',
            dialogRole: '@', 
            confirmDialog: '=', 
            headerText: '@',
            dialogId: '@',
            defaultHeight: '@',
            defaultWidth: '@',
            triggerElement: '@', 
            callBackHide: '&',
            callBackShow: '&',
            tkAriaDescribedby: '@',
            tkZindex:'@' 

        },
        replace: true, 
        transclude: true, 
        link: function(scope, element) {
            scope.dialogStyle = {};
            var dialog = element[0].querySelector('.tk-lbox-dialog');
            var dialogOverlay = element[0].querySelector('.tk-lbox-overlay');
            if(scope.tkZindex){
                dialogOverlay.style.zIndex = Number(scope.tkZindex);
                dialog.style.zIndex = Number(scope.tkZindex)+1;
            }
            element[0].querySelector('.tk-lbox-dialog').focus();

            var isIE = false || !!document.documentMode;
            if(isIE && document.documentMode === 9) {
                dialog.style.marginLeft = '-'+ window.innerWidth/5 + 'px';
                dialog.style.marginTop = '-'+ window.innerHeight/4 + 'px';
            }

            var ios = /iPhone|iPad|iPod/i.test(navigator.userAgent);
            if (ios) {
            };

            scope.hideModal = function(event) {
                if(event) {
                    if (event.keyCode !== SPACE_KEY_CODE && event.keyCode !== ENTER_KEY_CODE) {
                        return;
                    };
                }
                if ( scope.confirmDialog ) { 
                    if (confirm('Are you sure you want to close this dialog?')) { 
                        scope.show = false;
                        dialog.style.top = '50%';
                        dialog.style.left = '50%';
                        x = window.innerWidth/2; y = window.innerHeight/2;

                        if (typeof clearcountdown === 'function') { clearcountdown(); }

                        if(typeof scope.callBackHide === 'function'){
                            scope.callBackHide();
                        }

                        $timeout(function(){
                            angular.element(scope.triggerElement).focus(); 
                        },KEY_BOARD_NAV_CLOSE_TIME);
                    }
                }
                else { 
                    scope.show = false;
                    dialog.style.top = '50%';
                    dialog.style.left = '50%';
                    x = window.innerWidth/2; y = window.innerHeight/2;

                    if (typeof clearcountdown === 'function') { clearcountdown(); }

                    if(typeof scope.callBackHide === 'function'){
                        scope.callBackHide();
                    }
                    $timeout(function() {
                        angular.element(scope.triggerElement).focus(); 
                    },KEY_BOARD_NAV_CLOSE_TIME);
                }

                scope.$applyAsync();
                return false;
            };

            function escHandler (event) {
                if (event.keyCode === ESC_KEY_CODE) {
                    scope.hideModal();
                }
            };

            $document.on('keydown', escHandler);

            scope.$on('$destroy', function () {
                $document.off('keydown', escHandler);
            });


            scope.$watch("show", function ( ) {
                $timeout(function(){
                    if (scope.show === true) { 
                        angular.element(scope.dialogId).focus();
                        scope.callBackShow();
                    }

                }, 500);
            });

            scope.setFocus = function(position){
                switch(position) {
                    case 'start':
                        element[0].querySelector('button#'+scope.dialogId+'_closeLink').focus();
                        break;
                    case 'end':
                        var buttonElements = element[0].querySelectorAll('input[type="button"]');
                        if(buttonElements.length > 0) {
                            buttonElements[buttonElements.length - 1].focus();
                            break;
                        } else {
                            var inputElements = element[0].querySelectorAll('input');
                            var spanElement = element[0].querySelector('div.tk-lbox-content span.oui-a11y-hidden');

                            if(inputElements.length > 0) {
                                inputElements[inputElements.length - 1].focus();
                                break;
                            } else if(spanElement){
                                spanElement.focus();
                                break;
                            }
                        }
                }
            };
        },
        template: "<div class='tk-lbox' ng-show='show' id='{{dialogId}}_main'> "+
        "<span class='oui-a11y-hidden tk-lbox-startElem' tabindex='0' id='{{dialogId}}_startElemId' ng-focus=\"setFocus('end')\">Beginning of dialog</span>"+
        "<div class='tk-lbox-overlay' aria-hidden='{{!show}}' tabindex='-1' style=\"display: block;\"></div>" +
        "<div id='{{dialogId}}' aria-hidden='{{!show}}' tabindex='-1' ng-attr-aria-labelledby='{{dialogId}}_headerId' aria-describedby='{{tkAriaDescribedby ? tkAriaDescribedby : undefined}}' ng-style='{width: defaultWidth}' class='tk-lbox-dialog' role='{{dialogRole}}'>"+
        "<div class='tk-lbox-content-wrapper'>"+

        "<div id='{{dialogId}}_headerId' tabindex='-1' class='tk-lbox-header'>" +
        "<h2><span uitk-dialog-compile-header='headerText' tabindex='-1'></span></h2>"+
        "<h3><span uitk-dialog-compile-header='headerText' tabindex='-1'></span></h3>"+
        "</div>"+
        "<div class='tk-lbox-controls' ><button type='button' uitk-navigable='true' tabindex='0' id='{{dialogId}}_closeLink' ng-click='hideModal();'><span class='cux-icon-close'></span><span class='oui-a11y-hidden'>{{'Close' | uitkTranslate}}</span></button></div>"+
        "<div id='{{dialogId}}_contentId' class='tk-lbox-content tk-padding-1t' ng-style=\"\" style='height: auto;'><span class='oui-a11y-hidden' tabindex='-1'></span><div ng-transclude></div>" +
        "</div>" +
        "</div>"+
        "</div>" +
        "<span class='oui-a11y-hidden tk-lbox-endElem' tabindex='0' id='{{dialogId}}_endElemId' ng-focus=\"setFocus('start')\">End of dialog</span>"+

        "</div>"
    };
}]);


dialogApp.directive('uitkDialogCompileHeader', ["$compile", function ($compile) {
    return function ($scope, $element) {
        $compile($scope.headerText)($scope, function (clone) {
            if (!clone.selector) {
                $element.append(clone);
            } else {
                $element.append(clone.selector);
            }
        });
    };
}]);

angular.module('uitk.component.uitkMessage',['uitk.component.uitkNavigable','uitk.uitkUtility'])
    .directive('uitkMessage', ["$timeout", "uitkExceptionService", function($timeout, uitkExceptionService){
        function controller($scope, $element){

            $scope.messageVisibleFlag = false;
            var timer = null;

            function hideMessage(){
                var d = new Date();
                $scope.startTime = d.getTime();
                timer = $timeout(function(){
                    var d = new Date();
                    var time = d.getTime();
                    if($scope.startTime + $scope.model.messageVisibleTime <= time  && !$scope.customfocus){
                        $scope.model.visible = false;
                        $element.fadeOut($scope.model.animationTime);
                        $timeout(function(){
                            if($scope.model.activeItem) {
                                angular.element($scope.model.activeItem).focus();
                            }
                            $scope.model.rememberMeValue = $scope.message.rememberMeValue;
                            $scope.messageVisibleFlag = false;
                        },$scope.model.animationTime);
                    }
                },$scope.model.messageVisibleTime);
            }

            $scope.$watch('model.visible', function(newValue, oldValue) {
                if(newValue && ($scope.model.rememberMeValue === false)){
                    $scope.messageVisibleFlag = true;
                    $timeout(function(){
                        $scope.addAriaAttribute();
                    });

                    $element.hide();
                    if($scope.model.position !== 'absolute' && $scope.model.position !== 'inline'){
                        if($scope.model.closeButton === undefined){
                            $scope.model.closeButton = true;
                        }

                        $element.fadeIn($scope.model.animationTime,
                            function(){
                                var messageCompId = $scope.model.id;
                                messageCompId="#"+messageCompId;
                                $(messageCompId+ " > .oui-pmsg input:checkbox").attr("tabindex", "0");

                                if (isIE()) {
                                    $element.focus();
                                } else {
                                    angular.element("div",$element)[0].focus();
                                }
                            });
                    }
                    else {
                        $element.show();
                        $timeout(function(){
                            angular.element('#' + $scope.model.id + ' div.oui-pmsg-inline').attr('tabindex',-1);
                            angular.element('#' + $scope.model.id + ' div.oui-pmsg-inline').focus();
                        });
                    }

                    if($scope.model.messageType === 'success' && $scope.model.autoFadeOut){
                        hideMessage();
                    };
                }
                else if(newValue === false && oldValue === true ) {
                    $element.fadeOut($scope.model.animationTime, function(){
                        $scope.closeMessageStart = false;
                        var messageCompId = $scope.model.id;
                        $(messageCompId+ " > .oui-pmsg input:checkbox").attr("tabindex", "0");
                        $scope.messageVisibleFlag = false;
                    });
                }
            });

            $scope.resetTimer = function(){
                if($scope.model.messageType === 'success' && $scope.closeMessageStart === false && $scope.model.autoFadeOut){
                    if($element.is(':animated')) {
                        $element.stop().animate({opacity:'100'});
                    }
                    hideMessage();
                }
            }

            $scope.closeMessage = function(){
                $scope.model.visible = false;
                $element.fadeOut($scope.model.animationTime,function(){
                    $timeout.cancel(timer);
                    angular.element($scope.model.activeItem).focus();
                });
                $scope.closeMessageStart = true;
                $scope.model.rememberMeValue = $scope.message.rememberMeValue;
                $timeout(function() {
                    $scope.messageVisibleFlag = false;
                }, $scope.model.animationTime);
            }

            $scope.checkPosition = function(type){
                if($scope.model.position === type){
                    return true;
                }
                return false;
            }

            $scope.checkMessageType = function(type){
                if($scope.model.messageType === type){
                    return true;
                }
                return false;
            }

            $scope.position = function(){
                return $scope.model.position !== 'absolute' && $scope.model.position !== 'inline';
            }

            $scope.checkEscToCloseMesg = function(e){
                if (e.keyCode === 27) {
                    $scope.closeMessage();
                }
            };
        }
        controller.$inject = ["$scope", "$element"];;

        function isIE() {
            var ua = window.navigator.userAgent;

            if(ua.indexOf('MSIE ')>0 || ua.indexOf('Trident/')>0 || ua.indexOf('Edge/')>0){
                return true;
            }

            return false;
        };

        function link($scope, $element){
            var allowedMessageType = ['success','error','warning','information'];
            if(!_.includes(allowedMessageType, $scope.model.messageType)){
                uitkExceptionService.throwException('MessageTypeNotSupportedException',$scope.model.messageType + ' is not supported');
            };

            if(!$scope.model.id){
                uitkExceptionService.throwException('InvalidIdException','Id is required attribute');
            }

            if($scope.model.messageType === 'error' && $scope.model.rememberMe){
                uitkExceptionService.throwException('RememeberMeNotSupportedException','Remember me not supported for error message');
            }

            if($scope.model.messageType !== 'success' && $scope.model.messageVisibleTime){
                uitkExceptionService.throwException('MessageVisibleTimeNotSupportedException','Message visible time supported only for success message');
            }

            if($scope.model.rememberMeValue === undefined){
                $scope.model.rememberMeValue = false;
            }

            if($scope.model.autoFadeOut === undefined){
                $scope.model.autoFadeOut = true;
            }

            $scope.message = {rememberMeValue : false};
            if(!$scope.model.messageVisibleTime){
                $scope.model.messageVisibleTime = 5000;
            }
            if(!$scope.model.animationTime){
                $scope.model.animationTime = 1000;
            }

            if($scope.model.position === 'absolute' && !$scope.model.visible){
                $element.hide();
            }

            if(!$scope.model.rememberMe){
                $scope.model.rememberMe = false;
            }

            $scope.addAriaAttribute = function(){
                if($scope.model.position && $scope.model.position === 'inline') {
                    $element.find('div.oui-pmsg').removeAttr('tabindex');
                    $element.find('span.oui-a11y-hidden').removeAttr('tabindex');
                    if(isIE()) {
                        $element.find('div:first-child').attr("role", $scope.model.messageRole);
                    } else {
                        $('#'+$scope.model.id).attr("role", $scope.model.messageRole);
                    }
                } else {
                    $element.find('div:first-child').attr("role", $scope.model.messageRole);
                }

                if($scope.model.ariaAttributes) {
                    $element.find('div:first-child').attr('aria-labelledby', $scope.model.id+'-label');
                    $element.find('div:first-child').attr('aria-describedby', $scope.model.id+'-description');
                    $element.find('div:first-child').attr('uitk-navigable', 'true');
                } else {
                    $element.find('div:first-child').attr('uitk-navigable', 'false');
                }

                if($scope.model.headingLevel) {
                    $element.find('#' + $scope.model.id + '-label').attr('aria-level', $scope.model.headingLevel);
                }
            }
        }

        return {
            restrict: 'E',
            replace : true,
            transclude: true,
            controller: controller,
            link: link,
            scope: {
                model : '='
            },
            template : [
                '<div  id="{{model.id}}" ng-class="{\'oui-pmsg-wrapper\' : position()}" aria-hidden="{{!model.visible || model.rememberMeValue}}" class="message-container" ng-keyup="checkEscToCloseMesg($event)" >',
                '<div ng-if="messageVisibleFlag" ng-class="{\'oui-pmsg-success\': checkMessageType(\'success\'),\'oui-pmsg-error\': checkMessageType(\'error\'),\'oui-pmsg-inline\': checkPosition(\'inline\'),\'oui-pmsg-warning\': checkMessageType(\'warning\'),\'oui-pmsg-informational\': checkMessageType(\'information\'),\'oui-pmsg-absolute\':!position()}" ng-mouseover="resetTimer();" ng-focus="customfocus=true" ng-blur="customfocus=false" class="oui-pmsg" aria-hidden="{{!model.visible || model.rememberMeValue}}" tabindex="{{model.position == \'absolute\' ? 0 : -1}}">',
                '	<span ng-class="{\'cux-icon-checkmark_status\': checkMessageType(\'success\'),\'cux-icon-exclamationmark\': checkMessageType(\'error\'),\'cux-icon-warning\': checkMessageType(\'warning\'),\'cux-icon-information\': checkMessageType(\'information\')}"></span>',
                '	<div ng-class="{\'oui-pmsg-success-body\': checkMessageType(\'success\'),\'oui-pmsg-error-body\': checkMessageType(\'error\'),\'oui-pmsg-warning-body\': checkMessageType(\'warning\'),\'oui-pmsg-informational-body\': checkMessageType(\'information\')}" >',
                '		<span id={{model.id}}-label class="oui-a11y-hidden" role="heading" tabindex="-1">{{model.messageType}} message</span>',
                '		<span id={{model.id}}-description tabindex="-1" uitk-compile-message></span>',
                '		<div ng-transclude></div>',
                '		<div ng-if="model.rememberMe && !(checkMessageType(\'error\'))" aria-hidden="{{!(model.rememberMe && !checkMessageType(\'error\'))}}" class="tk-margin-top-halft"><input type="checkbox" id={{model.id}}-checkbox ng-model="message.rememberMeValue" uitk-navigable="model.rememberMe && !(checkMessageType(\'error\'))" ng-focus="resetTimer();" tabindex="-1"/> <label id={{model.id}}-labelContent for={{model.id}}-checkbox >{{"Do not show this message again." | uitkTranslate}}</label></div>',
                '	</div>',
                '	<button type="button" class="oui-pmsg-close" uitk-navigable="true" ng-if="model.closeButton" onclick="return false;" ng-click="closeMessage()" ng-focus="resetTimer();">',
                '		<span class="cux-icon-close"></span><span class="oui-a11y-hidden">Close {{model.messageType}} message</span>',
                '	</button>',
                '</div>',
                '</div>'
            ].join('')
        };
    }])
    .directive('uitkCompileMessage', ["$compile", function ($compile) {
        return function($scope, $element) {
            $scope.$watch('model.content',function(){
                $compile($scope.model.content)($scope, function(clone){
                    $element.empty();
                    $element.append(clone);
                });
            });
        };
    }]);

angular.module('uitk.component.uitkPanel',['uitk.component.uitkSlideAnimation','uitk.component.uitkNavigable','uitk.uitkUtility'])
.directive('uitkPanel', ["$compile", "uitkExceptionService", function($compile, uitkExceptionService){

		return {
		restrict : 'E',
		replace : true,
		scope : {
			model : '=',
            scope : '='
		},
		template: [
		           "<div class='tk-panl {{model.styleClass}}' id='{{model.id}}' ng-class='openStyle' ng-style=\"{'width': '{{model.panelWidth}}'}\" >",
		           "<div class='tk-panl-header {{model.headerClass}} tk-panl-header-w-actions' ng-click='togglePanel($event)'>",
		           		"<h2 ng-if='model.title && !model.titleH3'>",
			           		"<a ng-if='model.collapsible' class='tk-panl-helper' href='#' aria-expanded='{{model.open}}' aria-controls='{{model.id}}Content'>",
			           			"<span ng-if='model.open' class='cux-icon-carrot_down'></span>",
			           			"<span ng-if='!model.open' class='cux-icon-carrot_right'></span>",	
			           			"<span uitk-panel-compile-header='model.title'></span>",
			           		"</a>",
			           		"<span ng-if='!model.collapsible'><span uitk-panel-compile-header='model.title'></span></span>",
		           		"</h2>",
		           		"<h3 ng-if='model.title && model.titleH3'>",
			           		"<a ng-if='model.collapsible' class='tk-panl-helper' href='#' aria-expanded='{{model.open}}' aria-controls='{{model.id}}Content'>",
				           		"<span ng-if='model.open' class='cux-icon-carrot_down'></span>",
				           		"<span ng-if='!model.open' class='cux-icon-carrot_right'></span>",
				           		"<span uitk-panel-compile-header='model.title'></span>",
			           		"</a>",
			           		"<span ng-if='!model.collapsible'><span uitk-panel-compile-header='model.title'></span></span>",
			           	"</h3>",
			           	"<ul ng-show='model.showActionLinks' ng-click='$event.stopPropagation();'>",
			           		"<li ng-repeat='link in model.links' class='liclass'>",
				           		"<a ng-hide='link.disabled' ng-href='{{link.url}}' ng-click='linkClick(link, $event);' uitk-navigable='true'>",
				           			"<span uitk-panel-compile-link-text='link'></span>",
								"</a>",
								"<span ng-hide='!link.disabled' aria-disabled='true' role='link' class='tk-panl-disabled-link {{link.iconClass}}'><span uitk-panel-compile-link-text='link'></span></span>",
			           		"</li>",
			           	"</ul>",
			       "</div>",
			       "<div uitk-slide-show='model.open' uitk-slide-show-duration='500' class='tk-panl-content-wrapper'>",
			       		"<div class='tk-panl-content {{model.contentClass}}' ng-class=\"{'tk-panl-content-overflow-auto':model.panelHeight || model.panels}\" ",
                        "ng-style=\"{'max-height':'{{model.panelHeight}}','width':'{{model.panelWidth}}'}\" id='{{model.id}}Content' >",
			       			"<ng-include ng-if='!model.panels' src=\"model.templateUrl\" class='panelClass' ></ng-include>",
			       			"<uitk-panel ng-repeat='panel in model.panels' model='panel' class='panelClass'>{{panel.title}}</uitk-panel>",
			       		"</div>",
			       "</div>",
			       "</div>"].join(""),			       
		controller: ['$scope', '$element', function ($scope) {

			$scope.togglePanel = function(event) {
				if ($scope.model.collapsible === undefined || $scope.model.collapsible === false) 
					return;
				event.preventDefault();
				event.stopPropagation();
				$scope.model.open = !$scope.model.open;
			}

			$scope.linkClick = function(link){
				if(link.callBack){
					link.callBack.call();
				}
			}

		}],
		compile: function(tElement) {
			var contents = tElement.contents().remove();
			var compiledContents;
			return function($scope, iElement) {
				if(!compiledContents) {
					compiledContents = $compile(contents);
				}
				compiledContents($scope, function(clone) {
					iElement.append(clone);
				});

			if(!$scope.model){
                uitkExceptionService.throwException('EmptyModelException','Model is undefined');
	        }

			if(!$scope.model.id){
                uitkExceptionService.throwException('InvalidIdException','Id is required attribute');
	        }

			if(!$scope.model.title){
                uitkExceptionService.throwException('InvalidTitleException','Title is required attribute');
	        }

			if($scope.model.links){
				_.forEach($scope.model.links, function(link){
					if(!link.text){
                        uitkExceptionService.throwException('InvalidLinkTextException','Link Text is required attribute');
					}
				});
			}

						if($scope.model.links && $scope.model.showActionLinks === undefined){
				$scope.model.showActionLinks = true;
			}

			if($scope.model.open === undefined){
				$scope.model.open = false;
			}

						if ($scope.model.collapsible === true) {
				if ($scope.model.open === true) {
					$scope.openStyle =  'tk-panl-open';
				} else {
					$scope.openStyle =  'tk-panl-closed';
				}
			} else {
				 var headerBlock = iElement[0].querySelector('.tk-panl-header');
				 if(headerBlock){
					 headerBlock.removeAttribute("ng-click");
				 }
			}
		}

				}
	};
}])
.directive('uitkPanelCompileHeader', ["$compile", function ($compile) {
	  return function($scope, $element) {
		  $compile($scope.model.title)($scope, function(clone){
	    	if(!clone.selector) {
	    		$element.append(clone);
	    	} else {
	    		$element.append(clone.selector);
	    	}
	    });
	  };
}])
.directive('uitkPanelCompileLinkText', ["$compile", function ($compile) {
	  return function($scope, $element) {
		  $compile($scope.link.text)($scope, function(clone){
	    	if(!clone.selector) {
			  $element.append(clone);
	    	} else {
	    		$element.append(clone.selector);
	    	}
	    });
	  };
}]);
angular.module('uitk.component.uitkPrimaryNavigation', ['uitk.component.uitkSlideAnimation','uitk.component.uitkNavigable','uitk.uitkUtility'])
.directive('uitkPrimaryNavigation', ['$compile','$document','$timeout','$location','$sce','$filter','uitkExceptionService',function($compile,$document,$timeout,$location,$sce,$filter, uitkExceptionService){

		function controller($scope){
		$scope.model.level = $scope.$parent.model ? $scope.$parent.model.level + 1 : 1;

		var nonDisabledLinks = $scope.model.links.filter(function(link){ return !link.disabled});
		var firstNonDisabledLink = nonDisabledLinks[0];
		firstNonDisabledLink.firstLinkInDropDown = true;
		var lastNonDisabledLink = nonDisabledLinks[nonDisabledLinks.length - 1];
		lastNonDisabledLink.lastLinkInDropDown = true;

				if($scope.model.level === 1){

			$scope.model.menuVisible = true;
			$document.on("click", function ($event) {
				 if(!$event.target.keepPrimaryDropdownFlag){
					 $scope.$apply(function(){
						 $scope.hideAllMenus();
					 });
				 }
		     });


									var touchInterface = 'ontouchstart' in window || navigator.msMaxTouchPoints;
			 if(!touchInterface){
				 $timeout(function(){
					 var totalWidth = $(".tk-pnav li:last").offset().left -  $(".tk-pnav li:first").offset().left + $(".tk-pnav li:last").width();
					 var reducedWidth = 2;
					 var dLeft = $('.tk-pnav li:first').offset().left;
					 var dWidth = $('.tk-pnav li:first').width() + reducedWidth;
					 $('.tk-pnav-hover-div').css({visibility:"hidden"});
					 $('.tk-pnav-hover-div').stop().animate({left:dLeft, width:dWidth},{duration:'slow'});

									$(".tk-pnav > li").on("mouseover",function(){
						var position = $(this).offset().left;
						if($('.tk-head').length > 0){
							position = position - $('.tk-head').offset().left - 1;
						}
						var width = $(this).width()+ reducedWidth; 
						$('.tk-pnav-hover-div').css({visibility:"visible"});
						$('.tk-pnav-hover-div').stop().animate({left:position, width:width},{duration:'slow'});
					});

					$(".tk-pnav").mouseleave(
						function(){
							$('.tk-pnav-hover-div').css({visibility:"hidden"});
						}		
					);

					 				 },1000);
			 }

		}

		$scope.hideAllMenus = function(){
			var linkWithDropDowns = $scope.model.links;

			while(linkWithDropDowns.length > 0) {
				linkWithDropDowns = linkWithDropDowns.filter(function(link){ return link.dropDown; }); 
				var allDropdownUnderLink = linkWithDropDowns.map(function(link){ return link.dropDown; }); 
				allDropdownUnderLink.forEach(function(dropDown) { dropDown.menuVisible = false; }) 
				linkWithDropDowns = allDropdownUnderLink
				 						.filter(function(dropDown){ return dropDown.links; })
				 						.map(function(dropDown){ return dropDown.links; })
				 						.reduce(function(allLink, links){ return allLink.concat(links);}, []);
			}
		};

				$scope.expandMenuOrRedirectToLink = function($event, item){
			$event.target.keepPrimaryDropdownFlag = true;

			var linksWithDropDown = $scope.model.links.filter(function(link) { return link !== item; }).filter(function(link){ return link.dropDown;});
			linksWithDropDown.forEach(function(link) {
				link.dropDown.menuVisible = false;
				link.dropDown.links.forEach(function(link) {
					if(link.dropDown) {
						link.dropDown.menuVisible = false;
					}
				});
			});

			if(item.dropDown) {
				item.dropDown.menuVisible = item.dropDown.menuVisible?!item.dropDown.menuVisible:true;

								if(item.dropDown.menuVisible) { 
					item.dropDown.setOnFocus(); 
					if(item.dropDown.level === 3){
						$scope.checkMenuPosition();
					}
				}
				else{
					item.dropDown.links.forEach(function(subItem) {
						if(subItem.dropDown){
							subItem.dropDown.menuVisible = false;
						}
					});
				}
			}

			if(item.url){
				if(item.url[0] === '#'){
					$location.path(item.url.substring(1));
				}
				else{
					window.location = item.url;
				}

				if($scope.model.level > 1){
					var scope = $scope;
					while(scope.$parent.model !== undefined){
						scope = scope.$parent;
					}

					scope.model.links.forEach(function(link){link.selected = false;});
					scope.model.links.forEach(function(link){if(link.dropDown && link.dropDown.menuVisible){link.selected = true;}});
				}
				else{
					$scope.model.links.forEach(function(link){link.selected = false;});
					item.selected = true;
				}

				scope = $scope;
				while(scope.model.level !== 1 ){
					scope.model.menuVisible = false;
					scope = scope.$parent.$parent.$parent;
				}

				$('.tk-pnav-hover-div').css({visibility:"hidden"});

			}

					};	

				$scope.hideParentMenu = function(event, item) {
            if ( event.which === 27 ) {
                if ( $scope.model.level > 1 ) {
                    $scope.model.menuVisible = false; 
                    $scope.focusItem.focusMe = true;

                }
            }

			else if($scope.model.level > 1 && (event.which === 9) && !event.shiftKey){
				if(item.lastLinkInDropDown ) {
					if(!item.dropDown) {
						$scope.model.menuVisible = false;
						if($scope.$parent.$parent.item.lastLinkInDropDown) {
							$scope.$parent.$parent.$parent.model.menuVisible= false;
						}
					}	
					else if(!item.dropDown.menuVisible) {  
						$scope.model.menuVisible = false;
					}	
				}
			}
			else if($scope.model.level > 1 && (event.which === 9) && event.shiftKey && item.firstLinkInDropDown) {
				$scope.model.menuVisible = false;
			}
		};

				$scope.isExpanded = function(item){
			if(item.dropDown){
				if(item.dropDown.menuVisible){
					return true;
				}
				else { 
					return false;
				}
			}
			else{
				return undefined;
			}
		};

				$scope.getTrustedTextTemplate = function(item) {
            return $sce.trustAsHtml(item.textTemplate);
        };

		if ($scope.model.level > 1 && $scope.focusItem) {
            $scope.focusItem.focusMe = false;
        }
	}
	controller.$inject = ["$scope"];

	return {
		restrict : 'E',
		replace : true,
		transclude : true,
		scope : {
			model : '=',
            focusItem : '='
		},
		controller : controller,
		compile:function(tElement) {
            var contents = tElement.contents().remove();
            var compiledContents;
            return function(scope, iElement) {

            	if(!compiledContents) {
                    compiledContents = $compile(contents);
                }
                compiledContents(scope, function(clone, scope) {
                         iElement.append(clone); 
                         if(scope.model.level === 1){ 
                        	 iElement.after("<div id=\"pnavhorizontalslider\" class=\"tk-pnav-hover-div\"></div>");
                         }
                });

				scope.model.links.forEach(function(link){ if(link.url && link.dropDown){
					uitkExceptionService.throwException('InvalidLinkException','Link can not have both url and dropDown element');
				}});

                                scope.model.setOnFocus = function() {
        			$timeout(function(){ iElement.find('a')[0].focus(); }, 750) ;
        		};

        		        		scope.model.links.forEach(function(link,index){
        			link.setFocus = function(){
        				var otherElement = iElement.find('ul a');
        				$timeout(function(){ iElement.find('a').not(function(index, element){
        					return _.includes(otherElement, element);
        				})[index].focus(); }) ;
        			}
        		});

        		        		scope.checkMenuPosition = function(){
        			var elementRightPosition = iElement[0].getBoundingClientRect().right;
        			var elementWidth = iElement[0].getBoundingClientRect().width;
        			var screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        			if(screenWidth < elementRightPosition + elementWidth){
        				scope.model.links.forEach(function(link){if(link.dropDown){link.dropDown.menuPosition = true;}})
        			}
        		};
            };
        },
		template : [
					'<ul ng-class=\'{"tk-pnav-submenu-open": model.menuVisible,"tk-pnav-to-the-left": model.menuPosition, "tk-pnav": model.level===1 }\' uitk-slide-show="model.menuVisible" uitk-slide-show-duration="500">',
					'	<li ng-repeat="item in model.links" ng-class=\'{"tk-pnav-selected": item.selected, "tk-pnav-disabled": item.disabled}\' ng-if="!item.hidden">',
					'	<a href="javascript:void(0)" ng-if="!item.disabled" ng-click="expandMenuOrRedirectToLink($event,item)" ng-keydown="hideParentMenu($event, item)" uitk-compile-link="item" apply-parent-focus>',
                    '   <span ng-if="item.dropDown && model.level >= 1" class="oui-a11y-hidden">Has Submenu.</span>',
                    '   <span ng-if="item.dropDown && model.level === 1" class="cux-icon-carrot_down"></span>',
                    '       <span ng-if="item.dropDown && model.level === 2" class="cux-icon-carrot_right"></span>',
                    '       <span class="oui-a11y-hidden">',
                    '       <span ng-if="item.dropDown && model.level >= 1 && isExpanded(item)">Expanded</span>',
                    '       <span ng-if="item.dropDown && model.level >= 1 && !isExpanded(item)">Collapsed</span>',
                    '   </span>',
					'   </a>',
					'	<span ng-click="$event.stopPropagation();" role="link" aria-disabled="true" ng-if="item.disabled" ng-bind-html="getTrustedTextTemplate(item)"></span>',
					'	<uitk-primary-navigation ng-if="item.dropDown" model="item.dropDown" focus-item="item"></uitk-primary-navigation>',
					'	</li>',
					'</ul>'
		           ].join('')

			};
}])

    .directive('applyParentFocus', function() {
        return {
            link : function(scope, element) {
                if ( scope.item ) {
                    scope.$watch('item.focusMe', function(a, b) {
                        if ( scope.item.focusMe ) {
                            element.focus();
                            scope.item.focusMe = false;
                        }
                    })
                }
            }
        }
    })

.directive('uitkCompileLink', ["$compile", function ($compile) {
	  return function($scope, $element) {
		  $compile($scope.item.textTemplate)($scope, function(clone){
			  if(!clone.selector){
				  $element.prepend(clone);
			  }
			  else{
				  $element.prepend(clone.selector);
			  }
	    });
	  };
}]);


(function () {
    var uitkSelectDirective = function (uitkExceptionService) {
        return {
            restrict: 'E',
            replace: true,
            transclude: true,
            link: function (scope) {

                if (scope.itemList.length == 0) {
                    uitkExceptionService.throwException('ListItemLengthCannotBeZero','List item array length cannot be zero');
                }

                if (scope.checkFieldValidation === undefined) {
                    scope.checkFieldValidation = false;
                }

                scope.$watch("selectedValue", function (newValue, oldValue) {
                    if (!(newValue === scope.itemList[0])) {
                        scope.checkFieldValidation = true;
                    } else {
                        scope.checkFieldValidation = false;
                    }
                }, true);

                if (!scope.selectedValue) {
                    scope.selectedValue = scope.itemList[0];
                }

            },
            scope: {
                itemList: '=', 
                selectedValue: '=', 
                tkRequired: '@',     
                tkErrorClass: '=',
                onChange: '&',
                tkName:'@',
                checkFieldValidation: '=' 
            },
            template: function (ele,attr) {

                                if (!attr.name) {
                    return "<select ng-model='selectedValue'  name='{{tkName}}' ng-change='onChange(selectedValue)'  class='tk-sngl-dpwn' ng-style=\"{'width': 'auto'}\" ng-options='item.label disable when item.isDisabled for item in itemList' ng-attr-aria-invalid='{{tkErrorClass === undefined ? false : tkErrorClass}}' n-required='(tkRequired && checkFieldValidation) ? true : false' aria-required='{{(tkRequired ) ? true : false}}'>" +
                     "</select>"
                }
               return "<select ng-model='selectedValue' ng-change='onChange(selectedValue)'  class='tk-sngl-dpwn' ng-style=\"{'width': 'auto'}\" ng-options='item.label disable when item.isDisabled for item in itemList' ng-attr-aria-invalid='{{tkErrorClass === undefined ? false : tkErrorClass}}' ng-required='(tkRequired && checkFieldValidation) ? true : false' aria-required='{{(tkRequired ) ? true : false}}'>" +
            "</select>"

            }
        };
    };

    uitkSelectDirective.$inject = ['uitkExceptionService'];

    angular.module('uitk.component.uitkSelect',['uitk.uitkUtility'])
        .directive('uitkSelect', uitkSelectDirective);
})();

(function() {
    var app;
    app = angular.module("uitk.component.uitkCalendar", ['uitk.uitkUtility']);
    app.provider("uitkCalendarDefaults", function() {
        return {
            options: {
                dateFormat: 'MM-dd-yyyy',
                dateFormatDisplayTip: 'mm-dd-yyyy',
                timeFormat: 'h:mm a',
                labelFormat: null,
                placeholder: '',
                hoverText: null,
                disableTimepicker: true,
                disableClearButton: false,
                defaultTime: null,
                weekdayDay: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                dayAbbreviations: [ ["Sun","Sunday"], ["Mon","Monday"], ["Tue","Tuesday"], ["Wed","Wednesday"], ["Thu","Thursday"], ["Fri","Friday"], ["Sat","Saturday"] ],
                monthsList:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
                monthsListLong:["January","February","March","April","May","June","July","August","September","October","November","December"],
                minYear:'1900',
                maxYear:'2019',
                textFieldClassName: 'textField',
                validationErrorsMap:{"requiredMessage":"Date is required.","invalidFormatMessage":"Invalid date format.","outOfRangeMessage":"Date must be between ","invalidDateMessage":"Invalid date."},
                dateFilter: null,

                parseDateFunction: function(str) {
                    if(str.length === 10 && str.indexOf("-") > 0) {
                        var parts = str.split('-');
                        var parsedDate = new Date(parts[2], parts[0]-1, parts[1]); 
                        return parsedDate;
                    }
                    var seconds;
                    seconds = Date.parse(str);
                    if (isNaN(seconds)) {
                        return null;
                    } else {
                        return new Date(seconds);
                    }
                } 
            },
            $get: function() {
                return this.options;
            },
            set: function(keyOrHash, value) {
                var k, v, _results;
                if (typeof keyOrHash === 'object') {
                    _results = [];
                    for (k in keyOrHash) {
                        if(keyOrHash.hasOwnProperty(k)) {
                            v = keyOrHash[k];
                            _results.push(this.options[k] = v);
                        }
                    }
                    return _results;
                } else {
                    return this.options[keyOrHash] = value;
                }
            }
        };
    });

    app.filter('mydate', function() {
        return function (number) {
            if (!number) { return ''; }
            number = String(number.trim());
            var formattedNumber = number;

            var m = number.substring(0,2);
            var d = number.substring(2, 4);
            var y = number.substring(4, 8);
            if (d) {
                formattedNumber = (m + "-" + d);
            }
            if (y) {
                formattedNumber += ("-" + y);
            }
            return formattedNumber;
        };
    });

    app.directive("uitkCalendar", [
        'uitkCalendarDefaults', '$filter', '$sce', function(uitkCalendarDefaults, $filter, $sce) {
            return {
                restrict: "E",
                require: "?ngModel",
                scope: {
                    dateFilter: '=?',
                    onChange: "&",
                    required: '@', 
                    id: '@',
                    labelledBy: '@',
                    viewModel:"=" 

                },
                replace: true,
                templateUrl: function (element, attrs) {
                    return attrs.templateUrl || 'template/uitk-calendar.html';
                },
                link: function(scope, element, attrs, ngModelCtrl) {
                    var datepickerClicked, datesAreEqual, datesAreEqualToMinute, debounce, getDaysInMonth, initialize,
                        parseDateString, refreshView, setCalendarDate, setConfigOptions, setInputFieldValues,
                        setupCalendarView, stringToDate;

                    scope.$watch('viewModel.minYear', function(newValue, oldValue) {
                        scope.years.length = 0;
                        populateYears();
                    });

                    scope.$watch('viewModel.maxYear', function(newValue, oldValue) {
                        scope.years.length = 0;
                        populateYears();
                    });

                    scope.$watch('viewModel.dateText', function(newVal, oldVal) {
                        if ( newVal.length == 10 ) {
                            var isValid = scope.isValidDate(newVal);
                            if ( isValid ) {
                                var date = parseDateString(newVal);
                                if ( typeof scope.minDate !== 'undefined' ) {
                                    var minDateObj = parseDateString(scope.minDate);
                                    if (date < minDateObj) {
                                        scope.invalid = true;
                                    }
                                }
                                if (  typeof scope.maxDate !== 'undefined' ) {
                                    var maxDateObj = parseDateString(scope.maxDate);

                                    if ( date > maxDateObj ) {
                                        scope.invalid = true;
                                    }
                                }
                            }
                        }

                    });

                    var populateYears  = function(){
                        scope.minYear = scope.viewModel.minYear || scope.minYear;
                        scope.maxYear = scope.viewModel.maxYear || scope.maxYear;

                        scope.minDate = scope.viewModel.minDate || scope.minDate;
                        scope.maxDate = scope.viewModel.maxDate || scope.maxDate;

                        if ( typeof scope.minDate !== 'undefined' && typeof scope.maxDate !== 'undefined' ) {
                            var isValidMinDate = scope.isValidDate(scope.minDate);
                            if ( isValidMinDate === false ) {
                                scope.viewModel.errorMessage = "Invalid min or max date provided in view model.";
                                return;
                            }

                            var strMinDate = scope.minDate.split('-');
                            var strMaxDate = scope.maxDate.split('-');

                            scope.minYear = parseInt(strMinDate[2], 10);
                            scope.maxYear = parseInt(strMaxDate[2], 10);
                        }

                        for(var i=Number(scope.minYear);i<=scope.maxYear;i++){
                            scope.years.push(i);
                        }
                    };

                    scope.viewModel = scope.viewModel || {};
                    scope.viewModel.required = scope.required || scope.viewModel.required;
                    scope.displayTipText = $sce.trustAsHtml(scope.viewModel.displayTipText) || $sce.trustAsHtml('<span class="oui-a11y-hidden">Format</span> mm-dd-yyyy');
                    scope.displayTipId = scope.viewModel.displayTipId || scope.id;

                    if ( scope.viewModel.iconCalendar === false ) {
                        scope.viewModel.iconCalendar = false;
                    }
                    else {
                        scope.viewModel.iconCalendar = true;
                    }

                    initialize = function() {
                        var templateDate;
                        setConfigOptions();
                        scope.toggleCalendar(false);
                        scope.weeks = [];
                        scope.years = [];
                        scope.inputDate = null;
                        scope.inputTime = null;
                        scope.invalid = true;


                        if (typeof attrs.initValue === 'string') {
                            ngModelCtrl.$setViewValue(attrs.initValue);
                        }
                        if (!scope.defaultTime) {
                            templateDate = new Date(2013, 0, 1, 12, 0);
                            scope.datePlaceholder = $filter('date')(templateDate, scope.dateFormat);
                        }
                        setCalendarDate();
                        scope.selectedYear = scope.calendarDate.getFullYear();
                        scope.selectedMonth = scope.monthsList[scope.calendarDate.getMonth()];
                        scope.selectedMonthLong = scope.monthsListLong[scope.calendarDate.getMonth()];

                        if ((scope.id !== undefined) && (scope.id !== '')){
                            scope.inputCompId = scope.id.trim();
                        } else {
                            scope.inputCompId = 'input_'+randomId(6);
                        }
                        scope.textFieldClassName = scope.viewModel.textFieldClassName || scope.textFieldClassName;
                        populateYears();

                        return refreshView();
                    };

                    scope.getAriaDescribedBy = function () {
                        if(!scope.viewModel.supressAriaDescribedBy) {
                            scope.ariaDescribedByIds = '';
                            scope.ariaDescribedByTipId = scope.viewModel.displayTipId || scope.id; 

                            if(scope.viewModel.invalid === true){ 
                                scope.ariaDescribedByIds = scope.id + "_err";
                            }
                            if(scope.ariaDescribedByTipId) { 
                                scope.ariaDescribedByIds += " "+ scope.ariaDescribedByTipId + "_tip";
                            }
                            return scope.ariaDescribedByIds ? scope.ariaDescribedByIds : undefined;
                        } else {
                            return undefined;
                        }
                    };

                    scope.checkPrevAndNextMonthStatus=function(){
                        scope.disablePrevMonthSelection = false;
                        scope.disableNextMonthSelection=false;

                        if((scope.selectedYear < scope.minYear) ||(scope.selectedYear === scope.years[0] && scope.monthsList[0] === scope.selectedMonth) ){
                            scope.disablePrevMonthSelection = true;
                        }

                        if((scope.selectedYear > scope.maxYear) ||(scope.selectedYear === scope.years[scope.years.length-1] && scope.monthsList[11] === scope.selectedMonth) ){
                            scope.disableNextMonthSelection = true;
                        }
                    };

                    setConfigOptions = function() {
                        var key, value;
                        for (key in uitkCalendarDefaults) {
                            if(uitkCalendarDefaults.hasOwnProperty(key)) {
                                value = uitkCalendarDefaults[key];
                                if (!scope[key] && attrs[key]) {
                                    scope[key] = attrs[key];
                                } else if (!scope[key]) {
                                    scope[key] = value;
                                }
                            }
                        }

                        if (!scope.labelFormat) {
                            scope.labelFormat = scope.dateFormat;
                            if (!scope.disableTimepicker) {
                                scope.labelFormat += " " + scope.timeFormat;
                            }
                        }

                    };

                    datepickerClicked = false;

                    window.document.addEventListener('click', function() {
                        if (scope.calendarShown && !datepickerClicked) {
                            scope.toggleCalendar(false);
                            scope.$apply();
                        }

                        return datepickerClicked = false;
                    });


                    angular.element(element[0])[0].addEventListener('click', function() {
                        return datepickerClicked = true;
                    });

                    refreshView = function() {
                        var date = ngModelCtrl.$modelValue ? parseDateString(ngModelCtrl.$modelValue) : null;
                        setupCalendarView();
                        setInputFieldValues(date);
                        scope.checkPrevAndNextMonthStatus();
                        scope.viewModel.dateText = date ? $filter('date')(date, scope.dateFormat) : scope.placeholder;
                        scope.getAriaDescribedBy();
                        return scope.invalid = ngModelCtrl.$invalid;
                    };

                    setInputFieldValues = function(val) {
                        if (val != null) {
                            scope.inputDate = $filter('date')(val, scope.dateFormat);
                            return;
                        } else {
                            scope.inputDate = null;
                            return;
                        }
                    };

                    setCalendarDate = function(val) {

                        if ( typeof val !== 'undefined' && val !== null ) {
                            var d = new Date(val);
                            if (d.toString() === "Invalid Date" ) {
                                var strDate = val.toString().split('-');
                                var composedDate = new Date(strDate[2] +"-" + strDate[0] + "-" + strDate[1] + "T00:00:00.000Z");
                                return scope.calendarDate = composedDate;
                            }
                            else {
                                return scope.calendarDate = d;
                            }

                        }
                        else {
                            return scope.calendarDate = new Date();
                        }

                    };

                    setupCalendarView = function() {
                        var curDate, d, daysInMonth, numRows, offset, row, selected, time, today, weeks, _i, _j, _ref;
                        daysInMonth = getDaysInMonth(scope.calendarDate.getFullYear(), scope.calendarDate.getMonth());
                        weeks = [];
                        curDate = new Date(scope.calendarDate.getFullYear(),scope.calendarDate.getMonth(),1);
                        offset = curDate.getDay();
                        numRows = Math.ceil((offset + daysInMonth) / 7);
                        curDate.setDate(curDate.getDate() + (offset * -1));
                        for (row = _i = 0, _ref = numRows - 1; 0 <= _ref ? _i <= _ref : _i >= _ref; row = 0 <= _ref ? ++_i : --_i) {
                            weeks.push([]);

                            for (_j = 0; _j <= 6; ++_j) {

                                d = new Date(curDate);
                                if (scope.defaultTime) {
                                    time = scope.defaultTime.split(':');
                                    d.setHours(time[0] || 0);
                                    d.setMinutes(time[1] || 0);
                                    d.setSeconds(time[2] || 0);
                                }
                                selected = ngModelCtrl.$modelValue && d && datesAreEqual(d, ngModelCtrl.$modelValue);
                                today = datesAreEqual(d, new Date());
                                weeks[row].push({
                                    date: d,
                                    selected: selected,
                                    disabled: typeof scope.dateFilter === 'function' ? !scope.dateFilter(d) : false,
                                    other: d.getMonth() !== scope.calendarDate.getMonth(),
                                    today: today
                                });
                                curDate.setDate(curDate.getDate() + 1);
                            }
                        }
                        return scope.weeks = weeks;
                    };

                    ngModelCtrl.$parsers.push(function(viewVal) {
                        if (scope.required && (viewVal == null)) {
                            ngModelCtrl.$setValidity('required', false);
                            return null;
                        } else if (angular.isDate(viewVal)) {
                            ngModelCtrl.$setValidity('required', true);
                            return viewVal;
                        } else if (angular.isString(viewVal)) {
                            ngModelCtrl.$setValidity('required', true);
                            return scope.parseDateFunction(viewVal);
                        } else {
                            return null;
                        }
                    });

                    ngModelCtrl.$formatters.push(function(modelVal) {
                        if (angular.isDate(modelVal)) {
                            return modelVal;
                        } else if (angular.isString(modelVal)) {
                            return scope.parseDateFunction(modelVal);
                        } else {
                            return void 0;
                        }
                    });

                    stringToDate = function(date) {
                        if (typeof date === 'string') {
                            return parseDateString(date);
                        } else {
                            return date;
                        }
                    };

                    parseDateString = uitkCalendarDefaults.parseDateFunction;

                    datesAreEqual = function(d1, d2, compareTimes) {
                        if (compareTimes == null) {
                            compareTimes = false;
                        }
                        if (compareTimes) {
                            return (d1 - d2) === 0;
                        } else {
                            d1 = stringToDate(d1);
                            d2 = stringToDate(d2);
                            var objectsAreEqual =  d1 && d2;
                            var valuesAreEqual = (d1.getYear() === d2.getYear()) && (d1.getMonth() === d2.getMonth()) && (d1.getDate() === d2.getDate());
                            return objectsAreEqual && valuesAreEqual;
                        }
                    };

                    datesAreEqualToMinute = function(d1, d2) {
                        if (!(d1 && d2)) {
                            return false;
                        }
                        return parseInt(d1.getTime() / 60000, 10) === parseInt(d2.getTime() / 60000, 10);
                    };

                    getDaysInMonth = function(year, month) {
                        return [31, ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
                    };

                    debounce = function(func, wait) {

                        var args, context, later, result, timeout, timestamp;
                        timeout = args = context = timestamp = result = null;
                        later = function() {
                            var last;
                            last = +new Date() - timestamp;
                            if (last < wait && last > 0) {
                                return timeout = setTimeout(later, wait - last);
                            } else {
                                return timeout = null;
                            }
                        };
                        return function() {
                            context = this;
                            args = arguments;
                            timestamp = +new Date();
                            if (!timeout) {
                                timeout = setTimeout(later, wait);
                                result = func.apply(context, args);
                                context = args = null;
                            }
                            return result;
                        };
                    };

                    ngModelCtrl.$render = function() {
                        if ( ngModelCtrl.$viewValue !== 'undefined') {
                            setCalendarDate(ngModelCtrl.$viewValue);
                        }
                        return refreshView();
                    };

                    ngModelCtrl.$viewChangeListeners.unshift(function() {
                        setCalendarDate(ngModelCtrl.$viewValue);
                        refreshView();
                        if (scope.onChange) {
                            return scope.onChange();
                        }
                    });



                    scope.toggleCalendar = debounce(function(show) {
                        if (isFinite(show)) {
                            return scope.calendarShown = show;
                        } else {
                            return scope.calendarShown = !scope.calendarShown;
                        }
                    }, 150);

                    scope.selectDate = function(date, closeCalendar) {
                        if (closeCalendar == null) {
                            closeCalendar = true;
                        }
                        if (typeof scope.dateFilter === 'function' && !scope.dateFilter(date)) {

                            return false;
                        }
                        ngModelCtrl.$setViewValue(date);
                        if (closeCalendar) {
                            scope.toggleCalendar(false);
                        }
                        scope.viewModel.invalid = false;
                        scope.viewModel.errorMessage="";

                        return true;
                    };

                    scope.selectDateFromInput = function(closeCalendar) {
                        var err, tmpDate, tmpDateAndTime, tmpTime;
                        if (closeCalendar == null) {
                            closeCalendar = false;
                        }
                        try {
                            tmpDate = parseDateString(scope.inputDate);
                            if (!tmpDate) {
                                throw 'Invalid Date';
                            }
                            if (!scope.disableTimepicker && scope.inputTime && scope.inputTime.length && tmpDate) {
                                tmpTime = scope.disableTimepicker ? '00:00:00' : scope.inputTime;
                                tmpDateAndTime = parseDateString("" + scope.inputDate + " " + tmpTime);
                                if (!tmpDateAndTime) {
                                    throw 'Invalid Time';
                                }
                                tmpDate = tmpDateAndTime;
                            }
                            if (!datesAreEqualToMinute(ngModelCtrl.$viewValue, tmpDate) && !scope.selectDate(tmpDate, false)) {
                                throw 'Invalid Date';
                            }
                            if (closeCalendar) {
                                scope.toggleCalendar(false);
                            }
                            scope.inputDateErr = false;
                            return scope.inputTimeErr = false;
                        } catch (_error) {
                            err = _error;
                            if (err === 'Invalid Date') {
                                return scope.inputDateErr = true;
                            } else if (err === 'Invalid Time') {
                                return scope.inputTimeErr = true;
                            }
                        }
                    };


                    scope.selectDateOnKeyPress = function(event,date){

                        if((event.which === 32) || (event.which === 13) ){
                            scope.selectDate(date, true, true);
                            event.stopPropagation();
                            event.preventDefault();
                            this.setFocusOnClose();
                            return true;
                        }else if(event.which === 27){
                            scope.toggleCalendar(false);

                        }
                    }

                    scope.closeCalendarOnEscape = function(event){
                        if(event.which === 27){
                            scope.toggleCalendar(false);
                            this.setFocusOnClose();
                        }
                    }

                    scope.clickOnCalendarIcon = function () {
                        var date;
                        date = ngModelCtrl.$modelValue ? parseDateString(ngModelCtrl.$modelValue) : null;
                        if (date != null) {
                            scope.calendarDate = new Date(date);
                        }else{
                            scope.disablePrevMonthSelection=false;
                            scope.disableNextMonthSelection=false;
                            scope.calendarDate = new Date();
                        }
                        scope.selectedYear = scope.calendarDate.getFullYear();
                        scope.selectedMonth = scope.monthsList[scope.calendarDate.getMonth()];
                        setupCalendarView();
                        scope.toggleCalendar();
                    };


                    scope.toggleCalendarOnKeypress = function(event){
                        if(event.which === 13){
                            scope.clickOnCalendarIcon();
                            this.setFocusOnClose(); 
                        }else if(event.which === 27){
                            scope.toggleCalendar(false);
                            this.setFocusOnClose();  
                        }
                    }

                    scope.setFocusOnClose = function() {
                        document.getElementById(scope.inputCompId+'_calIcon').focus();
                    }

                    scope.onDateInputTab = function() {
                        if (scope.disableTimepicker) {
                            scope.toggleCalendar(false);
                        }
                        return true;
                    };

                    scope.onTimeInputTab = function() {
                        scope.toggleCalendar(false);
                        return true;
                    };

                    scope.nextMonth = function() {
                        if(scope.disableNextMonthSelection){
                            return;
                        }
                        setCalendarDate(new Date(new Date(scope.calendarDate).setMonth(scope.calendarDate.getMonth() + 1)));
                        scope.selectedYear = scope.calendarDate.getFullYear();
                        scope.selectedMonth = scope.monthsList[scope.calendarDate.getMonth()];
                        return refreshView();
                    };

                    scope.prevMonth = function() {
                        if(scope.disablePrevMonthSelection){
                            return;
                        }
                        setCalendarDate(new Date(new Date(scope.calendarDate).setMonth(scope.calendarDate.getMonth() - 1)));
                        scope.selectedYear = scope.calendarDate.getFullYear();
                        scope.selectedMonth = scope.monthsList[scope.calendarDate.getMonth()];
                        return refreshView();
                    };

                    scope.changeCalendarView = function(){
                        setCalendarDate(new Date(new Date(scope.calendarDate).setFullYear(scope.selectedYear,scope.monthsList.indexOf(scope.selectedMonth))));
                        return refreshView();
                    };

                    scope.formatGivenDate = function(date){
                        var strDate = [];
                        var dateDelimiter = '';
                        if(!date){
                            return "";
                        }
                        if(date.indexOf('-') !== -1){
                            dateDelimiter = "-";
                        }else if(date.indexOf('.') !== -1){
                            dateDelimiter = ".";
                        }else if(date.indexOf('/') !== -1){
                            dateDelimiter = "/";
                        }
                        if(dateDelimiter !== ''){
                            strDate = date.toString().split(dateDelimiter);
                            if(strDate[0].length === 4){
                                strDate[3] = strDate[0];
                                strDate[0] = strDate[1];
                                strDate[1] = strDate[2];
                                strDate[2] = strDate[3];
                                strDate.pop();
                            }else if(strDate[0].length === 3){
                                strDate[0] = strDate[0].toLowerCase();
                                uitkCalendarDefaults.monthsList.forEach(function(v,i,a){
                                    if(v.toLowerCase() === strDate[0]){
                                        strDate[0]=i+1;
                                    }
                                });
                            }
                            strDate[0] = strDate[0].toString(); 
                            strDate[1] = strDate[1].toString();
                            strDate[0] = (strDate[0].length == 1)? "0"+strDate[0]:strDate[0];
                            strDate[1] = (strDate[1].length == 1)? "0"+strDate[1]:strDate[1];
                            return strDate[0]+"-"+strDate[1]+"-"+strDate[2];
                        }else if(date.match(/^\d{8}$/)){
                            strDate[0] = date.substr(0,2);
                            strDate[1] = date.substr(2,2);
                            strDate[2] = date.substr(4,4);
                            return strDate[0]+"-"+strDate[1]+"-"+strDate[2];
                        }else if(date.indexOf(' ') > 0 && date.indexOf(',')>0 && date.indexOf(' ') < date.indexOf(',') ){
                            strDate[0] = "";
                            strDate[1] = date.substr(0, date.indexOf(' '));
                            if( strDate[1].length === 3){
                                uitkCalendarDefaults.monthsList.forEach(function(v,i,a){
                                    if(v.toLowerCase() === strDate[1].toLowerCase()){
                                        strDate[0]=i+1;
                                    }
                                });
                            }else if(strDate[1].length > 3){
                                uitkCalendarDefaults.monthsListLong.forEach(function(v,i,a){
                                    if(v.toLowerCase() === strDate[1].toLowerCase()){
                                        strDate[0]=i+1;
                                    }
                                });
                            }
                            if(strDate[0] === ""){
                                return ""
                            }else{
                                var tempStrDate = (date.substr(date.indexOf(' '),date.length)).toString().split(',');
                                strDate[1] = tempStrDate[0].trim();
                                strDate[2] = tempStrDate[1].trim();
                                strDate[0] = strDate[0].toString(); 
                                strDate[1] = strDate[1].toString();
                                strDate[0] = (strDate[0].length == 1)? "0"+strDate[0]:strDate[0];
                                strDate[1] = (strDate[1].length == 1)? "0"+strDate[1]:strDate[1];
                                return strDate[0]+"-"+strDate[1]+"-"+strDate[2];
                            }

                        }
                        return "";
                    };
                    scope.isValidDate = function(date) {
                        var strDate = [];
                        strDate = date.toString().split('-');

                        var composedDate = new Date(strDate[2],strDate[0]-1,strDate[1],0,0,0,0);

                        scope.viewModel.invalid = false;

                        if ( typeof scope.minDate !== 'undefined' ) {
                            var minDateObj = parseDateString(scope.minDate);
                            if ( composedDate < minDateObj ) {
                                scope.viewModel.errorMessage = (scope.viewModel.outOfRangeMessage || uitkCalendarDefaults.validationErrorsMap.outOfRangeMessage) + scope.minDate + " and " + scope.maxDate + ".";
                                scope.viewModel.invalid = true;
                                return false;
                            }
                        }

                        if ( typeof scope.maxDate !== 'undefined' ) {
                            var maxDateObj = parseDateString(scope.maxDate);
                            if ( composedDate > maxDateObj ) {
                                scope.viewModel.errorMessage = (scope.viewModel.outOfRangeMessage || uitkCalendarDefaults.validationErrorsMap.outOfRangeMessage) + scope.minDate + " and " + scope.maxDate + ".";
                                scope.viewModel.invalid = true;
                                return false;
                            }
                        }



                        if(!(strDate[0] && strDate[0]<13 && strDate[0]>0)){
                            scope.viewModel.errorMessage = scope.viewModel.invalidDateMessage || uitkCalendarDefaults.validationErrorsMap.invalidDateMessage;
                            scope.viewModel.invalid = true;
                            return false;
                        }

                        if(strDate[2] && ( strDate[2] < uitkCalendarDefaults.minYear || strDate[2] > uitkCalendarDefaults.maxYear) ){
                            scope.viewModel.errorMessage = (scope.viewModel.outOfRangeMessage || uitkCalendarDefaults.validationErrorsMap.outOfRangeMessage)+" 01-01-"+uitkCalendarDefaults.minYear+" and 12-31-"+uitkCalendarDefaults.maxYear+".";
                            scope.viewModel.invalid = true;
                            return false;
                        }


                        if(parseInt(strDate[1], 10) === 0 || strDate[1] > getDaysInMonth(strDate[2], strDate[0]-1)){
                            scope.viewModel.errorMessage = scope.viewModel.invalidDateMessage ||  uitkCalendarDefaults.validationErrorsMap.invalidDateMessage;
                            scope.viewModel.invalid = true;
                            return false;
                        }


                        if ( Object.prototype.toString.call(composedDate) === "[object Date]" ) {
                            if ( isNaN( composedDate.getTime() ) ) {
                                return false;
                            }
                            else {
                                return true;
                            }
                        }
                        else {
                            return false;
                        }
                        scope.getAriaDescribedBy();
                    };

                    scope.onKeyDown = function() {
                        var date_reg_ex = /^\d{1,2}\-\d{1,2}\-\d{4}$/;
                        var tmpDateAndTime = scope.formatGivenDate(scope.viewModel.dateText);
                        if(tmpDateAndTime.match(date_reg_ex)) {
                            if (scope.isValidDate(tmpDateAndTime) ) {
                                scope.selectDate(tmpDateAndTime, true, true);
                                scope.selectedYear = scope.calendarDate.getFullYear();
                                scope.selectedMonth = scope.monthsList[scope.calendarDate.getMonth()];
                                scope.changeCalendarView();
                            }
                        }
                        else if(scope.viewModel.dateText){
                            scope.viewModel.errorMessage =  scope.viewModel.invalidFormatMessage || uitkCalendarDefaults.validationErrorsMap.invalidFormatMessage;
                            scope.viewModel.invalid = true;
                        }else if(scope.viewModel.required){
                            ngModelCtrl.$setViewValue(null);
                            scope.viewModel.invalid = true;
                            scope.viewModel.errorMessage =  scope.viewModel.requiredMessage || uitkCalendarDefaults.validationErrorsMap.requiredMessage;
                        }else{
                            ngModelCtrl.$setViewValue(null);
                            scope.viewModel.invalid = false;
                        }
                        scope.getAriaDescribedBy();
                    }


                    scope.clear = function() {
                        return scope.selectDate(null, true);
                    };
                    return initialize();
                }
            };
        }
    ]);

}).call(this);

angular.module("uitk.component.uitkCalendar").run(["$templateCache", function($templateCache) {$templateCache.put("template/uitk-calendar.html","<div class=\'tk-cal\' ng-class=\"{\'tk-rfrm-has-error\': viewModel.invalid && viewModel.enableValidation}\">\n    <div ng-class=\"{\'tk-rfrm-error-container\': viewModel.errorMessage || viewModel.invalid}\">\n\n        <input type=\'text\' id=\'{{inputCompId}}_cal\' ng-attr-aria-describedby=\'{{getAriaDescribedBy()}}\' name=\'{{inputCompId}}_cal\' aria-labelledby=\'{{labelledBy}}\' aria-required=\'{{viewModel.required}}\' aria-invalid=\'{{viewModel.invalid}}\'  ng-model=\'viewModel.dateText\' maxlength=\'25\' ng-blur=\'onKeyDown($event)\' class=\'uitk-text-field customFieldSize\' ng-class=\"{\'tk-form-field-error\': viewModel.invalid && viewModel.enableValidation, \'{{viewModel.textFieldClassName}}\': viewModel.textFieldClassName}\"/>\n\n        <a href=\'\' id=\'{{inputCompId}}_calIcon\' ng-class=\"{\'cux-icon-calendar tk-cal-icon\' : viewModel.iconCalendar}\" aria-label=\'view calendar\' ng-click=\'clickOnCalendarIcon()\' tabindex=\'0\' ng-keyup=\'toggleCalendarOnKeypress($event)\' aria-expanded=\'{{calendarShown && viewModel.iconCalendar}}\' aria-hidden=\'{{!viewModel.iconCalendar}}\'></a>\n\n    </div>\n\n    <div class=\'tk-cal-popup\' aria-hidden=\'{{!calendarShown && viewModel.iconCalendar}}\' ng-class=\'{open: calendarShown && viewModel.iconCalendar}\'>\n        <div class=\'tk-cal-heading\'>\n            <a href=\'\' aria-disabled=\"{{!!disablePrevMonthSelection}}\" class=\'tk-cal-prev-month\' ng-click=\'prevMonth()\' tabindex=\'0\' ng-keyup=\'closeCalendarOnEscape($event)\'>\n                <span class=\'cux-icon-carrot_left\' aria-disabled=\"{{!!disablePrevMonthSelection}}\">\n                    <span class=\'oui-a11y-hidden\'>\n                        {{\'Previous Month\' | uitkTranslate}}\n                    </span>\n                </span>\n            </a>\n\n\n            <select ng-model=\'selectedMonth\' aria-label=\'select month\' aria-controls=\'{{inputCompId}}_desc\' ng-change=\'changeCalendarView()\' tabindex=\'0\' ng-keyup=\'closeCalendarOnEscape($event)\'>\n                <option ng-repeat=\'month in monthsList\' >{{month}}</option>\n            </select>\n            <select ng-model=\'selectedYear\' aria-label=\'select year\' aria-controls=\'{{inputCompId}}_desc\' ng-change=\'changeCalendarView()\' tabindex=\'0\' ng-keyup=\'closeCalendarOnEscape($event)\' ng-options=\'year as year for year in years\'>\n            </select>\n\n            <a href=\'\'aria-disabled=\"{{!!disableNextMonthSelection}}\" class=\'tk-cal-next-month\' ng-click=\'nextMonth()\'  tabindex=\'0\' ng-keyup=\'closeCalendarOnEscape($event)\'>\n                <span class=\'cux-icon-carrot_right\' aria-disabled=\"{{!!disableNextMonthSelection}}\">\n                    <span class=\'oui-a11y-hidden\'>\n                        {{\'Next Month\'| uitkTranslate}}\n                    </span>\n                </span>\n            </a>\n\n        </div>\n\n        <thead>\n            <tr scope=\'col\' role=\'row\'>\n                <th ng-repeat=\'day in dayAbbreviations\' role=\'columnheader\'>\n                    <span class=\'dayAbbr\' data-day-abbr=\'{{day[0]}}\'></span>\n                    <span class=\'oui-a11y-hidden\'>\n                        {{day[1]}}\n                    </span>\n                </th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr ng-repeat=\'week in weeks\' role=\'row\'>\n                <td ng-mousedown=\'selectDate(day.date, true, true)\' ng-keyup=\'selectDateOnKeyPress($event,day.date)\' ng-class=\'{\"other-month\": day.other, \"disabled-date\": day.disabled, \"selected\": day.selected, \"is-today\": day.today}\' ng-repeat=\'day in week\' tabindex=\'0\' role=\'gridcell\'>\n                    {{day.date | date:\'d\'}}\n                </td>\n            </tr>\n            <div id=\'{{inputCompId}}_desc\' class=\'oui-a11y-hidden\' role=\'region\' aria-atomic=\'true\' aria-live=\'assertive\' aria-relevant=\'all\'>\n                Showing the calendar for {{selectedMonth}} {{selectedYear}}\n            </div>\n            <table class=\'tk-cal-grid\' role=\'grid\' aria-readonly=\'true\' aria-describedby=\'{{inputCompId}}_desc\'>\n                <thead>\n                    <tr scope=\'col\' role=\'row\'>\n                        <th ng-repeat=\'day in dayAbbreviations\' role=\'columnheader\'>\n                            <span class=\'dayAbbr\' data-day-abbr=\'{{day[0]}}\'></span>\n                            <span class=\'oui-a11y-hidden\'> {{day[1]}}</span>\n                        </th>\n                    </tr>\n                </thead>\n                <tbody>\n                    <tr ng-repeat=\'week in weeks\' role=\'row\'>\n                        <td ng-mousedown=\'selectDate(day.date, true, true)\' ng-keyup=\'selectDateOnKeyPress($event,day.date)\' ng-class=\'{\"other-month\": day.other, \"disabled-date\": day.disabled, \"selected\": day.selected, \"is-today\": day.today}\' ng-repeat=\'day in week\' tabindex=\'0\' role=\'gridcell\'>\n                            {{day.date | date:\'d\'}}\n                        </td>\n                    </tr>\n                </tbody>\n            </table>\n        </tbody>\n    </div>\n    <div id=\'{{displayTipId}}_tip\' class=\'tk-cal-assistivetext\' ng-bind-html=\"displayTipText\">\n\n    </div>\n</div>");}]);
angular.module('uitk.component.uitkCheckboxGroup',[])
.directive('uitkCheckbox', function(){
	return {
		restrict : 'E',
		replace : true,
		transclude : true,
		scope : {
			itemList :'=',
			id : '@',
			groupName : '@',
			onChange : '&',
			isGroup: '@',
            tkDescribedby :'@',
            tkLabelledby : '@'
		},
		templateUrl: function (element, attrs) {
			return attrs.templateUrl || 'template/uitkCheckboxTemplate.html';
		}
	};
});

angular.module("uitk.component.uitkCheckboxGroup").run(["$templateCache", function($templateCache) {$templateCache.put("template/uitkCheckboxTemplate.html","<div>\n\n    <div ng-if=\'isGroup===\"false\"\' class=\'tk-form-checkboxes-radios\'>\n        <input type=\'checkbox\' id=\'{{id + \"_input\"}}\' name=\'{{id}}\' ng-model=\'itemList.value\'\n               ng-disabled=\'itemList.disabled\' ng-checked=\'itemList.checked\'\n               aria-describedby=\'{{tkDescribedby}}\'\n               ng-click=\'itemList.checked=!itemList.checked; onChange();\'/>\n        <label for=\'{{id + \"_input\"}}\' tabindex=\'-1\'>{{itemList.label}}</label>\n    </div>\n\n    <div ng-if=\'isGroup===undefined || isGroup===\"true\"\' role=\'group\' ng-attr-aria-describedby=\'{{tkDescribedby}}\' ng-attr-aria-labelledby=\'{{tkLabelledby}}\'>\n        <ul class=\'tk-form-checkboxes-radios\'>\n            <li ng-repeat=\'item in itemList\' >\n                <input type=\'checkbox\' id=\'{{groupName + $index }}\' name=\'{{groupName}}\' ng-model=\'item.value\'\n                       ng-disabled=\'item.disabled\' ng-checked=\'item.checked\'\n                       ng-click=\'item.checked=!item.checked; onChange();\'/>\n                <label for=\'{{groupName + $index }}\' tabindex=\'-1\'>{{item.label}}</label>\n            </li>\n        </ul>\n    </div>\n\n</div>");}]);
(function () {
    var TABS_SWITCH_TIMEOUT = 100;
    var uitkTabs =  function () {
        return {
            restrict: 'E',
            replace: true,
            transclude: true,
            scope:{
                tkModel:'='
            },
            link: function($scope, element, attrs, ctrl){

                if(!$scope.tkModel.id) {
                    $scope.tkModel.id='tabs_'+ctrl.randomId(6);
                }

                $scope.isSelected = function(index){
                    if($scope.tkModel.selectedIndex === index){
                        return true;
                    }
                    return false;
                }
            },
            controller: ["$scope", "$timeout", function($scope, $timeout) {

                $scope.selectTab = function (tab, index) {
                    if(!tab.disabled) {
                        angular.element('#' + $scope.tkModel.id + '_tab' + $scope.tkModel.selectedIndex + '_tab').attr('aria-selected',false);

                        if($scope.tkModel.selectedIndex !== index) {
                            var prevActiveElem = angular.element('div.tk-tpnl ul li')[$scope.tkModel.selectedIndex];
                            angular.element(prevActiveElem).removeClass('tk-tpnl-selected');
                        }

                        angular.element('#' + $scope.tkModel.id + '_tab' + index + '_tab').attr('aria-selected',true);

                        $scope.tkModel.selectedIndex = index;

                        if(tab.focusElement) {
                            $timeout(function(){
                                angular.element(tab.focusElement).focus();
                            }, TABS_SWITCH_TIMEOUT);
                        } else {
                            $timeout(function(){
                                var tabContentPanel = angular.element('#'+$scope.tkModel.id+'_tab'+index+'_tabpanel');
                                tabContentPanel.focus();
                            }, TABS_SWITCH_TIMEOUT);
                        }


                    }
                };

                $scope.tkModel.selectedIndex = ($scope.tkModel.selectedIndex % $scope.tkModel.tabs.length) || 0;
                var index = $scope.tkModel.selectedIndex;
                var tab = $scope.tkModel.tabs[index];
                for(var i=index; tab.disabled && i<$scope.tkModel.tabs.length; i++) {
                    index = i;
                    tab = $scope.tkModel.tabs[i];
                }
                if(!tab.disabled) {
                    $scope.tkModel.selectedIndex = index;
                    $scope.templateUrl = tab.templateurl;
                    $scope.selectTab($scope.tkModel.tabs[$scope.tkModel.selectedIndex], $scope.tkModel.selectedIndex);
                }

                this.randomId = function (length) {
                    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');
                    if (! length) {
                        length = Math.floor(Math.random() * chars.length);
                    }
                    var str = '';
                    for (var i = 0; i < length; i++) {
                        str += chars[Math.floor(Math.random() * chars.length)];
                    }
                    return str;
                };

                $scope.tabKeyupHandler = function(pane, index, event){
                    var pressedKey = event.keyCode;

                    switch(pressedKey) {
                        case 39:
                        case 40:
                            var nextTab;
                            var count = 0;
                            if($scope.tkModel.selectedIndex !== index) {
                                var prevActiveElem = angular.element('div.tk-tpnl ul li')[index];
                                angular.element(prevActiveElem).removeClass('tk-tpnl-selected');
                            }
                            do { 
                                index = (index + 1) % $scope.tkModel.tabs.length;
                                nextTab = $scope.tkModel.tabs[index];
                                count++;
                            } while(nextTab.disabled && count <= $scope.tkModel.tabs.length);
                            angular.element('#' + $scope.tkModel.id + '_tab' + index + '_tab').focus();
                            var activeElem = angular.element('div.tk-tpnl ul li')[index];
                            angular.element(activeElem).addClass('tk-tpnl-selected');
                            break;
                        case 37:
                        case 38:
                            var previousTab;
                            var count = 0;
                            if($scope.tkModel.selectedIndex !== index) {
                                var prevActiveElem = angular.element('div.tk-tpnl ul li')[index];
                                angular.element(prevActiveElem).removeClass('tk-tpnl-selected');
                            }
                            do { 
                                index = (index - 1 >= 0) ? index - 1 : $scope.tkModel.tabs.length-1;
                                previousTab = $scope.tkModel.tabs[index];
                                count++;
                            } while(previousTab.disabled && count <= $scope.tkModel.tabs.length);
                            angular.element('#' + $scope.tkModel.id + '_tab' + index + '_tab').focus();
                            var activeElem = angular.element('div.tk-tpnl ul li')[index];
                            angular.element(activeElem).addClass('tk-tpnl-selected');
                            break;
                    };
                };

                $scope.contentKeyupHandler = function(index, event) {
                    if (event.ctrlKey && event.keyCode === 38) { 
                        $timeout(function(){
                            angular.element('#' + $scope.tkModel.id + '_tab' + index + '_tab').focus();
                        });
                    }
                };

                $scope.$watch('tkModel.selectedIndex',function(){
                    $scope.templateUrl = $scope.tkModel.tabs[$scope.tkModel.selectedIndex].templateurl;
                });

            }],
            template:[
                '<div id="{{tkModel.id}}" class="tk-tpnl" aria-describedby="{{tkModel.id}}_desc">',
                '<div class="oui-a11y-hidden" id="{{tkModel.id}}_desc" aria-hidden="false" tabindex="-1">Use arrow keys to move between tabs, enter or spacebar to activate</div>',
                '<ul role="tablist" aria-label="{{tkModel.ariaLabel}}">',
                '<li role="presentation" ng-class="{\'tk-tpnl-selected\':isSelected($index), \'tk-tpnl-disabled\':pane.disabled}" ng-repeat="pane in tkModel.tabs" >',
                '<span id="{{tkModel.id+\'_tab\'+$index+\'_tab\'}}" role="tab" ng-click="selectTab(pane,$index)" aria-selected="false"',
                'aria-expanded="{{tkModel.selectedIndex === $index}}" ng-keyup="tabKeyupHandler(pane, $index, $event);" aria-disabled="{{pane.disabled}}" uitk-navigable="!pane.disabled" tabindex="{{(tkModel.selectedIndex === $index)?0:-1}}" aria-controls="{{tkModel.id+\'_tab\'+$index+\'_tabpanel\'}}">{{ pane.title }}</span>',
                '</li>',
                '</ul>',
                '<div class="tk-tpnl-content" role="presentation">',
                    '<div id="{{tkModel.id+\'_tab\'+$index+\'_tabpanel\'}}" ng-keyup="contentKeyupHandler($index, $event);" ng-keydown="contentKeydownHandler( $event);" aria-labelledby="{{tkModel.id+\'_tab\'+$index+\'_tab\'}}" tabindex="{{isSelected($index)?0:-1}}" role="tabpanel"  ng-include="templateUrl">',
                '</div>',
                '</div>',
                '</div>'
            ].join('')
        };
    };

    angular.module('uitk.component.tabs',['uitk.component.uitkNavigable'])
        .directive('uitkTabs', uitkTabs);
})();

var radioGroupApp = angular.module('uitk.component.uitkRadioGroup', []);
radioGroupApp
    .directive('uitkRadio', ["$compile", function ($compile) {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                itemList: '=',
                groupName: '@',
                modelValue: '=',
                tkDescribedby: '=',
                tkLabelledby: '@',
                onChange: '&'
            },
            transclude: true,
            template: "<div><div role='group' aria-describedby='{{tkDescribedby}}' aria-labelledby='{{tkLabelledby}}'>" +
                        "<ul class='tk-form-radio'>" +
                        "<li ng-repeat='item in itemList' class='template-list-item'>" +
                        "<input type='radio' id='{{groupName + $index }}' ng-change='onChange();'  name='{{groupName}}' ng-model='$parent.modelValue'" +
                        "ng-disabled='item.disabled'   ng-attr-aria-disabled='{{item.disabled?true:undefined}}' ng-value='{{$index}}'/> " +
                        "<label for='{{groupName + $index }}' tabindex='-1'>{{item.label}}</label>" +
                        "</li>" +
                       "</ul></div></div>",
            link: function (scope, element, attrs, ctrl, transclude) {
                if (scope.itemList == undefined) {
                    var radioContents = transclude().filter(function (index, el) { return el.localName == "uitk:radio-content"; });
                    for (var i = 0; i < radioContents.length; i++) {
                        var tempTemplate = angular.element("<li class='template-list-item'>" +
                                        "<input class='compiled-list-item' type='radio' id='{{groupName}}" + i + "' ng-change='onChange();'  name='{{groupName}}' ng-model='modelValue'" +
                                        "ng-disabled='" + ($(radioContents[i]).attr('uitk-disabled') == "true" ? true : false) + "' ng-attr-aria-disabled='" + ($(radioContents[i]).attr('disabled') == true ? true : false) + "' ng-value='{{" + i + "}}'/> " +
                                        "<label for='{{groupName}}" + i + "'>" + $(radioContents[i]).attr('tk-label') + "</label>" +
                                        "</li>");
                        tempTemplate.find('label').parent().append(radioContents[i]);
                        element.find('ul').append($compile(tempTemplate)(scope));
                    }
                }
            }
        };
    }])
    .directive('uitkRadioContent', function () {
        return {
            restrict: 'AE'
        };
    });

var textAreaApp = angular.module('uitk.component.uitkTextarea',['uitk.maxlength','uitk.uitkUtility']);
textAreaApp.directive('uitkTextarea', ["$timeout", "$compile", "uitkLiveRegionService", function($timeout, $compile, uitkLiveRegionService){
	return {
		restrict : 'E',
		replace : true,
		transclude: true,
		scope : {
			id: '@',
			model: '=',
			checkFieldValidation: '=', 
			maxCharCount: '@', 
			name: '@',
			rows: '@',
			width: '@',
			height: '@',
			extraClasses: '@',
			tkErrorClass: '=',
			tkRequired:'@',
			tkAriaDescribedby: '@',
	        onBlur: '&',  
	        onFocus: '&', 
	        onKeyup: '&'
		},
		link : function($scope, $element, $attr) {
			$scope.extraClasses = $attr['styleClass'];
			$scope.busyFlag = 'false';
			var timeupPromise = null;
			$scope.initialValue = $scope.model;

			if($scope.checkFieldValidation === undefined) {
				$scope.checkFieldValidation = false;
			}

			$scope.$watch('model',function(newVal,oldVal){
				if($scope.model === undefined) {
					$scope.model = "";
				}
				if((oldVal === undefined && newVal === "") || (newVal === undefined && oldVal === "")){
					return;
				}
				if(newVal !== $scope.initialValue) {
					$scope.checkFieldValidation = true;
				}
                $scope.ariaLiveFlag = 'off';
				$timeout.cancel(timeupPromise);
				timeupPromise = $timeout(function(){
                    $('#'+$scope.id+'_sub_character_remaining').remove();

                    if ( $scope.model.length === 0 ) {
                        $scope.ariaLiveFlag = 'off';
                    }
                    else {
                        uitkLiveRegionService.alertMessage(($scope.maxCharCount - $scope.model.length) + " characters remaining"); 
                    }

                    $timeout(function(){
                        $('#'+$scope.id+'_character_remaining').append($compile('<div id="'+$scope.id+'_sub_character_remaining">'+($scope.maxCharCount - $scope.model.length) + " <span translate>characters</span><span class='oui-a11y-hidden'> remaining</span></div>")($scope));
                    },10);
				},500);
			});

			$scope.onKeyupEvent = function(){
			    var elName = '#' + $scope.id + '_textarea';
				var el = angular.element(elName);
				var ctrl = el.controller('ngModel');
				if(ctrl && el.val()!==ctrl.$modelValue) {
					ctrl.$setViewValue(el.val());
					ctrl.$render();
				}

				if($scope.maxCharCount - $scope.model.length === 0){
                    $scope.ariaLiveFlag = 'off';
                    $timeout(function () {
                        $scope.ariaLiveFlag = 'polite';
					},500);
				}
			}

			$scope.blurEvent = function(event) {
				$scope.checkFieldValidation = true;
				$timeout(function(){
					$scope.onBlur(event);
				}, 500);
			}


			$scope.$watch('tkAriaDescribedby',function(newVal, oldVal) {
				$scope.describedByText = '';
				if(newVal !== undefined && newVal !== ''){
					$scope.describedByText += newVal + " ";
				}
				$scope.describedByText += $scope.id + "_character_remaining";
			});

		},
		template: '<div>'+
				  	'<textarea id="{{id}}_textarea" style="width:{{width}};height:{{height}};"  ng-keyup="onKeyup();onKeyupEvent()" ng-blur="blurEvent($event);" name="{{name}}" ng-class="{\'tk-form-field-error\':tkErrorClass} {{extraClasses}}" ng-focus="onFocus()" uitk-maxlength={{maxCharCount}} ng-model="model" rows="{{rows}}" class="tk-form-textarea" ng-trim="false" aria-describedby="{{describedByText}}" aria-required="{{tkRequired ? true : false}}" ng-required="(tkRequired && checkFieldValidation) ? true : false" ng-attr-aria-invalid="{{tkErrorClass == \'\' ? undefined : tkErrorClass}}"></textarea>' +
				  	'<div class="tk-textarea-tip" ng-if="maxCharCount" tabindex="-1">' +
				  		'<div id="{{id}}_character_remaining" aria-live="{{ariaLiveFlag}}" aria-atomic="true" aria-relevant="additions" tabindex="-1"><div id="{{id}}_sub_character_remaining">{{maxCharCount - model.length}} {{"characters" | uitkTranslate}}<span class="oui-a11y-hidden"> remaining</span></div></div>' +
				  	'</div>' +
				  '</div>'
	};
}]);

angular.module('uitk.component.uitkTextField',['uitk.uitkUtility', 'uitk.maxlength'])
.directive('uitkInput', ['$filter','$interpolate','$timeout', '$sce', function($filter, $interpolate,$timeout, $sce) {
	return {
		restrict: 'E',
		replace: true,
		scope: {
			id : '@',
			name : '@',
			model: '=',
			tkLayout: '@',
			checkFieldValidation: '=', 
			checkRequireValidation:'=', 
			formatErrorFlag: '=',
            tkRequired:'=',
            tkMinlength:'@',
            tkMaxlength:'@',
            maxCharacterAllowed:'@',
            maxCharacterAllowedMessage: '@',
            tkPattern:'@',
			styleClass: '@',
			tkErrorClass: '=',
			tkAriaDescribedby: '@',
			tkAriaLabelledby: '@',
			tkType : '@',
            emailPattern : '@',
            validateEmail : '@',
            emailErrorMessage : '@',
            tkDisabled : '=',
            tkReadonly : '@',
            tkPlaceholder : '@',
			onBlur: '&',  
	        onFocus: '&', 
	        onKeyup: '&',
	        onKeypress: '&',
	        onKeydown: '&',
	        onChange: '&',
	        tkStaticAriaDescribedby: '@',
            tkSupressDescribedby: '=',
	        tkSupressMessage: '=',
            tkSupressMaxCharacterDescribedby:'='

		},
		controller: ["$scope", function($scope) {
            if($scope.maxCharacterAllowed) {
                $scope.maxCharCount = $scope.maxCharacterAllowed;
            }

			if($scope.tkType === 'phone') {
				$scope.maxCharCount = 18;
			} else if($scope.tkType === 'zip') {
				$scope.maxCharCount = 12;
			} else if($scope.tkType === 'ssn') {
				$scope.maxCharCount = 13;
			}
		}],

		link: function (scope, element, attributes) {
			switch(scope.tkType) {
				case 'phone':
					scope.typeOfInput = "tel";
					break;
				case 'zip':
					scope.typeOfInput = "text";
					break;
				case 'ssn':
					scope.typeOfInput = "text";
					break;
				case 'password':
					scope.typeOfInput = "password";
					break;
                case 'email':
                    if(bowser && bowser.name == "Internet Explorer" && bowser.version == "9.0"){
                        scope.typeOfInput = "text";
                    }
                    else{
                        scope.typeOfInput = "email";
                    }
                    break;
				default:
					scope.typeOfInput = "text";
					break;
			}

			if(scope.checkFieldValidation === undefined) {
				scope.checkFieldValidation = false;
			}
			if(scope.checkRequireValidation === undefined){
                scope.checkRequireValidation = true;
            }

			scope.extraClasses = attributes['styleClass'];
			scope.locale = "";
			scope.inputType=attributes['tkType'];

			scope.model = scope.model || '';

			scope.initialValue = scope.model;

			if(attributes['value']) {
				scope.model = attributes['value'];
			}

            if(scope.maxCharacterAllowed && !scope.maxCharacterAllowedMessage){
                scope.maxCharacterAllowedMessage = "Accepts no more than "+scope.maxCharacterAllowed+" characters";
            }

			scope.$on("changeLocale", function () {
				scope.inputType = attributes['tkType'];
				if(scope.inputType === 'phone') {
					var value = String(scope.model);
					var number = value.replace(/[^0-9-]+/g, '');
					scope.model = formatPhoneNumber(number);
				}
			});

			scope.$watch("model", function(newValue){
				if(newValue !== scope.initialValue) {
					scope.checkFieldValidation = true;
				}
			});
			scope.blurEvent = function(event, value) {
				scope.checkFieldValidation = true;
				$timeout(function(){
					scope.onBlur(event);

                    scope.showInternalMessageOne = false;
                    scope.showInternalMessageTwo = false;
                    if (scope.tkLayout && scope.formatErrorFlag && (scope.format !== 'email' || (scope.format === 'email' && scope.emailErrorMessage === undefined))) {

                        if (!scope.tkSupressMessage) {
                            scope.showInternalMessageOne = true;
                        }
                    }
                    if (scope.formatErrorFlag && (scope.format !== 'email' || (scope.format === 'email' && scope.emailErrorMessage === undefined))) {
                        if (!scope.tkSupressMessage) {
                            scope.showInternalMessageTwo = true;
                        }
                    }
				});

				if (scope.inputType === 'phone' && this.tkPattern) {
				    if(event.target.value.length >=10) value = event.target.value;
				}
				if(value === '' || value === undefined){
					scope.formatErrorFlag = false;
					return true;
				}
				scope.formatErrorFlag = false;

				var filterType = '';
				switch(scope.inputType) {
				    case 'phone':
				    	filterType = 'phonenumber';
				        break;
				    case 'zip':
				        filterType = 'zipcode';
				        break;
				    case 'ssn':
				        filterType = 'ssnnumber';
				        break;
                    case 'password':
                        filterType = 'password';
                        break;
                    case 'email':
                        filterType = 'email';
                        break;
                    default:
                        filterType = '';
                        break;
				}

				if(filterType === 'phonenumber'){
					scope.model = formatPhoneNumber(value);
				}
				else if(filterType === 'zipcode'){
					scope.model = formatZip(value);
				}
				else if(filterType === 'ssnnumber'){
					scope.model = formatSSN(value);
				}
                else if(filterType === 'email'){
                    validateEmail(scope.model);
                }
			};

            function validateEmail(email) {
                if(scope.validateEmail || _.isUndefined(scope.validateEmail)){
                    var emailRegEx = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
                    if(scope.emailPattern){
                        emailRegEx = new RegExp(scope.emailPattern);
                    }
                    if(!emailRegEx.test(email)){
                        scope.format = 'email';
                        scope.formatErrorFlag = true;
                    }
                }
            }

			function formatPhoneNumber(number){
				var pattern;

		    	if($interpolate("{{'phone_number_pattern' | uitkTranslate}}")() === "phone_number_pattern"){

		    	   		pattern = "555-555-5555";

		    	}else{
		    		    pattern = $interpolate("{{'phone_number_pattern' | uitkTranslate}}")();
		    	}

                if ( number.length > 0 ) {
                    if( !validateInputPhoneNumber(number) || number.replace(/[^0-9]/g,"").length < 10 ) {
                        scope.format = pattern;
                        scope.formatErrorFlag = true;
                        return number;
                    }
                }

		    	var tempNumber = number.replace(/[^0-9]/g, '').replace(' ','');
		        if (!tempNumber)
		        	{ return ''; }
		        var formattedNumber = String(tempNumber);
		        var pattern_array = pattern.split("-");

		        var l1 = pattern_array[0].length;
		        var l2 = pattern_array[1].length + pattern_array[0].length;
		        var l3 = pattern_array[2].length + pattern_array[1].length + pattern_array[0].length;

				var area = tempNumber.substring(0,l1);
				var front = tempNumber.substring(l1, l2);
				var end = tempNumber.substring(l2, l3);

				if (front) {
					formattedNumber = (area + "-" + front);
				}
				if (end) {
					formattedNumber += ("-" + end);
				}

				if(formattedNumber.length === l1 && number.length === l1+1 && number.charAt(l1) === '-') {
					formattedNumber += "-";
				}
				if(formattedNumber.length === l2+1 && number.length === l2+2 && number.charAt(l2+1) === '-') {
					formattedNumber += "-";
				}
				console.log(formattedNumber);
				return formattedNumber;
			}

			var validateInputPhoneNumber = function(number) {
				var regexString = new RegExp('^[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$');
				return regexString.test(number);
			};

			function formatZip(number){
		    	if(!validateInputNumber(number) || number.replace(/[^0-9]/g,"").length !== 9){
		    		scope.format = '55555-5555';
		    		scope.formatErrorFlag = true;
		    		return number;
		    	}

				var tempNumber = number.replace(/-/g, '').replace(' ','');
		        if (!tempNumber) { return ''; }

		        var formattedNumber = String(tempNumber);

				var front = tempNumber.substring(0, 5);
				var end = tempNumber.substring(5, 9);

				if (end) {
					formattedNumber = (front + "-" + end);
				}

				if(formattedNumber.length === 5 && number.length === 6 && number.charAt(5) === '-') {
					formattedNumber += "-";
				}
				return formattedNumber;
			}

			function formatSSN(number){

		    	if(!validateInputNumber(number) || number.replace(/[^0-9]/g,"").length !== 9){
		    		scope.format = '555-55-5555';
		    		scope.formatErrorFlag = true;
		    		return number;
		    	}

				var tempNumber = number.replace(/-/g, '').replace(' ','');
		        if (!tempNumber) { return ''; }

		        var formattedNumber = String(tempNumber);

				var front = tempNumber.substring(0,3);
				var mid = tempNumber.substring(3, 5);
				var end = tempNumber.substring(5, 9);

				if (mid) {
					formattedNumber = (front + "-" + mid);
				}
				if (end) {
					formattedNumber += ("-" + end);
				}

				if(formattedNumber.length === 3 && number.length === 4 && number.charAt(3) === '-') {
					formattedNumber += "-";
				}
				if(formattedNumber.length === 6 && number.length === 7 && number.charAt(6) === '-') {
					formattedNumber += "-";
				}

				return formattedNumber;
			}

			function validateInputNumber(number){
				var regex = new RegExp('^[0-9 -]*$');
				return regex.test(number);
			}

			scope.keypressEvent = function(event){
				$timeout(function(){
					scope.onKeypress(event);
				});
			};

            scope.pasteEvent = function(event) {
                var pasteText = (event.originalEvent || event).clipboardData.getData('text/plain');
                if(scope.maxCharacterAllowed && (scope.model || '').length + pasteText.length > scope.maxCharacterAllowed){
                    scope.model = ((scope.model || '') + pasteText).substring(0, scope.maxCharacterAllowed);
                    event.preventDefault();
                }
            }

			scope.keyupEvent = function(event){
                var elName = '#' + scope.id + '_input';
                var el = angular.element(elName);
                var ctrl = el.controller('ngModel');
                if(ctrl && el.val()!==ctrl.$modelValue) {
                    ctrl.$setViewValue(el.val());
                    ctrl.$render();
                }

				$timeout(function(){
					scope.onKeyup(event);
				});
			};

			scope.keydownEvent = function(event){
				$timeout(function(){
					scope.onKeydown({"event":event});
				});
			};

			scope.onchangeEvent = function(){
				$timeout(function(){
					scope.onChange();
				});
			};

			scope.focusEvent = function(event){
				$timeout(function(){
					scope.onFocus(event);
				});
			};

			scope.getAriaDescribedBy = function () {
                scope.ariaDescribedByIds = '';

				if(scope.formatErrorFlag){ 
                    scope.ariaDescribedByIds = scope.id + "_format_err";
				}
				if (scope.tkAriaDescribedby) { 
                    scope.ariaDescribedByIds += " "+ scope.tkAriaDescribedby;
				}
                if (scope.tkStaticAriaDescribedby) { 
                    scope.ariaDescribedByIds += " " + scope.tkStaticAriaDescribedby;
                }
                if(scope.maxCharacterAllowed && !scope.tkSupressMaxCharacterDescribedby) {
                    scope.ariaDescribedByIds += " maxCharacterAllowedMessage";
                }

			    return scope.ariaDescribedByIds ? scope.ariaDescribedByIds.trim() : undefined;
			};
		},

		template: [
			        '<div>',
						'<input id="{{id}}_input" ng-attr-aria-describedby="{{tkSupressDescribedby === \'true\' ? undefined : getAriaDescribedBy()}}" type="{{typeOfInput}}" ng-attr-name="{{name}}" class="tk-input-masking {{styleClass}}" ng-class="{\'oui-form-field-error\':tkErrorClass} " ng-blur="blurEvent($event, model);" ng-focus="focusEvent($event);" ng-keyup="keyupEvent($event);" ng-keypress="keypressEvent($event);" ng-paste="pasteEvent($event);" ng-keydown="keydownEvent($event);" ng-change="onchangeEvent();" ng-model="model" autocomplete="off" aria-autocomplete="none" aria-required="{{tkRequired ? true : false}}"',
			        		' ng-attr-aria-invalid="{{tkErrorClass}}" ng-attr-aria-labelledby="{{tkAriaLabelledby === \'\' ? undefined : tkAriaLabelledby}}" ng-attr-placeholder="{{tkPlaceholder === \'\' ? undefined : tkPlaceholder}}"',
			        		' ng-minlength={{tkMinlength}} ng-maxlength={{tkMaxlength}} uitk-maxlength={{maxCharCount}} ng-pattern="{{tkPattern}}" ng-disabled="tkDisabled" ng-readonly="tkReadonly" ng-required="(tkRequired && checkRequireValidation && checkFieldValidation) ? true : false"',
			        	' />',
						'<div ng-if="!tkLayout">' +
							'<span id="{{id}}_format_err" ng-class="{\'uitk-msg-error-inline-horizontal\': tkLayout === \'horizontal\'}" ng-show="showInternalMessageTwo" tabindex="-1">{{"Invalid format." | uitkTranslate}}</span>' +
						'</div>',
						'<div ng-show="showInternalMessageOne" ng-class="{\'oui-rfrm-validation\': tkLayout === \'horizontal\', \'oui-rfrm-validation-vertical\': tkLayout === \'vertical\'}">' +
							'<span id="{{id}}_format_err" ng-class="{\'uitk-msg-error-inline-horizontal\': tkLayout === \'horizontal\'}" tabindex="-1">{{"Invalid format." | uitkTranslate}}</span>' +
						'</div>',
						'<div ng-if="!tkLayout">' +
							'<span ng-if="formatErrorFlag && format === \'email\' && emailErrorMessage !== undefined" id="{{id}}_format_err" ng-class="{\'uitk-msg-error-inline-horizontal\': tkLayout === \'horizontal\'}" tabindex="-1" translate>{{emailErrorMessage}}</span>' +
						'</div>',
						'<div ng-if="tkLayout && formatErrorFlag && format === \'email\' && emailErrorMessage !== undefined" ng-class="{\'oui-rfrm-validation\': tkLayout === \'horizontal\', \'oui-rfrm-validation-vertical\': tkLayout === \'vertical\'}">' +
							'<span id="{{id}}_format_err" ng-class="{\'uitk-msg-error-inline-horizontal\': tkLayout === \'horizontal\'}" tabindex="-1" translate>{{emailErrorMessage}}</span>' +
						'</div>',
                        '<div class="tk-input-masking-assistivetext oui-rfrm-tip" id="maxCharacterAllowedMessage" ng-if="maxCharacterAllowedMessage" tabindex="-1" translate>{{maxCharacterAllowedMessage}}</div>',
					'</div>'
					].join('')

	};
}]);


(function () {

    var uitkTooltip = function(uitkLiveRegionService){

        function link($scope, $element, $attr) {
            var focusableElementsString = "a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, *[tabindex], *[contenteditable]";


            var placement = $attr['tooltipPlacement'] ? $attr['tooltipPlacement'] : "below";
            var action = $attr['tooltipToggle'] ? $attr['tooltipToggle'] : "hover";


            $element.attr('tabindex', 0);
            $element.attr('aria-disabled', false);
            $element.attr('aria-owns', $element[0].childNodes[1].id);

            switch(placement) {
                case 'below':
                    $element.addClass("oui-ttip");
                    break;
                case 'above':
                    $element.addClass("oui-ttip oui-ttip-above");
                    break;
                case 'left':
                    $element.addClass("oui-ttip oui-ttip-left");
                    break;
                case 'above-left':
                    $element.addClass("oui-ttip oui-ttip-above oui-ttip-left");
                    break;
            }

            $element.bind("keydown", function(event) {
                var $this = $(this);
                var children = $this.find('*');

                var focusableItems = children.filter(focusableElementsString).filter(':visible');

                var focusedItem = $( document.activeElement );

                var numberOfFocusableItems = focusableItems.length;

                var focusedItemIndex = focusableItems.index(focusedItem);

                if(event.keyCode === 13 && !($element.hasClass('oui-ttip-visible'))) {
                    $scope.showTooltip();
                    angular.element($element[0].querySelector('span.oui-ttip-content')).focus();
                }
                else if( event.keyCode === 27 && $element.hasClass('oui-ttip-visible') ) {
                    $scope.hideTooltip();
                }

                else if ( event.keyCode == 9 ) { 
                    if ( !event.shiftKey && (focusedItemIndex == numberOfFocusableItems - 1) ) {
                        $scope.hideTooltip();
                    }
                    if ( event.shiftKey && focusedItemIndex=== -1 ){
                        $scope.hideTooltip();
                    }
                }
            });

            $element.bind("mouseenter", function(){
                $scope.showTooltip();
            });

            $element.bind("focus", function() {
                $scope.showTooltip();
            });

            $element.bind("mouseleave", function() {
                $scope.hideTooltip();
            });

            if(action === "hover") {
                $element.bind("blur", function() {
                    $scope.hideTooltip();
                });
            }


            else { 
                $element.bind("click", function(){
                    $scope.showTooltip();
                });
            }

            $scope.showTooltip = function() {
                if($scope.tooltipForTruncate === "true"){
                    var truncElement = $element[0].querySelector('span.tk-trunc');
                    if(truncElement.offsetWidth >= truncElement.scrollWidth ){
                        return;
                    }
                }
                $($element[0].querySelector('span.oui-ttip-structure')).css("opacity","0");
                $($element[0].querySelector('span.oui-ttip-structure')).stop();
                $element.addClass("oui-ttip-visible");
                setTimeout( function() {
                    $($element[0].querySelector('span.oui-ttip-structure')).animate({
                        opacity: 1
                    }, 500);
                }, 3);

                angular.element($element[0].querySelector('span.oui-ttip-structure')).attr('aria-hidden', false);
                angular.element($element[0].querySelector('span.oui-ttip-structure')).attr('aria-expanded', true);
                uitkLiveRegionService.alertMessage($element[0].innerText || $element[0].textContent);
            }

            $scope.hideTooltip = function() {
                $($element[0].querySelector('span.oui-ttip-structure')).css("opacity","1");
                $($element[0].querySelector('span.oui-ttip-structure')).stop();
                $($element[0].querySelector('span.oui-ttip-structure')).animate({
                    opacity: 0
                }, 500, function () {
                    $element.removeClass("oui-ttip-visible");
                });
                angular.element($element[0].querySelector('span.oui-ttip-structure')).attr('aria-hidden',true);
                angular.element($element[0].querySelector('span.oui-ttip-structure')).attr('aria-expanded', false);
            }

        }

        return {
            restrict : 'A',
            replace : true,
            scope : {
                tooltipForTruncate: '@'
            },
            link : link
        };
    };
    uitkTooltip.$inject = ["uitkLiveRegionService"];

    var uitkTooltipContent = function() {

        function link($scope, $element, $attr) {

            $scope.tooltipId = $element[0].parentElement.id;
            $scope.descripbyId = $scope.id + '_desc';
            $element.attr("name", $attr['id']+"-name");
            $element.attr("aria-hidden", true);
            $element.attr('role', "tooltip");



            if ( $scope.richContent ) {
                $element.attr('aria-haspopup', true);
                $element.attr('aria-expanded', false);
                $element.attr('tabindex', 0);
            }
        }

        return {
            require : '^?uitkTooltip',
            restrict : 'E',
            replace : true,
            transclude : true,
            scope : {
                id: '@',
                ttipWidth : '@',
                richContent : '='
            },
            link : link,
            template: ' <span class="oui-ttip-structure"> <span class="oui-ttip-content" tabindex="-1" style="width: {{ttipWidth}};" ng-transclude> </span></span>'
        };
    };

    var uitkTruncate = function() { 
        return {
            restrict : 'EA',
            scope : {
                tkContent : '@'
            },
            template: '<span uitk-tooltip class="tk-trunc-container" tooltip-for-truncate="true" >' +
            '<span class="tk-trunc">{{tkContent}}</span> ' +
            '<uitk-tooltip-content>{{tkContent}}</uitk-tooltip-content>' +
            '</span>'
        };
    };



    angular.module('uitk.component.uitkTooltip',['uitk.uitkUtility'])
        .directive('uitkTooltip', uitkTooltip)
        .directive('uitkTooltipContent', uitkTooltipContent)
        .directive('uitkTruncate',uitkTruncate)
})();
angular.module('uitk.component.sessionTimeout', ['uitk.component.uitkDialog','uitk.uitkUtility'])
.directive('uitkSessionTimeout', ["$timeout", "$interval", "$http", "$window", function ($timeout, $interval, $http, $window) {
        function controller($scope){
            if(!$scope.model){
                $scope.model = {};
            }
            if(!$scope.model.sessionTimeoutUrl){
                $scope.model.sessionTimeoutUrl = '/sessionexpired'
            }
            if(!$scope.model.sessionWarningTimeInMinutes){
                $scope.model.sessionWarningTimeInMinutes = 10;  
            }
            if(!$scope.model.sessionLogoutTimeInMinutes){
                $scope.model.sessionLogoutTimeInMinutes = 15;  
            }
            if(!$scope.model.announceInterval){
                $scope.model.announceInterval = 30;  
            }
            $scope.model.show = false;
            $scope.warningTime = null;

            $scope.model.sessionLogoutTimeInMinutes -= 1;

            var mins = ($scope.model.sessionLogoutTimeInMinutes - $scope.model.sessionWarningTimeInMinutes);
            var secs = mins * 60;

            var remainingMinutes = Math.floor(secs/60);
            var remainingSeconds = secs - Math.round(remainingMinutes * 60);
            var timeInMinsAndSecs = remainingMinutes + ' minutes ' + remainingSeconds + ' seconds';
            $scope.warningMessage = 'Your session will expire in '+timeInMinsAndSecs+' due to inactivity.';
        }
        controller.$inject = ["$scope"];
	 return {
		    restrict: 'E',
		    replace: true,
		    scope:{
		    	model:'='
		    },
            controller: controller,
		    link: function($scope){


		    			    	var decrementPromise;
		    	var flag = 0;
		    	var remainingMinutes = 0, remainingSeconds = 0;

		    	var mins = ($scope.model.sessionLogoutTimeInMinutes - $scope.model.sessionWarningTimeInMinutes);
		    	var secs = mins * 60;
		    	var serverTimerPromise; 
		    	var serverTimeRemaining = $scope.model.sessionLogoutTimeInMinutes * 60000;
                var interval = 0;

		    	function idleLogout() {
		    		var timeupPromise;
		    		window.onload = resetTimer;
		    		window.onmousemove = resetTimer;
		    		window.onmousedown = resetTimer; 
		    		window.onclick = resetTimer; 
		    		window.onscroll = resetTimer; 
		    		window.onkeypress = resetTimer;

		    		function timeup() {
		    			$scope.warningTime = null;
		    			$scope.model.show = true;
		    			countdown();
		    		}

		    		function resetTimer() {

			    		if(decrementPromise !== undefined && decrementPromise.$$state.value === undefined){
			    			return;
			    		}
		    			$timeout.cancel(timeupPromise);
		    			timeupPromise = $timeout(timeup,getTimeInMillis($scope.model.sessionWarningTimeInMinutes));
		    			checkServerSession();
		    		}
		    		resetTimer();
		    		startServerTimer();
		    	}

		    	function startServerTimer(){
		    		serverTimerPromise = $interval(function() {
		    			serverTimeRemaining-=1000; 
		    		}, 1000);
		    	}

		    			    	function checkServerSession(){
		    		if (serverTimeRemaining < 20000) { 
		    			resetServerSession();
		    		}
		    	}

		    	function countdown() {
		    		$interval.cancel(decrementPromise);
		    		decrementPromise = $interval(decrement, 1000);
		    		flag = 0;
		    	}

		    	$scope.clearCountDown = function() {
		    		$interval.cancel(decrementPromise);

		    				    		$scope.model.show = false;
		    		mins = ($scope.model.sessionLogoutTimeInMinutes - $scope.model.sessionWarningTimeInMinutes);
		    		secs = mins * 60;
		    		flag = 1;
                    interval = 0;
		    		resetServerSession();
		    	};

                $scope.setMessage = function() {
                    angular.element('#session-warning-message').html(getWarningMessage());
                };

		    	function resetServerSession() {
		    		$interval.cancel(serverTimerPromise);
		    		try {
		    			var url = location.href;
		    			if(url.indexOf('#') !== -1){
		    				url = url.substring(0,url.indexOf('#'));
		    			}
		    			$http.get(url);

		    					    			serverTimeRemaining = getTimeInMillis($scope.model.sessionLogoutTimeInMinutes);
		    			startServerTimer();
		    		} catch (e) {
		    			throw {
	         				name : 'Exception',
	         				message : e
	         			};
		    		}		
		    	}

		    	function forwardToSessionExpiration(){
		    		var contextPath = window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));
		    		$window.location = contextPath + $scope.model.sessionTimeoutUrl;
		    	}

		    	function decrement() {
		    		checkServerSession();
	    			remainingMinutes = getMinutes();
	    			remainingSeconds = getSeconds();
                    var warningMessage = getWarningMessage();
	    			secs--;

	    				    			if (flag === 0 && remainingMinutes === 0 && remainingSeconds === 0) {
	    				$interval.cancel(decrementPromise);
	    				$timeout(forwardToSessionExpiration,5000);
	    			}

                    if(interval === $scope.model.announceInterval) {
                        interval = 0;
                        $scope.ariaLiveFlag = 'assertive';
                    } else {
                        $scope.ariaLiveFlag = 'off';
                    }
                    interval++;
                    angular.element('#session-warning-message').html(warningMessage);
		    	}

                function getWarningMessage(){
                    remainingMinutes = getMinutes();
                    remainingSeconds = getSeconds();

                    var timeInMinutesAndSeconds = "";
                    if(remainingMinutes > 1) {
                        timeInMinutesAndSeconds = remainingMinutes + " minutes ";
                    } else if(remainingMinutes === 1) {
                        timeInMinutesAndSeconds = remainingMinutes + " minute ";
                    }

                    if(remainingSeconds > 1) {
                        timeInMinutesAndSeconds += remainingSeconds + " seconds";
                    } else if(remainingSeconds === 1) {
                        timeInMinutesAndSeconds += remainingSeconds + " second";
                    }

                    return 'Your session will expire in <span style="font-weight:bold;" id="time-remaining">'+timeInMinutesAndSeconds+'</span> due to inactivity.';
                }

		    			    	function getMinutes() {
		    		mins = Math.floor(secs / 60);
		    		return mins;
		    	}
		    	function getSeconds() {
		    		return secs - Math.round(mins * 60);
		    	}

		    	function getTimeInMillis(minutes){
		    		return (minutes * 60 * 1000);
		    	}

		    	idleLogout();
		    },
		    template: [
						'<div ng-show="warningTime !== undefined">',
							'<uitk:dialog dialog-id="session-timeout-dialog" dialog-role="dialog" call-back-show="setMessage();" tk-zindex="100000" tk-aria-describedby="session-timeout-dialog_contentId" header-text="Session About to Expire" show="model.show" ng-if="model.show" default-width="30%" call-back-hide="clearCountDown" style="width:30%" default-height="40%">',
								'<div class="tk-panl-content">',
									'<div id="session-warning-message" aria-live="{{ariaLiveFlag}}" aria-atomic="true">{{warningMessage}}</div>',
									'<div class="tk-margin-top-1t">{{"Click Continue to remain signed in." | uitkTranslate}}</div>',
									'<div class="tk-margin-top-1t">',
										'<uitk:button type="button" value="Continue" aria-describedby="extend-session" enable-default="true" ng-click="clearCountDown();" custom-class="uitk-width-7t  tk-margin-top-1t"></uitk:button>',
										'<span tabindex="-1" class="oui-a11y-hidden" id="extend-session">Select to extend your session</span>',
									'</div>',
								'</div>',
							'</uitk:dialog>',
						'</div>'
		               ].join('')
		  };
}]);
angular.module('uitk.component.uitkVerticalNavigation', ['uitk.component.uitkSlideAnimation','uitk.component.uitkNavigable','uitk.uitkUtility'])
.directive('uitkVerticalNavigation',['$compile','$document', '$timeout', '$location','$filter','uitkExceptionService', function($compile, $document, $timeout, $location, $filter, uitkExceptionService){

		function controller($scope, $element){
		$scope.model.level = $scope.$parent.model ? $scope.$parent.model.level + 1 : 1;
		$element.hide();

				if($scope.model.level === 1){
			$scope.model.menuVisible = true;

						if($scope.model.openFirstUrl){
				var firstLink = $scope.model.links[0];
				while(firstLink.dropDown){
					firstLink.dropDown.menuVisible = true;
					firstLink = firstLink.dropDown.links[0];
				}
				firstLink.selected = true;
				if(firstLink.url[0] === '#'){
					$location.path(firstLink.url.substring(1));
				}
				else{
					window.location = firstLink.url;
				}
			}
		}


						$scope.expandMenuOrRedirectToLink = function($event, item){

									if(item.dropDown) {
				item.dropDown.menuVisible = item.dropDown.menuVisible?!item.dropDown.menuVisible:true;

								if(item.dropDown.menuVisible) { 
					item.dropDown.setOnFocus(); 
					var linkWithDropDowns = $scope.model.links;
					 while(linkWithDropDowns.length > 0) {
						 linkWithDropDowns = linkWithDropDowns.filter(function(link){ if(link !== item){ return link.dropDown; }}); 
						 var allDropdownUnderLink = linkWithDropDowns.map(function(link){ return link.dropDown; }); 
						 allDropdownUnderLink.forEach(function(dropDown) { dropDown.menuVisible = false; }); 
						 linkWithDropDowns = allDropdownUnderLink
						 						.filter(function(dropDown){ return dropDown.links; })
						 						.map(function(dropDown){ return dropDown.links; })
						 						.reduce(function(allLink, links){ return allLink.concat(links);}, []);
					 }
				}
				else{
					item.dropDown.links.forEach(function(subItem) {
						if(subItem.dropDown){
							subItem.dropDown.menuVisible = false;
						}
					});
				}
			}

						if(item.url){
				if(item.url[0] === '#'){
					$location.path(item.url.substring(1));
				}
				else{
					window.location = item.url;
				}

					var scope = $scope;
					while(scope.$parent.model !== undefined){
						scope = scope.$parent;
					}

										linkWithDropDowns = scope.model.links;
					while(linkWithDropDowns.length > 0) {
						linkWithDropDowns = linkWithDropDowns.filter(function(link){ link.selected = false; return link.dropDown; }); 
						allDropdownUnderLink = linkWithDropDowns.map(function(link){ return link.dropDown; }); 
						linkWithDropDowns = allDropdownUnderLink
						 						.filter(function(dropDown){ return dropDown.links; })
						 						.map(function(dropDown){ return dropDown.links; })
						 						.reduce(function(allLink, links){ return allLink.concat(links);}, []);
					}
				item.selected = true;

								$scope.hideSiblingMenus(item);
			}
		};	

				$scope.hideSiblingMenus = function(){
			 var linkWithDropDowns = $scope.model.links;
			 while(linkWithDropDowns.length > 0) {
				 linkWithDropDowns = linkWithDropDowns.filter(function(link){ return link.dropDown; }); 
				 var allDropdownUnderLink = linkWithDropDowns.map(function(link){ return link.dropDown; }); 
				 allDropdownUnderLink.forEach(function(dropDown) { dropDown.menuVisible = false; }); 
				 linkWithDropDowns = allDropdownUnderLink
				 						.filter(function(dropDown){ return dropDown.links; })
				 						.map(function(dropDown){ return dropDown.links; })
				 						.reduce(function(allLink, links){ return allLink.concat(links);}, []);
			 }
		 };

		 		 $scope.isExpanded = function(item){
				if(item.dropDown){
					if(item.dropDown.menuVisible){
						return true;
					}
					else { 
						return false;
					}
				}
				else{
					return undefined;
				}
			};
	}
	controller.$inject = ["$scope", "$element"];

	return {
		restrict : 'E',
		replace : true,
		transclude : true,
		scope : {
			model : '='
		},
		compile:function(tElement) {
            var contents = tElement.contents().remove();
            var compiledContents;
            return function(scope, iElement) {
            	if(!compiledContents) {
                    compiledContents = $compile(contents);
                }
                compiledContents(scope, function(clone) {
                         iElement.append(clone); 
                });

                if(!scope.model.id && scope.model.level === 1){
                    uitkExceptionService.throwException('InvalidIdException','Id is required attribute');
         		}

                                scope.model.links.forEach(function(link){ if(link.url && link.dropDown){
                    uitkExceptionService.throwException('InvalidLinkException','Link can not have both url and dropDown element');
                }});

                                scope.model.setOnFocus = function() { 
        			$timeout(function(){ iElement.find('a')[0].focus(); }) ;
        		};

        		        		scope.model.links.forEach(function(link,index){
        			link.setFocus = function(){
        				var otherElement = iElement.find('ul a');
        				$timeout(function(){ iElement.find('a').not(function(index, element){
        					return _.includes(otherElement, element);
        				})[index].focus(); }) ;
        			}
        		});

        		            };
        },
		template : [
					'<ul ng-class=\'{"menuVisible": model.menuVisible, "tk-vnav": model.level===1 }\' role="{{model.level === 1 ? \'navigation\' : \'group\'}}" uitk-slide-show="model.menuVisible" uitk-slide-show-duration="500">',
					'	<li ng-repeat="item in model.links" ng-class=\'{"disabled": item.disabled}\' ng-if="!item.hidden">',
					'	<a ng-class="{\'select-active\': item.selected}" uitk-navigable="!item.disabled" ng-if="!item.disabled" ng-click="expandMenuOrRedirectToLink($event,item)" ng-attr-aria-expanded="{{isExpanded(item)}}" aria-haspopup="{{item.dropDown ? true : false}}" uitk-compile-vertical-link="item">',
					'		<span ng-if="item.dropDown && item.dropDown.menuVisible" class="cux-icon-carrot_down"></span>',
					'		<span ng-if="item.dropDown && !item.dropDown.menuVisible" class="cux-icon-carrot_right"></span>',
					'	</a>',
					'	<span ng-click="$event.stopPropagation();" aria-disabled="true" ng-if="item.disabled" uitk-compile-vertical-link="item"></span>',
					'	<uitk-vertical-navigation ng-if="item.dropDown" model="item.dropDown"></uitk-vertical-navigation>',
					'	</li>',
					'</ul>'
		           ].join(''),
		controller : controller
	};
}])
.directive('uitkCompileVerticalLink', ["$compile", function ($compile) {
	  return function($scope, $element) {
		  $compile($scope.item.textTemplate)($scope, function(clone){
			  if(!clone.selector){
				  $element.prepend(clone);
			  }
			  else{
				  $element.prepend(clone.selector);
			  }
	    });
	  };
}]);

/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 *
 */
'use strict';
angular.module('oid.component.oidTextSelectCombo', ['uitk.maxlength']).directive('oidTextSelectCombo',['$timeout', function ($timeout){
	return {
		restrict:'E',
		replace : true,
		transclude: true,
		
		controller: ["$scope", function($scope) {
            if($scope.maxCharacterAllowed) {
                $scope.maxCharCount = $scope.maxCharacterAllowed;
            }
		}],
		
        link: function(scope, elem, attrs){               	
        	scope.selectStyle = {
        		"background-color": "#f8f0ef",
        		"color" : "#666"
        	};
        	
        	scope.wrapStyle = {"word-break" : "break-all"};
        	
        	if(scope.maxCharacterAllowed && !scope.maxCharacterAllowedMessage){
                scope.maxCharacterAllowedMessage = "Accepts no more than "+scope.maxCharacterAllowed+" characters";
            }

        	scope.blurEvent = function(event) {
        		scope.checkFieldValidation = true;
				$timeout(function(){
					scope.onBlur(event);
				});
			};

			scope.focusEvent = function(event){
				$timeout(function(){
					scope.onFocus(event);
				});
			};

			scope.keypressEvent = function(event){
				$timeout(function(){
					scope.onKeypress(event);
				});
			};
			
			scope.pasteEvent = function(event) {
                var pasteText = (event.originalEvent || event).clipboardData.getData('text/plain');
                if(scope.maxCharacterAllowed && (scope.model || '').length + pasteText.length > scope.maxCharacterAllowed){
                    scope.model = ((scope.model || '') + pasteText).substring(0, scope.maxCharacterAllowed);
                    event.preventDefault();
                }
            }
			
			scope.onchangeEvent = function(event) {
				$timeout(function(){
					scope.onChange(event);
				});
			}
			
			scope.keyupEvent = function(event){
				$timeout(function(){
					scope.onKeyup(event);
				});
			};

			scope.keydownEvent = function(event){
				$timeout(function(){
					scope.onKeydown(event);
				});
			};
			
			scope.navigate = function(ev, val){
				if(ev.keyCode === 13){
					scope.showUserNameSuggestion = false;
					scope.toModel(val);
				}
			}
			
			scope.clickHandler = function(val){
				var userNameInputId = document.getElementById(scope.id + "_input");
				var userNameInputInfo = document.getElementById(scope.id + "_info");
				$timeout(function() {
					angular.element(userNameInputId).attr("aria-invalid", "false");
					angular.element(userNameInputId).attr("aria-describedby", "userNameTipId");
					scope.toModel(val);
				}, 10);
				
				$timeout(function() {
					angular.element(userNameInputId).focus();
					angular.element(userNameInputId).select();
					angular.element(userNameInputInfo).parent().attr("style", "display:none;");
				}, 100);
			}

			scope.toModel = function(val){
				scope.model = val;
			}

			scope.$watch("model", function(newValue){
				if(newValue !== scope.initialValue) {
					scope.checkFieldValidation = true;
				}
			});
        },
        
        scope : {
        	id : '@',
        	name : '@',
        	model: '=',
        	checkFieldValidation: '=',
        	tkRequired:'=',
        	styleClass: '@',
        	tkErrorClass: '=',
        	tkDisabled : '@',
        	maxCharacterAllowed:'@',
            maxCharacterAllowedMessage: '@',
        	onBlur: '&', 
        	onFocus: '&',
        	onKeypress: '&',
        	onKeyup: '&',
        	onKeydown: '&',
        	onChange: '&',
			itemList:'=',
			selectInfoMsg:'=',	
			showUserNameSuggestion: '=',
			selectOptumIdMsg: '=',
	        suggestionBoxClass: '@'
		},
        template: ['<div>',
						'<input id="{{id}}_input" type="text" ng-attr-name="{{name}}"   ng-keydown="keydownEvent($event);" ng-change="onchangeEvent($event)"',
						    'class="tk-input-masking {{styleClass}}" ng-class="{\'tk-form-field-error\':tkErrorClass}"',
						    'ng-blur="blurEvent($event, model)" ng-focus="focusEvent($event)" ng-keypress="keypressEvent($event)"',
						    'ng-model="model" autocomplete="off" aria-autocomplete="none" aria-required="{{tkRequired ? true : false}}"',
						    'ng-disabled="{{tkDisabled}}" ng-keyup="keyupEvent($event)" ng-trim="false" uitk-maxlength="{{maxCharCount}}"', 
						    'ng-required="(tkRequired && checkFieldValidation) ? true : false">',
						'</input>',
						'<div ng-style="selectStyle" class="tk-margin-bottom-min errBg {{suggestionBoxClass}} " ng-if="showUserNameSuggestion">',
							'<div class="tk-rfrm-validation tk-padding-halft">',
							    '<small class="error uitk-msg-error-inline" id="{{id}}_info" tabindex="-1">',
							        '<span ng-bind="selectInfoMsg"/>',
							    '</small>',
							    '<ul ng-style="wrapStyle" id="{{id}}_suggestions">',
								    '<li ng-repeat="opts in itemList" class="tk-padding-left-halft tk-padding-top-halft">',
										'<a title="{{selectOptumIdMsg}}" ng-keyup="navigate($event, opts.value)" id="{{id}}_link_{{$index}}" ng-click="clickHandler(opts.value)" ng-bind="opts.label" class="selectContainer" href></a>',
									'</li>',
								'</ul>',
							'</div>',
						'</div>',
					'</div>'].join('')
    };

}]);
