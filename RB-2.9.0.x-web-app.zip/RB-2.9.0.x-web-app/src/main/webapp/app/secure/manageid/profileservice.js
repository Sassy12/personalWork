'use strict';

(function() {
    var tbApp = angular.module('tbApp');
    tbApp.service('ProfileService', ProfileService);

    ProfileService.$inject = ['$http', '$q'];

    function ProfileService($http, $q) {
        var tabModel = null;
        var serviceCache = {};
        var currentIdx,
            tempTabIdx,
            tabScope;

        /* flag to show success msg in 1st tab when coming from 3rd tab */
        this.showSuccessMsg = false;
        this.cancelFlow = false;

        var config = {
            URL_RP_CONTEXT: '/tb/services/secure/rest/manageid/profileinfo/rpContext',
            URL_PROFILE: '/tb/services/secure/rest/manageid/profileinfo',
            URL_CHANGE_PWD: '/tb/services/secure/rest/manageid/changepwd',
            URL_CHANGE_PWD_DATA: '/tb/services/secure/rest/manageid/changepwd/context',
            URL_RECOVERY_OPTIONS: '/tb/services/secure/rest/manageid/accountrecovery'
        };

        this.getRPContext = function() {
            return $http.get(config.URL_RP_CONTEXT).then(function(response) {
                serviceCache.rpData = response.data;
            });
        };

        this.getRPDetailsFromCache = function() {
            return serviceCache.rpData;
        };

        this.getProfileInfo = function() {
            var deferred = $q.defer();

            if (serviceCache.profileData) {
                deferred.resolve(serviceCache.profileData);
            } else {
                $http.get(config.URL_PROFILE).then(function(response) {
                    serviceCache.profileData = response.data;
                    deferred.resolve(response.data);
                }, function(error) {
                    deferred.reject(error);
                });
            }

            return deferred.promise;
        };

        this.updateProfileInfo = function(postData) {
            var deferred = $q.defer();

            $http.post(config.URL_PROFILE, postData).then(function(response) {
                angular.extend(serviceCache.profileData.profile, postData);
                deferred.resolve(response);
            }, function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        };

        this.changePassword = function(postData) {
            return $http({
                method: 'POST',
                url: config.URL_CHANGE_PWD,
                data: $.param(postData),
                headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' }
            });
        };

        this.updateTabIndex = function(index) {
            if (tabModel) {
                tabModel.selectedIndex = index;
            }

            currentIdx = index;
        };

        this.saveTempTabIndex = function(index) {
            tempTabIdx = index;
        };

        this.getTempTabIndex = function() {
            return tempTabIdx;
        };

        this.getTabIndex = function() {
            if (tabModel) {
                return tabModel.selectedIndex;
            } else {
                return currentIdx;
            }
        };

        this.saveTabModel = function(tabMdl) {
            tabModel = tabMdl;
        };

        this.saveTabScope = function(scope) {
            tabScope = scope;
        };

        this.showModal = function() {
            if (tabScope) {
                tabScope.showModal = true;
            }
        };

        this.getPasswordPageData = function() {
            var deferred = $q.defer();

            if (serviceCache.changePwdData) {
                deferred.resolve(serviceCache.changePwdData);
            } else {
                $http.get(config.URL_CHANGE_PWD_DATA).then(function(response) {
                    serviceCache.changePwdData = response.data;
                    deferred.resolve(response.data);
                }, function(error) {
                    deferred.reject(error);
                });
            }

            return deferred.promise;
        };

        this.getVerifyOptionsData = function() {
            return $http.get(config.URL_RECOVERY_OPTIONS);
        };

        this.updateVerifyOptions = function(postData) {
            return $http.post(config.URL_RECOVERY_OPTIONS, postData);
        };

        this.saveVerifyOptionsPageData = function(data) {
            serviceCache.verifyOptionsData = data;
        };

        this.getVerifyOptionsPageData = function() {
            return serviceCache.verifyOptionsData;
        };
    }
})();
