'use strict';

var indexApp = angular.module('common.modules');

indexApp.controller("updateEmailAddressController", ["$scope", "$stateParams", "$state", "updateEmailAddressService", "$translate", '$rootScope', 'HelpObj', updateEmailAddressController]);
function updateEmailAddressController($scope, $stateParams, $state, updateEmailAddressService, $translate, $rootScope, HelpObj) {
    var formErrorMsg = ['<span>', $translate.instant('updEmailFormLvlErr'), '</span>'].join('');

    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1005_Update_Email_Address.htm' });
    $scope.updateEmailAddressError = "";
    $scope.updateEmailAddress = "";
    $scope.UpdateEmailFormErrorMessageModel = {
        animationTime: 1,
        ariaAttributes: true,
        autoFadeOut: false,
        content: formErrorMsg,
        headingLevel: '2',
        id: 'updateEmailFormLvlErrorMessage',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    $scope.resetValues = function() {
        $scope.UpdateEmailFormErrorMessageModel.visible = false;
        $scope.UpdateEmailFormErrorMessageModel.content = formErrorMsg;
        $scope.updateEmailAddressError = "";
    };

    $scope.cancelUpdEmail = function() {
        var verifyCodesCtx = $stateParams.vo.ctx;

        if (verifyCodesCtx.sendChannels) {
            verifyCodesCtx.sendChannels = [];
        }

        $state.go("confirmEmailAddress", {
            'verifyCodesCtx': verifyCodesCtx,
            "fromState": null,
            "emailShared": $stateParams.emailShared
        });
    };

    $scope.update = function() {
        $scope.UpdateEmailFormErrorMessageModel.visible = false;
        $scope.UpdateEmailFormErrorMessageModel.content = formErrorMsg;
        $scope.updateEmailAddressError = '';

        var vo = $stateParams.vo,
            form = $scope.updateEmailAddressForm;

        if (form.$submitted && form.updateEmailAddress.$error.required) {
            $scope.UpdateEmailFormErrorMessageModel.visible = true;
            angular.element("#updateEmailInput_input").focus();
            $rootScope.fireErrorTracker = true;
            return;
        }

        if (!validators.isValidEmail($scope.updateEmailAddress)) {

            $scope.UpdateEmailFormErrorMessageModel.visible = true;
            $scope.updateEmailAddressError = $translate.instant('emailInvalid');
            angular.element("#updateEmailInput_input").focus();
            $rootScope.fireErrorTracker = true;
            return;
        }

        if (vo.ctx.optionValue && vo.ctx.optionValue.toLowerCase() === $scope.updateEmailAddress.toLowerCase()) {
            $scope.UpdateEmailFormErrorMessageModel.visible = true;
            $scope.updateEmailAddressError = $translate.instant('unAlteredEmailAdd');
            angular.element("#updateEmailInput_input").focus();
            $rootScope.fireErrorTracker = true;
            return;
        }

        var verifyCodesVO = {};
        var ctx = $stateParams.vo.ctx;
        verifyCodesVO.ctx = ctx;
        verifyCodesVO.channel = ctx.chann;
        verifyCodesVO.email = $scope.updateEmailAddress;
        verifyCodesVO.emailShared = $stateParams.emailShared;

        updateEmailAddressService.update(verifyCodesVO).then(function(response) {
            if (response.data.status === 'success') {
                var verifyCodesCtx = $stateParams.vo.ctx;

                /* If update is success, add send channels to trigger confirmation code email from
                 * confirmation page for this updated email
                 */
                if (verifyCodesCtx.sendChannels && verifyCodesCtx.sendChannels.length === 0) {
                    verifyCodesCtx.sendChannels = [verifyCodesCtx.chann];
                    verifyCodesCtx.viewChannels = [verifyCodesCtx.chann];
                }

                if (verifyCodesCtx.userVO) {
                    verifyCodesCtx.userVO.emailAddress = $scope.updateEmailAddress;
                }

                verifyCodesCtx.optionValue = $scope.updateEmailAddress;

                /* Don't send emailShared attribute as we don't have any status whether
                 * it's shared email or not after update */
                $state.go('confirmEmailAddress', {
                    'verifyCodesCtx': verifyCodesCtx,
                    "fromState": "updateEmailAddress"
                });
            }
        }, function(errorResponse) {
            var errorData = errorResponse.data;
            var errorMap = errorData.errorMap;

            if (errorMap && Object.keys(errorMap).length > 0) {
                if ("email" in errorMap) {
                    $scope.updateEmailAddressError = errorMap.email;
                }
            } else if ('message' in errorData) {
                $scope.UpdateEmailFormErrorMessageModel.content = ['<span>', errorData.message, '</span>'].join('');
            }

            $scope.UpdateEmailFormErrorMessageModel.visible = true;
            angular.element("#updateEmailInput_input").focus();
            $rootScope.fireErrorTracker = true;
        });
    };
}
