(function() {
    'use strict';

    var tbApp = angular.module('tbApp');

    tbApp.controller('ChangePwdController', ChangePwdController);

    ChangePwdController.$inject = ['$scope', 'ProfileService', 'trustbrokerAriaService', '$translate', '$timeout', 'uitkLiveRegionService', '$rootScope', '$window', 'HelpObj'];

    function ChangePwdController($scope, ProfileService, trustbrokerAriaService, $translate, $timeout, uitkLiveRegionService, $rootScope, $window, HelpObj) {
        // dynamically setting help link
        HelpObj.setHelpObj({ url: '../../webHelp/Default_CSH.htm#Optum ID CSH/entry_1016_Change_Password_on_Profile.htm' });
        $scope.constants = $rootScope.constants;                    //app constant values
        $scope.fireErrorTracker = $rootScope.fireErrorTracker;      //for analytics
        $scope.trackError = $rootScope.trackError;
        $scope.data = {};
        $scope.errors = {};
        var pageData = {};
        $scope.processing = false;

        var self = this;

        var errorMarkup = {
            'formErrorNote': '<span translate="formErrorsNote"></span>'
        };
        // function for getting the username and password info==============================================
        ProfileService.getPasswordPageData().then(function(response) {
            pageData = response;
            $scope.userName = pageData.profile.userName;
        });
        // function for setting field validity for WCAG
        $scope.setFieldValidity = function(inputid, spanid) {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        };
        // Message model for success messages
        $scope.successMessageModel = {
            animationTime: 1,
            ariaAttributes: true,
            autoFadeOut: false,
            content: '<span translate="updateSuccess"></span>',
            headingLevel: '2',
            id: 'Success',
            messageRole: 'alert',
            messageType: 'success',
            position: 'inline',
            visible: true
        };
        // Message model for error messages
        $scope.errorMessageModel = {
            animationTime: 1,
            ariaAttributes: true,
            autoFadeOut: false,
            content: errorMarkup.formErrorNote,
            headingLevel: '2',
            id: 'Error',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: true
        };
        // function for clicking cancel button
        $scope.onCancel = function($event) {
            if (self.checkForUnsavedChanges()) {
                $event.preventDefault();
                ProfileService.saveTempTabIndex(0);
                ProfileService.showModal();
                return false;
            }
            if (pageData.rpContext && pageData.rpContext.targetURL) {
                $window.location.href = pageData.rpContext.targetURL;
            } else {
                ProfileService.updateTabIndex(0);

                $timeout(function () {
                    angular.element('#profiletabs_tab0_tab').focus();
                }, 300);
            }
        };
        //getting the password field validity from directive
        $rootScope.$on('IsPasswordValid', function(event, args) {
        	$scope.passwordFieldValid = args.msg;
        });
        // function for changing password
        $scope.savePwd = function(pwdData) {
        	console.log("inside save PWD: ",$scope.processing);
        	 var FIELDS = [
                           { fld: "passwordId_input",      msg: "passwordId_err" },
                           { fld: "confirmPwdId_input",    msg: "confirmPwdId_err" }
                       ];
            if ($scope.processing) {
                // Fire error tracker is to send a webanalytics event
                $rootScope.fireErrorTracker = true;
                return;
            }
            $scope.processing = true;
            $scope.showError = false;
            $scope.showSuccess = false;
            $scope.serverErrors = {};
            validateConfirmPwdField();      //validate confirm password field
            var hasErrors = false,
                prop,
                errors = $scope.errors;
            for (prop in errors) {
                if (errors[prop] === true) {
                    hasErrors = true;
                    break;
                }
            }
            if (hasErrors || $scope.changepwd_form.$invalid) {
                $scope.errorMessageModel.content = errorMarkup.formErrorNote;
                $scope.showError = true;
                $scope.processing = false;
                // For putting focus and setting WCAG properties
                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                }, 200, false);
                // Fire error tracker is to send a webanalytics event
                $rootScope.fireErrorTracker = true;
                return;
            }
            var postData = {
                newPwd: pwdData.pwd,
                confirmPwd: pwdData.confirmPwd
            };
            // making service call for saving information only if client side validations passes=================================           
            if ($scope.passwordFieldValid) {
	            ProfileService.changePassword(postData).then(function() {
	                $scope.showSuccess = true;
	                $scope.processing = false;
	                clearFields(pwdData);
	
	                $timeout(function() {
	                    angular.element('#Success').focus();
	                    $rootScope.$emit('formSuccessSaved', { msg: 'saved' });
	                }, 300);
	            }, function(error) {
	                $scope.processing = false;
	                var errorData = error.data;
	
	                if (errorData.errorMap) {
	                    var formErrors = error.data.errorMap,
	                        serverErrors = {};
	
	                    for (prop in formErrors) {
	                        if (formErrors.hasOwnProperty(prop)) {
	                            var errorKey = formErrors[prop];
	                            var translatedMsg = $translate.instant(errorKey);
	                            if (translatedMsg !== errorKey) {
	                                serverErrors[prop] = translatedMsg;
	                            } else {
	                                serverErrors[prop] = errorKey;
	                            }
	                        }
	                    }
	
	                    $scope.serverErrors = serverErrors;
	                    $rootScope.$emit('serverError', {msg: $scope.serverErrors.pwd, title: 'clearingField'});	//emitting server side errors
	                    $scope.errorMessageModel.content = errorMarkup.formErrorNote;
	                } else if (errorData.message) {
	                    $rootScope.$emit('formLevelSeverError', { msg: errorData.message });
	                    $scope.errorMessageModel.content = ['<span>', errorData.message, '</span>'].join('');
	                    $timeout(function() {
	                        angular.element('#Error').focus();
	                    }, 300);
	                }
	
	                $scope.showError = true;
	                clearFields(pwdData);
	                // Fire error tracker is to send a webanalytics event
	                $rootScope.fireErrorTracker = true;
	            });
            }
            else {
            	// if client side validation fails
            	 $scope.errorMessageModel.content = errorMarkup.formErrorNote;
            	 $scope.showError = true;
            	 $scope.processing = false;
            	// For putting focus and setting WCAG properties
                 $timeout(function() {
                     trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                 }, 200, false);
                 $rootScope.fireErrorTracker = true;
            }
        };

        function clearFields(pwdData) {
            pwdData.pwd = '';
            pwdData.confirmPwd = '';
            $scope.changepwd_form.$setUntouched();
        }
        //function for validating confirm password field
        function validateConfirmPwdField() {
            var isConfPwdReq = false,
                pwdNotMatching = false;
            var formData = $scope.data;

            if (validators.checkIfEmpty(formData.confirmPwd)) {
                isConfPwdReq = true;
            } else if (formData.pwd !== formData.confirmPwd) {
                pwdNotMatching = true;
            }

            $scope.errors.confirmPwdReq = isConfPwdReq;
            $scope.errors.pwdNotMatching = pwdNotMatching;
        }

        this.checkForUnsavedChanges = function () {
            var pwdData = $scope.data;

            if (!validators.checkIfEmpty(pwdData.pwd) || !validators.checkIfEmpty(pwdData.confirmPwd)) {
                return true;
            } else {
                return false;
            }
        };
    }

})();
