/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 *
 */
'use strict';
var tbApp=angular.module('tbApp');

tbApp.service('mobileVerificationService',['$http', function($http){
	
	
    this.checkForPreVerification=function(ctx){
		
		return $http.post("/tb/services/secure/rest/verifyCodes/checkForPreVerification",ctx);
		
	};
	
     this.resendCommChannelCode=function(ctx){
		
		return $http.post('/tb/services/secure/rest/verifyCodes/resendEmail',ctx);
		
	};
	
	this.verifyPhoneCode=function(ctx){
		
		return $http.post('/tb/services/secure/rest/verifyCodes/verifyPhoneCodeInSession',ctx);
		
	};
	
	
}]);

