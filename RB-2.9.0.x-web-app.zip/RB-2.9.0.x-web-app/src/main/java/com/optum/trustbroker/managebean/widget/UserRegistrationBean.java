package com.optum.trustbroker.managebean.widget;

import java.io.Serializable;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;
import org.richfaces.event.ItemChangeEvent;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.context.ApplicationContext;
import com.optum.trustbroker.context.ApplicationContextHolder;
import com.optum.trustbroker.esso.sso.SsoContext;
import com.optum.trustbroker.esso.sso.utils.SsoUtils;
import com.optum.trustbroker.managebean.EmailConfirmationBean;
import com.optum.trustbroker.message.ErrorMessage;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.InvitationConstants;
import com.optum.trustbroker.util.IrmLoggingUtil;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.AddTrusetedDeviceRequest;
import com.optum.trustbroker.vo.AddTrustedDeviceResponse;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.ExecutionStatus;
import com.optum.trustbroker.vo.InvitationContextPropertyVO;
import com.optum.trustbroker.vo.InvitationServiceResponse;
import com.optum.trustbroker.vo.InvitationVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RPAppDomainVO;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserNameCheckServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.VerificationCodeResponse;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.commons.beans.DeviceDetails;
import com.uhg.iam.esso.schemas.xsd._2013._12.AuthenticationType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;


@ManagedBean(name = "wUserRegistrationBean")
@SessionScoped
public class UserRegistrationBean extends AbstractBackingBean implements Serializable {

	private static final long serialVersionUID = 1L;
	protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");
	
	BaseLogger logger = new BaseLogger(UserRegistrationBean.class);
	
	@ManagedProperty(value = "#{userVO}")
	private UserVO userVO;
	@ManagedProperty(value = "#{wSecurityQuestionsBean}")
	private SecurityQuestionsBean tbSecurityQuestionsBean;
	@ManagedProperty(value = "#{emailConfirmationBean}")
	private EmailConfirmationBean emailConfirmationBean;
	
	private String action = "/siteminderagent/forms/login.fcc";
	private String targetUrl = "/tb/secure/home.jsf";
	private String signInPage="/views/login.xhtml?faces-redirect=true";
	
	private String localenv = "false";
	private String errorMsg;
	private String dateOfBirth;
	private String currentActiveItem;
	private String currentButtonId;
	private String confirmEmailAddress;
	private String confirmnewEmailAddress;
	private String confirmPassword;
	private String mobilePhone;
	private List<String> userNameSuggestionsList;
	private List<String> oldUsernameSuggestionsList;
	private String emailExistsMsg;
	private String tierEmailMsg;
	private String specialCharsMsg;
	private String emailExistsMsgSec;
	private String passwordStrength;
	private String personalInfoErrorMsg;
	private String relyingAppErroMsg = null;
	private String relyingAppTrustErrorMessage = null;
	private String tempUserName;
	private String invitationCode =null;
	private String emailId =null;
	private String registerDevice = "No";
	private String devicePrint;
	private Map<String, String> verificationDetails = null;
	
	private boolean showSugestions;
	private boolean showEmail;
	private boolean relyingApp=false;
	private boolean emailVerified;
	private boolean personalInfoValid=false;
	private boolean credentialsValid=false;
	private boolean decryptionfailed = false;
	private boolean displayDeviceRegistration = true;
	private boolean relyinPartyTrusted = true;
	private boolean tncAccepted;
	private boolean privacyPolicyAccepted;
	private boolean disableEmailCode = true;
	private boolean showContinue = false;
	private boolean emailMandatory = true;
	private boolean emailShared = true;
	private boolean showEmailWarnMsg = false;
	private boolean showSecQuestionBasedonSharedEmail =false;
	private boolean showSecQuestionBasedonSharedEmailDynamic=false;
	private boolean showSuggestionMsg=false;
	private String validationPersonalErrorMsg="No";
	private String validationPersonalErrorMsg2="No";
	private String validationSecurityErrorMsg="No";
	private String validationEmailVerificationErrorMsg="No";
	
   
	private String firstNameErrorMessage;
	private String lastNameErrorMessage;
	private String emailErrorMessage;
	private String confirmEmailErrorMessage;
	private String userNameErrorMessage;
	private String passwordErrorMessage;
	private String confirmPasswordErrorMessage;
	private String dobErrorMessage;
	
	public String getDobErrorMessage() {
		return dobErrorMessage;
	}

	public void setDobErrorMessage(String dobErrorMessage) {
		this.dobErrorMessage = dobErrorMessage;
	}

	private String secQuestionOneErrorMessage;
	private String secAnswerOneErrorMessage;
	private String secQuestionTwoErrorMessage;
	private String secAnswerTwoErrorMessage;
	private String secQuestionThreeErrorMessage;
	private String secAnswerThreeErrorMessage;
	private String termsConditionErrorMessage;
	
	
	private String  emailVerificationCodeErrorMessage;
	private String  emailVerificationPasswordErrorMessage;
	
	//private String  registrationSuccess="No";
	private String  registrationSuccessMsg;
	
	
	private String pwdSpace;
	private String confirmPwdSpace;
	
	private static int yobLimit=2;
	private String yearOfBirth=null;
	private boolean yobValid=false;
	
	private final String INCORRECT_YEAR_OF_BIRTH_COUNT="_INC_YEAR_OF_BIRTH";
	
	
	private boolean coppaValidationReqd = true;
		
	
	public String getPwdSpace() {
		return pwdSpace;
	}

	public void setPwdSpace(String pwdSpace) {
		this.pwdSpace = pwdSpace;
	}

	public String getConfirmPwdSpace() {
		return confirmPwdSpace;
	}

	public void setConfirmPwdSpace(String confirmPwdSpace) {
		this.confirmPwdSpace = confirmPwdSpace;
	}

	public String getRegistrationSuccessMsg() {
		return registrationSuccessMsg;
	}

	public void setRegistrationSuccessMsg(String registrationSuccessMsg) {
		this.registrationSuccessMsg = registrationSuccessMsg;
	}

	public boolean isPersonalInfoValid(){
		return personalInfoValid;
	}
	public void setPersonalInfoValid(boolean val){
		personalInfoValid=val;
	}
	public boolean isCredentialsValid(){
		return  credentialsValid;
	}
	public void setCredentialsValid(boolean val){
		credentialsValid=val;
	}
	
	public boolean isShowEmailWarnMsg(){
		return showEmailWarnMsg;
	}
	public void setShowEmailWarnMsg(boolean val){
		showEmailWarnMsg=val;
	}
	public boolean isShowSecQuestionBasedonSharedEmail() {
		return showSecQuestionBasedonSharedEmail;
	}

	public void setShowSecQuestionBasedonSharedEmail(
			boolean showSecQuestionBasedonSharedEmail) {
		this.showSecQuestionBasedonSharedEmail = showSecQuestionBasedonSharedEmail;
	}
	public boolean isShowSecQuestionBasedonSharedEmailDynamic() {
		return showSecQuestionBasedonSharedEmailDynamic;
	}

	public void setShowSecQuestionBasedonSharedEmailDynamic(
			boolean val) {
		this.showSecQuestionBasedonSharedEmailDynamic = val;
	}
	public boolean isShowSuggestionMsg() {
		return showSuggestionMsg;
	}

	public void setShowSuggestionMsg(
			boolean val) {
		showSuggestionMsg = val;
	}
	
	
	
	public String getValidationEmailVerificationErrorMsg() {
		return validationEmailVerificationErrorMsg;
	}
	public boolean isEmailMandatory() {
		return emailMandatory;
	}
	public void setEmailMandatory(boolean emailMandatory) {
		this.emailMandatory = emailMandatory;
	}
	public boolean isEmailShared() {
		return emailShared;
	}

	public void setEmailShared(boolean emailShared) {
		this.emailShared = emailShared;
	}
	public String getTierEmailMsg(){
		return tierEmailMsg;
	}
	public void setTierEmailMsg(String val){
		tierEmailMsg=val;
	}
	
	public void setValidationEmailVerificationErrorMsg(
			String validationEmailVerificationErrorMsg) {
		this.validationEmailVerificationErrorMsg = validationEmailVerificationErrorMsg;
	}

	public String getEmailVerificationCodeErrorMessage() {
		return emailVerificationCodeErrorMessage;
	}

	public void setEmailVerificationCodeErrorMessage(
			String emailVerificationCodeErrorMessage) {
		this.emailVerificationCodeErrorMessage = emailVerificationCodeErrorMessage;
	}

	public String getEmailVerificationPasswordErrorMessage() {
		return emailVerificationPasswordErrorMessage;
	}

	public void setEmailVerificationPasswordErrorMessage(
			String emailVerificationPasswordErrorMessage) {
		this.emailVerificationPasswordErrorMessage = emailVerificationPasswordErrorMessage;
	}
	
	public String getTermsConditionErrorMessage() {
		return termsConditionErrorMessage;
	}

	public void setTermsConditionErrorMessage(String termsConditionErrorMessage) {
		this.termsConditionErrorMessage = termsConditionErrorMessage;
	}

	public String getValidationSecurityErrorMsg() {
		return validationSecurityErrorMsg;
	}

	public void setValidationSecurityErrorMsg(String validationSecurityErrorMsg) {
		this.validationSecurityErrorMsg = validationSecurityErrorMsg;
	}
	
	
	public String getSecQuestionOneErrorMessage() {
		return secQuestionOneErrorMessage;
	}

	public void setSecQuestionOneErrorMessage(String secQuestionOneErrorMessage) {
		this.secQuestionOneErrorMessage = secQuestionOneErrorMessage;
	}

	public String getSecAnswerOneErrorMessage() {
		return secAnswerOneErrorMessage;
	}

	public void setSecAnswerOneErrorMessage(String secAnswerOneErrorMessage) {
		this.secAnswerOneErrorMessage = secAnswerOneErrorMessage;
	}

	public String getSecQuestionTwoErrorMessage() {
		return secQuestionTwoErrorMessage;
	}

	public void setSecQuestionTwoErrorMessage(String secQuestionTwoErrorMessage) {
		this.secQuestionTwoErrorMessage = secQuestionTwoErrorMessage;
	}

	public String getSecAnswerTwoErrorMessage() {
		return secAnswerTwoErrorMessage;
	}

	public void setSecAnswerTwoErrorMessage(String secAnswerTwoErrorMessage) {
		this.secAnswerTwoErrorMessage = secAnswerTwoErrorMessage;
	}

	public String getSecQuestionThreeErrorMessage() {
		return secQuestionThreeErrorMessage;
	}

	public void setSecQuestionThreeErrorMessage(String secQuestionThreeErrorMessage) {
		this.secQuestionThreeErrorMessage = secQuestionThreeErrorMessage;
	}

	public String getSecAnswerThreeErrorMessage() {
		return secAnswerThreeErrorMessage;
	}

	public void setSecAnswerThreeErrorMessage(String secAnswerThreeErrorMessage) {
		this.secAnswerThreeErrorMessage = secAnswerThreeErrorMessage;
	}

	public String getUserNameErrorMessage() {
		return userNameErrorMessage;
	}

	/**
	 * @return the coppaValidationReqd
	 */
	public boolean isCoppaValidationReqd() {
		return coppaValidationReqd;
	}

	/**
	 * @param coppaValidationReqd the coppaValidationReqd to set
	 */
	public void setCoppaValidationReqd(boolean coppaValidationReqd) {
		this.coppaValidationReqd = coppaValidationReqd;
	}

	public void setUserNameErrorMessage(String userNameErrorMessage) {
		this.userNameErrorMessage = userNameErrorMessage;
	}

	public String getValidationPersonalErrorMsg() {
		return validationPersonalErrorMsg;
	}
	public void setValidationPersonalErrorMsg(String validationPersonalErrorMsg) {
		this.validationPersonalErrorMsg = validationPersonalErrorMsg;
	}
	public void setValidationPersonalErrorMsg2(String validationPersonalErrorMsg2) {
		this.validationPersonalErrorMsg2 = validationPersonalErrorMsg2;
	}
	public String getValidationPersonalErrorMsg2() {
		return validationPersonalErrorMsg2;
	}

	
	public String getPasswordErrorMessage() {
		return passwordErrorMessage;
	}

	public void setPasswordErrorMessage(String passwordErrorMessage) {
		this.passwordErrorMessage = passwordErrorMessage;
	}

	public String getConfirmPasswordErrorMessage() {
		return confirmPasswordErrorMessage;
	}

	public void setConfirmPasswordErrorMessage(String confirmPasswordErrorMessage) {
		this.confirmPasswordErrorMessage = confirmPasswordErrorMessage;
	}

	
	public String getEmailErrorMessage() {
		return emailErrorMessage;
	}

	public void setEmailErrorMessage(String emailErrorMessage) {
		this.emailErrorMessage = emailErrorMessage;
	}

	public String getConfirmEmailErrorMessage() {
		return confirmEmailErrorMessage;
	}

	public void setConfirmEmailErrorMessage(String confirmEmailErrorMessage) {
		this.confirmEmailErrorMessage = confirmEmailErrorMessage;
	}

    public String getFirstNameErrorMessage() {
		return firstNameErrorMessage;
	}

	public void setFirstNameErrorMessage(String firstNameErrorMessage) {
		this.firstNameErrorMessage = firstNameErrorMessage;
	}

	public String getLastNameErrorMessage() {
		return lastNameErrorMessage;
	}

	public void setLastNameErrorMessage(String lastNameErrorMessage) {
		this.lastNameErrorMessage = lastNameErrorMessage;
	}

	public String getMiddleNameErrorMessage() {
		return middleNameErrorMessage;
	}
    private String middleNameErrorMessage;
	public void setMiddleNameErrorMessage(String middleNameErrorMessage) {
		this.middleNameErrorMessage = middleNameErrorMessage;
	}
	
	
	public boolean isShowDob() {
		return showDob;
	}

	public void setShowDob(boolean showDob) {
		this.showDob = showDob;
	}

	public boolean isShowQuestions() {
		return showQuestions;
	}

	public void setShowQuestions(boolean showQuestions) {
		this.showQuestions = showQuestions;
	}

	private boolean showDob = false;
    private boolean showQuestions = true;

	public String getEmailExistsMsgSec() {
		return emailExistsMsgSec;
	}

	public void setEmailExistsMsgSec(String emailExistsMsgSec) {
		this.emailExistsMsgSec = emailExistsMsgSec;
	}

	public boolean getRelyingApp() {
		return relyingApp;
	}

	public SecurityQuestionsBean getTbSecurityQuestionsBean() {
		return tbSecurityQuestionsBean;
	}

	public void setTbSecurityQuestionsBean(
			SecurityQuestionsBean tbSecurityQuestionsBean) {
		this.tbSecurityQuestionsBean = tbSecurityQuestionsBean;
	}

	public EmailConfirmationBean getEmailConfirmationBean() {
		return emailConfirmationBean;
	}

	public void setEmailConfirmationBean(EmailConfirmationBean emailConfirmationBean) {
		this.emailConfirmationBean = emailConfirmationBean;
	}
	
	public String getCurrentActiveItem() {
		return currentActiveItem;
	}

	public void setCurrentActiveItem(String currentActiveItem) {
		this.currentActiveItem = currentActiveItem;
	}

	public String getCurrentButtonId() {
		return currentButtonId;
	}

	public void setCurrentButtonId(String currentButtonId) {
		this.currentButtonId = currentButtonId;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public String getConfirmEmailAddress() {
		return confirmEmailAddress;
	}

	public void setConfirmEmailAddress(String confirmEmailAddress) {
		this.confirmEmailAddress = confirmEmailAddress;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public List<String> getUserNameSuggestionsList() {
		return userNameSuggestionsList;
	}

	public void setUserNameSuggestionsList(List<String> userNameSuggestionsList) {
		this.userNameSuggestionsList = userNameSuggestionsList;
	}

	public List<String> getOldUsernameSuggestionsList() {
		return oldUsernameSuggestionsList;
	}

	public void setOldUsernameSuggestionsList(
			List<String> oldUsernameSuggestionsList) {
		this.oldUsernameSuggestionsList = oldUsernameSuggestionsList;
	}

	public boolean isShowSugestions() {
		return showSugestions;
	}

	public void setShowSugestions(boolean showSugestions) {
		this.showSugestions = showSugestions;
	}

	public boolean isShowEmail() {
		return showEmail;
	}

	public void setShowEmail(boolean showEmail) {
		this.showEmail = showEmail;
	}

	public String getEmailExistsMsg() {
		return emailExistsMsg;
	}

	public void setEmailExistsMsg(String emailExistsMsg) {
		this.emailExistsMsg = emailExistsMsg;
	}

	public String getPasswordStrength() {
		return passwordStrength;
	}

	public void setPasswordStrength(String passwordStrength) {
		this.passwordStrength = passwordStrength;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getPersonalInfoErrorMsg() {
		return personalInfoErrorMsg;
	}

	public void setPersonalInfoErrorMsg(String personalInfoErrorMsg) {
		this.personalInfoErrorMsg = personalInfoErrorMsg;
	}

	public String getTempUserName() {
		return tempUserName;
	}

	public void setTempUserName(String tempUserName) {
		this.tempUserName = tempUserName;
	}

	public boolean isEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public String getInvtnCode() {
		return invitationCode;
	}

	public void setInvtnCode(String invitationCode) {
		this.invitationCode = invitationCode;
	}
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@SuppressWarnings("restriction")
	@PostConstruct
	public void init() {
		// Check if local environment.
		if (TBUtil.isLocalEnv()) {
			localenv = "true";
		}
		//clrSessFlags();
		addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, 
				HttpUtils.addParameterToURL(targetUrl, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, 
						TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE)); // Add default URL always with default alias
		addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE);
		
		//String registrationSuccessFlag = getSessionAttribute("registrationSuccess").toString();
		if(getSessionAttribute("registrationSuccess") != null ){
			
			setRegistrationSuccessMsg("true");
			
			removeSessionAttribute("registrationSuccess");
		}
		
		setCurrentActiveItem("personalInformation");
		
		try {
			
			ChallengeQuestionServiceResponse challengeQuestionServiceResponse = getContainer().getConfigService().getSecurityQuestions();
			tbSecurityQuestionsBean.setQuestions(challengeQuestionServiceResponse.getUserChallengeQuestions());
			logger.debug("Challenge quetions size from web service: " + tbSecurityQuestionsBean.getQuestions().size());
					
			String emailCodeFromReqParam = getRequestParameter("VerifyEmailCode");
	
			if (!StringUtils.isEmpty(emailCodeFromReqParam)) {
				emailConfirmationBean.setEmailVerificationCode(emailCodeFromReqParam);
				if(getRequestParameter(TrustBrokerWebAppConstants.INBOUND_SSO) != null){
					addSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO,
							container.getCryptAgentUtil().getCryptAgent().decrypt(getRequestParameter(TrustBrokerWebAppConstants.INBOUND_SSO), true));
				}
				
				processVerificationDetails();
			}
	
			if(getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null && getRequestParameter("relyingAppId") != null){
				captureRelyingPartyInfo(getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);	
				processRPreg();
			}
			
			// gtyagi1: Check for Sso Broker request!
			if ( SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
				captureDetailsFromSsoContext();
			}
	
			if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM) != null &&
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM) != null &&
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL) != null){
				if(getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null && getRequestParameter("relyingAppId") != null){
	
					emailId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL).toString();
					userVO.setEmailAddress(emailId);
					userVO.setFirstName(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM).toString());
					userVO.setLastName(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM).toString());
					setConfirmEmailAddress(emailId);
					//Inbound SSO Change for Registration.
					if(getSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO) == null ) {
						relyingApp=true;
					}
				}
			}
			
			if(getRequestParameter(TrustBrokerWebAppConstants.INVITATION) != null){
				String invitation = getRequestParameter(TrustBrokerWebAppConstants.INVITATION);
				Map<String, String> invitationMap = null;
				try {
					invitationMap = container.getInvitationService().decodeInvitationDetails(invitation);
				}
				catch (OperationFailedException ofe) {
					logger.error("exception while decryption invitation code", ofe);
					setDecryptionfailed(true);
					ErrorMessage errorMessageObj = ofe.getErrorMessage();
					setErrorMsg(errorMessageObj.getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo()));
					return;
				}
				if (null != invitationMap)
					captureInvitationInfo(invitationMap);
				processRPreg();
			}
			validateNameFields();
			
		} catch(OperationFailedException ope) {
			logger.error("Exception while initialization user registratio bean: " + ope);
			String errMsg = extractErrorMessageFromOFE(ope);
			setErrorMsg(errMsg);
		}

	}

	private void processVerificationDetails(){
		if (StringUtils.isNotEmpty(getRequestParameter(TrustBrokerConstants.VERIFICATION_DETAILS))){
			SupportContactInfoVO sci = getSupportContactInfo();
			try {
				verificationDetails = container.getCryptAgentUtil().getCryptAgent().getAttributesFromToken(
						getRequestParameter(TrustBrokerConstants.VERIFICATION_DETAILS), true);
				boolean response = container.getUserService().isEmailVerified(verificationDetails.get(TrustBrokerWebAppConstants.KEY_USER_UUID), 
						verificationDetails.get(TrustBrokerWebAppConstants.KEY_USER_EMAIL));
				if (response){
					setErrorMsg(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00A008).getEndUserMessage(
							container.getErrorMessageSource(), sci));
					setEmailVerified(true);
					showContinue = true;
				}
			}
			catch (OperationFailedException ofe) {
				setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(
						container.getErrorMessageSource(), sci) : ofe.getMessage());
				emailConfirmationBean.setEmailVerificationCode(null);
				disableEmailCode = false;
			}
		}
	}
	/**
	 * gtyagi1: Method captures details from SsoContext to pre-populate 
	 * UserVo from SsoContext
	 */
	private void captureDetailsFromSsoContext() {
		
		ApplicationContext appCtx = ApplicationContextHolder.getContext();
		if ( appCtx != null ) {
			SsoContext ssoContext = appCtx.retrieve(SsoContext.class);
			if ( ssoContext != null ) {
				try {
					container.getSsoContextUserVoDataConverter().convert(ssoContext, userVO);
					// gtyagi1: confirm primary email must match original value
					this.confirmEmailAddress = userVO.getEmailAddress();
				}
				catch ( Exception ex ) {
					// gtyagi1: let's not break the UX because of conversion issue, not a big deal as it stands
					logger.error("Exception occured (will be swallowed) in populating user from SsoContext, details - \n{}", ex);
				}
			}
			else {
				logger.error("No SsoContext found!");
			}
		}
		else {
			logger.error("No ApplicationContext found");
		}
	}

	
	/* Validation for Personal Information */
	
	public boolean validatePersonalInformation() {
		boolean result = true;
		
		clearValidationMessages();
		String summaryLog="";

		if (userVO.getFirstName().equals("")) {
			setFirstNameErrorMessage("First Name is Required");
			setValidationPersonalErrorMsg("Yes");
			summaryLog+="  First Name is Required";
			result = false;
		} else {
			boolean resultFirstName = TBUtil
					.validateName(userVO.getFirstName());
			if (!resultFirstName) {
				setFirstNameErrorMessage(tbResources.getString("numericSpecialCharMsg"));
				setValidationPersonalErrorMsg("Yes");
				summaryLog+="  first name invalid";
				result = false;
			}
			
		
		}

		if (userVO.getLastName().equals("")) {

			setLastNameErrorMessage("Last Name is Required");
			setValidationPersonalErrorMsg("Yes");
			summaryLog+="  last name required";
			result = false;
		} else {
			boolean resultLastName = TBUtil.validateName(userVO.getLastName());
			if (!resultLastName) {
				/*addFacesMessage("userRegistrationId:lastNameErrorMessage",
						tbResources.getString("lastnumericSpecialCharMsg"));*/
				setLastNameErrorMessage(tbResources.getString("lastnumericSpecialCharMsg"));
				setValidationPersonalErrorMsg("Yes");
				summaryLog+="  last name invalid";
				result = false;
			}
			
		
		}
		boolean resultMiddleName = TBUtil.validateName(userVO.getMiddleName());
		if(!resultMiddleName){
			logger.debug("validatePersonalInformation() resultMiddleName: "+resultMiddleName);
			setMiddleNameErrorMessage(tbResources.getString("middlenumericSpecialCharMsg"));
			setValidationPersonalErrorMsg("Yes");
			
			summaryLog+="resultMiddleName "+resultMiddleName;
			result=false;
		}
		
		boolean isEmailFieldsValidated = validateEmailFields();
		logger.debug("validatePersonalInformation() isEmailFieldsValidated: "+isEmailFieldsValidated);
		summaryLog+="emailFieldsValid "+isEmailFieldsValidated;
		
		if(!isEmailFieldsValidated)
			result=false;
	



	if(showDob)
	{
		boolean isDateValid = true;
		
		if(StringUtils.isNotBlank(dateOfBirth))
		{
			isDateValid = DateUtil.validateDate(dateOfBirth);
		
		if (!isDateValid) {
			  setDobErrorMessage(tbResources.getString("dobFormatErrorMsg"));
			  setValidationPersonalErrorMsg("Yes");
			  summaryLog+="  dob not valid";
			  result = false;
		} else if (StringUtils.isNotBlank(dateOfBirth)) {
			int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance()
					.getPortalConfigValue("userMinAgeLimit"));
			userVO.setDob(DateUtil.parseDate(dateOfBirth, DateUtil.EXT_DATE_FORMAT));
			boolean isLimitStillValid=checkYearOfBirthEntryLimit();
			if(isLimitStillValid){
				SimpleDateFormat dobFormat = new SimpleDateFormat(DateUtil.EXT_DATE_FORMAT);
			    Integer ageDifference = DateUtil.validateAge(dateOfBirth, minAgeLimit,dobFormat);
			    //if (DateUtil.validateAge(dateOfBirth, minAgeLimit)) {
				if (ageDifference != DateUtil.OVERAGE) {
					if(isCoppaValidationReqd())
					{
						incrementIncorrectYobCount();
					}
				   isLimitStillValid=checkYearOfBirthEntryLimit();
				   if(isLimitStillValid){
					   if(ageDifference == DateUtil.OVERAGEEXEEDED)
					   {
						   setDobErrorMessage(tbResources.getString("dobAgeConstraintOverMsg"));
						   setValidationPersonalErrorMsg("Yes");
						   summaryLog+="  dob iinvalid";
						   result = false;
					   }
					   else if(ageDifference == DateUtil.FUTURE)
					   {
						   setDobErrorMessage(tbResources.getString("dobAgeConstraintFutureMsg"));
						   setValidationPersonalErrorMsg("Yes");
						   summaryLog+="  dob iinvalid";
						   result = false;
					   }
					   else if(isCoppaValidationReqd())
					   {
							   setDobErrorMessage(tbResources.getString("dobAgeConstraintMsg"));
							   setValidationPersonalErrorMsg("Yes");
							   summaryLog+="  copa dob iinvalid";
							   result = false;
					   }
					   else
					   {
						   yobValid=true;
					   }
				   }
				   else
					   result = false;
			   }else
				  yobValid=true;
			}else
				result=false;
		}
		}
		else{
			
			 	setDobErrorMessage("Date of birth is required");
				setValidationPersonalErrorMsg("Yes");
				summaryLog+="  dob required";
				result = false;
		}
	}
	else if(isCoppaValidationReqd())
	{
		boolean isYearOfBirthValid = validateYearOfBirth();
		if(isYearOfBirthValid)
			yobValid=true;
		else{
			summaryLog+="  yob invalid";
			result=false;
		}
	}
		
		// check box validation
		//if(!showQuestions && !showSecQuestionBasedonSharedEmail){
			
		//if(!validateTermsAndCondition()){
		//	summaryLog+="  terma and conds not valid";
		//	 result = false;
		//}
		//}
		logger.debug("Is Personal Information validated: " + result);
		logger.debug(" summary persoanl inforamtion validation log: "+summaryLog);
		
		personalInfoValid=result;
		
		return result;
	}

	
	
	
	
	
	private boolean checkPwdContent(){
		boolean passwordpass = true;
		 HashMap validatePwdMap = TrustbrokerWebAppUtil.validatePwdContent(userVO);
		 	if (userVO.getPassword().contains(PWD_INVALID_SPL_CHAR)) {
				setPasswordErrorMessage(tbResources.getString("pwdSplCharErrMasg"));
				passwordpass = false;
			}
			if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME)) {
				setPasswordErrorMessage((String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME));
				setValidationPersonalErrorMsg("Yes");
				passwordpass=false;
			}
			if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE)) {
				setPasswordErrorMessage((String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE));
				passwordpass=false;
			}
			
			return passwordpass;
	}
	
	
	public void inspectEmailAddress(ValueChangeEvent event) {
		emailExistsMsg = "";
		showEmail = false;
		showSuggestionMsg=false;
		
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			verifyEmailAddress(event.getNewValue().toString());
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean result = TBUtil.validateEmailId(event.getNewValue()
					.toString());
			logger.debug("result value in email: " + result);
			if (!result) {
				addFacesMessage("userRegistrationId:email",
						tbResources.getString("invalidEmailAddress"));
			}
		}
		logger.debug("inspectEmailAddress()- getEmailExistsMsg(): " + getEmailExistsMsg());
	}
	
	
	private void clrSessFlags(){
		removeSessionAttribute("dynShowSecQues");
		removeSessionAttribute("warnmsg");
		removeSessionAttribute("emWarnGsg2");
		//showSecQuestionBasedonSharedEmail=false;
	}
	
	public boolean verifyEmailAddress(String email) {
		boolean result = true;
		String rpName ="";
		clrSessFlags();
		//showSecQuestionBasedonSharedEmailDynamic=false;
		showEmailWarnMsg=false;
		
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_NAME)!=null)
			rpName = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_NAME).toString();
			
		if (isEmailMandatory()) {

			if (StringUtils.isEmpty(email)) {
				addFacesMessage("userRegistrationId:email",	tbResources.getString("ifBlnkReqUniqEmOrShrMsg"));
				//addFacesMessage("userRegistrationId:email",	tbResources.getString("rpDoNotSupportEmptyEmail"));
				result = false;
			} else if (!TBUtil.validateEmailId(email)) {
				addFacesMessage("userRegistrationId:email",
						tbResources.getString("invalidEmailAddress"));
				result = false;
			} else if (!isEmailShared()
					&& container.getUserService().isEmailExists(email)) {
				showEmail = true;
				addFacesMessage("userRegistrationId:email",
						tbResources.getString("ifShrEmNotSupMsg"));
				addSessionAttribute("emWarnGsg2",true);
				//logger.debug(" share not supported and is share");
				result = false;

			}
			else if(isEmailShared()&& container.getUserService().isEmailExists(email))
			{
				//addFacesMessage("userRegistrationId:email",
				//		tbResources.getString("ifShrEmSupMsg"));
				addSessionAttribute("warnmsg", true);
				//showEmailWarnMsg=true;
				showSecQuestionBasedonSharedEmailDynamic=true;
				addSessionAttribute("dynShowSecQues",true);
					
			}
				 if(StringUtils.isNotEmpty(email) && !container.getUserService().isEmailExists(email))
			{
				//addFacesMessage("userRegistrationId:email",
				//		tbResources.getString("ifShrEmSupMsg"));
				//addSessionAttribute("warnmsg", true);
				//showEmailWarnMsg=true;
				showSecQuestionBasedonSharedEmailDynamic=false;
				//addSessionAttribute("dynShowSecQues",true);
				//logger.debug("show sec based on email true 2 not mandatory and shared allowed and is a shared");
			}
			if (StringUtils.isEmpty(getConfirmEmailAddress())) {
				//addFacesMessage("userRegistrationId:confirmEmail",	tbResources.getString("confirmEmailRequired"));
				setConfirmEmailErrorMessage(tbResources.getString("confirmEmailRequired"));
				result = false;
			} 
			
		} else {// not mandatory email
			if (!isEmailShared()) {
				if (!TBUtil.validateEmailId(email)) {
					addFacesMessage("userRegistrationId:email",
							tbResources.getString("invalidEmailAddress"));
					result = false;
					
				} else if (!StringUtils.isEmpty(email)
						&& container.getUserService().isEmailExists(email)) {
					showEmail = true;
					addFacesMessage("userRegistrationId:email",
							tbResources.getString("ifShrEmNotSupMsg"));
							//tbResources.getString("rpDoNotDuplicateNonMandatoryEmail"));
					addSessionAttribute("emWarnGsg2",true);
					//logger.debug(" share not supported and is share");
					result = false;
				}

			}else {//  not mandatory and isShared
				
			 if (!TBUtil.validateEmailId(email)) {
					addFacesMessage("userRegistrationId:email",
							tbResources.getString("invalidEmailAddress"));
					result = false;
				}
				
			if(email != null && email!= "" && container.getUserService().isEmailExists(email))
			{
				//addFacesMessage("userRegistrationId:email",
				//		tbResources.getString("ifShrEmSupMsg"));
				addSessionAttribute("warnmsg", true);
				//showEmailWarnMsg=true;
				showSecQuestionBasedonSharedEmailDynamic=true;
				addSessionAttribute("dynShowSecQues",true);
				//logger.debug("show sec based on email true 2 not mandatory and shared allowed and is a shared");
			}
			
			if(StringUtils.isEmpty(email)) {
				showSecQuestionBasedonSharedEmailDynamic=true;
			}

		  }
			
			 /* if(StringUtils.isEmpty(email) && !showQuestions && !showSecQuestionBasedonSharedEmail && !showSecQuestionBasedonSharedEmailDynamic && !result && !showEmailWarnMsg){
					showSuggestionMsg=true;
			  }*/
			
		  if(StringUtils.isEmpty(email) && !showQuestions  && !showSecQuestionBasedonSharedEmailDynamic && !result && !showEmailWarnMsg){
				showSuggestionMsg=true;
		  }
		  logger.debug("showSuggestionMsg not mandatory: "+showSuggestionMsg+" showQuestions: "+showQuestions+" showSecQuestionBasedonSharedEmail "+showSecQuestionBasedonSharedEmail+" showEmailWarnMsg "+showEmailWarnMsg);
			
		}
		 
		// This validation is for displaying the error message for SQ after hide and display
		//validateSecurityAnswersForSharedEmail("");
		 logger.debug("showSuggestionMsg: "+showSuggestionMsg+" email:"+email+":");
		
		 if(!showQuestions ){
			 
			 if(showSecQuestionBasedonSharedEmail){
				 
				 if(StringUtils.isEmpty(email)){
					 // blank email
					 showSecQuestionBasedonSharedEmailDynamic = true;
				 }else if(StringUtils.isNotEmpty(email) && !container.getUserService().isEmailExists(email)){
					// Unique  email
					 showSecQuestionBasedonSharedEmailDynamic = false;
				 }else if(StringUtils.isNotEmpty(email) && container.getUserService().isEmailExists(email)){
					// Shared email
					 showSecQuestionBasedonSharedEmailDynamic = true;
				 }
				 
				 
				 
			 }
		 }
		
		 
		 
		
		return result;

	}
	
	
	
	
	
	private void addFacesMessage(String fieldId, String message) {
	    getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	public boolean registerUser() {

		// Validation Form Fields
		boolean isSecurityAnswersValidated = false;
				
		if(tbSecurityQuestionsBean.getSecurityQuestionOne()==null && tbSecurityQuestionsBean.getSecurityQuestionTwo()==null && tbSecurityQuestionsBean.getSecurityQuestionThree()==null)
		{	
			isSecurityAnswersValidated = true;
		}
		else
		{
			isSecurityAnswersValidated = validateSecurityAnswers();
		}
		//boolean isUserNameValidated = validateUserName(userVO.getUserName());
		boolean isTermsAndConditionValidated=validateTermsAndCondition();
		/*return isNameFieldsValidated && isEmailFieldsValidated && isPwdFieldsValidated
				&& isSecurityAnswersValidated && isUserNameValidated && isTermsAndConditionValidated;*/
		
		return isSecurityAnswersValidated && isTermsAndConditionValidated;
	}

	private boolean validateTermsAndCondition() {
		boolean retVal=true;
		setTermsConditionErrorMessage("");
		String termsCondition = userVO.getTermsCondition();
		if(termsCondition.equals("off")){
			//addFacesMessage("userRegistrationId:tcChkBox1",tbResources.getString("termsAndConditions"));
			setTermsConditionErrorMessage(tbResources.getString("termsAndConditions"));
			setValidationSecurityErrorMsg("Yes");
			retVal=false;
		}
		
		return retVal;
	}
	
	private boolean validateSecurityAnswers() {
		
		
		setSecQuestionOneErrorMessage("");
		setSecQuestionTwoErrorMessage("");
		setSecQuestionThreeErrorMessage("");
		setSecAnswerOneErrorMessage("");
		setSecAnswerTwoErrorMessage("");
		setSecAnswerThreeErrorMessage("");
		
		
		String sameAnswer = "";
		boolean retVal = true;

		String answerOne = tbSecurityQuestionsBean.getSecurityAnswerOne();
		String answerTwo = tbSecurityQuestionsBean.getSecurityAnswerTwo();
		String answerThree = tbSecurityQuestionsBean.getSecurityAnswerThree();
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion3 = tbSecurityQuestionsBean.getSecurityQuestionThree();

		if (secQuestion1.equals("null") || secQuestion1.length() == 4) {
			//addFacesMessage("userRegistrationId:securityQuestionOne", tbResources.getString("secQuestion1"));
			setSecQuestionOneErrorMessage("Security Question 1 is required");
			setValidationSecurityErrorMsg("Yes");
			retVal = false;
		}

		if (secQuestion2.equals("null") || secQuestion2.length() == 4) {
			//addFacesMessage("userRegistrationId:securityQuestionTwo", tbResources.getString("secQuestion2"));
			setSecQuestionTwoErrorMessage("Security Question 2 is required");
			setValidationSecurityErrorMsg("Yes");
			retVal = false;
		}

		if (secQuestion3.equals("null") || secQuestion3.length() == 4) {
			//addFacesMessage("userRegistrationId:securityQuestionThree", tbResources.getString("secQuestion3"));
			setSecQuestionThreeErrorMessage("Security Question 3 is required");
			setValidationSecurityErrorMsg("Yes");
			retVal = false;

		}

		

		
		
		if("".equals(answerOne)){
			setSecAnswerOneErrorMessage("Security Answer 1 is required");
			setValidationSecurityErrorMsg("Yes");
			retVal = false;
		}
		if("".equals(answerTwo)){
			setSecAnswerTwoErrorMessage("Security Answer 2 is required");
			setValidationSecurityErrorMsg("Yes");
			retVal = false;
		}
		if("".equals(answerThree)){
			setSecAnswerThreeErrorMessage("Security Answer 3 is required");
			setValidationSecurityErrorMsg("Yes");
			retVal = false;
		}
		
		if (answerOne.equalsIgnoreCase(answerTwo) && answerOne.equalsIgnoreCase(answerThree))
			sameAnswer = answerOne;
		//if (answerTwo.equalsIgnoreCase(answerThree))
		//	sameAnswer = answerTwo;
		
		if (!"".equals(sameAnswer)) {

			if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase()) && sameAnswer.equalsIgnoreCase(answerOne)) {
				//addFacesMessage("userRegistrationId:securityAnswerOne", tbResources.getString("secAnswerRules"));
				setSecAnswerOneErrorMessage(tbResources.getString("secAnswerRules"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

			if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase()) && sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userRegistrationId:securityAnswerTwo", tbResources.getString("secAnswerRules"));
				setSecAnswerTwoErrorMessage(tbResources.getString("secAnswerRules"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

			if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())
					&& sameAnswer.equalsIgnoreCase(answerThree)) {
				//addFacesMessage("userRegistrationId:securityAnswerThree", tbResources.getString("secAnswerRules"));
				setSecAnswerThreeErrorMessage(tbResources.getString("secAnswerRules"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

			if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase())) {
				/*addFacesMessage("userRegistrationId:securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));*/
				setSecAnswerOneErrorMessage(tbResources.getString("secAnswermustnotContainsText"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

			if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase())) {
				/*addFacesMessage("userRegistrationId:securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));*/
				setSecAnswerTwoErrorMessage(tbResources.getString("secAnswermustnotContainsText"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

			if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())) {
				/*ddFacesMessage("userRegistrationId:securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));*/
				setSecAnswerThreeErrorMessage(tbResources.getString("secAnswermustnotContainsText"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerOne)) {
				//addFacesMessage("userRegistrationId:securityAnswerOne", tbResources.getString("uniqueSecAnsMsg"));
				setSecAnswerOneErrorMessage(tbResources.getString("uniqueSecAnsMsg1"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerTwo)) {
				//addFacesMessage("userRegistrationId:securityAnswerTwo", tbResources.getString("uniqueSecAnsMsg"));
				setSecAnswerTwoErrorMessage(tbResources.getString("uniqueSecAnsMsg1"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerThree)) {
				//addFacesMessage("userRegistrationId:securityAnswerThree", tbResources.getString("uniqueSecAnsMsg"));
				setSecAnswerThreeErrorMessage(tbResources.getString("uniqueSecAnsMsg1"));
				setValidationSecurityErrorMsg("Yes");
				retVal = false;
			}

		} else {
			
			
			if(!secQuestion1.toLowerCase().equals("null") && !answerOne.toLowerCase().isEmpty()){
				
				if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase())) {
					setSecAnswerOneErrorMessage(tbResources.getString("secAnswermustnotContainsText"));
					setValidationSecurityErrorMsg("Yes");
					retVal = false;
				}	
				
			}
			
			
if(!secQuestion2.toLowerCase().equals("null") && !answerTwo.toLowerCase().isEmpty()){
				
				
	if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase())) {
		setSecAnswerTwoErrorMessage(tbResources.getString("secAnswermustnotContainsText"));
		setValidationSecurityErrorMsg("Yes");
		retVal = false;
	}
	
	
			}
if(!secQuestion3.toLowerCase().equals("null") && !answerThree.toLowerCase().isEmpty()){
	
	if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())) {
		setSecAnswerThreeErrorMessage(tbResources.getString("secAnswermustnotContainsText"));
		setValidationSecurityErrorMsg("Yes");
		retVal = false;
	}
}		

			
		}
		
		if(!TBUtil.validateSecurityAnswer(answerOne)){
			//retVal = false;
			//addFacesMessage("userRegistrationId:securityAnswerOne", tbResources.getString("obsceneTextInAnswer"));
			setSecAnswerOneErrorMessage(tbResources.getString("obsceneTextInAnswer"));
			setValidationSecurityErrorMsg("Yes");
			retVal = false;
		}
		
		if(!TBUtil.validateSecurityAnswer(answerTwo)){
			//retVal = false;
			//addFacesMessage("userRegistrationId:securityAnswerTwo", tbResources.getString("obsceneTextInAnswer"));
			setSecAnswerTwoErrorMessage(tbResources.getString("obsceneTextInAnswer"));
			setValidationSecurityErrorMsg("Yes");
			retVal = false;
		}
		
		if(!TBUtil.validateSecurityAnswer(answerThree)){
			
			//addFacesMessage("userRegistrationId:securityAnswerThree", tbResources.getString("obsceneTextInAnswer"));
			setSecAnswerThreeErrorMessage(tbResources.getString("obsceneTextInAnswer"));
			setValidationSecurityErrorMsg("Yes");
			retVal = false;
		}

		return retVal;
	}

	private boolean validatePasswordFields() {
		boolean result = true;
		
		if (!userVO.getPassword().equals(getConfirmPassword())) {
			result = false;
			addFacesMessage("userRegistrationId:pwd",
					tbResources.getString("pwdDoNotMatch"));
		}
		
		if(!TBUtil.isPwdStrengthValid(userVO.getPassword())) {
			result = false;
			addFacesMessage("userRegistrationId:pwd",
					tbResources.getString("goodOrStrongPwdReq"));
		}
		
		return result;
	}
	
	

	private boolean validateEmailFields() {
	boolean result = true;
		
		String email = userVO.getEmailAddress();
		if(email != null) {
			email = email.toLowerCase();
		}
		result = verifyEmailAddress(email);
				
		if ( result && email != null && TBUtil.validateEmailId(email)
				&& !email.toLowerCase()
						.equals(getConfirmEmailAddress().toLowerCase())) {
			//addFacesMessage("userRegistrationId:confirmEmail",
			//		"Email and Confirm Email Address does not match");
			setConfirmEmailErrorMessage("Email and Confirm Email Address does not match");
					//tbResources.getString("emailDoNotMatch"));
			result = false;
		}
		
		return result;
	}
	
	
	
	
	
	
	
	public String clearAllValues(){
	
		 setCurrentActiveItem("personalInformation");
	        return "/views/userregistrationw.xhtml?faces-redirect=true";
	}
	
	public String back(){
		
		 setCurrentActiveItem("personalInformation");
	        return "/views/userregistrationw.xhtml?faces-redirect=true";
	}
	public String clearAllSecQuestionValues(){
		
		 setCurrentActiveItem("userSecurity");
	        return "/views/userregistrationw.xhtml?faces-redirect=true";
	}
	
	private boolean recoveryOptionsExist(){
		boolean exists = true;
		
		return exists;
	}

	/*
	public void personalInfoCLick(){
		//ItemChangeEvent ice = null;
		logger.debug("userRegistrationBean.personalInfoCLick() ");
		this.setCurrentButtonId("continuePersonalButton");
		//pageChanged(ice);
		
		
			logger.debug("continuePersonalButton current button id. validating PersonalIformation");
			
			if (!validatePersonalInformation()){
					userVO.setPassword("");
					userVO.setConfirmPwd("");
					setCurrentActiveItem("personalInformation");
					
					logger.debug(". continuePersonal validate false. going to "+currentActiveItem);
					return;
			}
			else { 
				setCurrentActiveItem("updateEmailConfirmation");
				
				logger.debug(". continuePersonal validate ok. going to "+currentActiveItem);
				return;
			}	
		
		
		//logger.debug("userRegistrationBean.personalInfoCLick() . currentActiveItem: "+currentActiveItem);
		
		
		//return;
	}
	*/
	
	public void pageChanged(ItemChangeEvent event) {
		
		logger.debug("userRegistrationBean.pageChanged() button: "+this.currentButtonId);

		setErrorMsg("");
		
		setRegistrationSuccessMsg("");
		
		
	if	("widgetContinueButton".equals(getCurrentButtonId())) {
        
		
		logger.debug("userRegistrationBean::Redirecting to RP Page");
		
		
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)!= null){
			redirectToRelyingParty(
					(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL),
					(String) getSessionAttribute(TrustBrokerWebAppConstants.ACTION),
					(String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS),
					(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			
			setCurrentActiveItem("personalInformation");
		}
		
	else{
		
		addSessionAttribute("registrationSuccess", "Yes");
		
		
		setCurrentActiveItem("personalInformation");
       // return "/views/userregistrationw.xhtml?faces-redirect=true";
		
		}
	
	}
	
		// This is for Widgets 
		if ("continuePersonalButton".equals(getCurrentButtonId())) {
			logger.debug("continuePersonalButton current button id. validating PersonalIformation");
			if (!validatePersonalInformation()){
					userVO.setPassword("");
					userVO.setConfirmPwd("");
					setCurrentActiveItem("personalInformation");
					return;
			}
			else {
				setCurrentActiveItem("userCredentials");
				
				
				logger.debug("pageChanged. continuePersonal validate ok. going to "+currentActiveItem);
				return;
			}	
		}
		
		if ("backButton".equals(getCurrentButtonId())) {
			logger.debug("backButton current button id. going back to personalInformation");
			setCurrentActiveItem("personalInformation");
			return;
		}
		
		if ("secQuestionBackButton".equals(getCurrentButtonId())) {
			logger.debug("secQuestionBackButton current button id. going back to userCredentials");
			setCurrentActiveItem("userCredentials");
			return;
		}

		if ("secQuestionCancelButton".equals(getCurrentButtonId())) {
			logger.debug("secQuestionCancelButton current button id. cancelling on sec quest");
			 clearSecInformationValidationMessages();
			setCurrentActiveItem("userSecurity");
			return;
		}
		
		if ("clearPersonalButton".equals(getCurrentButtonId())) {
			logger.debug("clearPersonalCancelButton clear credentials current button id. cancelling on pers info");
			userVO.setFirstName("");
			userVO.setLastName("");
			userVO.setMiddleName("");
			userVO.setEmailAddress("");
			setConfirmEmailAddress("");

			userVO.setUserName("");
			setDateOfBirth("");
			
			userVO.setPassword("");
			userVO.setConfirmPwd("");
			setMobilePhone("");
			yearOfBirth=null;
			//this.tncAccepted=false;
			clearValidationMessages();
			setCurrentActiveItem("personalInformation");
			return;
		}
		
		
		if ("continueButton".equals(getCurrentButtonId())) {
			logger.debug("continueButton current button id. continue from credentials to sec questtions");
			if (!validateCredentials()){
				setCurrentActiveItem("userCredentials");
			    userVO.setPassword("");
			    userVO.setConfirmPwd("");
			    setEmailExistsMsg("");
			    setPersonalInfoErrorMsg("");
			}else {
				
				setCurrentActiveItem("userSecurity");
				return;
			}
		}
		if ("backtoPersonalInfo".equals(getCurrentButtonId())) {
			userVO.setPassword("");
		    userVO.setConfirmPwd("");
			setCurrentActiveItem("personalInformation");
			return;
		}
		if ("cancelButton".equals(getCurrentButtonId())) {
			setCurrentActiveItem("signIn");
			return;
		}
		if ("registerButton".equals(getCurrentButtonId())) {
			if (!registerUser()){
				userVO.setPassword("");
				userVO.setConfirmPwd("");
				setCurrentActiveItem("userCredentials");
				return;
			}
			return;
		}
		
		if ("personalRegisterButton".equals(getCurrentButtonId())) {
			
			if(StringUtils.isNotEmpty(mobilePhone)){
				userVO.setPhoneNumber(mobilePhone);
			}
			if (!validatePersonalInformation()){
				userVO.setPassword("");
				userVO.setConfirmPwd("");
				setCurrentActiveItem("personalInformation");
				return;
			}else if(!validateCredentials()){
				userVO.setPassword("");
				userVO.setConfirmPwd("");
				setCurrentActiveItem("userCredentials");
			}else if(!recoveryOptionsExist()){
				userVO.setPassword("");
				userVO.setConfirmPwd("");
				setCurrentActiveItem("personalInformation");
				return;
			}else {
			    //setCurrentActiveItem("userSecurity");
			
			   UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			   userVO.setIsTncAccepted(tbResources.getString("isTncAccepted"));
			   userVO.setTncAgreementVersion(tbResources.getString("tncAgreementVersion"));
			   userVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
			   userVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));
			   if(yobValid && isCoppaValidationReqd())
			     userVO.setIsCoppaAccepted("Y");
			   else
				 userVO.setIsCoppaAccepted("N");
			   confirmnewEmailAddress = userVO.getEmailAddress();
			   if(getSessionMap().get("invitationCode")!=null){
				 userVO.setInvtnCode(invitationCode);
			   }
			
			
			
			userProfileServiceRequest.setUser(userVO);

			String confirmationUrl = constructURL("/views/registeremailconfirmation.jsf");
			String didNotRegisteredUrl = constructURL("/views/notregistered.jsf?UserId=");
			confirmationUrl = constructConfirmationUrlWithParams(userVO, confirmationUrl, false);

			userProfileServiceRequest.setConfirmationUrl(confirmationUrl);
			userProfileServiceRequest.setDidNotRegisteredUrl(didNotRegisteredUrl);
			if(tbSecurityQuestionsBean.getSecurityQuestionOne()!=null 
					&& tbSecurityQuestionsBean.getSecurityQuestionTwo()!=null 
					&& tbSecurityQuestionsBean.getSecurityQuestionThree()!=null)
			{
				
				/*if(showQuestions || showSecQuestionBasedonSharedEmail ||  showSecQuestionBasedonSharedEmailDynamic){
					   populateSecurityQuestions(userVO);
					}*/
				if(showQuestions  ||  showSecQuestionBasedonSharedEmailDynamic){
				   populateSecurityQuestions(userVO);
				}
			}
			
			userProfileServiceRequest.getUser().setRpId(getRelyingPartyApAlias(true));
			try {	
				String rpAppId = getRelyingPartyAppId();
				UserProfileServiceResponse response = container.getUserService().registerUser(userProfileServiceRequest, true,
						getVerificationCodeRequest(CommunicationChannel.PRIMARY_EMAIL, userVO, false));
				logger.debug("Status code: " + response.getExecutionStatus().getStatusCd() + " Status Message: " + 
						response.getExecutionStatus().getStatusMessage());
				SecurityLoggingUtil.info("User Registration", SecurityEventType.E3_CREATE, getServletRequest(), userVO.getUserName(),
						"Security Audit Event|RegisterUser:SUCCESS | User Registered, UserRegistrationBean:pageChanged()",
						SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_CREATE_USER);
				userVO.setUuId(response.getUser().getUuId());
				//courtesy email
				InvitationVO invitationVO = (InvitationVO) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION);
				String courtesyEmail = null;
				
				if (invitationVO != null) {
					updateUserInvitaion(response.getUser());
					courtesyEmail = invitationVO.getInvtnToEmail();
				}
				else if(StringUtils.isNotEmpty(emailId)) {
					courtesyEmail = emailId;
				}

				if (StringUtils.isNotEmpty(courtesyEmail) && !userVO.getEmailAddress().equalsIgnoreCase(courtesyEmail)) {
					container.getUserService().sendUserEmailUpdInfo(courtesyEmail, userVO, rpAppId, getUrlLogoOptumId(),
							getUrlLogoRelyingParty());
					logUserEmailUpdate(TrustBrokerWebAppConstants.REGN_EMAIL_UPD_MSG + "UserRegistrationBean.pageChanged()", 
							userVO, courtesyEmail, TrustBrokerConstants.REGN_EMAIL_UPD_ACTIVITY);
				}
				
				if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {
					//Send verification code
					sendVerificationCode();
				}
				else {
					try {
						container.getUserService().verifyChannel(CommunicationChannel.PRIMARY_EMAIL, 
								response.getEmailConfirmationCode(), "");		
					} catch(Exception e) {
						logger.error("Exception on user email auto verification: "+ e);
					}
					//setCurrentActiveItem("congratulations");
					redirectToView("/views/congratulationsw.jsf");
				}
			} catch (OperationFailedException ope) {
				logger.error("Exception during user registration on submit: " + ope);
				setErrorMsg(extractErrorMessageFromOFE(ope));				
				if(ope.getMessage().contains("User persistence failed at TB database and ESSO User deleted"))
				{
					setCurrentActiveItem("failure");
				}
				else if (ope.getMessage().contains(tbResources.getString("blackListedPasswordMsg")))
				{
					setPasswordErrorMessage(tbResources.getString("blackListedPasswordMsg"));
					setErrorMsg("");
					setCurrentActiveItem("personalInformation");
				}
				else
					setCurrentActiveItem("personalInformation");
			}
		}
		}
		
		if ("agreeButton".equals(getCurrentButtonId())) {
			
			if (!registerUser() ){
				
				setCurrentActiveItem("userSecurity");
				
			}else{
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userVO.setIsTncAccepted(tbResources.getString("isTncAccepted"));
			userVO.setTncAgreementVersion(tbResources.getString("tncAgreementVersion"));
			userVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
			userVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));
			if(yobValid && isCoppaValidationReqd())
			    userVO.setIsCoppaAccepted("Y");
			else
				userVO.setIsCoppaAccepted("N");
			confirmnewEmailAddress = userVO.getEmailAddress();
			if(getSessionMap().get("invitationCode")!=null){
				userVO.setInvtnCode(invitationCode);
			}			
			userProfileServiceRequest.setUser(userVO);

			String confirmationUrl = constructURL("/views/registeremailconfirmation.jsf");
			String didNotRegisteredUrl = constructURL("/views/notregistered.jsf?UserId=");
			confirmationUrl = constructConfirmationUrlWithParams(userVO, confirmationUrl, false);

			userProfileServiceRequest.setConfirmationUrl(confirmationUrl);
			userProfileServiceRequest.setDidNotRegisteredUrl(didNotRegisteredUrl);
			if(tbSecurityQuestionsBean.getSecurityQuestionOne()!=null 
					&& tbSecurityQuestionsBean.getSecurityQuestionTwo()!=null 
					&& tbSecurityQuestionsBean.getSecurityQuestionThree()!=null)
			{
				/*if(showQuestions || showSecQuestionBasedonSharedEmail || showSecQuestionBasedonSharedEmailDynamic){
				   populateSecurityQuestions(userVO);
				}*/
				
				if(showQuestions || showSecQuestionBasedonSharedEmailDynamic){
					   populateSecurityQuestions(userVO);
					}
			}
			
			userProfileServiceRequest.getUser().setRpId(getRelyingPartyApAlias(true));
			
			try {	
				String rpAppId = getRelyingPartyAppId();
				UserProfileServiceResponse response = container.getUserService().registerUser(userProfileServiceRequest, true,
						getVerificationCodeRequest(CommunicationChannel.PRIMARY_EMAIL, userVO, false));
				logger.debug("Status code: " + response.getExecutionStatus().getStatusCd() + " Status Message: " + 
						response.getExecutionStatus().getStatusMessage());
				SecurityLoggingUtil.info("User Registration", SecurityEventType.E3_CREATE, getServletRequest(), userVO.getUserName(),
						"Security Audit Event|RegisterUser:SUCCESS | User Registered, UserRegistrationBean:pageChanged()",
						SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_CREATE_USER);
				userVO.setUuId(response.getUser().getUuId());
				//courtesy email
				InvitationVO invitationVO = (InvitationVO) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION);
				String emailId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL);
				String courtesyEmail = null;
				
				if(invitationVO != null) {
					updateUserInvitaion(response.getUser());
					courtesyEmail = invitationVO.getInvtnToEmail();
				} else if(StringUtils.isNotEmpty(emailId)) {
					courtesyEmail = emailId;
				}
				
				
				if(StringUtils.isNotEmpty(courtesyEmail) && !userVO.getEmailAddress().equalsIgnoreCase(courtesyEmail)) {
					container.getUserService().sendUserEmailUpdInfo(courtesyEmail, userVO, rpAppId, getUrlLogoOptumId(),
							getUrlLogoRelyingParty());
					logUserEmailUpdate(TrustBrokerWebAppConstants.REGN_EMAIL_UPD_MSG+"UserRegistrationBean.pageChanged()", 
							userVO, courtesyEmail, TrustBrokerConstants.REGN_EMAIL_UPD_ACTIVITY);
				}
				
				if (TBUtil.isProdEnv() || isEmailConfirmationRequired()){
					
					if(StringUtils.isNotEmpty(userVO.getEmailAddress()) ) {	
						sendVerificationCode();
					}else{
						redirectToView("/views/congratulationsw.jsf");
					}						
				}
				if (! TBUtil.isProdEnv() &&  !isEmailConfirmationRequired()){
					redirectToView("/views/congratulationsw.jsf");
				}
				
			} catch (OperationFailedException ope) {
				logger.error("Exception during user registration on submit: " + ope);
				setErrorMsg(extractErrorMessageFromOFE(ope));				
				if(ope.getMessage().contains("User persistence failed at TB database and ESSO User deleted"))
					setCurrentActiveItem("failure");
				else
					setCurrentActiveItem("userCredentials");
			}
		}
		}
		
	}
		
	/**
	 * This method is used to send verification code and display the verification screen after registering the user.
	 * 
	 */
	private void sendVerificationCode() {
		
		VerifyCodesContext ctx = new VerifyCodesContext();
		ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
		ctx.setHideUpdateButtons(true);
		ctx.setShowDeviceRegistration(getDisplayDeviceRegistration());
		ctx.setNextView("/views/congratulationsw.jsf");
		ctx.setUserVO(userVO);
		ctx.setVerifyCodePgDimension(VerifyCodesContext.PAGE_7X3_DIMENSION);
		getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);
		redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
	}
	
	private void clearSecInformationValidationMessages(){
		
		 tbSecurityQuestionsBean.setSecurityQuestionOne("null");
		 tbSecurityQuestionsBean.setSecurityQuestionTwo("null");
		 tbSecurityQuestionsBean.setSecurityQuestionThree("null");
		 tbSecurityQuestionsBean.setSecurityAnswerOne("");
		 tbSecurityQuestionsBean.setSecurityAnswerTwo("");
		 tbSecurityQuestionsBean.setSecurityAnswerThree("");
		 
		 setSecQuestionOneErrorMessage("");
		 setSecQuestionTwoErrorMessage("");
		 setSecQuestionThreeErrorMessage("");
		 setSecAnswerOneErrorMessage("");
		 setSecAnswerTwoErrorMessage("");
		 setSecAnswerThreeErrorMessage("");
		 setTermsConditionErrorMessage("");
		 setTncAccepted(false);
	}
	

	public void checkmiddleNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultMiddleName = TBUtil.validateName(userVO.getMiddleName());
			if ( !resultMiddleName) {
				setMiddleNameErrorMessage(tbResources.getString("numericSpecialCharMsg"));
				//addFacesMessage("userRegistrationId:middleName",tbResources.getString("middlenumericSpecialCharMsg"));
			}
		}
	}
	
	
	
	private void clearValidationMessages(){
			
		setFirstNameErrorMessage("");
		setLastNameErrorMessage("");
		setMiddleNameErrorMessage("");
		setEmailErrorMessage("");
		setConfirmEmailErrorMessage("");
		setUserNameErrorMessage("");
		setPasswordErrorMessage("");
		setConfirmPasswordErrorMessage("");
		setDobErrorMessage("");
		setTermsConditionErrorMessage("");
		setValidationPersonalErrorMsg("No");
		setValidationPersonalErrorMsg2("No");
	}
	
	private boolean validateConfirmEmailAddress() {
		boolean retVal=true;
		setEmailVerificationCodeErrorMessage("");
		setEmailVerificationPasswordErrorMessage("");
		
		if(StringUtils.isEmpty(getEmailConfirmationBean().getEmailVerificationCode())){
			
			setEmailVerificationCodeErrorMessage("Confirmation Code is required");
			retVal=false;
		}
		if(StringUtils.isEmpty(emailConfirmationBean.getPwd())){
			
			
				setEmailVerificationPasswordErrorMessage("Password is required");
				retVal=false;
			}
		
		
		
		/*String termsCondition = userVO.getTermsCondition();
		if(termsCondition.equals("off")){
			//addFacesMessage("userRegistrationId:tcChkBox1",tbResources.getString("termsAndConditions"));
			setTermsConditionErrorMessage(tbResources.getString("termsAndConditions"));
			setValidationSecurityErrorMsg("Yes");
			retVal=false;
		}*/
		
		return retVal;
	}
	
	/**
	 * This method is used to log audit event when an user email id is changed.
	 * 
	 * @param msg event message. 
	 * @param userVO UserVO containing user info
	 */	
	private void logUserEmailUpdate(String msg, UserVO userVO, String email, String activity){
				
		msg = "Security Audit Event|"+msg+ "## uuid: ^^"+userVO.getUuId()+"!!";
		IrmLoggingUtil.info( activity,SecurityEventType.E3_MODIFY, getServletRequest().getRemoteAddr(),
				getServletRequest().getLocalAddr(),getServletRequest().getSession().getId(), 
				 userVO.getUserName(), msg, SecurityEventResult.SUCCESS, getRelyingPartyAppId(), email, "", SecuritySubEventType.E3_MODIFY_EMAIL);
	}
	
	private void addTrustedDevice(){
		if("Yes".equalsIgnoreCase(registerDevice)){
			DeviceDetails deviceDetails = new DeviceDetails();
			deviceDetails.setDevicePrint(devicePrint);
			container.getDeviceHelper().build(getServletRequest(), deviceDetails);
			AddTrusetedDeviceRequest request = new AddTrusetedDeviceRequest();
			request.setUser(userVO);
			request.setDeviceDetails(deviceDetails);
			AddTrustedDeviceResponse response = container.getUserService().addTrustedDevice(request);
			container.getSetDeviceDetailsAction().setDeviceCookie(getServletRequest(), getServletResponse(), response.getDeviceTokenCookie());
			container.getSetDeviceDetailsAction().setFSOToken(getServletRequest(), TrustbrokerWebAppUtil.encodeURL(response.getDeviceTokenFSO()));
		}
	}

	protected void checkRelyingPartyTrust(){
		
		if (isSessionAttributeExists(TrustBrokerWebAppConstants.RELYING_APP_ID)) {

			String relyingAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString();
			RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
			
			logger.debug("relyingPartyApp: " + relyingPartyAppVO);

			if (relyingPartyAppVO == null) {
				relyinPartyTrusted = false;
				relyingAppTrustErrorMessage = tbResources.getString("invalidRelyingAppMsg");
			}
			else if (isSessionAttributeExists(TrustBrokerWebAppConstants.RELYING_APP_URL)) {
				addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
				try {
					String rpDomainName = TBUtil.getDomainName(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL).toString());
					boolean isdomainValid=false;
					if(relyingPartyAppVO.getRpAppDomains()!=null&&relyingPartyAppVO.getRpAppDomains().size()>0)
						isdomainValid=isDomainValid(relyingPartyAppVO.getRpAppDomains(),rpDomainName);
					else
						isdomainValid=relyingPartyAppVO.getAppDomainName().equals(rpDomainName);
					if (relyingPartyAppVO!=null && !isdomainValid){
						relyinPartyTrusted = false;
						relyingAppTrustErrorMessage = tbResources.getString("securityThreatMsg");
					}
				} catch (URISyntaxException e) {
					logger.error(e.getMessage());
				}
			}
			
			if(relyinPartyTrusted){
				removeSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET);
				String loginTarget = HttpUtils.addParameterToURL(this.targetUrl, 
						TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, relyingPartyAppVO.getAlias());
				loginTarget = HttpUtils.addParameterToURL(loginTarget, TrustBrokerWebAppConstants.TARGET, 
						(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL));
				loginTarget = HttpUtils.addParameterToURL(loginTarget, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, relyingAppId);
				addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, loginTarget);
			}
		}
	}
	
	public boolean isDomainValid(List<RPAppDomainVO> domains,String domainName){
		return TBUtil.isDomainValid(domains, domainName);
	}
	
		
	public void updateEmailAddress() {
		try {
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(userVO);
			String rpAppId = getRelyingPartyAppId();
			UserVO essoUserVO = container.getUserService().fetchUserProfile(userVO.getUuId(),true, true).getUser();
			userProfileServiceRequest.setOldUser(essoUserVO);
			container.getUserService().modifyUser(userProfileServiceRequest, true);
			String confirmationUrl = constructURL("/views/registeremailconfirmation.jsf");
			confirmationUrl = constructConfirmationUrlWithParams(userVO, confirmationUrl, false);
			container.getUserService().sendVerificationCode(
					getVerificationCodeRequest(CommunicationChannel.PRIMARY_EMAIL, userVO, false));
			emailConfirmationBean.setEmailVerificationCode(null);
			setErrorMsg("A new confirmation code has been sent to your new email address");
		}
		catch (OperationFailedException exception) {
			logger.error("UserRegistrationBean:sendCode() | Send AnotherCode Service error for user '"
							+ userNameSuggestionsList + "'", exception);
			setErrorMsg("An error occured while updating your email address");
		}
	}
	
	private void populateSecurityQuestions(UserVO userVO) {
		List<UserChallengeQuestionVO> securityQuestions = new ArrayList<UserChallengeQuestionVO>();
		UserChallengeQuestionVO question1 = new UserChallengeQuestionVO();
	
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();		
		String secQuestion1Array[] = secQuestion1.split("_");
		question1.setQuestionId(secQuestion1Array[0]);
		question1.setQuestion(secQuestion1Array[1]);
		question1.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerOne());

		UserChallengeQuestionVO question2 = new UserChallengeQuestionVO();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion2Array[] = secQuestion2.split("_");
		question2.setQuestionId(secQuestion2Array[0]);
		question2.setQuestion(secQuestion2Array[1]);
		question2.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerTwo());

		UserChallengeQuestionVO question3 = new UserChallengeQuestionVO();
		String secQuestion3 = tbSecurityQuestionsBean
				.getSecurityQuestionThree();
		String secQuestion3Array[] = secQuestion3.split("_");
		question3.setQuestionId(secQuestion3Array[0]);
		question3.setQuestion(secQuestion3Array[1]);
		question3.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerThree());

		securityQuestions.add(question1);
		securityQuestions.add(question2);
		securityQuestions.add(question3);
		userVO.setUserChallengeQuestions(securityQuestions);
	}

	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	public void userNameChanged(ValueChangeEvent e) {
		validateUserName(e.getNewValue().toString());
	}
	
	private boolean validateUserName(String enteredUserName) {
		
		boolean isUserNameRegExValidated = TBUtil.validateRegEx(enteredUserName, tbResources.getString("userNameRegEx"));
		setTempUserName("");
		
		if (!isUserNameRegExValidated) {
			userNameSuggestionsList = new ArrayList<String>();
			addFacesMessage("userRegistrationId:userNameId", tbResources.getString("invalidUserName"));
			return false;
		} else {
			userNameSuggestionsList = new ArrayList<String>();
			setShowSugestions(false);
			userVO.setUserName(enteredUserName);

			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(userVO);
			
			UserNameCheckServiceResponse resp = container.getUserService().checkUserNameAvailability(userProfileServiceRequest);			
			if(resp != null) {
				List<String> userNameSuggestionsFromWS = resp.getUserSuggestions();
				if (null != userNameSuggestionsFromWS && userNameSuggestionsFromWS.size() > 0) {
					setUserNameSuggestionsList(userNameSuggestionsFromWS);
					setOldUsernameSuggestionsList(userNameSuggestionsFromWS);
					setShowSugestions(true);
					addFacesMessage("userRegistrationId:userNameId", tbResources.getString("userNameNotAvailable"));
					return false;
				}
			}
		}
		return true;
	}
	
	public void checkNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultFirstName = TBUtil.validateName(userVO.getFirstName());
			if (!resultFirstName ) {
				addFacesMessage("userRegistrationId:firstName",tbResources.getString("numericSpecialCharMsg"));
			}
		}
	}
	
	public void checkLastNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultLastName = TBUtil.validateName(userVO.getLastName());
			if ( !resultLastName) {
				addFacesMessage("userRegistrationId:lastName",tbResources.getString("lastnumericSpecialCharMsg"));
			}
		}
	}
	
	public void checkdateOfBirth(ValueChangeEvent event) {
		
		PhaseId phaseId = event.getPhaseId();
				
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultDob = DateUtil.validateDate(dateOfBirth);
			if ( !resultDob) {
				addFacesMessage("userRegistrationId:dobId", tbResources.getString("dobFormatErrorMsg"));
			}
		}
	}
	
	/*
	public void checkEmailAddress(ValueChangeEvent event) {
		emailExistsMsg = "";
		showEmail = false;
		PhaseId phaseId = event.getPhaseId();
		
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();		
			
			if(!TBUtil.validateEmailId(event.getNewValue().toString())){
				addFacesMessage("userRegistrationId:email",tbResources.getString("invalidEmailAddress"));
			} else {
				if (container.getUserService().isEmailExists(event.getNewValue().toString())) {
					showEmail = true;
					addFacesMessage("userRegistrationId:email",tbResources.getString("emailAlreadyExists"));
				}
			} 			
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
			logger.debug("result value in email: " + result);
			if (!result) {
				addFacesMessage("userRegistrationId:email",tbResources.getString("invalidEmailAddress"));
			} 
		}
		logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg());
	}
	*/
	public void validateNameFields(){
		boolean resultFirstName = TBUtil.validateName(userVO.getFirstName());
		boolean resultMiddleName = TBUtil.validateName(userVO.getMiddleName());
		boolean resultLastName = TBUtil.validateName(userVO.getLastName());
		
		if (!resultFirstName || !resultMiddleName || ! resultLastName) {
			setSpecialCharsMsg(tbResources.getString("numericSpecialCharMsg"));
		} 
	}
	
	public boolean validateFirstNameLastNameFields(){
		boolean retValue = true;
		
		boolean resultFirstName = TBUtil.validateName(userVO.getFirstName());
		boolean resultLastName = TBUtil.validateName(userVO.getLastName());
		
		if (!resultFirstName ) {
			addFacesMessage("userRegistrationId:firstName",tbResources.getString("numericSpecialCharMsg"));
			retValue = false;
		} 
		
		if (! resultLastName) {
			addFacesMessage("userRegistrationId:lastName",tbResources.getString("lastnumericSpecialCharMsg"));
			retValue = false;
		} 
		
		return retValue;
	}

	/*
	public void checkEmailAddressSec(ValueChangeEvent event) {
		emailExistsMsgSec = "";
		showEmail = false;
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
			// validateEmailFormat(event.getNewValue().toString());
			logger.debug("result value in email: " + result);
			if (!event.getNewValue().toString().isEmpty()&&!result) {
				setEmailExistsMsgSec(tbResources.getString("invalidEmailAddress"));
			}
		}
		logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg() +"");
	}
	*/
	public void userNameImageClick(AjaxBehaviorEvent evt) {
		if (null != this.userVO.getUserName())
			validateUserName(this.userVO.getUserName());
	}
	
	public boolean isSecEmailExists(String email){
		return  container.getUserService().isEmailExists(email);
	}
	
	public void userSuggestionSelected(ValueChangeEvent e) {
		
		if (e.getNewValue() != null) {
			logger.debug("e.getnewvalue: " + e.getNewValue());
			String userSuggestionSelectedValue = e.getNewValue().toString();
			if (null != userSuggestionSelectedValue) {
				if (userNameSuggestionsList != null
						&& userNameSuggestionsList.contains(e.getNewValue()
								.toString()))
					userVO.setUserName(userSuggestionSelectedValue);
			}
		}
	}
	//Method to redirect into relying party url after successful registration
	/*public String continueToApp() {
		
		if(relyinPartyTrusted){
			return fetchUserProfile();
		}else{
			relyingAppErroMsg = relyingAppTrustErrorMessage;
		}
		return null;
	}
	*/
	public String continueToRegistration() {
		logger.debug("userRegistrationBean::Redirecting to Registration Page");
		
		
		
		addSessionAttribute("registrationSuccess", "Yes");
		
		
		setCurrentActiveItem("personalInformation");
        return "/views/userregistrationw.xhtml?faces-redirect=true";
		

	}
	
	
	public String continueToLoginByTargetURL() {
		logger.debug("userRegistrationBean::Redirecting to Login Page");
		
		
		//return (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		
		
        return "/uit/ClientAppLogin.xhtml?faces-redirect=true";
		

	}

	private String fetchUserProfile() {
		FacesContext context = getFacesContext();
		UserRetrievalServiceResponse userRetrievalResponse = null;
		ExecutionStatus executionStatus = null;
		UserVO user = null;

		try {
			//userRetrievalResponse = userService.fetchUserByUserName(userVO.getUserName());
			userRetrievalResponse = container.getUserService().fetchUserDetailsForSession(userVO.getUserName());
		} catch (OperationFailedException exception) {
			logger.error("LoginBean::fetchUserProfile()::Failed to fetch profile " + userVO.getUserName(), exception);
			context.addMessage(null, new FacesMessage("Invalid Username or Password"));
		}

		if(userRetrievalResponse != null ){
			executionStatus = userRetrievalResponse.getExecutionStatus();
			user = userRetrievalResponse.getUser();
		}

		if (executionStatus != null && executionStatus.getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE) && user != null) {
			logger.info("LoginBean::fetchUserProfile()::ExecutionStatus" + TrustBrokerConstants.SUCCESS_CODE_VALUE);
			setCurrentUserVO(user);
			return getWidgetHomeURIWithAlias();
		} else {
			logger.info("LoginBean::fetchUserProfile()::ExecutionStatus" + TrustBrokerConstants.FAILURE_CODE_VALUE);
			context.addMessage(null, new FacesMessage("Invalid Username or Password"));
			return null;
		}
	}

	public String displayRelyingPartyNotTrustedMsg(){
		relyingAppErroMsg = relyingAppTrustErrorMessage;
		return null;
	}

	public boolean getRelyinPartyTrusted() {
		return relyinPartyTrusted;
	}

	public void setRelyinPartyTrusted(boolean relyinPartyTrusted) {
		this.relyinPartyTrusted = relyinPartyTrusted;
	}

	public String getRelyingAppErroMsg() {
		return relyingAppErroMsg;
	}

	public void setRelyingAppErroMsg(String relyingAppErroMsg) {
		this.relyingAppErroMsg = relyingAppErroMsg;
	}


	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public String getLocalenv() {
		return localenv;
	}

	public void setLocalenv(String localenv) {
		this.localenv = localenv;
	}
	public boolean isTncAccepted() {
		return tncAccepted;
	}

	public void setTncAccepted(boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}

	public boolean isPrivacyPolicyAccepted() {
		return privacyPolicyAccepted;
	}

	public void setPrivacyPolicyAccepted(boolean privacyPolicyAccepted) {
		this.privacyPolicyAccepted = privacyPolicyAccepted;
	}

	public boolean isDecryptionfailed() {
		return decryptionfailed;
	}

	public void setDecryptionfailed(boolean decryptionfailed) {
		this.decryptionfailed = decryptionfailed;
	}

	public void registerConfirmEmail() {
		try {
			VerificationCodeResponse response = container.getUserService().verifyChannel(
					CommunicationChannel.PRIMARY_EMAIL,
					emailConfirmationBean.getEmailVerificationCode(),
					emailConfirmationBean.getPwd());
			userVO.setUserName(response.getUserName());
			userVO.setUuId(response.getUuid());
			addTrustedDevice();
		} catch (OperationFailedException exception) {
			logger.error("VerifyEmail Service error" + exception);
			emailConfirmationBean.setPwd("");
			setErrorMsg(extractErrorMessageFromOFE(exception));
			return;
		}
		setEmailVerified(true);
		userVO.setPassword(getEmailConfirmationBean().getPwd());
		checkRelyingPartyTrust();//Check if relying party is trusted or not before auto login.
	}


	public String signInClicked() {
		logger.debug("LoginBean:signInClicked| Relying Party URL '"+ 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL)+"' Relying Party ID'"+
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
		
		clrSessFlags();
		
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null &&
			getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null){
			{
				String url=(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
				if(StringUtils.isNotBlank(url))
					{ if(StringUtils.contains(url, "INVITATION_CODE"))
						{
						url=StringUtils.split(url,"?")[0];
						addSessionAttribute(TrustBrokerWebAppConstants.TARGET, url);						
						}
					}
				if(getSessionAttribute(TrustBrokerWebAppConstants.INVITATION) != null) {
					addSessionAttribute(TrustBrokerWebAppConstants.INVITATION_REGN_SIGNIN, "true");
				}
				logger.debug("LoginBean:signInClicked| Relying Party URL Modifed: '"+getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL));
                // make sure to encode URL that is being used as parameter
				return signInPage + "&TARGET=" +TrustbrokerWebAppUtil.encodeURL(url) + "&relyingAppId="
					+ getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
			}
		}	else return signInPage;
	}
	
	
	private void captureInvitationInfo(Map<String, String> invitationMap){
		String invitation = getRequestParameter(TrustBrokerWebAppConstants.INVITATION);
		if(invitation != null && !"".equals(invitation)){
			try{
				invitationMap = container.getInvitationService().decodeInvitationDetails(invitation);
				String token = invitationMap.get(InvitationConstants.KEY_INVITATION_TOKEN);
				String relyingAppId = invitationMap.get(InvitationConstants.KEY_REPLYING_PARTY_APP_ID);
				
				RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
			
				InvitationServiceResponse invitationServiceResponse = container.getInvitationService().getInvitationByTokenAndRelyingAppId(token, relyingAppId);
				
				if(invitationServiceResponse.getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)){
					InvitationVO invitationVO = invitationServiceResponse.getInvitationVO();
					
					int invtnExpirationDays = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userInvitationExpiration"));
					
					if(TrustBrokerWebAppConstants.REGISTERED.equals(invitationVO.getInvtnStts().getStatusState()) || 
							invitationVO.getInvtnAccptdDttm() != null){
						
						addSessionAttribute("error", tbResources.getString("invitationUsed"));
						redirectToView("/views/userInvitationRegistrationFailure.jsf");
						return;
					} else if( (TrustBrokerWebAppConstants.EXPIRED.equals(invitationVO.getInvtnStts().getStatusState())) || 
							(invitationVO.getInvtnExprtnDttm() != null && 
							invitationVO.getInvtnExprtnDttm().before(DateUtil.getInstance().getCurrentDateTime())) || 
							(invitationVO.getInvtnGenDttm() != null && invitationVO.getInvtnExprtnDttm() == null &&
								DateUtil.validateDateByDays(invitationVO.getInvtnGenDttm(), invtnExpirationDays))){
						
						addSessionAttribute("error", tbResources.getString("invitationExpired"));
						redirectToView("/views/userInvitationRegistrationFailure.jsf");
						return;
					} else {
						userVO.setEmailAddress(invitationVO.getInvtnToEmail());
						invitationVO.getInvitationCtxProperties();
						Iterator<InvitationContextPropertyVO> ctxPropertyIterator = invitationVO.getInvitationCtxProperties().iterator();
						
						while (ctxPropertyIterator.hasNext()){
							InvitationContextPropertyVO invitationContextPropertyVO = ctxPropertyIterator.next();
							if(invitationContextPropertyVO.getName()!=null)
							{
								if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.FIRSTNAME)) {
									userVO.setFirstName(invitationContextPropertyVO.getValue());
								} else if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.MIDDLENAME)){
									userVO.setMiddleName(invitationContextPropertyVO.getValue());
								} else if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.LASTNAME)) {
									userVO.setLastName(invitationContextPropertyVO.getValue());
								} else if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.DOB)) {
									SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
									sdf.setLenient(false);
									Date testDate = null;
									boolean isDOBvalid = false;
									String strDate = invitationContextPropertyVO.getValue();
									try {
										testDate= sdf.parse(strDate);
										isDOBvalid = true;
								    } catch (ParseException e){
										isDOBvalid = false;
								    }
									if(isDOBvalid)
									dateOfBirth =new SimpleDateFormat("MM/dd/yyyy").format(testDate);
								}
							}
						}
						
						addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL, invitationVO.getRpAppTargetURL());
						addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, invitationVO.getRpAppId());
						if (relyingPartyAppVO != null) 
							addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
						setConfirmEmailAddress(invitationVO.getInvtnToEmail());
						addSessionAttribute(TrustBrokerWebAppConstants.INVITATION, invitationVO);
					}
				}else{
					addSessionAttribute("error", tbResources.getString("invitationNotFound"));
					redirectToView("/views/userInvitationRegistrationFailure.jsf");
					return;
				}
			} catch(Exception ex){
				logger.error("UserRegistrationBean:captureInvitationInfo() | Error while processing the invitation information", ex);
			}
		}
	}
	
	public String returnToLogin() {
		String relyingPartyRedirectionParams = getRelyingPartyRedirectionParameters();
		if (getCurrentUserVO() != null && isActiveSMSession()) {
			if(StringUtils.isNotBlank(relyingPartyRedirectionParams)){
				redirectToRelyingParty(
						(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL),
						(String) getSessionAttribute(TrustBrokerWebAppConstants.ACTION),
						(String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS),
						(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			}else{
				redirectToView("/secure/home.jsf?faces-redirect=true");
			}
			return null;
		}
		
		if(StringUtils.isNotBlank(relyingPartyRedirectionParams))
			return "/views/login.xhtml?faces-redirect=true&"+ relyingPartyRedirectionParams;
		else return "/views/login.xhtml?faces-redirect=true";
	}
	
	
	public void processRPreg()
	{
		showQuestions = false;
		
		String relyingAppId = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		RelyingPartyAppVO rpAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
		//Coppa will be required by default unless configured as N for relying party 
		if(rpAppVO != null && COPPA_REQD_NO_IND.equalsIgnoreCase(rpAppVO.getCoppaReqdInd())) {
			setCoppaValidationReqd(false);
		} else {
			setCoppaValidationReqd(true);
		}
		
		QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
		queryRelyingPartyResponse = container.getConfigService().queryRelyingParty(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS).toString());
		QueryTierResponse queryTierResponse = new QueryTierResponse();
		if(queryRelyingPartyResponse!=null &&  queryRelyingPartyResponse.getRelyingParty()!=null) {
			RelyingParty rp = queryRelyingPartyResponse.getRelyingParty();
				if(rp.getTiers() != null && rp.getTiers().size() > 0) {
					TierConfig tierConfig = rp.getTiers().get(0);
					userVO.setTierId(tierConfig.getTierId());
					queryTierResponse = container.getConfigService().queryTier(tierConfig.getTierId());
					if(queryTierResponse!=null && queryTierResponse.getTierDefinition()!=null)
					{
						List<TierAttribute> tierAttributes= queryTierResponse.getTierDefinition().getTierAttributes();
						for (Iterator<TierAttribute> iterator = tierAttributes.iterator(); iterator.hasNext();) {
							TierAttribute tierAttribute = iterator.next();
							if(tierAttribute.getName().equalsIgnoreCase(TrustBrokerConstants.DATE_OF_BIRTH) && tierAttribute.isMandatory())
							{
								showDob = true;
							}
							else if (tierAttribute.getName().equalsIgnoreCase(
									TrustBrokerConstants.EMAIL_ADDRESS)) {
								if (!tierAttribute.isMandatory()) {
									emailMandatory = false;
									showSecQuestionBasedonSharedEmail=true;
								}
								if (tierAttribute.isUnique()) {
									emailShared = false;
								}

							}
						}
					}
					
					List<AuthenticationType> authenticationTypes= tierConfig.getAuthenticationTypes();
					if(null != authenticationTypes && authenticationTypes.size() == 1) {
						if(authenticationTypes.get(0).value().equalsIgnoreCase(AuthenticationType.PASSWORD.value())){
							showQuestions = false;
							displayDeviceRegistration = false;
						}
					} else {
						for (Iterator<AuthenticationType> iterator = authenticationTypes.iterator(); iterator.hasNext();) {
							AuthenticationType authenticationType = iterator.next();
							if (authenticationType.value().equalsIgnoreCase(AuthenticationType.SECURITY_QUESTIONS.value()))
							{
								showQuestions = true;
							}
						}
					}
				}
		}
		
		if(showSecQuestionBasedonSharedEmail==true)
		{
			
			showSecQuestionBasedonSharedEmailDynamic = true;
		}
	}

	/*
	public void checkUpdateEmailAddress(ValueChangeEvent event) {
        emailExistsMsg = "";
        showEmail = false;
        PhaseId phaseId = event.getPhaseId();
        
        if (phaseId.equals(PhaseId.ANY_PHASE)) {
               event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
               event.queue();             
               
               if(!TBUtil.validateEmailId(event.getNewValue().toString())){
                     //setEmailExistsMsg(tbResources.getString("invalidEmailAddress"));
                      addFacesMessage("userRegistrationId:updateEmail",tbResources.getString("invalidEmailAddress"));
               } else {
                     if (container.getUserService().isEmailExists(event.getNewValue().toString())) {
                            
                            showEmail = true;
                            //setEmailExistsMsg(tbResources
                             //             .getString("emailAlreadyExists"));
                            addFacesMessage("userRegistrationId:updateEmail",tbResources.getString("emailAlreadyExists"));
                     }
               }                    
        } else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
               boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
               // validateEmailFormat(event.getNewValue().toString());
               logger.debug("result value in updateEmail: " + result);
               if (!result) {
                     //setEmailExistsMsg(tbResources.getString("invalidEmailAddress"));
                      addFacesMessage("userRegistrationId:updateEmail",tbResources.getString("invalidEmailAddress"));
               } 
               
               
        }
        logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg());
 }

*/



 public String updateEmailAddressPage() {
	 	confirmEmailAddress ="";
        setCurrentActiveItem("updateEmailConfirmation");
        return "/views/updateemailregistration.xhtml?faces-redirect=true";
 }
 
 
/**
 * @return the confirmnewEmailAddress
 */
public String getConfirmnewEmailAddress() {
	return confirmnewEmailAddress;
}

/**
 * @param confirmnewEmailAddress the confirmnewEmailAddress to set
 */
public void setConfirmnewEmailAddress(String confirmnewEmailAddress) {
	this.confirmnewEmailAddress = confirmnewEmailAddress;
}

public void checkUpdateConfirmEmailAddress(ValueChangeEvent event) {
    emailExistsMsg = "";
    showEmail = false;
    PhaseId phaseId = event.getPhaseId();
    
    if (phaseId.equals(PhaseId.ANY_PHASE)) {
           event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
           event.queue();             
           
           if(!TBUtil.validateEmailId(event.getNewValue().toString())){
                  addFacesMessage("userRegistrationId:confirmUpdateEmail",tbResources.getString("invalidEmailAddress"));
           } else {
                 if (container.getUserService().isEmailExists(event.getNewValue().toString())) {
                        
                        showEmail = true;
                        addFacesMessage("userRegistrationId:confirmUpdateEmail",tbResources.getString("emailAlreadyExists"));
                 }
           }                    
    } else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
           boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
           logger.debug("result value in updateEmail: " + result);
           if (!result) {
                  addFacesMessage("userRegistrationId:confirmUpdateEmail",tbResources.getString("invalidEmailAddress"));
           } 
           
           
    }
    logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg());
}

private boolean validateConfirmEmailFields() {
	boolean result = true;
	
	
	if (!TBUtil.validateEmailId(confirmnewEmailAddress.toLowerCase())){
		setEmailExistsMsg("");
		
		addFacesMessage("userRegistrationId:updateEmail", tbResources
				.getString("invalidEmailAddress"));	
		result = false;
	}
	if (!TBUtil.validateEmailId(confirmEmailAddress.toLowerCase())){
		setEmailExistsMsg("");
		
		addFacesMessage("userRegistrationId:confirmUpdateEmail", tbResources
				.getString("invalidEmailAddress"));	
		result = false;
	}
	
	
	
	if (TBUtil.validateEmailId(confirmnewEmailAddress)
			&& !confirmnewEmailAddress.toLowerCase().equals(
					getConfirmEmailAddress().toLowerCase())) {
		
		addFacesMessage("userRegistrationId:confirmUpdateEmail", tbResources
				.getString("emailDoNotMatch"));
		result = false;
		
		
	}
	if (container.getUserService().isEmailExists(confirmnewEmailAddress)) {
		showEmail = true;
		addFacesMessage("userRegistrationId:updateEmail", tbResources
				.getString("emailAlreadyExists"));
		result=false;
	}
	return result;
}

private String rpRegUrl ;



public boolean validateCredentials() {
		boolean result = true;
		
		clearValidationMessages();
		String summaryLog="";

		

		
	
	
	boolean passwordHasSpace=false;
	boolean confirmPasswordHasSpace=false;

     if(userVO.getPassword().equals("")){
	setPasswordErrorMessage("Password is required");
	setValidationPersonalErrorMsg2("Yes");
	summaryLog+="  password required";
	result=false;
	//setConfirmPasswordErrorMessage("");
      }else{
	
	 
	if(getPwdSpace().equals("Y")){
		
		passwordHasSpace =true;
		setPasswordErrorMessage("Password cannot contain spaces ");
		setValidationPersonalErrorMsg2("Yes");
		summaryLog+="  password invalid";
		result=false;
		
	}
		
		
     }
	




if(getConfirmPassword().equals("")){
	setConfirmPasswordErrorMessage("Confirm Password is required");
	setValidationPersonalErrorMsg2("Yes");
	summaryLog+="  confrim pwd required";
	result=false;
}else{
	
if(!getPwdSpace().equals("Y") && getConfirmPwdSpace().equals("Y")){
	    confirmPasswordHasSpace =true;
	    setConfirmPasswordErrorMessage(tbResources.getString("pwdDoNotMatch"));
		setValidationPersonalErrorMsg2("Yes");
		summaryLog+="  pwd not match";
		result=false;
	}
}



if(!passwordHasSpace && !confirmPasswordHasSpace){
boolean passwordPass = checkPwdContent();
if(!passwordPass)
{
	result=passwordPass;
}

summaryLog+="pwdcheck "+passwordPass;


if (!userVO.getPassword().equals(getConfirmPassword())) {
	result = false;
	/*addFacesMessage("userRegistrationId:pwd",
			tbResources.getString("pwdDoNotMatch"));*/
	setValidationPersonalErrorMsg2("Yes");
	setPasswordErrorMessage(tbResources.getString("pwdDoNotMatch"));
	summaryLog+="  pwd not match";
	result=false;
}
	
	if(!TBUtil.isPwdStrengthValid(userVO.getPassword())) {
		setPasswordErrorMessage(tbResources.getString("goodOrStrongPwdReq"));
		setValidationPersonalErrorMsg2("Yes");
		summaryLog+="  pwd weak";
		result = false;
		/*addFacesMessage("userRegistrationId:pwd",
				tbResources.getString("goodOrStrongPwdReq"));*/
	}


}

if(userVO.getUserName().equals("")){
	setUserNameErrorMessage("User Name is required");
	setValidationPersonalErrorMsg2("Yes");
	summaryLog+="  username required";
	result = false;
}else{
	
	
	boolean isUserNameRegExValidated = TBUtil.validateRegEx(userVO.getUserName(), tbResources.getString("userNameRegEx"));
	setTempUserName("");

	if (!isUserNameRegExValidated) {
		userNameSuggestionsList = new ArrayList<String>();
		//addFacesMessage("userRegistrationId:userNameId", tbResources.getString("invalidUserName"));
		setUserNameErrorMessage(tbResources.getString("invalidUserName"));
		setValidationPersonalErrorMsg2("Yes");
		summaryLog+="  username not valid";
		result = false;
	} else {
		userNameSuggestionsList = new ArrayList<String>();
		setShowSugestions(false);
		userVO.setUserName(userVO.getUserName());

		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(userVO);		
		UserNameCheckServiceResponse resp = container.getUserService().checkUserNameAvailability(userProfileServiceRequest);

		if(resp != null) {
			List<String> userNameSuggestionsFromWS = resp.getUserSuggestions();
			if (null != userNameSuggestionsFromWS && userNameSuggestionsFromWS.size() > 0) {
					setUserNameSuggestionsList(userNameSuggestionsFromWS);
					setOldUsernameSuggestionsList(userNameSuggestionsFromWS);
					setShowSugestions(true);
					//addFacesMessage("userRegistrationId:userNameId", tbResources.getString("userNameNotAvailable"));
					setUserNameErrorMessage(tbResources.getString("userNameNotAvailable"));
					setValidationPersonalErrorMsg2("Yes");
					summaryLog+="  username not available";
					result = false;		
			}
		}
	}
		
	
}
		
		// check box validation
//if(!showQuestions && !showSecQuestionBasedonSharedEmail && !showSecQuestionBasedonSharedEmailDynamic){
		if(!showQuestions  && !showSecQuestionBasedonSharedEmailDynamic){
			
		  if(!validateTermsAndCondition()){
			summaryLog+="  terma and conds not valid";
			 result = false;
		  }
		}
		logger.debug("Is Credentials validated: " + result);
		logger.debug(" summary credentials validation log: "+summaryLog);
		
		credentialsValid=result;

		return result;
	}






private boolean validateYearOfBirth(){
		
	boolean isYearValid=true;
	if(StringUtils.isEmpty(yearOfBirth)){
		setDobErrorMessage("Year of Birth is required");
		setValidationPersonalErrorMsg("Yes");
		isYearValid=false;
		return isYearValid;
	}
	
		
	isYearValid= validateYobFormat(yearOfBirth);
		
	if(!isYearValid){
			setDobErrorMessage(tbResources.getString("yobFormatErrorMsg"));
			setValidationPersonalErrorMsg("Yes");
			isYearValid = false;
			return isYearValid;
	}
	
	int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance()
				.getPortalConfigValue("userMinAgeLimit"));
	
	boolean isLimitStillValid=checkYearOfBirthEntryLimit();
	if(isLimitStillValid){
		SimpleDateFormat yearformat = new SimpleDateFormat(DateUtil.YEAR_FORMAT);
	  Integer ageDifference = DateUtil.validateAge(yearOfBirth, minAgeLimit,yearformat);
	  if (ageDifference != DateUtil.OVERAGE   ) {
		    incrementIncorrectYobCount();
		    isLimitStillValid=checkYearOfBirthEntryLimit();
		    if(isLimitStillValid){
		    	if(ageDifference == DateUtil.OVERAGEEXEEDED)
		    		  setDobErrorMessage(tbResources.getString("yobAgeConstraintOverMsg"));
		    	else  if(ageDifference == DateUtil.FUTURE)
		    		 setDobErrorMessage(tbResources.getString("yobAgeConstraintFutureMsg"));
		       else
		    	   setDobErrorMessage(tbResources.getString("yobAgeConstraintMsg"));
		    }
		    setValidationPersonalErrorMsg("Yes");
		    isYearValid = false;
	  }
	}else
		isYearValid=false;
	
	return isYearValid;
}	

private boolean validateYobFormat(String yobStr){
	if(showDob)
		return true;//then year of birth not used
	boolean valid=true;
	Integer yob=-1;
	Date yobDate=null;
	
	try{
		if(StringUtils.isEmpty(yobStr)){
			setDobErrorMessage("Year of Birth is required");
			valid=false;
			return valid;
		}
		yob = Integer.parseInt(yobStr);
		SimpleDateFormat yearformat = new SimpleDateFormat(DateUtil.YEAR_FORMAT);
		if(yob != -1) {
			yobDate = yearformat.parse(yobStr);
		}
	}catch(Exception e){
		logger.debug("caught exception parsing year of birth. e: "+e);
		valid=false;
	}
	
	return valid;
}

private boolean checkYearOfBirthEntryLimit(){
	if(isCoppaValidationReqd())
	{
		Integer yobCount = this.getIncorrectYobCount();
		if(yobCount >=yobLimit){
			setDobErrorMessage(tbResources.getString("ageNotElibleMsg"));
			setValidationPersonalErrorMsg("Yes");
			return false;
		}else{
			return true;
		}
	}
	else
	{
		return true;
	}
	
}
private void incrementIncorrectYobCount(){
	Integer yobCount = getIncorrectYobCount();
	yobCount++;
	this.addSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT, yobCount);
}
private Integer getIncorrectYobCount(){
	Integer yobCount=null;
	Object incorrectYobCountObj = getSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT);
	if(incorrectYobCountObj != null)
		yobCount = (Integer)incorrectYobCountObj;
	else{
		yobCount = new Integer(0);
		this.addSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT, yobCount);
	}
	return yobCount;
}





	public void setRpRegUrl(String rpRegUrl) {
	this.rpRegUrl = rpRegUrl;
}

	public String getRpRegUrl () {
		return (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
	}

	
	public String loginPage(){
		return signInPage;
	}

	public String getSpecialCharsMsg() {
		return specialCharsMsg;
	}

	public void setSpecialCharsMsg(String specialCharsMsg) {
		this.specialCharsMsg = specialCharsMsg;
	}
	
	public boolean isDisableEmailCode() {
		return disableEmailCode;
	}

	public void setDisableEmailCode(boolean disableEmailCode) {
		this.disableEmailCode = disableEmailCode;
	}
    public void setMobilePhone(String val){
    	mobilePhone=val;
    }
    public String getMobilePhone(){
    	return mobilePhone;
    }
	public boolean isShowContinue() {
		return showContinue;
	}

	public void setShowContinue(boolean showContinue) {
		this.showContinue = showContinue;
	}

	public String getRegisterDevice() {
		return registerDevice;
	}

	public void setRegisterDevice(String registerDevice) {
		this.registerDevice = registerDevice;
	}

	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	/**
	 * @return the yearOfBirth
	 */
	public String getYearOfBirth() {
		return yearOfBirth;
	}

	/**
	 * @param yearOfBirth the yearOfBirth to set
	 */
	public void setYearOfBirth(String yearOfBirth) {
		this.yearOfBirth = yearOfBirth;
	}

	public boolean getDisplayDeviceRegistration() {
		return displayDeviceRegistration;
	}

	public void setDisplayDeviceRegistration(boolean displayDeviceRegistration) {
		this.displayDeviceRegistration = displayDeviceRegistration;
	}
	
	public void clearALL(){
		
		setFirstNameErrorMessage("");
		setLastNameErrorMessage("");
		setMiddleNameErrorMessage("");
		setEmailErrorMessage("");
		setConfirmEmailErrorMessage("");
		//setUserNameErrorMessage("");
		//setPasswordErrorMessage("");
		//setConfirmPasswordErrorMessage("");
		setDobErrorMessage("");
		//setTermsConditionErrorMessage("");
		setValidationPersonalErrorMsg("No");
		setValidationPersonalErrorMsg2("No");
	}
	
}
