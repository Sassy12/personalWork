package com.optum.trustbroker.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.controller.vo.ErrorResponseVO;
import com.optum.trustbroker.controller.vo.ManageProfileVO;
import com.optum.trustbroker.controller.vo.ProfileVO;
import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.controller.vo.SecurityQuestionVO;
import com.optum.trustbroker.enums.PreferenceType;
import com.optum.trustbroker.helpers.RelyingPartyHelper;
import com.optum.trustbroker.helpers.UserHelper;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.RelyingPartyTierInfoVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@Component
@Path(TBConstants.ACCOUNT_RECOVERY_CONTROLLER_PATH)
public class VerificationOptionsController extends BaseController {

    private static final BaseLogger LOGGER = new BaseLogger(VerificationOptionsController.class);

    @Autowired
    private UserHelper userHelper;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRecoveryOptions() {
        Response response = null;

        UserVO userVO = getCurrentUser();
        ChallengeQuestionServiceResponse challengeQuestionServiceResponse = configService.getSecurityQuestions();

        ManageProfileVO manageProfileVO = new ManageProfileVO();
        ProfileVO profileVO = new ProfileVO();
        RpAppVO rpAppVO = null;
        SecurityQuestionVO securityQuestionVO = new SecurityQuestionVO();

        profileVO.setUserName(userVO.getUserName());
        profileVO.setUuid(userVO.getUuId());
        String relyingAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);

        if (StringUtils.isNotEmpty(relyingAppId)) {
            rpAppVO = new RpAppVO();
            RelyingPartyAppVO relyingPartyAppVO = getRPContext();
            RelyingPartyTierInfoVO rpTierInfo = getRPTierInfo(relyingPartyAppVO.getAlias());
            RelyingPartyHelper.buildRelyingPartyVO(rpAppVO, relyingPartyAppVO, rpTierInfo);
            String targetURL = getSessionAttribute(TrustBrokerWebAppConstants.TARGET);
            rpAppVO.setTargetURL(targetURL);

            boolean isSharedEmail = userService.isEmailExistsWithOtherUser(userVO.getEmailAddress(), userVO.getUserName());

            if (isSharedEmail || rpAppVO.isShowQuestions()) {
                manageProfileVO.setSecurityQuestionsReq(true);
            }
        }

        userHelper.populateSecurityQuestions(userVO, challengeQuestionServiceResponse, securityQuestionVO);
        userHelper.populateRecoveryOptions(userVO, profileVO);

        if (relyingAppId == null) {
            // making security questions mandatory for standalone
            manageProfileVO.setSecurityQuestionsReq(true);
        }
        manageProfileVO.setProfile(profileVO);
        manageProfileVO.setRpContext(rpAppVO);
        manageProfileVO.setSecurityContext(securityQuestionVO);
        response = Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(manageProfileVO).build();

        return response;
    }

    
	
    
    /**
     *  This method saves the updates made to recovery options and decides the next screen
     *  to display based on eSSO response and modified attributes on user profile. If mobile or secondary email
     *  are updated, recovery option preferences are removed from DB.
     *
     *  Verification needed for following fields -  primary, secondary email & mobile no
     *  Verification Not Needed for Security Questions & Answers update.
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateRecoveryOptions(ManageProfileVO manageProfileVO, @Context HttpServletRequest request) {
        Response response = null;

        UserVO currentUserVO = getCurrentUser();
        String relyingAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);

        RelyingPartyTierInfoVO rpTierInfo = null;
        boolean skipEmailVerification = false;
        if (StringUtils.isNotEmpty(relyingAppId)) {
            RelyingPartyAppVO relyingPartyAppVO = getRPContext();
            rpTierInfo = getRPTierInfo(relyingPartyAppVO.getAlias());
            if (TrustBrokerWebAppConstants.EMAIL_CONFM_REQD_NO_IND.equals(relyingPartyAppVO.getEmailconfirmreqd())) {
                skipEmailVerification = true;
            }
        }
        // validate form fields - email/phoneNo/security questions
       
        userHelper.validateFormFields(manageProfileVO, rpTierInfo, currentUserVO);
        Map<String, String> validationErrors = manageProfileVO.getErrorMap();
        if (MapUtils.isNotEmpty(validationErrors)) {
            LOGGER.error("Recovery options validations failed with errors - {}", validationErrors);
            ResponseVO errorResponse = new ResponseVO();
            errorResponse.setErrorMap(validationErrors);
            errorResponse.setStatus(TrustBrokerWebAppConstants.ERROR);
            response = Response.status(TrustBrokerWebAppConstants.HTTP_BAD_REQUEST).entity(errorResponse).build();
            return response;
        }

        UserVO userVO = new UserVO();
        // try to replace this with manual copy
        BeanUtils.copyProperties(currentUserVO, userVO);
        userHelper.populateRecoveryOptionsFromView(userVO, manageProfileVO);
        UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
        userProfileServiceRequest.setUser(userVO);
        userProfileServiceRequest.setOldUser(currentUserVO);
        // update recovery options

        UserProfileServiceResponse serviceResponse = userService.modifyUser(userProfileServiceRequest, true);

        if (TrustbrokerWebAppUtil.checkResponseStatus(serviceResponse)) {
            String status = null;
            List<String> modifiedFields = userHelper.checkIfVerificationNeeded(manageProfileVO, currentUserVO);
            if (!modifiedFields.isEmpty()) {
                if (TBUtil.isProdEnv() || !skipEmailVerification) {
                    status = TrustBrokerWebAppConstants.VERIFICATION_NEEDED;
                    
                    
                } else if (skipEmailVerification && modifiedFields.contains(TrustBrokerWebAppConstants.MOBILE_NO)) {
                    status = TrustBrokerWebAppConstants.VERIFICATION_NEEDED;
                } else if (skipEmailVerification && (modifiedFields.contains(TrustBrokerWebAppConstants.PRIMARY_EMAIL)
                        || modifiedFields.contains(TrustBrokerWebAppConstants.SECONDARY_EMAIL))) {
                    status = TrustBrokerWebAppConstants.VERIFICATION_NOT_NEEDED;
                }
                WebApplicationContextHolder.getContext().setWorkflowAttribute(WorkflowConstants.WORKFLOW_MANAGE_ID_VERIFY_OPTIONS, WorkflowConstants.WORKFLOW_ATTRIBUTE_STATUS, status);
            } else {
                status = TrustBrokerWebAppConstants.VERIFICATION_NOT_NEEDED;
            }
            
            /* Remove preferences in DB only when the user updates mobile or secondary email successfully */
            PreferenceType preferenceType = null;
            UserVO eSSOUserVO = serviceResponse.getUser();
            if (eSSOUserVO != null) {
                // eSSO user is not null in case of successful update
                if (!StringUtils.equalsIgnoreCase(eSSOUserVO.getSecEmailAddress(), currentUserVO.getSecEmailAddress())) {
                    preferenceType = PreferenceType.SECONDARY_EMAIL;
                    userService.deletePreferences(currentUserVO.getUuId(), preferenceType);
                }
                if (!StringUtils.equals(eSSOUserVO.getPhoneNumber(), currentUserVO.getPhoneNumber())) {
                    preferenceType = PreferenceType.MOBILE;
                    userService.deletePreferences(currentUserVO.getUuId(), preferenceType);
                }
                addSkipRecoveryOptionsEvent();
            }

            // send profile update notification to user
            sendProfileUpdateNotification(request, relyingAppId, userVO, currentUserVO,false);

            ManageProfileVO responseVO = new ManageProfileVO();
            responseVO.setStatus(status);
            responseVO.setModifiedFields(modifiedFields);
            response = Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(responseVO).build();

            SecurityLoggingUtil.info("User Account Modifications", SecurityEventType.E3_MODIFY, request,
                    currentUserVO.getUserName(),
                    "Security Audit Event| ModifyUserProfile:SUCCESS | User Profile Modified, VerificationOptionsController:updateRecoveryOptions()",
                    SecurityEventResult.SUCCESS, relyingAppId, SecuritySubEventType.E3_MODIFY_PROFILE);
        } else {
            String errorMsg = serviceResponse.getReasonMessage();
            ErrorResponseVO errorResponse = new ErrorResponseVO();
            errorResponse.setErrorCode(serviceResponse.getReasonCode());
            errorResponse.setMessage(errorMsg);
            LOGGER.error("Unable to update recovery options for user {} in eSSO due to {} ",
                    new String[] {userVO.getUserName(), errorMsg});
            response = Response.status(TrustBrokerWebAppConstants.HTTP_BAD_REQUEST).entity(errorResponse).build();
        }

        return response;
    }

    public UserHelper getUserHelper() {
        return userHelper;
    }

    public void setUserHelper(UserHelper userHelper) {
        this.userHelper = userHelper;
    }
}
