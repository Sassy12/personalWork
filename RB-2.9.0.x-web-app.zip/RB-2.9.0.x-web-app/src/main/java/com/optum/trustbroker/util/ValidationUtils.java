package com.optum.trustbroker.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.controller.vo.SecurityQuestionVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.controller.vo.ValidationData;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.vo.UserNameCheckServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.esso.schemas.xsd._2012._07.UserSearchResultItem;

public class ValidationUtils {

    private static final String PWD_KEY = "pwd";

    protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");

    private static final String USERNAME_KEY = "userName";

    private final int MIN_AGE_LIMIT = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userMinAgeLimit"));

    private static final BaseLogger LOGGER = new BaseLogger(ValidationUtils.class);

    private final int COPPA_ENTRY_LIMIT = 2;

    private static final char[] USERNAME_BLOCKED_CHARS = new char[] {'(', ')', '*', '&'};

    private static final String SEC_QUES_1 = "secQues1ErrorMsg";

    private static final String SEC_QUES_2 = "secQues2ErrorMsg";

    private static final String SEC_QUES_3 = "secQues3ErrorMsg";

    private static final String SEC_ANS_1 = "secAns1ErrorMsg";

    private static final String SEC_ANS_2 = "secAns2ErrorMsg";

    private static final String SEC_ANS_3 = "secAns3ErrorMsg";

    @Autowired
    private UserService userService;

    @Autowired
    protected WebApplicationCommonUtilities webApplicationCommonUtilities;

    public UserInfoVO checkUserExistsWithNameAndEmail(UserInfoVO userInfoVO) {
        UserVO userVO = new UserVO();
        userVO.setFirstName(userInfoVO.getFirstName());
        userVO.setLastName(userInfoVO.getLastName());
        userVO.setEmailAddress(userInfoVO.getEmailAddress());

        UserProfileServiceRequest request = new UserProfileServiceRequest();
        request.setUser(userVO);
        List<UserSearchResultItem> userSearchResults = userService.lookUpUser(request);
        if (!userSearchResults.isEmpty()) {
            userInfoVO.addNotificationMessage("userExists", "true");
            userInfoVO.setShowSecQuestionBasedonSharedEmail(true);
        }
        return userInfoVO;
    }

    private boolean containsWhiteSpace(String string) {
        return StringUtils.contains(string, ' ');
    }

    public void validateUserName(UserInfoVO userInfoVO) {

        String userName = userInfoVO.getUserName();

        /* check if username is empty */
        if (StringUtils.isEmpty(userName)) {
            userInfoVO.addErrorMessage(USERNAME_KEY, tbResources.getString("userNameRequired"));
            return;
        }

        /* check for spaces */
        if (containsWhiteSpace(userName)) {
            userInfoVO.addErrorMessage(USERNAME_KEY, tbResources.getString("invalidOptumID"));
            return;
        }
        /* check for length (6-50) */
        if (userName.length() < 6 || userName.length() > 50) {
            userInfoVO.addErrorMessage(USERNAME_KEY, tbResources.getString("invalidOptumID"));
            return;
        }
        /* check for blocked chars */
        if (StringUtils.indexOfAny(userName, USERNAME_BLOCKED_CHARS) != -1) {
            userInfoVO.addErrorMessage(USERNAME_KEY, tbResources.getString("invalidOptumID"));
            return;
        }
        /* check for valid chars */
        if (!TBUtil.validateName(userName)) {
            userInfoVO.addErrorMessage(USERNAME_KEY, tbResources.getString("invalidOptumID"));
            return;
        }

        /* check for username availability and populate suggestions if username is already taken */
        List<String> userNameSuggestionsList = new ArrayList<String>();
        UserVO userVO = new UserVO();
        userVO.setUserName(userInfoVO.getUserName());
        userVO.setFirstName(userInfoVO.getFirstName());
        userVO.setLastName(userInfoVO.getLastName());

        UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
        userProfileServiceRequest.setUser(userVO);

        UserNameCheckServiceResponse resp = userService.checkUserNameAvailability(userProfileServiceRequest);
        if (resp != null) {
            if (!resp.isUserNameAvailable()) {
                List<String> userNameSuggestionsFromWS = resp.getUserSuggestions();
                if (CollectionUtils.isNotEmpty(userNameSuggestionsFromWS)) {
                    userNameSuggestionsList.addAll(userNameSuggestionsFromWS);
                    userInfoVO.addErrorMessage("userNameNotAvailable", tbResources.getString("userNameNotAvailable"));
                    userInfoVO.setUserNameSuggestionsList(userNameSuggestionsList);
                } else {
                    userInfoVO.addErrorMessage(USERNAME_KEY, tbResources.getString("userNameNotAvailNoSuggstn"));
                }
            }
        }
    }

    public void validateName(UserInfoVO userInfoVO, String fieldId) {
        String formattedName = null;

        if ("firstName".equals(fieldId)) {

            if (StringUtils.isNotEmpty(userInfoVO.getFirstName())) {

                String firstName = userInfoVO.getFirstName();
                if (firstName.length() > 50) {

                    userInfoVO.addErrorMessage("firstNameError", "First name " + tbResources.getString("nameLengthErr"));

                }
                formattedName = trimAndTruncateSpaces(firstName);
                userInfoVO.setFirstName(formattedName);
                if (formattedName.length() == 0) {
                    userInfoVO.addErrorMessage("firstNameError", tbResources.getString("firstNameReqErr"));
                    return;
                }

            } else {
                userInfoVO.addErrorMessage("firstNameError", tbResources.getString("firstNameReqErr"));
                return;
            }
            if (StringUtils.isNotEmpty(userInfoVO.getFirstName()) && !TBUtil.validateName(userInfoVO.getFirstName())) {

                userInfoVO.addErrorMessage("firstNameError", "First name " + tbResources.getString("nameFieldSpclCharErr"));
                return;
            }

        } else if ("lastName".equals(fieldId)) {

            if (StringUtils.isNotEmpty(userInfoVO.getLastName())) {
                String lastName = userInfoVO.getLastName();
                if (lastName.length() > 50) {

                    userInfoVO.addErrorMessage("lastNameError", "Last name " + tbResources.getString("nameLengthErr"));

                }
                formattedName = trimAndTruncateSpaces(lastName);
                userInfoVO.setLastName(formattedName);
                if (formattedName.length() == 0) {
                    userInfoVO.addErrorMessage("lastNameError", tbResources.getString("lastNameReqErr"));
                }

            } else {
                userInfoVO.addErrorMessage("lastNameError", tbResources.getString("lastNameReqErr"));
                return;
            }
            if (StringUtils.isNotEmpty(userInfoVO.getLastName()) && !TBUtil.validateName(userInfoVO.getLastName())) {
                userInfoVO.addErrorMessage("lastNameError", "Last name " + tbResources.getString("nameFieldSpclCharErr"));

            }

        } else if ("middleName".equals(fieldId)) {

            if (StringUtils.isNotEmpty(userInfoVO.getMiddleName())) {
                String middleName = userInfoVO.getMiddleName();
                if (middleName.length() > 50) {

                    userInfoVO.addErrorMessage("middleNameError", "Middle name " + tbResources.getString("nameLengthErr"));

                }
                formattedName = trimAndTruncateSpaces(middleName);
                userInfoVO.setMiddleName(formattedName);
                if (formattedName.length() == 0) {
                    userInfoVO.addErrorMessage("middleNameError", tbResources.getString("middleNameReqErr"));
                }

            } else {
                userInfoVO.addErrorMessage("middleNameError", tbResources.getString("middleNameReqErr"));
                return;
            }
            if (StringUtils.isNotEmpty(userInfoVO.getMiddleName()) && !TBUtil.validateName(userInfoVO.getMiddleName())) {
                userInfoVO.addErrorMessage("middleNameError",
                        "Middle name " + tbResources.getString("nameFieldSpclCharErr"));

            }

        }

        if (StringUtils.isNotEmpty(userInfoVO.getFirstName()) && StringUtils.isNotEmpty(userInfoVO.getLastName())
                && StringUtils.isNotEmpty(userInfoVO.getEmailAddress())) {
            checkUserExistsWithNameAndEmail(userInfoVO);
        }
    }

    private String trimAndTruncateSpaces(String name) {
        String formattedName = null;
        formattedName = name.trim().replaceAll(" +", " ");
        return formattedName;
    }

    public void validateEmail(UserInfoVO userInfoVO) {

        ValidationData validationData = ValidationData.builder().addSecurityQuestions(userInfoVO.getSecurityQuestionVO());
        validationData.setEmail(userInfoVO.getEmailAddress());
        if (null != userInfoVO.getRpAppVO()) {
            validationData = validationData.allowSharedEmail(userInfoVO.getRpAppVO().isEmailShared());
        }
        validateEmail(validationData);

        if (validationData.isShowSecQuestions()) {
            userInfoVO.setShowSecQuestionBasedonSharedEmail(true);
        }
        if (validationData.getErrorMap() != null) {
            userInfoVO.getErrorMap().putAll(validationData.getErrorMap());
        }
        if (validationData.getNotificationMap() != null) {
            userInfoVO.getNotificationMap().putAll(validationData.getNotificationMap());
        }

    }

    /**
     * This method validates email for against iam-commons standard. It also
     * checks if the given email is shared email and whether it is allowed or
     * not based on RP context. Use this method for primary email validations
     *
     * @param validationData ValidationData
     */
    public void validateEmail(ValidationData validationData) {

        String email = validationData.getEmail();
        boolean allowSharedEmail = validationData.isSharedEmailAllowedInRP();
        if (!TBUtil.validateEmailId(email)) {
            validationData.addErrorMessage("email", tbResources.getString("formatErrorField"));

        } else {
            boolean isSharedEmail = userService.isEmailExists(email);
            validationData.setSharedEmail(isSharedEmail);
            if (!allowSharedEmail && isSharedEmail) {
                validationData.addErrorMessage("email", tbResources.getString("rpDoNotDuplicateEmail"));
            } else if (allowSharedEmail && isSharedEmail) {
                validationData.addNotificationMessage("sharedEmail", "true");
                validationData.setShowSecQuestions(true);
            }
        }

    }

    /**
     * This method only validates email against iam-commons standard. It will
     * not check whether it is a shared email or not. Use this method for
     * secondary email validations
     *
     * @param email String
     */
    public String validateEmail(String email) {
        String errorMsg = null;
        if (!TBUtil.validateEmailId(email)) {
            errorMsg = tbResources.getString("invalidEmailAddress");
        }
        return errorMsg;
    }

    public void validatePwd(UserInfoVO userInfoVO) {

        String password = userInfoVO.getPwd();

        /* check for empty pwd */
        if (StringUtils.isEmpty(password)) {
            userInfoVO.addErrorMessage(PWD_KEY, tbResources.getString("pwdRequired"));
            return;
        }

        /* check for pwd and confirmPwd match */
        if (!password.equals(userInfoVO.getConfirmPwd())) {
            userInfoVO.addErrorMessage("confirmPwd", tbResources.getString("pwdNotMatch"));
            return;
        }

        /* check for username in pwd */
        if (password.toLowerCase().contains(userInfoVO.getUserName().toLowerCase())) {
            userInfoVO.addErrorMessage(PWD_KEY, tbResources.getString("pwdCannotContainUsernameNextGen"));
            return;
        }

        /* check for ampersand */
        if (containsWhiteSpace(password) || password.contains(TrustBrokerWebAppConstants.PWD_INVALID_SPL_CHAR)) {
            userInfoVO.addErrorMessage(PWD_KEY, tbResources.getString("pwdMustMeetRequirement"));
            return;
        }

        /* check for blacklisted pwds */
        if (!TBUtil.validateBlackListedPassword(password)) {
            userInfoVO.addErrorMessage(PWD_KEY, tbResources.getString("blackListedPasswordMsg"));
        }

        /* check for valid chars */
        if (!TBUtil.validateName(password)) {
            userInfoVO.addErrorMessage(PWD_KEY, tbResources.getString("pwdMustMeetRequirement"));
            return;
        }

        /* check for pwd strength */
        if (!TBUtil.isPwdStrengthValidNextGen(password)) {
            userInfoVO.addErrorMessage(PWD_KEY, tbResources.getString("pwdMustMeetRequirement"));
        }

    }

    /**
     * This method validates security questions and answers
     *
     * @param userInfoVO userInfoVO
     */
    public void validateSecurityInfo(UserInfoVO userInfoVO) {

        ValidationData validationData = ValidationData.builder().addSecurityQuestions(userInfoVO.getSecurityQuestionVO());
        validateSecurityInfo(validationData);
        if (validationData.getErrorMap() != null) {
            userInfoVO.getErrorMap().putAll(validationData.getErrorMap());
        }

    }

    /**
     * This method validates security questions and answers
     *
     * @param validationData ValidationData
     */
    public void validateSecurityInfo(ValidationData validationData) {

        if (validationData.getSecurityQuestionVO() != null) {

            SecurityQuestionVO securityQuestionVO = validationData.getSecurityQuestionVO();

            String secQues1 = securityQuestionVO.getQuestionOne();
            String secQues2 = securityQuestionVO.getQuestionTwo();
            String secQues3 = securityQuestionVO.getQuestionThree();
            String secAns1 = securityQuestionVO.getAnsOne();
            String secAns2 = securityQuestionVO.getAnsTwo();
            String secAns3 = securityQuestionVO.getAnsThree();

            if (StringUtils.isNotBlank(secQues1) && StringUtils.isNotBlank(secQues2) && StringUtils.isNotBlank(secQues3)
                    && StringUtils.isNotBlank(secAns1) && StringUtils.isNotBlank(secAns2)
                    && StringUtils.isNotBlank(secAns3)) {

                boolean sameAnswer = false;
                /* Checking whether ans1, ans2 and ans3 are same or not */
                if (secAns1.equalsIgnoreCase(secAns2) && secAns2.equalsIgnoreCase(secAns3)) {
                    sameAnswer = true;
                }

                /* Validating security answers against the rules */
                validateAnswer(secQues1, secAns1, sameAnswer, "secAns1ErrorMsg", validationData);
                validateAnswer(secQues2, secAns2, sameAnswer, "secAns2ErrorMsg", validationData);
                validateAnswer(secQues3, secAns3, sameAnswer, "secAns3ErrorMsg", validationData);
            }

        }
    }

    /**
     * This methods validates the existence of security questions and answers.
     * Use this method to do field-required-type validations for security
     * questions and answers
     *
     * @param validationData ValidationData
     */
    public boolean validateSecurityQstns(ValidationData validationData) {

        int count = 0;

        if (validationData.getSecurityQuestionVO() != null) {

            SecurityQuestionVO securityQuestionVO = validationData.getSecurityQuestionVO();

            String secQues1 = securityQuestionVO.getId1();
            String secQues2 = securityQuestionVO.getId2();
            String secQues3 = securityQuestionVO.getId3();
            String secAns1 = securityQuestionVO.getAnsOne();
            String secAns2 = securityQuestionVO.getAnsTwo();
            String secAns3 = securityQuestionVO.getAnsThree();

            String errorMsg = tbResources.getString("securityQuestion123");
            if (StringUtils.isBlank(secQues1) || StringUtils.isBlank(secAns1)) {
                validationData.addErrorMessage("secQstn1", errorMsg);
                count++;
            }
            if (StringUtils.isBlank(secQues2) || StringUtils.isBlank(secAns2)) {
                validationData.addErrorMessage("secQstn2", errorMsg);
                count++;
            }
            if (StringUtils.isBlank(secQues3) || StringUtils.isBlank(secAns3)) {
                validationData.addErrorMessage("secQstn3", errorMsg);
                count++;
            }
        } else {

            String errorMsg = tbResources.getString("securityQuestion123");
            validationData.addErrorMessage("secQstn1", errorMsg);
            validationData.addErrorMessage("secQstn2", errorMsg);
            validationData.addErrorMessage("secQstn3", errorMsg);
            count = 3;
        }

        return count == 0 ? true : false;

    }

    /**
     * This methods validates mobile phone number. 1) checks if number is 12
     * digits in 555-555-5555 format 2) checks if all characters are numbers
     *
     * @param validationData ValidationData
     */
    public void validateMobile(ValidationData validationData) {

        String mobileNo = validationData.getPhoneNo();
        if (StringUtils.isNotBlank(mobileNo)) {
            boolean isMobileInvalid = false;
            if (mobileNo.length() != 12) {
                isMobileInvalid = true;
            } else if (StringUtils.countMatches(mobileNo, "-") != 2) {
                isMobileInvalid = true;
            } else {
                if (!(mobileNo.indexOf("-") == 3 && mobileNo.lastIndexOf("-") == 7)) {
                    isMobileInvalid = true;
                } else {
                    String number = mobileNo.replace("-", "");
                    if (!StringUtils.isNumeric(number)) {
                        isMobileInvalid = true;
                    }
                }
            }
            if (isMobileInvalid) {
                validationData.addErrorMessage("phoneNo", tbResources.getString("invalidMobileMsg"));
            }
        }
    }

    /**
     * This method checks whether the security answer contains 1) user has
     * entered all answers are same and contains text from questions 2) text
     * from security question 3) user has entered all answers as same 4) answer
     * has obscene text
     *
     * @param secQues Security Questions
     * @param secAns Security Answer
     * @param allAnswersAreSame all the answers are same
     * @param secAnsErrorKey security answer error key name
     * @param validationData validationData
     */
    private void validateAnswer(String secQues, String secAns, boolean allAnswersAreSame, String secAnsErrorKey,
            ValidationData validationData) {
        String errorMsg = "";
        secQues = secQues.toLowerCase();
        secAns = secAns.toLowerCase();

        if (secQues.contains(secAns) && allAnswersAreSame) {
            errorMsg = tbResources.getString("secAnswerRules");
        } else if (secQues.contains(secAns)) {
            errorMsg = tbResources.getString("secAnsCannotIncludeWordFromques");
        } else if (allAnswersAreSame) {
            errorMsg = tbResources.getString("secAnsMustBeDiff");
        }

        if (!TBUtil.validateSecurityAnswer(secAns)) {
            errorMsg = tbResources.getString("obsceneTextInAnswer");
        }

        if (StringUtils.isNotBlank(errorMsg)) {
            validationData.addErrorMessage(secAnsErrorKey, errorMsg);
        }

    }

    public void validateYOB(UserInfoVO userInfoVO) {

        boolean isCoppaReq = true;
        if (userInfoVO.getRpAppVO().getAppId() != null && !userInfoVO.getRpAppVO().isCoppaValidationReqd()) {
            isCoppaReq = false;
        }
        if ((userInfoVO.getRpAppVO().getAppId() != null && userInfoVO.getRpAppVO().isShowDob())) {
            return;
        }

        boolean isYearValid;
        isYearValid = validateYobFormat(userInfoVO);
        if (!isYearValid) {
            return;
        }

        boolean isLimitStillValid = checkYearOfBirthEntryLimit(userInfoVO);

        if (isLimitStillValid) {
            SimpleDateFormat yearformat = new SimpleDateFormat(DateUtil.YEAR_FORMAT);
            Integer ageDifference = DateUtil.validateAge(userInfoVO.getYearOfBirth(), MIN_AGE_LIMIT, yearformat);
            if (ageDifference != DateUtil.OVERAGE) {
                if (isCoppaReq) {
                    userInfoVO.setCoppaCount(userInfoVO.getCoppaCount() + 1);
                }
                isLimitStillValid = checkYearOfBirthEntryLimit(userInfoVO);
                if (isLimitStillValid) {
                    if (ageDifference == DateUtil.OVERAGEEXEEDED) {
                        userInfoVO.addErrorMessage("yobErrorMsg", tbResources.getString("yobAgeConstraintOverMsg"));
                    } else if (ageDifference == DateUtil.FUTURE) {
                        userInfoVO.addErrorMessage("yobErrorMsg", tbResources.getString("yobAgeLimitMsg"));
                    } else if (isCoppaReq) {
                        userInfoVO.addErrorMessage("yobErrorMsg", tbResources.getString("yobAgeLimitMsg"));
                    }
                }

            }
        }
    }

    public void validateDOB(UserInfoVO userInfoVO) {
        boolean isValid = validateDateFormat(userInfoVO);

        if (!isValid) {
            return;
        }

        boolean isCoppaReq = true;
        if (userInfoVO.getRpAppVO().getAppId() != null && !userInfoVO.getRpAppVO().isCoppaValidationReqd()) {
            isCoppaReq = false;
        }

        if (isCoppaReq) {
            isValid = validateCoppa(userInfoVO, isCoppaReq);
        }

    }

    private boolean validateDateFormat(UserInfoVO userInfoVO) {

        // check if date entered is in future
        boolean resultDobFuture = DateUtil.validateDateFuture(userInfoVO.getDateOfBirth());
        if (!resultDobFuture && StringUtils.isNotBlank(userInfoVO.getDateOfBirth())) {
            boolean isValid = resultDobFuture;
            // Date must be in the past
            userInfoVO.addErrorMessage("dobErrorMsg", tbResources.getString("dobFutureErrorMsg508"));
            return isValid; // no need to check it further
        }

        // check if date entered is earlier than 01-Jan-1890
        boolean resultDobPast = DateUtil.validateDatePast(userInfoVO.getDateOfBirth());
        if (!resultDobPast && StringUtils.isNotBlank(userInfoVO.getDateOfBirth())) {
            boolean isValid = resultDobPast;
            // Date must be in the past
            userInfoVO.addErrorMessage("dobErrorMsg", tbResources.getString("dobPastErrorMsg508"));
            return isValid; // no need to check it further
        }

        // all validations have been successful till now
        return true;

    }

    private boolean validateCoppa(UserInfoVO userInfoVO, boolean coppaRequired) {

        boolean maxAttemptsRemaining = checkYearOfBirthEntryLimit(userInfoVO);
        if (!maxAttemptsRemaining) {
            return false;
        }

        if (coppaRequired == true && checkYearOfBirthEntryLimit(userInfoVO)) {

            boolean isValid = DateUtil.validateAgeMultipleFormats(userInfoVO.getDateOfBirth(), MIN_AGE_LIMIT);

            if (isValid == false) {
                userInfoVO.addErrorMessage("dobErrorMsg", tbResources.getString("dobAgeLimitMsg"));
                userInfoVO.setCoppaCount(userInfoVO.getCoppaCount() + 1);
                return false;
            }

        }
        return true;
    }

    public boolean validateYobFormat(UserInfoVO userInfoVO) {

        boolean valid = true;
        Integer yob = -1;
        try {
            String yobStr = userInfoVO.getYearOfBirth();

            if (StringUtils.isEmpty(yobStr)) {
                userInfoVO.addErrorMessage("yobErrorMsg", tbResources.getString("yobReq"));
                valid = false;
                return valid;
            }
            if (yobStr.length() < 4) {
                userInfoVO.addErrorMessage("yobErrorMsg", tbResources.getString("yobFormatErrorMsg"));
                valid = false;
                return valid;
            }
            
            yob = Integer.parseInt(yobStr);
            
            /*
             * For YOB 140 years validation
             * */
            Calendar now = Calendar.getInstance();
            int cYear = now.get(Calendar.YEAR);
            if(cYear - yob > 140){
            	userInfoVO.addErrorMessage("yobErrorMsg", tbResources.getString("dobPastErrorMsg508"));
                valid = false;
                return valid;
            }
            
            if (yob != -1) {
                SimpleDateFormat yearformat = new SimpleDateFormat(DateUtil.YEAR_FORMAT);
                yearformat.parse(yobStr);
            }
        } catch (ParseException e) {
            LOGGER.debug("caught exception parsing year of birth. e: " + e);
            userInfoVO.addErrorMessage("yobErrorMsg", tbResources.getString("yobReq"));
            valid = false;
        }
        return valid;
    }

    public boolean checkForReqErrorInSecurityQuestions(UserInfoVO userInfoVO, Map<String, String> errorMap) {

        SecurityQuestionVO secQuesVO = userInfoVO.getSecurityQuestionVO();

        if (secQuesVO != null) {
            if (StringUtils.isEmpty(secQuesVO.getQuestionOne())) {
                errorMap.put(SEC_QUES_1, tbResources.getString("secQueOneReq"));
            }

            if (StringUtils.isEmpty(secQuesVO.getQuestionTwo())) {
                errorMap.put(SEC_QUES_2, tbResources.getString("secQueTwoReq"));
            }
            if (StringUtils.isEmpty(secQuesVO.getQuestionThree())) {
                errorMap.put(SEC_QUES_3, tbResources.getString("secQueThreeReq"));
            }

            if (StringUtils.isEmpty(secQuesVO.getAnsOne())) {
                errorMap.put(SEC_ANS_1, tbResources.getString("secAnsOneReq"));
            }

            if (StringUtils.isEmpty(secQuesVO.getAnsTwo())) {
                errorMap.put(SEC_ANS_2, tbResources.getString("secAnsTwoReq"));
            }

            if (StringUtils.isEmpty(secQuesVO.getAnsThree())) {
                errorMap.put(SEC_ANS_3, tbResources.getString("secAnsThreeReq"));
            }
        }
        if (errorMap.size() == 6) {
            return false;
        }
        return true;
    }

    private boolean checkYearOfBirthEntryLimit(UserInfoVO userInfoVO) {
        Integer yobCount = userInfoVO.getCoppaCount();
        if (yobCount >= COPPA_ENTRY_LIMIT) {
            String idStr = "yobErrorExceededMsg";
            if (null != userInfoVO.getRpAppVO().getAppId() && userInfoVO.getRpAppVO().isShowDob()) {
                idStr = "dobErrorExceededMsg";
            }
            userInfoVO.addErrorMessage(idStr,
                    TBUtil.formatMessage(tbResources.getString("ageNotElibleMsg"),
                            new String[] {getWebApplicationCommonUtilities().getApplicationSupportContactInformation(true)
                                    .getContactComboText()}));
            return false;
        } else {
            return true;
        }
    }

    public UserService getUserService() {
        return userService;
    }

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    /**
     * This method returns the webApplicationCommonUtilities.
     *
     * @return the webApplicationCommonUtilities
     */
    public WebApplicationCommonUtilities getWebApplicationCommonUtilities() {
        return webApplicationCommonUtilities;
    }

    /**
     * This method sets the given webApplicationCommonUtilities value to webApplicationCommonUtilities.
     *
     * @param webApplicationCommonUtilities the webApplicationCommonUtilities to set
     */
    public void setWebApplicationCommonUtilities(WebApplicationCommonUtilities webApplicationCommonUtilities) {
        this.webApplicationCommonUtilities = webApplicationCommonUtilities;
    }
}
