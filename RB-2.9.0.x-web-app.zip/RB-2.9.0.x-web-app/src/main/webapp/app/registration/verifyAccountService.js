'use strict';

angular.module('indexApp').service('verifyAccountService',function($http){
	
this.verifyEmailViaLink=function(verificationToken){
		
		return $http.post("/tb/services/rest/confirmationEmail/verifyLink",verificationToken);
		
	};
	
	this.resendEmail=function(verificationToken){
		
		return $http.post('/tb/services/rest/confirmationEmail/resendEmail',verificationToken);
		
	};
	
});

