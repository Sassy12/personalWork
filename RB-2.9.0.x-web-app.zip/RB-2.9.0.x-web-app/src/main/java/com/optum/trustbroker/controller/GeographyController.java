package com.optum.trustbroker.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.controller.vo.LabelValueVO;
import com.optum.trustbroker.controller.vo.StatesVO;
import com.optum.trustbroker.service.ReferenceService;

@Service
@Path(TBConstants.STATES_CONTROLLER_PATH)
public class GeographyController extends BaseController {
    @Autowired
    private ReferenceService referenceService;

    /**
     * get state list
     *
     * @return StatesVO
     */
    @SuppressWarnings("unchecked")
	@GET
    @Path(value = "/")
    @Produces(MediaType.APPLICATION_JSON)
    public StatesVO getStateList() {
    	StatesVO statesVo = new StatesVO();
    	statesVo.setLabelValueVOList(new ArrayList<LabelValueVO>());
        Map<String, String> states = referenceService.fetchStates();
        for (String key : states.keySet()) {
            LabelValueVO labelValueVO = new LabelValueVO();
            labelValueVO.setValue(key);
            labelValueVO.setLabel(key);
            statesVo.getLabelValueVOList().add(labelValueVO);
            Collections.sort(statesVo.getLabelValueVOList());
        }
        return statesVo;
    }
}