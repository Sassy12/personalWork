/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 *
 */
'use strict';
angular.module('indexApp').controller('linkExpiredCtrl',linkExpiredCtrl);

linkExpiredCtrl.$inject =['$scope', 'trustbrokerAriaService', '$state', 'LanguageService','mainMessage', 'pageHeader','isRPContextExist', 'HelpObj'];

function linkExpiredCtrl($scope, trustbrokerAriaService, $state, LanguageService, mainMessage, pageHeader, isRPContextExist, HelpObj){
	
	HelpObj.setHelpObj({url:'../webHelp/Default_CSH.htm#Optum ID CSH/entry_1035_Reset_Password_Verification_Link_Expired.htm'});
	
	$scope.setFieldValidity = function(inputid, spanid){
		trustbrokerAriaService.setFieldValidity(inputid, spanid);	
	};
	LanguageService.doTranslate("selfservice");

	$scope.lep={};
	$scope.lepmainMsg = mainMessage.message;
	$scope.lep.expLinkTitle = pageHeader;
	$scope.lep.retBtnLabel = "RET_SIGIN";
	$scope.lep.isRPContextExist = (isRPContextExist === "true")? true:false;
		
	$scope.lep.retBtnClick = function(){
		$state.go("login");
	};
	
}