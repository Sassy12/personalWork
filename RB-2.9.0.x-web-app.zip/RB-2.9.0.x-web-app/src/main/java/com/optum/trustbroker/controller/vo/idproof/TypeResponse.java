/*
 * Copyright 2016 Optum
 */
package com.optum.trustbroker.controller.vo.idproof;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.optum.trustbroker.controller.vo.ResponseVO;

/**
 * @author nvaneps
 */
@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class TypeResponse extends ResponseVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
