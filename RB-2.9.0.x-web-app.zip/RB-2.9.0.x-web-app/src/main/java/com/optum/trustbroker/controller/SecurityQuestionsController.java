package com.optum.trustbroker.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.LabelValueVO;
import com.optum.trustbroker.controller.vo.SecurityQuestionVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.helpers.UserHelper;
import com.optum.trustbroker.service.ConfigurationService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.ValidationUtils;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@Path(TBConstants.SET_SQA_CONTROLLER_PATH)
public class SecurityQuestionsController extends BaseController {

    private static final BaseLogger logger = new BaseLogger(SecurityQuestionsController.class);

    @Autowired
    private ConfigurationService configService;

    @Autowired
    private ValidationUtils validationUtils;

    @Autowired
    private UserService userService;

    @Autowired
    private CommonController commonController;

    @GET
    @Path(value = "/fetchSecQns")
    @Produces(MediaType.APPLICATION_JSON)
    public SecurityQuestionVO getSecurityQuestions() {
        ChallengeQuestionServiceResponse challengeQuestionServiceResponse = configService.getSecurityQuestions();
        List<LabelValueVO> quesLists = createSecQuestionsModel(challengeQuestionServiceResponse.getUserChallengeQuestions());
        SecurityQuestionVO secQuesVO = new SecurityQuestionVO();
        secQuesVO.setQuestions(quesLists);
        return secQuesVO;
    }

    @Path(value = "/addSecQns")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public UserInfoVO setSecurityQuestions(UserInfoVO userInfoVO, @Context HttpServletRequest request) {

        WebApplicationContext ctx = WebApplicationContextHolder.getContext();

        String authCode = ctx.getSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_AUTH_CODE);

        UserInfoVO userInfo = commonController.getUsernameFromAuthCode(authCode);
        String validatedUser = ctx.getSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN);

        if ((StringUtils.isEmpty(authCode) && StringUtils.isEmpty(validatedUser))
                || (StringUtils.isNotEmpty(authCode) && !userInfo.isAuthCodeValid())
                || (validatedUser != null && !userInfo.getUserName().equalsIgnoreCase(validatedUser))) {
            userInfoVO.getErrorMap().put("responseStatus", getBundle().getString("resetProfileError"));
            return userInfoVO;
        }
        //Adding a check where the UI did not give security questions and answers at all.
        if (userInfoVO.getSecurityQuestionVO() == null) {
            userInfoVO.getErrorMap().put("responseStatus", getBundle().getString("resetProfileError"));
            return userInfoVO;
        }
        validationUtils.validateSecurityInfo(userInfoVO);

        if (null != userInfoVO.getErrorMap() && !userInfoVO.getErrorMap().isEmpty()) {
            return userInfoVO;
        }

        UserVO userVO = userService.fetchUserProfile(userInfo.getUserName(), false, true).getUser();

        UserHelper.updateUserVOWithSecurityQuestions(userVO, userInfoVO.getSecurityQuestionVO());

        UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
        userProfileServiceRequest.setUser(userVO);

        UserProfileServiceResponse userProfileServiceResponse = userService
                .modifyUserSecurityQuestions(userProfileServiceRequest);
        if (!TrustbrokerWebAppUtil.checkResponseStatus(userProfileServiceResponse)) {
            userInfoVO.getErrorMap().put("responseStatus", userProfileServiceResponse.getReasonMessage());
            return userInfoVO;
        } else {
            logger.info("setSecurityQuestions successfull exit");
            userInfoVO.setNextState("login");
        }

        if (StringUtils.isNotEmpty(authCode)) {
            userService.invalidateUserAuthCode(authCode);
            SecurityLoggingUtil.info("SetSecurity Questions ", SecurityEventType.E3_MODIFY, request, userInfo.getUserName(),
                    "Security Audit Event|setSecurityQuestions:SUCCESS|Authorization Code Processed ,"
                            + "ResetSecurityCredentialsBean:setSecurityQuestions()",
                    SecurityEventResult.SUCCESS, ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),
                    SecuritySubEventType.E3_MODIFY_SECURITY_QUESTIONS);
            ctx.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_AUTH_CODE);
        }
        ctx.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN);
        return userInfoVO;

    }

    @Override
    public ConfigurationService getConfigService() {
        return configService;
    }

    @Override
    public void setConfigService(ConfigurationService configService) {
        this.configService = configService;
    }

    public SecurityQuestionsController() {

    }

    public ValidationUtils getValidationUtils() {
        return validationUtils;
    }

    public void setValidationUtils(ValidationUtils validationUtils) {
        this.validationUtils = validationUtils;
    }

    @Override
    public UserService getUserService() {
        return userService;
    }

    @Override
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

}
