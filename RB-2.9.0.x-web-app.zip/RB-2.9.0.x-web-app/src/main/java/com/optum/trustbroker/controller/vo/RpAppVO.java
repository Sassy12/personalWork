package com.optum.trustbroker.controller.vo;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.ALWAYS)
public class RpAppVO implements Serializable {
	private static final long serialVersionUID = 1L;

	private String appId;
	private String targetURL;
	private String failReason;
	private String emailEdit;
	private String alias;
	private String applicationName;
	private boolean coppaValidationReqd;
	private boolean emailShared; 
	private boolean showDob;
	private boolean showQuestions;
	private boolean rsaRequired;
	private boolean emailUnique;
	private String tierId;
	private boolean emailConfirmationRequired;
	
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getTargetURL() {
		return targetURL;
	}
	public void setTargetURL(String targetURL) {
		this.targetURL = targetURL;
	}
	public boolean isRsaRequired() {
		return rsaRequired;
	}
	public void setRsaRequired(boolean rsaRequired) {
		this.rsaRequired = rsaRequired;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getFailReason() {
		return failReason;
	}
	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}
	public String getEmailEdit() {
		return emailEdit;
	}
	public void setEmailEdit(String emailEdit) {
		this.emailEdit = emailEdit;
	}
	public boolean isCoppaValidationReqd() {
		return coppaValidationReqd;
	}
	public void setCoppaValidationReqd(boolean coppaValidationReqd) {
		this.coppaValidationReqd = coppaValidationReqd;
	}
	public boolean isEmailShared() {
		return emailShared;
	}
	public void setEmailShared(boolean emailShared) {
		this.emailShared = emailShared;
	}
	public boolean isShowDob() {
		return showDob;
	}
	public void setShowDob(boolean showDob) {
		this.showDob = showDob;
	}
	public boolean isShowQuestions() {
		return showQuestions;
	}
	public void setShowQuestions(boolean showQuestions) {
		this.showQuestions = showQuestions;
	}
	public boolean isEmailUnique() {
		return emailUnique;
	}
	public void setEmailUnique(boolean emailUnique) {
		this.emailUnique = emailUnique;
	}
	public String getTierId() {
		return tierId;
	}
	public void setTierId(String tierId) {
		this.tierId = tierId;
	}
	public boolean isEmailConfirmationRequired() {
		return emailConfirmationRequired;
	}
	public void setEmailConfirmationRequired(boolean emailConfirmationRequired) {
		this.emailConfirmationRequired = emailConfirmationRequired;
	}
	
}
