/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When      Who      Why
 * Jan 29, 2016 bmanna3 Initial version.
 ****************************************************************/
'use strict';
angular.module('indexApp').service('forgotAccessService',['$http', ForgotAccessService]);

function ForgotAccessService($http){
    var email ='';
    var errorFlag = {};
    this.isErrorFlag=function(errorFlag){
         this.errorFlag=errorFlag;
    };
    this.errorFlag=function(){
      return errorFlag;
    };
	this.getUserEmailType= function(requestData){
		email = requestData.email;
		return $http.post('/tb/services/rest/forgotaccess/getuseremailtype', requestData);
	};
	this.verifyuserwithfirstnameandlastname= function(firstName ,lastName){
		return $http.post('/tb/services/rest/forgotaccess/verifyuserwithfirstnameandlastname', {'firstName' : firstName , 'lastName' : lastName , 'email' : email});
	};
	this.findUserWOtherInfo= function(requestData){
		return $http.post('/tb/services/rest/forgotaccess/findunamewothrinfo', requestData);
	};
	this.getUserInfoForAccountRecoveryProcess= function(requestData){
		return $http.post('/tb/services/rest/forgotaccess/getUserInfoForAccountRecoveryProcess', requestData);
	};
	this.sendUserNameByAccountRecovery= function(requestData){
		return $http.post('/tb/services/rest/forgotaccess/sendUserNameByAccountRecovery', requestData);
	};
	this.displayUserNameByVerifyingSecurityQuestion= function(requestData){
		return $http.post('/tb/services/rest/forgotaccess/displayUserNameByVerifyingSecurityQuestion', requestData);
	};
	this.findPwdWMoreInfo= function(requestData){
	    return $http.post('/tb/services/rest/forgotaccess/findpwdwusername', requestData);
	};
	this.sendResetPasswordByEmail= function(requestData){
	    return $http.post('/tb/services/rest/forgotaccess/sendResetPasswordByEmail', requestData);
	};
	this.sendPhoneOTP= function(requestData){
	    return $http.post('/tb/services/rest/forgotaccess/sendPhoneOTP', requestData);
	};
	this.resendSQASetUpEmailToUser = function(userInfo){
		return $http.post('/tb/services/rest/forgotaccess/sendSQAAuthorizationLink', userInfo);
	};
	this.getCurrentWorkflowId= function(){
		return $http.get('/tb/services/rest/commonController/getCurrentWorkflowId');
	};
	this.returnVerifyIdentityStatus= function(){
        return $http.get('/tb/services/rest/commonController/returnVerifyIdentityStatus');
    };
}
