/*******************************************************************************
 * Copyright (c) 2012 Optum - All Rights Reserved.
 ******************************************************************************/
package com.optum.trustbroker.managebean;

import java.io.IOException;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserVO;

@ManagedBean(name = "updateConfirmEmailBean")
@RequestScoped
public class UpdateConfirmEmailBean extends AbstractBackingBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManagedProperty(value = "#{verifyCodesBean}")
	private VerifyCodesBean verifyCodesBean;	

	@ManagedProperty(value = "#{userVO}")
	private UserVO userVO;

	private String confirmCode;

	private String pwd;

	BaseLogger logger = new BaseLogger(UpdateConfirmEmailBean.class);

	String updateSecurityPage = "updatesecurityquestions.jsf?upf=";

	private String errorMessage = "";

	@PostConstruct
	public void init() {
		// setPasswordChangeSuccessMsg("Password is changed successfully");
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}


	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	/**
	 * Request Handler[POST] for ChangePassword page.
	 *
	 * The form fields are validated and changePassword method is called.
	 *
	 *
	 * @return the string - Change Password success page URL otherwise returns
	 *         null [appropriate face error message is set]
	 */

	public String doNavigation() {
		
		boolean result = false;
		// Validate form fields
		// fetch the user profile to validate the old password
		String oldpwd = userVO.getPassword();
		userVO = getCurrentUserVO();

		return null;
	}


	public String getConfirmCode() {
		return confirmCode;
	}

	public void setConfirmCode(String confirmCode) {
		this.confirmCode = confirmCode;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String confirmEmail() throws IOException {
		try {
			if(StringUtils.isNotEmpty(confirmCode))
				confirmCode = confirmCode.trim();
			// TODO
			getVerifyCodesBean().verify();
			
			if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF) != null){
				redirectToRelyingParty((String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF),
						TrustBrokerWebAppConstants.UPDATE_PROFILE, TrustBrokerWebAppConstants.SUCCESS,
						(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
				return null;
			}
		} catch (OperationFailedException exception) {
			getFacesContext().getExternalContext().redirect(updateSecurityPage+"f");
			return null;
		}
		getFacesContext().getExternalContext().redirect(updateSecurityPage+"s");
		return null;
	}

	/**
	 * Gets the faces context
	 *
	 * @return current FacesContext otherwise
	 */
	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	public VerifyCodesBean getVerifyCodesBean() {
		return verifyCodesBean;
	}

	public void setVerifyCodesBean(VerifyCodesBean verifyCodesBean) {
		this.verifyCodesBean = verifyCodesBean;
	}

}
