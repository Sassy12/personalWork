package com.optum.trustbroker.controller.vo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class SecurityQuestionVO {
	
	private List<LabelValueVO> questions;
	
	private String questionOne;
	private String questionTwo;
	private String questionThree;
	private String ansOne;
	private String ansTwo;
	private String ansThree;
	
	private String id1;
	private String id2;
	private String id3;
	

	
	public String getQuestionOne() {
		return questionOne;
	}

	public void setQuestionOne(String questionOne) {
		this.questionOne = questionOne;
	}

	public String getQuestionTwo() {
		return questionTwo;
	}

	public void setQuestionTwo(String questionTwo) {
		this.questionTwo = questionTwo;
	}

	public String getQuestionThree() {
		return questionThree;
	}

	public void setQuestionThree(String questionThree) {
		this.questionThree = questionThree;
	}

	public String getAnsOne() {
		return ansOne;
	}

	public void setAnsOne(String ansOne) {
		this.ansOne = ansOne;
	}

	public String getAnsTwo() {
		return ansTwo;
	}

	public void setAnsTwo(String ansTwo) {
		this.ansTwo = ansTwo;
	}

	public String getAnsThree() {
		return ansThree;
	}

	public void setAnsThree(String ansThree) {
		this.ansThree = ansThree;
	}

	public List<LabelValueVO> getQuestions() {
		return questions;
	}

	public void setQuestions(List<LabelValueVO> questions) {
		this.questions = questions;
	}

	public String getId1() {
		return id1;
	}

	public void setId1(String id1) {
		this.id1 = id1;
	}

	public String getId2() {
		return id2;
	}

	public void setId2(String id2) {
		this.id2 = id2;
	}

	public String getId3() {
		return id3;
	}

	public void setId3(String id3) {
		this.id3 = id3;
	}

}