/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 *
 */
'use strict';
angular.module('indexApp').service('mobileVerificationService',['$http', MobileVerificationService]);

function MobileVerificationService($http){

	this.resendOtp =function(formData){
		return $http.post('/tb/services/rest/mobileOtp/sendAnotherOTP', formData);
	};
	
	this.submitForm =function(formData){
		return $http.post('/tb/services/rest/mobileOtp/confirmOTP', formData);
	};

}