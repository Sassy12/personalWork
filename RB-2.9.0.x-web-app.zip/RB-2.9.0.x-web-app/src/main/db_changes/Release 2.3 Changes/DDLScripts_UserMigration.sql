/*creating the new table(user_migration_data)*/
create table user_migration_data
(
    ID number,
    uuid varchar2(64) not null,
    migration_status_cd varchar2(1) default 'I' not null,
    created_ts timestamp,
    modified_ts timestamp,
    EXCEPTION_MSG varchar2(100),
    primary key (ID)
);
/*creating the sequence for user_migration_data table*/
create sequence SEQ_MGN_DTA_ID
  CACHE 500;
  
/*creating the indexes for user_migration_data table*/
create index IDX_user_migration_data_1 ON
        user_migration_data (uuid);
create index IDX_user_migration_data_2 ON
        user_migration_data (migration_status_cd);


/*Trigger for user_migration_data */     
 CREATE OR REPLACE TRIGGER TRG_MGN_USR_DTA_UUIDS_INSERT
BEFORE INSERT ON user_migration_data
FOR EACH ROW
BEGIN
    :NEW.ID := SEQ_MGN_DTA_ID.NEXTVAL;
    :NEW.created_ts := sysdate;
    :NEW.modified_ts := sysdate;
END TRG_MGN_USR_DTA_UUIDS_INSERT;

/*Trigger for updating the user_migration_data table */     
CREATE OR REPLACE TRIGGER TRG_MGN_USR_DTA_UUIDS_UPDATE
BEFORE UPDATE ON user_migration_data
FOR EACH ROW
BEGIN
    :NEW.modified_ts := sysdate;
END TRG_MGN_USR_DTA_UUIDS_UPDATE;


/*Adding migrated_user column to tb_user table*/
ALTER TABLE tb_user
ADD MIGRATED_USER varchar2(1);