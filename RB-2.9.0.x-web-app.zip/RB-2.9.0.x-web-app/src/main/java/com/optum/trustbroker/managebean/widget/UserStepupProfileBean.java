package com.optum.trustbroker.managebean.widget;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.richfaces.event.ItemChangeEvent;

import com.optum.trustbroker.managebean.UserStepUpContext;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.ServiceResponse;
import com.optum.trustbroker.vo.TermsAndConditionsRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserChangePasswordServiceRequest;
import com.optum.trustbroker.vo.UserNameCheckServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.alps.authentication.sm.HttpLoginRequest;
import com.uhg.iam.alps.authentication.sm.LoginRequest;

@ManagedBean(name = "wUserStepupProfileBean")
@SessionScoped
public class UserStepupProfileBean extends AbstractBackingBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private static final String INCORRECT_YEAR_OF_BIRTH_COUNT="_INC_YEAR_OF_BIRTH";
	public static final String INFORMATION_SCREEN = "stepupinformation";
	public static final String CREDENTIALS_SCREEN = "stepupcredentials";
	public static final String QUESTIONS_SCREEN = "stepupquestions";
	
	private final String SECEMAIL_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_SecEmailId");
	private final String MOBILE_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_MobileId");
	private final String SECQUESTS_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_SecQuestId");
	
	BaseLogger logger = new BaseLogger(UserStepupProfileBean.class);
	
	@ManagedProperty(value = "#{userVO}")
	private UserVO userVO;
	@ManagedProperty(value = "#{wSecurityQuestionsBean}")
	private SecurityQuestionsBean tbSecurityQuestionsBean;
	
	private UserStepUpContext stepUpCtx;

	private String lastPage;
	private String errorMsg;
	private String dateOfBirth;
	private String yearOfBirth;
	private String emailAddress;
	private String secEmailAddress;
	private String confirmEmailAddress;
	private String userName;
	private String tempUserName;
	private String password;
	private String confirmPassword;
	private String primaryEmailAddress;
	private String mobilePhone;
	private String informationalText;
	private String currentActiveItem;
	private String currentButtonId;
	private String termsCondition;
	private String passwordStrength;
	private String oldUserName;
	
	private List<String> userNameSuggestionsList;
	private List<String> oldUsernameSuggestionsList;
	private List<String> modifiedUserAttrLst;
	
	
	private boolean validationErrorMessageColor = false;
	private boolean showSuggestions;
	private boolean pwdSpcErrInd = false;
	private boolean confPwdSpcErrInd = false;
	private boolean displaySkipOption;
	private boolean tncAccepted;
	private boolean cancel =false;
	private boolean requiredIndicatorForEmail =false;
	private boolean showSecQuestionBasedonSharedEmail =false;
	private boolean secQuestBasedonSharedEmailActualFlag =false;
	private boolean suggestion =false;
	private boolean suggestionHeader =false;
	
	
	private static int yobLimit=2;
    private int accessCount =0;
    private int questionOne=2;
	private int questionTwo=2;
	private int questionThree=2;
	private int ansOne=2;
	private int ansTwo=2;
	private int ansThree=2;
	
	private String emailOrDash;
	
	private List<SelectItem> acctRecoveryMethods = new ArrayList<SelectItem>();
	private String acctRecoveryMethod;
	
	public String getAcctRecoveryMethod() {
		return acctRecoveryMethod;
	}

	public void setAcctRecoveryMethod(String acctRecoveryMethod) {
		this.acctRecoveryMethod = acctRecoveryMethod;
	}

	public List<SelectItem> getAcctRecoveryMethods() {
		return acctRecoveryMethods;
	}

	public void setAcctRecoveryMethods(List<SelectItem> acctRecoveryMethods) {
		this.acctRecoveryMethods = acctRecoveryMethods;
	}

	public boolean isSuggestion() {
		return suggestion;
	}

	public void setSuggestion(boolean suggestion) {
		this.suggestion = suggestion;
	}

	public boolean isSuggestionHeader() {
		return suggestionHeader;
	}

	public void setSuggestionHeader(boolean suggestionHeader) {
		this.suggestionHeader = suggestionHeader;
	}


	public boolean isSecQuestBasedonSharedEmailActualFlag() {
		return secQuestBasedonSharedEmailActualFlag;
	}

	public void setSecQuestBasedonSharedEmailActualFlag(
			boolean secQuestBasedonSharedEmailActualFlag) {
		this.secQuestBasedonSharedEmailActualFlag = secQuestBasedonSharedEmailActualFlag;
	}

	public int getQuestionOne() {
		return questionOne;
	}

	public void setQuestionOne(int questionOne) {
		this.questionOne = questionOne;
	}

	public int getQuestionTwo() {
		return questionTwo;
	}

	public void setQuestionTwo(int questionTwo) {
		this.questionTwo = questionTwo;
	}

	public int getQuestionThree() {
		return questionThree;
	}

	public void setQuestionThree(int questionThree) {
		this.questionThree = questionThree;
	}
	public int getAnsOne() {
		return ansOne;
	}

	public void setAnsOne(int ansOne) {
		this.ansOne = ansOne;
	}

	public int getAnsTwo() {
		return ansTwo;
	}

	public void setAnsTwo(int ansTwo) {
		this.ansTwo = ansTwo;
	}

	public int getAnsThree() {
		return ansThree;
	}

	public void setAnsThree(int ansThree) {
		this.ansThree = ansThree;
	}

	public int getAccessCount() {
		return accessCount;
	}

	public void setAccessCount(int accessCount) {
		this.accessCount = accessCount;
	}
	public boolean isShowSecQuestionBasedonSharedEmail() {
		return showSecQuestionBasedonSharedEmail;
	}

	public void setShowSecQuestionBasedonSharedEmail(
			boolean showSecQuestionBasedonSharedEmail) {
		this.showSecQuestionBasedonSharedEmail = showSecQuestionBasedonSharedEmail;
	}

	public boolean isRequiredIndicatorForEmail() {
		return requiredIndicatorForEmail;
	}

	public void setRequiredIndicatorForEmail(boolean requiredIndicatorForEmail) {
		this.requiredIndicatorForEmail = requiredIndicatorForEmail;
	}

	public boolean isCancel() {
		return cancel;
	}

	public void setCancel(boolean cancel) {
		this.cancel = cancel;
	}

	public boolean isValidationErrorMessageColor() {
		return validationErrorMessageColor;
	}

	public void setValidationErrorMessageColor(boolean validationErrorMessageColor) {
		this.validationErrorMessageColor = validationErrorMessageColor;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getPrimaryEmailAddress() {
		return primaryEmailAddress;
	}

	public void setPrimaryEmailAddress(String primaryEmailAddress) {
		this.primaryEmailAddress = primaryEmailAddress;
	}

	public String getConfirmEmailAddress() {
		return confirmEmailAddress;
	}

	public void setConfirmEmailAddress(String confirmEmailAddress) {
		this.confirmEmailAddress = confirmEmailAddress;
	}
	
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	public SecurityQuestionsBean getTbSecurityQuestionsBean() {
		return tbSecurityQuestionsBean;
	}

	public void setTbSecurityQuestionsBean(SecurityQuestionsBean tbSecurityQuestionsBean) {
		this.tbSecurityQuestionsBean = tbSecurityQuestionsBean;
	}

	public String getCurrentActiveItem() {
		return currentActiveItem;
	}

	public void setCurrentActiveItem(String currentActiveItem) {
		this.currentActiveItem = currentActiveItem;
	}

	public String getCurrentButtonId() {
		return currentButtonId;
	}

	public void setCurrentButtonId(String currentButtonId) {
		this.currentButtonId = currentButtonId;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	@PostConstruct
	public void init() {

		try {
			userVO = getCurrentUserVO();
			setStepUpCtx((UserStepUpContext) getSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME));

			ChallengeQuestionServiceResponse challengeQuestionServiceResponse = getContainer().getConfigService().getSecurityQuestions();
			tbSecurityQuestionsBean.setQuestions(challengeQuestionServiceResponse.getUserChallengeQuestions());
			
			setOldUserName(getCurrentUserVO().getUserName());

			// Setting up informational text message and other attributes
			if(getStepUpCtx() != null) validateUserInformationAndSetUpInitialDisplayData();
				
			if (getStepUpCtx() != null && (getStepUpCtx().isDisplayPersonalInformationForStepUp() || getCurrentUserVO().isMigratedUser())) {
				pagesSetup();
			}  else if (checkIfUserAccountRecoveryRequired()) {
				setMobilePhone(userVO.getPhoneNumber());
				buildRecoveryMethods();
				setCurrentActiveItem("useracctrecovery");
				setSecEmailAddress(userVO.getSecEmailAddress());
				if (StringUtils.isNotEmpty(userVO.getEmailAddress())) {
					setDisplaySkipOption(true);
				}
			}
	
			modifiedUserAttrLst = new ArrayList<String>();
		} catch (OperationFailedException ope) {
			logger.error("Exception while initialization user user step up bean - {}",
					new String[] {TrustbrokerWebAppUtil.getUidFromError(ope) }, ope);
			String errMsg = extractErrorMessageFromOFE(ope);
			setErrorMsg(errMsg);
		}
	}
	
	
	public void pagesSetup() {
		if (stepUpCtx.isShowEmail() || stepUpCtx.isShowDob() || stepUpCtx.isShowYOB()) {
			stepUpCtx.setInfoPageDisplayed(true);
		}

		if (stepUpCtx.isShowUserName()|| stepUpCtx.isShowPassword()) {
			stepUpCtx.setCredentialPageDisplayed(true);
		}
		
		if (stepUpCtx.isSecQuestionRequired() || stepUpCtx.isShowSecQuestions()) {
			stepUpCtx.setQuestionsPageDisplayed(true);
		}
		
		if(!stepUpCtx.isInfoPageDisplayed() && !stepUpCtx.isCredentialPageDisplayed() && !stepUpCtx.isQuestionsPageDisplayed()){
			stepUpCtx.setInfoPageDisplayed(true);
		}

		if (stepUpCtx.isInfoPageDisplayed()) {
			setCurrentActiveItem(INFORMATION_SCREEN);
		} else  if (stepUpCtx.isCredentialPageDisplayed()) {
			setCurrentActiveItem(CREDENTIALS_SCREEN);
		} else  if (stepUpCtx.isQuestionsPageDisplayed()){
			setCurrentActiveItem(QUESTIONS_SCREEN);
		}
	
		if(stepUpCtx.isQuestionsPageDisplayed()){
			lastPage = QUESTIONS_SCREEN;
		} else {
			if(stepUpCtx.isCredentialPageDisplayed()) lastPage = CREDENTIALS_SCREEN;
			else lastPage = INFORMATION_SCREEN;
		}
	}
	
	public boolean isLastPage(){
		if(lastPage.equalsIgnoreCase(getCurrentActiveItem())){
			return true;
		} else {
			return false;
		}	
	}
	
	public boolean isBackButton(){
		
		if (getCurrentActiveItem().equalsIgnoreCase(CREDENTIALS_SCREEN)) {
			return stepUpCtx.isInfoPageDisplayed();
		}
		
		if(QUESTIONS_SCREEN.equalsIgnoreCase(getCurrentActiveItem())){
			return (stepUpCtx.isInfoPageDisplayed() || stepUpCtx.isCredentialPageDisplayed());
		}
		
		return false;
	}
	
	
	public void pageChanged(ItemChangeEvent event) {
		
	try{
		if ("backButtonCredentials".equals(getCurrentButtonId())){
			password=null;
			confirmPassword=null;
			setCurrentActiveItem(INFORMATION_SCREEN);
			return;
		}
		
		if ("backButtonQuestions".equals(getCurrentButtonId())) {
	
			
			if(stepUpCtx.isCredentialPageDisplayed()){
				setCurrentActiveItem(CREDENTIALS_SCREEN);
				return;
			}
			
			if(stepUpCtx.isInfoPageDisplayed()){
				setCurrentActiveItem(INFORMATION_SCREEN);
				return;
			}
		}
		if ("saveButtonInfo".equals(getCurrentButtonId())) {
			if(validateInfoPage(modifiedUserAttrLst)){
				setCurrentActiveItem(INFORMATION_SCREEN); return;
			}
		
			if(stepUpCtx.isCredentialPageDisplayed()){
				setCurrentActiveItem(CREDENTIALS_SCREEN); return;
			}
			if(stepUpCtx.isQuestionsPageDisplayed() || showSecQuestionBasedonSharedEmail){
				setCurrentActiveItem(QUESTIONS_SCREEN); return;
			}
			if((INFORMATION_SCREEN.equalsIgnoreCase(lastPage) && !showSecQuestionBasedonSharedEmail)){
				userVO = getCurrentUserVO();
				finalProcess(new UserProfileServiceRequest());
				}
		}
		if ("saveButtonCredentials".equals(getCurrentButtonId())) {
			if(validateCredentialsPage(modifiedUserAttrLst)){
				setCurrentActiveItem(CREDENTIALS_SCREEN); return;
			}
			if(stepUpCtx.isQuestionsPageDisplayed() || showSecQuestionBasedonSharedEmail){
				setCurrentActiveItem(QUESTIONS_SCREEN); return;
			}
			if(( CREDENTIALS_SCREEN.equalsIgnoreCase(lastPage) && !showSecQuestionBasedonSharedEmail)){
				userVO = getCurrentUserVO();
				finalProcess(new UserProfileServiceRequest());
				}
		}
		if ("saveButtonQuestions".equalsIgnoreCase(getCurrentButtonId())) {
			if(validateQuestionsPage(modifiedUserAttrLst)){
				setCurrentActiveItem(QUESTIONS_SCREEN); return;
			}
			userVO = getCurrentUserVO();
			finalProcess(new UserProfileServiceRequest());	
		}} catch (OperationFailedException ofe) {
				logger.error(" An error occureed while updating security questions & answers for user {}",
						new String[] { getCurrentUserVO() != null ? getCurrentUserVO().getUserName():"User not found in session", 
								TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
				setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(
						container.getErrorMessageSource(), getSupportContactInfo()) : ofe.getMessage());
				removeSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME);
				setCurrentActiveItem("failure");
			} catch (Exception e) {
				logger.error(" An error occureed while updating security questions & answers for user {}",
						new String[] { getCurrentUserVO()!= null ? getCurrentUserVO().getUserName():"User not found in session"}, e);
				setErrorMsg("Security Questions & Answers update is unsuccessful");
				removeSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME);
				setCurrentActiveItem("failure");
			}
	
			if ("postAcctRecoveryButton".equalsIgnoreCase(getCurrentButtonId())) {
				
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
				userVO = getCurrentUserVO();
				List<String> modifiedUserAttrLst = new ArrayList<String>();
		
				//validate the account recovery fields			
				if(StringUtils.isEmpty(this.acctRecoveryMethod) || "null".equalsIgnoreCase(this.acctRecoveryMethod)) {
					addFacesMessage("userStepupProfileId:regnRecoveryType",tbResources.getString("regnacctrecoveryMethodReqMsg"));
					setCurrentActiveItem("useracctrecovery");		
					return;
				} else 	if(SECEMAIL_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {				
					if(!validateRecoverySecEmail(getSecEmailAddress())) {
						setCurrentActiveItem("useracctrecovery");
						return;
					}				
					userVO.setEssoSecEmail(userVO.getSecEmailAddress());
				} else if (MOBILE_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {
					
					if(StringUtils.isEmpty(getMobilePhone())) {
						addFacesMessage("userStepupProfileId:mobilenum",tbResources.getString("regnacctrecoveryMobilReqMsg"));
						setCurrentActiveItem("useracctrecovery");
						return;
					}	
					
					if(!validatePhoneAccRecovery()) {
						setCurrentActiveItem("useracctrecovery");
						return;
					}	
					
					userVO.setSecEmailAddress(null);
					userVO.setPhoneNumber(getMobilePhone());
					
					try {
						userVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
						userVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));
						userVO.setSecEmailAddress(userVO.getSecEmailAddress());
						userProfileServiceRequest.setUser(userVO);
						UserVO essoUserVO = container.getUserService().fetchUserProfile(userVO.getUuId(),true, true).getUser();
						userProfileServiceRequest.setOldUser(essoUserVO);
						container.getUserService().modifyUser(userProfileServiceRequest, false);

						VerifyCodesContext ctx = new VerifyCodesContext();
						ctx.getViewChannels().add(CommunicationChannel.PHONE);
						ctx.getSendChannels().add(CommunicationChannel.PHONE);
						
						if(StringUtils.isNotBlank(getCurrentUserVO().getEmailAddress()) && !getCurrentUserVO().isIsemailVerified()) {
							ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
							ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
						}
						
						ctx.setHideUpdateButtons(true);
						ctx.setShowDeviceRegistration(false);
						ctx.setNextView(getWidgetHomeURIWithAlias());
						ctx.setUserVO(userVO);
						getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);	
						if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {
							setErrorMsg("A new confirmation code has been sent to your mobile phone");
							redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
							return;
						}
					} catch (OperationFailedException exception) {
						logger.error("Exception while Updating the phone number during user Post Account Recovery - {}", 
								new String[]{TrustbrokerWebAppUtil.getUidFromError(exception)},exception);
						setCurrentActiveItem("useracctrecovery");
						String emailErrorMsg = extractErrorMessageFromOFE(exception);
						if (null != emailErrorMsg) setErrorMsg(emailErrorMsg);
						else setErrorMsg(tbResources.getString("emailVerificationFailed **"));
						setErrorMsg("An error occured while updating your Phone number");
					}
					return;
				} else if (SECQUESTS_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {
					if(!validateSecurityAnswers("actrcy")) {
						setCurrentActiveItem("useracctrecovery");
						return;
					}
					
					userVO.setSecEmailAddress(null);
					populateSecurityQuestions(userVO);
					modifiedUserAttrLst.add("MODIFY_CHALLENGE_RESPONSE_QUESTIONS");
					
					userProfileServiceRequest.setUser(userVO);
					UserProfileServiceResponse response = getContainer().getUserService().modifyUserForStepUp(userProfileServiceRequest, modifiedUserAttrLst);
					
					if (!TrustbrokerWebAppUtil.checkResponseStatus(response)) {
						setCurrentActiveItem("failure");
						return;
					}
					
					logger.debug("Status code: " + response.getExecutionStatus().getStatusCd() + " Status Message: " + 
							response.getExecutionStatus().getStatusMessage());
					
					logger.info("Security Information  updated successfully for user {}",
							new String[] { getCurrentUserVO().getUserName() });
			
					redirectToView(getWidgetHomeURIWithAlias());
				} 							
				
				if(SECEMAIL_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {		
					
					try {
						
						userVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
						userVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));
						userVO.setSecEmailAddress(getSecEmailAddress());
						userProfileServiceRequest.setUser(userVO);
						UserVO essoUserVO = container.getUserService().fetchUserProfile(userVO.getUuId(),true, true).getUser();
						userProfileServiceRequest.setOldUser(essoUserVO);
						container.getUserService().modifyUser(userProfileServiceRequest, false);
						setErrorMsg("A new confirmation code has been sent to your new email address");
					} catch (OperationFailedException exception) {
						logger.error("Exception while Updating the confirm email during user Post Account Recovery - {}", 
								new String[]{TrustbrokerWebAppUtil.getUidFromError(exception)},exception);
						setCurrentActiveItem("useracctrecovery");
						String emailErrorMsg = extractErrorMessageFromOFE(exception);
						if (null != emailErrorMsg)
							setErrorMsg(emailErrorMsg);
						else
							setErrorMsg(tbResources.getString("emailVerificationFailed"));
						setErrorMsg("An error occured while updating your Secondary Email address");
					}
					
					userVO.setSecEmailVerified(false);
					VerifyCodesContext ctx = new VerifyCodesContext();
					ctx.getViewChannels().add(CommunicationChannel.SECONDARY_EMAIL);
					ctx.getSendChannels().add(CommunicationChannel.SECONDARY_EMAIL);
					
					if(StringUtils.isNotBlank(getCurrentUserVO().getEmailAddress()) && !getCurrentUserVO().isIsemailVerified()) {
						ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
						ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
					}
					
					ctx.setHideUpdateButtons(false);
					ctx.setShowDeviceRegistration(false);
					ctx.setNextView(getWidgetHomeURIWithAlias());
					ctx.setUserVO(userVO);
					getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);	
					
					if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {
						redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
						return;
					}
				}
			}
	
	
	
	
	
	
	
		}
	
	
	
    public void finalProcess(UserProfileServiceRequest userProfileServiceRequest){

	
		if(getStepUpCtx().isShowSecQuestions() || showSecQuestionBasedonSharedEmail ){
			populateSecurityQuestions(userVO);
			modifiedUserAttrLst.add("MODIFY_CHALLENGE_RESPONSE_QUESTIONS");
		}
		
		userVO.setRpId(getRelyingPartyApAlias(true));
		userProfileServiceRequest.setUser(userVO);
		
		if(getCurrentUserVO().isMigratedUser()){
			modifiedUserAttrLst.add(TrustBrokerConstants.MODIFY_MIGRATED_USER);
		}
		
		ServiceResponse servResponse = null;
		
		//Update Password for migration first as user might provide older one so i needs to be validated first
		if(getStepUpCtx().isShowPassword()){
			UserChangePasswordServiceRequest userChangePwdRequest = new UserChangePasswordServiceRequest();
			userChangePwdRequest.setPassword(getPassword());
			userChangePwdRequest.setUser(getCurrentUserVO());
			servResponse = container.getCredentialService().changePwd(userChangePwdRequest);
			if(!TrustbrokerWebAppUtil.checkResponseStatus(servResponse)){
				if(StringUtils.isNotBlank(servResponse.getReasonMessage())) 
					addFacesMessage("userStepupProfileId:pwd", servResponse.getReasonMessage());
				else addFacesMessage("userStepupProfileId:pwd", "Failed to update password. Please try again with different password.");
				setCurrentActiveItem(CREDENTIALS_SCREEN);return;
			}
			getStepUpCtx().setShowPassword(false);
			getCurrentUserVO().setPasswordChangeRequired(false);
		}
		
		//Update user name for migration
		if(getStepUpCtx().isShowUserName()){
			servResponse = container.getCredentialService().changeUserName(userProfileServiceRequest);
			if(!TrustbrokerWebAppUtil.checkResponseStatus(servResponse)){
				addFacesMessage("userStepupProfileId:userNameId", "Failed to update user name. Please try again with different user name.");
				setCurrentActiveItem(CREDENTIALS_SCREEN); return;
			}
			getStepUpCtx().setShowUserName(false);
			getStepUpCtx().setUserNameUpdated(true);
			getCurrentUserVO().setUserName(getUserName());//Update session with new user name 
			getCurrentUserVO().setUserNameChangeRequired(false);
		}
		
		if(getCurrentUserVO().isMigratedUser()) acceptTermsAndConditions();//Agree terms and conditions
		
		//Update user step up data with Coppa status
		UserProfileServiceResponse response = null;
		if(modifiedUserAttrLst.size() > 0){
			
			// check for the email and confirm email is empty and make the showEmail as false
			if (StringUtils.isBlank(getPrimaryEmailAddress()) && StringUtils.isBlank(getConfirmEmailAddress()) && suggestionHeader){
				getStepUpCtx().setShowEmail(false);
			}
			if(getStepUpCtx().isShowEmail()){
				userVO.setEssoPrimaryEmail(getCurrentUserVO().getEmailAddress());//First set the current email address to user.
				userVO.setEmailAddress(getPrimaryEmailAddress());
				userProfileServiceRequest.setUser(userVO);
			}
			response = getContainer().getUserService().modifyUserForStepUp(userProfileServiceRequest, modifiedUserAttrLst);
		}
		
		if(TrustBrokerWebAppConstants.YES.equalsIgnoreCase(userVO.getIsCoppaAccepted()) && getStepUpCtx().isCoppaRequired()) {
			getContainer().getUserService().updateUserCoppaComplianceAccpeted(userVO);
			getCurrentUserVO().setIsCoppaAccepted(TrustBrokerWebAppConstants.YES);
		}
		
		if(modifiedUserAttrLst.size() > 0){
			if (!TrustbrokerWebAppUtil.checkResponseStatus(response)) {
				setCurrentActiveItem("failure");
				return;
			} else {
				
				if(getStepUpCtx().isShowEmail()){
					getStepUpCtx().setShowEmail(false);
					userVO.setIsemailVerified(false);
					addSessionAttribute(TrustBrokerWebAppConstants.EMAIL_UPDATED_ON_STEPUP, true);
				}
				
				if(response!=null && response.getUser() != null){
					getCurrentUserVO().setDob(response.getUser().getDob());
					getCurrentUserVO().setEmailAddress(response.getUser().getEmailAddress());
					getCurrentUserVO().setPrimaryEmailUnique(response.getUser().isPrimaryEmailUnique());
				}
				
				if(modifiedUserAttrLst.contains(TrustBrokerConstants.MODIFY_MIGRATED_USER)) { //This was successful user migration
					addSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED, true);
					getCurrentUserVO().setMigratedUser(false);
				}
			}
		}
		
		logger.info("User profile updated successfuly on step up/migration for user {}", new String[] { getCurrentUserVO().getUserName() });
		
		if(getStepUpCtx().isUserNameUpdated()) {
			LoginRequest loginRequest = new HttpLoginRequest(getCurrentUserVO().getUserName(),  null, getServletRequest(), getServletResponse());
			loginRequest.setProtectedUrl(getWidgetHomeURIWithAlias());
			getStepUpCtx().setUserNameUpdated(false);
			container.getOptumidSMDlwsBasedLoginService().login(loginRequest);
		} 
		
		redirectToView(getWidgetHomeURIWithAlias());
	
    	
    }
	private void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}
	
	// This method validates the user profile information and creates initial step up data to be displayed  
	private void validateUserInformationAndSetUpInitialDisplayData(){
		
		List<UserChallengeQuestionVO> securityQuesList = getCurrentUserVO().getUserChallengeQuestions();
		if (securityQuesList != null && securityQuesList.size() > 0) {
			getStepUpCtx().setUserProfileHasSecQuestions(true);
		}
		
		if((getCurrentUserVO().isIsemailVerified() && getCurrentUserVO().isPrimaryEmailUnique()) || 
				(!getCurrentUserVO().isIsemailVerified() && !container.getUserService().isEmailExists(getCurrentUserVO().getEmailAddress())))
			getStepUpCtx().setUserEmailUnique(true);
		
		if(StringUtils.isNotBlank(getUserVO().getEmailAddress()) && !getStepUpCtx().isUserEmailUnique() 
				&& (!getStepUpCtx().isEmailUnique() || getStepUpCtx().isEmailMandatory())){
			
			if(getStepUpCtx().isUserProfileHasSecQuestions() || 
					(!getStepUpCtx().isUserProfileHasSecQuestions() && getStepUpCtx().isSecQuestionRequired())) 
				setInformationalText(tbResources.getString("iframeMigrationCase6Message"));
			else setInformationalText(tbResources.getString("iframeMigrationCase1Message"));
		}
		
		if(getStepUpCtx().isEmailUnique()) {
			if(StringUtils.isNotBlank(getCurrentUserVO().getEmailAddress()) && !getStepUpCtx().isUserEmailUnique()){
				setValidationErrorMessageColor(true);
				addFacesMessage("userStepupProfileId:email", tbResources.getString("iframeRpDoNotDuplicateNonMandatoryEmail"));
				setPrimaryEmailAddress(userVO.getEmailAddress());
				setConfirmEmailAddress(userVO.getEmailAddress());
			}
			
			if(StringUtils.isBlank(getCurrentUserVO().getEmailAddress()))
				setInformationalText(tbResources.getString("iframeMigrationCase3Message"));
		}
			
		if(!getStepUpCtx().isEmailUnique() && !getStepUpCtx().isEmailMandatory()) {
			if(StringUtils.isBlank(getCurrentUserVO().getEmailAddress()))
				setInformationalText(tbResources.getString("iframeMigrationCase5Message"));
		}
			
		if(!getStepUpCtx().isEmailUnique() && getStepUpCtx().isEmailMandatory()) {
			if(StringUtils.isBlank(getCurrentUserVO().getEmailAddress()))
				setInformationalText(tbResources.getString("iframeMigrationCase4Message"));
		}
		
		// Show Suggestion and suggestion header
		if(getCurrentUserVO().isMigratedUser() || getStepUpCtx().isStepUpRequired()) {

			if((!getStepUpCtx().isUserEmailUnique() && !getStepUpCtx().isEmailUnique()) || 
					(StringUtils.isBlank(getCurrentUserVO().getEmailAddress()) && !getStepUpCtx().isEmailMandatory())) {
				if(!getStepUpCtx().isShowEmail()) {
					suggestion = true;
					suggestionHeader = true;
				}
			}
			
		}

		if(StringUtils.isNotBlank(getUserVO().getEmailAddress()) && !getStepUpCtx().isUserEmailUnique() &&  (!getStepUpCtx().isEmailUnique())) {
			if (!getStepUpCtx().isShowSecQuestions() && !getStepUpCtx().isUserProfileHasSecQuestions()) {
					showSecQuestionBasedonSharedEmail = true;
					stepUpCtx.setQuestionsPageDisplayed(true);
			}
		}
		
		// if suggestion is on, then don't show the required indicator
		if (suggestion) {
			requiredIndicatorForEmail = false;
		} else if(getStepUpCtx().isEmailMandatory()) {
				requiredIndicatorForEmail = true;
		}
		
		if(!TBUtil.validateEmailId(getCurrentUserVO().getEmailAddress())){
			suggestion = false;
			suggestionHeader = false;
			requiredIndicatorForEmail = true;
			setInformationalText(tbResources.getString("incorrectFormatMessage"));
			getStepUpCtx().setShowEmail(true);
			getStepUpCtx().setEmailMandatory(true);
		}
		
		if(!TBUtil.validateRegEx(getCurrentUserVO().getUserName(), tbResources.getString("userNameRegEx"))){
			getStepUpCtx().setShowUserName(true);
		}

		if (showSecQuestionBasedonSharedEmail) {
			secQuestBasedonSharedEmailActualFlag = true;
		}
	}
	
	
	private boolean validateInfoPage(List<String> modifiedUserAttrLst){
		boolean validationStatus = false;
		
		if (getStepUpCtx().isShowDob()) {
			if (validateDateOfBirth()) {
				modifiedUserAttrLst.add("MODIFY_DOB");
				userVO.setDob(DateUtil.parseDate(dateOfBirth, DateUtil.EXT_DATE_FORMAT));
			} else validationStatus = true;
		}
		
		if(getStepUpCtx().isShowEmail()){
			if(!validateEmailAddress(getPrimaryEmailAddress())){
				validationStatus=true;
			} else {
				modifiedUserAttrLst.add("MODIFY_EMAILS");
			}
			if(!validateConfirmEmailFields() ){
				validationStatus=true;
			} else {
				modifiedUserAttrLst.add("MODIFY_EMAILS");
			}
		}
		
		if(getStepUpCtx().isCoppaRequired()) {
			if(!validateYearOfBirth()) {
				validationStatus=true;
			} else {
				userVO.setIsCoppaAccepted(TrustBrokerWebAppConstants.YES);
			}
		}
		
		if(!stepUpCtx.isCredentialPageDisplayed() && !stepUpCtx.isQuestionsPageDisplayed()){
			if(getCurrentUserVO().isMigratedUser() && !validateTermsAndCondition()){
				validationStatus = true;
			}
		}
		
		return validationStatus;
	}
	
	private boolean validateCredentialsPage(List<String> modifiedUserAttrLst){
		boolean validationStatus = false;
		

		if(getStepUpCtx().isShowUserName()){
			if(!validateUserName(getUserName())){
				validationStatus = true;
			} else {
				userVO.setUserName(getUserName());
			}
		}
		
		if(getStepUpCtx().isShowPassword()){
			if(!validatePasswordFields()){
				validationStatus = true;
			} else {
				userVO.setPassword(getPassword());
			}
		}
		
		if(!stepUpCtx.isQuestionsPageDisplayed()){
			if(getCurrentUserVO().isMigratedUser() && !validateTermsAndCondition()){
				validationStatus = true;
			}
		}
	
		return validationStatus;
	}
	
	private boolean validateQuestionsPage(List<String> modifiedUserAttrLst){
		boolean validationStatus = false;
		
		
		if ((getStepUpCtx().isShowSecQuestions() || showSecQuestionBasedonSharedEmail )  && tbSecurityQuestionsBean.getSecurityQuestionOne() != null
				&& tbSecurityQuestionsBean.getSecurityQuestionTwo() != null
				&& tbSecurityQuestionsBean.getSecurityQuestionThree() != null) {
			
			if (!validateSecurityAnswers()) {
				validationStatus = true;
			}
		}
		
		if(getCurrentUserVO().isMigratedUser() && !validateTermsAndCondition()){
			validationStatus = true;
		}
		
		return validationStatus;
	}
	

	public void checkSecurityAnswers(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			String answerOne = tbSecurityQuestionsBean.getSecurityAnswerOne();
			String answerTwo = tbSecurityQuestionsBean.getSecurityAnswerTwo();
			String answerThree = tbSecurityQuestionsBean.getSecurityAnswerThree();
			String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
			String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
			String secQuestion3 = tbSecurityQuestionsBean.getSecurityQuestionThree();
			
			if(StringUtils.isBlank(answerOne))
				addFacesMessage("userStepupProfileId:securityAnswerOne", tbResources.getString("secQuestion1"));
			if(StringUtils.isBlank(answerTwo))
				addFacesMessage("userStepupProfileId:securityAnswerTwo", tbResources.getString("secQuestion2"));
			if(StringUtils.isBlank(answerThree))
				addFacesMessage("userStepupProfileId:securityAnswerThree", tbResources.getString("secQuestion3"));
			
			
			if(!StringUtils.isBlank(secQuestion1)){
				if(secQuestion1.equals("null") || secQuestion1.length() == 4)
					addFacesMessage("userStepupProfileId:securityAnswerOne", tbResources.getString("secQuestion1"));
			}else
				addFacesMessage("userStepupProfileId:securityAnswerOne", tbResources.getString("secQuestion1"));
			if(!StringUtils.isBlank(secQuestion2)){
				if(secQuestion2.equals("null") || secQuestion2.length() == 4)
					addFacesMessage("userStepupProfileId:securityAnswerTwo", tbResources.getString("secQuestion2"));
			}else
				addFacesMessage("userStepupProfileId:securityAnswerTwo", tbResources.getString("secQuestion2"));
			if(!StringUtils.isBlank(secQuestion3)){
				if(secQuestion3.equals("null") || secQuestion3.length() == 4)
					addFacesMessage("userStepupProfileId:securityAnswerThree", tbResources.getString("secQuestion3"));
			}else
				addFacesMessage("userStepupProfileId:securityAnswerThree", tbResources.getString("secQuestion3"));
		}
	}

	private boolean validateSecurityAnswers() {
		String sameAnswer = "";
		boolean retVal = true;

		String answerOne = tbSecurityQuestionsBean.getSecurityAnswerOne();
		String answerTwo = tbSecurityQuestionsBean.getSecurityAnswerTwo();
		String answerThree = tbSecurityQuestionsBean.getSecurityAnswerThree();
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion3 = tbSecurityQuestionsBean.getSecurityQuestionThree();
			
		if (secQuestion1.equals("null") || secQuestion1.length() == 4 || StringUtils.isBlank(answerOne)) {
			addFacesMessage("userStepupProfileId:securityAnswerOne", tbResources.getString("secQuestion1"));
			retVal = false;
		}
		if (secQuestion2.equals("null") || secQuestion2.length() == 4 || StringUtils.isBlank(answerTwo)) {
			addFacesMessage("userStepupProfileId:securityAnswerTwo", tbResources.getString("secQuestion2"));
			retVal = false;
		}
		if (secQuestion3.equals("null") || secQuestion3.length() == 4 || StringUtils.isBlank(answerThree)) {
			addFacesMessage("userStepupProfileId:securityAnswerThree", tbResources.getString("secQuestion3"));
			retVal = false;
		}

		if (answerOne.equalsIgnoreCase(answerTwo) && answerOne.equalsIgnoreCase(answerThree))
			sameAnswer = answerOne;

		if (!"".equals(sameAnswer)) {

			if (StringUtils.containsIgnoreCase(secQuestion1, answerOne)
					&& sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("userStepupProfileId:securityAnswerOne",
						tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion2, answerTwo)
					&& sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userStepupProfileId:securityAnswerTwo",
						tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion3, answerThree)
					&& sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("userStepupProfileId:securityAnswerThree",
						tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion1, answerOne)) {
				addFacesMessage("userStepupProfileId:securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion2, answerTwo)) {
				addFacesMessage("userStepupProfileId:securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion3, answerThree)) {
				addFacesMessage("userStepupProfileId:securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("userStepupProfileId:securityAnswerOne",
						tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userStepupProfileId:securityAnswerTwo",
						tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("userStepupProfileId:securityAnswerThree",
						tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

		} else {
			if (StringUtils.containsIgnoreCase(secQuestion1, answerOne)) {
				retVal = false;

				addFacesMessage("userStepupProfileId:securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
			}

			if (StringUtils.containsIgnoreCase(secQuestion2, answerTwo)) {
				addFacesMessage("userStepupProfileId:securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion3, answerThree)) {
				addFacesMessage("userStepupProfileId:securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}
		}

		if (!TBUtil.validateSecurityAnswer(answerOne)) {
			retVal = false;
			addFacesMessage("userStepupProfileId:securityAnswerOne",
					tbResources.getString("iframeObsceneTextInAnswer"));
		}

		if (!TBUtil.validateSecurityAnswer(answerTwo)) {
			retVal = false;
			addFacesMessage("userStepupProfileId:securityAnswerTwo",
					tbResources.getString("iframeObsceneTextInAnswer"));
		}

		if (!TBUtil.validateSecurityAnswer(answerThree)) {
			retVal = false;
			addFacesMessage("userStepupProfileId:securityAnswerThree",
					tbResources.getString("iframeObsceneTextInAnswer"));
		}

		return retVal;
	}
	
	
	public void checkRecvrySecEmailAddr(ValueChangeEvent event) {
        PhaseId phaseId = event.getPhaseId();
        
        if (phaseId.equals(PhaseId.ANY_PHASE)) {
               event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
               event.queue();             
               validateRecoverySecEmail(event.getNewValue().toString());              
        } else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
               boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
               logger.debug("result value in updateEmail: " + result);
               if (!result) {
                      addFacesMessage("userStepupProfileId:secEmailAddress",tbResources.getString("invalidEmailAddress"));
               } 
               
               validateRecoverySecEmail(event.getNewValue().toString()); 
        }
	}
	
	private boolean validateRecoverySecEmail(String email) {
		
		userVO = getCurrentUserVO();
		boolean validEmail = true;
		
		if(StringUtils.isEmpty(email)) {
			addFacesMessage("userStepupProfileId:secEmailAddress",tbResources.getString("regnacctrecoverySecEmailReqMsg"));
			validEmail = false;
		} else if(!TBUtil.validateEmailId(email)){
			validEmail = false;
            addFacesMessage("userStepupProfileId:secEmailAddress",tbResources.getString("invalidEmailAddress"));
        } else if((userVO.getEmailAddress().equalsIgnoreCase(email))) { 
        	validEmail = false;
     	    addFacesMessage("userStepupProfileId:secEmailAddress",tbResources.getString("emailAlreadyExists"));
        } else if(email.equalsIgnoreCase(userVO.getSecEmailAddress()) && !userVO.isSecEmailVerified()){
        	validEmail = true;
        } else if(email.equalsIgnoreCase(userVO.getSecEmailAddress()) && ((userVO.isSecEmailVerified() && !userVO.isSecEmailUnique()) ||
        		container.getUserService().isEmailExistsWithOtherUser(email, getCurrentUserVO().getUserName()))){
        	validEmail = false;
          	addFacesMessage("userStepupProfileId:secEmailAddress",tbResources.getString("emailAlreadyExists"));
        } else if(!email.equalsIgnoreCase(userVO.getSecEmailAddress()) && container.getUserService().isEmailExists(email)){
        	validEmail = false;
          	addFacesMessage("userStepupProfileId:secEmailAddress",tbResources.getString("emailAlreadyExists"));
        }
		
		return validEmail;
	}
	
	
	private void populateSecurityQuestions(UserVO userVO) {
		List<UserChallengeQuestionVO> securityQuestions = new ArrayList<UserChallengeQuestionVO>();
		UserChallengeQuestionVO question1 = new UserChallengeQuestionVO();

		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion1Array[] = secQuestion1.split("_");
		question1.setQuestionId(secQuestion1Array[0]);
		question1.setQuestion(secQuestion1Array[1]);
		question1.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerOne());

		UserChallengeQuestionVO question2 = new UserChallengeQuestionVO();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion2Array[] = secQuestion2.split("_");
		question2.setQuestionId(secQuestion2Array[0]);
		question2.setQuestion(secQuestion2Array[1]);
		question2.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerTwo());

		UserChallengeQuestionVO question3 = new UserChallengeQuestionVO();
		String secQuestion3 = tbSecurityQuestionsBean
				.getSecurityQuestionThree();
		String secQuestion3Array[] = secQuestion3.split("_");
		question3.setQuestionId(secQuestion3Array[0]);
		question3.setQuestion(secQuestion3Array[1]);
		question3.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerThree());

		securityQuestions.add(question1);
		securityQuestions.add(question2);
		securityQuestions.add(question3);
		userVO.setUserChallengeQuestions(securityQuestions);
	}

	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	public void checkdateOfBirth(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultDob = DateUtil.validateDate(dateOfBirth);
			if (!resultDob) {
				addFacesMessage("userStepupProfileId:dobId", tbResources.getString("dobFormatErrorMsg"));
			}
			else if(StringUtils.isNotBlank(dateOfBirth))
			{
				int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userMinAgeLimit"));
				userVO.setDob(DateUtil.parseDate(dateOfBirth, DateUtil.EXT_DATE_FORMAT));
				SimpleDateFormat dobFormat = new SimpleDateFormat(DateUtil.EXT_DATE_FORMAT);
				Integer ageDifference = DateUtil.validateAge(dateOfBirth, minAgeLimit, dobFormat);
			    if(!getStepUpCtx().isCoppaRequired() && ageDifference == DateUtil.FUTURE) {
			       addFacesMessage("userRegistrationId:dobId", tbResources.getString("dobAgeConstraintFutureMsg"));
			    }
			}
		}
	}
	
	private boolean validateDateOfBirth() {
		boolean result = true;
		boolean isDateValid = true;
		
		if(StringUtils.isEmpty(dateOfBirth)){
			addFacesMessage("userStepupProfileId:dobId", "Date of Birth is required");
			return false;
		}
		
		isDateValid = DateUtil.validateDate(dateOfBirth);

		if (!isDateValid) {
			addFacesMessage("userStepupProfileId:dobId", tbResources.getString("dobFormatErrorMsg"));
			return false;
		} 
			
		int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userMinAgeLimit"));
		userVO.setDob(DateUtil.parseDate(dateOfBirth,DateUtil.EXT_DATE_FORMAT));

		boolean isLimitStillValid = checkYearOfBirthEntryLimit();
		if (isLimitStillValid) {
			SimpleDateFormat dobFormat = new SimpleDateFormat(DateUtil.EXT_DATE_FORMAT);
			Integer ageDifference = DateUtil.validateAge(dateOfBirth, minAgeLimit, dobFormat);
			if (ageDifference != DateUtil.OVERAGE) {
				if(getStepUpCtx().isCoppaRequired()) {
					incrementIncorrectYobCount();
				}
				isLimitStillValid = checkYearOfBirthEntryLimit();
				result = false;
				if (isLimitStillValid) {
					if (ageDifference == DateUtil.OVERAGEEXEEDED) {
						addFacesMessage("userStepupProfileId:dobId", tbResources.getString("dobAgeConstraintOverMsg"));
					} else if (ageDifference == DateUtil.FUTURE) {
						addFacesMessage("userStepupProfileId:dobId", tbResources.getString("dobAgeConstraintFutureMsg"));
					} else  {
						if(getStepUpCtx().isCoppaRequired()) {
								addFacesMessage("userStepupProfileId:dobId", tbResources.getString("dobAgeConstraintMsg"));
						   } else {
							   result = true;
						   }						
					}
				} else {
					handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00K000),null);
				}
				
			}
		} else result = false;
		
		return result;
	}
	
	public void checkEmailAddress(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			validateEmailAddress(event.getNewValue().toString());
		}
	}

	//This method is used to validate user email input on the field on focus out
	public boolean validateEmailAddress(String email) {
		boolean result = true;
		setValidationErrorMessageColor(false);
		showSecQuestionBasedonSharedEmail=false;
		
		if (getStepUpCtx().isEmailMandatory() && StringUtils.isEmpty(email)) {
			
			result = false;
		} else if (!TBUtil.validateEmailId(email) ) {
			addFacesMessage("userStepupProfileId:email", tbResources.getString("invalidEmailAddress"));
			result = false;
		} else if (StringUtils.isNotBlank(getCurrentUserVO().getSecEmailAddress()) && 
				getCurrentUserVO().getSecEmailAddress().equalsIgnoreCase(getPrimaryEmailAddress())) {					
			addFacesMessage("userStepupProfileId:email", "Secondary Email and Email Addresses cannot be same");
			result = false;
		} else if (getStepUpCtx().isEmailUnique() && container.getUserService().isEmailExists(email)) {
			getStepUpCtx().setShowEmail(true);
			addFacesMessage("userStepupProfileId:email", tbResources.getString("iframeRpDoNotDuplicateNonMandatoryEmail"));
			result = false;
		} else if (!getStepUpCtx().isEmailUnique() && container.getUserService().isEmailExists(email)) {
			if(getCurrentUserVO().getEmailAddress() !=null && 
					(getCurrentUserVO().getEmailAddress().equalsIgnoreCase(email))){
				addFacesMessage("userStepupProfileId:email", tbResources.getString("rpDoNotAllowEmailThatAlreadyInSameAccount"));
				result = false;	
			} else {
				
				if(!getStepUpCtx().isUserProfileHasSecQuestions())
				addFacesMessage("userStepupProfileId:email",tbResources.getString("iframeMigrationCase6Message"));
				else{
					setValidationErrorMessageColor(true);
					addFacesMessage("userStepupProfileId:email","This email is currently in use. Consider changing it to one only you use.");
				}
				
				if(!getStepUpCtx().isShowSecQuestions() && !getStepUpCtx().isUserProfileHasSecQuestions()){
						showSecQuestionBasedonSharedEmail = true;
				}
			}
		}
		

		if(StringUtils.isNotEmpty(email)) {
			if(TBUtil.validateEmailId(email) && !container.getUserService().isEmailExists(email)){
				showSecQuestionBasedonSharedEmail=false;
			}
		}
		return result;
	}
	
	//This method is used to validate user email input on submit button
	private boolean validateConfirmEmailFields() {
		boolean result = true;
		 setValidationErrorMessageColor(false);
		
		if (StringUtils.isNotBlank(getPrimaryEmailAddress()) && StringUtils.isNotBlank(getConfirmEmailAddress()) && 
				!StringUtils.equalsIgnoreCase(getPrimaryEmailAddress(), getConfirmEmailAddress())) {
			addFacesMessage("userStepupProfileId:confirmEmail", tbResources.getString("emailDoNotMatch"));
			
			if(!TBUtil.validateEmailId(StringUtils.lowerCase(getPrimaryEmailAddress()))){
				addFacesMessage("userStepupProfileId:email",tbResources.getString("invalidEmailAddress"));
			}
			return false;
		}
		
	
		if (StringUtils.isNotBlank(getCurrentUserVO().getSecEmailAddress()) && 
				getCurrentUserVO().getSecEmailAddress().equalsIgnoreCase(getPrimaryEmailAddress())) {					
			addFacesMessage("userStepupProfileId:email", "Secondary Email and Email Addresses cannot be same");
			return false;
		}
		
		if(!getStepUpCtx().isEmailMandatory() && StringUtils.isBlank(getPrimaryEmailAddress())){
			if(StringUtils.isNotBlank(getConfirmEmailAddress())){
			addFacesMessage("userStepupProfileId:confirmEmail", tbResources.getString("emailDoNotMatch"));
				return false;
			}
			
			
			return true;
		} else {
			
					
			if (!TBUtil.validateEmailId(StringUtils.lowerCase(getPrimaryEmailAddress()))){
				addFacesMessage("userStepupProfileId:email", tbResources.getString("invalidEmailAddress"));
				result = false;
			}
			
			if (!TBUtil.validateEmailId(StringUtils.lowerCase(getConfirmEmailAddress()))){
				addFacesMessage("userStepupProfileId:confirmEmail", tbResources.getString("invalidEmailAddress"));
				result = false;
			}
			
		    if(!result) return result;
			
			if(getStepUpCtx().isEmailUnique()){
				if(StringUtils.isBlank(getPrimaryEmailAddress()) && getStepUpCtx().isEmailMandatory()) {
					addFacesMessage("userStepupProfileId:email", tbResources.getString("iframeRpRequiresUniqueEmail"));
					if(StringUtils.isBlank(getConfirmEmailAddress()))
						addFacesMessage("userStepupProfileId:confirmEmail", "Confirm Email is required");
					result=false;
				} else if(container.getUserService().isEmailExists(getPrimaryEmailAddress())) {				
					addFacesMessage("userStepupProfileId:email",tbResources.getString("iframeRpDoNotDuplicateNonMandatoryEmail"));				
					result=false;
				}
				if (!result) {
					getStepUpCtx().setShowEmail(true);
					setValidationErrorMessageColor(false);
				}
			} else if (!getStepUpCtx().isEmailUnique() &&  container.getUserService().isEmailExists(getPrimaryEmailAddress())) { 
				//Shared is allowed and it exists
				if(getCurrentUserVO().getEmailAddress() !=null &&  (getCurrentUserVO().getEmailAddress().equalsIgnoreCase(getPrimaryEmailAddress()))){
					getStepUpCtx().setShowEmail(true);
					addFacesMessage("userStepupProfileId:email", tbResources.getString("rpDoNotAllowEmailThatAlreadyInSameAccount"));
					result = false;	
				} else{
					getStepUpCtx().setShowEmail(true);
					setValidationErrorMessageColor(true);
					result=true;
				}
			}
			
			if(getStepUpCtx().isEmailMandatory() && StringUtils.isBlank(getPrimaryEmailAddress())
					&& StringUtils.isBlank(getConfirmEmailAddress()) ){
				if(!suggestionHeader){
					addFacesMessage("userStepupProfileId:confirmEmail", "Confirm Email is required");
					addFacesMessage("userStepupProfileId:email", tbResources.getString("iframeRpDoNotSupportBlankEmail"));
					result = false;
				}
			}
		}
		
		if(!result) return result;
		
		if (StringUtils.isNotBlank(getPrimaryEmailAddress()) && StringUtils.isBlank(getConfirmEmailAddress())){
			addFacesMessage("userStepupProfileId:confirmEmail", "Please confirm your email address ");
			return false;
		}
		
		return result;
	}
	
	
	// **** Start of year of birth validations section *****
	
	//This method is used to validate year of both when COPPA is enabled and DOB not required for RP
	private boolean validateYearOfBirth(){
		if(getStepUpCtx().isShowDob() || !getStepUpCtx().isCoppaRequired()) return true;
		
		boolean isYearValid=true;
		
		if(StringUtils.isEmpty(yearOfBirth)){
			addFacesMessage("userStepupProfileId:yobId", "Year of Birth is required");
			return false;
		}
		
		isYearValid = validateYobFormat(yearOfBirth);
			
		if(!isYearValid){
			addFacesMessage("userStepupProfileId:yobId", tbResources.getString("yobFormatErrorMsg"));
			return isYearValid;
		}
		
		int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userMinAgeLimit"));
		boolean isLimitStillValid = checkYearOfBirthEntryLimit();
		
		if (isLimitStillValid) {
			SimpleDateFormat yearformat = new SimpleDateFormat(DateUtil.YEAR_FORMAT);
			Integer ageDifference = DateUtil.validateAge(yearOfBirth, minAgeLimit, yearformat);
			if (ageDifference != DateUtil.OVERAGE) {
				if(getStepUpCtx().isCoppaRequired()) {
					incrementIncorrectYobCount();
				}
				isLimitStillValid = checkYearOfBirthEntryLimit();
				if (isLimitStillValid) {
					if(ageDifference == DateUtil.OVERAGEEXEEDED){
						addFacesMessage("userStepupProfileId:yobId", tbResources.getString("yobAgeConstraintOverMsg")); 
					} else if(ageDifference == DateUtil.FUTURE){
						addFacesMessage("userStepupProfileId:yobId", tbResources.getString("yobAgeConstraintFutureMsg"));
					} else addFacesMessage("userStepupProfileId:yobId", tbResources.getString("yobAgeConstraintMsg"));
				} else {
					handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00K000), null); return false;
				}
				isYearValid = false;
			}
		} else isYearValid = false;
		
		return isYearValid;
	}

	//Helper method for year of birth check
	private boolean checkYearOfBirthEntryLimit(){
		Integer yobCount = this.getIncorrectYobCount();
		if(yobCount >=yobLimit){
			String idStr="userStepupProfileId:yobId";
			if(getStepUpCtx().isShowDob()) idStr="userStepupProfileId:dobId";
			addFacesMessage(idStr, TBUtil.formatMessage(tbResources.getString("ageNotElibleMsgIframe"),new Object[] { getSupportContactInfo().getContactComboText() }));
			return false;
		}else{
			return true;
		}
	}
	
	private boolean validateYobFormat(String yobStr){
		if(getStepUpCtx().isShowDob()) return true;//then year of birth not used
		
		boolean valid=true;
		Integer yob=-1;
		try{
			yob = Integer.parseInt(yobStr);
			SimpleDateFormat yearformat = new SimpleDateFormat(DateUtil.YEAR_FORMAT);
			if(yob != -1) yearformat.parse(yobStr);
		}catch(Exception e){
			logger.debug("caught exception parsing year of birth. e: "+e);
			valid=false;
		}
		return valid;
	}
	
	private void incrementIncorrectYobCount(){
		Integer yobCount = getIncorrectYobCount();
		yobCount++;
		this.addSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT, yobCount);
	}
	
	public void checkyearOfBirth(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean limitNotReached=checkYearOfBirthEntryLimit();
			if(limitNotReached){
			   boolean valid=validateYobFormat(yearOfBirth);
			   if ( !valid) addFacesMessage("userStepupProfileId:yobId", tbResources.getString("yobFormatErrorMsg"));
			}
		}
	}
	
	private Integer getIncorrectYobCount(){
		Integer yobCount=null;
		Object incorrectYobCountObj = getSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT);
		if(incorrectYobCountObj != null)
			yobCount = (Integer)incorrectYobCountObj;
		else{
			yobCount = new Integer(0);
			this.addSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT, yobCount);
		}
		return yobCount;
	}
	
	// **** End of year of birth validations section *****
	
	
	// **** start of user name validations section *****
	
	//Validate the user name field input
	private boolean validateUserName(String enteredUserName) {
		
		boolean isUserNameRegExValidated = TBUtil.validateRegEx(enteredUserName, tbResources.getString("userNameRegEx"));
		setTempUserName("");
		if(StringUtils.isEmpty(enteredUserName)){
			addFacesMessage("userStepupProfileId:userNameId", "Username is required");
			return false;
		}
		if (!isUserNameRegExValidated) {
			userNameSuggestionsList = new ArrayList<String>();
			addFacesMessage("userStepupProfileId:userNameId", tbResources.getString("invalidUserName"));
			return false;
		} else {
			userNameSuggestionsList = new ArrayList<String>();
			setShowSuggestions(false);
			UserVO tempUserVO = new UserVO();
			tempUserVO.setUserName(enteredUserName);
			tempUserVO.setFirstName(getCurrentUserVO().getFirstName());
			tempUserVO.setLastName(getCurrentUserVO().getLastName());

			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(tempUserVO);			
			UserNameCheckServiceResponse resp = container.getUserService().checkUserNameAvailability(userProfileServiceRequest);

			if(resp != null) {
				List<String> userNameSuggestionsFromWS = resp.getUserSuggestions();
				if (null != userNameSuggestionsFromWS && userNameSuggestionsFromWS.size() > 0) {
					setUserNameSuggestionsList(userNameSuggestionsFromWS);
					setOldUsernameSuggestionsList(userNameSuggestionsFromWS);
					setShowSuggestions(true);
					addFacesMessage("userStepupProfileId:userNameId", tbResources.getString("iframeUserNameNotAvailable"));
					return false;
				}
			}
		}
		return true;
	}
	
	public void userNameChanged(ValueChangeEvent e) {
		validateUserName(e.getNewValue().toString());
	}
	
	public void userSuggestionSelected(ValueChangeEvent e) {
		if (e.getNewValue() != null) {
			String userSuggestionSelectedValue = e.getNewValue().toString();
			if (null != userSuggestionSelectedValue) {
				if (userNameSuggestionsList != null && userNameSuggestionsList.contains(e.getNewValue().toString()))
					setUserName(userSuggestionSelectedValue);
			}
		}
	}
	
	// **** End of user name validations section *****
	
	
	// **** start of password validations section *****
	
	//Password Field validations
	public void checkPwd(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			checkPwdContent();
		}
	}
	
	private boolean checkPwdContent(){
		boolean result=true;
		UserVO tempUserVO = new UserVO();
		tempUserVO.setUserName(getUserName());
		tempUserVO.setPassword(getPassword());
		HashMap<String, String> validatePwdMap = TrustbrokerWebAppUtil.validatePwdContent(tempUserVO);
		 	
	 	if (getPassword()!= null && getPassword().contains(PWD_INVALID_SPL_CHAR)) {
			addFacesMessage("userStepupProfileId:pwd", tbResources.getString("pwdSplCharErrMasg"));
			result = false;
		}
		if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME)) {
			addFacesMessage("userStepupProfileId:pwd",(String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME));
			result=false;
		}
		if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE)) {
			addFacesMessage("userStepupProfileId:pwd", (String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE));
			result=false;
		}
		if(getPassword() != null && getConfirmPassword() != null && !getPassword().equals(getConfirmPassword())) {
			addFacesMessage("userStepupProfileId:pwd", tbResources.getString("pwdDoNotMatch"));
			result=false;
		}		
			
		return result;
	}
	
	private boolean validatePasswordFields() {
		boolean result = true;
		
		if(StringUtils.isBlank(getPassword()) || StringUtils.isBlank(getConfirmPassword())){
			result = false;
			addFacesMessage("userStepupProfileId:pwd","Password is required");
			return result;
		}
		
		if (!getPassword().equals(getConfirmPassword()) || isConfPwdSpcErrInd()) {
			result = false;
			addFacesMessage("userStepupProfileId:pwd", tbResources.getString("pwdDoNotMatch"));
			return result;
		}
			
		result = checkPwdContent();
		
		if(isPwdSpcErrInd()) {
			addFacesMessage("userStepupProfileId:pwd",tbResources.getString("pwdCannotContainSpaces"));
			result = false;
		} 
		
		if(!TBUtil.isPwdStrengthValid(getPassword())) {
			result = false;
			addFacesMessage("userStepupProfileId:pwd", tbResources.getString("goodOrStrongPwdReq"));
		}
		
		return result;
	}
	
	// **** End of password validations section *****
	
	
	// **** Terms and conditions section *****
	
	private boolean validateTermsAndCondition() {
		
		if(!isTncAccepted()){
			addFacesMessage("userStepupProfileId:tcChkBox1", tbResources.getString("termsAndConditionsMig"));
			addFacesMessage("userStepupProfileId:tcChkBox2", tbResources.getString("termsAndConditionsMig"));
			addFacesMessage("userStepupProfileId:tcChkBox3", tbResources.getString("termsAndConditionsMig"));
			return false;
		}
		if("off".equalsIgnoreCase(getTermsCondition())){
			addFacesMessage("userStepupProfileId:tcChkBox1", tbResources.getString("termsAndConditionsMig"));
			addFacesMessage("userStepupProfileId:tcChkBox2", tbResources.getString("termsAndConditionsMig"));
			addFacesMessage("userStepupProfileId:tcChkBox3", tbResources.getString("termsAndConditionsMig"));
			return false;
		}
		return true;
	}
	
	public boolean acceptTermsAndConditions(){

		try{
			TermsAndConditionsRetrievalServiceResponse response =  container.getReferenceService().fetchTermsAndConditions(null);
			if(!TrustbrokerWebAppUtil.checkResponseStatus(response)){
				return false;
			}
			
			container.getUserService().updateUserAcceptedTermsAndConditionVersion(response.getTermsandConditions(), getCurrentUserVO());
			getCurrentUserVO().setTermsCondition(TrustBrokerWebAppConstants.YES);
			getCurrentUserVO().setTncAgreementVersion(response.getTermsandConditions().getVersion());
			addSessionAttribute(TrustBrokerWebAppConstants.TERMS_CONDITON_ACCEPTED, true);
			return true;
		} catch (OperationFailedException ope) {
			logger.error("Error while excepting terms and condition for user: {}", 
					new String[]{getCurrentUserVO().getUserName(), TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
		}catch(Exception ioEx){
			logger.error("HomeBean:agreeTermsConditions() | Error while redirecting away from terms and condition for user '"
					+ getCurrentUserVO().getUserName() + "'", ioEx);
		}
		return false;
	}
	
	// **** End of Terms and conditions section *****

	
	/**
	 * This method is used to build account recovery methods for the user
	 * 
	 */
	private void buildRecoveryMethods() {

		SelectItem item = null;
		this.acctRecoveryMethods.clear();
		
		if (!StringUtils.isEmpty(userVO.getEmailAddress())) {
			item = new SelectItem(SECEMAIL_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_SecEmailVal"));
			this.acctRecoveryMethods.add(item);
		}
		
		item = new SelectItem(MOBILE_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_MobileVal"));
		this.acctRecoveryMethods.add(item);
		item = new SelectItem(SECQUESTS_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_SecQuestVal"));
		this.acctRecoveryMethods.add(item);
	}
	
	
	/**
	 * This method is used to validate the mobile phone number
	 * 
	 * @param value String
	 * @return boolean
	 */
	private boolean validatePhoneAccRecovery() {
		boolean validPhone = true;

		String mobileNum = getMobilePhone();

		if (!StringUtils.isEmpty(mobileNum)) {
			
			if (mobileNum.length() < 13) {
				addFacesMessage("userStepupProfileId:mobilenum", tbResources.getString("invalidMobileMsg"));
				return false;
			}
			
			String number = mobileNum.substring(1, 4) + mobileNum.substring(5, 8) + mobileNum.substring(9, 13);
			
			if (StringUtils.isEmpty(number.replace("_", ""))) {
				setMobilePhone("");
				addFacesMessage("userStepupProfileId:mobilenum", tbResources.getString("regnacctrecoveryMobilReqMsg"));
				return false;
			}
			
			if (!StringUtils.isNumeric(number)) {
				addFacesMessage("userStepupProfileId:mobilenum", tbResources.getString("invalidMobileMsg"));
				return false;
			}
		}
		return validPhone;
	}
	
	
	private boolean validateSecurityAnswers(String fieldPrefix) {
		String sameAnswer = "";
		boolean retVal = true;
		if(fieldPrefix == null) {
			fieldPrefix = "";
		}

		String answerOne = tbSecurityQuestionsBean.getSecurityAnswerOne();
		String answerTwo = tbSecurityQuestionsBean.getSecurityAnswerTwo();
		String answerThree = tbSecurityQuestionsBean.getSecurityAnswerThree();
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion3 = tbSecurityQuestionsBean.getSecurityQuestionThree();

		if (secQuestion1.equals("null") || secQuestion1.length() == 4) {
			addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("secQuestion1"));
			retVal = false;
		}

		if (secQuestion2.equals("null") || secQuestion2.length() == 4) {
			addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("secQuestion2"));
			retVal = false;
		}

		if (secQuestion3.equals("null") || secQuestion3.length() == 4) {
			addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("secQuestion3"));
			retVal = false;
		}
		
		// implemented when we not give the answers
				if (answerOne.equals("") ) {
					addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("secQuestion1"));
					retVal = false;
				}

				if (answerTwo.equals("") ) {
					addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("secQuestion2"));
					retVal = false;
				}

				if (answerThree.equals("") ) {
					addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("secQuestion3"));
					retVal = false;
				}
		
		if(!retVal) {
			return retVal;
		}

		if (answerOne.equalsIgnoreCase(answerTwo) && answerOne.equalsIgnoreCase(answerThree))
			sameAnswer = answerOne;
		//if (answerTwo.equalsIgnoreCase(answerThree))
		//	sameAnswer = answerTwo;

		if (!"".equals(sameAnswer)) {

			if (StringUtils.containsIgnoreCase(secQuestion1, answerOne) && sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion2, answerTwo) && sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion3, answerThree)
					&& sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion1, answerOne)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion2, answerTwo)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion3, answerThree)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

		} else {
			if (StringUtils.containsIgnoreCase(secQuestion1, answerOne)) {
				retVal = false;

				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
			}

			if (StringUtils.containsIgnoreCase(secQuestion2, answerTwo)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.containsIgnoreCase(secQuestion3, answerThree)) {
				addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}
		}
		
		if(!TBUtil.validateSecurityAnswer(answerOne)){
			retVal = false;
			addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("iframeObsceneTextInAnswer"));
		}
		
		if(!TBUtil.validateSecurityAnswer(answerTwo)){
			retVal = false;
			addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("iframeObsceneTextInAnswer"));
		}
		
		if(!TBUtil.validateSecurityAnswer(answerThree)){
			retVal = false;
			addFacesMessage("userStepupProfileId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("iframeObsceneTextInAnswer"));
		}

		return retVal;
	}
	
	
	 public String getEmailOrDash(){
			
			if(userVO ==null) {
				emailOrDash="---";
			} else if(userVO.getEmailAddress() ==null) {
				emailOrDash="---";
			} else {
				emailOrDash=userVO.getEmailAddress();
			}
			
			return emailOrDash;
		}
	
	 public void skipAccountRecoveryOptions() {
			addSessionAttribute(TrustBrokerWebAppConstants.SKIP_VERIFY_FLOW, "true");
			redirectToView(getWidgetHomeURIWithAlias());
		}
	
	public String getYearOfBirth() {
		return yearOfBirth;
	}

	public void setYearOfBirth(String yearOfBirth) {
		this.yearOfBirth = yearOfBirth;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getTempUserName() {
		return tempUserName;
	}

	public void setTempUserName(String tempUserName) {
		this.tempUserName = tempUserName;
	}

	public List<String> getUserNameSuggestionsList() {
		return userNameSuggestionsList;
	}

	public void setUserNameSuggestionsList(List<String> userNameSuggestionsList) {
		this.userNameSuggestionsList = userNameSuggestionsList;
	}

	public boolean isShowSuggestions() {
		return showSuggestions;
	}

	public void setShowSuggestions(boolean showSuggestions) {
		this.showSuggestions = showSuggestions;
	}

	public List<String> getOldUsernameSuggestionsList() {
		return oldUsernameSuggestionsList;
	}

	public void setOldUsernameSuggestionsList(
			List<String> oldUsernameSuggestionsList) {
		this.oldUsernameSuggestionsList = oldUsernameSuggestionsList;
	}

	public boolean isPwdSpcErrInd() {
		return pwdSpcErrInd;
	}

	public void setPwdSpcErrInd(boolean pwdSpcErrInd) {
		this.pwdSpcErrInd = pwdSpcErrInd;
	}

	public boolean isConfPwdSpcErrInd() {
		return confPwdSpcErrInd;
	}

	public void setConfPwdSpcErrInd(boolean confPwdSpcErrInd) {
		this.confPwdSpcErrInd = confPwdSpcErrInd;
	}

	public String getPasswordStrength() {
		return passwordStrength;
	}

	public void setPasswordStrength(String passwordStrength) {
		this.passwordStrength = passwordStrength;
	}

	public String getTermsCondition() {
		return termsCondition;
	}

	public void setTermsCondition(String termsCondition) {
		this.termsCondition = termsCondition;
	}

	public boolean isTncAccepted() {
		return tncAccepted;
	}

	public void setTncAccepted(boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}

	public String getSecEmailAddress() {
		return secEmailAddress;
	}

	public void setSecEmailAddress(String secEmailAddress) {
		this.secEmailAddress = secEmailAddress;
	}

	public boolean isDisplaySkipOption() {
		return displaySkipOption;
	}

	public void setDisplaySkipOption(boolean displaySkipOption) {
		this.displaySkipOption = displaySkipOption;
	}
	
	public String getOldUserName() {
		return oldUserName;
	}

	public void setOldUserName(String oldUserName) {
		this.oldUserName = oldUserName;
	}
	
	

	public UserStepUpContext getStepUpCtx() {
		return stepUpCtx;
	}

	public void setStepUpCtx(UserStepUpContext stepUpCtx) {
		this.stepUpCtx = stepUpCtx;
	}

	public String getInformationalText() {
		return informationalText;
	}

	public void setInformationalText(String informationalText) {
		this.informationalText = informationalText;
	}

	public String getLastPage() {
		return lastPage;
	}

	public void setLastPage(String lastPage) {
		this.lastPage = lastPage;
	}
	
}
