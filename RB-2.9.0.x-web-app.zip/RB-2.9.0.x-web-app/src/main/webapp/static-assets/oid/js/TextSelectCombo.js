/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 *
 */
'use strict';
angular.module('oid.component.oidTextSelectCombo', ['uitk.maxlength']).directive('oidTextSelectCombo',['$timeout', function ($timeout){
	return {
		restrict:'E',
		replace : true,
		transclude: true,
		
		controller: ["$scope", function($scope) {
            if($scope.maxCharacterAllowed) {
                $scope.maxCharCount = $scope.maxCharacterAllowed;
            }
		}],
		
        link: function(scope, elem, attrs){               	
        	scope.selectStyle = {
        		"background-color": "#f8f0ef",
        		"color" : "#666"
        	};
        	
        	scope.wrapStyle = {"word-break" : "break-all"};
        	
        	if(scope.maxCharacterAllowed && !scope.maxCharacterAllowedMessage){
                scope.maxCharacterAllowedMessage = "Accepts no more than "+scope.maxCharacterAllowed+" characters";
            }

        	scope.blurEvent = function(event) {
        		scope.checkFieldValidation = true;
				$timeout(function(){
					scope.onBlur(event);
				});
			};

			scope.focusEvent = function(event){
				$timeout(function(){
					scope.onFocus(event);
				});
			};

			scope.keypressEvent = function(event){
				$timeout(function(){
					scope.onKeypress(event);
				});
			};
			
			scope.pasteEvent = function(event) {
                var pasteText = (event.originalEvent || event).clipboardData.getData('text/plain');
                if(scope.maxCharacterAllowed && (scope.model || '').length + pasteText.length > scope.maxCharacterAllowed){
                    scope.model = ((scope.model || '') + pasteText).substring(0, scope.maxCharacterAllowed);
                    event.preventDefault();
                }
            }
			
			scope.onchangeEvent = function(event) {
				$timeout(function(){
					scope.onChange(event);
				});
			}
			
			scope.keyupEvent = function(event){
				$timeout(function(){
					scope.onKeyup(event);
				});
			};

			scope.keydownEvent = function(event){
				$timeout(function(){
					scope.onKeydown(event);
				});
			};
			
			scope.navigate = function(ev, val){
				if(ev.keyCode === 13){
					scope.showUserNameSuggestion = false;
					scope.toModel(val);
				}
			}
			
			scope.clickHandler = function(val){
				var userNameInputId = document.getElementById(scope.id + "_input");
				var userNameInputInfo = document.getElementById(scope.id + "_info");
				$timeout(function() {
					angular.element(userNameInputId).attr("aria-invalid", "false");
					angular.element(userNameInputId).attr("aria-describedby", "userNameTipId");
					scope.toModel(val);
				}, 10);
				
				$timeout(function() {
					angular.element(userNameInputId).focus();
					angular.element(userNameInputId).select();
					angular.element(userNameInputInfo).parent().attr("style", "display:none;");
				}, 100);
			}

			scope.toModel = function(val){
				scope.model = val;
			}

			scope.$watch("model", function(newValue){
				if(newValue !== scope.initialValue) {
					scope.checkFieldValidation = true;
				}
			});
        },
        
        scope : {
        	id : '@',
        	name : '@',
        	model: '=',
        	checkFieldValidation: '=',
        	tkRequired:'=',
        	styleClass: '@',
        	tkErrorClass: '=',
        	tkDisabled : '@',
        	maxCharacterAllowed:'@',
            maxCharacterAllowedMessage: '@',
        	onBlur: '&', 
        	onFocus: '&',
        	onKeypress: '&',
        	onKeyup: '&',
        	onKeydown: '&',
        	onChange: '&',
			itemList:'=',
			selectInfoMsg:'=',	
			showUserNameSuggestion: '=',
			selectOptumIdMsg: '=',
	        suggestionBoxClass: '@'
		},
        template: ['<div>',
						'<input id="{{id}}_input" type="text" ng-attr-name="{{name}}"   ng-keydown="keydownEvent($event);" ng-change="onchangeEvent($event)"',
						    'class="tk-input-masking {{styleClass}}" ng-class="{\'tk-form-field-error\':tkErrorClass}"',
						    'ng-blur="blurEvent($event, model)" ng-focus="focusEvent($event)" ng-keypress="keypressEvent($event)"',
						    'ng-model="model" autocomplete="off" aria-autocomplete="none" aria-required="{{tkRequired ? true : false}}"',
						    'ng-disabled="{{tkDisabled}}" ng-keyup="keyupEvent($event)" ng-trim="false" uitk-maxlength="{{maxCharCount}}"', 
						    'ng-required="(tkRequired && checkFieldValidation) ? true : false">',
						'</input>',
						'<div ng-style="selectStyle" class="tk-margin-bottom-min errBg {{suggestionBoxClass}} " ng-if="showUserNameSuggestion">',
							'<div class="tk-rfrm-validation tk-padding-halft">',
							    '<small class="error uitk-msg-error-inline" id="{{id}}_info" tabindex="-1">',
							        '<span ng-bind="selectInfoMsg"/>',
							    '</small>',
							    '<ul ng-style="wrapStyle" id="{{id}}_suggestions">',
								    '<li ng-repeat="opts in itemList" class="tk-padding-left-halft tk-padding-top-halft">',
										'<a title="{{selectOptumIdMsg}}" ng-keyup="navigate($event, opts.value)" id="{{id}}_link_{{$index}}" ng-click="clickHandler(opts.value)" ng-bind="opts.label" class="selectContainer" href></a>',
									'</li>',
								'</ul>',
							'</div>',
						'</div>',
					'</div>'].join('')
    };

}]);
