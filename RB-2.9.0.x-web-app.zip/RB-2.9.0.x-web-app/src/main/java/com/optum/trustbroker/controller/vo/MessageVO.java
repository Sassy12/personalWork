package com.optum.trustbroker.controller.vo;

import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class MessageVO extends ResponseVO{
	private String message = null;
	private Map<String, String> errorMap;
	
	private String userName = null;
	
	/**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }
    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getMessage() {
		return message;
	}
	public void setMessage(String msg) {
		this.message = msg;
	}
	@Override
    public Map<String, String> getErrorMap() {
		return errorMap;
	}
	@Override
    public void setErrorMap(Map<String, String> errorMap) {
		this.errorMap = errorMap;
	}
}