/*******************************************************************************
 * Copyright (c) 2012 Optum - All Rights Reserved. 
 ******************************************************************************/
package com.optum.trustbroker.managebean;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.UITab;
import org.richfaces.component.UITabPanel;
import org.richfaces.event.ItemChangeEvent;

import com.ingenix.uitoolkit.extendingProperties.ProductConfigurationMessageProvider;
import com.ingenix.uitoolkit.extendingProperties.ProductResourcesMessageProvider;
import com.ingenix.uitoolkit.util.UIToolKitUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.alps.common.http.HttpUtils;

@ManagedBean(name = "navBean")
@RequestScoped
public class NavBean extends AbstractBackingBean implements Serializable {

	private static final Logger LOGGER = Logger.getLogger(NavBean.class);
	private static final long serialVersionUID = 1L;
	private static final ResourceBundle prodResourceBundle = ResourceBundle
			.getBundle("productResources");
	private static final ResourceBundle prodConfigBundle = ResourceBundle
			.getBundle("productConfigurations");
	protected static ResourceBundle uitResources = ResourceBundle
			.getBundle("uiToolkitResources");
	private static final String TITLE = "Title";
	private static final String LINK = "Link";
	private static final String PRIMARY_NAV = "PrimaryNav";
	private static final String SECONDARY_NAV = "SecondaryNav";
	private static final String ID = "ID";
	private static final String SUB = "Sub";
	private static final String IDFILTER = "trustbroker";
	private static final String DELIMITERS = "[,;]+";
	private static final String userPersonalInfoLink = prodConfigBundle
			.getString("userPersonalInfoLink");
	private static final String userChangePwdLink = prodConfigBundle
			.getString("userChangePwdLink");

	private transient UITabPanel horizontalNavTabPanel;
	private transient List<UITab> horizontalNavTabNamesList = new ArrayList<UITab>();
	private String horizontalNavActiveTabName;
	private Map<String, String> horizontalNavMap = new LinkedHashMap<String, String>();
	String horizontalNavfirstTabName = "";
	private List<String> secondaryNavNames = new ArrayList<String>();
	private List<String> secondaryNavLinks = new ArrayList<String>();

	ProductResourcesMessageProvider prodResoucesObj = new ProductResourcesMessageProvider();
	ProductConfigurationMessageProvider prodConfigObj = new ProductConfigurationMessageProvider();
	private final  boolean enableSecNavOnProfilePage = Boolean
			.parseBoolean((String) prodConfigObj
					.get("enableSecNavOnProfilePage"));
	private static final String HOME_PAGE_VIEW_ID = tbResources.getString("homePageViewId").replace("xhtml", "jsf");
	
	private static String UpdateSecQuestionsPage="/secure/updatesecurityquestions.jsf";
	
	public static String USERACCTRECOVERYIND = "UserAccrRecoveryInd";

	public void clearActiveTabStyle() {
		if (horizontalNavTabPanel != null)
			horizontalNavTabPanel.setTabActiveHeaderClass("rf-tab-hdr-inact");
	}
	
	@PostConstruct
	public void init() {
				
		String viewId = getFacesContext().getViewRoot().getViewId()
				.replace(".xhtml", ".jsf");
		List<String> tabKeysList = getTabKeys(PRIMARY_NAV, TITLE);
		populateMapWithTabNamesLink(tabKeysList, PRIMARY_NAV, TITLE, LINK,
				horizontalNavMap, horizontalNavTabNamesList);

		/*
		 * if (tabKeysList != null && tabKeysList.size() > 0) {
		 * horizontalNavfirstTabName = (String) prodResoucesObj .get(PRIMARY_NAV
		 * + 1 + TITLE); }
		 */
		String activeTabNameSessionParam = (String) getSessionAttribute(TrustBrokerWebAppConstants.SESSION_ACTIVE_TAB_NM);
		if (activeTabNameSessionParam == null) {
			if (checkViewExists(viewId)) {
				horizontalNavActiveTabName = getKeysFromValue(horizontalNavMap,viewId, horizontalNavfirstTabName);
				addSessionAttribute(TrustBrokerWebAppConstants.SESSION_ACTIVE_TAB_NM, horizontalNavActiveTabName);
			} else {
				String subLink = getSubLinks(PRIMARY_NAV, LINK, SUB, viewId);
				if (!subLink.equals("")) {
					horizontalNavActiveTabName = subLink;
					addSessionAttribute(TrustBrokerWebAppConstants.SESSION_ACTIVE_TAB_NM, horizontalNavActiveTabName);
				} else
					horizontalNavActiveTabName = horizontalNavfirstTabName;
			}
		} else {
			horizontalNavActiveTabName = null;
			if (checkViewExists(viewId)) {
				horizontalNavActiveTabName = getKeysFromValue(horizontalNavMap, viewId, horizontalNavfirstTabName);
			}
			if (horizontalNavActiveTabName == null) {
				if (horizontalNavMap.containsKey(activeTabNameSessionParam)) {
					horizontalNavActiveTabName = activeTabNameSessionParam;
				} else {
					horizontalNavActiveTabName = getKeysFromValue(horizontalNavMap, viewId, horizontalNavfirstTabName);
				}
			}
			addSessionAttribute(TrustBrokerWebAppConstants.SESSION_ACTIVE_TAB_NM, horizontalNavActiveTabName);
		}

		populateListForSecNav(tabKeysList, viewId);

		
		
		//Added the below code to display return to RP button in nav page when the user comes from any RP app
		if(StringUtils.isBlank((String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL)) &&
				StringUtils.isBlank((String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)) &&
				!viewId.toUpperCase().startsWith(HOME_PAGE_VIEW_ID.toUpperCase())){
			addRelyingPartyRequestParam(TrustBrokerWebAppConstants.TARGET, TrustBrokerWebAppConstants.RELYING_APP_URL_PROF,
					getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
			addRelyingPartyRequestParam(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, TrustBrokerWebAppConstants.RELYING_APP_ID,
					getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
		}
		// Commenting out the code because once relying party information has been stored in session during login page, it 
		// need not to be set again, also when redirection happens to home page after login the rpAppid param which is coming
		// is not rpAPpId but the alias. When user comes through update profile or other flows we capture both target and app 
		// id on session and needs to be taken care from there only. IF we need to add session 
	}

	private boolean checkViewExists(String view) {
		boolean viewExists = false;
		Iterator<String> navValItr = this.horizontalNavMap.values().iterator();
		if(view != null) {
			int viewInd = view.indexOf('?');
			if(viewInd <= 0) {
				viewInd = view.length();
			}
			view = view.substring(0, viewInd);		
			String navMapVal = null;	
			int navValInd = 0;
			while(navValItr.hasNext()) {
				navMapVal = navValItr.next();
				navValInd = navMapVal.indexOf('?');
				if(navValInd <= 0) {
					navValInd = navMapVal.length();
				}
				navMapVal = navMapVal.substring(0, navValInd);
				viewExists = navMapVal.contains(view);
				if(viewExists) {
					break;
				}
			}
		}
		return viewExists;
	}
	private void populateListForSecNav(List<String> tabKeysList, String viewId) {

		if (getSessionMap().get("activeSecondaryNavigavion") != null)
			activeSecondaryNavNumber = (Integer) getSessionMap().get(
					"activeSecondaryNavigavion");
		else
			activeSecondaryNavNumber = 0;

		if (enableSecNavOnProfilePage) {
			if (addSecNavTabsForProfile(viewId) > 0)
				return;
		} else {
			if (checkProfilePage(viewId, userPersonalInfoLink,
					userChangePwdLink) > 0) {
				secondaryNavNames.clear();
				secondaryNavLinks.clear();
				return;
			}
		}

		String propertyName = "";
		for (String property : tabKeysList) {
			String tabName = prodResourceBundle.getString(property);
			if (tabName.equals(horizontalNavActiveTabName)) {
				propertyName = property;
				break;
			}
		}

		String propertyLink = propertyName.replace(PRIMARY_NAV, SECONDARY_NAV);
		propertyLink = propertyLink.replace(TITLE, LINK);
		propertyName = propertyName.replace(PRIMARY_NAV, SECONDARY_NAV);

		secondaryNavNames.clear();
		secondaryNavLinks.clear();
		for (int i = 1; i <= 10; i++) {
			String secProperty = (String) prodResoucesObj.get(propertyName + i);
			String secLink = (String) prodConfigObj.get(propertyLink + i);
			if ((secProperty != null) && (!"".equals(secProperty))
					&& (!"".equals(secLink))) {
				secondaryNavNames.add(secProperty);
				secondaryNavLinks.add(secLink);
			}
		}

	}

	private int addSecNavTabsForProfile(String viewId) {
		int pageNum = checkProfilePage(viewId, userPersonalInfoLink,
				userChangePwdLink);
		if (pageNum > 0) {
			activeSecondaryNavNumber = pageNum - 1;
			getSessionMap().put("activeSecondaryNavigavion",
					activeSecondaryNavNumber);

			secondaryNavNames.clear();
			secondaryNavLinks.clear();

			secondaryNavLinks.add("/uit/" + userPersonalInfoLink);
			secondaryNavLinks.add("/uit/" + userChangePwdLink);

			secondaryNavNames.add(uitResources.getString("personalInformation"));
			secondaryNavNames.add(uitResources.getString("changePwd"));
		}
		return pageNum;
	}

	private int checkProfilePage(String viewId, String link1, String link2) {
		if (viewId.contains(link1.replace("?faces-redirect=true", "")))
			return 1;
		if (viewId.contains(link2.replace("?faces-redirect=true", "")))
			return 2;
		return 0;
	}

	private int activeSecondaryNavNumber = 0;

	public void secondaryNavAction() throws IOException {
		int number = Integer.parseInt(getFacesContext().getExternalContext().getRequestParameterMap().get("secondaryNavActionNumber"));
		activeSecondaryNavNumber = number;

		getSessionMap().put("activeSecondaryNavigavion",
				activeSecondaryNavNumber);

		String link = secondaryNavLinks.get(number);

		if ("#".equals(link)) {
			String currentViewId = getFacesContext().getViewRoot().getViewId()
					.replaceAll(".xhtml", ".jsf");
			getFacesContext().getExternalContext().redirect(
					getFacesContext().getExternalContext()
							.getRequestContextPath() + currentViewId);
		} else {
			getFacesContext().getExternalContext().redirect(
					getFacesContext().getExternalContext()
							.getRequestContextPath() + link);
		}
		getFacesContext().responseComplete();

	}

	private String getSubLinks(String primaryNav, String link, String sub,
			String searchStr) {
		Enumeration<String> titleKeys = prodConfigBundle.getKeys();
		while (titleKeys.hasMoreElements()) {
			String propertyKey = titleKeys.nextElement();
			if (propertyKey.contains(primaryNav) && propertyKey.contains(link)
					&& propertyKey.contains(sub)) {
				String[] tokens = ((String) prodConfigBundle
						.getObject(propertyKey)).split(DELIMITERS);
				for (String propertyLink : tokens) {
					if (propertyLink.trim().equals(searchStr)) {
						propertyKey = propertyKey.substring(0,
								propertyKey.lastIndexOf(link));
						propertyKey = propertyKey.replace(sub, "Title");
						String titleResult = (String) prodResourceBundle
								.getObject(propertyKey);
						return titleResult;
					}
				}
			}
		}
		return "";
	}

	public static String getKeysFromValue(Map<String, String> navMap,
			String value, String failReturn) {
		for (Entry<String, String> title : navMap.entrySet()) {
			if (title.getValue().equals(value)) {
				return title.getKey();
			}
		}
		return failReturn;
	}

	public UITabPanel getHorizontalNavTabPanel() {
		return horizontalNavTabPanel;
	}

	public void setHorizontalNavTabPanel(UITabPanel horizontalNavTabPanel) {
		this.horizontalNavTabPanel = horizontalNavTabPanel;
	}

	public List<UITab> getHorizontalNavTabNamesList() {
		return horizontalNavTabNamesList;
	}

	public void setHorizontalNavTabNamesList(
			List<UITab> horizontalNavTabNamesList) {
		this.horizontalNavTabNamesList = horizontalNavTabNamesList;
	}

	public String getHorizontalNavActiveTabName() {
		return horizontalNavActiveTabName;
	}

	public void setHorizontalNavActiveTabName(String horizontalNavActiveTabName) {
		this.horizontalNavActiveTabName = horizontalNavActiveTabName;
	}

	public Map<String, String> getHorizontalNavMap() {
		return horizontalNavMap;
	}

	public void setHorizontalNavMap(Map<String, String> horizontalNavMap) {
		this.horizontalNavMap = horizontalNavMap;
	}

	

	@Override
	public Map<String, Object> getSessionMap() {
		return getFacesContext().getExternalContext().getSessionMap();
	}

	private void populateMapWithTabNamesLink(List<String> tabKeysList, String firstPart, String title, String link, 
			Map<String, String> map, List<UITab> tabNamesList) {
		
		int tabKeysListSize = tabKeysList.size();
		removeSessionAttribute(TrustBrokerWebAppConstants.AUTH_STEP_UP);
		createUserSession(); //Code moved to one common location as same is required at other identified place as well. 
		// also it has to be at one common place from future perspective.
		
		for (int i = 1; i <= tabKeysListSize; i++) {
			String tabNameValue = (String) prodResoucesObj.get(firstPart + i
					+ title);
			String tabLinkValue = prodConfigObj.get(firstPart + i + link)
					.toString();
			String tabIdValue = (String) prodResoucesObj
					.get(firstPart + i + ID);
			if (!"".equals(tabNameValue) && !"".equals(tabLinkValue)
					&& !"".equals(tabIdValue) && tabIdValue.contains(IDFILTER)) {
				if (TrustBrokerConstants.HOME_TAB.equals(tabNameValue) && 
						getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS) != null){
					tabLinkValue = HttpUtils.addParameterToURL(tabLinkValue, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, 
							(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS));
				}
				generateTabs(tabNameValue, tabNamesList, tabIdValue);
			  map.put(tabNameValue, tabLinkValue);
			}
		}
		if (!map.isEmpty()) {
			Map.Entry<String, String> entry = map.entrySet().iterator().next();
			horizontalNavfirstTabName = entry.getKey();
		}
//		LOGGER.debug("horizontalNavActiveTabName=" + horizontalNavActiveTabName);
	}

	private void generateTabs(String tabNameValue, List<UITab> tabNamesList,
			String tabIdValue) {
		UITab myTab = new UITab();
		myTab.setName(tabNameValue);
		myTab.setId(tabIdValue);
		tabNamesList.add(myTab);
	}

	private static List<String> getTabKeys(String firstPart, String secondPart) {
		List<String> keysList = new ArrayList<String>();
		Enumeration<String> titleKeys = prodResourceBundle.getKeys();
		while (titleKeys.hasMoreElements()) {
			String title = titleKeys.nextElement();
			if (title.contains(firstPart) && title.contains(secondPart)) {
				keysList.add(title);
			}
		}
		return keysList;
	}

	public void tabChanged(ItemChangeEvent event) {
		

		activeSecondaryNavNumber = 0;
		addSessionAttribute(TrustBrokerWebAppConstants.ACTIVE_SECONDARY_NAVIGATION, activeSecondaryNavNumber);

		horizontalNavActiveTabName = event.getNewItemName().toString();
		FacesContext facesContext = getFacesContext();
		addSessionAttribute(TrustBrokerWebAppConstants.SESSION_ACTIVE_TAB_NM, horizontalNavActiveTabName);
		try {
			String linkValue = horizontalNavMap.get(horizontalNavActiveTabName);
			String currentViewId = facesContext.getViewRoot().getViewId();
			currentViewId = currentViewId.replaceAll(".xhtml", ".jsf");
			if ("#".equals(linkValue)) {
				facesContext.getExternalContext().redirect(
						facesContext.getExternalContext()
								.getRequestContextPath() + currentViewId);
			} else {
				facesContext.getExternalContext().redirect(
						facesContext.getExternalContext()
								.getRequestContextPath()
								+ horizontalNavMap.get(horizontalNavActiveTabName));
			}
			facesContext.responseComplete();
		} catch (IOException e) {
			LOGGER.error(UIToolKitUtil.getStackTrace(e));
		}
	}

	public void tabChangedParticular(ActionEvent event) {
		tabChanged(new ItemChangeEvent(horizontalNavTabPanel,
				horizontalNavActiveTabName, horizontalNavTabPanel,
				horizontalNavActiveTabName, horizontalNavTabPanel));
	}

	public List<String> getSecondaryNavNames() {
		return secondaryNavNames;
	}

	public void setSecondaryNavNames(List<String> secondaryNavNames) {
		this.secondaryNavNames = secondaryNavNames;
	}

	public List<String> getSecondaryNavLinks() {
		return secondaryNavLinks;
	}

	public void setSecondaryNavLinks(List<String> secondaryNavLinks) {
		this.secondaryNavLinks = secondaryNavLinks;
	}

	public int getActiveSecondaryNavNumber() {
		return activeSecondaryNavNumber;
	}

	public void setActiveSecondaryNavNumber(int activeSecondaryNavNumber) {
		this.activeSecondaryNavNumber = activeSecondaryNavNumber;
	}
	
	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}
	
	public String returnToRPApp() {
		String relyingAppUrl = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);
		String action = (String)getSessionAttribute(TrustBrokerWebAppConstants.ACTION);
		String relyingAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		
		if(isValidAcctRecoveryExists()) {
			clearSessionAttributes(new String[]{ TrustBrokerWebAppConstants.RELYING_APP_URL_PROF, 
					TrustBrokerWebAppConstants.ACTION, TrustBrokerWebAppConstants.RELYING_APP_ID});
			return redirectToRelyingParty(
					relyingAppUrl,
					action, TrustBrokerWebAppConstants.SUCCESS,
					relyingAppId);		
		} else {
			addSessionAttribute(USERACCTRECOVERYIND, "false");
			redirectToView(UpdateSecQuestionsPage);
			return null;
		}
	}
	
	private boolean isValidAcctRecoveryExists() {
		boolean validAcctRecovery = false;
		UserVO user = geteSSOUser(getCurrentUserVO().getUuId());

		if( (!StringUtils.isEmpty(user.getEmailAddress()) && user.isPrimaryEmailUnique() && user.isIsemailVerified()) || 
				(!StringUtils.isEmpty(user.getSecEmailAddress()) && user.isSecEmailUnique() && user.isSecEmailVerified())	|| 
				(!StringUtils.isEmpty(user.getPhoneNumber()) && user.getIsPhoneVerified()) ||
				(user.getUserChallengeQuestions() != null && !user.getUserChallengeQuestions().isEmpty()) ) {
			validAcctRecovery = true;
		}
		
		return validAcctRecovery;
	}
		
	private UserVO geteSSOUser(String uuid) {
		UserVO essoUserVO = null;
		try {
			UserRetrievalServiceResponse userRetrievalServiceResponse = container.getUserService().fetchUserProfile(uuid,true, true);
			essoUserVO = userRetrievalServiceResponse.getUser();
		} catch (OperationFailedException e) {
			logger.info(" Failed to get the User details from eSSO for UUID "+ uuid);
			throw new OperationFailedException("Failed to get the User details from eSSO");
		}
		return essoUserVO;
	}
}
