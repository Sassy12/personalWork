(function() {
    'use strict';

    var tbApp = angular.module('tbApp');

    tbApp.controller('VerifyOptionsController', VerifyOptionsController);

    VerifyOptionsController.$inject = ['$scope', 'ProfileService', '$translate', '$timeout', '$state', '$rootScope', '$window', 'HelpObj', 'trustbrokerAriaService'];

    function VerifyOptionsController($scope, ProfileService, $translate, $timeout, $state, $rootScope, $window, HelpObj, trustbrokerAriaService) {
        HelpObj.setHelpObj({ url: '../../webHelp/Default_CSH.htm#Optum ID CSH/entry_1017_Manage_Verification_Options_on_Profile.htm' });

        $scope.constants = $rootScope.constants;
        $scope.fireErrorTracker = $rootScope.fireErrorTracker;
        $scope.trackError = $rootScope.trackError;

        var self = this;
        self.securityQstns = [];
        self.question1 = null;
        self.question2 = null;
        self.question3 = null;
        self.userName = '';
        self.showPrimaryEmailTip = false;
        self.showChkBoxForSecEmail = false;
        self.showChkBoxForMobile = false;
        self.showUpToDateMsg = false;
        self.errors = {
            'primaryEmail': {}
        };
        self.serverErrors = {};
        self.processing = false;
        self.secQstnsReq = false;
        self.formStatus = {};

        var select = {
            label: $translate.instant('select'),
            value: ''
        };

        self.questionList1 = [select];
        self.questionList2 = [select];
        self.questionList3 = [select];

        resetErrors();

        angular.element('#verifyoptionsForm').off().on('change', function() {
            self.formChanged = true;
        });

        var errorMarkup = {
            'formErrorNote': '<span translate="formErrorsNote"></span>'
        };

        self.errorMessageModel = {
            animationTime: 1,
            ariaAttributes: true,
            autoFadeOut: false,
            headingLevel: '2',
            id: 'Error',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            content: errorMarkup.formErrorNote,
            visible: true
        };

        self.successMessageModel = {
            animationTime: 1,
            ariaAttributes: true,
            autoFadeOut: false,
            content: '<span translate="profileUptoDate"></span>',
            headingLevel: '2',
            id: 'Success',
            messageRole: 'alert',
            messageType: 'information',
            position: 'inline',
            visible: true
        };

        var pageData = null;
        // var primaryEmailModified = false;
        // var secondaryEmailModified = false;

        var secData = ProfileService.getVerifyOptionsPageData();
        pageData = secData;
        var profile = secData.profile;
        var securityCtx = secData.securityContext;
        self.userName = profile.userName;
        self.primaryEmail = profile.primaryEmailAddress;

        if (profile.secondaryEmailAddress) {
            self.secondaryValid = true;
        }

        self.secondaryEmail = profile.secondaryEmailAddress;
        self.mobileNo = profile.phoneNo;

        var allQuestions = angular.copy(securityCtx.questions);
        allQuestions.unshift(select);
        self.allQuestions = allQuestions;

        self.answer1 = securityCtx.ansOne;
        self.answer2 = securityCtx.ansTwo;
        self.answer3 = securityCtx.ansThree;

        self.secQstnsReq = secData.securityQuestionsReq;

        if (profile.primaryEmailVerified) {
            self.showPrimaryEmailTip = true;
        }

        if (!validators.checkIfEmpty(profile.secondaryEmailAddress)) {
            if (profile.secondaryEmailVerified) {
                self.showSecEmailVerified = true;
            } else {
                self.showSecEmailLink = true;
            }
        }

        if (!validators.checkIfEmpty(profile.phoneNo)) {
            if (profile.phoneNoVerified) {
                self.showMobileNoVerified = true;
            } else {
                self.showMobileLink = true;
            }
        }

        self.questionList1 = allQuestions.filter(function(val) {
            if (val.value === securityCtx.id1) {
                self.question1 = val;
            } else if (val.value === securityCtx.id2 || val.value === securityCtx.id3) {
                return false;
            }

            return true;
        });

        self.questionList2 = allQuestions.filter(function(val) {
            if (val.value === securityCtx.id2) {
                self.question2 = val;
            } else if (val.value === securityCtx.id1 || val.value === securityCtx.id3) {
                return false;
            }

            return true;
        });

        self.questionList3 = allQuestions.filter(function(val) {
            if (val.value === securityCtx.id3) {
                self.question3 = val;
            } else if (val.value === securityCtx.id1 || val.value === securityCtx.id2) {
                return false;
            }

            return true;
        });

        var currentState = {
            profile: {
                'userName': profile.userName,
                'uuid': profile.uuid,
                'primaryEmailAddress': profile.primaryEmailAddress,
                'secondaryEmailAddress': profile.secondaryEmailAddress || '',
                'phoneNo': profile.phoneNo || ''
            }
        };

        if (self.question1 !== null && !validators.checkIfEmpty(self.answer1)) {
            currentState.securityContext = {
                'id1': securityCtx.id1 || '',
                'id2': securityCtx.id2 || '',
                'id3': securityCtx.id3 || '',
                'ansOne': securityCtx.ansOne || '',
                'ansTwo': securityCtx.ansTwo || '',
                'ansThree': securityCtx.ansThree || ''
            };
        }

        /* currentState.showSecEmailLink = false;
        currentState.showMobileLink = false; */

        self.currentState = currentState;

        this.onPrimaryChange = onPrimaryChange;
        this.onSecondaryChange = onSecondaryChange;

        this.questionChanged = function filterQuestions(index) {

            /* By the time this callback is invoked, model value doesn't reflect the latest
             * option from drop-down, So using the jQuery way to retrieve the selected option value */

            var question1Value = angular.element('#question1Id option:selected').attr('label');
            var question2Value = angular.element('#question2Id option:selected').attr('label');
            var question3Value = angular.element('#question3Id option:selected').attr('label');

            var allQuestions = self.allQuestions;

            if (index !== 1) {
                self.questionList1 = allQuestions.filter(function(val) {
                    if (val.label === select.label) {
                        return true;
                    } else if (val.label === question1Value) {
                        self.question1 = val;
                    } else if (val.label === select.label || val.label === question2Value || val.label === question3Value) {
                        return false;
                    }

                    return true;
                });
            }

            if (index !== 2) {
                self.questionList2 = allQuestions.filter(function(val) {
                    if (val.label === select.label) {
                        return true;
                    } else if (val.label === question2Value) {
                        self.question2 = val;
                    } else if (val.label === question1Value || val.label === question3Value) {
                        return false;
                    }

                    return true;
                });
            }

            if (index !== 3) {
                self.questionList3 = allQuestions.filter(function(val) {
                    if (val.label === select.label) {
                        return true;
                    } else if (val.label === question3Value) {
                        self.question3 = val;
                    } else if (val.label === select.label || val.label === question1Value || val.label === question2Value) {
                        return false;
                    }

                    return true;
                });
            }
        };

        this.onMobileNoChange = onMobileNoChange;

        this.onCancel = function($event) {
            if (self.checkForUnsavedChanges()) {
                $event.preventDefault();
                ProfileService.saveTempTabIndex(0);
                ProfileService.showModal();
                return false;
            }

            if (pageData.rpContext && pageData.rpContext.targetURL) {
                $window.location.href = pageData.rpContext.targetURL;
            } else {
                ProfileService.updateTabIndex(0);

                $timeout(function() {
                    angular.element('#profiletabs_tab0_tab').focus();
                }, 300);
            }
        };

        $scope.validateSecAnsText = function(event) {
            return validators.validateSecAns(event);
        };

        function onPrimaryChange() {
            if (self.primaryEmail === pageData.profile.primaryEmailAddress) {
                self.showPrimaryEmailTip = true;
            } else {
                self.showPrimaryEmailTip = false;
            }
        }

        function onSecondaryChange() {
            if (self.secondaryEmail === pageData.profile.secondaryEmailAddress) {
                if (pageData.profile.secondaryEmailVerified) {
                    self.showSecEmailVerified = true;
                    self.showSecEmailLink = false;
                } else {
                    self.showSecEmailLink = true;
                    self.showSecEmailVerified = false;
                }
            } else {
                self.showSecEmailVerified = false;
                self.showSecEmailLink = false;
            }
        }

        function updateEmailErrors() {
            if (!validators.checkIfEmpty(self.secondaryEmail)) {
                self.errors.secondaryEmailInvalid = !self.secondaryValid;
                self.secondaryEmailError = !self.secondaryValid;
            } else {
                self.errors.secondaryEmailInvalid = false;
                self.secondaryEmailError = false;
            }
        }

        function onMobileNoChange() {
            if (self.mobileNo === pageData.profile.phoneNo) {
                if (pageData.profile.phoneNoVerified) {
                    self.showMobileNoVerified = true;
                    self.showMobileLink = false;
                } else {
                    self.showMobileNoVerified = false;
                    self.showMobileLink = true;
                }
            } else {
                self.showMobileNoVerified = false;
                self.showMobileLink = false;
            }
        }

        function validatePrimaryEmail() {
            var emailErrors = {};
            self.errors.primaryEmail = emailErrors;

            if (self.primaryEmail === pageData.profile.primaryEmailAddress) {
                self.showPrimaryEmailTip = true;
            } else {
                self.showPrimaryEmailTip = false;
            }

            if (validators.checkIfEmpty(self.primaryEmail)) {
                emailErrors.required = true;
            } else if (!validators.isValidEmail(self.primaryEmail)) {
                emailErrors.invalid = true;
            }

            if (Object.keys(emailErrors).length <= 0) {
                self.primaryValid = true;
                self.primaryEmailError = false;
            } else {
                self.primaryValid = false;
                self.primaryEmailError = true;
                self.showPrimaryEmailTip = false;
            }
        }

        function validateEmail(email) {
            return !validators.checkIfEmpty(email) && validators.isValidEmail(email);
        }

        function validateQuestion1() {
            if (self.question1.value === '') {
                self.errors.question1Error = true;
            } else {
                self.errors.question1Error = false;
            }
        }

        function validateQuestion2() {
            if (self.question2.value === '') {
                self.errors.question2Error = true;
            } else {
                self.errors.question2Error = false;
            }
        }

        function validateQuestion3() {
            if (self.question3.value === '') {
                self.errors.question3Error = true;
            } else {
                self.errors.question3Error = false;
            }
        }

        function ans1Changed() {
            if (pageData.securityQuestionsReq && validators.checkIfEmpty(self.answer1)) {
                self.ans1Error = true;
                self.errors.answer1Req = true;
            } else if (self.question1.value !== '' && validators.checkIfEmpty(self.answer1)) {
                self.ans1Error = true;
                self.errors.answer1Req = true;
            } else {
                self.ans1Error = self.errors.invalidAns1 || false;
                self.errors.answer1Req = false;
            }
        }

        function ans2Changed() {
            if (pageData.securityQuestionsReq && validators.checkIfEmpty(self.answer2)) {
                self.ans2Error = true;
                self.errors.answer2Req = true;
            } else if (self.question2.value !== '' && validators.checkIfEmpty(self.answer2)) {
                self.ans2Error = true;
                self.errors.answer2Req = true;
            } else {
                self.ans2Error = self.errors.invalidAns2 || false;
                self.errors.answer2Req = false;
            }
        }

        function ans3Changed() {
            if (pageData.securityQuestionsReq && validators.checkIfEmpty(self.answer3)) {
                self.ans3Error = true;
                self.errors.answer3Req = true;
            } else if (self.question3.value !== '' && validators.checkIfEmpty(self.answer3)) {
                self.ans3Error = true;
                self.errors.answer3Req = true;
            } else {
                self.ans3Error = self.errors.invalidAns3 || false;
                self.errors.answer3Req = false;
            }
        }

        function getCurrentState(viewModel) {
            var mobileNo = viewModel.mobileNo;

            if (!validators.checkIfEmpty(mobileNo) && mobileNo.length === 10) {
                mobileNo = [
                    mobileNo.substring(0, 3),
                    mobileNo.substring(3, 6),
                    mobileNo.substring(6, 10)
                ].join('-');
            }

            mobileNo = mobileNo || '';

            var postData = {
                profile: {
                    'userName': pageData.profile.userName,
                    'uuid': pageData.profile.uuid,
                    'primaryEmailAddress': viewModel.primaryEmail,
                    'secondaryEmailAddress': viewModel.secondaryEmail,
                    'phoneNo': mobileNo
                }
            };

            if (viewModel.question1 !== null && !validators.checkIfEmpty(viewModel.answer1)) {
                postData.securityContext = {
                    'id1': viewModel.question1.value,
                    'id2': viewModel.question2.value,
                    'id3': viewModel.question3.value,
                    'ansOne': viewModel.answer1,
                    'ansTwo': viewModel.answer2,
                    'ansThree': viewModel.answer3
                };
            }
            return postData;
        }

        this.saveUpdates = function(viewModel) {

            resetErrors();
            self.showError = false;
            self.showUpToDateMsg = false;
            self.errors = {};
            self.serverErrors = {};

            if (self.processing) {
                return;
            } else {
                self.processing = true;
            }

            validateFormData(viewModel, self.errors);

            var hasErrors = false;

            hasErrors = checkForErrors(self.errors.primaryEmail);

            if (!hasErrors) {
                hasErrors = checkForErrors(self.errors);
            }

            if (hasErrors || $scope.verifyoptions_form.$invalid) {
                self.errorMessageModel.content = errorMarkup.formErrorNote;
                self.showError = true;

                // For putting focus and setting WCAG properties
                var FIELDS = [
                    { fld: "primaryEmailId_input",      msg: "primaryEmailId_err" },
                    { fld: "secondaryEmailId_input",    msg: "secondaryEmailId_err" },
                    { fld: "mobileNoId_input",          msg: "mobileNoId_err" },
                    { fld: "question1Id",               msg: "question1Id_err" },
                    { fld: "answer1Id_input",           msg: "answer1Id_err" },
                    { fld: "question2Id",               msg: "question2Id_err" },
                    { fld: "answer2Id_input",           msg: "answer2Id_err" },
                    { fld: "question3Id",               msg: "question3Id_err" },
                    { fld: "answer3Id_input",           msg: "answer3Id_err" }
                ];

                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                }, 200, false);

                self.processing = false;
                $rootScope.fireErrorTracker = true;
                return;
            }

            var postData = getCurrentState(viewModel);

            if (!isFormChanged(postData, self.currentState)) {
                self.showUpToDateMsg = true;
                self.processing = false;

                $timeout(function() {
                    angular.element('#Success').focus();
                }, 300);

                return;
            }

            self.currentState = postData;

            ProfileService.updateVerifyOptions(postData).then(function(response) {
                self.formChanged = false;
                self.processing = false;
                var responseData = response.data,
                    status = responseData.status,
                    fields = responseData.modifiedFields;

                if (status === 'verificationReq' && fields) {
                    var index = fields.indexOf('primaryEmail');

                    if (index !== -1) {
                        $state.go('confirmEmailAddress', {
                            verifyCodesCtx: {
                                viewChannels: ['PRIMARY_EMAIL'],
                                sendChannels: ['PRIMARY_EMAIL'],
                                chann: 'PRIMARY_EMAIL',
                                nextView: 'congratulations',
                                optionValue: viewModel.primaryEmail
                            },
                            fromState: 'home'
                        });
                    } else {
                        var fieldsToVerify = {};
                        fields.forEach(function(value) {
                            fieldsToVerify[value] = viewModel[value];
                        });
                        $state.go('optumIdSuccessVerificationNeeded', { 'fields': fieldsToVerify });
                    }
                } else if (status === 'verificationNotReq') {
                    /* Go to Profile tab if verification is not needed
                     * and show success message there */
                    ProfileService.showSuccessMsg = true;
                    ProfileService.updateTabIndex(0);
                }
            }, function(error) {
                self.formChanged = false;
                self.processing = false;
                var errorData = error.data;

                if (errorData.errorMap) {
                    self.showError = true;

                    var map = errorData.errorMap,
                        prop,
                        serverErrors = {};

                    if (map.form) {
                        self.errorMessageModel.content = [
                            '<span>',
                            map.form,
                            '</span>'
                        ].join('');
                    }

                    for (prop in map) {
                        if (map.hasOwnProperty(prop)) {
                            var errorKey = map[prop];
                            var translatedMsg = $translate.instant(errorKey);

                            if (translatedMsg !== errorKey) {
                                serverErrors[prop] = translatedMsg;
                            } else {
                                serverErrors[prop] = errorKey;
                            }
                        }
                    }

                    self.serverErrors = serverErrors;
                } else if ('message' in errorData) {
                    self.showError = true;
                    self.errorMessageModel.content = [
                        '<span>',
                        errorData.message,
                        '</span>'
                    ].join('');
                }

                $rootScope.fireErrorTracker = true;
            });
        };

        this.checkForUnsavedChanges = function() {
            var postData = getCurrentState(self);
            return isFormChanged(self.currentState, postData);
        };

        this.verifyOption = function($event,option) {
            $event.preventDefault();
            if (option === 'mobileNo') {
                $state.go('mobileVerification', {
                    fieldToVerify: 'mobileNo',
                    fromState: 'home'
                });
            } else if (option === 'secEmail') {
                $state.go('confirmEmailAddress', {
                    verifyCodesCtx: {
                        viewChannels: ['SECONDARY_EMAIL'],
                        sendChannels: ['SECONDARY_EMAIL'],
                        chann: 'SECONDARY_EMAIL',
                        nextView: 'congratulations',
                        optionValue: self.secondaryEmail
                    },
                    fromState: 'home'
                });
            }
            return false;
        };

        function validateFormData(vm, errors) {
            onPrimaryChange();
            onSecondaryChange();
            onMobileNoChange();

            validatePrimaryEmail();
            self.secondaryValid = validateEmail(vm.secondaryEmail);
            updateEmailErrors();

            if (self.primaryValid && self.secondaryValid && !validators.checkIfEmpty(vm.primaryEmail) && (vm.primaryEmail === vm.secondaryEmail)) {
                self.secondaryEmailError = true;
                self.errors.priAndSecEmailSame = true;
                // hide secondary email tip and verify link in this case
                self.showSecEmailVerified = false;
                self.showSecEmailLink = false;
            }

            if (validators.checkIfEmpty(vm.mobileNo)) {
                errors.mobileNoError = false;
            } else if (!validators.isValidMobileNo(vm.mobileNo)) {
                errors.mobileNoError = true;
            }

            if (pageData.securityQuestionsReq) {
                validateQuestion1();
                validateQuestion2();
                validateQuestion3();
                ans1Changed();
                ans2Changed();
                ans3Changed();
            }

            if (!validators.checkIfEmpty(vm.answer1) && !validators.checkIfEmpty(vm.answer2) && !validators.checkIfEmpty(vm.answer3)) {
                if (vm.answer1 === vm.answer2 && vm.answer2 === vm.answer3) {
                    errors.ans1Same = true;
                    errors.ans2Same = true;
                    errors.ans3Same = true;
                    return;
                }
            }

            var qstn, ans;

            if (vm.question1.value !== '') {
                if (!validators.checkIfEmpty(vm.answer1)) {
                    qstn = vm.question1.label.toLowerCase();
                    ans = vm.answer1.toLowerCase();

                    if (qstn.indexOf(ans) !== -1) {
                        errors.invalidAns1 = true;
                        vm.ans1Error = true;
                    }
                } else {
                    vm.ans1Error = true;
                    errors.answer1Req = true;
                }
            } else {
                if (!validators.checkIfEmpty(vm.answer1)) {
                    vm.errors.question1Error = true;
                }
            }

            if (vm.question2.value !== '') {
                if (!validators.checkIfEmpty(vm.answer2)) {
                    qstn = vm.question2.label.toLowerCase();
                    ans = vm.answer2.toLowerCase();

                    if (qstn.indexOf(ans) !== -1) {
                        errors.invalidAns2 = true;
                        vm.ans2Error = true;
                    }
                } else {
                    vm.ans2Error = true;
                    errors.answer2Req = true;
                }
            } else {
                if (!validators.checkIfEmpty(vm.answer2)) {
                    vm.errors.question2Error = true;
                }
            }

            if (vm.question3.value !== '') {
                if (!validators.checkIfEmpty(vm.answer3)) {
                    qstn = vm.question3.label.toLowerCase();
                    ans = vm.answer3.toLowerCase();

                    if (qstn.indexOf(ans) !== -1) {
                        errors.invalidAns3 = true;
                        vm.ans3Error = true;
                    }
                } else {
                    vm.ans3Error = true;
                    errors.answer3Req = true;
                }
            } else {
                if (!validators.checkIfEmpty(vm.answer3)) {
                    vm.errors.question3Error = true;
                }
            }
        }

        function resetErrors() {
            self.primaryEmailError = false;
            self.secondaryEmailError = false;
            self.mobileNoError = false;
            self.question1Error = false;
            self.question2Error = false;
            self.question3Error = false;
            self.ans1Error = false;
            self.ans2Error = false;
            self.ans3Error = false;
        }

        function checkForErrors(errors) {
            var prop;

            for (prop in errors) {
                if (errors[prop] === true) {
                    return true;
                }
            }

            return false;
        }

        function isFormChanged(currentState, prevState) {
            return !angular.equals(currentState, prevState);
        }

        return self;
    }
})();
