package com.optum.trustbroker.controller;

import java.util.ResourceBundle;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.ValidationUtils;

@Service
@Path(TBConstants.USER_CONTROLLER_PATH)
public class UserController extends BaseController {

	@Autowired
	private ValidationUtils validationUtils;

	@Path(TBConstants.USER_SERVICE_VALIDATEFIRSTNAME_PATH)
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoVO validateFirstName(UserInfoVO userInfoVO) {
		if (StringUtils.isNotEmpty(userInfoVO.getFirstName()) && !TBUtil.validateName(userInfoVO.getFirstName())) {
			ResourceBundle bundle = getBundle();
			userInfoVO.addErrorMessage("firstNameError", bundle.getString("numericSpecialCharMsg"));
			return userInfoVO;
		}
		if (StringUtils.isNotEmpty(userInfoVO.getFirstName()) && StringUtils.isNotEmpty(userInfoVO.getLastName())
				&& StringUtils.isNotEmpty(userInfoVO.getEmailAddress())) {
			validationUtils.checkUserExistsWithNameAndEmail(userInfoVO);
		}
		return userInfoVO;
	}

	@Path(TBConstants.USER_SERVICE_VALIDATELASTNAME_PATH)
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoVO validateLastName(UserInfoVO userInfoVO) {

		ResourceBundle bundle = getBundle();
		if (StringUtils.isNotEmpty(userInfoVO.getLastName()) && !TBUtil.validateName(userInfoVO.getLastName())) {
			userInfoVO.addErrorMessage("lastNameError", bundle.getString("lastnumericSpecialCharMsg"));
			return userInfoVO;
		}

		if (StringUtils.isNotEmpty(userInfoVO.getFirstName())
				&& StringUtils.isNotEmpty(userInfoVO.getLastName()) && StringUtils.isNotEmpty(userInfoVO.getEmailAddress())) {
			validationUtils.checkUserExistsWithNameAndEmail(userInfoVO);
		}
		return userInfoVO;
	}

	@Path(TBConstants.USER_SERVICE_VALIDATEUSERNAME_PATH)
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoVO validateUserName(UserInfoVO userInfoVO) {

		if (StringUtils.isNotEmpty(userInfoVO.getUserName())) {
			validationUtils.validateUserName(userInfoVO);
		}
		return userInfoVO;

	}

	@Path(TBConstants.USER_SERVICE_VALIDATEEMAIL_PATH)
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoVO validateEmail(UserInfoVO userInfoVO) {

		if (null != userInfoVO.getRpAppVO() && userInfoVO.getRpAppVO().isEmailShared()) {
			if (StringUtils.isNotEmpty(userInfoVO.getFirstName())
					&& StringUtils.isNotEmpty(userInfoVO.getLastName()) && StringUtils.isNotEmpty(userInfoVO.getEmailAddress())) {
				validationUtils.checkUserExistsWithNameAndEmail(userInfoVO);
			}
		}

		if (null != userInfoVO.getNotificationMap() && userInfoVO.getNotificationMap().isEmpty()) {
			if (StringUtils.isNotEmpty(userInfoVO.getEmailAddress())) {
				validationUtils.validateEmail(userInfoVO);
			}
		}
		return userInfoVO;

	}

	@Path(TBConstants.USER_SERVICE_VALIDATEYOB)
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoVO validateYOB(UserInfoVO userInfoVO) {

		if (StringUtils.isNotEmpty(userInfoVO.getYearOfBirth())) {
			validationUtils.validateYOB(userInfoVO);
		}
		return userInfoVO;

	}

	@Path(TBConstants.USER_SERVICE_VALIDATEDOB)
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoVO validateDOB(UserInfoVO userInfoVO) {

		if (StringUtils.isNotEmpty(userInfoVO.getDateOfBirth())) {
			validationUtils.validateDOB(userInfoVO);
		}
		return userInfoVO;

	}
	@Path(TBConstants.USER_SERVICE_VALIDATEPWD)
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoVO validatePwd(UserInfoVO userInfoVO) {

		if(StringUtils.isNotEmpty(userInfoVO.getPwd())) {
			validationUtils.validatePwd(userInfoVO);
		}
		return userInfoVO;
		
	}

}
