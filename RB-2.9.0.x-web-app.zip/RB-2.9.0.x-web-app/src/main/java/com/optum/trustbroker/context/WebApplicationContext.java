/*
 * Copyright (C) 2016 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.context;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * The current web request context.
 *
 * @author Sachin Kumar
 * @version 1.0
 */
public class WebApplicationContext implements Serializable {
    private static final long serialVersionUID = -2190875908779951310L;
    private static final String attributeSeparator = "_";
    private static final String workflowIdKey = "workflowId";
    private boolean dirty = false;

    public WebApplicationContext(){
    	
    }
    
    public WebApplicationContext(Map<String, String> sessionAttributes){
    	if(sessionAttributes != null){
    		this.sessionAttributes = sessionAttributes;
    	}
    }

    /**
     * All attributes within the scope of a session. RP Details
     */
    private Map<String, String> sessionAttributes = new HashMap<String, String>();
    
    /**
     * All attributes within the scope of a request. User name from SM header
     */
    private Map<String, String> requestAttributes = new HashMap<String, String>();

    /**
     * Sets the value for the specified security attribute.
     *
     * @param attribute The attribute to be set.
     * @param value The value to be set.
     */
    public void setSessionAttribute(String attribute, String value) {
        if (value == null) {
            removeSessionAttribute(attribute);
        }
        else {
        	if(!sessionAttributes.containsKey(attribute)
                    || !value.equals(sessionAttributes.get(attribute))){
        		sessionAttributes.put(attribute, value);
        		dirty = true;
        	}
        }
    }
    
    /**
     * Sets the value for the specified security attribute.
     *
     * @param attribute The attribute to be set.
     * @param value The value to be set.
     */
    public void setCurrentWorkflowId(String value) {
        if (value == null) {
            removeSessionAttribute(workflowIdKey);
        }
        else {
        	if(!sessionAttributes.containsKey(workflowIdKey)
                    || !value.equals(sessionAttributes.get(workflowIdKey))){
        		//clear out previous workflow and attributes
        		if(sessionAttributes.containsKey(workflowIdKey) && !value.equals(sessionAttributes.get(workflowIdKey))){
        			removeCurrentWorkflowAndAttributes();
        		}
        		
        		sessionAttributes.put(workflowIdKey, value);
        		dirty = true;
        	}
        }
    }
    
    /**
     * Sets the value for the specified workflow security attribute.
     *
     * @param workflowId The workflow identifier.
     * @param attribute The attribute to be set.
     * @param value The value to be set.
     */
    public void setWorkflowAttribute(String workflowId, String attribute, String value) {
    	String attributeId = workflowId + attributeSeparator + attribute;
    	
        if (value == null) {
            removeSessionAttribute(attributeId);
        }
        else {
        	//Add workflow id first if do no exist.
        	if(!sessionAttributes.containsKey(workflowIdKey) 
        			|| !workflowId.equals(sessionAttributes.get(workflowIdKey))){
        		//clear out previous workflow and attributes
        		if(sessionAttributes.containsKey(workflowIdKey) && !value.equals(sessionAttributes.get(workflowIdKey))){
        			removeCurrentWorkflowAndAttributes();
        		}
        		
        		sessionAttributes.put(workflowIdKey, workflowId);
        		dirty = true;
        	}
        	
        	if(!sessionAttributes.containsKey(attributeId)
                    || !value.equals(sessionAttributes.get(attributeId))){
        		sessionAttributes.put(attributeId, value);
        		dirty = true;
        	}
        	
        }
    }
    
    /**
     * Retrieves the values for the specified security attribute.
     *
     * @param attribute The attribute whose value is to be retrieved.
     * @return The value for the specified attribute.
     */
    public String getSessionAttribute(String attribute) {
        return sessionAttributes.get(attribute);
    }
    
    /**
     * Retrieves the current work-flow identifier.
     *
     * @return The value for the current workflow.
     */
    public String getcurrentWorkflowId() {
        return sessionAttributes.get(workflowIdKey);
    }
    
    /**
     * Retrieves the values for the current persisted workflow attribute.
     * 
     * @param attribute The attribute whose value is to be retrieved.
     * @return The value for the specified attribute.
     */
    public String getWorkflowAttribute(String attribute) {
        return sessionAttributes.get(sessionAttributes.get(workflowIdKey) + attributeSeparator + attribute);
    }
    
    /**
     * Retrieves the values for the specified workflow attribute.
     *
     * @param workflowId The workflow id for which attribute needs to be retrieved.
     * @param attribute The attribute whose value is to be retrieved.
     * @return The value for the specified attribute.
     */
    public String getWorkflowAttribute(String workflowId, String attribute) {
        return sessionAttributes.get(workflowId + attributeSeparator + attribute);
    }

    /**
     * Removes the specified attribute value.
     *
     * @param attribute The attribute value to be removed.
     */
    public void removeSessionAttribute(String attribute) {
        if (sessionAttributes.containsKey(attribute)) {
            sessionAttributes.remove(attribute);
            dirty = true;
        }
    }
    
    /**
     * Removes the specified workflow attribute value.
     *
     * @param workflowId The workflow id to be referenced with attribute.
     * @param attribute The attribute that needs to be removed.
     */
    public void removeWorkflowAttribute(String workflowId, String attribute) {
    	String attributeId = workflowId + attributeSeparator + attribute;
        if (sessionAttributes.containsKey(attributeId)) {
            sessionAttributes.remove(attributeId);
            dirty = true;
        }
    }
    
    /**
     * Removes the current workflow and all related attributes.
     *
     */
    public void removeCurrentWorkflowAndAttributes() {
    	String cuurentWorkflowId = sessionAttributes.get(workflowIdKey);
    	
    	if(cuurentWorkflowId == null) {
    		return;
    	}
    	
    	Iterator<String> it = sessionAttributes.keySet().iterator();
    	while (it.hasNext()) {
    		String key = it.next();
    		if(key.startsWith(cuurentWorkflowId)){
    			it.remove();
    		}
    	}
    	
    	sessionAttributes.remove(workflowIdKey);
    	dirty = true;
    }

    /**
     * Returns a copy of the security attributes associated with this
     * context.
     *
     * @return The current security attributes.
     */
    public Map<String, String> getSessionAttributes() {
        return new HashMap<String, String>(this.sessionAttributes);
    }

    /**
     * Sets the value for the specified audit attribute.
     *
     * @param attribute The attribute to be set.
     * @param value The value to be set.
     */
    public void setRequestAttribute(String attribute, String value) {
        if (value == null) {
            removeRequestAttribute(attribute);
        }
        else {
            requestAttributes.put(attribute, value);
        }
    }

    /**
     * Retrieves the values for the specified audit attribute.
     *
     * @param attribute The attribute whose value is to be retrieved.
     * @return The value for the specified attribute.
     */
    public String getRequestAttribute(String attribute) {
        return requestAttributes.get(attribute);
    }

    /**
     * Removes the specified attribute value.
     *
     * @param attribute The attribute value to be removed.
     */
    public void removeRequestAttribute(String attribute) {
        requestAttributes.remove(attribute);
    }


    /**
     * Removes temp session attributes added to context to keep track of certain
     * events like SIGN_IN and SKIP_RECOVERY.
     */
    public void removeTempSessionAttributes(){

        int prev = sessionAttributes.size();
        Iterator<String> keysIterator = sessionAttributes.keySet().iterator();

        while(keysIterator.hasNext()){
            String key = keysIterator.next();
            if(key.contains("TEMP")){
                keysIterator.remove();
            }
        }

        if(prev != sessionAttributes.size()){
            dirty = true;
        }
    }

    /**
     * Returns a copy of the audit attributes associated with this
     * context.
     *
     * @return The current audit attributes.
     */
    public Map<String, String> getRequestAttributes() {
        return new HashMap<String, String>(this.requestAttributes);
    }

    /**
     * Returns a string representation of this object.
     */
    @Override
    public String toString() {
        StringBuilder sBuff = new StringBuilder();
        sBuff.append("ApplicationContext {")
//                .append("application: ").append(application != null ? application.getAppName() : null)
                .append(", securityAttributes: [");
        boolean isFirst = true;
        for (String key : sessionAttributes.keySet()) {
            if (isFirst) {
                isFirst = false;
            }
            else {
                sBuff.append(", ");
            }
            sBuff.append(key).append("->").append(sessionAttributes.get(key));
        }
        sBuff.append(']')
                .append(", auditAttributes: [");
        isFirst = true;
        for (String key : requestAttributes.keySet()) {
            if (isFirst) {
                isFirst = false;
            }
            else {
                sBuff.append(", ");
            }
            sBuff.append(key).append("->").append(requestAttributes.get(key));
        }
        sBuff.append(']')
                .append("}");

        return sBuff.toString();
    }

	public boolean isDirty() {
		return dirty;
	}

	public void setDirty(boolean dirtySessionCheck) {
		this.dirty = dirtySessionCheck;
	}
}
