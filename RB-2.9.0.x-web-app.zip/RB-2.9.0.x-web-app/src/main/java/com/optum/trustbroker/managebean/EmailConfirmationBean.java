package com.optum.trustbroker.managebean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.OperationFailedException;

@ManagedBean(name = "emailConfirmationBean")
@ViewScoped
public class EmailConfirmationBean  extends AbstractBackingBean implements Serializable {
	public static final String SHOW_EDIT_EMAIL_BUTTON = "SHOW_EDIT_EMAIL_BUTTON";
	private static final long serialVersionUID = 1L;

	private String emailVerificationCode;
	private String pwd;
	private boolean hideUpdateEmailButton = false;
	
	
	@SuppressWarnings("restriction")
	@PostConstruct
	public void init() {
		// Check if local environment.
		
		try {
			
			if (getSessionAttribute(SHOW_EDIT_EMAIL_BUTTON) != null) {
				if (getSessionAttribute(SHOW_EDIT_EMAIL_BUTTON).toString().equalsIgnoreCase("true")) {
					hideUpdateEmailButton = true;
				} else {
					hideUpdateEmailButton = false;
				}
				
			}
			

		} catch (OperationFailedException ope) {
			logger.error("Exception while initialization user user step up bean - {}", new String[]{TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
		}

	}


	public String getEmailVerificationCode() {
		return emailVerificationCode;
	}

	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}


	/**
	 * @return the hideUpdateEmailButton
	 */
	public boolean isHideUpdateEmailButton() {
		return hideUpdateEmailButton;
	}


	/**
	 * @param hideUpdateEmailButton the hideUpdateEmailButton to set
	 */
	public void setHideUpdateEmailButton(boolean hideUpdateEmailButton) {
		this.hideUpdateEmailButton = hideUpdateEmailButton;
	}
	
	

}
