/*
 * Copyright (C) 2016 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.context.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;

/**
 * A filter bean that manages the creation and cleanup of the web application
 * context during the execution of the services for SM cookie attributes.
 *
 * @author Sachin Kumar
 * @version 1.0
 */
public class SiteMinderContextManagerFilter implements Filter {

    private static final BaseLogger LOGGER = new BaseLogger(SiteMinderContextManagerFilter.class);

    private static final List<String> COOKIE_NAMES = Arrays.asList(TrustBrokerWebAppConstants.SM_RESPONSE_CODE,
            TrustBrokerWebAppConstants.SM_USER_MSG, TrustBrokerWebAppConstants.SM_USERID);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        //No initialization required
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {

        try {
            // store site-minder context data details
            WebApplicationContextHolder.setContext(loadSiteMinderContextDetails((HttpServletRequest) servletRequest));

            filterChain.doFilter(servletRequest, servletResponse);
        } catch (Exception ex) {
            LOGGER.error("Error while adding the site minder context details to context manager", ex);
        }

    }

    /**
     * Creates the context from cookie and parameter values
     * 
     * @param request
     * @return {@link WebApplicationContext}
     */
    public WebApplicationContext loadSiteMinderContextDetails(HttpServletRequest request) {
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();

        try {

            //Iterate over cookies to capture Site-Minder session related cookie details.
            final Cookie[] cookies = request.getCookies();
            if (cookies != null) {
                for (int i = 0; i < cookies.length; i++) {
                    final String cookieName = cookies[i].getName();
                    if (COOKIE_NAMES.contains(cookieName)) {
                        ctx.setRequestAttribute(cookies[i].getName(), cookies[i].getValue());
                    }
                }
            }

            //Request related attributes (Example username header that is available post login) 
            final String userNameInHeader = request.getHeader(TrustBrokerWebAppConstants.USER_NM_HEADER);
            if (StringUtils.isNotBlank(userNameInHeader)) {
                ctx.setRequestAttribute(TrustBrokerWebAppConstants.USER_ID, userNameInHeader);

                LOGGER.debug("Custom header" + ctx.getRequestAttribute(TrustBrokerWebAppConstants.USER_ID));
            } else if (StringUtils.isNotBlank(request.getHeader(TrustBrokerWebAppConstants.SM_USER_NM_HEADER))) {
                ctx.setRequestAttribute(TrustBrokerWebAppConstants.USER_ID,
                        request.getHeader(TrustBrokerWebAppConstants.SM_USER_NM_HEADER));
                LOGGER.debug("Raw header" + ctx.getRequestAttribute(TrustBrokerWebAppConstants.USER_ID));
            }

        } catch (Exception ex) {
            LOGGER.error("Exception occured in loading context while reading SM session related cookies", ex);
        }

        return ctx;
    }

    @Override
    public void destroy() {}
}
