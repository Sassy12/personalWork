package com.optum.trustbroker.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.MessageVO;
import com.optum.trustbroker.controller.vo.ResetPasswordVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.service.CredentialService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.ValidationUtils;
import com.optum.trustbroker.vo.EnableUserServiceRequest;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.ResetUserRSAProfileRequest;
import com.optum.trustbroker.vo.ServiceResponse;
import com.optum.trustbroker.vo.UserAuthorizationRequest;
import com.optum.trustbroker.vo.UserAuthorizationResponse;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserChangePasswordServiceRequest;
import com.optum.trustbroker.vo.UserChangePasswordServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.common.http.HttpUtils;

@Path(TBConstants.RESET_PWD_CONTROLLER_PATH)
public class ResetPasswordController extends BaseController {

	private static final BaseLogger logger = new BaseLogger(
			ResetPasswordController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private CredentialService credentialService;
	
	@Autowired
	private CommonController commonController;


	public ResetPasswordController() {

	}
	
	@POST
    @Path(value = "/validateAuthCode")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public UserInfoVO validateAuthCode(String authCode) {
        UserInfoVO userInfo = new UserInfoVO();
        WebApplicationContext context = WebApplicationContextHolder.getContext();
        context.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_AUTH_CODE);
        context.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN);
        if (StringUtils.isNotEmpty(authCode)) {            
            UserAuthorizationResponse userAuthorizationResponse = userService.validateAuthCode(authCode);            
            if (userAuthorizationResponse!=null && TrustBrokerConstants.SUCCESS_CODE_VALUE
                    .equalsIgnoreCase(userAuthorizationResponse.getExecutionStatus().getStatusCd()) &&
                    !TrustBrokerConstants.AUTH_PROCESSED.equals(userAuthorizationResponse.getAuthStatus())) {
                logger.error("response from userService.validateAuthCode(...) is UNPROCESSED");
                userInfo.setAuthCodeValid(true);
                WebApplicationContext ctx = WebApplicationContextHolder.getContext();
                ctx.setSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_AUTH_CODE, authCode);                
            }                       
        }
        return userInfo;
    }

	@POST
	@Path(value = "/resetSecurityCredentials")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public MessageVO resetSecurityCredentials(ResetPasswordVO resetPasswordVO,
			@Context HttpServletRequest request) {

		WebApplicationContext ctx = WebApplicationContextHolder.getContext();
		String authCode = ctx.getSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_AUTH_CODE);
		UserInfoVO userInfo = commonController.getUsernameFromAuthCode(authCode);
		
		MessageVO messageVO = new MessageVO();
                Map<String, String> errorMap = new HashMap<String, String>();
                messageVO.setErrorMap(errorMap);
                String validatedUser = ctx.getSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN);
                if( (StringUtils.isEmpty(authCode) && StringUtils.isEmpty(validatedUser)) 
                        || (StringUtils.isNotEmpty(authCode) && !userInfo.isAuthCodeValid()) ||  
                        (validatedUser != null && !userInfo.getUserName().equalsIgnoreCase(validatedUser))) {                    
                    messageVO.getErrorMap().put("pwd", getBundle().getString("resetProfileError"));
                    return messageVO;
		}
				
		UserVO userVO = new UserVO();
		UserVO resetUserVO = new UserVO();		
		try {

			userVO = userService.fetchUserProfile(
			        userInfo.getUserName(), false, true).getUser();

			BeanUtils.copyProperties(userVO, resetUserVO);
			resetUserVO
					.setUserChallengeQuestions(new ArrayList<UserChallengeQuestionVO>());
			resetUserVO.setPassword(resetPasswordVO.getPwd());
		} catch (OperationFailedException ope) {
			logger.error(
					"Error while retrieveing user profile details for user: {}",
					new String[] { userInfo.getUserName(),
							TrustbrokerWebAppUtil.getUidFromError(ope) });
			ResourceBundle bundle = getBundle();
			messageVO.getErrorMap().put("pwd", bundle.getString("fetchUsernameError"));
			return messageVO;
		}
		// Validating Passwords from validations util
		UserInfoVO userInfoVO = new UserInfoVO();
		userInfoVO.setUserName(userInfo.getUserName());
		userInfoVO.setPwd(resetPasswordVO.getPwd());
		userInfoVO.setConfirmPwd(resetPasswordVO.getConfirmPwd());

		ValidationUtils validationUtil = new ValidationUtils();
		validationUtil.validatePwd(userInfoVO);
		if (null != userInfoVO.getErrorMap() && userInfoVO.getErrorMap().get("confirmPwd") != null) {
			messageVO.getErrorMap().put("confirmPwd", userInfoVO.getErrorMap().get("confirmPwd"));
			return messageVO;
		}
		if (null != userInfoVO.getErrorMap() && userInfoVO.getErrorMap().get("pwd") != null) {
			messageVO.getErrorMap().put("pwd", userInfoVO.getErrorMap().get("pwd"));
			return messageVO;
		}
		ResourceBundle bundle = getBundle();
		try {

			// Unlocking the user account if the user account is locked either
			// at LDAP or RSA
			EnableUserServiceRequest enableUserServiceRequest = new EnableUserServiceRequest();
			enableUserServiceRequest.setUser(userVO);
			ServiceResponse serviceResponse;

			logger.debug("Unlock the user at LDAP");
			// Unlocking the user at LDAP
			enableUserServiceRequest.setPasswordEnable(false);
			serviceResponse = credentialService
					.enableUser(enableUserServiceRequest);
			if (TrustBrokerConstants.FAILURE_CODE_VALUE
					.equals(serviceResponse.getExecutionStatus()
							.getStatusCd())) {
				resetPasswordVO.setErrorMsg(bundle
						.getString("unlockFail"));
				messageVO.getErrorMap().put("pwd", resetPasswordVO.getErrorMsg());
				return messageVO;
			} else {
				SecurityLoggingUtil
						.info("Unlock Account",
								SecurityEventType.E3_ENABLE,
								request,
								userInfo.getUserName(),
								"Security Audit Event|LDAP Unlock:Success, ResetSEcurityCredentialsBean:resetSecurityCredentials()",
								SecurityEventResult.SUCCESS,
								ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),
								SecuritySubEventType.E3_ENABLE_LDAP);
			}

			if (TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(userVO
					.getAaStatus())) {
				// Unlocking the user at RSA
				logger.debug("Unlock the user at RSA");
				ResetUserRSAProfileRequest resetUserRSAProfileRequest = new ResetUserRSAProfileRequest();
				resetUserRSAProfileRequest.setUser(userVO);
				serviceResponse = userService
						.resetUserRSAProfile(resetUserRSAProfileRequest);
				if (TrustBrokerConstants.FAILURE_CODE_VALUE
						.equalsIgnoreCase(serviceResponse.getExecutionStatus()
								.getStatusCd())) {
					messageVO.getErrorMap().put("pwd", bundle.getString("unlockFail"));
					return messageVO;
				} else {
					SecurityLoggingUtil
							.info("Unlock Account",
									SecurityEventType.E3_ENABLE,
									request,
									userInfo.getUserName(),
									"Security Audit Event|RSA Unlock:Success, ResetSEcurityCredentialsBean:resetSecurityCredentials()",
									SecurityEventResult.SUCCESS,
									ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),
									SecuritySubEventType.E3_ENABLE_RSA);
				}
			}

			// Modifying the eSSO user
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();

			resetUserVO.setEmailAddress(userVO.getEmailAddress());
			userProfileServiceRequest.setUser(resetUserVO);

			UserProfileServiceResponse response = userService
					.resetUserProfileForSelfService(userProfileServiceRequest,
							userVO);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response
					.getExecutionStatus().getStatusCd())) {
				logger.debug(userVO.getUserName()
						+ " profile updated successfully during self service recovery");
			} else {
				logger.debug("Error while resetting user profile during Self Service recovery: "
						+ response.getExecutionStatus().getStatusMessage());
				messageVO.getErrorMap().put("pwd", bundle.getString("resetProfileError"));
				return messageVO;
			}

		} catch (OperationFailedException ofe) {
			logger.error(
					"Error while unlocking or updating the user profile during resetting security credentials for user: {}",
					new String[] { userVO.getUserName(),
							TrustbrokerWebAppUtil.getUidFromError(ofe) }, ofe);
			messageVO.getErrorMap().put("pwd", bundle.getString("unlockOrResetError"));
			return messageVO;
		}

		try {
			// Changing the Password of a user
			UserChangePasswordServiceRequest userChangePwdServiceRequest = new UserChangePasswordServiceRequest();
			userChangePwdServiceRequest.setPassword(resetPasswordVO.getPwd());
			if(StringUtils.isNotEmpty(resetPasswordVO.getOldPwd())) {
				userChangePwdServiceRequest.setOldPassword(resetPasswordVO.getOldPwd());
			}
			userChangePwdServiceRequest.setUser(userVO);
			UserChangePasswordServiceResponse changePwdResponse = credentialService
					.changePwd(userChangePwdServiceRequest);

			if (TrustBrokerConstants.SUCCESS_CODE_VALUE
					.equals(changePwdResponse.getExecutionStatus()
							.getStatusCd())) {
				logger.debug(userVO.getUserName()
						+ " password changed successfully during self service recovery");
			} else {
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();

				// TO-DO check what these lines are for. Old password error from
				// here. What does resetUserProfileForSelfService do??
				userProfileServiceRequest.setUser(userVO);
				userService.resetUserProfileForSelfService(
						userProfileServiceRequest, resetUserVO);
				messageVO.getErrorMap().put("pwd", bundle.getString("oldPassErrorNxtGen"));
				return messageVO;
			}
		} catch (OperationFailedException ofe) {
			logger.error(
					"Error while changing user password during Self Service recovery: ",
					ofe);
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(userVO);
			userService.resetUserProfileForSelfService(
					userProfileServiceRequest, resetUserVO);
			messageVO.getErrorMap().put("pwd", ofe.getMessage());
			return messageVO;
		}
				
		if (StringUtils.isNotEmpty(authCode)) {
			userService.invalidateUserAuthCode(authCode);
			SecurityLoggingUtil.info("ResetSecuirty Credentials ", SecurityEventType.E3_MODIFY, request,
			        userInfo.getUserName(),
					"Security Audit Event|ResetSecuirty Credentials :SUCCESS|Authorization Code Processed , "
							+ "ResetSecurityCredentialsBean:resetSecurityCredentials()", SecurityEventResult.SUCCESS,
							ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM), SecuritySubEventType.E3_MODIFY_PROFILE);
			ctx.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_AUTH_CODE);
		}
		ctx.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN);
		return null;
	}
	
	
	@POST
	@Path(value = "/resendEmail")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public MessageVO sendMailToUser(ResetPasswordVO resetPasswordVO, @Context HttpServletRequest request) {
		UserVO userVO = new UserVO();
		MessageVO messageVO = new MessageVO();
		UserAuthorizationRequest userAuthorizationRequest = new UserAuthorizationRequest();
		WebApplicationContext ctx = WebApplicationContextHolder.getContext();
		String rpAppId = "";
	
		try {
			//2 conditions to fetch userVO
			//Condition 1: userName is available
			if(resetPasswordVO.getUserName() != null && StringUtils.isNotBlank(resetPasswordVO.getUserName())){
				userVO = userService.fetchUserProfile(resetPasswordVO.getUserName(), false, true).getUser();
				//checks if user has specified a particular email id 
				if(resetPasswordVO.getEmailId() != null && StringUtils.isNotBlank(resetPasswordVO.getEmailId())){
					userVO.setEmailAddress(resetPasswordVO.getEmailId());
				}
			} else if(resetPasswordVO.getEmailId() != null && StringUtils.isNotBlank(resetPasswordVO.getEmailId())){
				//Condition 2: Only emailId is available: email will be always primary for recovery/reset options
				UserVO userValueObject = new UserVO();
				userValueObject.setEmailAddress(resetPasswordVO.getEmailId());
				UserProfileServiceResponse userProfileServiceResponse = userService.lookupUserByHeuristicEvaluation(userValueObject, "*");
				userVO = userProfileServiceResponse.getUser();
			}
			
		} catch (OperationFailedException ope) {
			logger.error(
					"Error while retrieveing user profile details for user: {}");
			messageVO.getErrorMap().put("error", "error in fetching userVO");
			return messageVO;
		}
		
		userAuthorizationRequest.setUser(userVO);
		
		String resetAccountURL = TBUtil.generateContextPath(request) + "/link/reset-password";
		if (ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET) != null
				&& ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) != null) {
			rpAppId = ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);			
			resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, 
					(String)ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM));
			resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.TARGET, 
					(String)ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET));
			
			resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.AUTH_CODE, "");
		} else {
			
			resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.AUTH_CODE, "");
		}
		
		userAuthorizationRequest.setResetAccountLink(resetAccountURL);
		
		userService.sendAuthCodeToUser(userAuthorizationRequest, TrustBrokerConstants.ACCOUNT_RECOVERY, rpAppId, true, getUrlLogoOptumId(request), getUrlLogoRelyingParty(request,rpAppId));
		
		return null;
	}

	
	
	@Override
	public UserService getUserService() {
		return userService;
	}

	@Override
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public CredentialService getCredentialService() {
		return credentialService;
	}

	public void setCredentialService(CredentialService credentialService) {
		this.credentialService = credentialService;
	}
}
