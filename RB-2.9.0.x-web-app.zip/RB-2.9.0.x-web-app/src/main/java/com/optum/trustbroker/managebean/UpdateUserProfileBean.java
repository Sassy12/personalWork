package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.AddressVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@ManagedBean(name = "updateUserProfileBean")
@ViewScoped
public class UpdateUserProfileBean extends AbstractBackingBean implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private final BaseLogger logger = new BaseLogger(this.getClass());

	@ManagedProperty(value = "#{userVO}")
	private UserVO updateUserVO;

	@ManagedProperty(value = "#{userVO}")
	private UserVO sessionUserVO;

	@ManagedProperty(value = "#{addressVO}")
	private AddressVO updateAddressVO;

	@ManagedProperty(value = "#{addressVO}")
	private AddressVO sessionAddressVO;
	
	private String updateProfilePageUrl = "/secure/updateuserprofile.jsf";

	private String dateOfBirth;

	private String oldDateOfBirth;

	private String successMsg;

	private String errorMsg;

	private String warningMsg;

	private boolean showEmail;

	private String emailExistsMsg;
	
	private String specialCharsMsg;

	private String emailExistsMsgSec;
	public String getEmailExistsMsgSec() {
		return emailExistsMsgSec;
	}

	public void setEmailExistsMsgSec(String emailExistsMsgSec) {
		this.emailExistsMsgSec = emailExistsMsgSec;
	}
	private List<SelectItem> statesList;

	protected static final ResourceBundle tbResources = ResourceBundle
			.getBundle("trustBrokerResources");

	public boolean isShowEmail() {
		return showEmail;
	}

	public void setShowEmail(boolean showEmail) {
		this.showEmail = showEmail;
	}

	public String getEmailExistsMsg() {
		return emailExistsMsg;
	}

	public void setEmailExistsMsg(String emailExistsMsg) {
		this.emailExistsMsg = emailExistsMsg;
	}

	
	public UserVO getUpdateUserVO() {
		return updateUserVO;
	}

	public void setUpdateUserVO(UserVO updateUserVO) {
		this.updateUserVO = updateUserVO;
	}

	public UserVO getSessionUserVO() {
		return sessionUserVO;
	}

	public void setSessionUserVO(UserVO sessionUserVO) {
		this.sessionUserVO = sessionUserVO;
	}

	public AddressVO getUpdateAddressVO() {
		return updateAddressVO;
	}

	public void setUpdateAddressVO(AddressVO updateAddressVO) {
		this.updateAddressVO = updateAddressVO;
	}

	public AddressVO getSessionAddressVO() {
		return sessionAddressVO;
	}

	public void setSessionAddressVO(AddressVO sessionAddressVO) {
		this.sessionAddressVO = sessionAddressVO;
	}

	public String getSuccessMsg() {
		return successMsg;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getOldDateOfBirth() {
		return oldDateOfBirth;
	}

	public void setOldDateOfBirth(String oldDateOfBirth) {
		this.oldDateOfBirth = oldDateOfBirth;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getWarningMsg() {
		return warningMsg;
	}

	public void setWarningMsg(String warningMsg) {
		this.warningMsg = warningMsg;
	}

	public List<SelectItem> getStatesList() {
		return statesList;
	}

	public void setStatesList(List<SelectItem> statesList) {
		this.statesList = statesList;
	}

	public void preRenderView() {
        // stop execution for Ajax calls
        try {
            if (FacesContext.getCurrentInstance().isPostback()) {
                return;
            }
        }
        catch (Exception e) {
            // ignore
        }
        // makes sure init is called before any rendering
        init();
	}
	
	//@PostConstruct
	public void init() {
		
		if (!initOpenIdConnectForEntry(updateProfilePageUrl)) {
            return;
        }
		
		addRelyingPartyRequestParam(TrustBrokerWebAppConstants.TARGET, TrustBrokerWebAppConstants.RELYING_APP_URL_PROF,
				getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
		addRelyingPartyRequestParam(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, TrustBrokerWebAppConstants.RELYING_APP_ID,
				getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
		addRelyingPartyAlias(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)!=null? 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString():null);
		addSessionAttribute(TrustBrokerWebAppConstants.ACTION, TrustBrokerWebAppConstants.UPDATE_PROFILE);
		addOpenIdConnectDataToSession();
		UserVO essoUserVO = geteSSOUser(getCurrentUserVO().getUuId());
		revertChanges(essoUserVO);
		setSessionUserDetails(essoUserVO);
		
		try {
			Map<String, String> statesMap = container.getReferenceService().fetchStates();
			statesList = new ArrayList<SelectItem>();
			SortedSet<String> stateSortedByKey = new TreeSet<String>(statesMap.keySet());
			for (String key : stateSortedByKey) {
				SelectItem selectItem = new SelectItem(key, key);
				statesList.add(selectItem);
			}
		}
		catch(OperationFailedException ofe){
			logger.error("Error while fetching states reference data for update profile - {}", 
					new String[]{TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
			setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(
					container.getErrorMessageSource(), getSupportContactInfo()) : ofe.getMessage());
		}

		String upf = getFacesContext().getExternalContext().getRequestParameterMap().get("upf");
		
		if (upf!=null)
		{
			setSuccessMsg(upf.equals("f")?"User Profile is updated successfully.  You must confirm the email address before next sign in. ":"User Profile is updated successfully");
		}
		//Get relying party registration profile info to display mandatory fields
		getRPRegProfileAATypeinfo();
	}

	public boolean validatePersonalInformation() {
		boolean result = true;
		
		boolean resultFirstName = TBUtil.validateName(updateUserVO.getFirstName());
		boolean resultMiddleName = TBUtil.validateName(updateUserVO.getMiddleName());
		boolean resultLastName = TBUtil.validateName(updateUserVO.getLastName());
		
		if (!resultFirstName ) {
			addFacesMessage("updateUserProfileId:firstName",
					tbResources.getString("numericSpecialCharMsg"));
			result = false;
		} 
		
		if (!resultMiddleName) {
			addFacesMessage("updateUserProfileId:middleName",
					tbResources.getString("middlenumericSpecialCharMsg"));
			result = false;
		} 
		if (!resultLastName) {
			addFacesMessage("updateUserProfileId:lastName",
					tbResources.getString("lastnumericSpecialCharMsg"));
			result = false;
		} 
		
		if (StringUtils.isNotBlank(getUpdateAddressVO().getZip())
				&& (!(getUpdateAddressVO().getZip().matches("[0-9]+")) || getUpdateAddressVO().getZip().length() < 5)) {
			addFacesMessage("updateUserProfileId:zipId", tbResources.getString("invalidZipCode"));
			result = false;
		}
		//DOB validation
		if(!validateDOB())
			result = false;
		
		return result;
	}
	
	
	public void checkDOBField(ValueChangeEvent event) {		
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			validateDOB();
		}
	}
	
	private boolean validateDOB() {
		boolean result = true;				
		if(isDobRequired() && StringUtils.isBlank(dateOfBirth)) {
			addFacesMessage("updateUserProfileId:dobId", tbResources.getString("dobRequiredMsg"));
			result = false;
			return result;
		}
		boolean isDateValid = true;
		if(StringUtils.isNotBlank(dateOfBirth)) {
			isDateValid = DateUtil.validateDate(dateOfBirth);
		}
		if (!isDateValid) {
			addFacesMessage("updateUserProfileId:dobId", tbResources.getString("dobFormatErrorMsg"));
			result = false;
		} else if(StringUtils.isNotBlank(dateOfBirth)) {
			int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userMinAgeLimit"));
			boolean isAgeConstraint = DateUtil.validateAge(dateOfBirth, minAgeLimit);
			if (isAgeConstraint) {
				addFacesMessage("updateUserProfileId:dobId", tbResources.getString("dobAgeConstraintMsg"));
				result = false;
			}
		}
		return result;
	}

	public boolean validateEmailFormat(String emailAddress) {
		Pattern pattern = Pattern.compile(tbResources.getString("emailAddressRegEx"));
		Matcher matcher = pattern.matcher(emailAddress);
		return matcher.matches();
	}

	
	public boolean checkEmailAddressExist() {
		boolean status=container.getUserService().isEmailExists(updateUserVO.getEmailAddress().toLowerCase());
		if (status) {
			setEmailExistsMsg(tbResources.getString("emailAlreadyExists"));
		}
		return status;
	}
	
	public void checkNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultFirstName = TBUtil.validateName(updateUserVO.getFirstName());
			if (!resultFirstName ) {
				//setSpecialCharsMsg(tbResources.getString("numericSpecialCharMsg"));
				addFacesMessage("updateUserProfileId:firstName",tbResources.getString("numericSpecialCharMsgOldGen"));
				//addFacesMessage("updateUserProfileId:zipId", tbResources.getString("invalidZipCode"));
				
			} 
		}
	}
	
	
	public void checkMiddleNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultMiddleName = TBUtil.validateName(updateUserVO.getMiddleName());
			if (!resultMiddleName ) {
				addFacesMessage("updateUserProfileId:middleName",tbResources.getString("middlenumericSpecialCharMsgOldGen"));
			} 
		}
	}
	
	
	public void checkLastNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultLastName = TBUtil.validateName(updateUserVO.getLastName());
			if ( !resultLastName) {
				addFacesMessage("updateUserProfileId:lastName",tbResources.getString("lastnumericSpecialCharMsgOldGen"));
			}
		}
	}
	

	/*public void checkEmailAddress(ValueChangeEvent event) {
	
		emailExistsMsg = "";
		showEmail = false;
		PhaseId phaseId = event.getPhaseId();
		
		
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			
			boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
			if (!result) {
				addFacesMessage("updateSecurityQuestionsId:email",tbResources.getString("invalidEmailAddress"));
			} else {
				if (getCurrentUserVO().getEmailAddress().equalsIgnoreCase(updateUserVO.getEmailAddress())) {
					addFacesMessage("updateSecurityQuestionsId:email","");
				} else {
					if (container.getUserService().isEmailExists(updateUserVO.getEmailAddress().toLowerCase())) {
						showEmail = true;
						addFacesMessage("updateSecurityQuestionsId:email",
								tbResources.getString("emailAlreadyExists"));
					}
				}
			}
			
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES) && !event.getNewValue().toString().isEmpty()) {
			
			boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
			if (!result) {
				addFacesMessage("updateSecurityQuestionsId:email",
						tbResources.getString("invalidEmailAddress"));
			} else {
				if (getCurrentUserVO().getEmailAddress().equalsIgnoreCase(updateUserVO.getEmailAddress())) {
					addFacesMessage("updateSecurityQuestionsId:email","");
				} else {
					if (container.getUserService().isEmailExists(updateUserVO.getEmailAddress().toLowerCase())) {
						showEmail = true;
						addFacesMessage("updateSecurityQuestionsId:email",tbResources.getString("emailAlreadyExists"));
					}
				}
			}
		}
	}
*/
	/**
	 * Update the user profile in eSSO as well in trust broker database. 
	 * @return updated user value object
	 */
	public UserVO updateProfile() {
		clearMessages();// Clear all error messages if any

		if (!(validatePersonalInformation())) {
			return null;
		}

		clearValidateMessages();
		UserVO trustBrokerUserVO = null;

		try {
			trustBrokerUserVO = container.getUserService().fetchUserByUUID(getCurrentUserVO().getUuId()).getUser();

			UserProfileServiceRequest userRegistrationServiceRequest = new UserProfileServiceRequest();
			UserVO essoUserVO = geteSSOUser(trustBrokerUserVO.getUuId());

			// Set Role to the upateUserVO from session
			//updateUserVO.setUserRoleCd(trustBrokerUserVO.getUserRoleCd());
			updUserRepoObj(trustBrokerUserVO, updateUserVO);
			
			if (StringUtils.isNotBlank(dateOfBirth))
				updateUserVO.setDob(DateUtil.parseDate(dateOfBirth, DateUtil.EXT_DATE_FORMAT));
			else
				updateUserVO.setDob(null);

			updateUserVO.setRpId(getRelyingPartyApAlias(true));
			userRegistrationServiceRequest.setUser(updateUserVO);
			userRegistrationServiceRequest.setOldUser(essoUserVO);
			
			UserProfileServiceResponse response = container.getUserService().modifyUser(userRegistrationServiceRequest, true);

			if (!TrustbrokerWebAppUtil.checkResponseStatus(response)) {
				if(response.getReasonCode() != null && TrustBrokerConstants.OPT_ERR_001.equals(response.getReasonCode())){
					setErrorMsg("");
					setWarningMsg(response.getReasonMessage());
				} else setErrorMsg(response.getReasonMessage());
				logger.error("User Profile failure response for user {} from eSSO: "+response.getReasonMessage(), new String[]{essoUserVO.getUserName(), response.getReasonCode()});
				return null;
			}

			SecurityLoggingUtil.info("User Account Modifications",SecurityEventType.E3_MODIFY,getServletRequest(),essoUserVO.getUserName(),
					"Security Audit Event|ModifyUserProfile:SUCCESS | User Profile Modified, UpdateUserProfileBean:updateProfile()",
					SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_MODIFY_PROFILE);

			// Setting the current user in session		
			setCurrentUserVO(response.getUser());
			getCurrentUserVO().setIsCoppaAccepted(updateUserVO.getIsCoppaAccepted());
			setSessionUserDetails(response.getUser());
			logger.info("User Profile is updated successfully for the user {}", new String[]{trustBrokerUserVO.getUserName()});

			setSuccessMsg("User Profile is updated successfully");
			
			if (null != getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG)) {
				ExternalContext ec = getFacesContext().getExternalContext();
				ec.getFlash().put("updateProfileSuccess", tbResources.getString("idProofUpdateProfileSuccess"));
				ec.redirect(ec.getRequestContextPath() + "/secure/idverification.jsf");
				return null;
			}
			return response.getUser();
		}
		catch (OperationFailedException ofe) {
			logger.error(" An error occureed while updating user profile for user : {}",
					new String[] { getCurrentUserVO().getUserName(), TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
			setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(
					container.getErrorMessageSource(), getSupportContactInfo()) : ofe.getMessage());
		}
		catch (Exception e) {
			logger.error(" An error occureed while updating user profile for user : {}", new String[]{getCurrentUserVO().getUserName()}, e);
			setErrorMsg("User Profile update is unsuccessful");
		}
		return null;
	}

	public void revertChanges(UserVO eSSOUserVO) {
		clearMessages();
		clearValidateMessages();
		UserVO trustBrokerUserVO = container.getUserService().fetchUserByUUID(getCurrentUserVO().getUuId()).getUser();
		toCurrentUserVO(eSSOUserVO, trustBrokerUserVO);
		if(null != updateUserVO.getDob())
			setDateOfBirth(DateUtil.formatDate(updateUserVO.getDob(), "MM/dd/yyyy"));
	}

	private void clearMessages() {
		setSuccessMsg("");
		setErrorMsg("");
		setWarningMsg("");
	}

	private void clearValidateMessages() {
		setEmailExistsMsg("");
		setEmailExistsMsgSec("");
	}

	private void setSessionUserDetails(UserVO essoUserVO) {

		setSessionUserVO(essoUserVO);
		setOldDateOfBirth(getDateOfBirth());
		if(essoUserVO.getAddresses() != null && essoUserVO.getAddresses().size() > 0) 
			setSessionAddressVO(essoUserVO.getAddresses().get(0));

		if (null == sessionUserVO.getMiddleName())
			sessionUserVO.setMiddleName("");
		if (null == sessionUserVO.getPrefix())
			sessionUserVO.setPrefix("");
		if (null == sessionUserVO.getSuffix())
			sessionUserVO.setSuffix("");
		if (null == sessionAddressVO.getZipAreaCode())
			sessionAddressVO.setZipAreaCode("");
		if(null == sessionUserVO.getSecEmailAddress())
			sessionUserVO.setSecEmailAddress("");

	}

	private void toCurrentUserVO(UserVO essoUserVO, UserVO trustBrokerUserVO) {
		boolean isAddressMatched = false;
		List<AddressVO> addesses = new ArrayList<AddressVO>();
		
		if (null != essoUserVO.getAddresses()) {
			AddressVO updatedAddressVO = null;
			Iterator<AddressVO> addressIterator = essoUserVO.getAddresses().iterator();
			while (addressIterator.hasNext()) {
				AddressVO essoAddressVO = addressIterator.next();
				if (null != essoAddressVO.getIsPrimaryAddress()
						&& essoAddressVO.getIsPrimaryAddress().equalsIgnoreCase(TrustBrokerConstants.ADDRESS_TYPE_WORK)) {
					updatedAddressVO = essoAddressVO;
					isAddressMatched = true;
					break;
				}
			}
			
			if (!isAddressMatched) updatedAddressVO = essoUserVO.getAddresses().get(0);
			setUpdateAddressVO(updatedAddressVO);
			addesses.add(updatedAddressVO);
			updateUserVO.setAddresses(addesses);

		} else {
			updateUserVO.setAddresses(new ArrayList<AddressVO>());
		}
		
		updateUserVO.setUserId(trustBrokerUserVO.getUserId());
		updateUserVO.setIdentityProofingId(trustBrokerUserVO.getIdentityProofingId());
		updateUserVO.setCreatedBy(trustBrokerUserVO.getCreatedBy());
		updateUserVO.setModifiedBy(trustBrokerUserVO.getModifiedBy());
		updateUserVO.setIsTncAccepted(trustBrokerUserVO.getIsTncAccepted());
		updateUserVO.setTncAgreedTs(trustBrokerUserVO.getTncAgreedTs());
		updateUserVO.setTncAgreementVersion(trustBrokerUserVO.getTncAgreementVersion());
		updateUserVO.setDob(essoUserVO.getDob());
		updateUserVO.setEmailAddress(essoUserVO.getEmailAddress());
		updateUserVO.setSecEmailAddress(essoUserVO.getSecEmailAddress()==null ? "" : essoUserVO.getSecEmailAddress());
		updateUserVO.setFirstName(essoUserVO.getFirstName());
		updateUserVO.setHealthID(essoUserVO.getHealthID());
		updateUserVO.setLastName(essoUserVO.getLastName());
		updateUserVO.setMiddleName(essoUserVO.getMiddleName()==null ? "" :essoUserVO.getMiddleName());
		updateUserVO.setPrefix(essoUserVO.getPrefix()==null ? "" : essoUserVO.getPrefix());
		updateUserVO.setSuffix(essoUserVO.getSuffix()==null ? "" : essoUserVO.getSuffix());
		updateUserVO.setUserName(essoUserVO.getUserName());
		updateUserVO.setUuId(essoUserVO.getUuId());
		updateUserVO.setPhoneNumber(essoUserVO.getPhoneNumber());
		updateUserVO.setIsPhoneVerified(essoUserVO.getIsPhoneVerified());
	}

	public UserVO geteSSOUser(String uuid) {
		UserVO essoUserVO = null;
		try {
			UserRetrievalServiceResponse userRetrievalServiceResponse = container.getUserService().fetchUserProfile(uuid,true, true);
			essoUserVO = userRetrievalServiceResponse.getUser();
		} catch (OperationFailedException e) {
			logger.info(" Failed to get the User details from eSSO for UUID "+ uuid);
			throw new OperationFailedException("Failed to get the User details from eSSO");
		}
		return essoUserVO;
	}

	private void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

/*	public void validateSecEmailFormat(ValueChangeEvent event) {
		emailExistsMsgSec = "";
		showEmail = false;
		boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			if (!event.getNewValue().toString().isEmpty()&&!result) {
				addFacesMessage("updateSecurityQuestionsId:secEmail",tbResources.getString("invalidEmailAddress"));
			}
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			if (!event.getNewValue().toString().isEmpty()&&!result) {
				addFacesMessage("updateSecurityQuestionsId:secEmail",tbResources.getString("invalidEmailAddress"));
			}

		}
	}*/


	public String cancel() {
		try {
			ExternalContext ec = getFacesContext().getExternalContext();
			if (null != getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG)) {
				ec.redirect(ec.getRequestContextPath() + "/secure/idverification.jsf");
				return null;
			} else {
				//return "/secure/home?faces-redirect=true";
				return "/secure/updateuserprofile?faces-redirect=true";
				
			}
			
		} catch (Exception e) {
			logger.error("Error occured during cancel in update user profile for user: {}",
					new String[] { getCurrentUserVO().getUserName() }, e);
			return null;
		}
	}

	public String getSpecialCharsMsg() {
		return specialCharsMsg;
	}

	public void setSpecialCharsMsg(String specialCharsMsg) {
		this.specialCharsMsg = specialCharsMsg;
	}

}
