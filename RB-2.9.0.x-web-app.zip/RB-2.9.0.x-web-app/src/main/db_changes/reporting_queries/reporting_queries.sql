
-- 1.Dates and Times when a particular user logged in directly to TB
	select actor_id,timestamp,app_id from irm_audit_logs where actor_id='Arcadiaww1' and app_id='UHGWM110-008293' and message='Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeBean:onPreinitialize()'  order by timestamp;

--2. Dates and Times when a particular user logged in to a specific RP
	select actor_id,timestamp,app_id from irm_audit_logs where actor_id='Arcadiaww1' and app_id='OTX47239' and message='Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeBean:onPreinitialize()' order by timestamp;

--3. Latest date and time when a particular user logged in directly to TB
	select actor_id,timestamp,app_id from irm_audit_logs where actor_id='Arcadiaww1' and app_id='OTX47239' and message='Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeBean:onPreinitialize()'
 	AND timestamp =( select MAX(timestamp) from irm_audit_logs where actor_id='Arcadiaww1' and app_id='OTX47239'and message='Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeBean:onPreinitialize()' );
  
--4 .Latest date and time when a particular user logged in to a specific RP
	select actor_id,timestamp,app_id from irm_audit_logs where actor_id='Arcadiaww1' and app_id='UHGWM110-008293' and message='Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeBean:onPreinitialize()'
	AND timestamp =( select MAX(timestamp) from irm_audit_logs where actor_id='Arcadiaww1' and app_id='UHGWM110-008293' and message='Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeBean:onPreinitialize()');

--5.	Count of currently registered users
	select count(*) from tb_user;
	
--6.	Count of users registered in a date range
	select count(*) from tb_user where created_ts between TO_DATE('21-NOV-13','DD-MON-YY') AND TO_DATE('22-NOV-13','DD-MON-YY');
	
--7.	Count of users per RP
	SELECT  rp.APPLICATION_NAME,  COUNT(*) AS noofusers  FROM   user_rp_rel urr,rp_app rp where urr.APPLICATION_ID=rp.APPLICATION_ID group by rp.APPLICATION_NAME;
	
--8.	Count of users per RP in a date range
	SELECT  rp.APPLICATION_NAME,  COUNT(*) AS noofusers  FROM   user_rp_rel urr,rp_app rp where urr.APPLICATION_ID=rp.APPLICATION_ID  and urr.CREATED_TS between TO_DATE('12-NOV-13','DD-MON-YY') AND TO_DATE('13-NOV-13','DD-MON-YY') group by rp.APPLICATION_NAME;
	
--9.	Count of users logged in TB in a date range
	select count(*)  from 
	irm_audit_logs where   timestamp between TO_DATE('20-NOV-13','DD-MON-YY')
	AND TO_DATE('21-NOV-13','DD-MON-YY') and  message='Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeBean:onPreinitialize()' order by app_id;
	
--10.	Count of users logged in TB per RP in a date range
	select rp.application_name, COUNT(*) AS noofusers  FROM   irm_audit_logs ial,rp_app rp where
	ial.app_id=rp.APPLICATION_ID   and   ial. timestamp between TO_DATE('20-NOV-13','DD-MON-YY')
	AND TO_DATE('21-NOV-13','DD-MON-YY') and  
	ial.message='Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeBean:onPreinitialize()'  group by rp.application_name;

