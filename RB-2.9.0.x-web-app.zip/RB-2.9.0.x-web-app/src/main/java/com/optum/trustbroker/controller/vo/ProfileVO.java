package com.optum.trustbroker.controller.vo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class ProfileVO {
	
	private String firstName;
	private String middleName;
	private String lastName;
	private String suffix;
	private String prefix;
	private String dateOfBirth;
	private String homeAddress;
	private String zip;
	private String city;
	private String state;
	
	private String uuid;
	private String userName;
	
	/*fields for verification options tab*/
	private boolean primaryEmailVerified;
	private String primaryEmailAddress;
	private boolean secondaryEmailVerified;
	private String secondaryEmailAddress;
	private String phoneNo;
	private boolean phoneNoVerified;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public boolean isPrimaryEmailVerified() {
		return primaryEmailVerified;
	}
	public void setPrimaryEmailVerified(boolean primaryEmailVerified) {
		this.primaryEmailVerified = primaryEmailVerified;
	}
	public String getPrimaryEmailAddress() {
		return primaryEmailAddress;
	}
	public void setPrimaryEmailAddress(String primaryEmailAddress) {
		this.primaryEmailAddress = primaryEmailAddress;
	}
	public boolean isSecondaryEmailVerified() {
		return secondaryEmailVerified;
	}
	public void setSecondaryEmailVerified(boolean secondaryEmailVerified) {
		this.secondaryEmailVerified = secondaryEmailVerified;
	}
	public String getSecondaryEmailAddress() {
		return secondaryEmailAddress;
	}
	public void setSecondaryEmailAddress(String secondaryEmailAddress) {
		this.secondaryEmailAddress = secondaryEmailAddress;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public boolean isPhoneNoVerified() {
		return phoneNoVerified;
	}
	public void setPhoneNoVerified(boolean phoneNoVerified) {
		this.phoneNoVerified = phoneNoVerified;
	}
	
}
