'use strict';

var indexApp = angular.module('indexApp', [
    'common.modules',
    'common.services',
    'ngResource',
    'oid.component.oidTextSelectCombo',
    'pascalprecht.translate',
    'trustbroker.AriaLibrary',
    'ui.router',
    'uitk.component.header',
    'uitk.component.uitkButton',
    'uitk.component.uitkCalendar',
    'uitk.component.uitkCheckboxGroup',
    'uitk.component.uitkDialog',
    'uitk.component.uitkDynamicTable',
    'uitk.component.uitkFooter',
    'uitk.component.uitkGlobalNavigation',
    'uitk.component.uitkHelp',
    'uitk.component.uitkLabel',
    'uitk.component.uitkMessage',
    'uitk.component.uitkPanel',
    'uitk.component.uitkPrimaryNavigation',
    'uitk.component.uitkRadioGroup',
    'uitk.component.uitkSelect',
    'uitk.component.uitkTextarea',
    'uitk.component.uitkTextField',
    'uitk.component.uitkTooltip',
    'uitk.component.uitkVerticalNavigation',
    'uitk.component.uitkDateOfBirth',
    'uitk.uitkUtility'
]);

/* Router configuration for all states */
indexApp.config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$translateProvider', '$httpProvider', 'uitkDateOfBirthDefaultsProvider',
    function($stateProvider, $urlRouterProvider, $locationProvider, $translateProvider, $httpProvider, uitkDateOfBirthDefaultsProvider) {

        $translateProvider.useLoader("$translatePartialLoader", {
            urlTemplate: "{part}/i18n/{lang}.json"
        });

        $translateProvider.translations('en_US', {
            P_POLICY: 'Privacy Policy',
            T_O_USE: 'Terms of Use',
            LINK_INFO: 'Opens in a new window',
            RQD_VAR: 'required'
        });
        
        uitkDateOfBirthDefaultsProvider.set('minYear', '0000');

        $translateProvider.preferredLanguage('en_US');
        $translateProvider.useSanitizeValueStrategy('escaped');
        $locationProvider.html5Mode(false);
        // Push service response interceptor to default interceptors array
        $httpProvider.interceptors.push('ServiceResponseInterceptor');
        
        // Push service request interceptor to default interceptors array for random token
        $httpProvider.interceptors.push('httpRequestInterceptor');
        
        //$urlRouterProvider.otherwise('/login');
        
        $urlRouterProvider.otherwise(function($injector) {
    	  var $state = $injector.get('$state');
    	  $state.go('login');
    	});


        $stateProvider.state('login', {
            url: "/login",
            templateUrl: "login/views/login.html",
            controller: 'LoginCtrl',
            params: {
                prevState: null,
                userName: null,
                resendInfo: {}
            },
            resolve: {
                initData: function(LanguageService, LoginService) {
                    LanguageService.doTranslate("login");
                    return LoginService.init();
                },
                redirect: function(initData, $state, $stateParams) {
                    if (initData.data.redirect) {
                        if (initData.data.redirect === 'sentauthorizationcodesqa') {
                            $state.go("setsecurityquestions", { userinfo: { 'userName': initData.data.lockedUserID } });
                        }
                        if (initData.data.redirect === 'accountrecoveryoptions') {
                            $state.go('forgotCredByIdentity', { userinfo: { 'userName': initData.data.lockedUserID } });
                        }
                        if (initData.data.redirect === 'norecoveryoption' && $stateParams.prevState !== 'norecoveryoption') {
                            $state.go("norecoveryoption");
                        } else {
                            $stateParams.prevState = null;
                        }
                        if (initData.data.redirect === 'ERROR_PAGE') {
                            $state.go("errorpage");
                        }
                    }
                    if ($stateParams.prevState === 'resetPasswordSuccess') {
                        $stateParams.prevState = null;
                        initData.data.successMessage = '<span translate="resetPassSuccess"></span>';
                    }
                    if ($stateParams.prevState === 'sendUserNameSuccessViaPrimaryEmail') {
                        $stateParams.prevState = null;
                        initData.data.successMessage = '<span translate="sendUserNameSuccessViaPrimaryEmail"></span>';
                        initData.data.resendInfo = $stateParams.resendInfo;
                        initData.data.resendType = "pEmail";
                    }
                    if ($stateParams.prevState === 'sendUserNameSuccessViaSecondaryEmail') {
                        $stateParams.prevState = null;
                        initData.data.successMessage = '<span translate="sendUserNameSuccessViaSecondaryEmail"></span>';
                        initData.data.resendInfo = $stateParams.resendInfo;
                        initData.data.resendType = "sEmail";
                    }
                    if ($stateParams.prevState === 'sendUserNameSuccessViaPhone') {
                        $stateParams.prevState = null;
                        initData.data.successMessage = '<span translate="sendUserNameSuccessViaPhone"></span>';
                        initData.data.resendInfo = $stateParams.resendInfo;
                        initData.data.resendType = "txt";
                    }
                    if ($stateParams.prevState === 'displayUserNameSuccessViaSQ') {
                        $stateParams.prevState = null;
                        initData.data.userName = $stateParams.userName;
                        initData.data.successMessage = '<span translate="displayUserNameSuccessViaSQ1"></span><span class="change-to-bold">' +
                            $stateParams.userName +
                            '</span><span translate="displayUserNameSuccessViaSQ2"></span>';
                    }
                    if ($stateParams.prevState === 'createSecurityQuestions') {
                        $stateParams.prevState = null;
                        initData.data.successMessage = '<span translate="MSG_CREATE_SQA"></span>';
                    }
                    return null;
                }
            }
        }).state('registration', {
            url: "/registration",
            templateUrl: "registration/views/registration.html",
            controller: 'RegistrationController',
            resolve: {
                regInitData: function(LanguageService, RegistrationService) {
                    LanguageService.doTranslate("registration");
                    return RegistrationService.initializedata();
                },
                redirect: function(regInitData, $state) {
                    if (regInitData.data.nextState) {
                        if (regInitData.data.nextState === "invitationExpired") {
                            $state.go("invitationLinkExp");
                        }
                    }
                }
            }
        }).state('forgotcredentialPage', {
            url: "/forgotcredentialPage",
            templateUrl: "selfservice/views/findunamewithmoredetails.html",
            controller: 'findUserCtrl'
        }).state('findusrwmoreinfo', {
            url: "/findusrwmoreinfo",
            templateUrl: "selfservice/views/findunamewotherinfo.html",
            controller: 'findUnameOtherInfoCtlr'
        }).state('findpwdwmoreinfo', {
            url: "/findpwdwmoreinfo",
            templateUrl: "selfservice/views/findpwdwmoreinfo.html",
            controller: 'findPwdWMoreInfoCtlr'
        }).state('forgotCredByIdentity', {
            url: "/forgotCredByIdentity",
            templateUrl: "selfservice/views/findUserNameDetailsByIdentity.html",
            controller: 'verifyUserNameCtrl',
            params: { userinfo: {} },
            resolve: {
                forgotAccessResponseVO: function(forgotAccessService, $stateParams) {
                    var userinfo = $stateParams.userinfo;
                    if (!userinfo) {
                        userinfo = { userinfo: { 'userName': null } };
                    }
                    return forgotAccessService.getUserInfoForAccountRecoveryProcess(userinfo);
                }
            }
        }).state('selfservice', {
            url: "/selfservice",
            templateUrl: "selfservice/views/forgotunamepwd.html",
            controller: 'forgotAccessController'
        }).state('forgotOptumID', {
            url: "/forgotOptumID",
            templateUrl: "selfservice/views/forgotOptumId.html",
            controller: 'forgotAccessController'
        }).state('forgotpwd', {
            url: "/forgotpwd",
            templateUrl: "selfservice/views/forgotpwd.html",
            controller: 'forgotPwdController'
        }).state('accountrecoveryoptions', {
            url: "/accountrecoveryoptions"
        }).state('errorpage', {
            url: "/errorpage"
        }).state('privacyPolicy', {
            url: "/privacyPolicy",
            templateUrl: "privacyPolicy/views/privacyPolicy.html",
            controller: function(LanguageService) {
                LanguageService.doTranslate("privacyPolicy");
            }
        }).state('termsOfUse', {
            url: "/termsOfUse",
            templateUrl: "termsOfUse/views/termsOfUse.html",
            controller: "termsOfUsePreLoginCtrl"
        }).state('resetPassword', {
            url: "/resetPassword",
            templateUrl: "selfservice/views/resetPassword.html",
            controller: 'ResetPassCtrl',
            params: { userName: null },
            resolve: {
                redirect: function($state, ResetPasswordService, GeneralService) {
                    if (GeneralService.getURLParameter("authCode")) {
                        ResetPasswordService.validateAuthCode(GeneralService.getURLParameter("authCode")).then(function(response) {
                            var responseVO = response.data;
                            if (!responseVO.authCodeValid) {
                                $state.go("resetPwdLinkExp");
                            }
                        });
                        return;
                    }
                },
                userNameDetails: function($state, $stateParams, ResetPasswordService, GeneralService) {
                    if ($stateParams.userName) {
                        return $stateParams.userName;
                    } else {
                        return ResetPasswordService.getUsernameFromAuthCode(GeneralService.getURLParameter("authCode"));
                    }
                }
            }
        }).state('mobileVerification', {
            url: "/mobileVerification",
            templateUrl: "selfservice/views/mobileVerification.html",
            controller: 'mobileVerificationCtrl',
            params: { userName: null },
            resolve: {
                userNameDetails: function($stateParams) {
                    return $stateParams.userName;
                },
                currentWorkflowId: function(forgotAccessService) {
                    return forgotAccessService.getCurrentWorkflowId();
                },
                returnVerifyIdentity: function(forgotAccessService) {
                    return forgotAccessService.returnVerifyIdentityStatus();
                }
            }
        }).state('resetPwdLinkExp', {
            url: "/resetPwdLinkExp",
            title: "Reset Password: Verification Link - Optum ID",
            templateUrl: "selfservice/views/link_expired_page.html",
            controller: 'linkExpiredCtrl',
            resolve: {
                mainMessage: function(GeneralService) {
                    return GeneralService.getData('/tb/services/rest/commonController/linkExpMsg');
                },
                pageHeader: function() {
                    return "RESET_PWD_LINK_EXP";
                },
                isRPContextExist: function(GeneralService) {
                    return GeneralService.getData('/tb/services/rest/commonController/isRPContextExist');
                }
            }
        }).state('invitationLinkExp', {
            url: "/invitationLinkExp",
            templateUrl: "selfservice/views/link_expired_page.html",
            controller: 'linkExpiredCtrl',
            resolve: {
                mainMessage: function(GeneralService) {
                    return GeneralService.getData('/tb/services/rest/commonController/linkExpMsg');
                },
                pageHeader: function() {
                    return "INV_LINK_EXP";
                },
                isRPContextExist: function(GeneralService) {
                    return GeneralService.getData('/tb/services/rest/commonController/isRPContextExist');
                }
            }
        }).state('resetSecQnLinkExp', {
            url: "/resetSecQnLinkExp",
            title: "Reset Security Questions: Verification Link - Optum ID",
            templateUrl: "selfservice/views/link_expired_page.html",
            controller: 'linkExpiredCtrl',
            resolve: {
                mainMessage: function(GeneralService) {
                    return GeneralService.getData('/tb/services/rest/commonController/linkExpMsg');
                },
                pageHeader: function() {
                    return "RESET_SQ_LINK_EXP";
                },
                isRPContextExist: function(GeneralService) {
                    return GeneralService.getData('/tb/services/rest/commonController/isRPContextExist');
                }
            }
        }).state('setsecurityquestions', {
            url: "/setsecurityquestions",
            title: "Set Up Your Security Questions - Optum ID",
            templateUrl: "selfservice/views/setup_security_qs.html",
            controller: 'setSecurityQuestionsController',
            params: { userinfo: {} },
            resolve: {
                mainMessage: function(GeneralService, $stateParams) {
                    if ($stateParams.userinfo) {
                        $stateParams.userName = $stateParams.userinfo.userName;
                    }
                    return GeneralService.getData('/tb/services/rest/commonController/setupsecqnmessage');
                }
            }
        }).state('norecoveryoption', {
            url: "/norecoveryoption",
            title: "Verify Your Account - Optum ID",
            templateUrl: "selfservice/views/acct_no_recovery_option.html",
            controller: 'noAccoutRecoveryController',
            resolve: {
                messageData: function(GeneralService, LanguageService) {
                    LanguageService.doTranslate("selfservice");
                    return GeneralService.getData('/tb/services/rest/commonController/noAccountRecoveryMsg');
                },
                currentWorkflowId: function(forgotAccessService) {
                    return forgotAccessService.getCurrentWorkflowId();
                }
            }
        }).state('resetPwdVerificationLink', {
            url: "/resetPwdVerificationLink",
            templateUrl: "selfservice/views/reset_pwd_verification_link.html",
            controller: 'resetPwdVLinkCtrl',
            params: { userinfo: {} },
            resolve: {
                userDetails: function($stateParams) {
                    if ($stateParams.userinfo) {
                        return $stateParams.userinfo;
                    }
                },
                currentWorkflowId: function(forgotAccessService) {
                    return forgotAccessService.getCurrentWorkflowId();
                },
                returnVerifyIdentity: function(forgotAccessService) {
                    return forgotAccessService.returnVerifyIdentityStatus();
                }
            }
        }).state("tbErrorPage", {
            url: "/errorPage",
            templateUrl: "tb-error/views/errorPage.html",
            controller: "errorPageController",
            resolve: {
                'langData': function(LanguageService) {
                    LanguageService.doTranslate("tb-error");
                },
                errorData: function(errorService, $location) {
                    var errorCode = $location.search().errorCode;
                    var referenceCode = $location.search().referenceCode;
                    return errorService.getErrorMessages(errorCode, referenceCode);
                }
            }
        }).state("genErrorPage", {
            url: "/genErrorPage",
            templateUrl: "tb-error/views/genErrorPage.html",
            controller: "genErrorPageController",
            params: { errorCode: null },
            resolve: {
                'langData': function(LanguageService) {
                    LanguageService.doTranslate("tb-error");
                },
                errorData: function(genErrorService, $location) {
                    var errorCode = $location.search().errorCode;
                    return genErrorService.getErrorMessage(errorCode);
                }
            }
        }).state('createSecurityQuestions', {
            url: "/createSecQns",
            templateUrl: "selfservice/views/setSecurityQuestions.html",
            controller: 'createSecurityQuestionsCtrl',
            params: { userName: null },
            resolve: {
                redirect: function($state, ResetPasswordService, GeneralService) {
                    if (GeneralService.getURLParameter("authCode")) {
                        ResetPasswordService.validateAuthCode(GeneralService.getURLParameter("authCode")).then(function(response) {
                            var responseVO = response.data;
                            if (!responseVO.authCodeValid) {
                                $state.go("resetSecQnLinkExp");
                            }
                        });
                        return;
                    }
                },
                secQuestionsVO: function(GeneralService) {
                    return GeneralService.getData('/tb/services/rest/securityQuestions/fetchSecQns');
                },
                userInfo: function($state, $stateParams, ResetPasswordService, LanguageService, GeneralService) {
                    LanguageService.doTranslate("selfservice");
                    if ($stateParams.userName) {
                        return $stateParams.userName;
                    } else if (GeneralService.getURLParameter("authCode")) {
                        return ResetPasswordService.getUsernameFromAuthCode(GeneralService.getURLParameter("authCode"));
                    } else {
                        return;
                    }
                }
            }
        }).state("verifyAccount", {
            url: "/verifyAccount",
            templateUrl: 'registration/views/verifyAccount.html',
            controller: 'verifyAccountController',
            resolve: {
                getVerifyToken: function(GeneralService) {
                    var verifyToken = GeneralService.getURLParameter("verificationDetails");
                    return verifyToken;
                }
            }
       }).state('verifyIdentityBySecurityQuestions', {
    url: "/verifyIdentityBySecurityQuestions",
    templateUrl: "selfservice/views/verifyIdentityBySecurityQuestions.html",
    controller: 'verifyIdentityBySecQuestionsCtrl',
    params: { userinfo: {} },
    resolve: {
        forgotAccessResponseVO: function(forgotAccessService, $stateParams) {
            var userinfo = $stateParams.userinfo;
            if (!userinfo) {
                userinfo = { userinfo: { 'userName': null } };
            }
            return forgotAccessService.getUserInfoForAccountRecoveryProcess(userinfo);
        }
    }
    });
}
]);

indexApp.run(function($rootScope, $injector, AnalyticsService) {
    AnalyticsService.postPageViewData($rootScope, $injector);
});

indexApp.controller('appController', function($location, $scope, $rootScope, $timeout, AnalyticsService, $translate) {
    var reqVar = $translate.instant('RQD_VAR');

    $rootScope.$watch(function() {
        return $rootScope.fireErrorTracker;
    }, function(val) {
        if (AnalyticsService.globalAnalyticsObj.elemCount && val) { // &&val todo
            $timeout(function() {
                $scope.trackError(AnalyticsService.globalAnalyticsObj.postCallCount, true);
            });
        }
    });

    $rootScope.fireErrorTracker = false;

    $scope.trackError = function(count, isCallMadeFrmWatch) {
        if ($rootScope.fireErrorTracker && AnalyticsService.globalAnalyticsObj.elemCount && (count === AnalyticsService.globalAnalyticsObj.elemCount || isCallMadeFrmWatch)) {
            AnalyticsService.globalAnalyticsObj.postCallCount = 0;
            $rootScope.fireErrorTracker = false;
            var errorStr = "";
            var fName = "";
            var errStatus = "";
            var objKeys = Object.keys(AnalyticsService.globalAnalyticsObj.errorTrackObj);
            var objKeyLen = objKeys.length;
            var tempObj;

            for (var keys = 0; keys < objKeyLen; keys++) {
                tempObj = AnalyticsService.globalAnalyticsObj.errorTrackObj[objKeys[keys]];
                if (tempObj.errorElem.text().indexOf(reqVar) !== -1) {
                    errStatus = ":missing field";
                } else {
                    errStatus = ":invalid field";
                }
                if (tempObj.fieldName.indexOf("||") !== -1) {
                    fName = tempObj.fieldName.split('||')[0];
                } else {
                    fName = tempObj.fieldName;
                }

                errorStr = errorStr + fName + errStatus + "|";
            }

            var retStr = errorStr.substring(0, errorStr.length - 1);
            AnalyticsService.postErrorTrackInfo("field validation error", retStr);
        }
    };
});

indexApp.controller('footerCtrl', ['$scope', '$window', '$translate', function($scope, $window, $translate) {
    $scope.policyLabel = $translate.instant('P_POLICY');
    $scope.touselabel = $translate.instant('T_O_USE');
    $scope.linkinfo = $translate.instant('LINK_INFO');

    $('.outer-footer-wrapper').on("click", "a", function(event) {
        event.preventDefault();
    });

    $scope.checkLinks = function(linkLabel) {
        if (linkLabel === "privacyLink") {
            var newWindow = $window.open('/tb/app/index.html#/privacyPolicy', 'Optum ID', 'left=20, top=20, toolbar=no, titlebar=yes, location=no, directories=no, status=no, menubar=no, resizable=1, scrollbars=yes');
            newWindow.focus();
        }
        if (linkLabel === "termsLink") {
            $window.open('/tb/app/index.html#/termsOfUse', 'Optum ID', 'left=20, top=20, toolbar=no, titlebar=yes, location=no, directories=no, status=no, menubar=no, resizable=1, scrollbars=yes');
        }
    };
}]);

indexApp.controller('IndexCtrl', ['$scope', '$location', '$window', '$rootScope', '$translate', '$http', '$timeout', 'GeneralService', 'HelpObj', IndexController]);

function IndexController($scope, $location, $window, $rootScope, $translate, $http, $timeout, GeneralService, HelpObj) {
    $scope.rpAppId = null;
    $scope.rpUrl = null;
    $scope.ftrImgUrl = null;

    $rootScope.constants = {
        pwdFieldLen: "100",
        userNameFieldLen: "50",
        emailAddressFieldLen: "250",
        firstNameFieldLen: "50",
        middleNameFieldLen: "50",
        lastNameFieldLen: "50",
        suffixFieldLen: "50",
        yobFieldLen: "4",
        mobilePhoneFieldLen: "18",
        sqaFieldLen: "50",
        confirmCodeLen: "10"
    };

    // new help component has been added for help link in header
    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm' });

    $scope.checkForRp = function() {
        GeneralService.getData('/tb/services/rest/rp/checkIfRPExists').then(function(response) {
            $scope.isRPContextExist = response;
        });
        $scope.rpUrl = "/tb/services/rest/rp/rpapplogo";
        $scope.ftrImgUrl = "/tb/services/rest/rp/footerlogo";
    };

    $scope.help = function() {
        // Send a tracking event when help link is clicked
        if (typeof _satellite !== "undefined") {
            pageDataLayer.content.siteErrorType = "";
            pageDataLayer.content.siteErrorFields = "";
            pageDataLayer.content.siteSectionL1 = "";
            pageDataLayer.content.pageName = "helpPage";
            _satellite.track('trackPageView');
        }
    };

    // WCAG Focus Management
    // On pageload, set focus to <main>
    $rootScope.$on("$stateChangeSuccess", function() {
        var bodyStr = "body"; // Sonar FIX

        $timeout(function() {
            $(bodyStr).append("<span class='loading-message' tabindex='-1'>loading</span>");
            $(".loading-message").focus();

            $timeout(function() {
                $("main").attr("aria-label", angular.element(document.getElementsByTagName("h1")[0]).text());
                $("main").attr("tabindex", -1).focus();
                $(".loading-message").remove();
                $("main").removeAttr("tabindex");
            }, 1000);
        }, 10);
    });

}
