/*
 * Copyright (C) 2012 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.context;

import org.apache.log4j.Logger;

import java.lang.reflect.Constructor;

/**
 * Manages the current web service context for the executing
 * thread.
 * <p>
 * This class defaults to using a thread local storage mechanism, however,
 * it can be overwritten using the <i>mng.context</i> System property.  Here is a list
 * of acceptable usages:
 * <ul>
 *     <li><b>THREADLOCAL</b> - If specifed, a thread local strategy will be used</li>
 *     <li><b>INHERITABLE_THREAD_LOCAL</b> - If specified, an InheritableThreadLocal strategy
 *     will be used</li>
 *     <li><b>Class&lt;ContextHolderStrategy&gt;</b> - You can also specify the name of a
 *     Class which implements {@link WebApplicationContextHolderStrategy} and has a no argument constructor.</li>
 * </ul>
 * </p>
 * <p/>
 * This class is loosely based on Spring security's
 * {@link org.springframework.security.core.context.SecurityContextHolder}.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
public class WebApplicationContextHolder {
    public static final String MODE_THREADLOCAL = "THREADLOCAL";
    public static final String MODE_INHERITABLE_THREADLOCAL = "INHERITABLE_THREAD_LOCAL";

    public static final String SYSTEM_PROPERTY = "mng.context";

    private static final Logger LOG = Logger.getLogger(WebApplicationContextHolder.class);

    private static String strategyName = MODE_INHERITABLE_THREADLOCAL;
    private static WebApplicationContextHolderStrategy strategy;
    
    private void WebApplicationContextHolder(){
    	
    }

//    private static final ContextHolder instance = new ContextHolder();

    // initialize the ContextHolder
    static {
        String override = System.getProperty(SYSTEM_PROPERTY);
        if (override != null && !(override = override.trim()).isEmpty()) {
            strategyName = override;//.toUpperCase();
        }
        if (MODE_INHERITABLE_THREADLOCAL.equals(strategyName)) {
            strategy = new WebApplicationThreadLocalContextHolderStrategy(true);
        }
        // attempt to load strategy by class
        else if (!MODE_THREADLOCAL.equals(strategyName)) {
            try {
                Class<?> clazz = Class.forName(strategyName);
                Constructor<?> customStrategy = clazz.getConstructor();
                strategy = (WebApplicationContextHolderStrategy) customStrategy.newInstance();
            }
            catch (Exception ex) {
                LOG.warn("Unable to load custom ContextHolderStrategy '" + strategyName + "'. Using default.", ex);
            }
        }

        // fall back to default
        if (strategy == null) {
            strategy = new WebApplicationThreadLocalContextHolderStrategy(true);
        }

        // set initial empty context
        strategy.setContext(new WebApplicationContext());
    }

    /**
     * Returns the current context.
     *
     * @return The current context.
     */
    public static WebApplicationContext getContext() {
        return strategy.getContext();
    }

    /**
     * Clears the current context.
     */
    public static void clearContext() {
        strategy.clearContext();
    }

    /**
     * Stores the specified context using the
     * strategy represented by this instance.
     *
     * @param context The context being stored.
     */
    public static void setContext(WebApplicationContext context) {
        strategy.setContext(context);
    }
}
