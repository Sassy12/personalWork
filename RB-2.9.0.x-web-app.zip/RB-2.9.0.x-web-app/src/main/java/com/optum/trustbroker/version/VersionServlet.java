/*
 * Copyright (C) 2015 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.version;

import com.optum.trustbroker.versioning.ApplicationVersion;
import com.optum.trustbroker.versioning.VersionManager;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * <p>A simple servlet which will log the applications version information
 * on startup and exposes a simple REST API which allows for real-time retrieval
 * of the version information.
 * </p>
 * <p>Why a servlet?  A servlet can be configured to instantiated immediately
 * on deployment.  As a result, the version information can be logged
 * immediately.
 * </p>
 * <p/>
 * <p>
 * By default, this servlet will return the version data in JSON format.  Alternatively
 * XML content can be returned by setting the HTTP header Accept header to 'application/xml'.
 * An additional override parameter {@link #PARAM_TYPE} can be used to specify that the content
 * should be returned as JSON, XML or plain-text.  See parameter documentation for supported
 * value for this parameter.
 * </p>
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
public class VersionServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(VersionServlet.class);

    /**
     * Name of an HTTP request parameter which can be provided to the servlet
     * to control the type of content returned from the servlet request.
     * <p/>
     * <p>Supported parameter values are 'xml', 'text' and 'json'.  Any other
     * value will result in the default of 'json' content to be used.</p>
     */
    public static final String PARAM_TYPE = "type";

    /**
     * Initializes the servlet and logs the version information to
     * the application log.
     */
    @Override
    public void init() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(VersionManager.getInstance().getAppVersion());
        }
    }


    /**
     * Implements GET resource handling.  Returns application version information
     * upon execution in the format requested by the client.
     *
     * @param req  an {@link HttpServletRequest} object that
     *             contains the request the client has made
     *             of the servlet
     * @param resp an {@link HttpServletResponse} object that
     *             contains the response the servlet sends
     *             to the client
     * @throws IOException      if an input or output error is
     *                          detected when the servlet handles
     *                          the GET request
     * @throws ServletException if the request for the GET
     *                          could not be handled
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // check HTTP header for content type
        String acceptH = req.getHeader("Accept");
        boolean isJson = acceptH == null
                || !acceptH.contains("application/xml");

        // check for parameter override
        String pType = req.getParameter(PARAM_TYPE);
        if (pType != null) {
            if ("xml".equalsIgnoreCase(pType)) {
                isJson = false;
                resp.setContentType("application/xml");
            }
            else if ("text".equalsIgnoreCase(pType)) {
                isJson = false;
                resp.setContentType("text/plain");
            }
            // set default
            else {
                resp.setContentType("application/json");
            }
        }
        // set default
        else if (isJson) {
            resp.setContentType("application/json");
        }
        // fall back to XML
        else {
            resp.setContentType("application/xml");
        }

        // write version content back to client
        PrintWriter out = resp.getWriter();
        ApplicationVersion appVersion = VersionManager.getInstance().getAppVersion();
        try {
            if (isJson) {
                out.println(appVersion.toJson());
            }
            else {
                // add XML file header to content
                out.println("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                out.println(appVersion.toXml());
            }
        }
        finally {
            out.close();
        }
    }
}
