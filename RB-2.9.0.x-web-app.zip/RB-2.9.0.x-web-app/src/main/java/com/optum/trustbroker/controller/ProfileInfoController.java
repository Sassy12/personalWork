/*
 * Copyright (C) 2016 Optum ID
 *
 * All rights reserved.
 */
package com.optum.trustbroker.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.IntRange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.controller.vo.ErrorResponseVO;
import com.optum.trustbroker.controller.vo.LabelValueVO;
import com.optum.trustbroker.controller.vo.ManageProfileVO;
import com.optum.trustbroker.controller.vo.ProfileVO;
import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.helpers.UserHelper;
import com.optum.trustbroker.service.ReferenceService;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.ValidationUtils;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.RelyingPartyTierInfoVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

/**
 *
 * @author dgopinad
 */
@Component
@Path(TBConstants.MANAGE_PROFILE_CONTROLLER_PATH)
public class ProfileInfoController extends BaseController {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    private static final String FLD_NAME_DOB = "dob";

    @Autowired
    private ReferenceService referenceService;

    @Autowired
    private UserHelper userHelper;
    
    @Autowired
    private ValidationUtils validationUtils;
    
    

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response getDetails() {
        
        UserVO currentUserVO = getCurrentUser();
        String targetURL = getSessionAttribute(TrustBrokerWebAppConstants.TARGET);

        ManageProfileVO manageProfileVO = new ManageProfileVO();
        ProfileVO profileVO = new ProfileVO();
        userHelper.populateProfileFromUser(currentUserVO, profileVO);
        manageProfileVO.setProfile(profileVO);

        populateStates(manageProfileVO);
        processRelyingPartyInfo(manageProfileVO, targetURL);

        return Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(manageProfileVO).build();

    }

    @Path(TBConstants.GET_RPCONTEXT_PATH)
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response getRPDetails() {

        String targetURL = getSessionAttribute(TrustBrokerWebAppConstants.TARGET);
        ManageProfileVO manageProfileVO = new ManageProfileVO();
        /**
         * Skip populating relying party info when target URL is null
         * based on the assumption that target URL and rpAppId are both
         * required when coming from RPs.
         */

        if (targetURL != null) {
            processRelyingPartyInfo(manageProfileVO, targetURL);
        }

        return Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(manageProfileVO).build();
    }

    /**
    * Update the user profile in eSSO as well in trust broker database. 
    * @param profileVO ProfileVO
    * @return Response
    */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateInfo(ProfileVO profileVO, @Context HttpServletRequest request) {

        Map<String,String> validationErrors = validateProfileFields(profileVO);
        if (MapUtils.isNotEmpty(validationErrors)) {
            LOGGER.error("Profile validations failed with errors - {}", validationErrors);
            ResponseVO errorResponse = new ResponseVO();
            errorResponse.setErrorMap(validationErrors);
            errorResponse.setStatus(TrustBrokerWebAppConstants.ERROR);
            return Response.status(TrustBrokerWebAppConstants.HTTP_BAD_REQUEST).entity(errorResponse).build();
        }

        // get current user from eSSO
        UserVO essoUserVO = getCurrentUser();

        // get the user from repository/database
        UserVO trustBrokerUserVO = userService.fetchUserByUUID(essoUserVO.getUuId()).getUser();

        UserVO userVO = new UserVO();
        userHelper.populateUserFromProfile(profileVO, userVO);

        /**
         * capture previous values from eSSO for fields not updated through this screen
         * Email Address, Secondary Email Address, Phone No
         */
        userVO.setEmailAddress(essoUserVO.getEmailAddress());
        userVO.setSecEmailAddress(essoUserVO.getSecEmailAddress());
        userVO.setPhoneNumber(essoUserVO.getPhoneNumber());

        String rpAppId = null;

        /* request failing with demo-rp ID, need to check if it's required for actual RPs */
        if (StringUtils.isNotEmpty(essoUserVO.getRpId())) {
            userVO.setRpId(essoUserVO.getRpId());
            rpAppId = essoUserVO.getRpId();
        } else {
            rpAppId = tbResources.getString("TB_APP_ID");
        }

        // Set flags from database into new UserVO
        userHelper.updateUserFlags(trustBrokerUserVO, userVO);

        String dateOfBirth = userVO.getDobStr();
        if (StringUtils.isNotBlank(dateOfBirth)) {
            userVO.setDob(DateUtil.parseDate(dateOfBirth, DateUtil.EXT_DATE_FORMAT2));
        } else {
            userVO.setDob(null);
        }

        UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
        userProfileServiceRequest.setUser(userVO);
        userProfileServiceRequest.setOldUser(essoUserVO);

        UserProfileServiceResponse serviceResponse = userService.modifyUser(userProfileServiceRequest, true);

        if (TrustbrokerWebAppUtil.checkResponseStatus(serviceResponse)) {

            // send profile update notification to user
            sendProfileUpdateNotification(request, rpAppId, userVO, essoUserVO, false);

            ManageProfileVO manageProfileVO = new ManageProfileVO();
            manageProfileVO.setStatus(TBConstants.STATUS_SUCCESS);
            
            SecurityLoggingUtil.info(SecurityLoggingUtil.buildAuditLogRequestVO("User Account Modifications",SecurityEventType.E3_MODIFY,
                    request, userVO.getUserName(), "Security Audit Event|ModifyUserProfile:SUCCESS | User Profile Modified, UpdateUserProfileBean:updateProfile()", SecurityEventResult.SUCCESS,
           			rpAppId, SecuritySubEventType.E3_MODIFY_PROFILE));
            
            
            return Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(manageProfileVO).build();
        } else {
            String errorMsg = serviceResponse.getReasonMessage();
            ErrorResponseVO errorResponse = new ErrorResponseVO();
            errorResponse.setMessage(errorMsg);
            LOGGER.error("Unable to update profile for user {} in eSSO due to {} ",
                    new String[] {essoUserVO.getUserName(), errorMsg});
            return Response.status(TrustBrokerWebAppConstants.HTTP_BAD_REQUEST).entity(errorResponse).build();
        }
    }

    private void populateStates(ManageProfileVO manageProfileVO) {
        Map<String, String> results = referenceService.fetchStates();
        List<LabelValueVO> states = new ArrayList<LabelValueVO>();
        for (String key : results.keySet()) {
            LabelValueVO labelValueVO = new LabelValueVO();
            labelValueVO.setLabel(key);
            labelValueVO.setValue(key);
            states.add(labelValueVO);
        }
        manageProfileVO.setStates(states);
    }

    private Map<String, String> validateProfileFields(ProfileVO profileVO) {

        Map<String, String> errorMap = new HashMap<String, String>();
        String relyingAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);

        boolean dobReq = false;
        boolean coppaReq = true;

        if (StringUtils.isNotBlank(relyingAppId)) {
            RelyingPartyAppVO relyingPartyAppVO = getRPContext();
            RelyingPartyTierInfoVO rpTierInfo = getRPTierInfo(relyingPartyAppVO.getAlias());

            if (rpTierInfo.isDobRequired()) {
                dobReq = true;
            }

            if (TrustBrokerWebAppConstants.COPPA_REQUIRED_VALUE.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
                coppaReq = true;
            } else {
                coppaReq = false;
            }
        }
        
        UserInfoVO  userInfoVO = new UserInfoVO();
        userInfoVO.setFirstName(profileVO.getFirstName());
        userInfoVO.setLastName(profileVO.getLastName());
        userInfoVO.setMiddleName(profileVO.getMiddleName());
        
       	getValidationUtils().validateName(userInfoVO, TrustBrokerWebAppConstants.FIRST_NAME);
       	profileVO.setFirstName(userInfoVO.getFirstName());

       	if(StringUtils.isNotBlank(userInfoVO.getMiddleName())) {
       		getValidationUtils().validateName(userInfoVO, TrustBrokerWebAppConstants.MIDDLE_NAME);
       		profileVO.setMiddleName(userInfoVO.getMiddleName());
       	}

        getValidationUtils().validateName(userInfoVO, TrustBrokerWebAppConstants.LAST_NAME);
        profileVO.setLastName(userInfoVO.getLastName());
        
        if(MapUtils.isNotEmpty(userInfoVO.getErrorMap())) {
        	errorMap.putAll(userInfoVO.getErrorMap());
        }

        /**
         *  Validations for Date field
         *  - Required
         *  - Future date
         *  - Past date
         *  - COPPA validation based on RP
         */
        String dateOfBirth = profileVO.getDateOfBirth();

        if (dobReq && StringUtils.isBlank(dateOfBirth)) {
            errorMap.put(FLD_NAME_DOB, "dateOfBirthReq");
        } else if (StringUtils.isNotBlank(dateOfBirth)) {

            Date date = DateUtil.parseDate(dateOfBirth, DateUtil.EXT_DATE_FORMAT2);
            if (date == null) {
                errorMap.put(FLD_NAME_DOB, "invalidDate");
            } else {

                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.MILLISECOND, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.HOUR, 0);
                calendar.set(Calendar.HOUR_OF_DAY, 0);

                if (date.equals(calendar.getTime()) || !DateUtil.validateDateFuture(dateOfBirth)) {
                    errorMap.put(FLD_NAME_DOB, "futureDate");
                } else if (!DateUtil.validateDatePast(dateOfBirth)) {
                    errorMap.put(FLD_NAME_DOB, getMessage("dobPastErrorMsg508"));
                } else {
                    if (coppaReq) {
                        // validate age for coppa limit
                        boolean ageInvalid = DateUtil.validateAge(date, 13);
                        if (ageInvalid) {
                            errorMap.put(FLD_NAME_DOB, getMessage("dobAgeConstraintMsg"));
                        }
                    }
                }

            }

        }

        /* Address fields validation
        *  Either all(4) of them should be present or none of them should be present
        */

        int count = 0;

        if (StringUtils.isNotBlank(profileVO.getHomeAddress())) {
            count++;
        }
        if (StringUtils.isNotBlank(profileVO.getZip())) {
            count++;
        }
        if (StringUtils.isNotBlank(profileVO.getCity())) {
            count++;
        }
        if (StringUtils.isNotBlank(profileVO.getState())) {
            count++;
        }

        if (new IntRange(1, 3).containsInteger(count)) {
            errorMap.put("addressFieldsError", "addressFieldsError");
        }

        return errorMap;
    }

    public ValidationUtils getValidationUtils() {
        return validationUtils;
    }

    public void setValidationUtils(ValidationUtils validationUtils) {
        this.validationUtils = validationUtils;
    }

    public ReferenceService getReferenceService() {
        return referenceService;
    }

    public void setReferenceService(ReferenceService referenceService) {
        this.referenceService = referenceService;
    }

    public UserHelper getUserHelper() {
        return userHelper;
    }

    public void setUserHelper(UserHelper userHelper) {
        this.userHelper = userHelper;
    }
}
