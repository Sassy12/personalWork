package com.optum.trustbroker.controller.vo;

import java.io.Serializable;

public class TermsAndConditionsVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String version;
	private String content;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}