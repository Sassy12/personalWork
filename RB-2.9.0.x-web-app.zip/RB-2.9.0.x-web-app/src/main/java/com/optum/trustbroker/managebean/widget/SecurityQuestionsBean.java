package com.optum.trustbroker.managebean.widget;

/*******************************************************************************
 * Copyright (c) 2012 Optum - All Rights Reserved.
 ******************************************************************************/

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.richfaces.event.ItemChangeEvent;

import com.ingenix.uitoolkit.extendingProperties.ProductConfigurationMessageProvider;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserVO;

@SuppressWarnings("restriction")
@ManagedBean(name = "wSecurityQuestionsBean")
@ViewScoped
public class SecurityQuestionsBean extends AbstractBackingBean implements
		Serializable {

	private static final long serialVersionUID = 1L;
	protected static ProductConfigurationMessageProvider prodConfig = new ProductConfigurationMessageProvider();
	protected static int NO_SEC_QUESTIONS = Integer
			.parseInt((String) prodConfig.get("noOfSecQuestions"));

	private String securityQuestionOne;
	private String securityQuestionTwo;
	private String securityQuestionThree;
	private String securityAnswerOne;
	private String securityAnswerTwo;
	private String securityAnswerThree;
	private String token;
	private List<SelectItem> securityQuestionListOne;
	private List<SelectItem> securityQuestionListTwo;
	private List<SelectItem> securityQuestionListThree;
	private String selectedSecurityQuesOne = "";
	private String selectedSecurityQuesTwo = "";
	private String selectedSecurityQuesThree = "";
	List<UserChallengeQuestionVO> questions;
	
	private String currentButtonId ;
	
	public String getCurrentButtonId() {
		return currentButtonId;
	}

	public void setCurrentButtonId(String currentButtonId) {
		this.currentButtonId = currentButtonId;
	}

	public void pageChanged(ItemChangeEvent event) {
		int i=10;
	}

	private String emailExistsMsg;
	private String specialCharsMsg;

	private boolean showEmail;

	@ManagedProperty(value = "#{userService}")
	private UserService userService;

	@ManagedProperty(value = "#{userVO}")
	private UserVO updateUserVO;

	/*@Autowired
	private ConfigurationService configService;*/

	private ArrayList<SelectItem> securityQuestionsList;

	public String getEmailExistsMsg() {
		return emailExistsMsg;
	}

	public void setEmailExistsMsg(String emailExistsMsg) {
		this.emailExistsMsg = emailExistsMsg;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}



	public UserVO getUpdateUserVO() {
		return updateUserVO;
	}

	public void setUpdateUserVO(UserVO updateUserVO) {
		this.updateUserVO = updateUserVO;
	}




	/*@PostConstruct
	public void init() {
		ChallengeQuestionServiceResponse challengeQuestionServiceResponse = configService
				.getSecurityQuestions();
		questions = challengeQuestionServiceResponse
				.getUserChallengeQuestions();
		logger.debug("Challenge quetions size from web service: "
				+ questions.size());
	}
*/
	public String getSelectedSecurityQuesOne() {
		return selectedSecurityQuesOne;
	}

	public void setSelectedSecurityQuesOne(String selectedSecurityQuesOne) {
		this.selectedSecurityQuesOne = selectedSecurityQuesOne;
	}

	public String getSecurityQuestionOne() {
		return securityQuestionOne;
	}

	public void setSecurityQuestionOne(String securityQuestionOne) {
		this.securityQuestionOne = securityQuestionOne;
        setSecurityQuestionListTwo(filterSecurityQuestions(getSecurityQuestions(),
                                                           this.securityQuestionOne,
                                                           this.securityQuestionThree));
        setSecurityQuestionListThree(filterSecurityQuestions(getSecurityQuestions(),
                                                             this.securityQuestionOne,
                                                             this.securityQuestionTwo));
    }

    public String getSecurityQuestionTwo() {
		return securityQuestionTwo;
	}

	public void setSecurityQuestionTwo(String securityQuestionTwo) {
		this.securityQuestionTwo = securityQuestionTwo;
        setSecurityQuestionListOne(filterSecurityQuestions(getSecurityQuestions(),
                                                           this.securityQuestionTwo,
                                                           this.securityQuestionThree));
        setSecurityQuestionListThree(filterSecurityQuestions(getSecurityQuestions(),
                                                             this.securityQuestionTwo,
                                                             this.securityQuestionOne));
    }

	public String getSecurityQuestionThree() {
		return securityQuestionThree;
	}

	public void setSecurityQuestionThree(String securityQuestionThree) {
		this.securityQuestionThree = securityQuestionThree;
        setSecurityQuestionListOne(filterSecurityQuestions(getSecurityQuestions(),
                                                           this.securityQuestionThree,
                                                           this.securityQuestionTwo));
        setSecurityQuestionListTwo(filterSecurityQuestions(getSecurityQuestions(),
                                                           this.securityQuestionThree,
                                                           this.securityQuestionOne));
    }

	public String getSecurityAnswerOne() {
		return securityAnswerOne;
	}

	public void setSecurityAnswerOne(String securityAnswerOne) {
		this.securityAnswerOne = securityAnswerOne.trim();
	}

	public String getSecurityAnswerTwo() {
		return securityAnswerTwo;
	}

	public void setSecurityAnswerTwo(String securityAnswerTwo) {
		this.securityAnswerTwo = securityAnswerTwo.trim();
	}

	public String getSecurityAnswerThree() {
		return securityAnswerThree;
	}

	public void setSecurityAnswerThree(String securityAnswerThree) {
		this.securityAnswerThree = securityAnswerThree.trim();
	}

	public String getSelectedSecurityQuesTwo() {
		return selectedSecurityQuesTwo;
	}

	public void setSelectedSecurityQuesTwo(String selectedSecurityQuesTwo) {
		this.selectedSecurityQuesTwo = selectedSecurityQuesTwo;
	}

	public String getSelectedSecurityQuesThree() {
		return selectedSecurityQuesThree;
	}

	public void setSelectedSecurityQuesThree(String selectedSecurityQuesThree) {
		this.selectedSecurityQuesThree = selectedSecurityQuesThree;
	}
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	public List<UserChallengeQuestionVO> getQuestions() {
		return questions;
	}

	public void setQuestions(List<UserChallengeQuestionVO> questions) {
		this.questions = questions;

        // generate template list of SelectItem based on provided questions
        ArrayList<SelectItem> tmpSecurityQuestionsList = new ArrayList<SelectItem>();
        if (questions != null) {
            for (Iterator iterator = questions.iterator(); iterator.hasNext(); ) {
                UserChallengeQuestionVO userChallengeQuestionVO = (UserChallengeQuestionVO) iterator
                        .next();
                tmpSecurityQuestionsList.add(new SelectItem(
                        userChallengeQuestionVO.getQuestionId() + "_"
                                + userChallengeQuestionVO.getQuestion(),
                        userChallengeQuestionVO.getQuestion()));
            }
        }
        this.securityQuestionsList = tmpSecurityQuestionsList;
    }

	@SuppressWarnings({"rawtypes", "unchecked"})
	public List<SelectItem> getSecurityQuestions() {
        // return copy of the question list
		return (ArrayList<SelectItem>) securityQuestionsList.clone();
	}

	public List<SelectItem> getSecurityQuestionListOne() {
        // initialize to default if they have not been configured yet
        if (securityQuestionListOne == null) {
            securityQuestionListOne = getSecurityQuestions();
        }
		return securityQuestionListOne;
	}

	public void setSecurityQuestionListOne(
			List<SelectItem> securityQuestionListOne) {
		this.securityQuestionListOne = securityQuestionListOne;
	}

	public List<SelectItem> getSecurityQuestionListTwo() {
        // initialize to default if they have not been configured yet
        if (securityQuestionListTwo == null) {
            securityQuestionListTwo = getSecurityQuestions();
        }
		return securityQuestionListTwo;
	}

	public void setSecurityQuestionListTwo(
			List<SelectItem> securityQuestionListTwo) {
		this.securityQuestionListTwo = securityQuestionListTwo;
	}

	public List<SelectItem> getSecurityQuestionListThree() {
        if (securityQuestionListThree == null) {
            securityQuestionListThree = getSecurityQuestions();
        }
		return securityQuestionListThree;
	}

	public void setSecurityQuestionListThree(
			List<SelectItem> securityQuestionListThree) {
		this.securityQuestionListThree = securityQuestionListThree;
	}

    /**
     * Removes the SelectItems which match the specified filter strings from
     * the supplied list of SelectItems.
     *
     * @param questions The list of security question SelectItems to be filtered
     * @param filters The list of filter strings that will be used to filter the questions list
     * @return The filtered security question list
     */
    protected List<SelectItem> filterSecurityQuestions(List<SelectItem> questions, String... filters) {
        if (filters != null && filters.length > 0) {
            Set<String> filterSet = new HashSet<String>(filters.length);
            Collections.addAll(filterSet, filters);

            List<SelectItem> removeList = new ArrayList<SelectItem>(filters.length);
            for (SelectItem secQuestion : questions) {
                if (filterSet.contains(secQuestion.getValue())) {
                    removeList.add(secQuestion);
                }
            }
            if (!removeList.isEmpty()) {
                questions.removeAll(removeList);
            }
        }
        return questions;
    }

	public void securityQuestionOneChanged(ValueChangeEvent e) {
        // do nothing - update logic moved to setQuestionXxx method
	}

	public void securityQuestionTwoChanged(ValueChangeEvent e) {
        // do nothing - update logic moved to setQuestionXxx method
	}

	public void securityQuestionThreeChanged(ValueChangeEvent e) {
        // do nothing - update logic moved to setQuestionXxx method
	}

	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	public void checkSecurityAnswer(ValueChangeEvent event) {
		if (PhaseId.ANY_PHASE.equals(event.getPhaseId())) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		}

		if(!TBUtil.validateSecurityAnswer(event.getNewValue().toString())){
			addFacesMessage(((UIComponent)event.getSource()).getClientId(),tbResources.getString("obsceneTextInAnswer"));
		}
	}



	public void checkEmailAddress(ValueChangeEvent event) {
		emailExistsMsg = "";
		showEmail = false;

		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES) && !event.getNewValue().toString().isEmpty()) {
			boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
			if (!result) {
				setEmailExistsMsg(tbResources.getString("invalidEmailAddress"));
			} else {
				if (getCurrentUserVO().getEmailAddress().equalsIgnoreCase(updateUserVO.getEmailAddress())) {
					setEmailExistsMsg("");
				} else {
					if (userService.isEmailExists(updateUserVO.getEmailAddress().toLowerCase())) {
						showEmail = true;
						setEmailExistsMsg(tbResources.getString("emailAlreadyExists"));
					}
				}
			}
		}
	}




	public void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}
}
