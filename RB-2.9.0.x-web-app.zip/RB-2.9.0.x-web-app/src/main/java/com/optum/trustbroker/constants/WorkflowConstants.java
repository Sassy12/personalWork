package com.optum.trustbroker.constants;

public class WorkflowConstants {

	//Prevent from creating class instance as it has constants only
	private void WorkflowConstants(){
		
	}
	
	public static final String WORKFLOW_FORGOT_USER_NAME = "forgotUserName";
	public static final String WORKFLOW_FORGOT_PWD = "forgotPwd";
	public static final String WORKFLOW_USER_REGISTRATION = "userRegistration";
	public static final String WORKFLOW_SETUP_SECURITY_QUESTIONS = "setUpSecurityQuestion";
	public static final String WORKFLOW_UNLOCK_USER_ACCOUNT = "unlockUserAccount";
	public static final String EMAIL_CONFIRMATION_POST_LOGIN = "emailConfirmationPostLogin";
	public static final String WORKFLOW_UPDATE_EMAIL = "updateEmail";
	public static final String WORKFLOW_MANAGE_ID_VERIFY_OPTIONS = "manageIdVerifyOptions";
	
	public static final String WORKFLOW_ATTRIBUTE_EMAIL = "email";
	public static final String WORKFLOW_ATTRIBUTE_SEC_EMAIL = "secondaryEmail";
	public static final String WORKFLOW_ATTRIBUTE_MOBILE_NUMBER = "mobileNo";
	public static final String WORKFLOW_ATTRIBUTE_STATUS = "status";
	public static final String WORKFLOW_ATTRIBUTE_USERNAME = "username";
	public static final String WORKFLOW_ATTRIBUTE_UUID = "uuid";
	public static final String WORKFLOW_RETURN_VERIFY_IDENTITY = "returnVerifyIdentity";
	public static final String WORKFLOW_ATTRIBUTE_INVITATION = "invitation";
	public static final String WORKFLOW_ATTRIBUTE_RECOVERY_TYPE = "recoveryType";
}
