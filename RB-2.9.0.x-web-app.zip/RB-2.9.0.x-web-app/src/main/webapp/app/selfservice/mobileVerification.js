'use strict';

angular.module('indexApp').controller('mobileVerificationCtrl', ['$scope', '$timeout', '$state', 'trustbrokerAriaService', 'LanguageService', 'userNameDetails', 'mobileVerificationService', 'currentWorkflowId', 'returnVerifyIdentity', '$rootScope', 'HelpObj', mobileVerificationCtrl]);

function mobileVerificationCtrl($scope, $timeout, $state, trustbrokerAriaService, LanguageService, userNameDetails, mobileVerificationService, currentWorkflowId, returnVerifyIdentity, $rootScope, HelpObj) {
    LanguageService.doTranslate('selfservice');

    if (userNameDetails) {
        $scope.userName = userNameDetails;
    }

    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1026_Reset_Password_Verification_Code.htm' });

    $scope.isShowMsg = true;

    $scope.currentWorkflowId = currentWorkflowId.data;
    $scope.returnVerifyIdentityFlag = returnVerifyIdentity.data;

    $scope.errorMessageModel = {
        animationTime: 1,
        ariaAttributes: true,
        content: '<span translate="genericFormErrorSingle"></span>',
        headingLevel: '2',
        id: 'errorMessage',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    if ($scope.currentWorkflowId === 'forgotPwd' || $scope.currentWorkflowId === 'unlockUserAccount') {
        $scope.verifyIdentityFromTextMsg = "verifyIdentityFromTextMsgRstPswd";
        $scope.mobilePassVerificationHeader = "mobilePassVerificationHeaderUnlkPass";
        $scope.verifyIdentityFromResendTextMsg = 'otpResenttxtRstPwd';
        pageDataLayer.content.pageName = "verificationcode";
        pageDataLayer.content.siteSectionL1 = "resetpassword";
    } else if ($scope.currentWorkflowId === 'setUpSecurityQuestion') {
        $scope.verifyIdentityFromTextMsg = "verifyIdentityFromTextMsgSetupSQA";
        $scope.mobilePassVerificationHeader = 'mobilePassVerificationHeaderSetupSQA';
        $scope.verifyIdentityFromResendTextMsg = 'otpResenttxtSetupSQA';
        pageDataLayer.content.pageName = "verificationcode";
        pageDataLayer.content.siteSectionL1 = "setsecurityquestions";
    }

    if (typeof _satellite !== "undefined") {
        _satellite.track('trackPageView');
    }

    if ($scope.returnVerifyIdentityFlag === 'enable') {
        $scope.returnToVerifyIdentity = true;
    } else if ($scope.returnVerifyIdentityFlag === 'disable') {
        $scope.returnToVerifyIdentity = false;
    }

    $scope.successMessageModel = {
        animationTime: 1,
        autoFadeOut: false,
        content: '<span translate="' + $scope.verifyIdentityFromTextMsg + '"></span>',
        headingLevel: '2',
        id: 'successId',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: true
    };

    $scope.setFieldValidity = function(inputid, spanid) {
        trustbrokerAriaService.setFieldValidity(inputid, spanid);
    };

    $scope.retLinkClick = function($event) {
        $event.preventDefault();
        $state.go("forgotCredByIdentity", { userinfo: { 'userName': $scope.userName } });
    };

    $scope.resendOtp = function() {
        var serviceResponse = [];

        mobileVerificationService.resendOtp($scope.userName).then(function(response) {
            serviceResponse = response;

            if (serviceResponse.data.errorMap) {
                $scope.errorMessageModel.content = serviceResponse.data.errorMap.otpSendErrMsg;
                $scope.errorMessageModel.visible = true;
                $scope.isShowMsg = true;
            } else {
                // if ($scope.mobileOtpVerificationForm.$submitted && $scope.mobileOtpVerificationForm.verificationCode.$error.required) {
                //     $scope.mobileOtpVerificationForm.$setPristine();
                //     trustbrokerAriaService.removeDescribedByAttribute("verificationCodeId_input", "verificationCodeId_err");
                // }

                $scope.verificationCode = "";
                $scope.mobileOtpVerificationForm.$setPristine();
                trustbrokerAriaService.removeDescribedByAttribute("verificationCodeId_input", "verificationCodeId_err");

                $scope.errorMessageModel.visible = false;
                $scope.isShowMsg = false;
                $scope.successMessageModel.content = '<span translate="' + $scope.verifyIdentityFromResendTextMsg + '"></span>';

                $timeout(function() {
                    $('#successId').focus();
                }, 300);
            }
        });
    };

    // On clicking submit
    $scope.next = function() {
        var FIELDS = [{
            fld: "verificationCodeId_input",
            msg: "verificationCodeId_err"
        }];

        if ($scope.mobileOtpVerificationForm.verificationCode.$error.required) {
            $scope.errorMessageModel.content = '<span translate="genericFormErrorSingle"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.isShowMsg = true;

            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);

            $rootScope.fireErrorTracker = true;
            return;
        }

        var serviceResponse = [];

        var formData = {
            userName: $scope.userName,
            otp: $scope.verificationCode
        };

        mobileVerificationService.submitForm(formData).then(function(response) {
            serviceResponse = response;

            if ($scope.userName === '' || $scope.userName === undefined) {
                $scope.userName = serviceResponse.data.userName;
            }

            if (serviceResponse.data.errorMap) {
                $scope.errorMessageModel.content = '<span translate="genericFormErrorSingle"></span>';
                $scope.errorMessageModel.visible = true;
                $scope.isShowMsg = true;

                if (serviceResponse.data.errorMap.optError) {
                    $scope.serverError = serviceResponse.data.errorMap.optError;
                }

                if (serviceResponse.data.errorMap.optExpired) {
                    $scope.serverError = serviceResponse.data.errorMap.optExpired;
                }

                if (serviceResponse.data.errorMap.invalid) {
                    $scope.serverError = serviceResponse.data.errorMap.invalid;
                }

                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                }, 300);

                $rootScope.fireErrorTracker = true;
            } else {
                if ($scope.currentWorkflowId === 'forgotPwd' || $scope.currentWorkflowId === 'unlockUserAccount') {
                    $state.go("resetPassword", { 'userName': $scope.userName });
                } else {
                    $state.go("createSecurityQuestions", { 'userName': $scope.userName });
                }
            }
        });
    };
}
