package com.optum.trustbroker.managebean;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import com.optum.trustbroker.enums.AuthorizationCodeStatus;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.UserAuthorizationResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;

@ManagedBean(name = "mobileOtpBean")
@ViewScoped
public class MobileOtpBean extends AbstractBackingBean implements
		Serializable {

	private static final long serialVersionUID = 1L;
	BaseLogger logger = new BaseLogger(MobileOtpBean.class);

	private String errorMsg;
	private boolean widgetView=false;
	private String errorMsgOTP;
	
	public String getErrorMsgOTP() {
		return errorMsgOTP;
	}

	public void setErrorMsgOTP(String errorMsgOTP) {
		this.errorMsgOTP = errorMsgOTP;
	}

	private String otp;
	

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	@PostConstruct
	public void init() {
	}

	public void sendAnotherOTP() {
		
		try{
			Map<String, String> userDetailsMap = (Map<String, String>) getSessionAttribute(
					TrustBrokerWebAppConstants.USER_DETAILS_MAP);
			UserRetrievalServiceResponse  userRetrievalServiceResponse =container.getUserService().fetchUserProfile(
					userDetailsMap.get(TrustBrokerWebAppConstants.USER_NAME), false, true);
			UserAuthorizationResponse response = getContainer().getUserService().generateAuthCodeToUser(
					userRetrievalServiceResponse.getUser().getUuId(), TrustBrokerConstants.SMSOTP);
			getContainer().getSecureMessagingService().sendText(userRetrievalServiceResponse.getUser().getPhoneNumber(),
					"Optum ID One-Time Access Code:" + response.getUserAuthCode());
			this.errorMsg="A new OTP has been sent to your mobile number";
		} catch (Exception e) {
			setErrorMsg(tbResources.getString("otpSendErrMsg"));
			logger.error("Error in sending OTP to your mobile number: ", e);
		}
	}
	
	public void sendAnotherCodeSelfService() {
	}

	public String confirmOTPw() throws IOException{
		widgetView=true;
		return confirmOTP();
	}
	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		}
		return super.getFacesContext();
	}
	private void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}
	
	public String confirmOTP() throws IOException {
		
		setErrorMsg("");
		setErrorMsgOTP("");
		
		if(otp==null || otp.equals("")){
			
		//getFacesContext().addFacesMessage("accountrecoveryoptionsid:emailVerificationCode", new FacesMessage("OTP is empty"));
		//addFacesMessage("accountrecoveryoptionsid:emailVerificationCode", tbResources.getString("OTPmsg"));
			//this.errorMsg=tbResources.getString("OTPmsg");
			//setErrorMsg(tbResources.getString("OTPmsg"));
			setErrorMsg(tbResources.getString("OTPmsg"));
		    return null;
		}
		ExternalContext ec = getFacesContext().getExternalContext();
		UserAuthorizationResponse response = container.getUserService().validateAuthCode(otp);
		
		if (response == null){
			setErrorMsg(tbResources.getString("invalidMobileOTP"));
			return null;
		}
		if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
			
			if (response.getAuthStatus().equals(AuthorizationCodeStatus.PROCESSED.toString())){	
				this.errorMsg="OTP already used.";
				return null;
			}
			String recoveryType = (String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
			Map<String, String> userDetailsMap = new HashMap<String, String>();
			userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME, response.getUser().getUserName());
			userDetailsMap.put("authCode", otp);
			
			addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);
			if (response.getPurpose().equals(TrustBrokerConstants.ACCOUNT_RECOVERY))
				ec.redirect(ec.getRequestContextPath()+ "/views/resetsecuritycredentials.jsf");
			else if (response.getPurpose().equals(TrustBrokerConstants.SMSOTP)){
				
				if(TrustBrokerWebAppConstants.ONLINE_SECURITY_FLOW.equalsIgnoreCase(recoveryType)){
					ec.redirect(ec.getRequestContextPath()+ "/views/setsecurityques.jsf");
				} else {
					if(widgetView)
						ec.redirect(ec.getRequestContextPath()+ "/views/resetsecuritycredentialsw.jsf");
					else
					    ec.redirect(ec.getRequestContextPath()+ "/views/resetsecuritycredentials.jsf");
				}
			}
			
		} else if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(response
				.getExecutionStatus().getStatusCd()))
			ec.redirect(ec.getRequestContextPath()
					+ "/views/userauthorizationcodeexpired.jsf");
		return null;
	}


}

