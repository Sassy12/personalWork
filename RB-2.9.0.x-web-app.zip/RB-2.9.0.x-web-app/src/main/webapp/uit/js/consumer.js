/*
 * This is consumer javascript insertion file.
 * Consumers please place all your javascript functions in this file
 * or provide the relative path to your js file in the productConfigurations_Consumer.properties
 * property name: CustomJS
 */
/*
 if(document.location.href.indexOf('UIToolKitSign') > 0)
 alert ('CustomJS is active');
 */