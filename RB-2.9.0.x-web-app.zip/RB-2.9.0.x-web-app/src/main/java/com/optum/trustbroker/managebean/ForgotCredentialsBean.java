package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.commons.beans.EmailDetail;
import com.uhg.iam.commons.utils.ValidationUtilities;

@ManagedBean(name = "forgotCredentialsBean")
@ViewScoped
public class ForgotCredentialsBean extends AbstractBackingBean implements
		Serializable {
	private static final long serialVersionUID = 1L;
	private BaseLogger logger = new BaseLogger(ForgotCredentialsBean.class);
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String dobStr;

	String securityQuesPage = "/views/forgotusernamesecurityquesverificationpage.xhtml?faces-redirect=true";
	String emailNotVerifiedPage = "/views/emailnotverifiedpage.xhtml?faces-redirect=true";
	String userLockedPage = "/views/userlocked.xhtml?faces-redirect=true";
	String findusernamewithotherinformationPage = "/views/forgotUserNameForgotEmail.xhtml?faces-redirect=true";
	String sharedEmailPage = "/views/forgotUserNameSharedEmail.jsf";
	String confirmationPage = "/views/forgotcredentialsconfirmationpage.xhtml?faces-redirect=true";
	private String accountrecoveryoptions = "/views/accountrecoveryoptions.xhtml?faces-redirect=true";
	private String emailErrorMsg;
	private String errorMsg;
	private String sharedSuggestionMsg;
	private String suggestionMsg;
	private String emailId;
	private String searchText;
	boolean userError = false;
	private boolean isForgotPassword;
	private boolean isSharedEmail;
	private boolean blnkDobOrMob;
	
	// render DOB to reflect change in format from MMddyyyy to MM/dd/yyyy
	private boolean renderDOB = false;
	
	public boolean isRenderDOB() {
		return renderDOB;
	}

	public void setRenderDOB(boolean renderDOB) {
		this.renderDOB = renderDOB;
	}

	public boolean isBlnkDobOrMob() {
		return blnkDobOrMob;
	}

	public void setBlnkDobOrMob(boolean blnkDobOrMob) {
		this.blnkDobOrMob = blnkDobOrMob;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public boolean isUserError() {
		return userError;
	}

	public void setUserError(boolean userError) {
		this.userError = userError;
	}

	public boolean isForgotPassword() {
		return isForgotPassword;
	}

	public void setForgotPassword(boolean isForgotPassword) {
		this.isForgotPassword = isForgotPassword;
	}

	@PostConstruct
	public void init() {
		@SuppressWarnings("unchecked")
		Map<String, String> userDetailsMap = (HashMap<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		addRelyingPartyAlias(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null ? getSessionAttribute(
				TrustBrokerWebAppConstants.RELYING_APP_ID).toString()
				: null);
		addSessionAttribute(TrustBrokerWebAppConstants.RECOVERY_BY_EMAIL,
				getEmailId());
		addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP,
				userDetailsMap);
		addSessionAttribute(TrustBrokerWebAppConstants.REGISTER_TYPE,
				"standAlone");

		addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_NAME,
				getRelyingPartyName());
        
		if (isSessionAttributeExists(TrustBrokerWebAppConstants.SHARED_EMAIL)) {
			setEmailId((String) getSessionAttribute(TrustBrokerWebAppConstants.SHARED_EMAIL));
			setSharedSuggestionMsg(tbResources
					.getString("sharedEmailPageSuggestion"));

			removeSessionAttribute(TrustBrokerWebAppConstants.SHARED_EMAIL);
		}

	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void forgotUsername() {
	}

	public String getDobStr() {
		return dobStr;
	}

	public void setDobStr(String dobStr) {
		this.dobStr = dobStr;
	}

	public String getSharedSuggestionMsg() {
		return sharedSuggestionMsg;
	}

	public void setSharedSuggestionMsg(String sharedSuggestionMsg) {
		this.sharedSuggestionMsg = sharedSuggestionMsg;
	}

	public String continueClicked() {
		String pageName = getRequestParameter("pageInfo");
		blnkDobOrMob = false;
        boolean blnkFrstOrLst=false;
		
		if (StringUtils.isBlank(getEmailId()) && "simple".equals(pageName)) {
			getFacesContext().addMessage(
					"forgotUsernameForm:email",
					new FacesMessage(tbResources
							.getString("forgotusrnmemailreqd")));
			setErrorMsg(TBUtil.formatMessage(tbResources
					.getString("requiredEmailToSearchUsername"),
					new Object[] { getSupportContactInfo()
							.getContactComboText() }));
			return null;
		}

		if (StringUtils.isEmpty(this.emailId)
				&& StringUtils.isEmpty(this.phoneNumber)
				&& StringUtils.isEmpty(this.dobStr)
				&& StringUtils.isNotEmpty(this.firstName)
				&& StringUtils.isNotEmpty(this.lastName)
				&&"forgotEmail".equals(pageName)) {
			setErrorMsg(tbResources.getString("doborphoneError"));
			blnkDobOrMob = true;
			return null;

		}
		
		// Find username with other information
		if ("forgotEmail".equals(pageName)) {

			
			if (StringUtils.isEmpty(firstName) && StringUtils.isEmpty(lastName)
					&& StringUtils.isEmpty(this.phoneNumber)
					&& StringUtils.isEmpty(this.dobStr)) {

				addFacesMessage("forgotUsernameForm:firstName",
						"First Name is required");
				addFacesMessage("forgotUsernameForm:lastName",
						"Last Name is required");
				blnkDobOrMob = true;

			}
			if (StringUtils.isNotEmpty(firstName)
					&& StringUtils.isEmpty(lastName)
					&& StringUtils.isEmpty(this.phoneNumber)
					&& StringUtils.isEmpty(this.dobStr)) {

				addFacesMessage("forgotUsernameForm:lastName",
						"Last Name is required");
				blnkDobOrMob = true;

			}
			if (StringUtils.isEmpty(firstName)
					&& StringUtils.isNotEmpty(lastName)
					&& StringUtils.isEmpty(this.phoneNumber)
					&& StringUtils.isEmpty(this.dobStr)) {

				addFacesMessage("forgotUsernameForm:firstName",
						"First Name is required");

				blnkDobOrMob = true;

			}
			if (StringUtils.isEmpty(firstName)
					&& StringUtils.isNotEmpty(lastName)
					&& (StringUtils.isNotEmpty(this.phoneNumber)
					|| StringUtils.isNotEmpty(this.dobStr))) {

				addFacesMessage("forgotUsernameForm:firstName",
						"First Name is required");

				blnkFrstOrLst=true;

			}
			if (StringUtils.isNotEmpty(firstName)
					&& StringUtils.isEmpty(lastName)
					&& (StringUtils.isNotEmpty(this.phoneNumber)
					|| StringUtils.isNotEmpty(this.dobStr))) {

				addFacesMessage("forgotUsernameForm:lastName",
						"Last Name is required");
				blnkFrstOrLst=true;
				

			}
			
			if (StringUtils.isEmpty(firstName)
					&& StringUtils.isEmpty(lastName)
					&& (StringUtils.isNotEmpty(this.phoneNumber)
					|| StringUtils.isNotEmpty(this.dobStr))) {

				addFacesMessage("forgotUsernameForm:firstName",
						"First Name is required");
				addFacesMessage("forgotUsernameForm:lastName",
						"Last Name is required");
				blnkFrstOrLst=true;
				

			}

			boolean formLevelErrorExists = false;
			formLevelErrorExists = validatePhoneMultipleFormats("forgotUsernameForm:phoneNumber", phoneNumber);
			
			if(!StringUtils.isBlank(dobStr)) {
				formLevelErrorExists = validateDate("forgotUsernameForm:dob", dobStr);
			}
			
			if(blnkDobOrMob||blnkFrstOrLst||!formLevelErrorExists){
				setErrorMsg(TBUtil.formatMessage(tbResources
						.getString("formNotSubmittedNotHighlighted"),
						new Object[] { getSupportContactInfo()
								.getContactComboText() }));
				return null;
			}

		}

		if (!validatePhoneMultipleFormats("forgotUsernameForm:phoneNumber", phoneNumber) || (!StringUtils.isBlank(dobStr))
				&& !validateDate("forgotUsernameForm:dob", dobStr)) {
			if (!validateDate("forgotUsernameForm:dob", dobStr)
					&& StringUtils.isNotBlank(dobStr))
				addFacesMessage("forgotUsernameForm:dob",
						tbResources.getString("dobFormatErrorMsg508"));			
			if (StringUtils.isBlank(getEmailId())
					&& "sharedEmailCase".equals(pageName))
				getFacesContext().addMessage(
						"forgotUsernameForm:email",
						new FacesMessage(tbResources
								.getString("forgotusrnmemailreqd")));
			if (!validateEmailFields())
				getFacesContext().addMessage(
						"forgotUsernameForm:email",
						new FacesMessage(tbResources
								.getString("invalidEmailAddress")));

			setErrorMsg(TBUtil.formatMessage(tbResources
					.getString("formNotSubmittedNotHighlighted"),
					new Object[] { getSupportContactInfo()
							.getContactComboText() }));
			return null;
		}

		if (StringUtils.isBlank(getEmailId())
				&& "sharedEmailCase".equals(pageName)) {
			getFacesContext().addMessage(
					"forgotUsernameForm:email",
					new FacesMessage(tbResources
							.getString("forgotusrnmemailreqd")));
			setErrorMsg(TBUtil.formatMessage(tbResources
					.getString("requiredEmailToSearchShared"),
					new Object[] { getSupportContactInfo()
							.getContactComboText() }));
			return null;
		}

		if (!validateEmailFields()) {
			getFacesContext().addMessage(
					"forgotUsernameForm:email",
					new FacesMessage(tbResources
							.getString("invalidEmailAddress")));
			setErrorMsg(tbResources.getString("invalidEmailAddressMsg"));
			return null;
		}

		FacesContext context = getFacesContext();
		try {
			UserVO userVO = getUserProfile();
			if (userVO == null) {

				return null;
			}
			addSessionAttribute(
					TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE,
					TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW);
			addSessionAttribute("SELF_ACC_RECOVER_TYPE",
					TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW);
			return accountrecoveryoptions;
		} catch (OperationFailedException ex) {
			logger.error(
					"Error while verifying user details for user email {}",
					new String[] { getEmailId(),
							TrustbrokerWebAppUtil.getUidFromError(ex) }, ex);
			if (null != ex.getErrorMessage()) {
				setErrorMsg(ex.getErrorMessage().getEndUserMessage(
						container.getErrorMessageSource(),
						getSupportContactInfo()));
			} else if (ex.getMessage().equals(TrustBrokerConstants.USER_LOCKED)) {
				getFacesContext().addMessage(null,
						new FacesMessage("User Locked."));
				logger.info("ForgotCredentialsBean :: " + getEmailId()
						+ " user has been locked ");
				return null;
			}
			if (ex.getErrorMessages() != null
					&& ex.getErrorMessages().size() > 0) {
				String code = ex.getErrorMessages().keySet().iterator().next();
				if ("USR101".equals(code))
					context.addMessage(
							"forgotUsernameForm:email",
							new FacesMessage(
									"Email Address provided does not match our records"));
				else
					context.addMessage("forgotUsernameForm:email",
							new FacesMessage(ex.getMessage()));
			} else
				context.addMessage("forgotUsernameForm:email",
						new FacesMessage(ex.getMessage()));
			return null;
		}
	}

	public String findusernamewithotherinformationClicked() {
		removeSessionWithoutRelyingPartyInfo();
		return findusernamewithotherinformationPage;
	}

	public String navToLoginpage() {
		return "/views/login.xhtml?faces-redirect=true";
	}

	private UserVO getUserProfile(String username, boolean isUUID) {

		UserRetrievalServiceResponse response = null;
		UserVO userVO = null;
		try {
			response = getContainer().getUserService().fetchUserProfile(
					username, isUUID, false);

		} catch (OperationFailedException ofe) {
			return null;
		} catch (Exception e) {
			return null;
		}

		if (response != null) {
			userVO = response.getUser();
			Map<String, String> userDetailsMap = new HashMap<String, String>();
			userDetailsMap.put("emailId", getEmailId());
			userDetailsMap.put("uuId", userVO.getUuId());
			userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME,
					userVO.getUserName());
			addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP,
					userDetailsMap);

			if (StringUtils.isNotBlank(userVO.getEmailAddress())
					|| !userVO.isPrimaryEmailUnique()) {
				UserChallengeQuestionServiceResponse userChallengeResp = null;
				try {
					userChallengeResp = getContainer()
							.getUserService()
							.getChallengeQuestions(
									userVO.getUuId(),
									TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
				} catch (OperationFailedException ofe) {
				}

				if ((StringUtils.isNotBlank(userVO.getEmailAddress())
						&& userVO.isIsemailVerified() && userVO
							.isPrimaryEmailUnique())
						|| (StringUtils.isNotBlank(userVO.getSecEmailAddress())
								&& userVO.isSecEmailVerified() && userVO
									.isSecEmailUnique())
						|| (StringUtils.isNotBlank(userVO.getPhoneNumber()) && userVO
								.getIsPhoneVerified())
						|| (null != userChallengeResp
								&& null != userChallengeResp
										.getUserChallengeQuestions() && userChallengeResp
								.getUserChallengeQuestions().size() > 0))
					;
				else {
					logger.info(
							"ForgotCredentialsBean | Email Address {} doesn't have any recovery methods",
							new String[] { getEmailId() });
					generateAcctRecoveryNotUniqueError();
					return null;
				}
			} else {
				logger.info(
						"ForgotCredentialsBean | Email Address {} is not unique",
						new String[] { getEmailId() });
				generateAcctRecoveryNotUniqueError();
				return null;
			}
		}

		return userVO;
	}

	public void checkdateOfBirth(ValueChangeEvent event) {

		PhaseId phaseId = event.getPhaseId();
        
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();

		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			setRenderDOB(false);
			boolean isValid = validateDate("forgotUsernameForm:dob", dobStr);
			if(isValid == false) {
				return;
			}
			
			// covert date to MM/dd/yyyy format if the input format is MMddyyyy
			String convertedDate = DateUtil.formatDate(dobStr, DateUtil.EXT_DATE_FORMAT3, DateUtil.EXT_DATE_FORMAT);
			if(!StringUtils.isEmpty(convertedDate)) {
				dobStr = convertedDate;
				setRenderDOB(true);
			}
		}
		

	}
	
	public void checkPhone(ValueChangeEvent event) {

		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {

			validatePhoneMultipleFormats("forgotUsernameForm:phoneNumber", phoneNumber);
		
		}
	}


	public static boolean validateEmailId(String enteredEmailId) {
		if (enteredEmailId != null && !enteredEmailId.equals("")) {
			EmailDetail emailDetail = new EmailDetail();
			emailDetail.setEmailAddress(enteredEmailId);
			emailDetail.setLabel("EMAIL");
			try {
				ValidationUtilities.isValidEmail(emailDetail);
			}
			catch (Exception e) {
				return false;
			}
		}
		return true;
	}

	public String continuePassword() {

		if (searchText == null || searchText.isEmpty()) {
			setErrorMsg(TBUtil.formatMessage(tbResources
					.getString("requiredEmailUsernameToSearch"),
					new Object[] { getSupportContactInfo()
							.getContactComboText() }));
			addFacesMessage("forgotPasswordForm:searchText",
					tbResources.getString("forgotpwdinputreqd"));
			return null;
		}

		setForgotPassword(true);
		setErrorMsg("");
		boolean isUserName = false;

		if (validateEmailId(searchText)) {
			isUserName = false;
			emailId = searchText;
		} else {
			isUserName = true;
		}

		if (!validateEmailFields()) {
			getFacesContext().addMessage(
					"forgotPasswordForm:email",
					new FacesMessage(tbResources
							.getString("invalidEmailAddress")));
			return null;
		}

		FacesContext context = getFacesContext();

		UserVO userVO = null;
		try {

			if (isUserName) {
				userVO = getUserProfile(searchText, false);
				if (userVO == null) {
					if (StringUtils.isBlank(getErrorMsg())) {
						SupportContactInfoVO sci = getSupportContactInfo();
						Object[] msgArguments = { sci.getContactComboText() };
						setErrorMsg(TBUtil.formatMessage(tbResources
								.getString("noAccountMsgForgotPassword"),
								msgArguments));
					}
					return null;
				}
			} else {
				userVO = getUserProfile();
				if (userVO == null)
					return null;
			}

			addSessionAttribute(
					TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE,
					TrustBrokerWebAppConstants.FORGOT_PWD_FLOW);

			addSessionAttribute("SELF_ACC_RECOVER_TYPE",
					TrustBrokerWebAppConstants.FORGOT_PWD_FLOW);
		} catch (OperationFailedException ex) {
			logger.error(
					"Error while verifying user details for user email {}",
					new String[] { getEmailId(),
							TrustbrokerWebAppUtil.getUidFromError(ex) }, ex);
			if (null != ex.getErrorMessage()) {
				setErrorMsg(ex.getErrorMessage().getEndUserMessage(
						container.getErrorMessageSource(),
						getSupportContactInfo()));
			} else if (ex.getMessage().equals(TrustBrokerConstants.USER_LOCKED)) {
				getFacesContext().addMessage(null,
						new FacesMessage("User Locked."));
				logger.info("ForgotCredentialsBean :: " + getEmailId()
						+ " user has been locked ");
				return null;
			}
			if (ex.getErrorMessages() != null
					&& ex.getErrorMessages().size() > 0) {
				String code = ex.getErrorMessages().keySet().iterator().next();
				if ("USR101".equals(code))
					context.addMessage(
							"forgotPasswordForm:email",
							new FacesMessage(
									"Email Address provided does not match our records"));
				else
					context.addMessage("forgotPasswordForm:email",
							new FacesMessage(ex.getMessage()));
			} else
				context.addMessage("forgotPasswordForm:email",
						new FacesMessage(ex.getMessage()));
			return null;
		}
		return accountrecoveryoptions;
	}

	public UserVO getUserProfile() throws OperationFailedException {

		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		UserVO userValueObject = new UserVO();
		userValueObject.setEmailAddress(getEmailId());
		userValueObject.setFirstName(getFirstName());
		userValueObject.setLastName(getLastName());
		//userValueObject.setPhoneNumber(getPhoneNumber());
		userValueObject.setPhoneNumber(getPhoneNumberInAcceptedBackendFormat(getPhoneNumber()));
		userValueObject.setDobStr(getDobStr());
		if (StringUtils.isNotBlank(getDobStr()))
			userValueObject.setDob(DateUtil.parseDate(getDobStr(),
					DateUtil.EXT_DATE_FORMAT));

		userProfileServiceRequest.setUser(userValueObject);
		boolean userDuplicate = false;
		boolean userNotFound = false;
		UserRetrievalServiceResponse userRetrievalServiceResponse = null;
		UserProfileServiceResponse userProfileServiceResponse = null;

		userProfileServiceResponse = getContainer().getUserService()
				.lookupUserByHeuristicEvaluation(userValueObject, "*");

		if (userProfileServiceResponse
				.getExecutionStatus()
				.getStatusCd()
				.equals(TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE))
			userDuplicate = true;
		else if (userProfileServiceResponse.getExecutionStatus().getStatusCd()
				.equals(TrustBrokerConstants.FAILURE_CODE_VALUE))
			userNotFound = true;

		if (userNotFound) {

			SupportContactInfoVO sci = getSupportContactInfo();
			Object[] msgArguments = { sci.getContactComboText() };
			setSharedSuggestionMsg("");
			if (isUserEmailShared(userValueObject)) {
				setErrorMsg(TBUtil.formatMessage(tbResources
						.getString("selfServiceInvalidActSharedErrMsg"),
						msgArguments));
			} else {
				setErrorMsg(TBUtil.formatMessage(
						tbResources.getString("selfServiceInvalidActErrMsg"),
						msgArguments));
			}

			return null;
		}

		if (userDuplicate) {

				if (isForgotPassword) {
				setErrorMsg(tbResources.getString("multAccountMsg"));
				
				
				return null;

			} else {
				isForgotPassword = false;
				SupportContactInfoVO sci = getSupportContactInfo();
				Object[] msgArguments = { sci.getContactComboText() };
				if(!StringUtils.isBlank(getFirstName())&&!StringUtils.isBlank(getLastName())){
					
					setErrorMsg(TBUtil
							.formatMessage(
									tbResources
											.getString("selfServiceInvalidActSharedErrMsg"),
									msgArguments));
					
					return null;
					
				}
				
				if (StringUtils.isBlank(getFirstName())
						&& StringUtils.isBlank(getLastName())
						&& StringUtils.isBlank(getDobStr())
						&& StringUtils.isBlank(getPhoneNumber())) {

					String pageName = getRequestParameter("pageInfo");
					if ("sharedEmailCase".equals(pageName)) {

						
						setSharedSuggestionMsg("");
						if (isUserEmailShared(userValueObject)) {
							setErrorMsg(TBUtil
									.formatMessage(
											tbResources
													.getString("selfServiceInvalidActSharedErrMsg"),
											msgArguments));
						} else {
							setErrorMsg(TBUtil.formatMessage(tbResources
									.getString("selfServiceInvalidActErrMsg"),
									msgArguments));
						}

						return null;

					} else {
						addSessionAttribute(
								TrustBrokerWebAppConstants.SHARED_EMAIL,
								getEmailId());
						redirectToView(sharedEmailPage);
					}

				}

				return null;
			}
		}

		userRetrievalServiceResponse = getContainer().getUserService()
				.fetchUserProfile(
						userProfileServiceResponse.getUser().getUuId(), true,
						false);

		Map<String, String> userDetailsMap = new HashMap<String, String>();
		userDetailsMap.put("emailId", getEmailId());
		userDetailsMap.put("uuId", userRetrievalServiceResponse.getUser()
				.getUuId());
		userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME,
				userRetrievalServiceResponse.getUser().getUserName());
		addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP,
				userDetailsMap);

		UserVO userVO = null;
		if (userRetrievalServiceResponse != null) {
			userVO = userRetrievalServiceResponse.getUser();
			if (StringUtils.isNotBlank(userVO.getEmailAddress())
					|| !userVO.isPrimaryEmailUnique()) {
				UserChallengeQuestionServiceResponse userChallengeResp = null;
				try {
					userChallengeResp = getContainer()
							.getUserService()
							.getChallengeQuestions(
									userVO.getUuId(),
									TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
				} catch (OperationFailedException ofe) {
				}

				if ((StringUtils.isNotBlank(userVO.getEmailAddress())
						&& userVO.isIsemailVerified() && userVO
							.isPrimaryEmailUnique())
						|| (StringUtils.isNotBlank(userVO.getSecEmailAddress())
								&& userVO.isSecEmailVerified() && userVO
									.isSecEmailUnique())
						|| (StringUtils.isNotBlank(userVO.getPhoneNumber()) && userVO
								.getIsPhoneVerified())
						|| (null != userChallengeResp
								&& null != userChallengeResp
										.getUserChallengeQuestions() && userChallengeResp
								.getUserChallengeQuestions().size() > 0))
					;
				else {
					logger.info(
							"ForgotCredentialsBean | Email Address {} doesn't have any recovery methods",
							new String[] { getEmailId() });
					generateAcctRecoveryNotUniqueError();
					return userVO;
				}
			} else {
				logger.info(
						"ForgotCredentialsBean | Email Address {} is not unique",
						new String[] { getEmailId() });
				generateAcctRecoveryNotUniqueError();
				return userVO;
			}
		}
		return userVO;
	}

	public Date convertToDateFormat(String dateInString) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date date = sdf.parse(dateInString);
		return date;
	}

	public boolean isUserEmailShared(UserVO userVO) {
		boolean userEmailShared = false;
		try {
			if (container.getUserService().isEmailExists(
					userVO.getEmailAddress())) {
				userEmailShared = true;
			}
		} catch (OperationFailedException ofe) {
			logger.error(
					"ResetSecurityCredentials Bean:isUserEmailShared | Error checking duplicate email",
					ofe);
		}
		return userEmailShared;
	}

	private void generateAcctRecoveryNotUniqueError() {
		SupportContactInfoVO sci = getSupportContactInfo();
		Object[] msgArguments = { sci.getContactComboText() };
		setErrorMsg(TBUtil.formatMessage(
				tbResources.getString("acctRecoveryNotUniqueErrorMsg"),
				msgArguments));
	}

	/**
	 * Gets the faces context
	 * 
	 * @return current FacesContext otherwise
	 */
	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		}
		return super.getFacesContext();
	}

	private boolean validateEmailFields() {
		boolean result = true;
		if (!TBUtil.validateEmailId(getEmailId())) {
			result = false;
		}
		return result;
	}

	public void checkEmailAddress(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			if (StringUtils.isNotEmpty(event.getNewValue().toString())) {
				boolean result = TBUtil.validateEmailId(event.getNewValue()
						.toString());
				logger.debug("result value in email: " + result);
				if (!result)
					addFacesMessage(
							((UIComponent) event.getSource()).getClientId(),
							tbResources.getString("invalidEmailAddress"));
			}
		}
	}

	private void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	/**
	 * @param emailExistsMsgId
	 *            the emailExistsMsgId to set
	 */
	public void setEmailErrorMsg(String emailErrorMsg) {
		this.emailErrorMsg = emailErrorMsg;
	}

	/**
	 * @return the emailExistsMsgId
	 */
	public String getEmailErrorMsg() {
		return emailErrorMsg;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getSuggestionMsg() {
		return suggestionMsg;
	}

	public void setSuggestionMsg(String suggestionMsg) {
		this.suggestionMsg = suggestionMsg;
	}
}
