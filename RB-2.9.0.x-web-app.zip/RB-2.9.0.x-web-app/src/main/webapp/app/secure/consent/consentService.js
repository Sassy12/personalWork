/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 */
'use strict';
angular.module('tbApp').service('ConsentService',['$http', ConsentService]);

function ConsentService($http){
	
	this.getConsentVO = function(){		
		   var promise = $http.get('/tb/services/rest/commonController/consentInfo');
		      promise.success(function(data) {
		        return data;
		      });
		      return promise;
	};
	this.agreeConsent= function(){
		return $http.get('/tb/services/secure/rest/commonSecureController/agreeConsent');
		
	};
}