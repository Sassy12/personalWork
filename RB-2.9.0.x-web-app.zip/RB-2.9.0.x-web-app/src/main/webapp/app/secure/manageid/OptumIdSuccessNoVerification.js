'use strict';

var tbApp = angular.module('tbApp');

tbApp.controller('noVerificationCtrl', ['$scope', '$state', '$translate', function($scope, $state, $translate) {
    // alt text for success message model
    $scope.altText = $translate.instant('altTextForSuccessMessage');

    // defining the message modal to be displayed on page
    $scope.successMessageNoVerification = {
        animationTime: 1,
        autoFadeOut: false,
        content: '<span translate="optumSuccessMsg"></span>',
        headingLevel: '2',
        id: 'Success',
        messageRole: 'status',
        messageType: 'success',
        position: 'inline',
        visible: true
    };

    //function to navigate to next screen
    $scope.navigateToRP = function() {
        $state.go('profile.profileinfo');
    };
}]);
