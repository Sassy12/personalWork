package com.optum.trustbroker.controller.vo;

/**
 * Created by dgopinad on 5/3/2016.
 */
public class PreferenceVO {

    private String preferenceType;
    private String preferenceValue;
    private String maskedValue;

    public String getPreferenceType() {
        return preferenceType;
    }

    public void setPreferenceType(String preferenceType) {
        this.preferenceType = preferenceType;
    }

    public String getPreferenceValue() {
        return preferenceValue;
    }

    public void setPreferenceValue(String preferenceValue) {
        this.preferenceValue = preferenceValue;
    }

    public String getMaskedValue() {
        return maskedValue;
    }

    public void setMaskedValue(String maskedValue) {
        this.maskedValue = maskedValue;
    }
}
