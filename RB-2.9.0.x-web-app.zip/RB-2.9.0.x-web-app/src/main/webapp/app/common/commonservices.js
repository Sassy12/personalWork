'use strict';
var services = angular.module('common.services', []);
services.service('LanguageService', LanguageService);
services.service('GeneralService', GeneralService);
services.directive('textWithEmail', textWithEmail);
services.factory('ServiceResponseInterceptor', ServiceResponseInterceptor);

window.pageDataLayer={'content':
{'businessUnit':'optum',
'website':'id'
}
};
services.service('AnalyticsService', ['$timeout', function($timeout) {
	var stateToPageNameArr = {
		"registration" : {
			"pageName" : "userregistration",
			"siteSectionL1" : ""
		},
		"updateEmailAddress":{
			"pageName" : "verifycodesupdate",//taken from old impl
			"siteSectionL1" : ""
		},
		"congratulations":{
			"pageName" : "emailaddressconfirmed",
			"siteSectionL1" : ""
		},
		"profile.changepwd":{
			"pageName" : "changepassword",
			"siteSectionL1" : ""
		},
		"resetPassword":{
			"pageName" : "resetpassword",
			"siteSectionL1" : ""
		},
		"findusrwmoreinfo":{
			"pageName" : "otherinfo",
			"siteSectionL1" : "findusername"
		},
		"forgotcredentialPage":{
			"pageName" : "sharedemailaddress",
			"siteSectionL1" : "findusername"
		},
		"migrationsuccess":{
			"pageName" : "accountUpdatesSuccess",
			"siteSectionL1" : ""
		},
		"findpwdwmoreinfo":{
			"pageName" : "sharedEmailAddress",
			"siteSectionL1" : "forgotPassword"
		},
		"selfservice":{
			"pageName" : "forgotusernameorpasswordpage",
			"siteSectionL1" : ""
		},
        "forgotpwd" : {
            "pageName" : "forgotpwd",
            "siteSectionL1" : ""
        },
		"norecoveryoption":{
			"pageName" : "noAccountRecoveryOptions",
			"siteSectionL1" : ""
		},
		"consent":{
			"pageName" : "shareMyOptumID",
			"siteSectionL1" : ""
		},
		"termsOfUse":{
			"pageName" : "termsandconditions",
			"siteSectionL1" : ""
		},
		"privacyPolicy":{
			"pageName" : "privacypolicy",
			"siteSectionL1" : ""
		},
		"resetPwdLinkExp":{
			"pageName" : "userauthorizationcodeexpired",
			"siteSectionL1" : "resetpasswordverificationlinkexpired"
		},
		"invitationLinkExp":{
			"pageName" : "userauthorizationcodeexpired",
			"siteSectionL1" : "invitationlinkexpired"
		},
		"resetSecQnLinkExp":{
			"pageName" : "userauthorizationcodeexpired",
			"siteSectionL1" : "resetsecurityquestionslinkexpired"
		},
		"profile.verifyoptions":{
			"pageName" : "manageVerificationOptions",
			"siteSectionL1" : ""
		},
		"optumIdSuccessVerificationNeeded":{
			"pageName" : "optumIdSuccessVerificationNeeded",
			"siteSectionL1" : ""
		},
		"mobileVerification":{
			"pageName" : "mobilePhoneVerificationCode",
			"siteSectionL1" : ""
		},
		"lexisNexis":{
			"pageName" : "additionalinformation",
			"siteSectionL1" : "youroptumID"
		},
		"optumIdSuccessNoVerification":{
			"pageName" : "optumIdSuccessNoVerification",
			"siteSectionL1" : ""
		},
		"mobileVerificationSuccess":{
			"pageName" : "mobilePhoneVerificationSuccess",
			"siteSectionL1" : ""
		},
		"lexisNexisSuccess":{
			"pageName" : "additionalinformationSuccess",
			"siteSectionL1" : ""
		},
		"addAccountRecovery":{
			"pageName" : "addAccountRecovery",
			"siteSectionL1" : ""
		},
		"forgotOptumID":{
            "pageName" : "forgotOptumID",
            "siteSectionL1" : ""
        },
        "verifyIdentityBySecurityQuestions":{
            "pageName" : "verifyIdentityBySecurityQuestions",
            "siteSectionL1" : ""
        }

	};
	var errorCodeToErrInfo = {
			"00A":"esso service error",
			"00B":"identity service error",
			"00C":"site minder error",
			"00D":"database error",
			"00E":"encryption/decryption failure",
			"00F":"rsa error",
			"00K":"coppa error",
			"00S":"secure messaging error",
			"500":"internal server error",
			"invalidRPappDomain":"invalid rp url",
			"404":"incorrect address"
	};
	var dummyPageDataLayer={};
	
	this.postPageViewData = function(rootScope, injector) {
		dummyPageDataLayer={};
		if (injector.has('$state')) {
			rootScope.$on('$stateChangeSuccess', function(e, toState, toParams, fromState) {
				var onLoadCallBack = function (){};
				dummyPageDataLayer.stateName = toState.name;
				dummyPageDataLayer.fromState = fromState.url;
				pageDataLayer.content.siteErrorCode ="";
				if(dummyPageDataLayer.fromState === "^"){
					onLoadCallBack = function(){
						var stateName = dummyPageDataLayer.stateName;
						if (stateName && stateToPageNameArr[stateName]) {
							pageDataLayer.content.siteErrorType = "";
							pageDataLayer.content.siteErrorFields = "";
							
							pageDataLayer.content.siteSectionL1=stateToPageNameArr[stateName].siteSectionL1 ;
							pageDataLayer.content.pageName=stateToPageNameArr[stateName].pageName;
						}
						
						if(typeof _satellite !== "undefined"){
							_satellite.track('trackPageView');
						}
					};
					window.addEventListener('load',onLoadCallBack);
				} else {
					window.addEventListener('load', onLoadCallBack);
				}
				
			});
			
			rootScope.$on('$stateChangeError', function() {
				dummyPageDataLayer.stateName = "";
			});
			
			rootScope.$on('$viewContentLoaded', function() {
				if(dummyPageDataLayer.fromState !== "^"){
					$timeout(function(){
						var stateName = dummyPageDataLayer.stateName;
						if(typeof _satellite !== "undefined" && stateName && stateToPageNameArr[stateName]){
								pageDataLayer.content.siteErrorType = "";
								pageDataLayer.content.siteErrorFields = "";
								pageDataLayer.content.siteErrorCode ="";
								
								pageDataLayer.content.siteSectionL1=stateToPageNameArr[stateName].siteSectionL1 ;
								pageDataLayer.content.pageName=stateToPageNameArr[stateName].pageName;
							
								_satellite.track('trackPageView');
					}},100);
				}
			});
		}

	};
	//Setter created for dummyPageDataLayer to test using jasmine testcase
	this.setDummyPageDataLayer = function(value){
		dummyPageDataLayer=value;
	};
	
	this.callAnalyticsForErrorTracking=function(){
		if(typeof _satellite !== "undefined"){
			_satellite.track('errorTracking');
		}
	};
		
	this.postErrorTrackInfo = function(errType, errFields){
	if(typeof _satellite !== "undefined"){
		pageDataLayer.content.siteErrorType = errType;
		pageDataLayer.content.siteErrorFields = errFields;
		
		_satellite.track('errorTracking');
	}
	
	};
	
	this.postRecoveryTypeInfo = function(recoveryDetail,recoveryType){
		if(typeof _satellite !== "undefined"){
		pageDataLayer.content.recoveryType = recoveryDetail+":"+recoveryType;
		_satellite.track('recoveryTracking');
		pageDataLayer.content.recoveryType ="";
		}
	};
	
	this.postErrorPageInfo = function(errorCode){
			pageDataLayer.content.siteErrorCode = errorCode;
			var key=errorCode;
			if(errorCode.indexOf("OPT")>-1){
				key = errorCode.substring(4, 7);
			}
			if(errorCodeToErrInfo[key]){
				pageDataLayer.content.siteErrorType = errorCodeToErrInfo[key];
			}else{
				pageDataLayer.content.siteErrorType = "unexpected error";
			}
			
			if(typeof _satellite !== "undefined"){
			_satellite.track('errorTracking');
			}
			
			
	};
	
	this.globalAnalyticsObj = {};
	this.globalAnalyticsObj.errorTrackObj = {};
	this.globalAnalyticsObj.elemCount = 0;
	this.globalAnalyticsObj.postCallCount = 0;
}]);

LanguageService.$inject = ['$translatePartialLoader', '$translate'];
GeneralService.$inject = ['$http'];
ServiceResponseInterceptor.$inject = ['$q', '$injector', '$window'];



function LanguageService($translatePartialLoader, $translate) {
    this.doTranslate = function(part) {
        $translatePartialLoader.addPart(part);
        return $translate.refresh();
    };
}

function GeneralService($http) {
    this.getData = function(urlinfo) {
        return $http({ method: 'GET', url: urlinfo }).then(function (response) {
            return response.data;
        });
    };

    this.postData = function(urlinfo, data) {
        return $http.post(urlinfo, data);
    };
    
    this.getURLParameter= function(name){
	  var a = decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [null, ''])[1]) || null;
	  if(a===null){
	   a = decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.hash) || [null, ''])[1]) || null;
	  }
	  return a;
};
}

function textWithEmail() {
    return {
        restrict: 'E',
        transclude: true,
        link: function(scope, elem, attrs) {
            var msg = scope[attrs.message];
            var emailaddress = msg.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/gi);
            var retMsg = "";

            angular.forEach(emailaddress, function(value) {
                var replaceStr = '<a href=\"mailto:' + value + '\">' + value + '</a>';
                msg = msg.replace(value, replaceStr);
            });

            retMsg = '<p id=' + attrs.elemid + ' class=\"' + attrs.elemclass + '\">' + msg + '</p>';
            elem.html(retMsg);
        },
        template:'<p></p>' // dummy
    };
}

services.directive('title', ['$rootScope', '$timeout', function($rootScope, $timeout) {
    return {
        link: function() {
            var listener = function() {
                // TimeOut needed to allow loading of json files in browser before firing this event.
                $timeout(function() {
                    if (document.getElementsByTagName("h1")[0]) {
                        $rootScope.title = angular.element(document.getElementsByTagName("h1")[0]).text() + " - Optum ID";
                    } else {
                        $rootScope.title = "Optum ID";
                    }
                }, 1000);
            };
            $rootScope.$on('$viewContentLoaded', listener);
        }
    };
}]);

function ServiceResponseInterceptor($q, $injector, $window) {
    var ServiceResponseInterceptor = {
        // On response success
        response: function(response) {
            // Contains the data from the response.
            if (response.data.responseCode === '500') {
                $window.open('/tb/app/index.html#/errorPage?errorCode=' + response.data.errorResponse.errorCode + '&referenceCode=' + response.data.errorResponse.referenceCode + '', '_self');
            }

            // Return the response or promise.
            return response || $q.when(response);
        },

        responseError: function(response) {
            // Contains the data from the response.
            if (response.status === 500) {
                $window.open('/tb/app/index.html#/errorPage?errorCode=' + response.status + '&referenceCode=' + response.statusText + '', '_self');
            }

            // Return the response or promise.
            return $q.reject(response);
        }
    };
    return ServiceResponseInterceptor;
}

services.directive('supportAssistanceInfo', ['GeneralService', '$sce', function(GeneralService, $sce) {
    return {
        restrict: 'E',
        replace: true,
        template: '<div id="footerMsgId" class="tk-margin-top-1t"><p ng-bind-html="message"></p></div>',
        link: function(scope) {
            GeneralService.postData('/tb/services/rest/commonController/getErrorMessageWithSupportInfo', 'selfserviceSupportMsg').then(function (response) {
                scope.message = $sce.trustAsHtml(response.data.message);
            });
        }
    };
}]);

/**
 * Web analytics changes
 */
services.directive('pageDataLayerAttr', ['$timeout', 'AnalyticsService', function ($timeout, aService){
	return {
		restrict:'A',
        link: {
        	pre: function(scope, elem, attrs){
	        	var errorDetObj = {};
	        	errorDetObj.fieldName = attrs.pageDataLayerAttr;
	        	errorDetObj.errorElem = elem;
	        	aService.globalAnalyticsObj.errorTrackObj[attrs.pageDataLayerAttr] = errorDetObj;
	        	aService.globalAnalyticsObj.elemCount = aService.globalAnalyticsObj.elemCount+1;
	        	errorDetObj = null;
	        	//console.log("preLink --> "+attrs.pageDataLayerAttr);

	        },
	        post: function(scope, elem, attrs){
	        		$timeout(function(){
	        			aService.globalAnalyticsObj.postCallCount = aService.globalAnalyticsObj.postCallCount + 1;
	        			scope.trackError(aService.globalAnalyticsObj.postCallCount);
	        			//console.log("postLink -timeout-> "+attrs.pageDataLayerAttr);
	        		});
	        	    scope.$on("$destroy",
	                 function() {
	                    delete aService.globalAnalyticsObj.errorTrackObj[attrs.pageDataLayerAttr];
	                    aService.globalAnalyticsObj.elemCount = aService.globalAnalyticsObj.elemCount -1;
	                    //console.log("postLink - destroy-> "+attrs.pageDataLayerAttr);
	                    
	               }
	            );
	        	    //console.log("postLink --> "+attrs.pageDataLayerAttr);
	    	}
        }
    };

}]);
//============================================================================================================
//Directive for password field component======================================================================
//============================================================================================================
services.directive('passwordFieldValidation', function($timeout, trustbrokerAriaService, $rootScope, uitkLiveRegionService, $translate) {
	return {
		restrict: 'A',
		scope: {
			fieldName: '@',
			fieldLabel: '@',
			fieldModel: '=',
			trackError:'=',
			passwordRequiredErrorMessage: '@',
			passwordRequirementsFailedMessage: '@',
			version: '@'
		},
		templateUrl: function(element, attrs) {
			if (attrs.version === 'preLogin') {
				return './common/passwordFieldValidation.html';
			}
			else if (attrs.version === 'postLogin') {
				return './../common/passwordFieldValidation.html';
			}
			else if (attrs.version === 'smVersion') {
				return '/tb/app/common/passwordFieldValidation.html';
			}
		} ,
		link : function(scope) {
			var inputid = scope.fieldLabel+'Id_input';
			var spanid = scope.fieldLabel+'Id_err';
			var validationRules, previousRulesMet;
			//function for setting passwordField Form invalid after template has loaded
			$timeout(function() {
				scope.passwordFieldForm[scope.fieldName].$invalid = true;
				scope.passwordFieldForm[scope.fieldName].$valid = false;
				scope.passwordFieldForm.$valid = false;
				scope.passwordFieldForm.$invalid  = true;
				scope.constants = $rootScope.constants;
			});
			
			scope.passwordFieldValidation = function(modelValue) {
				validationRules = validators.passwordValidation(modelValue);
				previousRulesMet = scope.pwdRulesMet;
		        scope.pwdlengthValidation = validationRules.pwdlengthValidation;
		        scope.pwdUpperCaseValidation = validationRules.pwdUpperCaseValidation;
		        scope.pwdLowerCaseValidation = validationRules.pwdLowerCaseValidation;
		        scope.pwdSpaceValidation = validationRules.pwdSpaceValidation;
		        scope.pwdNumericValidation = validationRules.pwdNumericValidation;
		        scope.pwdRulesMet = validationRules.pwdRulesMet;
			};
			//function for validating password on key up strokes
			scope.passwordValidationOnKeyup = function() {
				scope.serverError = false;				//removing server error on user key up
				scope.passwordFieldValidation(scope.fieldModel);
		        // For WCAG
		        if (previousRulesMet !== scope.pwdRulesMet) {
		            if (scope.pwdRulesMet === 5) {
		                uitkLiveRegionService.alertMessage($translate.instant('PwdValidAlert'));
		            } else {
		                uitkLiveRegionService.alertMessage($translate.instant('PwdNotValidAlert') + scope.pwdRulesMet + $translate.instant('PwdNumberMetAlert'));
		            }
		        }
			};
			//function for validating password on blur event
			scope.passwordValidationOnBlur = function() {
				if (!scope.fieldModel) {
					scope.passwordFieldForm[scope.fieldName].$invalid = true;
					scope.passwordFieldForm[scope.fieldName].$valid = false;
					scope.passwordFieldForm.$valid = false;
					scope.passwordFieldForm.$invalid  = true;
					scope.passwordRequirementsFailed = false;
				}
				else if(scope.pwdRulesMet !== 5) {
					scope.passwordRequirementsFailed = true;
					scope.passwordFieldForm[scope.fieldName].$invalid = true;
					scope.passwordFieldForm[scope.fieldName].$valid = false;
					scope.passwordFieldForm.$valid = false;
					scope.passwordFieldForm.$invalid  = true;
				}
				else if (scope.fieldModel && scope.pwdRulesMet === 5) {
					scope.passwordRequirementsFailed = false;
					scope.passwordFieldForm[scope.fieldName].$invalid = false;
					scope.passwordFieldForm[scope.fieldName].$valid = true;
					scope.passwordFieldForm.$valid = true;
					scope.passwordFieldForm.$invalid  = false;
					
				}
				//emitting password value
				$rootScope.$emit('pwdValue', {value: scope.fieldModel});
				//emitting  password fields validating
				$rootScope.$emit('IsPasswordValid', {msg: scope.passwordFieldForm.$valid});
			};
			//function for WCAG (setting field validity)
			scope.setFieldValidity = function() {
		        $timeout(function() {
		            trustbrokerAriaService.setFieldValidity(inputid, spanid);
		        }, 300);
		    };
		    //function for watching if parent form is submitted
		    scope.$watch('passwordFieldForm.$$parentForm.$submitted', function(newValue) {
		    	if (newValue === true) {
		    		$rootScope.$emit('IsPasswordValid', {msg: scope.passwordFieldForm.$valid});
		    	}
		    });
		    //function for getting the error messages from server if there are any
		    $rootScope.$on('serverError', function(event, args) {
		    	scope.serverError = args.msg;
		    	//clearing the password requirements
		    	if (args.title === 'clearingField') {
		    		scope.passwordFieldValidation();
		    	}
		    	$timeout(function() {
		            trustbrokerAriaService.setFieldValidity(inputid, spanid);
		        }, 300);
		    });
		    //clearing out the tick marks besides all requirements
		    $rootScope.$on('formLevelSeverError', function() {
		    	scope.passwordFieldValidation();
		    });
		  //clearing out the tick marks besides all requirements
		    $rootScope.$on('formSuccessSaved', function() {
		    	scope.passwordFieldValidation();
		    });
		}
	};
});

services.factory('httpRequestInterceptor', function () {
  return {
    request: function (config) {
      config.headers['X-CSRF'] = "OID_TOKEN";
      return config;
    }
  };
});

