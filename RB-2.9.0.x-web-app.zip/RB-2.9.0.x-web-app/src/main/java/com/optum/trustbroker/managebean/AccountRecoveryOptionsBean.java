package com.optum.trustbroker.managebean;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.auditlogging.IDProofingAuditTypes;
import com.optum.trustbroker.auditlogging.IDProofingLoggingUtil;
import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.UuidUtil;
import com.optum.trustbroker.vo.AddressVO;
import com.optum.trustbroker.vo.AuthenticateChallengeQuestionServiceRequest;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.EnableUserServiceRequest;
import com.optum.trustbroker.vo.IDProofingQuizServiceRequest;
import com.optum.trustbroker.vo.IDProofingQuizServiceResponse;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.ResetUserRSAProfileRequest;
import com.optum.trustbroker.vo.ResetUserRSAProfileResponse;
import com.optum.trustbroker.vo.ServiceResponse;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserAuthorizationResponse;
import com.optum.trustbroker.vo.UserChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@ManagedBean(name = "accountrecoveryoptions")
@ViewScoped
public class AccountRecoveryOptionsBean extends AbstractBackingBean implements
		Serializable {

	private static final long serialVersionUID = 1L;

	BaseLogger logger = new BaseLogger(AccountRecoveryOptionsBean.class);
	
	@ManagedProperty(value = "#{mobileOtpBean}")
	private MobileOtpBean mobileOtpBean;
	
	private String errorMsg;
	private String successMsg;
	private String mobilePhone;
	private String sessionId;
	private String transactionId;
	private boolean disableButton;
	private boolean mobilePhoneVerified;
	private String wrongSecAnswerMsg;
	String mobileotp = "/views/mobileotp.jsf";
	String mobileotpw = "/views/mobileotpw.jsf";
	private boolean widgetView = false;
	String confirmationPage = "/views/forgotcredentialsconfirmationpage.xhtml?faces-redirect=true";
	String confirmationPagew = "/views/forgotcredentialsconfirmausernamew.xhtml?faces-redirect=true";
	@ManagedProperty(value = "#{userVO}")
	private UserVO userVO;
	private List<UserChallengeQuestionVO> userChallengeQuestions;
	private String primaryEmailMaskValue;
	private String secEmailMaskValue;
	private boolean rsaLock;
	private String localenv = "false";
	private boolean emailAddressPanel;
	private boolean hasTwoEmail;
	private List<SelectItem> emailList;
	private String email;
	private String emailChosenForLink;
	private String mobileOTPSentSuccessMsg;
	private String mobileUsrnameSentSuccessMsg;
	private String activeItem;
	private String secAnsWrongThreeTyms;
	private boolean secQuesPanel;
    private boolean noOptionsOtherThanSecQues;
    private String secQuesErrorMsg;
    private boolean isPhoneVerified;
    private String pageTitle;
	private String pageHeading;
	private String pageLevelMessage;
	private String securityPanelInfo;
	private String emailPanelInfo;
	private String singleEmailPanelInfo;

	public boolean isPhoneVerified() {
		return isPhoneVerified;
	}

	public void setPhoneVerified(boolean isPhoneVerified) {
		this.isPhoneVerified = isPhoneVerified;
	}

	public String getSecQuesErrorMsg() {
		return secQuesErrorMsg;
	}

	public void setSecQuesErrorMsg(String secQuesErrorMsg) {
		this.secQuesErrorMsg = secQuesErrorMsg;
	}

	public boolean isNoOptionsOtherThanSecQues() {
		return noOptionsOtherThanSecQues;
	}

	public void setNoOptionsOtherThanSecQues(boolean noOptionsOtherThanSecQues) {
		this.noOptionsOtherThanSecQues = noOptionsOtherThanSecQues;
	}

	public boolean isSecQuesPanel() {
		return secQuesPanel;
	}

	public void setSecQuesPanel(boolean secQuesPanel) {
		this.secQuesPanel = secQuesPanel;
	}

	public String getSecAnsWrongThreeTyms() {
		return secAnsWrongThreeTyms;
	}

	public void setSecAnsWrongThreeTyms(String secAnsWrongThreeTyms) {
		this.secAnsWrongThreeTyms = secAnsWrongThreeTyms;
	}

	public String getActiveItem() {
		
		return activeItem;
	}

	public void setActiveItem(String activeItem) {
		
		this.activeItem = activeItem;
	}

	public String getMobileOTPSentSuccessMsg() {
		return mobileOTPSentSuccessMsg;
	}

	public void setMobileOTPSentSuccessMsg(String mobileOTPSentSuccessMsg) {
		this.mobileOTPSentSuccessMsg = mobileOTPSentSuccessMsg;
	}

	public String getEmailChosenForLink() {
		return emailChosenForLink;
	}

	public void setEmailChosenForLink(String emailChosenForLink) {
		this.emailChosenForLink = emailChosenForLink;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<SelectItem> getEmailList() {
		return emailList;
	}

	public void setEmailList(List<SelectItem> emailList) {
		this.emailList = emailList;
	}

	public boolean isHasTwoEmail() {
		return hasTwoEmail;
	}

	public void setHasTwoEmail(boolean hasTwoEmail) {
		this.hasTwoEmail = hasTwoEmail;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getSuccessMsg() {
		return successMsg;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public boolean isDisableButton() {
		return disableButton;
	}

	public void setDisableButton(boolean disableButton) {
		this.disableButton = disableButton;
	}

	public boolean isMobilePhoneVerified() {
		return mobilePhoneVerified;
	}

	public void setMobilePhoneVerified(boolean mobilePhoneVerified) {
		this.mobilePhoneVerified = mobilePhoneVerified;
	}

	public String getWrongSecAnswerMsg() {
		return wrongSecAnswerMsg;
	}

	public void setWrongSecAnswerMsg(String wrongSecAnswerMsg) {
		this.wrongSecAnswerMsg = wrongSecAnswerMsg;
	}

	public List<UserChallengeQuestionVO> getUserChallengeQuestions() {
		return userChallengeQuestions;
	}

	public void setUserChallengeQuestions(
			List<UserChallengeQuestionVO> userChallengeQuestions) {
		this.userChallengeQuestions = userChallengeQuestions;
	}

	public String getPrimaryEmailMaskValue() {
		return primaryEmailMaskValue;
	}

	public void setPrimaryEmailMaskValue(String primaryEmailMaskValue) {
		this.primaryEmailMaskValue = primaryEmailMaskValue;
	}

	public String getSecEmailMaskValue() {
		return secEmailMaskValue;
	}

	public void setSecEmailMaskValue(String secEmailMaskValue) {
		this.secEmailMaskValue = secEmailMaskValue;
	}

	public boolean isRsaLock() {
		return rsaLock;
	}

	public void setRsaLock(boolean rsaLock) {
		this.rsaLock = rsaLock;
	}

	
	public String getLocalenv() {
		return localenv;
	}

	public void setLocalenv(String localenv) {
		this.localenv = localenv;
	}
	
	
	
	@PostConstruct
	public void init() {
		@SuppressWarnings("unchecked")
		Map<String, String> userDetails = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		try {
			userVO = container
					.getUserService()
					.fetchUserProfile(
							(userDetails
									.get(TrustBrokerWebAppConstants.USER_NAME)),
							false, true).getUser();
			userDetails.put("emailId", userVO.getEmailAddress());
			userDetails.put("uuId", userVO.getUuId());
			
			if(StringUtils.isNotBlank(getUserVO().getPhoneNumber()) && getUserVO()
					.getIsPhoneVerified()){
				
				setPhoneVerified(true);
				
			}else{
				
				setPhoneVerified(false);
			}

			if (StringUtils.isNotBlank(userVO.getPhoneNumber())) {
				setMobilePhone(TBUtil.phoneMask(userVO.getPhoneNumber()));
				setMobilePhoneVerified(userVO.getIsPhoneVerified());
			}
			if (StringUtils.isNotBlank(userVO.getEmailAddress()))
				setPrimaryEmailMaskValue(TBUtil.emailMask(userVO
						.getEmailAddress()));
			if (StringUtils.isNotBlank(userVO.getSecEmailAddress()))
				setSecEmailMaskValue(TBUtil.emailMask(userVO
						.getSecEmailAddress()));

			if (!userVO.getAaStatus().equalsIgnoreCase(
					TrustBrokerConstants.AA_LOCK_STATUS)) {
				retrieveChallengeQuestionsofUser();
			}

			if ((StringUtils.isNotBlank(getUserVO().getEmailAddress())
					&& getUserVO().isIsemailVerified() && getUserVO()
					.isPrimaryEmailUnique())
					|| (StringUtils
							.isNotBlank(getUserVO().getSecEmailAddress())
							&& getUserVO().isSecEmailVerified() && getUserVO()
							.isSecEmailUnique())
					|| (null != getUserChallengeQuestions())
					|| (StringUtils.isNotBlank(getUserVO().getPhoneNumber()) && getUserVO()
							.getIsPhoneVerified()))
				;
			else
				redirectToView("/views/accountrecoverynotverified.jsf");
		} catch (Exception e) {
		}
		setNoOptionsOtherThanSecQues(false);
		setSecQuesPanel(false);
		if ((null != getUserChallengeQuestions())) {
			setSecQuesPanel(true);
			setActiveItem("secQues");
			if (!(StringUtils.isNotBlank(getUserVO().getEmailAddress())
					&& getUserVO().isIsemailVerified() && getUserVO()
					.isPrimaryEmailUnique())
					&& !(StringUtils.isNotBlank(getUserVO()
							.getSecEmailAddress())
							&& getUserVO().isSecEmailVerified() && getUserVO()
							.isSecEmailUnique())

					&& !(StringUtils.isNotBlank(getUserVO().getPhoneNumber()) && getUserVO()
							.getIsPhoneVerified())) {

				setNoOptionsOtherThanSecQues(true);
			}
		} else if ((StringUtils.isNotBlank(getUserVO().getEmailAddress())
				&& getUserVO().isIsemailVerified() && getUserVO()
				.isPrimaryEmailUnique())
				|| (StringUtils.isNotBlank(getUserVO().getSecEmailAddress())
						&& getUserVO().isSecEmailVerified() && getUserVO()
						.isSecEmailUnique())) {
			setActiveItem("email");

		} else if ((StringUtils.isNotBlank(getUserVO().getPhoneNumber()) && getUserVO()
				.getIsPhoneVerified())) {
			setActiveItem("mobile");

		}
		
		if ((StringUtils.isNotBlank(getUserVO().getEmailAddress())
				&& getUserVO().isIsemailVerified() && getUserVO()
				.isPrimaryEmailUnique())
				|| (StringUtils.isNotBlank(getUserVO().getSecEmailAddress())
						&& getUserVO().isSecEmailVerified() && getUserVO()
						.isSecEmailUnique())) {
			emailAddressPanel = true;
			if ((StringUtils.isNotBlank(getUserVO().getEmailAddress())
					&& getUserVO().isIsemailVerified() && getUserVO()
					.isPrimaryEmailUnique())
					&& (StringUtils
							.isNotBlank(getUserVO().getSecEmailAddress())
							&& getUserVO().isSecEmailVerified() && getUserVO()
							.isSecEmailUnique())) {
				hasTwoEmail = true;
				emailList = new ArrayList<SelectItem>();
				setEmail(getUserVO().getEmailAddress());
				emailList.add(new SelectItem(getUserVO().getEmailAddress(), getPrimaryEmailMaskValue()));
				emailList.add(new SelectItem(getUserVO().getSecEmailAddress(), getSecEmailMaskValue()));

			} else {
				hasTwoEmail = false;
			}
		} else {
			emailAddressPanel = false;
		}
		
		String recoveryType = (String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
		
		if("forgotUserNameFlow".equalsIgnoreCase(recoveryType)) {
			setPageTitle(tbResources.getString("forgotUserNamePageTitle"));
			setPageHeading(tbResources.getString("recoverUsername"));
			setPageLevelMessage(tbResources.getString("forgotUsernameUnderText"));
			setSecurityPanelInfo(tbResources.getString("secQuesMsgForgotUsername"));
			setEmailPanelInfo(tbResources.getString("emailPanelInfoForUsername"));
			setSingleEmailPanelInfo(tbResources.getString("singleEmailInforUsername"));
		}
		else if("forgotPwdFlow".equalsIgnoreCase(recoveryType)) {
			setPageTitle(tbResources.getString("forgotPasswordPageTitle"));
			setPageHeading(tbResources.getString("recoverPassword"));
			setPageLevelMessage(tbResources.getString("forgotPasswordUnderText"));
			setSecurityPanelInfo(tbResources.getString("secQuesMsg"));
			setEmailPanelInfo(tbResources.getString("emailPanelInfoForPwdAndUnlock"));
			setSingleEmailPanelInfo(tbResources.getString("singleEmailPanelInfoPwdUnlock"));
		}
		else if("unlockUserAccount".equalsIgnoreCase(recoveryType)) {
			setPageTitle(tbResources.getString("unlockAccountPageTitle"));
			setPageHeading(tbResources.getString("unlockUserAccount"));
			setPageLevelMessage(tbResources.getString("unlockAccountUnderText"));
			setSecurityPanelInfo(tbResources.getString("secQuesMsgUnlockAccount"));
			setEmailPanelInfo(tbResources.getString("emailPanelInfoForPwdAndUnlock"));
			setSingleEmailPanelInfo(tbResources.getString("singleEmailPanelInfoPwdUnlock"));
		}
		else if("onlineSecurityFlow".equalsIgnoreCase(recoveryType)) {
			setPageTitle(tbResources.getString("setSecurityQuestionsPageTitle"));
			setPageHeading(tbResources.getString("onlineSecurity"));
			setPageLevelMessage(tbResources.getString("createSecurityQuestionsUnderText"));
			setEmailPanelInfo(tbResources.getString("emailPanelInfoForSetSec"));
			setSingleEmailPanelInfo(tbResources.getString("singleEmailInforSetSec"));
		}
		


        if (TBUtil.isLocalEnv()) {
			localenv = "true";
		}
	}
	
	public void expandNextPanel(){
		if(emailAddressPanel){
			setActiveItem("email");
		}else if (!emailAddressPanel&&isPhoneVerified) {
			setActiveItem("mobile");
		}
	}

	public void continueEmail() {
		
		if (email.equals(getUserVO().getEmailAddress())) {
			sendToPrimaryEmail();
		}
		if (email.equals(getUserVO().getSecEmailAddress())) {
			sendToSecEmail();
		}

	}

	public void sendToPrimaryEmail() {
		
		this.activeItem ="email";
		
		String recoveryType = (String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);

		if (recoveryType.equals("lostAccessToRecovery")) {
			recoveryType = (String) getSessionAttribute("SELF_ACC_RECOVER_TYPE");
		}

		setErrorMsg("");
		setWrongSecAnswerMsg("");
		String rpAppId = getRelyingPartyAppId();
		if (TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK.equalsIgnoreCase(recoveryType)) {
			try {
				setEmailChosenForLink(getPrimaryEmailMaskValue());
					// Sending the authorization link to user's primary email
					getContainer().getUserService().sendAuthCodeToUser( generateAuthorizationRequest(userVO), TrustBrokerConstants.ACCOUNT_RECOVERY, 
							rpAppId, true, getUrlLogoOptumId(), getUrlLogoRelyingParty());
					setSuccessMsg(tbResources.getString("unlockEmailSuccessMsgUnlockAccount"));
					setDisableButton(true);
					return;
			} catch (OperationFailedException ofe) {
				setErrorMsg(tbResources.getString("accRecoveryErrorMsg"));
				logger.error("Error account recovery options bean for primary email address: ", ofe);
				return;
			}
		}
		
		if (TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW.equalsIgnoreCase(recoveryType)) {
			setEmailChosenForLink(getPrimaryEmailMaskValue());
			getContainer().getUserService().sendForgotUserNameMessage( getUserVO(), CommunicationChannel.PRIMARY_EMAIL, rpAppId, 
					getUrlLogoOptumId(), getUrlLogoRelyingParty());
			setSuccessMsg(tbResources.getString("unlockEmailSuccessMsgForgotUserName"));
			setDisableButton(true);
		} else {
			if (TrustBrokerWebAppConstants.FORGOT_PWD_FLOW
					.equalsIgnoreCase(recoveryType)) {
				//setEmailChosenForLink(userVO.getEmailAddress());
				setEmailChosenForLink(getPrimaryEmailMaskValue());
				getContainer().getUserService().sendAuthCodeToUser( generateAuthorizationRequest(userVO), TrustBrokerConstants.ACCOUNT_RECOVERY, 
						rpAppId, true, getUrlLogoOptumId(), getUrlLogoRelyingParty());
				
				setSuccessMsg(tbResources.getString("unlckEmailSuccessMsg"));
				setDisableButton(true);
			} else if (TrustBrokerWebAppConstants.ONLINE_SECURITY_FLOW
					.equalsIgnoreCase(recoveryType)) {
				SecurityLoggingUtil.info("SQA Missing ", SecurityEventType.E3_CREATE, getServletRequest(), userVO.getUserName(),
								"Security Audit Event|SQA Missing authorization code :SUCCESS|Authorization Code sent to User, LoginBean:init()",
								SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_CREATE_AUTH_CODE);
				getContainer().getUserService().sendAuthCodeToUser(
						generateAuthorizationRequest(userVO),
						TrustBrokerConstants.SQA, rpAppId, true,
						getUrlLogoOptumId(), getUrlLogoRelyingParty());
				
				setEmailChosenForLink(getPrimaryEmailMaskValue());
				
				setSuccessMsg(tbResources.getString("unlockEmailSuccessMsgSetSecurityQues"));
				setDisableButton(true);
			}

			
		}
	}

	public void sendToSecEmail() {
		
		setActiveItem("email");
		String recoveryType = (String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
		if (recoveryType.equals("lostAccessToRecovery")) {
			recoveryType = (String) getSessionAttribute("SELF_ACC_RECOVER_TYPE");
		}
		setErrorMsg("");
		setWrongSecAnswerMsg("");
		String rpAppId = getRelyingPartyAppId();
		
		if (TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK.equalsIgnoreCase(recoveryType)) {
			try {
					// Sending the authorization link to user's secondary email
					getContainer().getUserService().sendAuthCodeToUser(generateAuthorizationRequest(userVO), 
							TrustBrokerConstants.ACCOUNT_RECOVERY, rpAppId, false, getUrlLogoOptumId(), getUrlLogoRelyingParty());
					setEmailChosenForLink(getSecEmailMaskValue());
					setSuccessMsg(tbResources.getString("unlockEmailSuccessMsgUnlockAccount"));
					setDisableButton(true);
					return;
			} catch (OperationFailedException ofe) {
				setErrorMsg(tbResources.getString("accRecoveryErrorMsg"));
				logger.error("Error account recovery options bean for secondary email address: ", ofe);
				return;
			}
		}
		
		if (TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW.equalsIgnoreCase(recoveryType)) {
			setEmailChosenForLink(getSecEmailMaskValue());
			logger.debug("sending forgot username secondary email. getUrlLogoOptumId(): "+getUrlLogoOptumId()+" getUrlLogoRelyingParty() "+getUrlLogoRelyingParty());
			getContainer().getUserService().sendForgotUserNameMessage(
					getUserVO(), CommunicationChannel.SECONDARY_EMAIL, rpAppId,
					getUrlLogoOptumId(), getUrlLogoRelyingParty());
			setSuccessMsg(tbResources.getString("unlockEmailSuccessMsgForgotUserName"));
			setDisableButton(true);
		} else {
			
			if (TrustBrokerWebAppConstants.FORGOT_PWD_FLOW.equalsIgnoreCase(recoveryType)) {
				//setEmailChosenForLink(userVO.getSecEmailAddress());
				setEmailChosenForLink(getSecEmailMaskValue());
				getContainer().getUserService().sendAuthCodeToUser(generateAuthorizationRequest(userVO),
						TrustBrokerConstants.ACCOUNT_RECOVERY, rpAppId, false, getUrlLogoOptumId(), getUrlLogoRelyingParty());
				
				setSuccessMsg(tbResources.getString("unlckEmailSuccessMsg"));
				setDisableButton(true);
				
				
			} else if (TrustBrokerWebAppConstants.ONLINE_SECURITY_FLOW.equalsIgnoreCase(recoveryType)) {
				getContainer().getUserService().sendAuthCodeToUser(
						generateAuthorizationRequest(userVO), TrustBrokerConstants.SQA, rpAppId, false,
						getUrlLogoOptumId(), getUrlLogoRelyingParty());
				
				setEmailChosenForLink(getSecEmailMaskValue());
				setSuccessMsg(tbResources.getString("unlockEmailSuccessMsgSetSecurityQues"));
				setDisableButton(true);
			}
			
		}
	}

	public void sendToMobilew() {
		widgetView = true;
		sendToMobile();
	}

	public void sendToMobile() {
		
		setActiveItem("mobile");
		String recoveryType = (String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
		setMobileOTPSentSuccessMsg("");
		setSuccessMsg("");
		if (recoveryType.equals("lostAccessToRecovery")) {
			recoveryType = (String) getSessionAttribute("SELF_ACC_RECOVER_TYPE");
		}
		setErrorMsg("");
		setWrongSecAnswerMsg("");
		
		if (TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK.equalsIgnoreCase(recoveryType)) {
			
			try {
				UserAuthorizationResponse response = getContainer().getUserService().generateAuthCodeToUser(
								getUserVO().getUuId(), TrustBrokerConstants.SMSOTP);
				getContainer().getSecureMessagingService().sendText(
						userVO.getPhoneNumber(), "Optum ID One-Time Access Code:" + response.getUserAuthCode());
				setMobileOTPSentSuccessMsg(tbResources.getString("mobilePhoneSuccessMsg"));
				setDisableButton(true);
				if (widgetView) 
					redirectToView(mobileotpw);
			} catch (OperationFailedException ofe) {
				setErrorMsg(tbResources.getString("accRecoveryErrorMsg"));
				logger.error("Error account recovery options bean for mobile number: ", ofe);
			}
		}

		 else if (TrustBrokerWebAppConstants.FORGOT_PWD_FLOW.equalsIgnoreCase(recoveryType) || 
				 TrustBrokerWebAppConstants.ONLINE_SECURITY_FLOW.equalsIgnoreCase(recoveryType)  || 
				 TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW.equalsIgnoreCase(recoveryType)) {
			try {
				
				if(TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW.equalsIgnoreCase(recoveryType)){
					getContainer().getSecureMessagingService().sendText(
							userVO.getPhoneNumber(), "Optum ID: " + getUserVO().getUserName());
					setMobileUsrnameSentSuccessMsg(tbResources.getString("mobilePhoneUserNameSuccessMsg"));
					// Below success message is for IFrame
					setSuccessMsg(tbResources.getString("mobilePhoneUserNameSuccessMsg"));
				} else{
					UserAuthorizationResponse response = getContainer()
							.getUserService().generateAuthCodeToUser(getUserVO().getUuId(), TrustBrokerConstants.SMSOTP);
					getContainer().getSecureMessagingService().sendText(
							userVO.getPhoneNumber(), "Optum ID One-Time Access Code:" + response.getUserAuthCode());
					setMobileOTPSentSuccessMsg(tbResources.getString("mobilePhoneSuccessMsg"));
					if (widgetView) 
						redirectToView(mobileotpw);
				}
				
				setDisableButton(true);
			} catch (Exception e) {
				setErrorMsg("An unexpected error has occurred, please try again.");
				logger.error("Error in account recovery options bean for mobile number in forgot password flow: ", e);
			}
			setDisableButton(true);
		}
	}

	public String validateSecQuestionsw() {
		widgetView = true;
		return validateSecQuestions();
	}

	public void validateSecurityQuestions(FacesContext context, UIComponent component, Object value) {   
	    if ( value.toString().equals(null)||value.toString().equals("")) {   
	    	setSecQuesErrorMsg("Security Answer is required");
	    }   
	}  
	public String validateSecQuestions() {
		setSecAnsWrongThreeTyms("");
		setActiveItem("secQues");
		if(!validateAnswers()) {
			setWrongSecAnswerMsg(tbResources.getString("secQueAndAnsReq"));
			return null;
		}		
		String recoveryType = (String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
		if (recoveryType.equals("lostAccessToRecovery")) {
			recoveryType = (String) getSessionAttribute("SELF_ACC_RECOVER_TYPE");
		}
		setErrorMsg("");
		setWrongSecAnswerMsg("");
		try {
			AuthenticateChallengeQuestionServiceRequest request = new AuthenticateChallengeQuestionServiceRequest();
			request.setSessionId(getSessionId());
			request.setTransactionId(getTransactionId());
			request.setUserChallengeQuestions(getUserChallengeQuestions());
			request.setUuid(getUserVO().getUuId());
			request.setNoOfQuestions(TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);

			String authChallengeResp = getContainer().getUserService()
					.authenticateChallengeQuestion(request);

			if (TrustBrokerConstants.SUCCESS_CODE_VALUE
					.equalsIgnoreCase(authChallengeResp)) {
				if (TrustBrokerWebAppConstants.FORGOT_USERNAME_FLOW
						.equalsIgnoreCase(recoveryType)) {
					addSessionAttribute(TrustBrokerWebAppConstants.USER_NAME,
							userVO.getUserName());
					if (widgetView)
						return confirmationPagew;
					else
						return confirmationPage;
				}
				if (widgetView)
					return "/views/resetpasswordw.xhtml?faces-redirect=true";
				else
					return "/views/resetpassword.xhtml?faces-redirect=true";

			} else if (TrustBrokerConstants.FAILURE_CODE_VALUE
					.equalsIgnoreCase(authChallengeResp)) {
				retrieveChallengeQuestionsofUser();
				setWrongSecAnswerMsg(tbResources
						.getString("secAnswerIncorrect"));
			}
		} catch (OperationFailedException ofe) {
			if (ofe.getCause() instanceof OperationFailedException) {
				OperationFailedException dd = (OperationFailedException) ofe
						.getCause();
				Map<String, String> errorMessages = dd.getErrorMessages();
				if (null != errorMessages
						&& TrustBrokerConstants.AA_LOCK_STATUS
								.equalsIgnoreCase(errorMessages
										.get(TrustBrokerConstants.AA_STATUS))) {
					SupportContactInfoVO sci = getSupportContactInfo();
					Object[] msgArguments = { sci.getContactComboText() };
					// setErrorMsg(TBUtil.formatMessage(
					// tbResources.getString("lockWithIncorrectAns"),
					// msgArguments));
					if (!noOptionsOtherThanSecQues) {
						setSecAnsWrongThreeTyms(TBUtil.formatMessage(
								tbResources
										.getString("lockWithIncorrectAns"),
								msgArguments));
						return null;
					} else {

						setSecAnsWrongThreeTyms(TBUtil
								.formatMessage(tbResources
										.getString("lockWithIncorrectAnsLcked"),
										msgArguments));
						

					}
					setRsaLock(true);
					setUserChallengeQuestions(null);
				if ((StringUtils.isNotBlank(getUserVO().getEmailAddress())
							&& getUserVO().isIsemailVerified() && getUserVO()
							.isPrimaryEmailUnique())
							|| (StringUtils.isNotBlank(getUserVO()
									.getSecEmailAddress())
									&& getUserVO().isSecEmailVerified() && getUserVO()
									.isSecEmailUnique())
							|| (StringUtils.isNotBlank(userVO.getPhoneNumber())))
						;
					else
						//redirectToView("/views/accountrecoverynotverified.jsf");
						setSecAnsWrongThreeTyms(TBUtil
								.formatMessage(tbResources
										.getString("lockWithIncorrectAnsLcked"),
										msgArguments));
				}
			}
			logger.error(
					"Error account recovery options bean while validating security questions: ",
					ofe);
		}
		return null;
		
	}
	
	private boolean validateAnswers() {
		boolean answersValid = true;
		List<UserChallengeQuestionVO> userQuestions = getUserChallengeQuestions();
		if(userQuestions != null) {
			UserChallengeQuestionVO userQuestion = null;
			for(int i=0; i < userQuestions.size(); i++) {
				userQuestion = userQuestions.get(i);
				if(StringUtils.isEmpty(userQuestion.getAnswer())) {
					addFacesMessage("forgotPasswordSecQues:Answer_"+(i+1), tbResources.getString("secAnswerRequired"));
					answersValid = false;
				}
			}
		}
		return answersValid;
	}
	
	public void sendAnotherOTP() {	
		setSecAnsWrongThreeTyms("");
		setErrorMsg("");
		setWrongSecAnswerMsg("");
		setActiveItem("mobile");
		getMobileOtpBean().sendAnotherOTP();
	}
	
	public void confirmOTP() {
		try {
			setSecAnsWrongThreeTyms("");
			setErrorMsg("");
			setWrongSecAnswerMsg("");
			setActiveItem("mobile");
			getMobileOtpBean().confirmOTP();
		} catch (IOException e) {
			logger.error(
					"Error confirming OTP to mobile: ",
					e);
		}
	}
	
	private void addFacesMessage(String fieldId, String message) {       
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	public boolean isEmailAddressPanel() {
		return emailAddressPanel;
	}

	public void setEmailAddressPanel(boolean emailAddressPanel) {
		this.emailAddressPanel = emailAddressPanel;
	}

	private boolean unlockUser() {
		EnableUserServiceRequest enableUserServiceRequest = new EnableUserServiceRequest();
		enableUserServiceRequest.setUser(userVO);
		ServiceResponse serviceResponse;
		if (TrustBrokerConstants.PWD_DISABLED.equalsIgnoreCase(userVO
				.getPwdStatus())) {
			logger.debug("Unlocking the user at LDAP");
			// Unlocking the user at LDAP
			enableUserServiceRequest.setPasswordEnable(false);
			serviceResponse = container.getCredentialService().enableUser(
					enableUserServiceRequest);
			if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(serviceResponse
					.getExecutionStatus().getStatusCd())) {
				errorMsg = "Failed to unlock user account";
				return false;
			}
			SecurityLoggingUtil
					.info("Unlock Account",
							SecurityEventType.E3_ENABLE,
							getServletRequest(),
							getUserVO().getUserName(),
							"Security Audit Event|LDAP Unlock:Success, AccountRecoveryOptionsBean:unlockUser()",
							SecurityEventResult.SUCCESS,
							getRelyingPartyAppId(),
							SecuritySubEventType.E3_ENABLE_LDAP);
		}

		if (TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(userVO
				.getAaStatus()) || isRsaLock()) {
			// Resetting the user's RSA profile.
			logger.debug("Resetting RSA profile for user {}",
					userVO.getUserName());
			ResetUserRSAProfileRequest request = new ResetUserRSAProfileRequest();
			request.setUser(userVO);
			ResetUserRSAProfileResponse response = container.getUserService()
					.resetUserRSAProfile(request);

			if (!TrustbrokerWebAppUtil.checkResponseStatus(response)) {
				errorMsg = "Failed to unlock user account";
				return false;
			}
			SecurityLoggingUtil
					.info("Unlock Account",
							SecurityEventType.E3_ENABLE,
							getServletRequest(),
							getUserVO().getUserName(),
							"Security Audit Event|RSA Unlock:Success, AccountRecoveryOptionsBean:unlockUser()",
							SecurityEventResult.SUCCESS,
							getRelyingPartyAppId(),
							SecuritySubEventType.E3_ENABLE_RSA);
		}
		return true;
	}

	private void retrieveChallengeQuestionsofUser() {
		try {
			UserChallengeQuestionServiceResponse userChallengeResp = getContainer()
					.getUserService()
					.getChallengeQuestions(
							userVO.getUuId(),
							TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
			if (null != userChallengeResp
					&& null != userChallengeResp.getUserChallengeQuestions()
					&& userChallengeResp.getUserChallengeQuestions().size() > 0) {
				setUserChallengeQuestions(userChallengeResp
						.getUserChallengeQuestions());
			}
			setSessionId(userChallengeResp.getSessionId());
			setTransactionId(userChallengeResp.getTransactionId());
		} catch (OperationFailedException ofe) {
		}
	}

	public String lostAccessTRecoveryMethods() {
		addSessionAttribute(
				TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE,
				TrustBrokerWebAppConstants.LOST_ACCESS_TO_RECOVERY);
		UserRetrievalServiceResponse userRetrievalServiceResponse;

		@SuppressWarnings("unchecked")
		Map<String, String> userDetails = (HashMap<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_UUID,
				userDetails.get("uuId"));
		setSuccessMsg("");
		setErrorMsg("");
		setWrongSecAnswerMsg("");
		try {
			userRetrievalServiceResponse = getContainer()
					.getUserService()
					.fetchUserProfile(
							userDetails
									.get(TrustBrokerWebAppConstants.USER_NAME),
							false, false);
		} catch (OperationFailedException ope) {
			logger.error(
					"Exception during lost access to recovery methods: {}",
					new String[] {
							userDetails
									.get(TrustBrokerWebAppConstants.USER_NAME),
							TrustbrokerWebAppUtil.getUidFromError(ope) }, ope);
			if (null != ope.getErrorMessage())
				setErrorMsg(ope.getErrorMessage().getEndUserMessage(
						container.getErrorMessageSource(),
						getSupportContactInfo()));
			return null;
		}
		if (null != userRetrievalServiceResponse) {
			UserVO userVO = userRetrievalServiceResponse.getUser();
			logger.debug(userVO.getUserName() + " exists at eSSO side");
			SupportContactInfoVO sci = getSupportContactInfo();
			try {
				IDProofingQuizServiceRequest idProofingQuizServiceRequest = new IDProofingQuizServiceRequest();
				if (checkUserDataForIDProofing(userVO)) {
					return null;
				}
				idProofingQuizServiceRequest.setUser(userVO);
				idProofingQuizServiceRequest.setVerificationFlow(getContainer()
						.getConfigProps().getProperty(
								"basic_idp_verification_flow"));
				IDProofingQuizServiceResponse idProofingQuizServiceResponse = getContainer()
						.getIdProofingService().generateQuiz(
								idProofingQuizServiceRequest);
				String executionStatusCd = idProofingQuizServiceResponse
						.getExecutionStatus().getStatusCd();
				logger.debug("executionStatusCd code after generateQuiz call: "
						+ executionStatusCd);

				boolean failed = false;
				if (TrustBrokerConstants.SYSTEM_ERROR_CODE_VALUE
						.equals(executionStatusCd)) {
					String uid = UuidUtil.generateUid();
					logger.error(
							"System Error: {}, while generating basic id quiz for user : {} ",
							new String[] {
									idProofingQuizServiceResponse
											.getExecutionStatus()
											.getStatusMessage(),
									userVO.getUserName(), uid });
					Object[] msgArguments = { sci.getContactComboText(), uid };
					setErrorMsg(TBUtil.formatMessage(
							tbResources.getString("systemError"), msgArguments));
					failed = true;
				}
				if (TrustBrokerConstants.BAD_REQUEST_CODE_VALUE
						.equals(executionStatusCd)) {
					logger.error("Bad Request error: "
							+ idProofingQuizServiceResponse
									.getExecutionStatus().getStatusMessage());
					failed = true;
				}
				if (TrustBrokerConstants.FAILURE_CODE_VALUE
						.equals(executionStatusCd)) {
					logger.error("Failure error: "
							+ idProofingQuizServiceResponse
									.getExecutionStatus().getStatusMessage());
					failed = true;
					Object[] msgArguments = { sci.getContactComboText() };
					setErrorMsg(TBUtil.formatMessage(
							tbResources.getString("verifyIDInvalidAccount"),
							msgArguments));
				}

				IDProofingAuditTypes auditType = failed ? IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_FAIL
						: IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_SUCCESS;
				IDProofingLoggingUtil.info(auditType, getRelyingPartyAppId(),
						userVO.getUserName(),
						getErrorReasonCode(idProofingQuizServiceResponse
								.getExecutionStatus()),
						"ForgotCredentialsBean:lostAccessToEmail()",
						getServletRequest());

				if (failed) {
					return null;
				}

				addSessionAttribute(
						TrustBrokerWebAppConstants.ID_PROOFING_QUIZ,
						idProofingQuizServiceResponse.getIdProofingQuizVO());
				return "/views/knowledgeBasedIdentification.xhtml?faces-redirect=true";
			} catch (OperationFailedException ope) {
				logger.error(
						"Exception while getting idproofing questions for user: {}",
						new String[] { userVO.getUserName(),
								TrustbrokerWebAppUtil.getUidFromError(ope) },
						ope);
				if (null != ope.getErrorMessage())
					setErrorMsg(ope.getErrorMessage().getEndUserMessage(
							container.getErrorMessageSource(), sci));
				return null;
			} catch (Exception e) {
				String uid = UuidUtil.generateUid();
				logger.error(
						"Error occured while generating questions using ID Proofing services for user {}",
						new String[] { userVO.getUserName(), uid }, e);
				Object[] msgArguments = { sci.getContactComboText(), uid };
				setErrorMsg(TBUtil.formatMessage(
						tbResources.getString("systemError"), msgArguments));
				return null;
			}
		}
		return null;
	}

	private boolean checkUserDataForIDProofing(UserVO userVO) {

		List<String> missingData = new ArrayList<String>();
		if (StringUtils.isEmpty(userVO.getFirstName()))
			missingData.add("First Name");
		if (StringUtils.isEmpty(userVO.getLastName()))
			missingData.add("Last Name");
		if (null == userVO.getDob())
			missingData.add("Date of Birth");

		if (userVO.getAddresses() != null && userVO.getAddresses().size() > 0) {
			logger.debug("user address is not null");
			AddressVO addressVO = userVO.getAddresses().get(0);
			if (StringUtils.isEmpty(addressVO.getStreetAddress()))
				missingData.add("Street Address");
			if (StringUtils.isEmpty(addressVO.getCity()))
				missingData.add("City");
			if (StringUtils.isEmpty(addressVO.getZip()))
				missingData.add("Zip");
			if (StringUtils.isEmpty(addressVO.getState()))
				missingData.add("State");
		} else
			missingData.add("Home Address");
		StringBuilder message = new StringBuilder();
		for (int i = 0; i < missingData.size() - 1; i++) {
			if (i == missingData.size() - 2)
				message.append(missingData.get(i) + " and ");
			else
				message.append(missingData.get(i) + ", ");
		}

		if (missingData.size() > 0)
			message.append(missingData.get(missingData.size() - 1));

		SupportContactInfoVO sci = getSupportContactInfo();
		if (null != userVO.getDob()
				&& !DateUtil.validateDate(DateUtil.formatDate(userVO.getDob(),
						"MM/dd/yyyy"))) {
			if (StringUtils.isNotEmpty(message.toString())) {
				message.append(", Invalid Date of Birth");
				Object[] msgArguments = { sci.getContactComboText(),
						message.toString() };
				setErrorMsg(TBUtil.formatMessage(tbResources
						.getString("selfServiceMissingDataMsgForIDP"),
						msgArguments));
			} else {
				message.append("Invalid Date of Birth");
				Object[] msgArguments = { sci.getContactComboText(),
						message.toString() };
				setErrorMsg(TBUtil.formatMessage(tbResources
						.getString("selfServiceMissingDataMsgForIDP"),
						msgArguments));
			}
		} else {
			Object[] msgArguments = { sci.getContactComboText(),
					message.toString() };
			setErrorMsg(TBUtil.formatMessage(
					tbResources.getString("selfServiceMissingDataMsgForIDP"),
					msgArguments));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("checkUserDataForIDProofing() - " + message
					+ " data is missing from " + userVO.getUserName());
		}
		if (StringUtils.isNotEmpty(message.toString()))
			return true;
		else
			return false;
	}

	public String getMobileUsrnameSentSuccessMsg() {
		return mobileUsrnameSentSuccessMsg;
	}

	public void setMobileUsrnameSentSuccessMsg(String mobileUsrnameSentSuccessMsg) {
		this.mobileUsrnameSentSuccessMsg = mobileUsrnameSentSuccessMsg;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public String getPageHeading() {
		return pageHeading;
	}

	public void setPageHeading(String pageHeading) {
		this.pageHeading = pageHeading;
	}

	public String getPageLevelMessage() {
		return pageLevelMessage;
	}

	public void setPageLevelMessage(String pageLevelMessage) {
		this.pageLevelMessage = pageLevelMessage;
	}

	public String getSecurityPanelInfo() {
		return securityPanelInfo;
	}

	public void setSecurityPanelInfo(String securityPanelInfo) {
		this.securityPanelInfo = securityPanelInfo;
	}

	public String getEmailPanelInfo() {
		return emailPanelInfo;
	}

	public void setEmailPanelInfo(String emailPanelInfo) {
		this.emailPanelInfo = emailPanelInfo;
	}

	public String getSingleEmailPanelInfo() {
		return singleEmailPanelInfo;
	}

	public void setSingleEmailPanelInfo(String singleEmailPanelInfo) {
		this.singleEmailPanelInfo = singleEmailPanelInfo;
	}

	public MobileOtpBean getMobileOtpBean() {
		return mobileOtpBean;
	}

	public void setMobileOtpBean(MobileOtpBean mobileOtpBean) {
		this.mobileOtpBean = mobileOtpBean;
	}
	

}