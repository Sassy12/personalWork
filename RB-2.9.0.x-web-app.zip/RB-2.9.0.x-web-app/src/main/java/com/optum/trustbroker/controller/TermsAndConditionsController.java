package com.optum.trustbroker.controller;

import java.util.Locale;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.controller.vo.TermsAndConditionsVO;
import com.optum.trustbroker.service.ReferenceService;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.TermsAndConditionsRetrievalServiceResponse;

@Service
@Path(TBConstants.TERMS_CONDITIONS_CONTROLLER_PATH)
public class TermsAndConditionsController extends BaseController {
	
	@Autowired
	private ReferenceService referenceService;
	
	/**
	 * Get terms and conditions
	 *
	 * @return TermsAndConditionsVO
	 */
	@GET
	@Path(value = "/")
	@Produces(MediaType.APPLICATION_JSON)
	public TermsAndConditionsVO getTermsAndConditions() {
		TermsAndConditionsVO tc = new TermsAndConditionsVO();
		tc.setVersion("0");
		tc.setContent("");
		String userLocale = getContextAttribute(TrustBrokerWebAppConstants.USER_LOCALE);
		TermsAndConditionsRetrievalServiceResponse resp;
		if (userLocale == null) {
			resp = referenceService.fetchTermsAndConditions(null);
		}
		else {
			resp = referenceService.fetchTermsAndConditions(Locale.forLanguageTag(userLocale));
		}
		if (resp != null && TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(resp.getExecutionStatus().getStatusCd())) {
			tc.setVersion(resp.getTermsandConditions().getVersion());
			tc.setContent(resp.getTermsandConditions().getContent());
		}
		return tc;
	}
}