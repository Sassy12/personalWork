package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.richfaces.event.ItemChangeEvent;
import org.springframework.beans.BeanUtils;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.context.ApplicationContext;
import com.optum.trustbroker.context.ApplicationContextHolder;
import com.optum.trustbroker.esso.sso.SsoContext;
import com.optum.trustbroker.esso.sso.utils.SsoUtils;
import com.optum.trustbroker.message.ErrorMessage;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.InvitationConstants;
import com.optum.trustbroker.util.IrmLoggingUtil;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.ExecutionStatus;
import com.optum.trustbroker.vo.InvitationContextPropertyVO;
import com.optum.trustbroker.vo.InvitationServiceResponse;
import com.optum.trustbroker.vo.InvitationVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RPAppDomainVO;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserNameCheckServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.authentication.sm.HttpLoginRequest;
import com.uhg.iam.alps.authentication.sm.LoginRequest;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.esso.schemas.xsd._2012._07.ResponseTypeCode;
import com.uhg.iam.esso.schemas.xsd._2013._12.AuthenticationType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

@ManagedBean(name = "userRegistrationBean")
@SessionScoped
public class UserRegistrationBean extends AbstractBackingBean implements Serializable {
	private static final long serialVersionUID = 1L;
	// TODO
	public static final String EMAIL_CONFRM_ACTIVE_ITEM = "userEmailConfirmation";
	BaseLogger logger = new BaseLogger(UserRegistrationBean.class);
	@ManagedProperty(value = "#{userVO}")
	private UserVO userVO;
	@ManagedProperty(value = "#{tbSecurityQuestionsBean}")
	private SecurityQuestionsBean tbSecurityQuestionsBean;
	
	private String action = "/siteminderagent/forms/login.fcc";
	private String targetUrl = "/tb/secure/home.jsf";
    private String registrationUrl = "/views/userregistration.jsf";
	private String signInPage="/views/login.xhtml?faces-redirect=true";
	private String localenv = "false";
	private String errorMsg;
	private String dateOfBirth;
	private String currentActiveItem;
	private String currentButtonId;
	private String confirmEmailAddress;
	private String confirmPassword;
	private List<String> userNameSuggestionsList;
	private List<String> oldUsernameSuggestionsList;
	private String emailExistsMsg;
	private String specialCharsMsg;
	private String emailExistsMsgSec;
	private String passwordStrength;
	private String personalInfoErrorMsg;
	private String relyingAppErroMsg = null;
	private String relyingAppTrustErrorMessage = null;
	private String tempUserName;
	private String invitationCode =null;
	private String emailId =null;
	private String mobilePhone;
	private boolean showSugestions;
	private boolean showEmail;
	private boolean relyingApp=false;
	private boolean decryptionfailed = false;
	private boolean relyinPartyTrusted = true;
	private boolean tncAccepted;
	private boolean privacyPolicyAccepted;
	private boolean disableEmailCode = true;
	private boolean showContinue = false;
	private boolean disableEmailAddress = false;
	private boolean verifyNowFlag = false;
	private boolean pwdSpcErrInd = false;
	private boolean confPwdSpcErrInd = false;
	private boolean showDob = false;
	private boolean showQuestions = true;
	private boolean rsaReqdForRP = true;
	private boolean emailMandatory = true;
	private boolean emailShared = true;
	private String emailOrDash;
	private static int yobLimit=2;
	private String yearOfBirth=null;
	private boolean yobValid=false;
	
	private List<SelectItem> acctRecoveryMethods = new ArrayList<SelectItem>();
	private String acctRecoveryMethod;
	private final String SECEMAIL_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_SecEmailId");
	private final String MOBILE_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_MobileId");
	private final String SECQUESTS_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_SecQuestId");
	private final String INCORRECT_YEAR_OF_BIRTH_COUNT="_INC_YEAR_OF_BIRTH";
	
	private final int MIN_AGE_LIMIT = Integer.parseInt(PropertyLoader.getInstance()
			.getPortalConfigValue("userMinAgeLimit"));
	
	private boolean displaySkipOption;
	
	boolean skipverifyCodeFlow = false;
	boolean skipAccountRecoveryFlow = false;
	boolean isPrimaryEmailChosen = false;
	boolean isMobileNumberChosen = false;
	boolean isSecEmailChosen = false;
	boolean isSQChosen = false;
	private boolean coppaValidationReqd = true;
	private final String COPPA_REQD_NO_IND ="N";
	
	private boolean showSecQuestionBasedonSharedEmail =false;
	
	private int accessCount =0;

	private int questionOne=2;
	private int questionTwo=2;
	private int questionThree=2;
	private int ansOne=2;
	private int ansTwo=2;
	private int ansThree=2;
	private String focusField="firstName";
	private boolean invitationRegnErr = false;
	
	private String password=null;
	private String confirmPwdSavedVal =null;
	private boolean pwdValChgInd = false;
	private boolean confirmPwdChgInd = false;
	private boolean passwordValid;
	private boolean confirmPwdValid;
	private final String DUMMY_PWD_VAL = tbResources.getString("dummypasswordval");
			
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPwdSavedVal() {
		return confirmPwdSavedVal;
	}

	public void setConfirmPwdSavedVal(String confirmPwdSavedVal) {
		this.confirmPwdSavedVal = confirmPwdSavedVal;
	}

	public boolean isPwdValChgInd() {
		return pwdValChgInd;
	}

	public void setPwdValChgInd(boolean pwdValChgInd) {
		this.pwdValChgInd = pwdValChgInd;
	}
	
	public boolean isConfirmPwdChgInd() {
		return confirmPwdChgInd;
	}

	public void setConfirmPwdChgInd(boolean confirmPwdChgInd) {
		this.confirmPwdChgInd = confirmPwdChgInd;
	}
	public void setConfirmPwdValid(boolean confirmPwdValid) {
		this.confirmPwdValid = confirmPwdValid;
	}

	/**
	 * This method is to check if the user entered valid confirm password or not 
	 * 
	 * @return boolean
	 */
	public boolean isConfirmPwdValid() {
		return this.confirmPwdValid;
	}
	
	public void setPasswordValid(boolean passwordValid) {
		this.passwordValid = passwordValid;
	}

	/**
	 * This method is to check if the user entered valid password or not 
	 * 
	 * @return boolean
	 */
	public boolean isPasswordValid() {
		return this.passwordValid;
	}
	public String getDummyPasswordVal() {
		return DUMMY_PWD_VAL;
	}

	// render DOB to reflect change in format from MMddyyyy to MM/dd/yyyy
	private boolean renderDOB = false;
	
	public boolean isRenderDOB() {
		return renderDOB;
	}

	public void setRenderDOB(boolean renderDOB) {
		this.renderDOB = renderDOB;
	}

	public int getAccessCount() {
		return accessCount;
	}
	
	public int getQuestionOne() {
		return questionOne;
	}

	public void setQuestionOne(int questionOne) {
		this.questionOne = questionOne;
	}

	public int getQuestionTwo() {
		return questionTwo;
	}

	public void setQuestionTwo(int questionTwo) {
		this.questionTwo = questionTwo;
	}

	public int getQuestionThree() {
		return questionThree;
	}

	public void setQuestionThree(int questionThree) {
		this.questionThree = questionThree;
	}
	public int getAnsOne() {
		return ansOne;
	}

	public void setAnsOne(int ansOne) {
		this.ansOne = ansOne;
	}

	public int getAnsTwo() {
		return ansTwo;
	}

	public void setAnsTwo(int ansTwo) {
		this.ansTwo = ansTwo;
	}

	public int getAnsThree() {
		return ansThree;
	}

	public void setAnsThree(int ansThree) {
		this.ansThree = ansThree;
	}

	public void setAccessCount(int accessCount) {
		this.accessCount = accessCount;
	}

	@ManagedProperty(value = "#{userService}")
	private UserService userService;
	
	
	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
	public boolean isShowSecQuestionBasedonSharedEmail() {
		return showSecQuestionBasedonSharedEmail;
	}

	public void setShowSecQuestionBasedonSharedEmail(
			boolean showSecQuestionBasedonSharedEmail) {
		this.showSecQuestionBasedonSharedEmail = showSecQuestionBasedonSharedEmail;
	}

	public boolean isDisplaySkipOption() {
		return displaySkipOption;
	}

	public void setDisplaySkipOption(boolean displaySkipOption) {
		this.displaySkipOption = displaySkipOption;
	}

	public String getAcctRecoveryMethod() {
		return acctRecoveryMethod;
	}

	public void setAcctRecoveryMethod(String acctRecoveryMethod) {
		this.acctRecoveryMethod = acctRecoveryMethod;
	}

	public boolean isShowDob() {
		return showDob;
	}

	public void setShowDob(boolean showDob) {
		this.showDob = showDob;
	}
	public String getYearOfBirth(){
	    	return yearOfBirth;
	}
	public void setYearOfBirth(String val){
	    	yearOfBirth=val;
	}
	public boolean isShowQuestions() {
		return showQuestions;
	}

	public void setShowQuestions(boolean showQuestions) {
		this.showQuestions = showQuestions;
	}

	public String getEmailExistsMsgSec() {
		return emailExistsMsgSec;
	}

	public void setEmailExistsMsgSec(String emailExistsMsgSec) {
		this.emailExistsMsgSec = emailExistsMsgSec;
	}

	public boolean getRelyingApp() {
		return relyingApp;
	}

	public SecurityQuestionsBean getTbSecurityQuestionsBean() {
		return tbSecurityQuestionsBean;
	}

	public void setTbSecurityQuestionsBean(
			SecurityQuestionsBean tbSecurityQuestionsBean) {
		this.tbSecurityQuestionsBean = tbSecurityQuestionsBean;
	}

	public String getCurrentActiveItem() {
		return currentActiveItem;
	}

	public void setCurrentActiveItem(String currentActiveItem) {
		this.currentActiveItem = currentActiveItem;
	}

	public String getCurrentButtonId() {
		return currentButtonId;
	}

	public void setCurrentButtonId(String currentButtonId) {
		this.currentButtonId = currentButtonId;
	}

	public UserVO getUserVO() {
		return userVO;
                
	}


	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public String getConfirmEmailAddress() {
		return confirmEmailAddress;
	}

	public void setConfirmEmailAddress(String confirmEmailAddress) {
		this.confirmEmailAddress = confirmEmailAddress;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public List<String> getUserNameSuggestionsList() {
		return userNameSuggestionsList;
	}

	public void setUserNameSuggestionsList(List<String> userNameSuggestionsList) {
		this.userNameSuggestionsList = userNameSuggestionsList;
	}

	public List<String> getOldUsernameSuggestionsList() {
		return oldUsernameSuggestionsList;
	}

	public void setOldUsernameSuggestionsList(
			List<String> oldUsernameSuggestionsList) {
		this.oldUsernameSuggestionsList = oldUsernameSuggestionsList;
	}

	public boolean isShowSugestions() {
		return showSugestions;
	}

	public void setShowSugestions(boolean showSugestions) {
		this.showSugestions = showSugestions;
	}

	public boolean isShowEmail() {
		return showEmail;
	}

	public void setShowEmail(boolean showEmail) {
		this.showEmail = showEmail;
	}

	public String getEmailExistsMsg() {
		return emailExistsMsg;
	}

	public void setEmailExistsMsg(String emailExistsMsg) {
		this.emailExistsMsg = emailExistsMsg;
	}

	public String getPasswordStrength() {
		return passwordStrength;
	}

	public void setPasswordStrength(String passwordStrength) {
		this.passwordStrength = passwordStrength;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getPersonalInfoErrorMsg() {
		return personalInfoErrorMsg;
	}

	public void setPersonalInfoErrorMsg(String personalInfoErrorMsg) {
		this.personalInfoErrorMsg = personalInfoErrorMsg;
	}

	public String getTempUserName() {
		return tempUserName;
	}

	public void setTempUserName(String tempUserName) {
		this.tempUserName = tempUserName;
	}

	public String getInvtnCode() {
		return invitationCode;
	}

	public void setInvtnCode(String invitationCode) {
		this.invitationCode = invitationCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
		 
    public boolean isPwdSpcErrInd() {
		return pwdSpcErrInd;
	}

	public void setPwdSpcErrInd(boolean pwdSpcErrInd) {
		this.pwdSpcErrInd = pwdSpcErrInd;
	}

	/**
	 * @return the disableEmailAddress
	 */
	public boolean isDisableEmailAddress() {
		return disableEmailAddress;
	}

	/**
	 * @param disableEmailAddress the disableEmailAddress to set
	 */
	public void setDisableEmailAddress(boolean disableEmailAddress) {
		this.disableEmailAddress = disableEmailAddress;
	}
	
    /**
	 * @return the emailMandatory
	 */
	public boolean isEmailMandatory() {
		return emailMandatory;
	}

	/**
	 * @param emailMandatory the emailMandatory to set
	 */
	public void setEmailMandatory(boolean emailMandatory) {
		this.emailMandatory = emailMandatory;
	}

	/**
	 * @return the emailShared
	 */
	public boolean isEmailShared() {
		return emailShared;
	}

	/**
	 * @param emailShared the emailShared to set
	 */
	public void setEmailShared(boolean emailShared) {
		this.emailShared = emailShared;
	}

	/**
	 * @return the verifyNowFlag
	 */	
	public boolean isVerifyNowFlag() {
		return verifyNowFlag;
	}
	
	/**
	 * @param verifyNowFlag the verifyNowFlag to set
	 */
	public void setVerifyNowFlag(boolean verifyNowFlag) {
		this.verifyNowFlag = verifyNowFlag;
	}
	/**
     * This method is used to return COPPA validation required flag.
     *        
     * @return coppaReqdInd String   
     */	
	public boolean isCoppaValidationReqd() {
		return coppaValidationReqd;
	}
	/**
     * This method is used to set COPPA validation required flag.
     *        
     * @param coppaReqdInd String   
     */
	public void setCoppaValidationReqd(boolean coppaValidationReqd) {
		this.coppaValidationReqd = coppaValidationReqd;
	}

	public boolean isRsaReqdForRP() {
		return rsaReqdForRP;
	}

	public void setRsaReqdForRP(boolean rsaReqdForRP) {
		this.rsaReqdForRP = rsaReqdForRP;
	}
	
	public String getFocusField() {
		return focusField;
	}

	public void setFocusField(String focusField) {
		this.focusField = focusField;
	}

	public boolean isInvitationRegnErr() {
		return invitationRegnErr;
	}

	public void setInvitationRegnErr(boolean invitationRegnErr) {
		this.invitationRegnErr = invitationRegnErr;
	}


    public void preRenderView() {
        // stop execution for Ajax calls
        try {
            if (FacesContext.getCurrentInstance().isPostback()) {
                return;
            }
        }
        catch (Exception e) {
            // ignore
        }
   		// makes sure init is called before any rendering
           init();
   	}


	public void init() {
		// Check if local environment.
		if (TBUtil.isLocalEnv()) {
			localenv = "true";
		}

        if (!initOpenIdConnectForEntry(registrationUrl)) {
            return;
        }

		if(!isSessionAttributeExists(TrustBrokerWebAppConstants.LOGIN_TARGET)){
		addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, 
				HttpUtils.addParameterToURL(targetUrl, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, 
						TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE)); // Add default URL always with default alias
		}
		addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE);
		
		try {
			setCurrentActiveItem("personalInformation");
			
			//updateRegnConfStatus();
			
			ChallengeQuestionServiceResponse challengeQuestionServiceResponse = getContainer().getConfigService().getSecurityQuestions();
			tbSecurityQuestionsBean.setQuestions(challengeQuestionServiceResponse.getUserChallengeQuestions());
						
			if(getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null && getRequestParameter("relyingAppId") != null){
				captureRelyingPartyInfo(getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);	
				if(getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_EDIT).toString().equalsIgnoreCase("N")) {
					if(getSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO) == null ) {
						disableEmailAddress = true;
					}
					else
					{
						disableEmailAddress = false;
					}
				}
				removeSessionAttribute(TrustBrokerWebAppConstants.EMAIL_EDIT);
				processRPreg();
			}
			
			// gtyagi1: Check for Sso Broker request!
			if ( SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
				captureDetailsFromSsoContext();
			}
	
			if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM) != null &&
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM) != null &&
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL) != null){
				if(getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null && 
						getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) != null){
	
					emailId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL).toString();
					userVO.setEmailAddress(emailId);
					userVO.setFirstName(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM).toString());
					userVO.setLastName(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM).toString());
					setConfirmEmailAddress(emailId);
					//Inbound SSO Change for Registration.
					if(getSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO) == null ) {
						relyingApp=true;
					}
				}
			}

			// TODO
			if(getSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL)!=null)
			{
				userVO.setEmailAddress(getSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL).toString());
				setConfirmEmailAddress(getSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL).toString());
			}
			
			if(getRequestParameter(TrustBrokerWebAppConstants.INVITATION) != null){
				String invitation = getRequestParameter(TrustBrokerWebAppConstants.INVITATION);
				Map<String, String> invitationMap = null;
				try {
					invitationMap = container.getInvitationService().decodeInvitationDetails(invitation);
				}
				catch (OperationFailedException ofe) {
					String uid = ofe.getErrorMessage() != null ? ofe.getErrorMessage().getUid():"";
					logger.error("Exception while decryption invitation code - {}", new String[]{uid}, ofe);
					logger.error(ofe);
					setDecryptionfailed(true);
					ErrorMessage errorMessageObj = ofe.getErrorMessage();
					setErrorMsg(errorMessageObj.getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo()));
					return;
				}
				if(null != invitationMap) {
					captureInvitationInfo(invitationMap);
				}
				processRPreg();				
				boolean nameFieldsValid = validateFirstNameLastNameFields();
				if(!nameFieldsValid) {
					setInvitationRegnErr(true);
				}
				setDefaultFocus();
				//Remove page level validation error as this is not required here
				setErrorMsg(null);
			}
			
		}
		catch(OperationFailedException ope) {
			logger.error("Exception while initialization user registration bean: ", 
					new String[]{TrustbrokerWebAppUtil.getUidFromError(ope)} , ope);
			logger.error(ope);
			setErrorMsg(extractErrorMessageFromOFE(ope));
		}
	}
	

	/**
	 * gtyagi1: Method captures details from SsoContext to pre-populate 
	 * UserVo from SsoContext
	 */
	private void captureDetailsFromSsoContext() {
		
		ApplicationContext appCtx = ApplicationContextHolder.getContext();
		if (appCtx != null) {
			SsoContext ssoContext = appCtx.retrieve(SsoContext.class);
			if (ssoContext != null) {
				try {
					container.getSsoContextUserVoDataConverter().convert(
							ssoContext, userVO);
					// gtyagi1: confirm primary email must match original value
					this.confirmEmailAddress = userVO.getEmailAddress();
					userVO.setConfirmEmailAddress(userVO.getEmailAddress());

					// gtyagi1 note - relying on the correctness of config that
					// attribute used to obtain verified email is same as the
					// one's that's populating email in VO inside DataConverter.
					// Note that although SSOBroker config allows email
					// attribute to vary but DataConverter used to populate
					// UserVO is global and relies on a static well-known
					// name.Relying on config correctness is ok for now,
					// ideally DataConverterShould also use EmailAttribute name
					// from SSO Broker ...to be analyzed later!
					if (StringUtils
							.isNotBlank(ssoContext.getPreVerifiedEmail())) {
						addSessionAttribute(
								TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL,
								ssoContext.getPreVerifiedEmail());
					}
				} catch (Exception ex) {
					// gtyagi1: let's not break the UX because of conversion
					// issue, not a big deal as it stands
					logger.error(
							"Exception occured (will be swallowed) in populating user from SsoContext, details - \n{}",
							ex);
				}
			} else {
				logger.error("No SsoContext found!");
			}
		} else {
			logger.error("No ApplicationContext found");
		}
	}

	public boolean validatePersonalInformation() {
		
		// all validations are to be performed as all the error message will be shown in case of error post submit
		boolean result = true;

		boolean resultFirstName = TBUtil.validateName(userVO.getFirstName());
		boolean resultLastName = TBUtil.validateName(userVO.getLastName());
		
		if (!resultFirstName ) {
			addFacesMessage("userRegistrationId:firstName", tbResources.getString("numericSpecialCharMsg"));
			result = false;
		}
		
		if ( ! resultLastName) {
			addFacesMessage("userRegistrationId:lastName", tbResources.getString("lastnumericSpecialCharMsg"));
			result = false;
		} 
		
		// date check
		boolean isDateValid = true;
		
		if(StringUtils.isNotBlank(dateOfBirth)) {
			//isDateValid = validateDate("userRegistrationId:dobId", dateOfBirth);
			isDateValid = validateDateCoppa("userRegistrationId:dobId", dateOfBirth, isCoppaValidationReqd());
			if(isDateValid == false) {
				setErrorMsg(tbResources.getString("formNotSubmitted")); // setting page level error
				result = false;
			}
			
			changeDateFormat(dateOfBirth); // renderDOB is not required in case of post-submit
			
			// setting it to userVO as this date will be saved in case all the validations are successful
			//userVO.setDob(DateUtil.parseDate(dateOfBirth, DateUtil.EXT_DATE_FORMAT));
			userVO.setDob(DateUtil.parseDateMultipleFormats(dateOfBirth));

			
		}
			


		logger.debug("Is Personal Information validated: " + result);
		// if result is false, it means page submit is not successful and one ore more errors are present
		return result;
	}


	// this message is setting page level error message as well using errorMsg variable
	private void addFacesMessage(String fieldId, String message) {
		setErrorMsg(tbResources.getString("formNotSubmitted"));
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}
	
	public void validateTncCheckbox(FacesContext context, UIComponent component, Object value) {   
	   
	    	errorMsg="This form is not ready to be submitted. Check the highlighted fields – at least one required field is missing information or needs a different format.";
	    
	}  
	public boolean registerUser() {
		// Validation Form Fields
		
		boolean isNameFieldsValidated = validateFirstNameLastNameFields();
		boolean isEmailFieldsValidated = validateEmailFields();
		boolean isPwdFieldsValidated = validatePasswordFields();
		//boolean isphoneFieldsValidated = validatePhone();
		boolean isphoneFieldsValidated = validatePhoneMultipleFormats("userRegistrationId:mobilePhone", getMobilePhone());
		if(isphoneFieldsValidated == false) {
			setErrorMsg(tbResources.getString("formNotSubmitted")); // form level error message
		}
		
		boolean isSecurityQuestionsNotNull=true;
		
		if(tbSecurityQuestionsBean.getSecurityQuestionOne()==null||"null".equals(tbSecurityQuestionsBean.getSecurityQuestionOne())||tbSecurityQuestionsBean.getSecurityQuestionTwo()==null||"null".equals(tbSecurityQuestionsBean.getSecurityQuestionTwo())||tbSecurityQuestionsBean.getSecurityQuestionThree()==null||"null".equals(tbSecurityQuestionsBean.getSecurityQuestionThree())){
			
			isSecurityQuestionsNotNull=false;
		}
		
		boolean isSecurityAnswersValidated = false;
		
		// if Sec question is must , then do validate otherwise based on showQuestions flag and showSecQuestionBasedonSharedEmail flags do validation
		if(showQuestions || showSecQuestionBasedonSharedEmail){
			
			if(isEmptySecQuestion(tbSecurityQuestionsBean.getSecurityQuestionOne()) && isEmptySecQuestion(tbSecurityQuestionsBean.getSecurityQuestionTwo()) 
					&& isEmptySecQuestion(tbSecurityQuestionsBean.getSecurityQuestionThree()) && StringUtils.isEmpty(tbSecurityQuestionsBean.getSecurityAnswerOne())  
					&& StringUtils.isEmpty(tbSecurityQuestionsBean.getSecurityAnswerTwo()) && StringUtils.isEmpty(tbSecurityQuestionsBean.getSecurityAnswerThree()))
			{	
				isSecurityAnswersValidated = true;
			}
			else{
				isSecurityAnswersValidated = validateSecurityAnswers("");
			}
	
		}else{
			 isSecurityAnswersValidated = true;
		}
		
		if(!isPwdFieldsValidated) {
			clearPasswordFields();
		}
		
		boolean isUserNameValidated = validateUserName(userVO.getUserName());
		boolean isTermsAndConditionValidated=validateTermsAndCondition();
		boolean isYearOfBirthValid = validateYearOfBirth();
		if(isYearOfBirthValid)
		    yobValid=true;
		
		return isNameFieldsValidated && isEmailFieldsValidated && isPwdFieldsValidated
				&& isSecurityAnswersValidated && isUserNameValidated && isTermsAndConditionValidated && isYearOfBirthValid && isphoneFieldsValidated;
	}
	
	/**
	 * This method is used to clear password fields and reset password valid flags
	 */
	private void clearPasswordFields() {
		userVO.setPassword("");
		userVO.setConfirmPwd("");
		setConfirmPassword("");
		setPasswordValid(false);
		setConfirmPwdValid(false);
	}
	
	private boolean isEmptySecQuestion(String question) {
		boolean emptySecQuest = false;
		if(question == null || "null".equalsIgnoreCase(question)) {
			emptySecQuest = true;
		}		
		return emptySecQuest;
	}

	private boolean validateTermsAndCondition() {
		boolean retVal=true;
		String termsCondition = userVO.getTermsCondition();
		return retVal;
	}
	
	private boolean validateSecurityAnswers(String fieldPrefix) {
		String sameAnswer = "";
		boolean retVal = true;
		if(fieldPrefix == null) {
			fieldPrefix = "";
		}

		String answerOne = tbSecurityQuestionsBean.getSecurityAnswerOne();
		String answerTwo = tbSecurityQuestionsBean.getSecurityAnswerTwo();
		String answerThree = tbSecurityQuestionsBean.getSecurityAnswerThree();
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion3 = tbSecurityQuestionsBean.getSecurityQuestionThree();

		if (secQuestion1.equals("null") || secQuestion1.length() == 4) {
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("securityQuestion123"));
			retVal = false;
		}

		if (secQuestion2.equals("null") || secQuestion2.length() == 4) {
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("securityQuestion123"));
			retVal = false;
		}

		if (secQuestion3.equals("null") || secQuestion3.length() == 4) {
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("securityQuestion123"));
			retVal = false;
		}
		
		// implemented when we not give the answers
		if (answerOne.equals("") ) {
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("securityQuestion123"));
			retVal = false;
		}

		if (answerTwo.equals("") ) {
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("securityQuestion123"));
			retVal = false;
		}

		if (answerThree.equals("") ) {
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("securityQuestion123"));
			retVal = false;
		}
		
		
		if(!retVal) {
			return retVal;
		}

		if (answerOne.equalsIgnoreCase(answerTwo) && answerOne.equalsIgnoreCase(answerThree))
			sameAnswer = answerOne;
		//if (answerTwo.equalsIgnoreCase(answerThree))
		//	sameAnswer = answerTwo;

		if (!"".equals(sameAnswer)) {

			if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase()) && sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase()) && sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())
					&& sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

		} else {
			if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase())) {
				retVal = false;

				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
			}

			if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}
		}
		
		if(!TBUtil.validateSecurityAnswer(answerOne)){
			retVal = false;
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("obsceneTextInAnswer"));
		}
		
		if(!TBUtil.validateSecurityAnswer(answerTwo)){
			retVal = false;
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("obsceneTextInAnswer"));
		}
		
		if(!TBUtil.validateSecurityAnswer(answerThree)){
			retVal = false;
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("obsceneTextInAnswer"));
		}

		return retVal;
	}

	private boolean validatePasswordFields() {
		boolean result = true;
			
		if (!userVO.getPassword().equals(getConfirmPassword()) || isConfPwdSpcErrInd()) {
			result = false;
			addFacesMessage("userRegistrationId:confirmPwd", tbResources.getString("pwdDoNotMatch"));
			return result;
		}
			
		result = checkPwdContent();
		
		if(isPwdSpcErrInd()) {
			addFacesMessage("userRegistrationId:pwd",
					tbResources.getString("pwdCannotContainSpaces"));
			result = false;
		} 
				 
		if(!TBUtil.isPwdStrengthValid(userVO.getPassword())) {
			result = false;
			addFacesMessage("userRegistrationId:pwd", "Password must meet requirements");
			
		}
		
		return result;
	}
	
	

	private boolean validateEmailFields() {
		boolean result = true;
		
		String email = userVO.getEmailAddress();
		if(email != null) {
			email = email.toLowerCase();
		}
		if(getConfirmEmailAddress() != null){
			confirmEmailAddress = confirmEmailAddress.toLowerCase();
		}
		result = validateEmailAddress(email);
				
		if (email != null && TBUtil.validateEmailId(email)
				&& !email.toLowerCase()
						.equals(getConfirmEmailAddress().toLowerCase())) {
			addFacesMessage("userRegistrationId:confirmEmail",
					tbResources.getString("emailDoNotMatch"));
			result = false;
		}
		
		return result;
	}
	
	
	/**
	 * This method is used to validate the mobile phone number
	 * 
	 * @param value String
	 * @return boolean
	 */
	private boolean validatePhone() {
		boolean validPhone = true;	
		
		String mobileNum = getMobilePhone();
		
		if(!StringUtils.isEmpty(mobileNum)) {
			if(mobileNum.length() < 13) {
				addFacesMessage("userRegistrationId:mobilePhone",
						tbResources.getString("invalidMobileMsg508"));
				return false;
			}
			String number = mobileNum.substring(1, 4) + mobileNum.substring(5, 8)
					+ mobileNum.substring(9, 13);
			if(StringUtils.isEmpty(number.replace("_", ""))) {
				
				addFacesMessage("userRegistrationId:mobilePhone",
						tbResources.getString("invalidMobileMsg508"));
				return false;
			}
			if(! StringUtils.isNumeric(number)) {
				addFacesMessage("userRegistrationId:mobilePhone",
						tbResources.getString("invalidMobileMsg508"));
				return false;
			}
		}
		return validPhone;
	}

	
	/**
	 * This method is used to validate the mobile phone number
	 * 
	 * @param value String
	 * @return boolean
	 */
	private boolean validatePhoneAccRecovery() {
		boolean validPhone = true;	
		
		String mobileNum = getMobilePhone();
		
		if(!StringUtils.isEmpty(mobileNum)) {
			if(mobileNum.length() < 13) {
				addFacesMessage("userRegistrationId:mobilenum",
						tbResources.getString("invalidMobileMsg508"));
				return false;
			}
			String number = mobileNum.substring(1, 4) + mobileNum.substring(5, 8)
					+ mobileNum.substring(9, 13);
			if(StringUtils.isEmpty(number.replace("_", ""))) {
				
				//userVO.setPhoneNumber("");
				setMobilePhone("");
				addFacesMessage("userRegistrationId:mobilenum",
						tbResources.getString("regnacctrecoveryMobilReqMsg"));
				return false;
			}
			if(! StringUtils.isNumeric(number)) {
				addFacesMessage("userRegistrationId:mobilenum",
						tbResources.getString("invalidMobileMsg508"));
				return false;
			}
		}
		return validPhone;
	}
	
	

	public void pageChanged(ItemChangeEvent event) {
		
		setErrorMsg("");
		setInvitationRegnErr(false);
		if(!isPwdValChgInd() && getDummyPasswordVal().equals(getUserVO().getPassword())) {
			getUserVO().setPassword(getPassword());			
		}
		if(!isConfirmPwdChgInd() && getDummyPasswordVal().equals(getConfirmPassword())) {
			setConfirmPassword(getConfirmPwdSavedVal());
		}
		if ("continueButton".equals(getCurrentButtonId())) {
			if (!validatePersonalInformation())
				setCurrentActiveItem("personalInformation");
			else {			
				setEmailExistsMsg("");
				setPersonalInfoErrorMsg("");
				setCurrentActiveItem("userSecurity");
			}
		}
		if ("backtoPersonalInfo".equals(getCurrentButtonId())) {
			setCurrentActiveItem("personalInformation");
		}
		if ("cancelButton".equals(getCurrentButtonId())) {
			setCurrentActiveItem("signIn");
		}
		if ("registerButton".equals(getCurrentButtonId())) {
			if (!registerUser()){				
				setCurrentActiveItem("userSecurity");
			}
		}

		if ("agreeButton".equals(getCurrentButtonId())) {
			 if (!registerUser() || !validatePersonalInformation()){				
				setCurrentActiveItem("personalInformation");
				setErrorMsg(tbResources.getString("formNotSubmitted"));
			}else{
							
				userVO.setIsTncAccepted(tbResources.getString("isTncAccepted"));
				userVO.setTncAgreementVersion(tbResources.getString("tncAgreementVersion"));
				userVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
				if(yobValid && isCoppaValidationReqd()) {
				    userVO.setIsCoppaAccepted("Y");
				} else {
					userVO.setIsCoppaAccepted("N");
				}
				userVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));
				if(getSessionMap().get("invitationCode")!=null){
					userVO.setInvtnCode(invitationCode);
				}
				if(StringUtils.isNotEmpty(mobilePhone)){
					
					// remove non-digit chracters from mobile phone
					mobilePhone = mobilePhone.replaceAll("\\D+","");
					// convert all-digit mobile nubmer 5555555555 to format (555)555-5555 accepted by ESSO
					mobilePhone = "("+mobilePhone.substring(0, 3) + ")" + mobilePhone.substring(3, 6) + "-" + mobilePhone.substring(6);
					
					userVO.setPhoneNumber(mobilePhone);
				}
				if(!isEmptySecQuestion(tbSecurityQuestionsBean.getSecurityQuestionOne()) 
						&& !isEmptySecQuestion(tbSecurityQuestionsBean.getSecurityQuestionTwo()) 
						&& !isEmptySecQuestion(tbSecurityQuestionsBean.getSecurityQuestionThree()))
				{
					if(showQuestions || showSecQuestionBasedonSharedEmail){
						populateSecurityQuestions(userVO);
					}
					
				}
		
				if(StringUtils.isEmpty(userVO.getEmailAddress()) ) {	
					setDisplaySkipOption(false);			
				}else{
					setDisplaySkipOption(true);
					
				}
				
				/*if(StringUtils.isEmpty(userVO.getEmailAddress())  
						&& isUserSecQuestionsNotExists(userVO) && StringUtils.isEmpty(getMobilePhone()) ) {	
					setDisplaySkipOption(false);			
				}else{
					setDisplaySkipOption(true);
					
				}*/
				
				
				//Check if primary email is empty or shared and mobile number is empty and user security questions are empty
				//If all these conditions match then display account recovery screen, else continue with registration
				
				if(!isUserSecQuestionsNotExists(userVO)){
					
					if(StringUtils.isEmpty(userVO.getEmailAddress())){
						
						
						skipverifyCodeFlow =true;
						skipAccountRecoveryFlow =true;
						
					}
					
					registerNewUser();
				}else{
				
				if((StringUtils.isEmpty(userVO.getEmailAddress()) || isUserEmailShared(userVO)) 
						&& isUserSecQuestionsNotExists(userVO) && StringUtils.isEmpty(getMobilePhone()) ) {
					//Build account recovery options list
					
					if(isDisplaySkipOption()){
						if(UserRegistration()) {
							skipAccountRecoveryOptions();
						} else {
							return;
						}
					}
					buildRecoveryMethods();
					setCurrentActiveItem("useracctrecovery");					
				} else {
					
					if((StringUtils.isEmpty(userVO.getEmailAddress()) || isUserEmailShared(userVO)) 
							&&  !StringUtils.isEmpty(getMobilePhone())){
						
							if(isDisplaySkipOption()){
								if(UserRegistration()) {
									skipAccountRecoveryOptions();
								} else {
									return;
								}
							}
							buildRecoveryMethods();
							setCurrentActiveItem("useracctrecovery");
					}else{
					
						if(!isUserEmailShared(userVO)){
							
							addSessionAttribute("IS_UNIQUE_EMAIL", "YES");
						}
					registerNewUser();
					
					}
				}
				
				
			}
								
			}
		}
				
		if ("RegnAcctRecoveryButton".equalsIgnoreCase(getCurrentButtonId())) {
					
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			VerifyCodesContext ctx = new VerifyCodesContext();
			
			if (StringUtils.isNotBlank(userVO.getEmailAddress())) {
				isPrimaryEmailChosen = true;
				ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
				ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			}
			
			if(StringUtils.isEmpty(this.acctRecoveryMethod) || "null".equalsIgnoreCase(this.acctRecoveryMethod)) {
				addFacesMessage("userRegistrationId:regnRecoveryType",tbResources.getString("regnacctrecoveryMethodReqMsg"));
				setCurrentActiveItem("useracctrecovery");		
				return;
			} else 	if(SECEMAIL_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {				
				if(!validateRecoverySecEmail(userVO.getSecEmailAddress())) {
					setCurrentActiveItem("useracctrecovery");
					return;
				}				
				userVO.setEssoSecEmail(userVO.getSecEmailAddress());
		
				try {
					userVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
					userVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));
					userVO.setSecEmailAddress(userVO.getSecEmailAddress());
					userProfileServiceRequest.setUser(userVO);
					
					setErrorMsg("A new confirmation code has been sent to your new email address");
				} catch (OperationFailedException exception) {
					logger.error("Exception while Updating the confirm email during user Post Account Recovery - {}", 
							new String[]{TrustbrokerWebAppUtil.getUidFromError(exception)},exception);
					logger.error(exception);
					setCurrentActiveItem("useracctrecovery");
					String emailErrorMsg = extractErrorMessageFromOFE(exception);
					if (null != emailErrorMsg)
						setErrorMsg(emailErrorMsg);
					else
						setErrorMsg(tbResources.getString("emailVerificationFailed"));
					setErrorMsg("An error occured while updating your Secondary Email address");
				}
				
				
				 isSecEmailChosen = true;
				
				userVO.setSecEmailVerified(false);
				ctx.getViewChannels().add(CommunicationChannel.SECONDARY_EMAIL);
				ctx.getSendChannels().add(CommunicationChannel.SECONDARY_EMAIL);
								
			} else if (MOBILE_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {
				if(StringUtils.isEmpty(getMobilePhone())) {
					addFacesMessage("userRegistrationId:mobilenum",tbResources.getString("regnacctrecoveryMobilReqMsg"));
					setCurrentActiveItem("useracctrecovery");
					return;
				}	
				
				if(!validatePhoneAccRecovery()) {
					//addFacesMessage("userRegistrationId:mobilenum",tbResources.getString("regnacctrecoveryMobilReqMsg"));
					setCurrentActiveItem("useracctrecovery");
					return;
				}
				//userVO.setPhoneNumber(getMobilePhone());
				userVO.setSecEmailAddress(null);
				
				userVO.setPhoneNumber(getMobilePhone());					
				try {						
					userVO.setIsPhoneVerified(false);
					 isMobileNumberChosen = true;
					ctx.getViewChannels().add(CommunicationChannel.PHONE);
					ctx.getSendChannels().add(CommunicationChannel.PHONE);
					setErrorMsg("A new confirmation code has been sent to your mobile phone");				
					
				} catch (OperationFailedException exception) {
					logger.error("Exception while Updating the phone number during user Registration Account Recovery - {}", 
							new String[]{TrustbrokerWebAppUtil.getUidFromError(exception)},exception);
					logger.error(exception);
					setCurrentActiveItem("useracctrecovery");
					String emailErrorMsg = extractErrorMessageFromOFE(exception);
					if (null != emailErrorMsg)
						setErrorMsg(emailErrorMsg);
					else
						setErrorMsg(tbResources.getString("emailVerificationFailed "));
					setErrorMsg("An error occured while updating your Phone number");
				}	
			} else if (SECQUESTS_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {
				if(!validateSecurityAnswers("actrcy")) {
					setCurrentActiveItem("useracctrecovery");
					return;
				}
				
				userVO.setSecEmailAddress(null);
				
				populateSecurityQuestions(userVO);
				List<String> modifiedUserAttrLst = new ArrayList<String>();
				modifiedUserAttrLst.add("MODIFY_CHALLENGE_RESPONSE_QUESTIONS");
				isSQChosen = true;
			} 	
			
			//setCurrentUserVO(userVO);
			if(!isDisplaySkipOption()){
				boolean returnFlag = registerNewUser();
				if(returnFlag) {
					return;
				}
			} else {
				userProfileServiceRequest.setUser(userVO);
				UserVO essoUserVO = container.getUserService().fetchUserProfile(userVO.getUuId(),true, true).getUser();
				userProfileServiceRequest.setOldUser(essoUserVO);
				container.getUserService().modifyUser(userProfileServiceRequest, false);
			}
			
			if(!isPrimaryEmailChosen){
				
				if(isSQChosen){
					setCurrentUserVO(userVO);
					redirectToView("/views/congratulations.jsf");
				}
			}
			
			
			ctx.setHideUpdateButtons(false);
			ctx.setShowDeviceRegistration(isRsaReqdForRP());
			ctx.setNextView("/views/congratulations.jsf");
			ctx.setUserVO(userVO);
			getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);	
			
			if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {
				redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
				return;
			}
			
		}
	}
	
	private boolean UserRegistration() {
		try {		
			UserProfileServiceRequest userProfileServiceRequestObj = new UserProfileServiceRequest();
			VerifyCodesContext ctxObj = new VerifyCodesContext();
			String rpAppIdValue=null;
			
			userProfileServiceRequestObj.setUser(userVO);
			// TODO remove confirmation url from service/email message
			userProfileServiceRequestObj.setConfirmationUrl("");
			userProfileServiceRequestObj.setDidNotRegisteredUrl(constructURL("/views/notregistered.jsf?UserId="));
			userProfileServiceRequestObj.getUser().setRpId(getRelyingPartyApAlias(true));
			
	   		 if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)!= null)
	   			    rpAppIdValue = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
	   		 if(getSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL)!=null && 
	   				 getSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL).equals(userVO.getEmailAddress()))
	   			userProfileServiceRequestObj.setPreVerify(true);
				UserProfileServiceResponse response = container.getUserService().registerUser(userProfileServiceRequestObj, false,
						getVerificationCodeRequest(CommunicationChannel.PRIMARY_EMAIL, userVO));
	
				logger.debug("Status code: " + response.getExecutionStatus().getStatusCd() + " Status Message: " + 
						response.getExecutionStatus().getStatusMessage());
				SecurityLoggingUtil.info("User Registration", SecurityEventType.E3_CREATE, getServletRequest(), userVO.getUserName(),
						"Security Audit Event|RegisterUser:SUCCESS | User Registered, UserRegistrationBean:pageChanged()",
						SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_CREATE_USER);
				
				userVO.setUuId(response.getUser().getUuId());
				//courtesy email
				InvitationVO invitationVO = (InvitationVO) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION);
				String emailId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL);
				String courtesyEmail = null;
				
				if(invitationVO != null) {
					updateUserInvitaion(response.getUser());
					courtesyEmail = invitationVO.getInvtnToEmail();
				} else if(StringUtils.isNotEmpty(emailId)) {
					courtesyEmail = emailId;
				}
				if(StringUtils.isNotEmpty(courtesyEmail) && !userVO.getEmailAddress().equalsIgnoreCase(courtesyEmail)) {
					container.getUserService().sendUserEmailUpdInfo(courtesyEmail, userVO, rpAppIdValue,
							getUrlLogoOptumId(), getUrlLogoRelyingParty());
					logUserEmailUpdate(TrustBrokerWebAppConstants.REGN_EMAIL_UPD_MSG+"UserRegistrationBean.pageChanged()", 
							userVO, courtesyEmail, TrustBrokerConstants.REGN_EMAIL_UPD_ACTIVITY);
				}
				
				createUserSMSession(userVO.getUserName());
			}
			catch (OperationFailedException ope) {
				logger.error("Exception during user registration on submit - {}" , new String[]{TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
				logger.error(ope);
				setErrorMsg(extractErrorMessageFromOFE(ope));				
				if(ope.getMessage().contains("User persistence failed at TB database and ESSO User deleted"))
					setCurrentActiveItem("failure");
				else if (ope.getMessage().contains(tbResources.getString("blackListedPasswordMsg")))
				{
					addFacesMessage("userRegistrationId:pwd",
							tbResources.getString("blackListedPasswordMsg"));
					setErrorMsg("");
					setCurrentActiveItem("personalInformation");
				}
				else
					setCurrentActiveItem("personalInformation");
				return false;
			}
		return true;
	}
	
	
	
	private boolean registerNewUser() {
		try {		
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			VerifyCodesContext ctx = new VerifyCodesContext();

			userProfileServiceRequest.setUser(userVO);
			// TODO remove confirmation url from service/email message
			//userProfileServiceRequest.setConfirmationUrl("");
			
			//to be removed
			String confirmationUrl = constructURL("/views/registeremailconfirmation.jsf");
			confirmationUrl = constructConfirmationUrlWithParams(userVO, confirmationUrl, false);
			userProfileServiceRequest.setConfirmationUrl(confirmationUrl);
			//to be removed
			
			userProfileServiceRequest.setDidNotRegisteredUrl(constructURL("/views/notregistered.jsf?UserId="));
			userProfileServiceRequest.getUser().setRpId(getRelyingPartyApAlias(true));
			String rpAppId = getRelyingPartyAppId();
			if (getSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL)!=null && 
	   				 getSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL).equals(userVO.getEmailAddress()))
	   			 userProfileServiceRequest.setPreVerify(true);
			UserProfileServiceResponse response = container.getUserService().registerUser(userProfileServiceRequest, true, 
					getVerificationCodeRequest(CommunicationChannel.PRIMARY_EMAIL, userVO));
	
				logger.debug("Status code: " + response.getExecutionStatus().getStatusCd() + " Status Message: " + 
						response.getExecutionStatus().getStatusMessage());
				SecurityLoggingUtil.info("User Registration", SecurityEventType.E3_CREATE, getServletRequest(), userVO.getUserName(),
						"Security Audit Event|RegisterUser:SUCCESS | User Registered, UserRegistrationBean:pageChanged()",
						SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_CREATE_USER);
				
				createUserSMSession(userVO.getUserName());
				
				userVO.setUuId(response.getUser().getUuId());
				//courtesy email
				InvitationVO invitationVO = (InvitationVO) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION);
				String emailId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL);
				String courtesyEmail = null;
				
				if(invitationVO != null) {
					updateUserInvitaion(response.getUser());
					courtesyEmail = invitationVO.getInvtnToEmail();
				} else if(StringUtils.isNotEmpty(emailId)) {
					courtesyEmail = emailId;
				}
				if (StringUtils.isNotEmpty(courtesyEmail) && !userVO.getEmailAddress().equalsIgnoreCase(courtesyEmail)) {
					container.getUserService().sendUserEmailUpdInfo(courtesyEmail, userVO, rpAppId, getUrlLogoOptumId(),
							getUrlLogoRelyingParty());
					logUserEmailUpdate(TrustBrokerWebAppConstants.REGN_EMAIL_UPD_MSG+"UserRegistrationBean.pageChanged()", 
							userVO, courtesyEmail, TrustBrokerConstants.REGN_EMAIL_UPD_ACTIVITY);
				}
				
				if (StringUtils.isNotBlank(userVO.getEmailAddress())) {
					ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
				}

				if (StringUtils.isNotBlank(this.acctRecoveryMethod)) {
					if (SECEMAIL_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {				
						ctx.getViewChannels().add(CommunicationChannel.SECONDARY_EMAIL);
						ctx.getSendChannels().add(CommunicationChannel.SECONDARY_EMAIL);
					}
					else if (MOBILE_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {
						ctx.getViewChannels().add(CommunicationChannel.PHONE);
						ctx.getSendChannels().add(CommunicationChannel.PHONE);
					}else if(SECQUESTS_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)){
						
						if(!isPrimaryEmailChosen){
							skipverifyCodeFlow = true;
						}
						
					}
				}
				
				if(!skipverifyCodeFlow){
				ctx.setHideUpdateButtons(false);
				ctx.setShowDeviceRegistration(isRsaReqdForRP());
				ctx.setNextView("/views/congratulations.jsf");
				ctx.setUserVO(userVO);
				getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);
				if (TBUtil.isProdEnv() || isEmailConfirmationRequired() && !response.getUser().isIsemailVerified()) {
					redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
					return true;
				}
				else {
					checkRelyingPartyTrust();
					if (userProfileServiceRequest.isPreVerify()) {
						setCurrentActiveItem("autologin");
					}
					else {
						ctx.setAutoVerify(true);
						if(StringUtils.isNotBlank(response.getEmailConfirmationCode())) {
							ctx.getPrePopulatedCodes().put(CommunicationChannel.PRIMARY_EMAIL, response.getEmailConfirmationCode());
						}
						redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
						return true;
					}
				}
				
				}

              if(skipAccountRecoveryFlow){
					setCurrentUserVO(userVO);
					redirectToView("/views/congratulations.jsf");
					return true;
				}
			}
			catch (OperationFailedException ope) {
				logger.error("Exception during user registration on submit - {}" , new String[]{TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
				logger.error(ope);
				setErrorMsg(extractErrorMessageFromOFE(ope));				
				if(ope.getMessage().contains("User persistence failed at TB database and ESSO User deleted"))
					setCurrentActiveItem("failure");
				else if (ope.getMessage().contains(tbResources.getString("blackListedPasswordMsg"))) {
					setErrorMsg("");
					addFacesMessage("userRegistrationId:pwd",tbResources.getString("blackListedPasswordMsg"));
					clearPasswordFields();
					setCurrentActiveItem("personalInformation");
				} 
				else setCurrentActiveItem("personalInformation");
			}
		return false;
	}
	
	//to be removed
	public String constructConfirmationUrlWithParams(UserVO userVO, String confirmationUrl, boolean addUpdateProfileParam){
		String verificationDetails = "";
		String inbSSO = (String)getSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO); // Inbound SSO scenario
		if(inbSSO != null) inbSSO = container.getCryptAgentUtil().getCryptAgent().encrypt(inbSSO);
		
		if(StringUtils.isNotBlank(userVO.getEmailAddress()) && StringUtils.isNotBlank(userVO.getUuId())){
			Map<String, String> userDetails = new HashMap<String, String>();
			userDetails.put(TrustBrokerWebAppConstants.KEY_USER_UUID, userVO.getUuId());
			userDetails.put(TrustBrokerWebAppConstants.KEY_USER_EMAIL, userVO.getEmailAddress());
			verificationDetails =  container.getCryptAgentUtil().getCryptAgent().createToken(userDetails);
			confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl, TrustBrokerConstants.VERIFICATION_DETAILS, verificationDetails);
		}else {
			verificationDetails = "{0}";
			confirmationUrl += ("?" + TrustBrokerConstants.VERIFICATION_DETAILS + "=" + verificationDetails);
		}
		
		if ((getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null || 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF) != null ) 
				&& getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null) {
			
			String target = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null ? 
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL).toString() : 
						getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF).toString();
			
			confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl,TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, 
					(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl,TrustBrokerWebAppConstants.TARGET, target);
			
			if(addUpdateProfileParam){
				confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl,TrustBrokerWebAppConstants.ACTION, 
						TrustBrokerWebAppConstants.UPDATE_PROFILE);
				confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl,TrustBrokerWebAppConstants.STATUS, 
						TrustBrokerWebAppConstants.SUCCESS);
			}
			
			if(inbSSO != null){
				confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl,TrustBrokerWebAppConstants.INBOUND_SSO, inbSSO);
			}
			
			confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl,TrustBrokerWebAppConstants.VERIFY_EMAIL_CODE_PARAM, "");
			
		} else{
			if(inbSSO != null) confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl,TrustBrokerWebAppConstants.INBOUND_SSO, inbSSO); 
			confirmationUrl = HttpUtils.addParameterToURL(confirmationUrl,TrustBrokerWebAppConstants.VERIFY_EMAIL_CODE_PARAM,"");
		}
		
		return confirmationUrl;
	}
	
	/**
	 * This method is used to log audit event when an user email id is changed.
	 * 
	 * @param msg event message. 
	 * @param userVO UserVO containing user info
	 */	
	private void logUserEmailUpdate(String msg, UserVO userVO, String email, String activity){
				
		msg = "Security Audit Event|"+msg+ "## uuid: ^^"+userVO.getUuId()+"!!";
		IrmLoggingUtil.info( activity,SecurityEventType.E3_MODIFY, getServletRequest().getRemoteAddr(),
				getServletRequest().getLocalAddr(),getServletRequest().getSession().getId(), 
				 userVO.getUserName(), msg, SecurityEventResult.SUCCESS, getRelyingPartyAppId(), email, "", SecuritySubEventType.E3_MODIFY_EMAIL);
	}
	
	protected void checkRelyingPartyTrust() {
		
		//String loginTarget = null;		
		//String rpAliasName = null;
		if (isSessionAttributeExists(TrustBrokerWebAppConstants.RELYING_APP_ID)) {

			String relyingAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString();
			RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
			
			logger.debug("checkRelyingPartyTrust() - relyingPartyApp: " + relyingPartyAppVO);

			if (relyingPartyAppVO == null) {
				relyinPartyTrusted = false;
				relyingAppTrustErrorMessage = tbResources.getString("invalidRelyingAppMsg");
			}
			else if (isSessionAttributeExists(TrustBrokerWebAppConstants.RELYING_APP_URL)) {
				addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
				try {
					String rpDomainName = TBUtil.getDomainName(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL).toString());
					boolean isdomainValid=false;
					if(relyingPartyAppVO.getRpAppDomains()!=null&&relyingPartyAppVO.getRpAppDomains().size()>0)
						isdomainValid=isDomainValid(relyingPartyAppVO.getRpAppDomains(),rpDomainName);
					else
						isdomainValid=relyingPartyAppVO.getAppDomainName().equals(rpDomainName);
					if (relyingPartyAppVO!=null && !isdomainValid){
						relyinPartyTrusted = false;
						relyingAppTrustErrorMessage = tbResources.getString("securityThreatMsg");
					}
				} catch (URISyntaxException e) {
					logger.error(e.getMessage());
				}
			}
			
			if(relyinPartyTrusted){
				removeSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET);
				String loginTarget = HttpUtils.addParameterToURL(this.targetUrl, 
						TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, relyingPartyAppVO.getAlias());
				loginTarget = HttpUtils.addParameterToURL(loginTarget, TrustBrokerWebAppConstants.TARGET, 
						(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL));
				loginTarget = HttpUtils.addParameterToURL(loginTarget, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, relyingAppId);
				addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, loginTarget);
			}
		}
		/*if(loginTarget == null || loginTarget.length() <= 0) {
			loginTarget = HttpUtils.addParameterToURL(this.targetUrl, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, 
							TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE);				
		}
		if(rpAliasName == null) {
			rpAliasName = TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE;
		}
		String authType = getRPAuthType(rpAliasName);
		String adapAuthUrl = QNA_AA_REDIRECT_URL;
		if(AuthenticationType.SECURITY_QUESTIONS.name().equals(authType)) {
			adapAuthUrl = QNA_AA_REDIRECT_URL;
		} else if(AuthenticationType.OTPEMAIL.name().equals(authType)) {
			adapAuthUrl = OTP_AA_REDIRECT_URL;
		} else if(AuthenticationType.PASSWORD.name().equals(authType)) {
			adapAuthUrl = NO_RSA_AA_REDIRECT_URL;
		} 
		
		removeSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET);
		String aaRedirectUrl = HttpUtils.addParameterToURL(adapAuthUrl, TrustBrokerWebAppConstants.AA_REDIRECT_PARAM, decodeURL(loginTarget));
		addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, aaRedirectUrl);*/
	}
	
	private String decodeURL(String url) {
		String decodedUrl = null;
		if(url != null) {			
			try {
				decodedUrl =  URLDecoder.decode(url, HttpUtils.DEFAULT_URL_ENCODING);
			} catch (UnsupportedEncodingException e) {
				decodedUrl = url;
			}
		}		
		return decodedUrl;
	}
	
	private String getRPAuthType(String rpId) {
		
		String rpAuthType = null;
		QueryRelyingPartyResponse response = container.getConfigService().queryRelyingParty(rpId);
		if (response != null && ResponseTypeCode.SUCCESS.equals(response.getStatus())) {
			RelyingParty relyingParty = response.getRelyingParty();
			if(relyingParty != null && relyingParty.getTiers() != null && !relyingParty.getTiers().isEmpty()) {		
				TierConfig tierConfig = relyingParty.getTiers().get(0);
				List<AuthenticationType> authTypes = tierConfig.getAuthenticationTypes();
				if(authTypes != null) {
					AuthenticationType authType = null;
					Iterator<AuthenticationType> authTypeItr = authTypes.iterator();
					while(authTypeItr.hasNext()) {
						authType = authTypeItr.next();
						rpAuthType = authType.name();
						if(!AuthenticationType.PASSWORD.name().equalsIgnoreCase(rpAuthType)) {							
							return rpAuthType;
						}
					}
				}
			}
		}
		
		return rpAuthType;
	}
	
	public boolean isDomainValid(List<RPAppDomainVO> domains,String domainName){		
		return TBUtil.isDomainValid(domains, domainName);
	}
	
	public void updateEmailAddress() {
		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(userVO);
		UserVO essoUserVO = container.getUserService().fetchUserProfile(userVO.getUuId(),true, true).getUser();
		userProfileServiceRequest.setUser(essoUserVO);
		container.getUserService().modifyUser(userProfileServiceRequest, true);
		try {
			// TODO this is in VerfiyCodesBean?
			//verifyCodesBean.resendPrimaryEmailCode();
			setErrorMsg("A new confirmation code has been sent to your new email address");
		}
		catch (OperationFailedException e) {
			logger.error(e);
			setErrorMsg("An error occured while updating your email address");
		}
	}
	
	private void populateSecurityQuestions(UserVO userVO) {
		List<UserChallengeQuestionVO> securityQuestions = new ArrayList<UserChallengeQuestionVO>();
		UserChallengeQuestionVO question1 = new UserChallengeQuestionVO();
	
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();		
		String secQuestion1Array[] = secQuestion1.split("_");
		question1.setQuestionId(secQuestion1Array[0]);
		question1.setQuestion(secQuestion1Array[1]);
		question1.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerOne());

		UserChallengeQuestionVO question2 = new UserChallengeQuestionVO();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion2Array[] = secQuestion2.split("_");
		question2.setQuestionId(secQuestion2Array[0]);
		question2.setQuestion(secQuestion2Array[1]);
		question2.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerTwo());

		UserChallengeQuestionVO question3 = new UserChallengeQuestionVO();
		String secQuestion3 = tbSecurityQuestionsBean
				.getSecurityQuestionThree();
		String secQuestion3Array[] = secQuestion3.split("_");
		question3.setQuestionId(secQuestion3Array[0]);
		question3.setQuestion(secQuestion3Array[1]);
		question3.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerThree());

		securityQuestions.add(question1);
		securityQuestions.add(question2);
		securityQuestions.add(question3);
		userVO.setUserChallengeQuestions(securityQuestions);
	}

	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	public void userNameChanged(ValueChangeEvent e) {
		validateUserName(e.getNewValue().toString());
	}
	
	private boolean validateUserName(String enteredUserName) {
		
		boolean isUserNameRegExValidated = TBUtil.validateRegEx(enteredUserName, tbResources.getString("userNameRegEx"));
		setTempUserName("");
		
		if (!isUserNameRegExValidated) {
			userNameSuggestionsList = new ArrayList<String>();
			addFacesMessage("userRegistrationId:userNameId", tbResources.getString("invalidUserName"));
			return false;
		} else {
			userNameSuggestionsList = new ArrayList<String>();
			setShowSugestions(false);
			userVO.setUserName(enteredUserName);

			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(userVO);
			
			UserNameCheckServiceResponse resp = container.getUserService().checkUserNameAvailability(userProfileServiceRequest);
			if(resp != null) {
				if(!resp.isUserNameAvailable()) {					
					List<String> userNameSuggestionsFromWS = resp.getUserSuggestions();
					if (null != userNameSuggestionsFromWS && userNameSuggestionsFromWS.size() > 0) {						
						setUserNameSuggestionsList(userNameSuggestionsFromWS);
						setOldUsernameSuggestionsList(userNameSuggestionsFromWS);
						addFacesMessage("userRegistrationId:userNameId", tbResources.getString("userNameNotAvailable"));
						setShowSugestions(true);													
					}	else {
						addFacesMessage("userRegistrationId:userNameId", tbResources.getString("userNameNotAvailNoSuggstn"));
						setShowSugestions(false);	
					}
					return false;
				}				
			}
			
		}
		return true;
	}
	
	public void checkNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultFirstName = TBUtil.validateName(userVO.getFirstName());
			if (!resultFirstName ) {
				addFacesMessage("userRegistrationId:firstName",tbResources.getString("numericSpecialCharMsgOldGen"));
			}
		}
	}
	
	public void checkmiddleNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultMiddleName = TBUtil.validateName(userVO.getMiddleName());
			if ( !resultMiddleName) {
				addFacesMessage("userRegistrationId:middleName",tbResources.getString("middlenumericSpecialCharMsgOldGen"));
			}
		}
	}
	
	public void checkLastNameField(ValueChangeEvent event) {
		specialCharsMsg = "";
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean resultLastName = TBUtil.validateName(userVO.getLastName());
			if ( !resultLastName) {
				addFacesMessage("userRegistrationId:lastName",tbResources.getString("lastnumericSpecialCharMsgOldGen"));
			}
		}
	}
	
	public void checkdateOfBirth(ValueChangeEvent event) {
		
		
		PhaseId phaseId = event.getPhaseId();
				
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			
			//boolean resultDob = validateDate("userRegistrationId:dobId", dateOfBirth);
			boolean resultDob = validateDateCoppa("userRegistrationId:dobId", dateOfBirth, false);
			
			if (!resultDob) {
				setErrorMsg(tbResources.getString("formNotSubmitted")); // form level error message
				return; // no need to check it further
			}
			
			// covert date to MM/dd/yyyy format if the input format is MMddyyyy
			// this method is only for UI requirement
			changeDateFormat(dateOfBirth);
			
		}
	}
	
	// dob related validation - starts
	/**
	 * single entry point for performing date validation for screens like registration and step up.
	 * 
	 * coppaCheckRequired introduced as coppa check is not done during ajax validation
	 * 
	 * **/
	public boolean validateDateCoppa(String componentID, String dobStr, boolean coppaCheckRequired){
		
		boolean isValid = false;
		isValid = validateDate(componentID, dobStr);
		if(!isValid) {
			return isValid;
		}
		if(coppaCheckRequired == true) {
			isValid = validateCoppa(componentID, dobStr, isCoppaValidationReqd());
		}
		
		return isValid;
	}
	
	
	public boolean validateCoppa(String componentID, String dateOfBirth, boolean coppaRequired) {
		
		boolean maxAttemptsRemaining = checkYearOfBirthEntryLimit();
		if(!maxAttemptsRemaining) {
			return false;
		}
		
		if (coppaRequired == true && checkYearOfBirthEntryLimit()) {
			
			boolean isValid = DateUtil.validateAgeMultipleFormats(dateOfBirth, MIN_AGE_LIMIT);
			
			if (isValid == false) {
				getFacesContext().addMessage(componentID, new FacesMessage(tbResources.getString("yobAgeConstraintMsg")));
				incrementIncorrectYobCount();
				return false;
			}
			
		} 
		
		return true;
	}
	
	private void changeDateFormat(String dateOfBirth) {
		// covert date to MM/dd/yyyy format if the input format is MMddyyyy
		String convertedDate = DateUtil.formatDate(dateOfBirth, DateUtil.EXT_DATE_FORMAT3, DateUtil.EXT_DATE_FORMAT);
		if(!StringUtils.isEmpty(convertedDate)) {
			this.dateOfBirth = convertedDate;
			setRenderDOB(true);
		}				
	}
	// dob related validation - ends
	
	public void checkEmailAddress(ValueChangeEvent event) {
		emailExistsMsg = "";
		showEmail = false;
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			validateEmailAddress(event.getNewValue().toString());
			
			// This validation is for displaying the error message for SQ after hide and display
			//validateSecurityAnswersForSharedEmail("");
			
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean result = TBUtil.validateEmailId(event.getNewValue()
					.toString());
			logger.debug("result value in email: " + result);
			if (!result) {
				addFacesMessage("userRegistrationId:email",
						tbResources.getString("invalidEmailAddress"));
			}
		}
		logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg());
	}
	
	public boolean validateEmailAddress(String email) {
		boolean result = true;
		String rpName ="";
		removeSessionAttribute("warnmsg");
		showSecQuestionBasedonSharedEmail=false;
		
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_NAME)!=null)
			rpName = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_NAME).toString();
			
		if (isEmailMandatory()) {

			if (StringUtils.isEmpty(email)) {
					if(StringUtils.isEmpty(getConfirmEmailAddress()))
						addFacesMessage("userRegistrationId:confirmEmail",	tbResources.getString("confirmEmailRequired"));
				addFacesMessage("userRegistrationId:email",	tbResources.getString("rpDoNotSupportEmptyEmail"));
				result = false;
			} else if (!TBUtil.validateEmailId(email)) {
				addFacesMessage("userRegistrationId:email",
						tbResources.getString("invalidEmailAddress"));
				result = false;
			} else if (!isEmailShared()
					&& container.getUserService().isEmailExists(email)) {
				showEmail = true;
				addFacesMessage("userRegistrationId:email",
						tbResources.getString("rpDoNotDuplicateEmail"));
				result = false;

			}
			else if(isEmailShared()&& container.getUserService().isEmailExists(email))
			{
				addFacesMessage("userRegistrationId:email",
						tbResources.getString("duplicateEmailWarn1"));
				addSessionAttribute("warnmsg", true);
				showSecQuestionBasedonSharedEmail=true;
				
			}
		
			if (StringUtils.isEmpty(getConfirmEmailAddress()) && getConfirmEmailAddress()!= null) {
				addFacesMessage("userRegistrationId:confirmEmail",	tbResources.getString("confirmEmailRequired"));
				result = false;
			} 
			
		} else {
			if (!isEmailShared()) {
				if (!TBUtil.validateEmailId(email)) {
					addFacesMessage("userRegistrationId:email",
							tbResources.getString("invalidEmailAddress"));
					result = false;
				} else if (!StringUtils.isEmpty(email)
						&& container.getUserService().isEmailExists(email)) {
					showEmail = true;
					addFacesMessage("userRegistrationId:email",
							tbResources.getString("rpDoNotDuplicateNonMandatoryEmail"));
					result = false;
				}

			}else {
				
			 if (!TBUtil.validateEmailId(email)) {
					addFacesMessage("userRegistrationId:email",
							tbResources.getString("invalidEmailAddress"));
					result = false;
				}
				
			if(email != null && email!= "" && container.getUserService().isEmailExists(email))
			{
				addFacesMessage("userRegistrationId:email",
						tbResources.getString("duplicateEmailWarn1"));
				addSessionAttribute("warnmsg", true);
				showSecQuestionBasedonSharedEmail=true;
				
			}

		}
		}
		
		
		return result;

	}
	
	
	public boolean validateFirstNameLastNameFields(){
		boolean retValue = true;
		
		boolean resultFirstName = TBUtil.validateName(userVO.getFirstName());
		boolean resultLastName = TBUtil.validateName(userVO.getLastName());
		
		boolean resultMiddleName =TBUtil.validateName(userVO.getMiddleName()); 
		
		if (!resultFirstName ) {
			addFacesMessage("userRegistrationId:firstName",tbResources.getString("numericSpecialCharMsg"));
			retValue = false;
		} 
		
		
		if (! resultLastName) {
			addFacesMessage("userRegistrationId:lastName",tbResources.getString("lastnumericSpecialCharMsg"));
			retValue = false;
		} 
		
		if (! resultMiddleName) {
			addFacesMessage("userRegistrationId:middleName",tbResources.getString("middlenumericSpecialCharMsg"));
			retValue = false;
		} 
		
		
		
		return retValue;
	}

	
	public void checkEmailAddressSec(ValueChangeEvent event) {
		emailExistsMsgSec = "";
		showEmail = false;
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
			// validateEmailFormat(event.getNewValue().toString());
			logger.debug("result value in email: " + result);
			if (!event.getNewValue().toString().isEmpty()&&!result) {
				setEmailExistsMsgSec(tbResources.getString("invalidEmailAddress"));
			}
		}
		logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg());
	}
	
	
	public void checkConfirmEmailAddress(ValueChangeEvent event) {
	
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			/*boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
			// validateEmailFormat(event.getNewValue().toString());
			logger.debug("result value in email: " + result);
			if (!event.getNewValue().toString().isEmpty()&&!result) {
				addFacesMessage("userRegistrationId:confirmEmail",
						tbResources.getString("invalidEmailAddress"));
			}else if(event.getNewValue().toString().isEmpty()){
				addFacesMessage("userRegistrationId:confirmEmail",
						tbResources.getString("confirmEmailRequired"));*/
			//}
		}
		//logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg());
	}
	public void userNameImageClick(AjaxBehaviorEvent evt) {
		if (null != this.userVO.getUserName())
			validateUserName(this.userVO.getUserName());
	}
	
	public boolean isSecEmailExists(String email){
		return  container.getUserService().isEmailExists(email);
	}
	
	public void userSuggestionSelected(ValueChangeEvent e) {
	
		if (e.getNewValue() != null) {
			logger.debug("e.getnewvalue: " + e.getNewValue());
			String userSuggestionSelectedValue = e.getNewValue().toString();
			if (null != userSuggestionSelectedValue) {
				if (userNameSuggestionsList != null
						&& userNameSuggestionsList.contains(e.getNewValue()
								.toString()))
					userVO.setUserName(userSuggestionSelectedValue);
			}
		}
	}

	// TODO remove this
	//Method to redirect into relying party url after successful registration
	public String continueToApp() {
		
		if(relyinPartyTrusted){
			return fetchUserProfile();
		}else{
			relyingAppErroMsg = relyingAppTrustErrorMessage;
		}
		return null;
	}

	private String fetchUserProfile() {
		FacesContext context = getFacesContext();
		UserRetrievalServiceResponse userRetrievalResponse = null;
		ExecutionStatus executionStatus = null;
		UserVO user = null;

		try {
			userRetrievalResponse = container.getUserService().fetchUserDetailsForSession(userVO.getUserName());
		} catch (OperationFailedException exception) {
			logger.error("LoginBean::fetchUserProfile()::Failed to fetch profile " + userVO.getUserName(), exception);
			logger.error(exception);
			context.addMessage(null, new FacesMessage("Invalid Username or Password"));
		}

		if(userRetrievalResponse != null ){
			executionStatus = userRetrievalResponse.getExecutionStatus();
			user = userRetrievalResponse.getUser();
		}

		if (executionStatus != null && executionStatus.getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE) && user != null) {
			logger.info("LoginBean::fetchUserProfile()::ExecutionStatus" + TrustBrokerConstants.SUCCESS_CODE_VALUE);
			setCurrentUserVO(user);
			return getHomePageURIWithAlias();
		} else {
			logger.info("LoginBean::fetchUserProfile()::ExecutionStatus" + TrustBrokerConstants.FAILURE_CODE_VALUE);
			context.addMessage(null, new FacesMessage("Invalid Username or Password"));
			return null;
		}
	}

	public String displayRelyingPartyNotTrustedMsg(){
		relyingAppErroMsg = relyingAppTrustErrorMessage;
		return null;
	}

	public boolean getRelyinPartyTrusted() {
		return relyinPartyTrusted;
	}

	public void setRelyinPartyTrusted(boolean relyinPartyTrusted) {
		this.relyinPartyTrusted = relyinPartyTrusted;
	}

	public String getRelyingAppErroMsg() {
		return relyingAppErroMsg;
	}

	public void setRelyingAppErroMsg(String relyingAppErroMsg) {
		this.relyingAppErroMsg = relyingAppErroMsg;
	}


	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public String getLocalenv() {
		return localenv;
	}

	public void setLocalenv(String localenv) {
		this.localenv = localenv;
	}
	public boolean isTncAccepted() {
		return true;
	}

	public void setTncAccepted(boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}

	public boolean isPrivacyPolicyAccepted() {
		return privacyPolicyAccepted;
	}

	public void setPrivacyPolicyAccepted(boolean privacyPolicyAccepted) {
		this.privacyPolicyAccepted = privacyPolicyAccepted;
	}

	public boolean isDecryptionfailed() {
		return decryptionfailed;
	}

	public void setDecryptionfailed(boolean decryptionfailed) {
		this.decryptionfailed = decryptionfailed;
	}

	public String signInClicked() {
		logger.debug("LoginBean:signInClicked| Relying Party URL '"+ 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL)+"' Relying Party ID'"+
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
		removeSessionAttribute("warnmsg");
			
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null &&
			getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null){
			{
				String url=(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
				if(StringUtils.isNotBlank(url))
					{ if(StringUtils.contains(url, "INVITATION_CODE"))
						{
							url=StringUtils.split(url,"?")[0];
							addSessionAttribute(TrustBrokerWebAppConstants.TARGET, url);						
						}
					}
				if(getSessionAttribute(TrustBrokerWebAppConstants.INVITATION) != null) {
					addSessionAttribute(TrustBrokerWebAppConstants.INVITATION_REGN_SIGNIN, "true");
				}
				logger.debug("LoginBean:signInClicked| Relying Party URL Modifed: '"+getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL));
				return constructURLWithRPParams(signInPage);
			}
		}	else return signInPage;
	}
	
	
	private void captureInvitationInfo(Map<String, String> invitationMap){
		String invitation = getRequestParameter(TrustBrokerWebAppConstants.INVITATION);
		if(invitation != null && !"".equals(invitation)){
			try{
				invitationMap = container.getInvitationService().decodeInvitationDetails(invitation);
				String token = invitationMap.get(InvitationConstants.KEY_INVITATION_TOKEN);
				String relyingAppId = invitationMap.get(InvitationConstants.KEY_REPLYING_PARTY_APP_ID);
				
				RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
			
				InvitationServiceResponse invitationServiceResponse = container.getInvitationService().getInvitationByTokenAndRelyingAppId(token, relyingAppId);
				
				if(invitationServiceResponse.getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)){
					InvitationVO invitationVO = invitationServiceResponse.getInvitationVO();
					
					int invtnExpirationDays = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userInvitationExpiration"));
					
					if(TrustBrokerWebAppConstants.REGISTERED.equals(invitationVO.getInvtnStts().getStatusState()) || 
							invitationVO.getInvtnAccptdDttm() != null){
						
						addSessionAttribute("error", tbResources.getString("invitationUsed"));
						redirectToView("/views/userInvitationRegistrationFailure.jsf");
						return;
					} else if( (TrustBrokerWebAppConstants.EXPIRED.equals(invitationVO.getInvtnStts().getStatusState())) || 
							(invitationVO.getInvtnExprtnDttm() != null && 
							invitationVO.getInvtnExprtnDttm().before(DateUtil.getInstance().getCurrentDateTime())) || 
							(invitationVO.getInvtnGenDttm() != null && invitationVO.getInvtnExprtnDttm() == null &&
								DateUtil.validateDateByDays(invitationVO.getInvtnGenDttm(), invtnExpirationDays))){
						
						addSessionAttribute("error", tbResources.getString("invitationExpired"));
						redirectToView("/views/userInvitationRegistrationFailure.jsf");
						return;
					} else {
						userVO.setEmailAddress(invitationVO.getInvtnToEmail());
						invitationVO.getInvitationCtxProperties();
						Iterator<InvitationContextPropertyVO> ctxPropertyIterator = invitationVO.getInvitationCtxProperties().iterator();
						String username = null;
						while (ctxPropertyIterator.hasNext()){
							InvitationContextPropertyVO invitationContextPropertyVO = ctxPropertyIterator.next();
							if(invitationContextPropertyVO.getName()!=null)
							{
								if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.FIRSTNAME)) {
									userVO.setFirstName(invitationContextPropertyVO.getValue());
								} else if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.MIDDLENAME)){
									userVO.setMiddleName(invitationContextPropertyVO.getValue());
								} else if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.LASTNAME)) {
									userVO.setLastName(invitationContextPropertyVO.getValue());
								} else if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.USERNAME)) {
									username = invitationContextPropertyVO.getValue();
								} else if(invitationContextPropertyVO.getName().equalsIgnoreCase(TrustBrokerConstants.DOB)) {
									SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
									sdf.setLenient(false);
									Date testDate = null;
									boolean isDOBvalid = false;
									String strDate = invitationContextPropertyVO.getValue();
									try {
										testDate= sdf.parse(strDate);
										isDOBvalid = true;
								    } catch (ParseException e){
										isDOBvalid = false;
								    }
									if(isDOBvalid)
									dateOfBirth =new SimpleDateFormat("MM/dd/yyyy").format(testDate);
								}
							}
						}
						if(username != null) {
							//Process username from invitation context property
							processInvtnUsername(username);
						}						
						addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL, invitationVO.getRpAppTargetURL());
						addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, invitationVO.getRpAppId());
						if (relyingPartyAppVO != null) 
							addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
						setConfirmEmailAddress(invitationVO.getInvtnToEmail());
						addSessionAttribute(TrustBrokerWebAppConstants.INVITATION, invitationVO);
					}
				}else{
					addSessionAttribute("error", tbResources.getString("invitationNotFound"));
					redirectToView("/views/userInvitationRegistrationFailure.jsf");
					return;
				}
			} catch(Exception ex){
				logger.error("UserRegistrationBean:captureInvitationInfo() | Error while processing the invitation information", ex);
			}
		}
	}
	
	/**
	 * This method is to check username from invitation context is valid or not.
	 * 
	 * @param username
	 */
	private void processInvtnUsername(String username) {
		//Check if username is valid
		boolean isUserNameRegExValidated = TBUtil.validateRegEx(username, tbResources.getString("userNameRegEx"));				
		if(isUserNameRegExValidated) {			
			//if username is valid, validate the username rules to check if username is available and set corresponding validation message
			boolean userNameValid = validateUserName(username);
			if(!userNameValid) {
				setInvitationRegnErr(true);
			}
			this.userVO.setUserName(username);						
		}		
	}
	
	/**
	 * This method is to set the default focus in registration screen when the page loads to first required empty field.
	 * 
	 */
	private void setDefaultFocus() {		
		if(StringUtils.isEmpty(userVO.getFirstName())) {
			setFocusField("firstName");
		} else if(StringUtils.isEmpty(userVO.getLastName())) {
			setFocusField("lastName");
		} else if(isShowDob() && StringUtils.isEmpty(getDateOfBirth())) {
			setFocusField("dobId");
		} else if(!isShowDob() && isCoppaValidationReqd() ) {
			setFocusField("yobId");
		} else if(isEmailMandatory() && StringUtils.isEmpty(userVO.getEmailAddress())) {
			setFocusField("email");
		} else if(StringUtils.isEmpty(userVO.getUserName())) {
			setFocusField("userNameId");
		} else {
			setFocusField("pwd");
		}
	}
	
	public String returnToLogin() {
		String relyingPartyRedirectionParams = getRelyingPartyRedirectionParameters();
		if (getCurrentUserVO() != null && isActiveSMSessionForUser(getCurrentUserVO().getUserName())) {
			if(StringUtils.isNotBlank(relyingPartyRedirectionParams)){
				redirectToRelyingParty(
						(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL),
						(String) getSessionAttribute(TrustBrokerWebAppConstants.ACTION),
						(String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS),
						(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			}else{
				redirectToView("/secure/home.jsf?faces-redirect=true");
			}
			return null;
		}
		
		if(StringUtils.isNotBlank(relyingPartyRedirectionParams))
			return "/views/login.xhtml?faces-redirect=true&"+ relyingPartyRedirectionParams;
		else return "/views/login.xhtml?faces-redirect=true";
	}
	
	
	public void processRPreg()
	{
		showQuestions = false;
		setRsaReqdForRP(true);
		String relyingAppId = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		RelyingPartyAppVO rpAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
		//Coppa will be required by default unless configured as N for relying party 
		if(rpAppVO != null && COPPA_REQD_NO_IND.equalsIgnoreCase(rpAppVO.getCoppaReqdInd())) {
			setCoppaValidationReqd(false);
		} else {
			setCoppaValidationReqd(true);
		}
		
		QueryRelyingPartyResponse queryRelyingPartyResponse = container.getConfigService().queryRelyingParty(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS).toString());
		QueryTierResponse queryTierResponse = null;
			if(queryRelyingPartyResponse!=null &&  queryRelyingPartyResponse.getRelyingParty()!=null) {
			RelyingParty rp = queryRelyingPartyResponse.getRelyingParty();
				if(rp.getTiers() != null && rp.getTiers().size() > 0) {
					TierConfig tierConfig = rp.getTiers().get(0);
					userVO.setTierId(tierConfig.getTierId());
					queryTierResponse = container.getConfigService().queryTier(tierConfig.getTierId());
					if(queryTierResponse!=null && queryTierResponse.getTierDefinition()!=null)
					{
						List<TierAttribute> tierAttributes= queryTierResponse.getTierDefinition().getTierAttributes();
						for (Iterator<TierAttribute> iterator = tierAttributes.iterator(); iterator.hasNext();) {
							TierAttribute tierAttribute = iterator.next();
							if(tierAttribute.getName().equalsIgnoreCase(TrustBrokerConstants.DATE_OF_BIRTH) && tierAttribute.isMandatory())
							{
								showDob = true;
							}
							else if (tierAttribute.getName().equalsIgnoreCase(
									TrustBrokerConstants.EMAIL_ADDRESS)) {
								if (!tierAttribute.isMandatory()) {
									emailMandatory = false;
								}
								if (tierAttribute.isUnique()) {
									emailShared = false;
								}

							}
						}
					}
					
					List<AuthenticationType> authenticationTypes= tierConfig.getAuthenticationTypes();
					if(null != authenticationTypes && authenticationTypes.size() == 1) {
						if(authenticationTypes.get(0).value().equalsIgnoreCase(AuthenticationType.PASSWORD.value())){
							showQuestions = false;
							setRsaReqdForRP(false);
						}
					} else {
						for (Iterator<AuthenticationType> iterator = authenticationTypes.iterator(); iterator.hasNext();) {
							AuthenticationType authenticationType = iterator.next();
							if (authenticationType.value().equalsIgnoreCase(AuthenticationType.SECURITY_QUESTIONS.value()))
							{
								showQuestions = true;
							}
						}
					}
				}
		}
	}

	public void checkRecvrySecEmailAddr(ValueChangeEvent event) {
        emailExistsMsg = "";
        showEmail = false;
        PhaseId phaseId = event.getPhaseId();
        
        if (phaseId.equals(PhaseId.ANY_PHASE)) {
               event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
               event.queue();             
               validateRecoverySecEmail(event.getNewValue().toString());                 
        } else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
               boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
               logger.debug("result value in updateEmail: " + result);
               if (!result) {
                      addFacesMessage("userRegistrationId:secEmailAddress",tbResources.getString("invalidEmailAddress"));
               } 
        }
        logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg());
	}

	private boolean validateRecoverySecEmail(String email) {
		boolean validEmail = true;		
		if(StringUtils.isEmpty(email)) {
			addFacesMessage("userRegistrationId:secEmailAddress",tbResources.getString("regnacctrecoverySecEmailReqMsg"));
			validEmail = false;
		} else if(!TBUtil.validateEmailId(email)){
			validEmail = false;
            addFacesMessage("userRegistrationId:secEmailAddress",tbResources.getString("invalidEmailAddress"));
        } else  if ( userVO.getEmailAddress().equalsIgnoreCase(email)) {
        	validEmail = false;
     	   showEmail = true;
     	   addFacesMessage("userRegistrationId:secEmailAddress",tbResources.getString("emailAlreadyExists"));
        }  else if(container.getUserService().isEmailExists(email)){
        		validEmail = false;
          	   showEmail = true;
          	   addFacesMessage("userRegistrationId:secEmailAddress",tbResources.getString("emailAlreadyExists"));
        		
        }
		return validEmail;		
		
		
	}
	/**
	 * This method is change event listener for password, which validates it.
	 * 
	 * @param event
	 */
	public void checkPwd(ValueChangeEvent event) {
		
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();		
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {		
			pwdValidation();
		}
	}
	
	/**
	 * This method is validation method for password field
	 * 
	 * @param context
	 * @param component
	 * @param value
	 */
	public void validatePwd(FacesContext context, UIComponent component, Object value) {   
		userVO.setPassword((String)value);
	    pwdValidation();
	} 
	
	/**
	 * This method is to validate the password and update password flags
	 *
	 */	
	private void pwdValidation() {
		boolean isPwdValid = checkPwdContent();				
		if(!StringUtils.isEmpty(userVO.getPassword()) && !getDummyPasswordVal().equals(userVO.getPassword())) {
			setPasswordValid(isPwdValid);			
			if(isPwdValid) {
				setPassword(userVO.getPassword());				
			} else {
				setConfirmPwdValid(isPwdValid);	
				setPassword("");
			}		
			if(!checkConfmPwdContent()) {
				setConfirmPwdValid(false);	
				setPasswordValid(false);
			}
		}
	}
	
	/**
	 * This method is change event listener for confirm password, which validates it.
	 * 
	 * @param event
	 */
	public void checkConfirmPwd(ValueChangeEvent event) {
		
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();		
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {		
			confPwdValidation();
		}
		
	}
	/**
	 * This method is validation method for confirm password field
	 * 
	 * @param context
	 * @param component
	 * @param value
	 */
	public void validateConfirmPwd(FacesContext context, UIComponent component, Object value) {
	    setConfirmPassword((String)value);
		confPwdValidation();
	} 
	
	/**
	 * This method is to validate the confirm password and update password flags
	 *
	 */	
	private void confPwdValidation() {
		boolean isPwdValid = checkConfmPwdContent();				
		if(!StringUtils.isEmpty(getConfirmPassword()) && !getDummyPasswordVal().equals(getConfirmPassword()) ) {			
			setConfirmPwdValid(isPwdValid);	
			if(!StringUtils.isEmpty(userVO.getPassword())) {
				setPasswordValid(isPwdValid);
			}
			if(isPwdValid) {
				setConfirmPwdSavedVal(getConfirmPassword());
			} else {				
				setConfirmPwdSavedVal("");
			}				
		}
	}
	
/**
 * This method is to validate password.
 * 
 * @return boolean
 */
private boolean checkPwdContent(){
	boolean result=true;
	 HashMap<String, String> validatePwdMap = TrustbrokerWebAppUtil.validatePwdContent(userVO);
	 	
	 	if (userVO.getPassword()!= null && userVO.getPassword().contains(PWD_INVALID_SPL_CHAR)) {
			addFacesMessage("userRegistrationId:pwd",
					tbResources.getString("pwdSplCharErrMasg"));
			result = false;
		}
		if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME)) {
			addFacesMessage("userRegistrationId:pwd",
					  (String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME));
			result=false;
		}
		if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE)) {
			addFacesMessage("userRegistrationId:pwd",
					  (String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE));
			result=false;
		}
		
	/*	if(!TBUtil.validateBlackListedPassword(userVO.getPassword())){
			
			addFacesMessage("userRegistrationId:pwd",
					"The password you entered is frequently used; for your security, please select a more unique password");
			result=false;
			
		}*/
		
		return result;
}
	/**
	 * This method is to validate confirm password and returns true if valid
	 * 
	 * @return boolean
	 */
	private boolean checkConfmPwdContent(){
		boolean result=true;
		String password = userVO.getPassword();
		if(getDummyPasswordVal().equals(password)) {
			password = getPassword();
		}
		String cfmPassword = getConfirmPassword();
		if(getDummyPasswordVal().equals(cfmPassword)) {
			cfmPassword = getConfirmPwdSavedVal();
		}
		if(!StringUtils.isEmpty(password) && !StringUtils.isEmpty(getConfirmPassword()) && !password.equals(cfmPassword)) {
			addFacesMessage("userRegistrationId:confirmPwd",
					tbResources.getString("pwdDoNotMatch"));
			result=false;
		}
		return result;
	}

public void checkyearOfBirth(ValueChangeEvent event) {
	
	PhaseId phaseId = event.getPhaseId();
			
	if (phaseId.equals(PhaseId.ANY_PHASE)) {
		event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
		event.queue();
	} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
		boolean limitNotReached=checkYearOfBirthEntryLimit();
		if(limitNotReached){
		   boolean valid=validateYobFormat(yearOfBirth);
		   if ( !valid) 
			  addFacesMessage("userRegistrationId:yobId", tbResources.getString("yobFormatErrorMsg508"));
		}
	}
}
public void checkPhone(ValueChangeEvent event) {
	
	PhaseId phaseId = event.getPhaseId();
			
	if (phaseId.equals(PhaseId.ANY_PHASE)) {
		event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
		event.queue();
	} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
		
		   validatePhoneMultipleFormats("userRegistrationId:mobilePhone", getMobilePhone());
		
	}
}
public void validatePhone(FacesContext context, UIComponent component, Object value) {

	if (value instanceof String && !StringUtils.isEmpty( (String) value) ) {

		validatePhoneMultipleFormats("userRegistrationId:mobilePhone", (String)value);

	}else{

		errorMsg="This form is not ready to be submitted. Check the highlighted fields – at least one required field is missing information or needs a different format.";
	}
}

private boolean validateYearOfBirth(){
	if(showDob || !isCoppaValidationReqd()) {
		return true;
	}
	
	boolean isYearValid=true;
	if(StringUtils.isEmpty(yearOfBirth)){
		addFacesMessage("userRegistrationId:yobId", tbResources.getString("yobRequiredMsg"));
		isYearValid=false;
		return isYearValid;
	}
	
		
	isYearValid= validateYobFormat(yearOfBirth);
		
	if(!isYearValid){
			addFacesMessage("userRegistrationId:yobId", tbResources.getString("yobFormatErrorMsg508"));
			isYearValid = false;
			return isYearValid;
	}
	
		
	boolean isLimitStillValid=checkYearOfBirthEntryLimit();
	if(isLimitStillValid){
		SimpleDateFormat yearformat = new SimpleDateFormat(DateUtil.YEAR_FORMAT);
	  Integer ageDifference = DateUtil.validateAge(yearOfBirth, MIN_AGE_LIMIT, yearformat);
	  if (ageDifference != DateUtil.OVERAGE   ) {
		  	if(isCoppaValidationReqd()) {
		  		incrementIncorrectYobCount();
		  	}
		    isLimitStillValid=checkYearOfBirthEntryLimit();
		    if(isLimitStillValid){
		    	if(ageDifference == DateUtil.OVERAGEEXEEDED)
			    	  addFacesMessage("userRegistrationId:yobId", tbResources.getString("yobAgeConstraintOverMsg")); 
		    	else  if(ageDifference == DateUtil.FUTURE)
		    	  addFacesMessage("userRegistrationId:yobId", tbResources.getString("yobAgeConstraintFutureMsg")); 
		       else
			      addFacesMessage("userRegistrationId:yobId", tbResources.getString("yobAgeConstraintMsg"));
		    }
		    
		    isYearValid = false;
	  }
	}else
		isYearValid=false;
	
	return isYearValid;
}

private boolean checkYearOfBirthEntryLimit(){
	Integer yobCount = this.getIncorrectYobCount();
	if(yobCount >=yobLimit){
		String idStr="userRegistrationId:yobId";
		if(this.showDob)
		   idStr="userRegistrationId:dobId";

		addFacesMessage(idStr, tbResources.getString("ageNotElibleMsg"));
		return false;
	}else{
		return true;
	}
}

private void incrementIncorrectYobCount(){
	Integer yobCount = getIncorrectYobCount();
	yobCount++;
	this.addSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT, yobCount);
}
private Integer getIncorrectYobCount(){
	Integer yobCount=null;
	Object incorrectYobCountObj = getSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT);
	if(incorrectYobCountObj != null)
		yobCount = (Integer)incorrectYobCountObj;
	else{
		yobCount = new Integer(0);
		this.addSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT, yobCount);
	}
	return yobCount;
}

private boolean validateYobFormat(String yobStr){
	if(showDob)
		return true;//then year of birth not used
	boolean valid=true;
	Integer yob=-1;
	Date yobDate=null;
	
	try{
		if(StringUtils.isEmpty(yobStr)){
			addFacesMessage("userRegistrationId:yobId", tbResources.getString("yobRequiredMsg"));
			valid=false;
			return valid;
		}
		if(yobStr.length()<4){
			addFacesMessage("userRegistrationId:yobId", tbResources.getString("yobFormatErrorMsg508"));
			valid=false;
			return valid;
		}
		yob = Integer.parseInt(yobStr);
		if(yob != -1) {
			SimpleDateFormat yearformat = new SimpleDateFormat(DateUtil.YEAR_FORMAT);
			yobDate = yearformat.parse(yobStr);
		}
		/*
		if(yobDate!=null){
			Calendar nowCal = Calendar.getInstance();
			Calendar yobCal = Calendar.getInstance();
            yobCal.setTime(yobDate);
            int curYear=nowCal.get(Calendar.YEAR);
            int yobYear =yobCal.get(Calendar.YEAR);
            int yearDiff = curYear - yobYear;
            logger.debug("--GSA yearDiff: "+yearDiff);
            if(yearDiff < 13)
            	valid=false;
		}
		*/
	}catch(Exception e){
		logger.debug("caught exception parsing year of birth. e: "+e);
		valid=false;
	}
	
	return valid;
}





	private void updateRegnConfStatus() {
		UserRegistrationBean userRegnBean = (UserRegistrationBean) getSessionAttribute("UserRegnConfStatusBean");
		if(userRegnBean != null) {
			BeanUtils.copyProperties(userRegnBean, this, new String[]{"userVO", "tbSecurityQuestionsBean" });
			if(this.userVO != null && userRegnBean.getUserVO() != null) {
				this.userVO.setUuId(userRegnBean.getUserVO().getUuId());
				this.userVO.setUserName(userRegnBean.getUserVO().getUserName());
				this.userVO.setEmailAddress(userRegnBean.getUserVO().getEmailAddress());
			}
			removeSessionAttribute("UserRegnConfStatusBean");
		}
	}


	public String loginPage(){
		return signInPage;
	}

	public String getSpecialCharsMsg() {
		return specialCharsMsg;
	}

	public void setSpecialCharsMsg(String specialCharsMsg) {
		this.specialCharsMsg = specialCharsMsg;
	}
	
	public boolean isDisableEmailCode() {
		return disableEmailCode;
	}

	public void setDisableEmailCode(boolean disableEmailCode) {
		this.disableEmailCode = disableEmailCode;
	}

	public boolean isShowContinue() {
		return showContinue;
	}

	public void setShowContinue(boolean showContinue) {
		this.showContinue = showContinue;
	}

    public void setMobilePhone(String val){
    	mobilePhone=val;
    }
    public String getMobilePhone(){
    	return mobilePhone;
    }

	public boolean isConfPwdSpcErrInd() {
		return confPwdSpcErrInd;
	}

	public void setConfPwdSpcErrInd(boolean confPwdSpcErrInd) {
		this.confPwdSpcErrInd = confPwdSpcErrInd;
	}
	
	/**
	 * This method is used to return to registration personal information page
	 * 
	 */
	public void returnToRegn() {
		clearAcctRecoveryFields();
		setCurrentActiveItem("personalInformation");
		return;
	}
	
	/**
	 * This method is used to return to registration personal information page
	 * 
	 */
	public void cancelAcctRecovery() {
		clearAcctRecoveryFields();
		setCurrentActiveItem("useracctrecovery");
		return;
	}
	
	/**
	 * This method is used to return to registration personal information page
	 * 
	 */
	private void clearAcctRecoveryFields() {
		
		if(getAcctRecoveryMethod() != null){
		
		if(getAcctRecoveryMethod().equals("SECQUEST")){
		tbSecurityQuestionsBean.setSecurityQuestionOne(null);
		tbSecurityQuestionsBean.setSecurityQuestionTwo(null);
		tbSecurityQuestionsBean.setSecurityQuestionThree(null);
		tbSecurityQuestionsBean.setSecurityAnswerOne("");
		tbSecurityQuestionsBean.setSecurityAnswerTwo("");
		tbSecurityQuestionsBean.setSecurityAnswerThree("");
		
		}else if(getAcctRecoveryMethod().equals("MOBILE")){
			
			setMobilePhone(null);
		}else if(getAcctRecoveryMethod().equals("SECEMAIL")){

			userVO.setSecEmailAddress(null);
		}else{
			
			setAcctRecoveryMethod("null");
		}
		
		}
		
			
	}
	
	/**
	 * This method is used to build account recovery methods for the user 
	 * 
	 */
	private void buildRecoveryMethods() {	
		
		SelectItem item = null;
		this.acctRecoveryMethods.clear();
		if(!StringUtils.isEmpty(userVO.getEmailAddress())) {
			item = new SelectItem(SECEMAIL_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_SecEmailVal"));
			this.acctRecoveryMethods.add(item);
		}		
		item = new SelectItem(MOBILE_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_MobileVal"));
		this.acctRecoveryMethods.add(item);
		item = new SelectItem(SECQUESTS_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_SecQuestVal"));
		this.acctRecoveryMethods.add(item);
	}
	
	/**
	 * This method is used to return account recovery methods
	 * 
	 * @return List<SelectItem>
	 */
	public List<SelectItem> getAcctRecoveryMethods() {				
		return acctRecoveryMethods;
	}
	
	
	public void skipAccountRecoveryOptions(){
		
		VerifyCodesContext ctx = new VerifyCodesContext();
		setCurrentUserVO(userVO);
		addSessionAttribute("SKIP_VERIFY_FLOW_REGISTRATION", "true");
		
		if (StringUtils.isNotBlank(userVO.getEmailAddress())) {
			ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
		
		ctx.setHideUpdateButtons(false);
		ctx.setShowDeviceRegistration(isRsaReqdForRP());
		ctx.setNextView("/views/congratulations.jsf");
		ctx.setUserVO(userVO);
		getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);	
		
		if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {
			redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
			return;
		}
		
		}else{
			setCurrentUserVO(userVO);
			redirectToView("/views/congratulations.jsf");
		}
	}

	private Map<String, String> verificationDetails = null;
	
	private boolean emailVerified = false;
	
	public boolean isEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(boolean emailVerified) {
		this.emailVerified = emailVerified;
	}
	
	/**
	 * This method gets called before view gets initialized.
	 */
	public void onPreinitialize() {
		processVerificationDetails();
	}
	
	private void processVerificationDetails(){
		
		if(StringUtils.isNotEmpty(getRequestParameter(TrustBrokerConstants.VERIFICATION_DETAILS))){
			try{
				verificationDetails = container.getCryptAgentUtil().getCryptAgent().getAttributesFromToken(
						getRequestParameter(TrustBrokerConstants.VERIFICATION_DETAILS), true);
				String uuid = verificationDetails.get(TrustBrokerWebAppConstants.KEY_USER_UUID);				
				UserRetrievalServiceResponse userResp = container.getUserService().fetchUserProfile(uuid, true, false);				
				UserVO userDetail = userResp.getUser();			
				showContinue = true;
				if(userDetail != null) {
					boolean response = userDetail.isIsemailVerified();
					setCurrentUserVO(userDetail);
					if(response){
						setEmailVerified(true);						
						return;			
					} else {
						VerifyCodesContext ctx = new VerifyCodesContext();	
						if (StringUtils.isNotBlank(userDetail.getEmailAddress())) {
							ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
						}
						ctx.setHideUpdateButtons(true);
						ctx.setHideResendButtons(true);
						ctx.getPrePopulatedCodes().put(CommunicationChannel.PRIMARY_EMAIL,
								getRequestParameter(TrustBrokerWebAppConstants.VERIFY_EMAIL_CODE_PARAM));
						ctx.setNextView("/views/congratulations.jsf");
						ctx.setUserVO(userDetail);
						getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);					
						redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
					}
				}
			}
			catch(OperationFailedException ofe){
				logger.error("error while verifying user details - {}", ofe);
				setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(
						container.getErrorMessageSource(), getSupportContactInfo()) : ofe.getMessage());
			}
		}
	}
	public String getEmailOrDash(){
		
		if(userVO ==null)
			emailOrDash="---";
		else if(userVO.getEmailAddress() ==null)
			emailOrDash="---";
		else
			emailOrDash=userVO.getEmailAddress();
		
		return emailOrDash;
	}
	
	
	private boolean validateSecurityAnswersForSharedEmail(String fieldPrefix ) {
		String sameAnswer = "";
		boolean retVal = true;
		if(fieldPrefix == null) {
			fieldPrefix = "";
		}

		
		String value1 = FacesContext.getCurrentInstance().
				getExternalContext().getRequestParameterMap().get("userRegistrationId:ansOne");
		String value2 = FacesContext.getCurrentInstance().
				getExternalContext().getRequestParameterMap().get("userRegistrationId:ansTwo");
		String value3 = FacesContext.getCurrentInstance().
				getExternalContext().getRequestParameterMap().get("userRegistrationId:ansThree");
		
		String questionvalue1 = FacesContext.getCurrentInstance().
				getExternalContext().getRequestParameterMap().get("userRegistrationId:questionOne"); 
		String questionvalue2 = FacesContext.getCurrentInstance().
				getExternalContext().getRequestParameterMap().get("userRegistrationId:questionTwo");
		String questionvalue3 = FacesContext.getCurrentInstance().
				getExternalContext().getRequestParameterMap().get("userRegistrationId:questionThree");
		
       
		
		String answerOne = tbSecurityQuestionsBean.getSecurityAnswerOne();
		String answerTwo = tbSecurityQuestionsBean.getSecurityAnswerTwo();
		String answerThree = tbSecurityQuestionsBean.getSecurityAnswerThree();
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion3 = tbSecurityQuestionsBean.getSecurityQuestionThree();
		
		if(secQuestion1 == null && answerOne==null && secQuestion2 == null && answerTwo==null && secQuestion3 == null && answerThree==null){
			
			if(!questionvalue1.equals("2") && !value1.equals("2") && !questionvalue2.equals("2") && !value2.equals("2") 
					&& !questionvalue3.equals("2") && !value2.equals("2")){
			//addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("securityQuestion123"));
			//addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("securityQuestion123"));
			//addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("securityQuestion123"));
			}
			return retVal;
			
		}
		
		if(value1.equals("0")){
		
			tbSecurityQuestionsBean.setSecurityAnswerOne("");
			answerOne=tbSecurityQuestionsBean.getSecurityAnswerOne();
		}
		if(value2.equals("0")){
		
			tbSecurityQuestionsBean.setSecurityAnswerTwo("");
			answerTwo=tbSecurityQuestionsBean.getSecurityAnswerTwo();
		}
		if(value3.equals("0")){
	
			tbSecurityQuestionsBean.setSecurityAnswerThree("");
			answerThree=tbSecurityQuestionsBean.getSecurityAnswerThree();
		}
		
		if(questionvalue1.equals("0")){
			
			tbSecurityQuestionsBean.setSecurityQuestionOne("null");
			secQuestion1=tbSecurityQuestionsBean.getSecurityQuestionOne();
		}
		if(questionvalue2.equals("0")){
		
			tbSecurityQuestionsBean.setSecurityQuestionTwo("null");
			secQuestion2=tbSecurityQuestionsBean.getSecurityQuestionTwo();
		}
		if(questionvalue3.equals("0")){
	
			tbSecurityQuestionsBean.setSecurityQuestionThree("null");
			secQuestion3=tbSecurityQuestionsBean.getSecurityQuestionThree();
		}
		               
		
		if(secQuestion1 == null || answerOne==null){
			
			if(!questionvalue1.equals("2") && !value1.equals("2")){
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("securityQuestion123"));
			retVal = false;
			}
			
			if((questionvalue1.equals("2") && !value1.equals("2")) || (!questionvalue1.equals("2") && value1.equals("2")) ){
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
			
			
		}else {
			
			if (secQuestion1.equals("null") || secQuestion1.length() == 4) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
			
			if (answerOne.equals("") ) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
		}
		
		if(secQuestion2 == null || answerTwo==null){
			
			if(!questionvalue2.equals("2") && !value2.equals("2")){
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("securityQuestion123"));
			retVal = false;
			}
			
			if((questionvalue2.equals("2") && !value2.equals("2")) || (!questionvalue2.equals("2") && value2.equals("2")) ){
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
			
		}else {
			
			if (secQuestion2.equals("null") || secQuestion2.length() == 4) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
			
			if (answerTwo.equals("") ) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
		}

		if(secQuestion3 == null || answerThree==null){
			
			if(!questionvalue3.equals("2") && !value3.equals("2")){
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("securityQuestion123"));
			retVal = false;
			}
			
			if((questionvalue3.equals("2") && !value3.equals("2")) || (!questionvalue3.equals("2") && value3.equals("2")) ){
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
			
		}else{

		if (secQuestion3.equals("null") || secQuestion3.length() == 4) {
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("securityQuestion123"));
			retVal = false;
		}
		if (answerThree.equals("") ) {
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("securityQuestion123"));
			retVal = false;
		}
		
		}
		if(!retVal) {
			return retVal;
		}

	
			
		if(answerOne==null || answerTwo==null || answerThree==null 
				|| answerOne.equals("") || answerTwo.equals("") || answerThree.equals("")){
			
			return retVal;
		}
		
		
		
		
		if (answerOne.equalsIgnoreCase(answerTwo) && answerOne.equalsIgnoreCase(answerThree))
			sameAnswer = answerOne;
		//if (answerTwo.equalsIgnoreCase(answerThree))
		//	sameAnswer = answerTwo;

		if (!"".equals(sameAnswer)) {

			if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase()) && sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase()) && sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())
					&& sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

		} else {
			if (secQuestion1.toLowerCase().contains(answerOne.toLowerCase())) {
				retVal = false;

				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
			}

			if (secQuestion2.toLowerCase().contains(answerTwo.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion3.toLowerCase().contains(answerThree.toLowerCase())) {
				addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}
		}
		
		if(!TBUtil.validateSecurityAnswer(answerOne)){
			retVal = false;
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("obsceneTextInAnswer"));
		}
		
		if(!TBUtil.validateSecurityAnswer(answerTwo)){
			retVal = false;
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("obsceneTextInAnswer"));
		}
		
		if(!TBUtil.validateSecurityAnswer(answerThree)){
			retVal = false;
			addFacesMessage("userRegistrationId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("obsceneTextInAnswer"));
		}

		return retVal;
	}
	
	
	private void createUserSMSession(String userName){
		
		try{
			
			LoginRequest loginRequest = new HttpLoginRequest(userName, null, getServletRequest(), getServletResponse());
			loginRequest.setProtectedUrl(getHomePageURIWithAlias());
			container.getOptumidSMDlwsBasedLoginService().login(loginRequest);
			
		} catch(Exception e){
			logger.error("Error during session creation for registraion", e);
		}
	}
	
	
}
