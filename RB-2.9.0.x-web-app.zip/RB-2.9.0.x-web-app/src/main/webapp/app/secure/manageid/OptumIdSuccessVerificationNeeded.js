'use strict';

var tbApp = angular.module('tbApp');

tbApp.controller('VerificationNeededCtrl', VerificationNeededCtrl);

VerificationNeededCtrl.$inject = ['$scope', 'verifyService', 'vfData', '$state', '$translate'];

function VerificationNeededCtrl($scope, verifyService, vfData, $state, $translate) {
    // alt text for success message model
    $scope.altText = $translate.instant('altTextForSuccessMessage');

    // defining message modal to be dispalyed on page
    $scope.successMessageVerificationNeeded = {
        animationTime: 1,
        autoFadeOut: false,
        content: '<span translate="optumSuccessMsgForVerificationNeeded"></span>',
        headingLevel: '2',
        id: 'Success',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: true
    };
    
   
    var modFields = vfData.data;
    
    var fieldsToVerify = $state.params.fields;
    if( !fieldsToVerify){
    	fieldsToVerify=modFields;
    }
  
    var   hideMsg = $state.params.hideSuccessMsg;
   
    if (fieldsToVerify) {
        if (fieldsToVerify.mobileNo) {
            $scope.showMobVerificationMsg = true;
            $scope.propertyType = 'mobileNo';
            $scope.propertyTypeName = 'mobile number';
        } else if (fieldsToVerify.secondaryEmail) {
            $scope.propertyType = 'secondaryEmail';
            $scope.propertyTypeName = 'secondary email';
        }
    }

    if (hideMsg) {
        $scope.successMessageVerificationNeeded.visible = false;
    }

    $scope.verifyLinkNextState = function() {
        if ($scope.propertyType === 'mobileNo') {
        	verifyService.clearWorkflow();
            $state.go('mobileVerification', {
                fieldToVerify: 'mobileNo',
                fromState: 'home'
            });
        } else {
        	verifyService.clearWorkflow();
            $state.go('confirmEmailAddress', {
                verifyCodesCtx: {
                    viewChannels: ['SECONDARY_EMAIL'],
                    sendChannels: ['SECONDARY_EMAIL'],
                    chann: 'SECONDARY_EMAIL',
                    nextView: 'congratulations',
                    optionValue: fieldsToVerify.secondaryEmail
                },
                fromState: 'home'
            });
        }
    };

    // function for skipping current verification flow and triggering next one
    $scope.skipVerification = function($event) {
        $event.preventDefault();

        var field = $scope.propertyType;
        if(field && fieldsToVerify){
            delete fieldsToVerify[field];
        }

        if(Object.keys(fieldsToVerify).length === 0){
        	verifyService.clearWorkflow();
            $state.go('profile.verifyoptions');
        }else{
            $state.go('optumIdSuccessVerificationNeeded',
                {
                    'fields' : fieldsToVerify,
                    'hideSuccessMsg' : true
                },
                {reload: true});
        }

    };
}
