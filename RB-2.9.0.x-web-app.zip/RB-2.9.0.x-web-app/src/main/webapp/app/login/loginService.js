/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 *
 */
'use strict';
angular.module('indexApp').service('LoginService',['$http', 'forgotAccessService', LoginService]);

function LoginService($http, forgotAccessService){

		this.init = function(){

			   var promise = $http.get('/tb/services/rest/login/init?'+window.location.search.split("?")[1]);
			      promise.success(function(data) {
			        return data;
			      });
			      return promise;
		};
		this.checkEmail= function(email){
			return $http.post('/tb/services/rest/login/checkEmail', email);
			
		};
		this.localLogin= function(userName){
			return $http.post('/tb/services/rest/login/localLogin', userName);
			
		};
		this.submitForm =function(){
			return $('form[name="signInForm"]')[0].submit();
		};
		this.getUrlParams =function(){
			return window.location.search;
		};
				
		window.handleResendInfo = function(){
			var scope = forgotAccessService.scopeRef;
	       	forgotAccessService.sendUserNameByAccountRecovery(scope.resendInfo).then(function(response) {
	       		var responseVO = response.data;
	            var status = responseVO.status;
	            if (status) {
	            	scope.successMessageModel.content = '<span>' + scope.newMsgStr + scope.linkStr +'</span>';
	            }
	       	});
		};
				
	
}