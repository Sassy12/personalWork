package com.optum.trustbroker.managebean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.richfaces.event.ItemChangeEvent;
import org.springframework.beans.BeanUtils;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.EnableUserServiceRequest;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.ResetUserRSAProfileRequest;
import com.optum.trustbroker.vo.ServiceResponse;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserChangePasswordServiceRequest;
import com.optum.trustbroker.vo.UserChangePasswordServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.esso.schemas.xsd._2013._12.AuthenticationType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

@ManagedBean(name = "resetSecurityCredentialsBean")
@SessionScoped
public class ResetSecurityCredentialsBean extends AbstractBackingBean {

	BaseLogger logger = new BaseLogger(ResetSecurityCredentialsBean.class);
	protected static final ResourceBundle tbResources = ResourceBundle
			.getBundle("trustBrokerResources");

	@ManagedProperty(value = "#{tbSecurityQuestionsBean}")
	private SecurityQuestionsBean tbSecurityQuestionsBean;
	
	@ManagedProperty(value = "#{userVO}")
	private UserVO userVO;
	
	
	@ManagedProperty(value = "#{isEmailConfirmationRequired}")
	private String isEmailConfirmationRequired;
	
	private String homePage = "/views/login.xhtml?faces-redirect=true";

	private String confirmPassword;
	private String passwordStrength;
	private UserVO eSSOUserVO;
	private String errorMessage;
	private String acctRecoveryErrorMsg;
	private String confirmEmailAddress;
	private String emailExistsMsg;
	private String emailAddress;
	private boolean pwdSpcErrInd = false;
	private boolean pwdDoNotMatch = false;
	private boolean widgetView=false;
	private boolean showQuestions = false;
	private boolean emailMandatory = true;
	private boolean emailShared = true;
	private String mobilePhone;
	private String currentButtonId;
	private String currentActiveItem;
	private List<SelectItem> acctRecoveryMethods = new ArrayList<SelectItem>();
	private String acctRecoveryMethod;
	private String sharedEmailErrorMsg;
	private final String SECEMAIL_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_SecEmailId");
	private final String MOBILE_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_MobileId");
	private final String SECQUESTS_ACCT_REC_METHOD = tbResources.getString("AcctRecovery_SecQuestId");
	
	private boolean displaySkipOption;
	private boolean byPassConfirmation=false;
	
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getConfirmEmailAddress() {
		return confirmEmailAddress;
	}

	public void setConfirmEmailAddress(String confirmEmailAddress) {
		this.confirmEmailAddress = confirmEmailAddress;
	}

	public SecurityQuestionsBean getTbSecurityQuestionsBean() {
		return tbSecurityQuestionsBean;
	}

	public void setTbSecurityQuestionsBean(
			SecurityQuestionsBean tbSecurityQuestionsBean) {
		this.tbSecurityQuestionsBean = tbSecurityQuestionsBean;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getPasswordStrength() {
		return passwordStrength;
	}

	public void setPasswordStrength(String passwordStrength) {
		this.passwordStrength = passwordStrength;
	}

	public UserVO geteSSOUserVO() {
		return eSSOUserVO;
	}

	public void seteSSOUserVO(UserVO eSSOUserVO) {
		this.eSSOUserVO = eSSOUserVO;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getAcctRecoveryErrorMsg() {
		return acctRecoveryErrorMsg;
	}

	public void setAcctRecoveryErrorMsg(String acctRecoveryErrorMsg) {
		this.acctRecoveryErrorMsg = acctRecoveryErrorMsg;
	}

	public boolean isPwdSpcErrInd() {
		return pwdSpcErrInd;
	}

	public void setPwdSpcErrInd(boolean pwdSpcErrInd) {
		this.pwdSpcErrInd = pwdSpcErrInd;
	}

	public boolean isShowQuestions() {
		return showQuestions;
	}

	public void setShowQuestions(boolean showQuestions) {
		this.showQuestions = showQuestions;
	}

	public boolean isEmailMandatory() {
		return emailMandatory;
	}

	public void setEmailMandatory(boolean emailMandatory) {
		this.emailMandatory = emailMandatory;
	}

	public boolean isEmailShared() {
		return emailShared;
	}

	public void setEmailShared(boolean emailShared) {
		this.emailShared = emailShared;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getCurrentButtonId() {
		return currentButtonId;
	}

	/**
	 * @return the byPassConfirmation
	 */
	public boolean isByPassConfirmation() {
		return byPassConfirmation;
	}

	/**
	 * @param byPassConfirmation the byPassConfirmation to set
	 */
	public void setByPassConfirmation(boolean byPassConfirmation) {
		this.byPassConfirmation = byPassConfirmation;
	}

	public void setCurrentButtonId(String currentButtonId) {
		this.currentButtonId = currentButtonId;
	}

	public List<SelectItem> getAcctRecoveryMethods() {
		return acctRecoveryMethods;
	}

	public String getAcctRecoveryMethod() {
		return acctRecoveryMethod;
	}

	public String getSharedEmailErrorMsg() {
		return sharedEmailErrorMsg;
	}

	public void setSharedEmailErrorMsg(String sharedEmailErrorMsg) {
		this.sharedEmailErrorMsg = sharedEmailErrorMsg;
	}

	public void setAcctRecoveryMethod(String acctRecoveryMethod) {
		this.acctRecoveryMethod = acctRecoveryMethod;
	}

	public String getCurrentActiveItem() {
		return currentActiveItem;
	}

	public void setCurrentActiveItem(String currentActiveItem) {
		this.currentActiveItem = currentActiveItem;
	}

	@PostConstruct
	public void init() {
		Map<String, String> userDetails = (HashMap<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		try {
			ChallengeQuestionServiceResponse challengeQuestionServiceResponse = getContainer().getConfigService().getSecurityQuestions();
			tbSecurityQuestionsBean.setQuestions(challengeQuestionServiceResponse.getUserChallengeQuestions());
		
			if (null != userDetails) {
				userVO = getContainer().getUserService().fetchUserProfile((userDetails.get(TrustBrokerWebAppConstants.USER_NAME)), false, true).getUser();
				eSSOUserVO = new UserVO();
				BeanUtils.copyProperties(userVO, eSSOUserVO);
				if (isSessionAttributeExists(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE)) {
					String recoveryType = (String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
					if (TrustBrokerWebAppConstants.LOST_ACCESS_TO_RECOVERY.equalsIgnoreCase(recoveryType)
							|| TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK.equalsIgnoreCase(recoveryType)) {
						userVO.setEmailAddress("");
						userVO.setSecEmailAddress("");
						userVO.setPhoneNumber("");
					}
				}
				userVO.setUserChallengeQuestions(new ArrayList<UserChallengeQuestionVO>());
			}
			if (!(isSessionAttributeExists(TrustBrokerWebAppConstants.SET_SECURITY_QUESTIONS)))
				processRPreg();
		} catch (OperationFailedException ope) {
			logger.error("Error while retrieveing user profile details for user: {}", 
					new String[]{userDetails.get(TrustBrokerWebAppConstants.USER_NAME), TrustbrokerWebAppUtil.getUidFromError(ope)});
			setErrorMessage(extractErrorMessageFromOFE(ope));
		}
	}

	
	public String resetSecurityCredentialsw(){
		widgetView=true;
		return resetSecurityCredentials();
	}
	public String resetSecurityCredentials() {
		setErrorMessage("");
	if (!validatePasswordFields()) {
			emptyPwdFields();
			return null;
		}

		try {

			// Unlocking the user account if the user account is locked either
			// at LDAP or RSA
			EnableUserServiceRequest enableUserServiceRequest = new EnableUserServiceRequest();
			enableUserServiceRequest.setUser(eSSOUserVO);
			ServiceResponse serviceResponse;

			logger.debug("Unlock the user at LDAP");
			// Always unlocking the user account at LDAP by default - Just on a safe side
			enableUserServiceRequest.setPasswordEnable(false);
			serviceResponse = getContainer().getCredentialService().enableUser(enableUserServiceRequest);
			if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(serviceResponse.getExecutionStatus().getStatusCd())) {
				setErrorMessage("Unlocking the user failed");
				emptyPwdFields();
				return null;
			} else {
				SecurityLoggingUtil.info("Unlock Account", SecurityEventType.E3_ENABLE, getServletRequest(), eSSOUserVO.getUserName(),
						"Security Audit Event|LDAP Unlock:Success, ResetSEcurityCredentialsBean:resetSecurityCredentials()",
						SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_ENABLE_LDAP);
			}

			if (TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(eSSOUserVO.getAaStatus())) {
				// Unlocking the user at RSA
				logger.debug("Unlock the user at RSA");
				ResetUserRSAProfileRequest request = new ResetUserRSAProfileRequest();
				request.setUser(eSSOUserVO);
				serviceResponse = getContainer().getUserService().resetUserRSAProfile(request);
				if (TrustBrokerConstants.FAILURE_CODE_VALUE.equalsIgnoreCase(serviceResponse.getExecutionStatus().getStatusCd())) {
					setErrorMessage("Unlocking the user failed");
					emptyPwdFields();
					return null;
				} else
					SecurityLoggingUtil.info("Unlock Account", SecurityEventType.E3_ENABLE, getServletRequest(), eSSOUserVO.getUserName(),
							"Security Audit Event|RSA Unlock:Success, ResetSEcurityCredentialsBean:resetSecurityCredentials()",
							SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_ENABLE_RSA);
			}

			// Modifying the eSSO user
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userVO.setEmailAddress(eSSOUserVO.getEmailAddress());
			userProfileServiceRequest.setUser(userVO);
			//populateSecurityQuestions(userVO);

			UserProfileServiceResponse response = getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest,
					eSSOUserVO);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
				logger.debug(userVO.getUserName() + " profile updated successfully during self service recovery");
			} else {
				logger.debug("Error while resetting user profile during Self Service recovery: "
						+ response.getExecutionStatus().getStatusMessage());
				setErrorMessage("Error while resetting user profile during Self Service recovery");
				emptyPwdFields();
				return null;
			}

		} catch (OperationFailedException ofe) {
			logger.error("Error while unlocking or updating the user profile during resetting security credentials for user: {}",
					new String[]{eSSOUserVO.getUserName(), TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
			setErrorMessage(extractErrorMessageFromOFE(ofe));
			emptyPwdFields();
			return null;
		}

		try {
			// Changing the Password of a user
			UserChangePasswordServiceRequest userChangePwdServiceRequest = new UserChangePasswordServiceRequest();
			userChangePwdServiceRequest.setPassword(userVO.getPassword());
			userChangePwdServiceRequest.setUser(eSSOUserVO);
			UserChangePasswordServiceResponse changePwdResponse = getContainer().getCredentialService()
					.changePwd(userChangePwdServiceRequest);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(changePwdResponse.getExecutionStatus().getStatusCd()))
				logger.debug(userVO.getUserName() + " password changed successfully during self service recovery");
			else {
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
				userProfileServiceRequest.setUser(eSSOUserVO);
				getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest, userVO);
				/*if (changePwdResponse.getReasonCode().equalsIgnoreCase("PASSWORD_MANAGEMENT_ERROR"))
				{
					addFacesMessage("resetSecCredentialsFormId:pwd",
							tbResources.getString("blackListedPasswordMsg"));
					setErrorMessage("");
				}
				else
				{
					setErrorMessage(changePwdResponse.getReasonMessage());
				}*/
				setErrorMessage(changePwdResponse.getReasonMessage());
				emptyPwdFields();
				return null;
			}
		} catch (OperationFailedException ofe) {
			logger.error("Error while changing user password during Self Service recovery: ", ofe);
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(eSSOUserVO);
			getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest, userVO);
			setErrorMessage(ofe.getMessage());
			/*if (ofe.getMessage().contains(tbResources.getString("blackListedPasswordMsg")))
			{
				addFacesMessage("resetSecCredentialsFormId:pwd",
						tbResources.getString("blackListedPasswordMsg"));
				setErrorMessage("");
			}*/
			emptyPwdFields();
			return null;
		}

		@SuppressWarnings("unchecked")
		Map<String, String> userDetails = (HashMap<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		String authCode = userDetails.get("authCode");
		if (StringUtils.isNotEmpty(authCode)) {
			getContainer().getUserService().invalidateUserAuthCode(authCode);
			SecurityLoggingUtil.info("ResetSecuirty Credentials ", SecurityEventType.E3_MODIFY, getServletRequest(),
					eSSOUserVO.getUserName(),
					"Security Audit Event|ResetSecuirty Credentials :SUCCESS|Authorization Code Processed , "
							+ "ResetSecurityCredentialsBean:resetSecurityCredentials()", SecurityEventResult.SUCCESS,
					getRelyingPartyAppId(), SecuritySubEventType.E3_MODIFY_PROFILE);
		}
		removeSessionWithoutRelyingPartyInfo();
		if(widgetView)
		     return "/views/selfrecoverysuccessw.xhtml?faces-redirect=true";
		else
			return "/views/selfrecoverysuccess.xhtml?faces-redirect=true";
	}

	private void emptyPwdFields() {
		userVO.setPassword("");
		userVO.setConfirmPwd("");
	}

	private boolean validateFormFields() {
		boolean isPwdFieldsValidated = validatePasswordFields();
		boolean isSecurityAnswersValidated = validateSecurityAnswers("");

		return isPwdFieldsValidated && isSecurityAnswersValidated;
	}
	
	public void checkPwd(ValueChangeEvent event) {
		
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			//checkPwdContent();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			checkPwdContent();
		}
		
	}
	

	private boolean validatePasswordFields() {
		boolean result = true;
		if(StringUtils.isBlank(userVO.getPassword())){
			result = false;
			setErrorMessage(tbResources.getString("passwordRequired"));
		}
		if(!result)
			return result;
		if(StringUtils.isBlank(getConfirmPassword())){
			result = false;
			setErrorMessage("Confirm Password is required");
		}
			if(!result)
			return result;
		
		if (!userVO.getPassword().equals(getConfirmPassword())) {
			result = false;
			setErrorMessage(
					tbResources.getString("pwdDoNotMatch"));
			return result;
		}
		if(isPwdDoNotMatch()) {
			setErrorMessage(
					tbResources.getString("pwdDoNotMatch"));
			return false;
		} 
		result=checkPwdContent();
		if(!result)
			return result;
		if(isPwdSpcErrInd()) {
			setErrorMessage(tbResources.getString("pwdCannotContainSpaces"));
			result = false;
		} 
		
		if(!TBUtil.isPwdStrengthValid(userVO.getPassword())) {
			result = false;
			//setErrorMessage(tbResources.getString("goodOrStrongPwdReq"));
			setErrorMessage("Password must meet requirements");
			
		}
		return result;
	}
	private boolean checkPwdContent(){
		boolean result=true;
		 HashMap validatePwdMap = TrustbrokerWebAppUtil.validatePwdContent(userVO);
		 	if (userVO.getPassword().contains(PWD_INVALID_SPL_CHAR)) {
		 		setErrorMessage(
		 				tbResources.getString("pwdSplCharErrMasg"));
				result = false;
			}
			if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME)) {
				setErrorMessage((String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME));
				result=false;
			}
			if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE)) {
				setErrorMessage((String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE));
				result=false;
			}
			
		/*if(!TBUtil.validateBlackListedPassword(userVO.getPassword())){
				
				addFacesMessage("resetSecCredentialsFormId:pwd",
						"The password you entered is frequently used; for your security, please select a more unique password");
				result=false;
				
			}*/
			
			return result;
	}
	private boolean validateSecurityAnswers(String fieldPrefix) {
		String sameAnswer = "";
		boolean retVal = true;
		if(fieldPrefix == null) {
			fieldPrefix = "";
		}

		String answerOne = tbSecurityQuestionsBean.getSecurityAnswerOne();
		String answerTwo = tbSecurityQuestionsBean.getSecurityAnswerTwo();
		String answerThree = tbSecurityQuestionsBean.getSecurityAnswerThree();
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion3 = tbSecurityQuestionsBean
				.getSecurityQuestionThree();
		
		if (secQuestion1.equals("null") || secQuestion1.length() == 4) {
			addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("secQuestion1"));
			retVal = false;
		}

		if (secQuestion2.equals("null") || secQuestion2.length() == 4) {
			addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("secQuestion2"));
			retVal = false;
		}

		if (secQuestion3.equals("null") || secQuestion3.length() == 4) {
			addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("secQuestion3"));
			retVal = false;
		}
		
		if (answerOne.equalsIgnoreCase(answerTwo)
				&& answerOne.equalsIgnoreCase(answerThree))
			sameAnswer = answerOne;
//		if (answerTwo.equalsIgnoreCase(answerThree))
//			sameAnswer = answerTwo;
//		
//		if (answerThree.equalsIgnoreCase(answerOne))
//			sameAnswer = answerOne;
		

		if (!"".equals(sameAnswer)) {
			if (secQuestion1.contains(answerOne)
					&& sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion2.contains(answerTwo)
					&& sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion3.contains(answerThree)
					&& sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage(
						"resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion1.contains(answerOne)) {
				addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion2.contains(answerTwo)) {
				addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion3.contains(answerThree)) {
				addFacesMessage(
						"resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage(
						"resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

		} else {
			if (secQuestion1.contains(answerOne)) {
				retVal = false;

				addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerOne",
						tbResources.getString("secAnswermustnotContainsText"));
			}

			if (secQuestion2.contains(answerTwo)) {
				addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerTwo",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (secQuestion3.contains(answerThree)) {
				addFacesMessage(
						"resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerThree",
						tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}
		}
		
		if(!TBUtil.validateSecurityAnswer(answerOne)){
			addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerOne", tbResources.getString("obsceneTextInAnswer"));
			retVal = false;
		}
		
		if(!TBUtil.validateSecurityAnswer(answerTwo)){
			addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerTwo", tbResources.getString("obsceneTextInAnswer"));
			retVal = false;
		}
		
		if(!TBUtil.validateSecurityAnswer(answerThree)){
			addFacesMessage("resetSecCredentialsFormId:"+fieldPrefix+"securityAnswerThree", tbResources.getString("obsceneTextInAnswer"));
			retVal = false;
		}
		
		return retVal;
	}

	private void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	private void populateSecurityQuestions(UserVO userVO) {
		List<UserChallengeQuestionVO> securityQuestions = new ArrayList<UserChallengeQuestionVO>();
		UserChallengeQuestionVO question1 = new UserChallengeQuestionVO();
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion1Array[] = secQuestion1.split("_");
		question1.setQuestionId(secQuestion1Array[0]);
		question1.setQuestion(secQuestion1Array[1]);
		question1.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerOne());

		UserChallengeQuestionVO question2 = new UserChallengeQuestionVO();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion2Array[] = secQuestion2.split("_");
		question2.setQuestionId(secQuestion2Array[0]);
		question2.setQuestion(secQuestion2Array[1]);
		question2.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerTwo());

		UserChallengeQuestionVO question3 = new UserChallengeQuestionVO();
		String secQuestion3 = tbSecurityQuestionsBean
				.getSecurityQuestionThree();
		String secQuestion3Array[] = secQuestion3.split("_");
		question3.setQuestionId(secQuestion3Array[0]);
		question3.setQuestion(secQuestion3Array[1]);
		question3.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerThree());

		securityQuestions.add(question1);
		securityQuestions.add(question2);
		securityQuestions.add(question3);
		userVO.setUserChallengeQuestions(securityQuestions);
	}

	public String continueClicked() {
		String redirectURL = homePage;
		String relyingPartyAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		String relyingPartyTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		
		if (StringUtils.isNotBlank(relyingPartyAppId) && StringUtils.isNotBlank(relyingPartyTargetURL)) {
			redirectURL = HttpUtils.addParameterToURL(redirectURL, TrustBrokerConstants.RELYING_APP_ID_PARAM, relyingPartyAppId);
			redirectURL = HttpUtils.addParameterToURL(redirectURL, TrustBrokerConstants.TARGET, relyingPartyTargetURL);
		} 
		
		return redirectURL;
	}
	
	public String getEmailExistsMsg() {
		return emailExistsMsg;
	}

	public void setEmailExistsMsg(String emailExistsMsg) {
		this.emailExistsMsg = emailExistsMsg;
	}

	private boolean validateEmailFields() {
		boolean result = validatePrimaryEmail(userVO.getEmailAddress());
		
		if (StringUtils.isNotEmpty(getConfirmEmailAddress())
				&& !getConfirmEmailAddress().equalsIgnoreCase(userVO.getEmailAddress())) {
			result = false;
			addFacesMessage("resetSecCredentialsFormId:confirmEmail", tbResources.getString("emailDoNotMatch"));
		}

		if (isSessionAttributeExists(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE)
				&& TrustBrokerWebAppConstants.LOST_ACCESS_TO_RECOVERY.equalsIgnoreCase((String) getSessionMap().get(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE))
				&& StringUtils.isNotBlank(userVO.getEmailAddress()) && userVO.getEmailAddress().equalsIgnoreCase(eSSOUserVO.getEmailAddress())) {
			
			eSSOUserVO.getSecEmailAddress();
			
		}
		return result;
	}

	private boolean validatePrimaryEmail(String emailAddress) {
		boolean result = true;
		String email = userVO.getEmailAddress();
		
		if(StringUtils.isNotBlank(email)&&email.equalsIgnoreCase(geteSSOUserVO().getSecEmailAddress()))
		{
			setEmailExistsMsg(tbResources.getString("rpDoNotUseSecondaryEmail"));
			result = false;
			return false;
		}
			
		if (isEmailMandatory()) {
			if (StringUtils.isEmpty(email)) {
				setEmailExistsMsg(tbResources.getString("rpDoNotSupportEmptyEmail"));
				result = false;
			} else if (!TBUtil.validateEmailId(email)) {
				setEmailExistsMsg(tbResources.getString("invalidEmailAddress"));
				result = false;
			} else if (!isEmailShared()
					&& container.getUserService().isEmailExists(email)
					&& (StringUtils.isNotBlank(geteSSOUserVO().getEmailAddress()) && !geteSSOUserVO().getEmailAddress().equalsIgnoreCase(email))) {
					setEmailExistsMsg(tbResources.getString("rpDoNotDuplicateEmail"));
				result = false;
			}
			else if(isEmailShared() && container.getUserService().isEmailExists(email) 
					&& (StringUtils.isNotBlank(geteSSOUserVO().getEmailAddress()) && !geteSSOUserVO().getEmailAddress().equalsIgnoreCase(email)))
			{
				setSharedEmailErrorMsg(tbResources.getString("duplicateEmailWarn"));
			}
		} else {
			if (!isEmailShared()) {
				if (!TBUtil.validateEmailId(email)) {
					setEmailExistsMsg(tbResources.getString("invalidEmailAddress"));
					result = false;
				} else if (!StringUtils.isEmpty(email)
						&& container.getUserService().isEmailExists(email)
						&& (StringUtils.isNotBlank(geteSSOUserVO().getEmailAddress()) && !geteSSOUserVO().getEmailAddress().equalsIgnoreCase(email))) {
					setEmailExistsMsg(tbResources.getString("rpDoNotDuplicateNonMandatoryEmail"));
					result = false;
				}
			}
			else if(email != null && email!= "" && container.getUserService().isEmailExists(email)
					&& (StringUtils.isNotBlank(geteSSOUserVO().getEmailAddress()) && !geteSSOUserVO().getEmailAddress().equalsIgnoreCase(email)))
			{
				setSharedEmailErrorMsg(tbResources.getString("duplicateEmailWarn"));
			}
		}
		
		
		return result;
	}
	
	private boolean validateEmailFieldsForresetsec() {
		boolean result = true;

		if (StringUtils.isNotEmpty(getConfirmEmailAddress())
				&& !userVO.getEmailAddress().equalsIgnoreCase(getConfirmEmailAddress())) {
			result = false;
			addFacesMessage("resetSecCredentialsFormId:confirmEmail", tbResources.getString("emailDoNotMatch"));
		}

		if (!eSSOUserVO.getEmailAddress().equalsIgnoreCase(userVO.getEmailAddress())) {
			if (StringUtils.isEmpty(getConfirmEmailAddress())) {
				addFacesMessage("resetSecCredentialsFormId:confirmEmail", "Please enter confirm email address");
				result = false;
			}
			if (!TBUtil.validateEmailId(userVO.getEmailAddress())) {
				setEmailExistsMsg(tbResources.getString("invalidEmailAddress"));
				result = false;
			} else {
				if (getContainer().getUserService().isEmailExists(userVO.getEmailAddress())) {
					result = false;
					setEmailExistsMsg(tbResources.getString("emailAlreadyExists"));
				}
			}
		}

		if (isSessionAttributeExists(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE)) {
			String recoveryType = (String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
				if((TrustBrokerWebAppConstants.LOST_ACCESS_TO_RECOVERY.equalsIgnoreCase(recoveryType) || 
						TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK.equalsIgnoreCase(recoveryType))
				&& userVO.getEmailAddress().equalsIgnoreCase(eSSOUserVO.getEmailAddress())) { 
					errorMessage = "You have indicated that you lost access to this email: " + userVO.getEmailAddress()
							+ ". Please modify";
					addFacesMessage("resetSecCredentialsFormId:email", "");
					result = false;
				}
		}
		return result;
	}
	
	public String getIsEmailConfirmationRequired() {
		return isEmailConfirmationRequired;
	}

	/**
	 * @return the displaySkipOption
	 */
	public boolean isDisplaySkipOption() {
		return displaySkipOption;
	}

	/**
	 * @param displaySkipOption the displaySkipOption to set
	 */
	public void setDisplaySkipOption(boolean displaySkipOption) {
		this.displaySkipOption = displaySkipOption;
	}

	public void setIsEmailConfirmationRequired(String isEmailConfirmationRequired) {
		this.isEmailConfirmationRequired = isEmailConfirmationRequired;
	}

	public void checkEmailAddress(ValueChangeEvent event) {
		emailExistsMsg = "";
		setSharedEmailErrorMsg("");
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
				boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
				if (!result) {
					setEmailExistsMsg(tbResources.getString("invalidEmailAddress"));
				} 
				validatePrimaryEmail(event.getNewValue().toString());
		}
	}

	
	public String resetSecurityCredentialswithemail() {

		setErrorMessage("");
		setEmailExistsMsg("");
		if (!validatePasswordFields()) {
			emptyPwdFields();
			return null;
		}
		
		if((StringUtils.isEmpty(userVO.getEmailAddress()) || isUserEmailShared(userVO)) 
				&& isUserSecQuestionsNotExists(userVO) ) {
			//Build account recovery options list
			buildRecoveryMethods();
			return "/views/resetsecacctrecovery.xhtml?faces-redirect=true";
		}
		
		if (!validateEmailFieldsForresetsec()) {
			return null;
		}
		
		try {

			// Unlocking the user account if the user account is locked either at LDAP or RSA
			EnableUserServiceRequest enableUserServiceRequest = new EnableUserServiceRequest();
			enableUserServiceRequest.setUser(eSSOUserVO);
			ServiceResponse serviceResponse;

			if (TrustBrokerConstants.PWD_DISABLED.equalsIgnoreCase(eSSOUserVO.getPwdStatus())
					|| TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(eSSOUserVO.getAaStatus())) {
				logger.debug("Unlock the user at LDAP");
				// Unlocking the user at LDAP
				enableUserServiceRequest.setPasswordEnable(false);
				serviceResponse = getContainer().getCredentialService().enableUser(enableUserServiceRequest);
				if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(serviceResponse.getExecutionStatus().getStatusCd())) {
					setErrorMessage("Unlocking the user failed");
					emptyPwdFields();
					return null;
				}
			}

			if (TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(eSSOUserVO.getAaStatus())) {
				// Unlocking the user at RSA
				logger.debug("Unlock the user at RSA");
				ResetUserRSAProfileRequest request = new ResetUserRSAProfileRequest();
				request.setUser(eSSOUserVO);
				serviceResponse = getContainer().getUserService().resetUserRSAProfile(request);
				if (TrustBrokerConstants.FAILURE_CODE_VALUE.equalsIgnoreCase(serviceResponse.getExecutionStatus().getStatusCd())) {
					setErrorMessage("Unlocking the user failed");
					emptyPwdFields();
					return null;
				}
			}

			// Modifying the eSSO user
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(userVO);
			//populateSecurityQuestions(userVO);

			UserProfileServiceResponse response = getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest,
					eSSOUserVO);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
				logger.debug(userVO.getUserName() + " profile updated successfully during self service recovery");
			} else {
				logger.debug("Error while resetting user profile during Self Service recovery: "
						+ response.getExecutionStatus().getStatusMessage());
				setErrorMessage("Error while resetting user profile during Self Service recovery");
				emptyPwdFields();
				return null;
			}
		} catch (OperationFailedException ofe) {
			logger.error("Error while resetting user profile during Self Service recovery: ", ofe);
			setErrorMessage(ofe.getMessage());
			emptyPwdFields();
			return null;
		}

		try {
			// Changing the Password of a user
			UserChangePasswordServiceRequest userChangePasswordServiceRequest = new UserChangePasswordServiceRequest();
			userChangePasswordServiceRequest.setPassword(userVO.getPassword());
			userChangePasswordServiceRequest.setUser(eSSOUserVO);
			UserChangePasswordServiceResponse changePwdResponse = getContainer().getCredentialService()
					.changePwd(userChangePasswordServiceRequest);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(changePwdResponse.getExecutionStatus().getStatusCd()))
				logger.debug(userVO.getUserName() + " password changed successfully during self service recovery");
			else {
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
				userProfileServiceRequest.setUser(eSSOUserVO);
				getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest, userVO);
				/*if (changePwdResponse.getReasonCode().equalsIgnoreCase("PASSWORD_MANAGEMENT_ERROR"))
				{
					addFacesMessage("resetSecCredentialsFormId:pwd",
							tbResources.getString("blackListedPasswordMsg"));
					setErrorMessage("");
				}
				else
				{
					setErrorMessage(changePwdResponse.getReasonMessage());
				}*/
				setErrorMessage(changePwdResponse.getReasonMessage());
				emptyPwdFields();
				return null;
			}
		} catch (OperationFailedException ofe) {
			logger.error("Error while changing user password during Self Service recovery: ", ofe);
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(eSSOUserVO);
			getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest, userVO);
			setErrorMessage(ofe.getMessage());
			/*if (ofe.getMessage().contains(tbResources.getString("blackListedPasswordMsg")))
			{
				addFacesMessage("resetSecCredentialsFormId:pwd",
						tbResources.getString("blackListedPasswordMsg"));
				setErrorMessage("");
			}*/
			emptyPwdFields();
			return null;
		}
		if (!userVO.getEmailAddress().equalsIgnoreCase(eSSOUserVO.getEmailAddress())) {
			// TODO remove "/views/selfserviceemailconfirmation.xhtml?faces-redirect=true";
			VerifyCodesContext ctx = new VerifyCodesContext();
			ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			ctx.setHideUpdateButtons(true);
			ctx.setShowDeviceRegistration(false);
			ctx.setNextView("/views/selfrecoverysuccess.xhtml?faces-redirect=true");
			ctx.setUserVO(getCurrentUserVO());
			getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);	
			//if (TBUtil.isProdEnv() || Boolean.parseBoolean(getIsEmailConfirmationRequired())) {
			if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {
				return VerifyCodesBean.VERIFY_CODES_VIEW;
			}
			else {
				// TODO: double check
				//ctx.setAutoVerify(true);
				//return VerifyCodesBean.VERIFY_CODES_VIEW;
			}
		}
		
		removeSessionWithoutRelyingPartyInfo();
		return "/views/selfrecoverysuccess.xhtml?faces-redirect=true";
	}
	
	
	
	public String resetSecurityCredentialswithoutsq() {

		setErrorMessage("");
		setEmailExistsMsg("");
		boolean isPwdFieldsValidated = validatePasswordFields();
		boolean isEmailsValidated = validateEmailFieldsForresetsec();
		if (!(isPwdFieldsValidated && isEmailsValidated)) {
			emptyPwdFields();
			return null;
		}
		
		try {

			// Modifying the eSSO user
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(userVO);

			UserProfileServiceResponse response = getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest,
					eSSOUserVO);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
				logger.debug(userVO.getUserName() + " profile updated successfully during self service recovery");
			} else {
				logger.debug("Error while resetting user profile during Self Service recovery: "
						+ response.getExecutionStatus().getStatusMessage());
				setErrorMessage("Error while resetting user profile during Self Service recovery");
				emptyPwdFields();
				return null;
			}
		} catch (OperationFailedException ofe) {
			logger.error("Error while resetting user profile during Self Service recovery: ", ofe);
			setErrorMessage(ofe.getMessage());
			emptyPwdFields();
			return null;
		}

		try {
			// Changing the Password of a user
			UserChangePasswordServiceRequest userChangePasswordServiceRequest = new UserChangePasswordServiceRequest();
			userChangePasswordServiceRequest.setPassword(userVO.getPassword());
			userChangePasswordServiceRequest.setUser(eSSOUserVO);
			UserChangePasswordServiceResponse changePwdResponse = getContainer().getCredentialService()
					.changePwd(userChangePasswordServiceRequest);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(changePwdResponse.getExecutionStatus().getStatusCd()))
				logger.debug(userVO.getUserName() + " password changed successfully during self service recovery");
			else {
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
				userProfileServiceRequest.setUser(eSSOUserVO);
				getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest, userVO);
				/*if (changePwdResponse.getReasonCode().equalsIgnoreCase("PASSWORD_MANAGEMENT_ERROR"))
				{
					addFacesMessage("resetSecCredentialsFormId:pwd",
							tbResources.getString("blackListedPasswordMsg"));
					setErrorMessage("");
				}
				else
				{
					setErrorMessage(changePwdResponse.getReasonMessage());
				}*/
				setErrorMessage(changePwdResponse.getReasonMessage());
				emptyPwdFields();
				return null;
			}
		} catch (OperationFailedException ofe) {
			logger.error("Error while changing user password during Self Service recovery: ", ofe);
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(eSSOUserVO);
			getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest, userVO);
			setErrorMessage(ofe.getMessage());
			/*if (ofe.getMessage().contains(tbResources.getString("blackListedPasswordMsg")))
			{
				addFacesMessage("resetSecCredentialsFormId:pwd",
						tbResources.getString("blackListedPasswordMsg"));
				setErrorMessage("");
			}*/
			emptyPwdFields();
			return null;
		}
		if (!userVO.getEmailAddress().equalsIgnoreCase(eSSOUserVO.getEmailAddress())) {
			VerifyCodesContext ctx = new VerifyCodesContext();
			ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			ctx.setHideUpdateButtons(true);
			ctx.setShowDeviceRegistration(false);
			ctx.setNextView("/views/selfrecoverysuccess.xhtml?faces-redirect=true");
			ctx.setUserVO(getCurrentUserVO());
			getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);	
			if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {
				return VerifyCodesBean.VERIFY_CODES_VIEW;	
			}
			else {
				// TODO: double check
				//ctx.setAutoVerify(true);
				//return VerifyCodesBean.VERIFY_CODES_VIEW;	
			}
		}
		removeSessionWithoutRelyingPartyInfo();
		return "/views/selfrecoverysuccess.xhtml?faces-redirect=true";
	}
	
	
	public String setSecurityQuestions() {
		setErrorMessage("");
		if (!validateSecurityAnswers("")) {
			setErrorMessage(tbResources.getString("setSecurityErrorMessage"));
			return null;
		}

		try {

			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userVO.setEmailAddress(eSSOUserVO.getEmailAddress());
			userProfileServiceRequest.setUser(userVO);
			populateSecurityQuestions(userVO);

			UserProfileServiceResponse response = getContainer().getUserService().resetUserProfileForSelfService(userProfileServiceRequest,
					eSSOUserVO);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
				logger.debug(userVO.getUserName() + " profile updated successfully while setting secuirty questions");
			} else {
				logger.debug("Error while resetting user profile while setting secuirty questions: "
						+ response.getExecutionStatus().getStatusMessage());
				setErrorMessage("Error while resetting user profile while setting security questions");
				return null;
			}

		} catch (OperationFailedException ofe) {
			logger.error("Error while unlocking or updating the user profile while setting secuirty questions page for user: {}",
					new String[]{eSSOUserVO.getUserName(), TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
			setErrorMessage(extractErrorMessageFromOFE(ofe));
			return null;
		}

		@SuppressWarnings("unchecked")
		Map<String, String> userDetails = (HashMap<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		String authCode = userDetails.get("authCode");
		if (StringUtils.isNotEmpty(authCode)) {
			getContainer().getUserService().invalidateUserAuthCode(authCode);
			SecurityLoggingUtil.info("SetSecurity Questions", SecurityEventType.E3_MODIFY, getServletRequest(),
					eSSOUserVO.getUserName(),
					"Security Audit Event|setSecurityQuestions:SUCCESS|Authorization Code Processed , "
							+ "ResetSecurityCredentialsBean:setSecurityQuestions()", SecurityEventResult.SUCCESS,
					getRelyingPartyAppId(), SecuritySubEventType.E3_MODIFY_SECURITY_QUESTIONS);
		}
		removeSessionWithoutRelyingPartyInfo();
		getSessionMap().put("sqamissing_username", userVO.getUserName());
		return "/views/setsecsuccess.xhtml?faces-redirect=true";
	}

	public boolean isPwdDoNotMatch() {
		return pwdDoNotMatch;
	}

	public void setPwdDoNotMatch(boolean pwdDoNotMatch) {
		this.pwdDoNotMatch = pwdDoNotMatch;
	}
	
	public void processRPreg()
	{
		setShowQuestions(false);
		QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
		queryRelyingPartyResponse = container.getConfigService().queryRelyingParty((String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS));
		QueryTierResponse queryTierResponse = new QueryTierResponse();
			if(queryRelyingPartyResponse!=null &&  queryRelyingPartyResponse.getRelyingParty()!=null) {
			RelyingParty rp = queryRelyingPartyResponse.getRelyingParty();
				if(rp.getTiers() != null && rp.getTiers().size() > 0) {
					TierConfig tierConfig = rp.getTiers().get(0);
					userVO.setTierId(tierConfig.getTierId());
					queryTierResponse = container.getConfigService().queryTier(tierConfig.getTierId());
					if(queryTierResponse!=null && queryTierResponse.getTierDefinition()!=null)
					{
						List<TierAttribute> tierAttributes= queryTierResponse.getTierDefinition().getTierAttributes();
						for (Iterator<TierAttribute> iterator = tierAttributes.iterator(); iterator.hasNext();) {
							TierAttribute tierAttribute = iterator.next();
							if (tierAttribute.getName().equalsIgnoreCase(TrustBrokerConstants.EMAIL_ADDRESS)) {
								if (!tierAttribute.isMandatory())
									setEmailMandatory(false);
								if (tierAttribute.isUnique())
									setEmailShared(false);
							}
						}
					}
					
					List<AuthenticationType> authenticationTypes= tierConfig.getAuthenticationTypes();
					if(null != authenticationTypes && authenticationTypes.size() == 1) {
						if(authenticationTypes.get(0).value().equalsIgnoreCase(AuthenticationType.PASSWORD.value()))
							setShowQuestions(false);
					} else {
						for (Iterator<AuthenticationType> iterator = authenticationTypes.iterator(); iterator.hasNext();) {
							AuthenticationType authenticationType = iterator.next();
							if (authenticationType.value().equalsIgnoreCase(AuthenticationType.SECURITY_QUESTIONS.value()))
								setShowQuestions(true);
						}
					}
				}
		}
	}
	
	
	/**
	 * This method is used to build account recovery methods for the user 
	 * 
	 */
	private void buildRecoveryMethods() {	
		SelectItem item = null;
		this.acctRecoveryMethods.clear();
		if(!StringUtils.isEmpty(userVO.getEmailAddress())) {
			item = new SelectItem(SECEMAIL_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_SecEmailVal"));
			this.acctRecoveryMethods.add(item);
		}		
		item = new SelectItem(MOBILE_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_MobileVal"));
		this.acctRecoveryMethods.add(item);
		item = new SelectItem(SECQUESTS_ACCT_REC_METHOD, tbResources.getString("AcctRecovery_SecQuestVal"));
		this.acctRecoveryMethods.add(item);
	}
	
	public void checkRecvrySecEmailAddr(ValueChangeEvent event) {
        emailExistsMsg = "";
        PhaseId phaseId = event.getPhaseId();
        
        if (phaseId.equals(PhaseId.ANY_PHASE)) {
               event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
               event.queue();             
               validateRecoverySecEmail(event.getNewValue().toString());                 
        } else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
               boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
               logger.debug("result value in updateEmail: " + result);
               if (!result) {
                      addFacesMessage("resetSecCredentialsFormId:secEmailAddress",tbResources.getString("invalidEmailAddress"));
               } 
        }
        logger.debug("getEmailExistsMsg(): " + getEmailExistsMsg());
	}
	
	private boolean validateRecoverySecEmail(String email) {
		boolean validEmail = true;		
		if(StringUtils.isEmpty(email)) {
			addFacesMessage("resetSecCredentialsFormId:secEmailAddress",tbResources.getString("regnacctrecoverySecEmailReqMsg"));
			validEmail = false;
		} else if(!TBUtil.validateEmailId(email)){
			validEmail = false;
            addFacesMessage("resetSecCredentialsFormId:secEmailAddress",tbResources.getString("invalidEmailAddress"));
        } else  if (userVO.getEmailAddress().equalsIgnoreCase(email)) { 
        	validEmail = false;
     	   addFacesMessage("resetSecCredentialsFormId:secEmailAddress",tbResources.getString("emailAlreadyExists"));
        } else if(container.getUserService().isEmailExists(email)){
    		validEmail = false;
       	   addFacesMessage("resetSecCredentialsFormId:secEmailAddress",tbResources.getString("emailAlreadyExists"));
        }
		return validEmail;
	}
	
	public void pageChanged(ItemChangeEvent event) {
		setErrorMessage("");
		setAcctRecoveryErrorMsg("");
		setEmailExistsMsg("");
		setSharedEmailErrorMsg("");
		byPassConfirmation=false;
		if ("resetSecurityCredForRecovery".equalsIgnoreCase(getCurrentButtonId())) {
			boolean pwdValidated = validatePasswordFields();
			boolean secValidated = true;
			boolean emailValidated = validateEmailFields();
			
			if(showQuestions)
				secValidated = validateSecurityAnswers("");
			
			if(pwdValidated && secValidated && emailValidated) {
				
				resetForLostRecoveryMethods();
			
				/*
				if((StringUtils.isEmpty(userVO.getEmailAddress()) || 
						(isUserEmailShared(userVO)&& (StringUtils.isNotBlank(geteSSOUserVO().getEmailAddress()) 
								&& !geteSSOUserVO().getEmailAddress().equalsIgnoreCase(userVO.getEmailAddress())))) 
						&& !showQuestions) {
					//Build account recovery options list
					buildRecoveryMethods();
					setCurrentActiveItem("resetacctrecovery");
				} else
					resetForLostRecoveryMethods();
				*/
				
			} else {
				emptyPwdFields();
				setCurrentActiveItem("resetSecurityCredForRecovery");
			}
				
			
		}
		/*
		
		if ("resetacctrecovery".equalsIgnoreCase(getCurrentButtonId())) {
			userVO.setUserChallengeQuestions(null);
			//validate the account recovery fields			
			if(StringUtils.isEmpty(this.acctRecoveryMethod) || "null".equalsIgnoreCase(this.acctRecoveryMethod)) {
				addFacesMessage("resetSecCredentialsFormId:regnRecoveryType",tbResources.getString("regnacctrecoveryMethodReqMsg"));
				setCurrentActiveItem("resetacctrecovery");		
				return;
			} else 	if(SECEMAIL_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {				
				if(!validateRecoverySecEmail(userVO.getSecEmailAddress())) {
					setCurrentActiveItem("resetacctrecovery");
					return;
				} else if(StringUtils.isNotBlank(eSSOUserVO.getSecEmailAddress()) && userVO.getSecEmailAddress().equalsIgnoreCase(eSSOUserVO.getSecEmailAddress())) {
						setAcctRecoveryErrorMsg("You have indicated that you lost access to your secondary email: " + eSSOUserVO.getSecEmailAddress()
					+ ". Please modify"); 
					setCurrentActiveItem("resetacctrecovery");
					return;
				}			
				userVO.setEssoSecEmail(userVO.getSecEmailAddress());
			} else if (MOBILE_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {
				if(StringUtils.isEmpty(getMobilePhone())) {
					addFacesMessage("resetSecCredentialsFormId:mobilenum",tbResources.getString("regnacctrecoveryMobilReqMsg"));
					setCurrentActiveItem("resetacctrecovery");
					return;
				} else if(StringUtils.isNotBlank(eSSOUserVO.getPhoneNumber()) && getMobilePhone().equalsIgnoreCase(eSSOUserVO.getPhoneNumber())) {
						setAcctRecoveryErrorMsg("You have indicated that you lost access to your mobile phone: " + eSSOUserVO.getPhoneNumber()
					+ ". Please modify"); 
					setCurrentActiveItem("resetacctrecovery");
					return;
				}
				userVO.setPhoneNumber(getMobilePhone());
			} else if (SECQUESTS_ACCT_REC_METHOD.equals(this.acctRecoveryMethod)) {
				if(!validateSecurityAnswers("actrcy")) {
					setCurrentActiveItem("resetacctrecovery");
					return;
				}
				populateSecurityQuestions(userVO);
			} 			
			resetForLostRecoveryMethods();
		}
		*/
		
	}

	private void resetForLostRecoveryMethods() {
		try {
			// Unlocking the user account if the user account is locked either at LDAP or RSA
			EnableUserServiceRequest enableUserServiceRequest = new EnableUserServiceRequest();
			enableUserServiceRequest.setUser(eSSOUserVO);
			ServiceResponse serviceResponse;

			if (TrustBrokerConstants.PWD_DISABLED.equalsIgnoreCase(eSSOUserVO.getPwdStatus())
					|| TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(eSSOUserVO.getAaStatus())) {
				logger.debug("Unlock the user at LDAP");
				// Unlocking the user at LDAP
				enableUserServiceRequest.setPasswordEnable(false);
				serviceResponse = getContainer().getCredentialService().enableUser(enableUserServiceRequest);
				if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(serviceResponse.getExecutionStatus().getStatusCd())) {
					setErrorMessage("Unlocking the user failed");
					emptyPwdFields();
					setCurrentActiveItem("resetSecurityCredForRecovery");
					return;
				}
			}

			if (TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(eSSOUserVO.getAaStatus())) {
				// Unlocking the user at RSA
				logger.debug("Unlock the user at RSA");
				ResetUserRSAProfileRequest request = new ResetUserRSAProfileRequest();
				request.setUser(eSSOUserVO);
				serviceResponse = getContainer().getUserService().resetUserRSAProfile(request);
				if (TrustBrokerConstants.FAILURE_CODE_VALUE.equalsIgnoreCase(serviceResponse.getExecutionStatus().getStatusCd())) {
					setErrorMessage("Unlocking the user failed");
					emptyPwdFields();
					setCurrentActiveItem("resetSecurityCredForRecovery");
					return;
				}
			}

			// Modifying the eSSO user
			UserVO modifyUserVO = new UserVO();
			BeanUtils.copyProperties(eSSOUserVO, modifyUserVO);
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(modifyUserVO);
			modifyUserVO.setEmailAddress(userVO.getEmailAddress());
			
			if(null != userVO.getUserChallengeQuestions() && userVO.getUserChallengeQuestions().size() > 0)
				modifyUserVO.setUserChallengeQuestions(userVO.getUserChallengeQuestions());

			userProfileServiceRequest.setOldUser(eSSOUserVO);
			UserProfileServiceResponse response = getContainer().getUserService().modifyUser(userProfileServiceRequest, false);
			
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())
					||(response.getReasonCode() != null && TrustBrokerConstants.OPT_ERR_001.equals(response.getReasonCode()))) {
				logger.debug(userVO.getUserName() + " profile updated successfully during self service recovery");
			} else {
				logger.debug("Error while resetting user profile during Self Service recovery: "
						+ response.getExecutionStatus().getStatusMessage());
				setErrorMessage("Error while resetting user profile during Self Service recovery");
				emptyPwdFields();
				setCurrentActiveItem("resetSecurityCredForRecovery");
				return;
			}
		} catch (OperationFailedException ofe) {
			logger.error("Error while resetting user profile during Self Service recovery: ", ofe);
			setErrorMessage(ofe.getMessage());
			emptyPwdFields();
			setCurrentActiveItem("resetSecurityCredForRecovery");
			return;
		}

		try {
			// Changing the Password of a user
			UserChangePasswordServiceRequest userChangePasswordServiceRequest = new UserChangePasswordServiceRequest();
			userChangePasswordServiceRequest.setPassword(userVO.getPassword());
			userChangePasswordServiceRequest.setUser(eSSOUserVO);
			UserChangePasswordServiceResponse changePwdResponse = getContainer().getCredentialService()
					.changePwd(userChangePasswordServiceRequest);
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(changePwdResponse.getExecutionStatus().getStatusCd()))
				logger.debug(userVO.getUserName() + " password changed successfully during self service recovery");
			else {
				UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
				userProfileServiceRequest.setUser(eSSOUserVO);
				userProfileServiceRequest.setOldUser(userVO);
				getContainer().getUserService().modifyUser(userProfileServiceRequest, false);
				setErrorMessage(changePwdResponse.getReasonMessage());
				emptyPwdFields();
				setCurrentActiveItem("resetSecurityCredForRecovery");
				return;
			}
		} catch (OperationFailedException ofe) {
			logger.error("Error while changing user password during Self Service recovery: ", ofe);
			UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
			userProfileServiceRequest.setUser(eSSOUserVO);
			userProfileServiceRequest.setOldUser(userVO);
			getContainer().getUserService().modifyUser(userProfileServiceRequest, false);
			setErrorMessage(ofe.getMessage());
			emptyPwdFields();
			setCurrentActiveItem("resetSecurityCredForRecovery");
			return;
		}
		
		VerifyCodesContext ctx = new VerifyCodesContext();
		
		if (StringUtils.isNotBlank(userVO.getEmailAddress())
				&& (StringUtils.isNotBlank(geteSSOUserVO().getEmailAddress()) && !geteSSOUserVO().getEmailAddress().equalsIgnoreCase(userVO.getEmailAddress()))
				) {
			userVO.setIsemailVerified(false);
			ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
		}
		if(null != ctx.getViewChannels() && ctx.getViewChannels().size() > 0) {
			ctx.setHideUpdateButtons(false);
			ctx.setNextView("/views/selfrecoverysuccess.jsf");
			ctx.setUserVO(userVO);
			getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);
			if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {
				redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
			} else
				redirectToView("/views/selfrecoverysuccess.jsf");
		} else
			redirectToView("/views/selfrecoverysuccess.jsf");
	}
	
	/**
	 * This method is used to return to reset security page
	 * 
	 */
	public void cancelAcctRecovery() {
		clearAcctRecoveryFields();
		setErrorMessage("");
		setAcctRecoveryErrorMsg("");
		setCurrentActiveItem("resetacctrecovery");
		return;
	}
	
	
	public void skipAccountRecoveryOptions() {
		clearAcctRecoveryFields();
		setErrorMessage("");
		setAcctRecoveryErrorMsg("");
		byPassConfirmation=true;
		resetForLostRecoveryMethods();
	}
	
	private void clearAcctRecoveryFields() {
		tbSecurityQuestionsBean.setSecurityQuestionOne(null);
		tbSecurityQuestionsBean.setSecurityQuestionTwo(null);
		tbSecurityQuestionsBean.setSecurityQuestionThree(null);
		tbSecurityQuestionsBean.setSecurityAnswerOne("");
		tbSecurityQuestionsBean.setSecurityAnswerTwo("");
		tbSecurityQuestionsBean.setSecurityAnswerThree("");
		userVO.setSecEmailAddress(null);
		setMobilePhone(null);
		setAcctRecoveryMethod("null");
	}
	
	public void returnToResetPage() {
		clearAcctRecoveryFields();
		setCurrentActiveItem("resetSecurityCredForRecovery");
		return;
	}

}