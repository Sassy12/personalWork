package com.optum.trustbroker.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

/**
 * Filter implementation class RequestSecurityFilter
 */
public class RequestSecurityFilterOldGen implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {

        if (servletRequest instanceof HttpServletRequest) {
            HttpServletRequest hsReq = (HttpServletRequest) servletRequest;

            HttpSession session = null;
            try {
                session = hsReq.getSession(false);
            } catch (IllegalStateException ex) {
                session = null;
            }

            //CSRF check is done only for POST calls
            if ("POST".equalsIgnoreCase(hsReq.getMethod()) && session != null) {
                //check for custom header parameter in the request
                if (hsReq.getParameter("CSRF_ID") == null) {
                    throw new WebApplicationException(Response.Status.BAD_REQUEST);
                } else {
                    String sCsrfId = (String) hsReq.getSession().getAttribute("CSRF_ID");
                    String rCsrfId = hsReq.getParameter("CSRF_ID");
                    if (!sCsrfId.equalsIgnoreCase(rCsrfId.split(":")[0])) {
                        throw new WebApplicationException(Response.Status.BAD_REQUEST);
                    }
                }
            }
        }

        filterChain.doFilter(servletRequest, servletResponse);

    }

    @Override
    public void destroy() {}
}
