package com.optum.trustbroker.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.uhg.iam.alps.common.crypto.CryptAgent;

/**
 * Performs OpenId Connection logic specific to application entry points. The logic converts the OpenID Connect specific request parameters into the
 * application expected format for processing.
 *
 * <p>
 * If this method detects OpenId Connect specific parameters, then it encodes them into an encoded OpenID parameter and adds them as a parameter value
 * for the standard entry point parameter list.
 * </p>
 */
public class OidcParamFilter implements Filter {
    private CryptAgent cryptAgent;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        WebApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(filterConfig.getServletContext());
        if (ctx == null) {
            throw new ServletException("couldn't get spring context");
        }
        cryptAgent = (CryptAgent) ctx.getBean("cryptAgent");
        if (cryptAgent == null) {
            throw new ServletException("couldn't get cryptAgent from spring context");
        }
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
        throws IOException, ServletException {
        com.optum.trustbroker.context.WebApplicationContext wac = WebApplicationContextHolder.getContext();
        // check one parameter first to see if it is an OpenID Connect initialization
        String clientId = servletRequest.getParameter(TrustBrokerWebAppConstants.OpenIDConnect.CLIENT_ID);
        String redirectUri = servletRequest.getParameter(TrustBrokerWebAppConstants.OpenIDConnect.REDIRECT_URI);
        String resumeUri = servletRequest.getParameter(TrustBrokerWebAppConstants.OpenIDConnect.RESUME_URI);
        String state = servletRequest.getParameter(TrustBrokerWebAppConstants.OpenIDConnect.STATE);
        String responseType = servletRequest.getParameter(TrustBrokerWebAppConstants.OpenIDConnect.RESPONSE_TYPE);
        String oidData = servletRequest.getParameter(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
        DateUtil dateUtil = DateUtil.getInstance();
        String requestTime = DateUtil.formatDate(dateUtil.getCurrentDateinGMT(), DateUtil.DATE_TIME_FORMAT_WITH_MILIS);
        wac.removeSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.ERROR);
        // check if all required params are here
        if (clientId != null && resumeUri != null && redirectUri != null) {
            addToSession(wac, clientId, redirectUri, resumeUri, requestTime, state, responseType);
        }
        else if (oidData != null) {
            String preExistingResumeUri = wac.getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.RESUME_URI);
            Map<String, String> oidMap = cryptAgent.getAttributesFromToken(oidData, true);
            clientId = oidMap.get(TrustBrokerWebAppConstants.OpenIDConnect.CLIENT_ID);
            redirectUri = oidMap.get(TrustBrokerWebAppConstants.OpenIDConnect.REDIRECT_URI);
            resumeUri = oidMap.get(TrustBrokerWebAppConstants.OpenIDConnect.RESUME_URI);
            // TODO is this correct?
            //requestTime = oidMap.get(TrustBrokerWebAppConstants.OpenIDConnect.REQUEST_TIME);
            state = oidMap.get(TrustBrokerWebAppConstants.OpenIDConnect.STATE);
            responseType = oidMap.get(TrustBrokerWebAppConstants.OpenIDConnect.RESPONSE_TYPE);
            addToSession(wac, clientId, redirectUri, resumeUri, requestTime, state, responseType);
            if (preExistingResumeUri == null || !preExistingResumeUri.equals(resumeUri)) {
                wac.setSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.ERROR, TrustBrokerWebAppConstants.OpenIDConnect.ERROR);
            }
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    private void addToSession(com.optum.trustbroker.context.WebApplicationContext wac, String clientId, String redirectUri, String resumeUri,
        String requestTime, String state, String responseType) {
        wac.setSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, clientId);
        wac.setSessionAttribute(TrustBrokerWebAppConstants.TARGET, redirectUri);
        wac.setSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.RESUME_URI, resumeUri);
        wac.setSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.REQUEST_TIME, requestTime);
        if (StringUtils.isNotBlank(state)) {
            wac.setSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.STATE, state);
        }
        if (StringUtils.isNotBlank(responseType)) {
            wac.setSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.RESPONSE_TYPE, responseType);
        }
    }

    @Override
    public void destroy() {
    }
}
