'use strict';
//service for getting the error messages based on errorCodes and referenceCode
angular.module('indexApp').service('genErrorService',['$http', function($http){
	this.getErrorMessage = function(errorcode){		
		return $http.post('/tb/services/rest/commonController/getErrorMessageWithSupportInfo', errorcode);
	};
}]);
