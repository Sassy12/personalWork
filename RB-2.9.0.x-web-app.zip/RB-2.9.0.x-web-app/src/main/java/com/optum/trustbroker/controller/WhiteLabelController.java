/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 * 
 ***********************************************
 * Modification History
 * When          Who         Why
 * Jan 15, 2016  bmanna3	Initial version
 ****************************************************************/
package com.optum.trustbroker.controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.vo.RPWhiteLabelVO;

/**
 * The service class provides REST services for white labeling functionality.
 * 
 */

@Path(TBConstants.WHITE_LBL_CONTROLLER_PATH)
public class WhiteLabelController extends BaseController {

    private static final Logger LOG = Logger.getLogger(WhiteLabelController.class);

    // Siteminder application param name
    private static final String SM_APP_NAME = "sm";

    // AA web application param name
    private static final String AAWEB_APP_NAME = "aaweb";

    /**
     * This service method is to get the relying party application css content
     * for the given RP app id. If RP app id is not passed as parameter, then it
     * will try to get the RP app id from session or cookie. If RP app id is
     * invalid or empty, returns empty style.
     * 
     * @param appName
     *            String
     * @param rpApplicationId
     *            String
     * @param request
     *            http request
     * @return Response
     */
    @GET
    @Path(value = "/css{appName:(/[^/]+?)?}{p:/?}{rpid:(/[^/]+?)?}")
    public Response getRPAppStyle(@PathParam("appName") String appName, @PathParam("rpid") String rpApplicationId,
            @Context HttpServletRequest request) {
        final String contentType = "text/css";
        Response response = null;
        String rpAppId = rpApplicationId;
        // If RP id request param is empty, get it from session or cookie
        if (StringUtils.isBlank(rpAppId)) {
            rpAppId = getRPIdFromHttpRequest(request);
        }
        String attributeType = getAttributeType(appName);
        if (StringUtils.isNotBlank(rpAppId)) {
            int fileTypeInd = rpAppId.toLowerCase().lastIndexOf(".css");
            if (fileTypeInd > 0) {
                rpAppId = rpAppId.substring(0, fileTypeInd);
            }
            try {
                // Gets the RP css content details
                List<RPWhiteLabelVO> rpAppStyles = relyingPartyAppService.getRPAppStyles(rpAppId, attributeType);
                // Get the RP css content
                RPWhiteLabelVO rpAppStyle = getRPAppStyle(rpAppStyles);
                if (rpAppStyle != null) {
                    response = Response.ok(rpAppStyle.getFileContent(), contentType).build();
                }
            } catch (Exception e) {
                LOG.error("Exception in getting RP app style ", e);
            }
        }
        if (response == null) {
            response = Response.ok().type(contentType).build();
        }
        return response;

    }

    /**
     * This method is used to get the relying party application css content
     * 
     * @param rpAppStyles
     *            List&lt;RPWhiteLabelVO&gt;
     * @return RPWhiteLabelVO
     */
    private RPWhiteLabelVO getRPAppStyle(List<RPWhiteLabelVO> rpAppStyles) {
        RPWhiteLabelVO rpAppStyle = null;
        if (rpAppStyles != null && !rpAppStyles.isEmpty()) {
            Iterator<RPWhiteLabelVO> rpAppStyleItr = rpAppStyles.iterator();
            while (rpAppStyleItr.hasNext()) {
                rpAppStyle = rpAppStyleItr.next();
            }
        }
        return rpAppStyle;
    }

    /**
     * This method is used to get the relying party id from the cookie or
     * session if it is not passed as parameter.
     * 
     * @param request
     *            HttpServletRequest
     * @return String
     */
    private String getRPIdFromHttpRequest(HttpServletRequest request) {
        String rpAppId = null;
        if (request != null) {
            Cookie[] cookies = request.getCookies();
            if (cookies != null) {
                for (int i = 0; i < cookies.length; i++) {
                    if ("relyingAppId".equalsIgnoreCase(cookies[i].getName())) {
                        rpAppId = cookies[i].getValue();
                        break;
                    }
                }
            }
        }
        return rpAppId;
    }

    /**
     * This method is used to get the attribute type for the given app name.
     * 
     * @param appName
     *            String
     * @return String
     */
    private String getAttributeType(String appName) {
        String attributeType = TrustBrokerConstants.TB_APP_STYLE_ATTR_TYP;
        if (StringUtils.isNotBlank(appName)) {
            if (SM_APP_NAME.equalsIgnoreCase(appName)) {
                attributeType = TrustBrokerConstants.SM_APP_STYLE_ATTR_TYP;
            } else if (AAWEB_APP_NAME.equalsIgnoreCase(appName)) {
                attributeType = TrustBrokerConstants.AAWEB_APP_STYLE_ATTR_TYP;
            }
        }
        return attributeType;
    }

}