(function() {
    'use strict';

    var module = angular.module('indexApp');

    module.controller('findUserCtrl', ['$scope', '$state', '$timeout', 'trustbrokerAriaService', 'LanguageService', 'forgotAccessService', '$rootScope', 'HelpObj',
    function($scope, $state, $timeout, trustbrokerAriaService, LanguageService, forgotAccessService, $rootScope, HelpObj) {

        HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1024_Forgot_Optum_ID_more_details_entered_shared_email_address.htm' });

        LanguageService.doTranslate("selfservice");

        $scope.setFieldValidity = function(inputid, spanid) {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        };

        $scope.firstNameErrFlag = false;
        $scope.lastNameErrFlag = false;
        $scope.accountSearchCount = 0;
        $scope.disableNext = false;

        $scope.errorMessageModel = {
            animationTime: 1,
            ariaAttributes: true,
            content: '',
            headingLevel: '2',
            id: 'errorMessage',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: false
        };

        $scope.goToLogin = function() {
            $state.go('login');
        };

        $scope.onKeyUp = function(fieldId, errorId, fldErrorFlag, fldErrorMsg) {
            var fldValue = angular.element("#" + fieldId).val();

            if (fldValue !== '' && fldValue !== undefined) {
                trustbrokerAriaService.removeDescribedByAttribute(fieldId, errorId);
                $scope[fldErrorFlag] = false;
            } else if ($scope[fldErrorMsg] !== "" && $scope[fldErrorMsg] !== undefined) {
                trustbrokerAriaService.appendDescribedByAttribute(fieldId, errorId);
                $scope[fldErrorFlag] = true;
            }
        };

        $scope.findUserName = function() {
            $scope.validationProcess();
        };

        $scope.validationProcess = function() {
            $scope.firstNameErrFlag = false;
            $scope.lastNameErrFlag = false;

            if (($scope.firstName === '' || $scope.firstName === undefined) || ($scope.lastName === '' || $scope.lastName === undefined)) {
                if ($scope.firstName === '' || $scope.firstName === undefined) {
                    $scope.firstNameIsEmpty();
                }

                if ($scope.lastName === '' || $scope.lastName === undefined) {
                    $scope.lastNameIsEmpty();
                }

                if ($scope.firstNameErrFlag || $scope.lastNameErrFlag) {
                    $scope.ariaUpdate();
                }

                $rootScope.fireErrorTracker = true;
            } else {
                $scope.findUserDetails();
            }
        };

        $scope.firstNameIsEmpty = function() {
            $scope.findUserNameForm.submitted = true;
            $scope.firstNameErrFlag = true;
            $scope.errorMsgForFirstName = 'errorMsgForFirstName';
            $scope.setFormErrMsg();
        };

        $scope.lastNameIsEmpty = function() {
            $scope.findUserNameForm.submitted = true;
            $scope.lastNameErrFlag = true;
            $scope.errorMsgForLastName = 'errorMsgForLastName';
            $scope.setFormErrMsg();
        };

        $scope.setFormErrMsg = function() {
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1" />';
            $scope.errorMessageModel.visible = true;
        };

        $scope.disableNextButton = function() {
            $scope.errorMessageModel.content = '<span translate="disablePageMsg" />';
            $scope.errorMessageModel.visible = true;
            $scope.disableNext = true;

            // For WCAG
            $timeout(function() {
                angular.element('#errorMessage').focus();
            }, 300);

            // To enable the field after 2 mins
            $timeout(function() {
                $state.reload();
            }, 120000);
        };

        $scope.disableNextButtonWarning = function() {
            $scope.errorMessageModel.content = '<span translate="disablePageWarningMsg" />';
            $scope.errorMessageModel.visible = true;

            // For WCAG
            $timeout(function() {
                angular.element('#errorMessage').focus();
            }, 300);
        };

        $scope.findUserDetails = function() {
            $scope.accountNotFound = false;

            forgotAccessService.verifyuserwithfirstnameandlastname($scope.firstName, $scope.lastName).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;
                $scope.invalidRecoveryOptns = responseVO.invalidRecoveryOptns;
                $scope.skipAccountRecovery = responseVO.skipAccountRecovery;

                if (status) {
                    var passRequestParameter = { 'userName': responseVO.userName };

                    if ($scope.invalidRecoveryOptns) {
                        $state.go('norecoveryoption');
                    } else if ($scope.skipAccountRecovery) {
                        var successMessageKey = responseVO.successMessageKey;
                        $state.go('login', { 'prevState': successMessageKey });
                    } else {
                        $state.go('forgotCredByIdentity', { userinfo: passRequestParameter });
                    }
                } else {
                    $scope.processErrorMessages(responseVO);
                    $rootScope.fireErrorTracker = true;
                }
            });
        };

        $scope.processErrorMessages = function(responseVO) {
            var messages = responseVO.messages;

            var firstnamerequired = messages.firstnamerequired,
                lastnamerequired = messages.lastnamerequired,
                acctnotfound = messages.acctnotfound,
                emailrequired = messages.emailrequired,
                useracctlocked = messages.useracctlocked;

            $scope.errorMessageModel.visible = true;

            if (firstnamerequired !== '' && firstnamerequired !== undefined) {
                $scope.firstNameErrFlag = true;
                $scope.errorMsgForFirstName = 'errorMsgForFirstName';
                $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1" />';
            }

            if (lastnamerequired !== '' && lastnamerequired !== undefined) {
                $scope.lastNameErrFlag = true;
                $scope.errorMsgForLastName = 'errorMsgForLastName';
                $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1" />';
            }

            if (emailrequired !== '' && emailrequired !== undefined) {
                $scope.errorMessageModel.content = '<span>' + emailrequired + '</span>';
            }

            if (acctnotfound !== '' && acctnotfound !== undefined) {
                $scope.errorMessageModel.content = '<span>' + acctnotfound + '</span>';
                $scope.accountSearchCount++;
            }

            if (useracctlocked !== '' && useracctlocked !== undefined) {
                $scope.errorMessageModel.content = '<span>' + useracctlocked + '</span>';
            }

            $scope.ariaUpdate();

            if ($scope.accountSearchCount === 4) {
                $scope.disableNextButtonWarning();
            }

            if ($scope.accountSearchCount >= 5) {
                $scope.disableNextButton();
            }
        };

        $scope.ariaUpdate = function() {
            var FIELDS = [];
            var ind = 0;

            if ($scope.firstNameErrFlag) {
                FIELDS[ind] = { fld: "firstNameId_input", msg: "firstNameId_err" };
                ind++;
            }

            if ($scope.lastNameErrFlag) {
                FIELDS[ind] = { fld: "lastNameId_input", msg: "lastNameId_err" };
                ind++;
            }

            if (FIELDS.length > 0) {
                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    $scope.formErrorIsHidden = false;
                }, 300);
            } else {
                $timeout(function() {
                    angular.element('#errorMessage').focus();
                }, 300);
            }
            return;
        };
    }]);
})();
