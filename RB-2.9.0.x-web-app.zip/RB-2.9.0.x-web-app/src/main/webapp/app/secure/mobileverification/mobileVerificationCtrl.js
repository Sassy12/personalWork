'use strict';

var tbApp = angular.module('tbApp');

tbApp.controller("mobileVerificationCtrl", ['$scope', 'mobileVerificationService', '$state', '$stateParams', 'LanguageService', '$timeout', 'uitkLiveRegionService', '$translate', '$window', '$rootScope',
function($scope, mobileVerificationService, $state, $stateParams, LanguageService, $timeout, uitkLiveRegionService, $translate, $window, $rootScope) {
    LanguageService.doTranslate('mobileverification');
    $scope.mobileVerificationCodeError = false;
    var ctx = {};

    if ($stateParams.fieldToVerify === 'mobileNo') {
        ctx = {
            viewChannels: ['PHONE'],
            sendChannels: ['PHONE'],
            chann: 'PHONE'
        };
    }

    mobileVerificationService.checkForPreVerification(ctx);

    $scope.mobileVerificationErrorMessageModel = {
        animationTime: 1,
        content: '',
        headingLevel: '2',
        id: 'mobileVerificationFormLevelMsgID',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    $scope.mobileVerificationSuccessMessageModel = {
        autoFadeOut: false,
        content: '<span translate="mobileVerificationSuccessMsg"></span>',
        headingLevel: '2',
        id: 'mobileVerificationSuccFormLevelMsgID',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: true
    };

    $scope.takeToManageID = function() {
        $state.go('profile.profileinfo');
    };

    $scope.resendVerifictionCode = function() {
        $scope.mobileVerificationCodeError = false;
        $scope.mobileVerificationErrorMessageModel.content = '';
        $scope.mobileVerificationErrorMessageModel.visible = false;
        $scope.mobileVerificationForm.$setPristine();
        var serviceResponse = [];

        mobileVerificationService.resendCommChannelCode(ctx).then(function(response) {
            serviceResponse = response;

            if (serviceResponse.data.errorMap && Object.keys(serviceResponse.data.errorMap).length !== 0) {
                $scope.mobileVerificationCode = "";
                $scope.mobileVerificationErrorMessageModel.content = "<span>" + serviceResponse.data.errorMap.otpSendErrMsg + "</span>";
                $scope.mobileVerificationErrorMessageModel.visible = true;
            } else {
                $scope.mobileVerificationCode = "";
                $scope.mobileVerificationForm.$setPristine();
                $scope.mobileVerificationErrorMessageModel.content = '';
                $scope.mobileVerificationErrorMessageModel.visible = false;
                $scope.resendMsgText = serviceResponse.data.resentPhCode;
                $('main').focus();
                uitkLiveRegionService.alertMessage($translate.instant('mobileCodeResendmsg'));
            }
        });
    };

    $scope.redirectBack = function() {
        var fromState = $stateParams.fromState;

        if (fromState) {
            if (fromState === 'home') {
                $window.location.href = "/tb/app/secure/home.do";
            } else {
                $state.go(fromState);
            }
        } else {
            $state.go('profile.profileinfo');
        }
    };

    $scope.verify = function() {
        $scope.resendMsgText = '';
        $scope.mobileVerificationCodeError = false;
        $scope.mobileVerificationErrorMessageModel.content = '';
        $scope.mobileVerificationErrorMessageModel.visible = false;

        if ($scope.mobileVerificationForm.mobileVerificationCode.$error.required) {
            $scope.mobileVerificationErrorMessageModel.content = '<span>The highlighted errors must be corrected before you can continue.</span>';
            $scope.mobileVerificationErrorMessageModel.visible = true;
            $('main').focus();

            $timeout(function() {
                angular.element('#mobileVerificationCode_input').focus();
            }, 400);

            $rootScope.fireErrorTracker = true;
            return;
        }

        var serviceResponse = [];
        ctx.primaryCode = $scope.mobileVerificationCode;

        mobileVerificationService.verifyPhoneCode(ctx).then(function(response) {
            serviceResponse = response;

            if (serviceResponse.data.errorMap && Object.keys(serviceResponse.data.errorMap).length !== 0) {
                $scope.mobileVerificationErrorMessageModel.content = '<span>The highlighted errors must be corrected before you can continue.</span>';
                $scope.mobileVerificationErrorMessageModel.visible = true;

                if (serviceResponse.data.errorMap.phoneErr) {
                    $scope.mobileVerificationCodeError = serviceResponse.data.errorMap.phoneErr;
                }

                $rootScope.fireErrorTracker = true;

                $timeout(function() {
                    angular.element('#mobileVerificationCode_input').focus();
                }, 400);
            } else {
                $state.go('mobileVerificationSuccess');
            }
        });
    };
}]);
