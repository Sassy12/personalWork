package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.IrmLoggingUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

@ManagedBean(name = "updateSecurityQuestionsBean")
@SessionScoped
public class UpdateUserSecurityQuestionsBean extends AbstractBackingBean implements
		Serializable {

	private static final long serialVersionUID = 1L;
	
	BaseLogger logger = new BaseLogger(this.getClass());

	@ManagedProperty(value = "#{tbSecurityQuestionsBean}")
	private SecurityQuestionsBean tbSecurityQuestionsBean;

	@ManagedProperty(value = "#{userVO}") 
	private UserVO updateUserVO;
	
	@ManagedProperty(value = "#{userVO}")
	private UserVO sessionUserVO;
		
	UserRetrievalServiceResponse userRetrievalServiceResponse = null;
	
	private String updateUserSecQuestionPageUrl = "/secure/updatesecurityquestions.jsf";

	public UserVO getSessionUserVO() {
		return sessionUserVO;
	}

	public void setSessionUserVO(UserVO sessionUserVO) {
		this.sessionUserVO = sessionUserVO;
	}

	public UserVO getUpdateUserVO() {
		return updateUserVO;
	}

	public void setUpdateUserVO(UserVO updateUserVO) {
		this.updateUserVO = updateUserVO;
	}

	private String warningMsg;

	public String getWarningMsg() {
		return warningMsg;
	}

	public void setWarningMsg(String warningMsg) {
		this.warningMsg = warningMsg;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	private String emailErrorMsg;
	public String getEmailErrorMsg() {
		return emailErrorMsg;
	}

	public void setEmailErrorMsg(String emailErrorMsg) {
		this.emailErrorMsg = emailErrorMsg;
	}

	private String email;
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	private String emailAddress;
	
	private String successMsg;
	
	private String successSecMsg;

	public String getSuccessSecMsg() {
		return successSecMsg;
	}

	public void setSuccessSecMsg(String successSecMsg) {
		this.successSecMsg = successSecMsg;
	}

	private String errorMsg;

	private String generatedToken;
	private String securityQuestionOne;
	private String securityQuestionTwo;
	private String securityQuestionThree;
	private String securityAnswerOne;
	private String securityAnswerTwo;
	private String securityAnswerThree;
	
	private String emailExistsMsgSec;
	
	private String emailExistsMsg;
	
	private int messageCount=0;
	
	private String tempSecEmail;
	
	private String secQuestReqMsg = null;
	
	private boolean seqQnsBlankPass ;
	
	private boolean byPassSQUpdate ;
	
	private boolean emailMandatory = true;
	
	private boolean emailShared = true;
	
	private boolean emailWarnMsgInd = false;
	
	private boolean confEmailWarnMsgInd = false;
	
	private boolean secEmailRecoveryInd = false;
	
	private boolean mobileRecoveryInd = false;
	
	private boolean disableEmailField;
	
	private boolean disableSecAcctRecovery;
	
	private boolean disablePhoneAcctRecovery;
	
	private String secEmailHelpMessage;
	
	private String mobilePhoneHelpMessage;
	
	private boolean showEmailSaveMsg;
			
	public boolean isEmailMandatory() {
		return emailMandatory;
	}

	public void setEmailMandatory(boolean emailMandatory) {
		this.emailMandatory = emailMandatory;
	}

	public boolean isEmailShared() {
		return emailShared;
	}

	public void setEmailShared(boolean emailShared) {
		this.emailShared = emailShared;
	}

	public boolean isByPassSQUpdate() {
		return byPassSQUpdate;
	}

	public void setByPassSQUpdate(boolean byPassSQUpdate) {
		this.byPassSQUpdate = byPassSQUpdate;
	}

	public boolean isSeqQnsBlankPass() {
		return seqQnsBlankPass;
	}

	public void setSeqQnsBlankPass(boolean seqQnsBlankPass) {
		this.seqQnsBlankPass = seqQnsBlankPass;
	}

	public String getTempSecEmail() {
		return tempSecEmail;
	}

	public void setTempSecEmail(String tempSecEmail) {
		this.tempSecEmail = tempSecEmail;
	}

	public int getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(int messageCount) {
		this.messageCount = messageCount;
	}

	private static String updateEmailConfirmationPage="/secure/updateemailconfirmpage.jsf";

	protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");

	public SecurityQuestionsBean getTbSecurityQuestionsBean() {
		return tbSecurityQuestionsBean;
	}

	public String getGeneratedToken() {
		return generatedToken;
	}

	public void setGeneratedToken(String generatedToken) {
		this.generatedToken = generatedToken;
	}

	public void setTbSecurityQuestionsBean(
			SecurityQuestionsBean tbSecurityQuestionsBean) {
		this.tbSecurityQuestionsBean = tbSecurityQuestionsBean;
	}

	public String getSuccessMsg() {
		return successMsg;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getSecurityQuestionOne() {
		return securityQuestionOne;
	}

	public void setSecurityQuestionOne(String securityQuestionOne) {
		this.securityQuestionOne = securityQuestionOne;
	}

	public String getSecurityQuestionTwo() {
		return securityQuestionTwo;
	}

	public void setSecurityQuestionTwo(String securityQuestionTwo) {
		this.securityQuestionTwo = securityQuestionTwo;
	}

	public String getSecurityQuestionThree() {
		return securityQuestionThree;
	}

	public void setSecurityQuestionThree(String securityQuestionThree) {
		this.securityQuestionThree = securityQuestionThree;
	}

	public String getSecurityAnswerOne() {
		return securityAnswerOne;
	}

	public void setSecurityAnswerOne(String securityAnswerOne) {
		this.securityAnswerOne = securityAnswerOne;
	}

	public String getSecurityAnswerTwo() {
		return securityAnswerTwo;
	}

	public void setSecurityAnswerTwo(String securityAnswerTwo) {
		this.securityAnswerTwo = securityAnswerTwo;
	}

	public String getSecurityAnswerThree() {
		return securityAnswerThree;
	}

	public void setSecurityAnswerThree(String securityAnswerThree) {
		this.securityAnswerThree = securityAnswerThree;
	}
	
	/*public ConfigurationService getConfigService() {
		return configService;
	}

	public void setConfigService(ConfigurationService configService) {
		this.configService = configService;
	}*/
	
	public String getEmailExistsMsg() {
		return emailExistsMsg;
	}

	public void setEmailExistsMsg(String emailExistsMsg) {
		this.emailExistsMsg = emailExistsMsg;
	}

	public String getEmailExistsMsgSec() {
		return emailExistsMsgSec;
	}

	public void setEmailExistsMsgSec(String emailExistsMsgSec) {
		this.emailExistsMsgSec = emailExistsMsgSec;
	}
	
	public String getSecQuestReqMsg() {
		return secQuestReqMsg;
	}

	public void setSecQuestReqMsg(String secQuestReqMsg) {
		this.secQuestReqMsg = secQuestReqMsg;
	}
		
	public boolean isSecEmailRecoveryInd() {
		return secEmailRecoveryInd;
	}

	public void setSecEmailRecoveryInd(boolean secEmailRecoveryInd) {
		this.secEmailRecoveryInd = secEmailRecoveryInd;
	}

	public boolean isMobileRecoveryInd() {
		return mobileRecoveryInd;
	}

	public void setMobileRecoveryInd(boolean mobileRecoveryInd) {
		this.mobileRecoveryInd = mobileRecoveryInd;
	}

	public static String getEncryptedToken() throws NoSuchAlgorithmException{
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG");	// Initialize a MessageDigest
		MessageDigest sha = MessageDigest.getInstance("SHA-1");
		// create a MessageDigest of the random number
		byte[] randomDigest = sha.digest(new Integer(random.nextInt()).toString().getBytes());
		return hexEncode(randomDigest); // encode the byte[] into some textual representation
	}
	
	static private String hexEncode( byte[] aInput){
		StringBuilder result = new StringBuilder();
		char[] digits = {'0', '1', '2', '3', '4','5','6','7','8','9','a','b','c','d','e','f'};
		for ( int idx = 0; idx < aInput.length; ++idx) {
			byte b = aInput[idx];
			result.append( digits[ (b&0xf0) >> 4 ] );
			result.append( digits[ b&0x0f] );
		}
		return result.toString();
	}

	List<UserChallengeQuestionVO> securityQuesList = null;
	
	public void preRenderView() {
        // stop execution for Ajax calls
        try {
            if (FacesContext.getCurrentInstance().isPostback()) {
                return;
            }
        }
        catch (Exception e) {
            // ignore
        }
        // makes sure init is called before any rendering
        init();
	}
	
	//@PostConstruct
	public void init() {
		
		if (!initOpenIdConnectForEntry(updateUserSecQuestionPageUrl)) {
            return;
        }
		
		addRelyingPartyRequestParam(TrustBrokerWebAppConstants.TARGET, TrustBrokerWebAppConstants.RELYING_APP_URL_PROF,
				getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
		
		addRelyingPartyRequestParam(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, TrustBrokerWebAppConstants.RELYING_APP_ID,
				getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
		addRelyingPartyAlias(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null ? 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString():null);
		addSessionAttribute(TrustBrokerWebAppConstants.ACTION, TrustBrokerWebAppConstants.CHANGE_SEC_QUES);
		addOpenIdConnectDataToSession();
		setSessionUserDetails();
		
		try {
			clearMessages();
			ChallengeQuestionServiceResponse challengeQuestionServiceResponse = getContainer().getConfigService().getSecurityQuestions();
			if(!TrustbrokerWebAppUtil.checkResponseStatus(challengeQuestionServiceResponse) && 
					StringUtils.isNotEmpty(challengeQuestionServiceResponse.getReasonMessage())) {
				setErrorMsg(challengeQuestionServiceResponse.getReasonMessage());
				return;
			}
			
			if(isSessionAttributeExists(TrustBrokerWebAppConstants.RELYING_APP_ALIAS)) getRPProfileConfig();
			
			setSecEmailHelpMessage(tbResources.getString("secEmailVerifyMsg"));
			setMobilePhoneHelpMessage(tbResources.getString("mobilePhoneVerifyMsg"));
			
			tbSecurityQuestionsBean.setQuestions(challengeQuestionServiceResponse.getUserChallengeQuestions());
			userRetrievalServiceResponse = container.getUserService().fetchUserProfile(getCurrentUserVO().getUuId(),true, true);
			updateUserVO = userRetrievalServiceResponse.getUser();
			updateUserVO.setIsemailVerified(userRetrievalServiceResponse.getUser().isIsemailVerified());
			updateUserVO.setConfirmEmailAddress(userRetrievalServiceResponse.getUser().getConfirmEmailAddress());
			updateUserVO.setSecEmailVerified(userRetrievalServiceResponse.getUser().isSecEmailVerified());
			updateUserVO.setConfirmSecEmailAddress(userRetrievalServiceResponse.getUser().getConfirmSecEmailAddress());
			updateUserVO.setPhoneNumber(userRetrievalServiceResponse.getUser().getPhoneNumber());
			updateUserVO.setIsPhoneVerified(userRetrievalServiceResponse.getUser().getIsPhoneVerified());
			if(!userRetrievalServiceResponse.getUser().isSecEmailVerified()) {
				updateUserVO.setSecEmailUnique(true);
			}
			
			setTempSecEmail(userRetrievalServiceResponse.getUser().getSecEmailAddress());
			
			securityQuesList = userRetrievalServiceResponse.getUser().getUserChallengeQuestions();
			
			if(null != securityQuesList && securityQuesList.size() > 0) {
				tbSecurityQuestionsBean.setSecurityQuestionOne(securityQuesList.get(0).getQuestionId()+
						"_"+securityQuesList.get(0).getQuestion());
				tbSecurityQuestionsBean.setSecurityQuestionTwo(securityQuesList.get(1).getQuestionId()+
						"_"+securityQuesList.get(1).getQuestion());
				tbSecurityQuestionsBean.setSecurityQuestionThree(securityQuesList.get(2).getQuestionId()+
						"_"+securityQuesList.get(2).getQuestion());
				
				tbSecurityQuestionsBean.setSecurityAnswerOne(securityQuesList.get(0).getAnswer());
				tbSecurityQuestionsBean.setSecurityAnswerTwo(securityQuesList.get(1).getAnswer());
				tbSecurityQuestionsBean.setSecurityAnswerThree(securityQuesList.get(2).getAnswer());
			}
						
			String generatedToken=getEncryptedToken();
			setGeneratedToken(generatedToken);
			tbSecurityQuestionsBean.setToken(generatedToken);
			initialzeSecurityQuestionAnswers(tbSecurityQuestionsBean);
			
			String upf=getFacesContext().getExternalContext().getRequestParameterMap().get("upf");
			
			if(upf!=null)
			{
				setSuccessMsg(upf.equals("s")?"User  Security Information is updated successfully. ":"User  Security Information is updated successfully.");
			}
			
			String UsrAccrRecInd = (String) getSessionAttribute(NavBean.USERACCTRECOVERYIND);
			if("false".equals(UsrAccrRecInd)) {
				setErrorMsg(tbResources.getString("returnRPRecryErrMsg"));
				removeSessionAttribute(NavBean.USERACCTRECOVERYIND);
			}
		}
		catch (OperationFailedException ex) {
			logger.error("Error while retrieving user profile details for user: {}", new String[]{getCurrentUserVO().getUserName(),
					TrustbrokerWebAppUtil.getUidFromError(ex)},ex);
			setErrorMsg(ex.getErrorMessage() != null ? ex.getErrorMessage().getEndUserMessage(
					container.getErrorMessageSource(), getSupportContactInfo()) : ex.getMessage());
		}
		catch (Exception ex) {
			logger.error("exception", ex);
			setErrorMsg(ex.getMessage());
		}

		//Get relying party registration profile info to display mandatory fields
		getRPRegProfileAATypeinfo();
	}

	private void initialzeSecurityQuestionAnswers(SecurityQuestionsBean tbSecurityQuestionsBean) {
		if (null != tbSecurityQuestionsBean) {
			setSecurityQuestionOne(tbSecurityQuestionsBean.getSecurityQuestionOne());
			setSecurityQuestionTwo(tbSecurityQuestionsBean.getSecurityQuestionTwo());
			setSecurityQuestionThree(tbSecurityQuestionsBean.getSecurityQuestionThree());
			setSecurityAnswerOne(tbSecurityQuestionsBean.getSecurityAnswerOne());
			setSecurityAnswerTwo(tbSecurityQuestionsBean.getSecurityAnswerTwo());
			setSecurityAnswerThree(tbSecurityQuestionsBean.getSecurityAnswerThree());
		}
	}

	public void revertChanges() {
		clearMessages();
		tbSecurityQuestionsBean.setSecurityQuestionOne(getSecurityQuestionOne());
		tbSecurityQuestionsBean.setSecurityQuestionTwo(getSecurityQuestionTwo());
		tbSecurityQuestionsBean.setSecurityQuestionThree(getSecurityQuestionThree());
		tbSecurityQuestionsBean.setSecurityAnswerOne(getSecurityAnswerOne());
		tbSecurityQuestionsBean.setSecurityAnswerTwo(getSecurityAnswerTwo());
		tbSecurityQuestionsBean.setSecurityAnswerThree(getSecurityAnswerThree());
	}
	
	private boolean validateSecurityAnswers() {
		String sameAnswer = "";
		boolean retVal = true;
		String answerOne = tbSecurityQuestionsBean.getSecurityAnswerOne();
		String answerTwo = tbSecurityQuestionsBean.getSecurityAnswerTwo();
		String answerThree = tbSecurityQuestionsBean.getSecurityAnswerThree();
		String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
		String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
		String secQuestion3 = tbSecurityQuestionsBean.getSecurityQuestionThree();

		if(isQuestionsRequired()) {
			if (StringUtils.isBlank(secQuestion1)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
				retVal = false;
			}

			if (StringUtils.isBlank(secQuestion2)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
				retVal = false;
			}

			if (StringUtils.isBlank(secQuestion3)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
			if (StringUtils.isBlank(answerOne)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
				retVal = false;
			}

			if (StringUtils.isBlank(answerTwo)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
				retVal = false;
			}

			if (StringUtils.isBlank(answerThree)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
				retVal = false;
			}
		}
		else
		{
			if(null != securityQuesList && securityQuesList.size() > 0) {
				if(StringUtils.isNotBlank(securityQuesList.get(0).getQuestionId()+
						"_"+securityQuesList.get(0).getQuestion()) && (StringUtils.isBlank(secQuestion1))){
					addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
					seqQnsBlankPass = false;
				}
				if(StringUtils.isNotBlank(securityQuesList.get(1).getQuestionId()+
						"_"+securityQuesList.get(1).getQuestion()) && (StringUtils.isBlank(secQuestion2))){
					addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
					seqQnsBlankPass = false;
				}
				if(StringUtils.isNotBlank(securityQuesList.get(2).getQuestionId()+
						"_"+securityQuesList.get(2).getQuestion()) && (StringUtils.isBlank(secQuestion3))){
					addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
					seqQnsBlankPass = false;
				}
				
				if(StringUtils.isNotBlank(securityQuesList.get(0).getAnswer()) && (StringUtils.isBlank(answerOne))) {
					addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
					seqQnsBlankPass = false;
				}
				if(StringUtils.isNotBlank(securityQuesList.get(1).getAnswer()) && (StringUtils.isBlank(answerTwo))) {
					addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
					seqQnsBlankPass = false;
				}
				if(StringUtils.isNotBlank(securityQuesList.get(2).getAnswer()) && (StringUtils.isBlank(answerThree))) {
					addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
					seqQnsBlankPass = false;
				}
			} 
			
			
			String quesAnsArray[] = {secQuestion1, secQuestion2, secQuestion3, answerOne, answerTwo, answerThree};
			String quesAnsVal = StringUtils.join(quesAnsArray);
			if(!seqQnsBlankPass)
				{
					setSecQuestReqMsg(tbResources.getString("secQnAnsBlankMsg"));
					retVal = false;
				}
				else if(!(StringUtils.isBlank(quesAnsVal) || (StringUtils.isNotBlank(secQuestion1) && StringUtils.isNotBlank(secQuestion2) && StringUtils.isNotBlank(secQuestion3) 
						&& StringUtils.isNotBlank(answerOne) && StringUtils.isNotBlank(answerTwo) && StringUtils.isNotBlank(answerThree))) ) {
					setSecQuestReqMsg(tbResources.getString("secAnsSelMsg"));
					retVal = false;
				}	
				
			if(null != securityQuesList && securityQuesList.size() == 0) {
				if( (StringUtils.isBlank(secQuestion1))&&
						 (StringUtils.isBlank(secQuestion2))&&
						(StringUtils.isBlank(secQuestion3))&&
						 (StringUtils.isBlank(answerOne))&&
						(StringUtils.isBlank(answerTwo))&&
						 (StringUtils.isBlank(answerThree)))
				{
					byPassSQUpdate = true;
				}
				else
				{
					if ((StringUtils.isNotBlank(secQuestion1)&&StringUtils.isBlank(answerOne))||
							(StringUtils.isBlank(secQuestion1)&&StringUtils.isNotBlank(answerOne))) {
						addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
						retVal = false;
					}else if(StringUtils.isBlank(secQuestion1)){
						addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
						retVal = false;
					}

					if ((StringUtils.isNotBlank(secQuestion2)&&StringUtils.isBlank(answerTwo))||
							(StringUtils.isBlank(secQuestion2)&&StringUtils.isNotBlank(answerTwo))) {
						addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
						retVal = false;
					}else if(StringUtils.isBlank(secQuestion2)){
						addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
						retVal = false;
					}

					if ((StringUtils.isNotBlank(secQuestion3)&&StringUtils.isBlank(answerThree))||
							(StringUtils.isBlank(secQuestion3)&&StringUtils.isNotBlank(answerThree))) {
						addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
						retVal = false;
					}else if(StringUtils.isBlank(secQuestion3)){
						addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
						retVal = false;
					}
					
					if(StringUtils.isNotBlank(secQuestion1)&&StringUtils.isNotBlank(answerOne))
					{
						if(StringUtils.isBlank(secQuestion2)&&StringUtils.isBlank(answerTwo))
						{
							addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
							retVal = false;
						}
						if(StringUtils.isBlank(secQuestion3)&&StringUtils.isBlank(answerThree))
						{
							addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
							retVal = false;
						}
						
					}
					if(StringUtils.isNotBlank(secQuestion2)&&StringUtils.isNotBlank(answerTwo))
					{
						if(StringUtils.isBlank(secQuestion1)&&StringUtils.isBlank(answerOne))
						{
							addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
							retVal = false;
						}
						if(StringUtils.isBlank(secQuestion3)&&StringUtils.isBlank(answerThree))
						{
							addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
							retVal = false;
						}
						
					}
					if(StringUtils.isNotBlank(secQuestion3)&&StringUtils.isNotBlank(answerThree))
					{
						if(StringUtils.isBlank(secQuestion2)&&StringUtils.isBlank(answerTwo))
						{
							addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
							retVal = false;
						}
						if(StringUtils.isBlank(secQuestion1)&&StringUtils.isBlank(answerOne))
						{
							addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
							retVal = false;
						}
					}
				}
				
				if((StringUtils.isNotBlank(secQuestion1)&&StringUtils.isNotBlank(answerOne))
						&&(StringUtils.isNotBlank(secQuestion2)&&StringUtils.isNotBlank(answerTwo))
						&&(StringUtils.isNotBlank(secQuestion3)&&StringUtils.isNotBlank(answerThree)))
				{
					setMessageCount(1);
				}
					
			}
			
			
		}
		

		if (answerOne.equalsIgnoreCase(answerTwo) && answerOne.equalsIgnoreCase(answerThree))
			sameAnswer = answerOne;
		//if (answerTwo.equalsIgnoreCase(answerThree))
		//	sameAnswer = answerTwo;

		if (!"".equals(sameAnswer)) {
			if (secQuestion1.toUpperCase().contains(answerOne.toUpperCase()) && sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion2.toUpperCase().contains(answerTwo.toUpperCase()) && sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (secQuestion3.toUpperCase().contains(answerThree.toUpperCase())
					&& sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("secAnswerRules"));
				retVal = false;
			}

			if (StringUtils.isNotBlank(answerOne) && secQuestion1.toUpperCase().contains(answerOne.toUpperCase())) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.isNotBlank(answerTwo) && secQuestion2.toUpperCase().contains(answerTwo.toUpperCase())) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.isNotBlank(answerThree) && secQuestion3.toUpperCase().contains(answerThree.toUpperCase())) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerOne)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerTwo)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

			if (sameAnswer.equalsIgnoreCase(answerThree)) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("uniqueSecAnsMsg"));
				retVal = false;
			}

		} else {
			if (StringUtils.isNotBlank(answerOne) && secQuestion1.toUpperCase().contains(answerOne.toUpperCase())) {
				retVal = false;
				addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("secAnswermustnotContainsText"));
			}

			if (StringUtils.isNotBlank(answerTwo) && secQuestion2.toUpperCase().contains(answerTwo.toUpperCase())) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}

			if (StringUtils.isNotBlank(answerThree) && secQuestion3.toUpperCase().contains(answerThree.toUpperCase())) {
				addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("secAnswermustnotContainsText"));
				retVal = false;
			}
		}
		
		if(!TBUtil.validateSecurityAnswer(answerOne)){
			addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("obsceneTextInAnswer"));
			retVal = false;
		}
		
		if(!TBUtil.validateSecurityAnswer(answerTwo)){
			addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("obsceneTextInAnswer"));
			retVal = false;
		}
		
		if(!TBUtil.validateSecurityAnswer(answerThree)){
			addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("obsceneTextInAnswer"));
			retVal = false;
		}
		
		
				
		return retVal;
	}
	
	public void securityQuestionOneChanged(ValueChangeEvent e) {
		if(isQuestionsRequired() && StringUtils.isBlank((String)e.getNewValue())){
			addFacesMessage("updateSecurityQuestionsId:securityAnswerOne", tbResources.getString("securityQuestion123"));
		} else {				
			tbSecurityQuestionsBean.securityQuestionOneChanged(e);
		}
	}

	public void securityQuestionTwoChanged(ValueChangeEvent e) {
		if(isQuestionsRequired() && StringUtils.isBlank((String)e.getNewValue())) {
			addFacesMessage("updateSecurityQuestionsId:securityAnswerTwo", tbResources.getString("securityQuestion123"));
		} else {	
			tbSecurityQuestionsBean.securityQuestionTwoChanged(e);
		}
	}

	public void securityQuestionThreeChanged(ValueChangeEvent e) {
		if(isQuestionsRequired() && StringUtils.isBlank((String)e.getNewValue())) {	
			addFacesMessage("updateSecurityQuestionsId:securityAnswerThree", tbResources.getString("securityQuestion123"));
		} else {
			tbSecurityQuestionsBean.securityQuestionThreeChanged(e);
		}
	}
	
	
	private void clearMessages() {
		setSuccessMsg("");
		setSuccessSecMsg("");
		setErrorMsg("");
		setMessageCount(0);
		setSecQuestReqMsg("");
		//setSuccessSecMsg("");
	}

	
	public UserVO updateUserSecurityQuestions() {
		
		clearMessages();// Clear all error messages if any
		setSessionUserDetails();
		clearValidateMessages();
		
		setSuccessSecMsg("");
		setWarningMsg("");
		seqQnsBlankPass = true;
		byPassSQUpdate = false;
	

		if (! (validateEmailFields() && validatePhone(updateUserVO.getPhoneNumber()) && validateSecurityAnswers())) {			
			return null;
		}
		
		UserVO trustBrokerUserVO = null;
		UserVO userVO = null;
		
		if(StringUtils.isEmpty(tbSecurityQuestionsBean.getToken())  || !getGeneratedToken().equals(tbSecurityQuestionsBean.getToken()))
			return null;
				
		try {
			userVO = new UserVO();
			populateSecurityQuestions(userVO);
			
			if( !isPrimaryEmailUnique() 
					&& isSecEmailVerificationReqd()
					&& (userVO.getUserChallengeQuestions() == null || userVO.getUserChallengeQuestions().isEmpty()) 
					&& (!isMobileRecoveryInd() && !updateUserVO.getIsPhoneVerified()) ) {
				setErrorMsg(tbResources.getString("updProfRecryErrMsg"));
				return null;
			}
			trustBrokerUserVO = container.getUserService().fetchUserByUUID(getCurrentUserVO().getUuId()).getUser();

			UserProfileServiceRequest userRegistrationServiceRequest1 = new UserProfileServiceRequest();
			UserVO essoUserVO = getSessionUserVO(); //geteSSOUser(trustBrokerUserVO.getUuId());
			// Set Role to the upateUserVO from session
			updUserRepoObj(trustBrokerUserVO, updateUserVO);
			updateUserVO.setUserName(getCurrentUserVO().getUserName());
			updateUserVO.setEssoPrimaryEmail(essoUserVO.getEmailAddress());
			updateUserVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
			updateUserVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));			
			userRegistrationServiceRequest1.setUser(updateUserVO);
			
			UserProfileServiceResponse emailResponse = null;
			boolean userSecValChanged = isUserSecInfoChanged(updateUserVO, essoUserVO);
			boolean userSecQuestionsChanged = areUserSecQuestionsChanged();
			
			logger.debug("SecEmailRecoveryInd:" +isSecEmailRecoveryInd()+", mobileind:"+isMobileRecoveryInd());
			
			if(!userSecValChanged && !userSecQuestionsChanged && !isSecEmailRecoveryInd() && !isMobileRecoveryInd()) {
				setWarningMsg(tbResources.getString("updUsrSecInfoErrMsg"));
				return null;
			}
			
			if(userSecValChanged) {
				userRegistrationServiceRequest1.setOldUser(essoUserVO);
				emailResponse = container.getUserService().modifyUser(userRegistrationServiceRequest1, true);
				if(TrustbrokerWebAppUtil.checkResponseStatus(emailResponse)){
					setSuccessSecMsg(tbResources.getString("updUsrSecInfoSuccMsg"));
					addFacesMessage("updateSecurityQuestionsId:email", ""); 
					addFacesMessage("updateSecurityQuestionsId:secEmail", ""); 	
					setConfEmailWarnMsgInd(false);					
				} else {
					errorMsg = emailResponse.getReasonMessage();
					return userVO;
				}
			}
		 
			SecurityLoggingUtil.info("User Account Modifications",SecurityEventType.E3_MODIFY,getServletRequest(),updateUserVO.getUserName(),
					"Security Audit Event|ModifyUserProfile:SUCCESS | User Profile Modified, UpdateUserProfileBean:updateProfile()",
					SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_MODIFY_PROFILE);

			//****************
			String generatedToken=getEncryptedToken();
			setGeneratedToken(generatedToken);
			tbSecurityQuestionsBean.setToken(generatedToken);
			
			UserProfileServiceRequest userRegistrationServiceRequest = new UserProfileServiceRequest();
			UserVO currentUserVO = getCurrentUserVO();
			userVO.setUuId(currentUserVO.getUuId());
			userVO.setUserName(currentUserVO.getUserName());
			userVO.setIsTncAccepted(currentUserVO.getIsTncAccepted());
			userVO.setTncAgreementVersion(currentUserVO.getTncAgreementVersion());
			userVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
			userVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));
			userVO.setIsCoppaAccepted(currentUserVO.getIsCoppaAccepted());
						
			userRegistrationServiceRequest.setUser(userVO);
			
			if(userSecQuestionsChanged)
			{
				UserProfileServiceResponse response = container.getUserService().modifyUserSecurityQuestions(userRegistrationServiceRequest);				
				if(!TrustbrokerWebAppUtil.checkResponseStatus(response)){
					errorMsg = response.getReasonMessage();
					setSuccessSecMsg("");
					return userVO;
				} else {
					setSuccessSecMsg(tbResources.getString("updUsrSecInfoSuccMsg"));
					//Set question list after update
					securityQuesList = userVO.getUserChallengeQuestions();
				}
				initialzeSecurityQuestionAnswers(tbSecurityQuestionsBean);
			}
									
			logger.info("Security Questions & Answers are updated successfully for user {}", new String[]{getCurrentUserVO().getUserName()});
					 		    
   		    //Send email/mobile confirmation codes
			sendConfirmationCodes();	
			setSessionUserDetails();
			logger.info("User Profile is updated successfully for the user {}", new String[]{trustBrokerUserVO.getUserName()});
			
			if (null != getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG)) {
				ExternalContext ec = getFacesContext().getExternalContext();
				ec.getFlash().put("updateProfileSuccess", tbResources.getString("idProofUpdateProfileSuccess"));
				ec.redirect(ec.getRequestContextPath() + "/secure/idverification.jsf");
				return null;
			}
			return getCurrentUserVO();

		}
		catch (OperationFailedException ofe) {
			logger.error(" An error occureed while updating user profile and security questions & answers for user : {}",
					new String[] { getCurrentUserVO().getUserName(), TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
			setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(
					container.getErrorMessageSource(), getSupportContactInfo()) : ofe.getMessage());
		}
		catch (Exception e) {
			logger.error(" An error occureed while updating user profile for user : {}", new String[]{getCurrentUserVO().getUserName()}, e);
			setErrorMsg("User Profile update is unsuccessful");
		}
		
		return updateUserVO;
	}
	
	/**
	 * This method is used to builds verification code channels and redirects to verification code bean to send/verify confirmation codes
	 * 
	 */
	private void sendConfirmationCodes() {
		
		VerifyCodesContext ctx = new VerifyCodesContext();
		//Build verify code channels based on the profile info
  		 if (!StringUtils.isEmpty(updateUserVO.getEmailAddress()) && !areValuesSame(updateUserVO.getEmailAddress(), getCurrentUserVO().getEmailAddress())) {
  			ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
  			ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
  		 } 
  		 
  		if(!StringUtils.isEmpty(updateUserVO.getPhoneNumber()) && mobileRecoveryInd) {
  			ctx.getViewChannels().add(CommunicationChannel.PHONE);
			ctx.getSendChannels().add(CommunicationChannel.PHONE);
  		 } 
  		
  		if ( !StringUtils.isEmpty(updateUserVO.getSecEmailAddress()) && secEmailRecoveryInd ) {
  			ctx.getViewChannels().add(CommunicationChannel.SECONDARY_EMAIL);
			ctx.getSendChannels().add(CommunicationChannel.SECONDARY_EMAIL);
  		 }
	   	
		   setCurrentUserVO(container.getUserService().fetchUserDetailsForSession(getCurrentUserVO().getUserName()).getUser());
		   //redirects to verify code page which sends confirmation code and displays verification screen
  		 if(!ctx.getSendChannels().isEmpty()) {
  		    if (TBUtil.isProdEnv() || isEmailConfirmationRequired()) {	
  		    	ctx.setHideUpdateButtons(true);
  		    	ctx.setShowDeviceRegistration(false);
				ctx.setNextView("/secure/updatesecurityquestions.jsf");
				ctx.setUserVO(getCurrentUserVO());
				getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);
				redirectToView(updateEmailConfirmationPage);
			}
  		 }
		
	}
	
	
	/**
	 * This method is used to populate user security questions from this bean
	 * 
	 * @param userVO UserVO
	 */
	private void populateSecurityQuestions(UserVO userVO) {
		List<UserChallengeQuestionVO> securityQuestions = new ArrayList<UserChallengeQuestionVO>();
				
		if(StringUtils.isNotBlank(tbSecurityQuestionsBean.getSecurityQuestionOne())) {
			UserChallengeQuestionVO question1 = new UserChallengeQuestionVO();
			String secQuestion1 = tbSecurityQuestionsBean.getSecurityQuestionOne();
			String secQuestion1Array[] = secQuestion1.split("_");
			question1.setQuestionId(secQuestion1Array[0]);
			question1.setQuestion(secQuestion1Array[1]);
			question1.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerOne());
			securityQuestions.add(question1);
		}

		if(StringUtils.isNotBlank(tbSecurityQuestionsBean.getSecurityQuestionTwo())) {
			UserChallengeQuestionVO question2 = new UserChallengeQuestionVO();
			String secQuestion2 = tbSecurityQuestionsBean.getSecurityQuestionTwo();
			String secQuestion2Array[] = secQuestion2.split("_");
			question2.setQuestionId(secQuestion2Array[0]);
			question2.setQuestion(secQuestion2Array[1]);
			question2.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerTwo());
			securityQuestions.add(question2);
		}

		if(StringUtils.isNotBlank(tbSecurityQuestionsBean.getSecurityQuestionThree())) {
			UserChallengeQuestionVO question3 = new UserChallengeQuestionVO();
			String secQuestion3 = tbSecurityQuestionsBean
					.getSecurityQuestionThree();
			String secQuestion3Array[] = secQuestion3.split("_");
			question3.setQuestionId(secQuestion3Array[0]);
			question3.setQuestion(secQuestion3Array[1]);
			question3.setAnswer(tbSecurityQuestionsBean.getSecurityAnswerThree());
			securityQuestions.add(question3);
		}		
		userVO.setUserChallengeQuestions(securityQuestions);
	}

	private void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		}
		return super.getFacesContext();
	}


	public String cancel()
	{
		// take to SQ page update security questions
		//return "/secure/home?faces-redirect=true";
		return "/secure/updatesecurityquestions?faces-redirect=true";
	
	}
	
	/**
	 * This method is used to validate user primary and secondary emails.
	 * 
	 * @return boolean
	 */
	private boolean validateEmailFields() {
		setEmailExistsMsg("");
		setEmailExistsMsgSec("");
		setEmailErrorMsg("");
		boolean result = true;
		boolean secMail = false;
		setConfEmailWarnMsgInd(false);
		int emailErrorCount=0;
		result = validateEmailAddress(updateUserVO.getEmailAddress(), "updateSecurityQuestionsId:email");		
		if(!result) {
			return result;
		}
			
		if(!StringUtils.isEmpty(updateUserVO.getEmailAddress()) && !updateUserVO.getEmailAddress().equalsIgnoreCase(getSessionUserVO().getEmailAddress())) {
			if(StringUtils.isEmpty(updateUserVO.getConfirmEmailAddress())) {
				addFacesMessage("updateSecurityQuestionsId:confirmEmail", "Confirm Email is required");  
				return false;
			} else if(!(updateUserVO.getEmailAddress().equalsIgnoreCase(updateUserVO.getConfirmEmailAddress()))){
				emailErrorCount++;
				addFacesMessage("updateSecurityQuestionsId:confirmEmail", "Email and Confirm Email Addresses do not match");
				return false;
			}			
		}
						
		int secEmailErrorCount=0;
		if(!StringUtils.isEmpty(updateUserVO.getSecEmailAddress())) {
				if(StringUtils.isEmpty(updateUserVO.getEmailAddress())) {
					addFacesMessage("updateSecurityQuestionsId:secEmail", tbResources.getString("secEmailOnlyErrMsg"));
					return false;
				}
				if (updateUserVO.getSecEmailAddress().equalsIgnoreCase(updateUserVO.getEmailAddress())) {					
					addFacesMessage("updateSecurityQuestionsId:secEmail", "Secondary Email and Email Addresses cannot be same");
					return false;
	
				}
			    secMail =TBUtil.validateEmailId(updateUserVO.getSecEmailAddress());
			    result = validateSecEmail(updateUserVO.getSecEmailAddress());
			    if(!result) {
					return result;
				}
							    
				if(!(updateUserVO.getSecEmailAddress().equalsIgnoreCase(getSessionUserVO().getSecEmailAddress()))){
					if(!(updateUserVO.getSecEmailAddress().equalsIgnoreCase(updateUserVO.getConfirmSecEmailAddress()))){
						secEmailErrorCount++;
						if( updateUserVO.getSecEmailAddress().length()!=0){
							addFacesMessage("updateSecurityQuestionsId:confirmSecEmail", "Secondary Email and Confirm Secondary Email Addresses do not match");
							return false;
						}
					}
				}
		}
		boolean email = TBUtil.validateEmailId(updateUserVO.getEmailAddress());
		if(emailErrorCount==1 && secEmailErrorCount==0 && email) {
			setEmailErrorMsg("1");
		}else if(emailErrorCount==0 && secEmailErrorCount==1 && secMail) {
			setEmailErrorMsg("2");
		}else if(emailErrorCount==1 && secEmailErrorCount==1 && email && secMail) {
			setEmailErrorMsg("3");
		}
		return result;
	}
	
	private void clearValidateMessages() {
		setEmailExistsMsg("");
		setEmailExistsMsgSec("");
	}
	
	public boolean checkEmailAddressExist() {
		boolean status= isUserEmailShared(updateUserVO.getEmailAddress().toLowerCase());
		if (status) {
			setEmailExistsMsg(tbResources.getString("emailAlreadyExists"));
		}
		return status;
	}
	
	public UserVO geteSSOUser(String uuid) {
		UserVO essoUserVO = null;
		try {
			UserRetrievalServiceResponse userRetrievalServiceResponse = container.getUserService().fetchUserProfile(uuid,true, true);
			essoUserVO = userRetrievalServiceResponse.getUser();
		} catch (OperationFailedException e) {
			logger.info(" Failed to get the User details from eSSO for UUID "+ uuid);
			throw new OperationFailedException("Failed to get the User details from eSSO");
		}
		return essoUserVO;
	}
	
	private void setSessionUserDetails() {

		if(getCurrentUserVO() != null) {
			UserVO essoUserVO = geteSSOUser(getCurrentUserVO().getUuId());
			setSessionUserVO(essoUserVO);
			if(null == sessionUserVO.getSecEmailAddress())
				sessionUserVO.setSecEmailAddress("");
		}

	}
	/**
	 * This method is used to log audit event when an user email id is changed.
	 * 
	 * @param msg event message. 
	 * @param userVO UserVO containing user info
	 */	
	private void logUserEmailUpdate(String msg, UserVO userVO ){
				
		msg = "Security Audit Event|"+msg+ "## uuid: ^^"+userVO.getUuId()+"!!";
		IrmLoggingUtil.info(TrustBrokerConstants.EMAIL_UPD_ACTIVITY, SecurityEventType.E3_MODIFY, getServletRequest().getRemoteAddr(),
				getServletRequest().getLocalAddr(), getServletRequest().getSession().getId(), 
				 userVO.getUserName(), msg, SecurityEventResult.SUCCESS, getRelyingPartyAppId(), userVO.getEmailAddress(), "", SecuritySubEventType.E3_MODIFY_EMAIL);
	}

	private void getRPProfileConfig()
	{
		QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
		queryRelyingPartyResponse = container.getConfigService().queryRelyingParty(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS).toString());
		QueryTierResponse queryTierResponse = new QueryTierResponse();
			if(queryRelyingPartyResponse!=null &&  queryRelyingPartyResponse.getRelyingParty()!=null) {
			RelyingParty rp = queryRelyingPartyResponse.getRelyingParty();
				if(rp.getTiers() != null && rp.getTiers().size() > 0) {
					TierConfig tierConfig = rp.getTiers().get(0);
					//userVO.setTierId(tierConfig.getTierId());
					queryTierResponse = container.getConfigService().queryTier(tierConfig.getTierId());
					if(queryTierResponse!=null && queryTierResponse.getTierDefinition()!=null)
					{
						List<TierAttribute> tierAttributes= queryTierResponse.getTierDefinition().getTierAttributes();
						for (Iterator<TierAttribute> iterator = tierAttributes.iterator(); iterator.hasNext();) {
							TierAttribute tierAttribute = iterator.next();
							if (tierAttribute.getName().equalsIgnoreCase(TrustBrokerConstants.EMAIL_ADDRESS)) {
								if (!tierAttribute.isMandatory()) {
									emailMandatory = false;
								}
								if (tierAttribute.isUnique()) {
									emailShared = false;
								}
							}
						}
					}										
				}
		}
	}
	
	private boolean showEmail;
	
	public boolean isShowEmail() {
		return showEmail;
	}

	public void setShowEmail(boolean showEmail) {
		this.showEmail = showEmail;
	}

	/**
	 * This method is used to validate user primary address field value
	 * 
	 * @param event ValueChangeEvent
	 */
	public void checkEmailAddress(ValueChangeEvent event) {
		
		emailExistsMsg = "";
		showEmail = false;
		PhaseId phaseId = event.getPhaseId();		
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			validateEmailAddress(event.getNewValue().toString(), "updateSecurityQuestionsId:email");
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES) && !event.getNewValue().toString().isEmpty()) {
			validateEmailAddress(event.getNewValue().toString(), "updateSecurityQuestionsId:email");
		}
	}
	/**
	 * This method is used to validate the secondary email field value
	 * 
	 * @param event ValueChangeEvent
	 */
	public void validateSecEmailFormat(ValueChangeEvent event) {
		emailExistsMsgSec = "";
		showEmail = false;		
		//setSecEmailRecoveryInd(false);
		String value = event.getNewValue().toString();
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			validateSecEmail(value);
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			validateSecEmail(value);
		}
	}
	/**
	 * This method is used to validate the mobile phone number field value
	 * 
	 * @param event ValueChangeEvent
	 */
	public void validateMobilePhone(ValueChangeEvent event) {
		emailExistsMsgSec = "";
		showEmail = false;		
		//setMobileRecoveryInd(false);
		String value = event.getNewValue().toString();
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			validatePhone(value);
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			validatePhone(value);
		}
	}
	
	/**
	 * This method is used to update the mobile phone number check box field value
	 * 
	 * @param event ValueChangeEvent
	 */
	public void updMobilePhoneChkbox(ValueChangeEvent event) {
		String value = event.getNewValue().toString();
		PhaseId phaseId = event.getPhaseId();
		setMobilePhoneHelpMessage("");
		boolean mobilePhoneChkBoxValue = Boolean.parseBoolean(value);
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			setMobileRecoveryInd(mobilePhoneChkBoxValue);
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			setMobileRecoveryInd(mobilePhoneChkBoxValue);
			
		}
		if(mobilePhoneChkBoxValue) {
			setDisableEmailField(true);
			setDisableSecAcctRecovery(true);
			setMobilePhoneHelpMessage("");
			setSecEmailHelpMessage(tbResources.getString("altVerifyHelpMsg"));
		} else {
			setDisableEmailField(false);
			setDisableSecAcctRecovery(false);
			if(!isEmailMandatory() && StringUtils.isBlank(updateUserVO.getEmailAddress()))
				setDisableSecAcctRecovery(true);
			setMobilePhoneHelpMessage(tbResources.getString("mobilePhoneVerifyMsg"));
			setSecEmailHelpMessage(tbResources.getString("secEmailVerifyMsg"));
		}
	}
	
	/**
	 * This method is used to update the secondary email check box field value
	 * 
	 * @param event ValueChangeEvent
	 */
	public void updSecEmailChkbox(ValueChangeEvent event) {
		setDisableEmailField(false);
		setDisablePhoneAcctRecovery(false);
		setSecEmailHelpMessage("");
		String value = event.getNewValue().toString();
		PhaseId phaseId = event.getPhaseId();
		boolean secEmailChkBoxValue = Boolean.parseBoolean(value);
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			setSecEmailRecoveryInd(secEmailChkBoxValue);
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			setSecEmailRecoveryInd(secEmailChkBoxValue);
			
		}
		if(secEmailChkBoxValue) {
			setDisableEmailField(true);
			setDisablePhoneAcctRecovery(true);
			setSecEmailHelpMessage("");
			setMobilePhoneHelpMessage(tbResources.getString("altVerifyHelpMsg"));
		} else {
			setDisableEmailField(false);
			setDisablePhoneAcctRecovery(false);
			setSecEmailHelpMessage(tbResources.getString("secEmailVerifyMsg"));
			setMobilePhoneHelpMessage(tbResources.getString("mobilePhoneVerifyMsg"));
		}
	}
		
	
	/**
	 * This method is used to validate the given secondary email address
	 * 
	 * @param value String
	 * @return boolean
	 */
	private boolean validateSecEmail(String value) {
		boolean validSecEmail = true;
		clearMessages();
		setConfEmailWarnMsgInd(false);
		
		UserVO sessnUser = getSessionUserVO();
		boolean emailDiff = areValuesSame(value, sessnUser.getSecEmailAddress());
		if(emailDiff) {
			updateUserVO.setSecEmailVerified(sessnUser.isSecEmailVerified());
			if(!sessnUser.isSecEmailVerified()) {
				updateUserVO.setSecEmailUnique(true);
			} else {
				setSecEmailRecoveryInd(false);
			}
			return validSecEmail;
		}		
		updateUserVO.setSecEmailVerified(false);
		
		boolean result = TBUtil.validateEmailId(value);
		if(!value.isEmpty()) {
			if (!result) {
				addFacesMessage("updateSecurityQuestionsId:secEmail",tbResources.getString("invalidEmailAddress"));
				validSecEmail = false;
			} else {
				if(value.equalsIgnoreCase(updateUserVO.getEmailAddress())){
					addFacesMessage("updateSecurityQuestionsId:secEmail", "Secondary Email and Email Addresses cannot be same");
					return false;
				}
				boolean emailExists = isUserEmailShared(value);
				if(emailExists) {	
					updateUserVO.setSecEmailUnique(false);
					if(isEmailShared()) {
						addFacesMessage("updateSecurityQuestionsId:secEmail",
								tbResources.getString("duplicateEmailWarn"));
						setConfEmailWarnMsgInd(true);
					} else {
						addFacesMessage("updateSecurityQuestionsId:secEmail",
								tbResources.getString("rpDoNotDuplicateNonMandatoryEmail"));
						validSecEmail = false;
					}
				} else {
					updateUserVO.setSecEmailUnique(true);
				}
			}
		}
		return validSecEmail;
	}
	
	/**
	 * This method is used to validate the mobile phone number
	 * 
	 * @param value String
	 * @return boolean
	 */
	private boolean validatePhone(String value) {
		boolean validPhone = true;		
		UserVO sessnUser = getSessionUserVO();
		boolean emailDiff = areValuesSame(value, sessnUser.getPhoneNumber());
		if(emailDiff) {
			updateUserVO.setIsPhoneVerified(sessnUser.getIsPhoneVerified());
			if(updateUserVO.getIsPhoneVerified()) {
				setMobileRecoveryInd(false);
			}
			return validPhone;
		}		
		updateUserVO.setIsPhoneVerified(false);
		if(!StringUtils.isEmpty(value)) {
			if(value.length() < 13) {
				addFacesMessage("updateSecurityQuestionsId:mobilePhone",
						tbResources.getString("invalidMobileMsg"));
				return false;
			}
			String number = value.substring(1, 4) + value.substring(5, 8)
					+ value.substring(9, 13);
			if(StringUtils.isEmpty(number.replace("_", ""))) {
				updateUserVO.setPhoneNumber("");
				return true;
			}
			if(! StringUtils.isNumeric(number)) {
				addFacesMessage("updateSecurityQuestionsId:mobilePhone",
						tbResources.getString("invalidMobileMsg"));
				return false;
			}
		}
		return validPhone;
	}
	
	/**
	 * This method is used to validate the primary and secondary email fields
	 * 
	 * @param email String
	 * @param fieldId String
	 * @return boolean
	 */
	private boolean validateEmailAddress(String email, String fieldId) {
		boolean result = true;
		setEmailWarnMsgInd(false);
		UserVO sessnUser = getSessionUserVO();
		boolean emailDiff = areValuesSame(email, sessnUser.getEmailAddress());
		if(emailDiff) {
			updateUserVO.setIsemailVerified(sessnUser.isIsemailVerified());
			addFacesMessage("updateSecurityQuestionsId:confirmEmail", "");
			if(isDisablePhoneAcctRecovery())
				setDisableSecAcctRecovery(false);
			if(isDisableSecAcctRecovery())
				setDisablePhoneAcctRecovery(false);
			return result;
		} else {
			setDisableSecAcctRecovery(true);
			setDisablePhoneAcctRecovery(true);
			setSecEmailHelpMessage(tbResources.getString("altVerifyHelpMsg"));
			setMobilePhoneHelpMessage(tbResources.getString("altVerifyHelpMsg"));
		}
		updateUserVO.setIsemailVerified(false);
		if (isEmailMandatory()) {

			if (StringUtils.isEmpty(email)) {
				addFacesMessage(fieldId, tbResources.getString("rpDoNotSupportEmptyEmailNonRegister"));
				result = false;
			} else if (!TBUtil.validateEmailId(email)) {
				addFacesMessage(fieldId,
						tbResources.getString("invalidEmailAddress"));
				result = false;
			} else if (!isEmailShared()	&& !email.equalsIgnoreCase(getCurrentUserVO().getEmailAddress())
					&& isUserEmailShared(email)) {
				showEmail = true;
				addFacesMessage(fieldId,
						tbResources.getString("rpDoNotDuplicateEmail"));
				result = false;

			}
			else if(isEmailShared() && isUserEmailShared(email))
			{
				addFacesMessage(fieldId,
						tbResources.getString("duplicateEmailWarn"));
				setEmailWarnMsgInd(true);
			}
		} else {
			if(StringUtils.isBlank(email)) {
				setDisablePhoneAcctRecovery(false);
				setMobilePhoneHelpMessage(tbResources.getString("mobilePhoneVerifyMsg"));
			}
			if (!isEmailShared()) {
				if (!TBUtil.validateEmailId(email)) {
					addFacesMessage(fieldId,
							tbResources.getString("invalidEmailAddress"));
					result = false;
				} else if (!StringUtils.isEmpty(email)
						&& isUserEmailShared(email)) {
					showEmail = true;
					addFacesMessage(fieldId,
							tbResources.getString("rpDoNotDuplicateNonMandatoryEmail"));
					result = false;
				}
			}
			else if(email != null && email!= "" && isUserEmailShared(email))
			{
				addFacesMessage(fieldId,
						tbResources.getString("duplicateEmailWarn"));
				setEmailWarnMsgInd(true);
			}
		}
		showEmailSaveMsg = result;
		return result;

	}

	public boolean isEmailWarnMsgInd() {
		return emailWarnMsgInd;
	}

	public void setEmailWarnMsgInd(boolean emailWarnMsgInd) {
		this.emailWarnMsgInd = emailWarnMsgInd;
	}

	public boolean isConfEmailWarnMsgInd() {
		return confEmailWarnMsgInd;
	}

	public void setConfEmailWarnMsgInd(boolean confEmailWarnMsgInd) {
		this.confEmailWarnMsgInd = confEmailWarnMsgInd;
	}
	
	
	/**
	 * This method is used to check if the primary email is unique or not
	 * 
	 * @param email String
	 * @return boolean
	 */
	private boolean isPrimaryEmailUnique() {
		boolean uniqueEmail = false;
		UserVO sessnUser = getSessionUserVO();
		String email = updateUserVO.getEmailAddress();
		if(!StringUtils.isEmpty(email) && areValuesSame(email, sessnUser.getEmailAddress())) {
			uniqueEmail = sessnUser.isPrimaryEmailUnique();
		} else {
			uniqueEmail = isEmailUnique(email);
		}
		return uniqueEmail;
	}
	
	/**
	 * This method is used to check if the secondary email is unique or not
	 * 
	 * @return boolean
	 */
	private boolean isSecondaryEmailUnique() {
		boolean uniqueEmail = false;
		//UserVO sessnUser = getSessionUserVO();
		String email = updateUserVO.getSecEmailAddress();
		/*if(!StringUtils.isEmpty(email) && areValuesSame(email, sessnUser.getSecEmailAddress())) {
			uniqueEmail = sessnUser.isSecEmailUnique();
		} else {*/
			uniqueEmail = isEmailUnique(email);
		//}
		return uniqueEmail;
	}
	/**
	 * This method is used to check if the secondary email is selected as account recovery
	 * 
	 * @return boolean
	 */	
	private boolean isSecEmailVerificationReqd() {
		boolean verifReqd = false;
		if( !(isSecondaryEmailUnique()) 
				|| (!isSecEmailRecoveryInd() && !updateUserVO.isSecEmailVerified())) {
			verifReqd = true;
		}
		return verifReqd;		
	}
	/**
	 * This method is used to check if the given email is unique or not
	 * 
	 * @param email String
	 * @return boolean
	 */
	private boolean isEmailUnique(String email) {
		boolean uniqueEmail = true;
		if( StringUtils.isEmpty(email) || isEmailExistsWithOtherUser(email)) {
			uniqueEmail = false;
		}
		return uniqueEmail;
	}
	
	/**
	 * This method is used to check if user email or mobile info changed
	 * 
	 * @param updUser UserVO
	 * @param sessUser UserVO 
	 * @return boolean
	 */
	private boolean isUserSecInfoChanged(UserVO updUser, UserVO sessUser) {
		boolean sameValFlag = true;				
		if(areValuesSame(defaultStr(updUser.getEmailAddress()), defaultStr(sessUser.getEmailAddress())) && 
				areValuesSame(defaultStr(updUser.getSecEmailAddress()), defaultStr(sessUser.getSecEmailAddress())) && 
				areValuesSame(defaultStr(updUser.getPhoneNumber()), defaultStr(sessUser.getPhoneNumber())) ) {
			sameValFlag = false;
		}		
		logger.debug("USERUPDPROFISS", "Email usr:"+updUser.getEmailAddress()+", sess:"+sessUser.getEmailAddress());
		logger.debug("USERUPDPROFISS", "Sec Email usr:"+updUser.getSecEmailAddress()+", sess:"+sessUser.getSecEmailAddress());
		logger.debug("USERUPDPROFISS", "Mobile usr:"+updUser.getPhoneNumber()+", sess:"+sessUser.getPhoneNumber());
		return sameValFlag;
	}
	/**
	 * This method is used to return default string value as empty string even if it is null
	 * 
	 * @param val String
	 * @return String
	 */	
	private String defaultStr(String val) {
		return StringUtils.defaultString(val);
	}
	
	/**
	 * This method is used to check if user security questions changed
	 *
	 * @return boolean
	 */
	private boolean areUserSecQuestionsChanged() {
		boolean sameValFlag = true;				
		SecurityQuestionsBean bean = tbSecurityQuestionsBean;
		if(areValuesSame(defaultStr(getSecurityQuestionOne()), defaultStr(bean.getSecurityQuestionOne())) && 
				areValuesSame(defaultStr(getSecurityQuestionTwo()), defaultStr(bean.getSecurityQuestionTwo())) && 
				areValuesSame(defaultStr(getSecurityQuestionThree()), defaultStr(bean.getSecurityQuestionThree())) && 
				areValuesSame(defaultStr(getSecurityAnswerOne()), defaultStr(bean.getSecurityAnswerOne())) && 
				areValuesSame(defaultStr(getSecurityAnswerTwo()), defaultStr(bean.getSecurityAnswerTwo())) && 
				areValuesSame(defaultStr(getSecurityAnswerThree()), defaultStr(bean.getSecurityAnswerThree()))) {
			sameValFlag = false;
		}		
		return sameValFlag;
	}
	
	/**
	 * This method is used to check both the input values or same or not
	 * 
	 * @param valueOne String
	 * @param valueTwo String 
	 * @return boolean
	 */
	public boolean areValuesSame(String valueOne, String valueTwo) {
		boolean sameValFlag = false;				
		if( (valueOne == null && valueTwo == null) 
				|| (valueOne != null && valueOne.equalsIgnoreCase(valueTwo)) ) {
			sameValFlag = true;
		}		
		return sameValFlag;
	}

	public boolean isDisableEmailField() {
		return disableEmailField;
	}

	public void setDisableEmailField(boolean disableEmailField) {
		this.disableEmailField = disableEmailField;
	}

	public boolean isDisableSecAcctRecovery() {
		return disableSecAcctRecovery;
	}

	public void setDisableSecAcctRecovery(boolean disableSecAcctRecovery) {
		this.disableSecAcctRecovery = disableSecAcctRecovery;
	}

	public boolean isDisablePhoneAcctRecovery() {
		return disablePhoneAcctRecovery;
	}

	public void setDisablePhoneAcctRecovery(boolean disablePhoneAcctRecovery) {
		this.disablePhoneAcctRecovery = disablePhoneAcctRecovery;
	}

	public String getSecEmailHelpMessage() {
		return secEmailHelpMessage;
	}

	public void setSecEmailHelpMessage(String secEmailHelpMessage) {
		this.secEmailHelpMessage = secEmailHelpMessage;
	}

	public String getMobilePhoneHelpMessage() {
		return mobilePhoneHelpMessage;
	}

	public void setMobilePhoneHelpMessage(String mobilePhoneHelpMessage) {
		this.mobilePhoneHelpMessage = mobilePhoneHelpMessage;
	}

	public boolean isShowEmailSaveMsg() {
		return showEmailSaveMsg;
	}

	public void setShowEmailSaveMsg(boolean showEmailSaveMsg) {
		this.showEmailSaveMsg = showEmailSaveMsg;
	}
	
}
