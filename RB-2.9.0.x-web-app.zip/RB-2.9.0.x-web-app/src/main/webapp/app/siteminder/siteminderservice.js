'use strict';

angular.module('siteminderApp').service('SiteminderService', ['$http', SiteminderService]);

function SiteminderService($http) {
    this.validatePwd = function(postData) {
        return $http.post('/tb/services/rest/siteminderservice/validatePwd', postData);
    };

    this.getAboutToExpiredMsg = function() {
        return $http.get('/tb/services/rest/siteminderservice/getAboutToExpiredMsg');
    };

    this.removeAboutToExpiredMsg = function() {
        return $http.get('/tb/services/rest/siteminderservice/removeAboutToExpiredMsg');
    };
}
