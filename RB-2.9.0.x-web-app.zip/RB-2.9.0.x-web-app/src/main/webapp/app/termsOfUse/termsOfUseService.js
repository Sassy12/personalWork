'use strict';
var indexApp = angular.module('indexApp');
indexApp.service('termsOfUseService', ['$http', '$q', function($http, $q){
	//getting terms of use content from server
	this.getTermsData = function() {
		var deferred = $q.defer();
		$http.get('/tb/services/rest/terms-and-conditions').success(function(response){
			deferred.resolve(response);
		}).error(function(err){
			deferred.reject(err);
		});
		return deferred.promise;
	};
}]);