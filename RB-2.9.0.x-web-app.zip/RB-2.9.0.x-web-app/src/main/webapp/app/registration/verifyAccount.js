'use strict';

var indexApp = angular.module('indexApp');

indexApp.controller("verifyAccountController", ["$scope", "verifyAccountService", "$window", "$state", "LanguageService", "$translate", "getVerifyToken", verifyAccountController]);

function verifyAccountController($scope, verifyAccountService, $window, $state, LanguageService, $translate, getVerifyToken) {
    LanguageService.doTranslate("registration");
    $scope.isButtonEnbaled = false;
    $scope.showHeaderFooter = false;
    $scope.verifyLinkHeader = "verifyLinkVerifiedHeader";

    $scope.EmailVerificationErrorStatusModel = {
        animationTime: 1,
        content: '',
        headingLevel: '2',
        id: 'emailVerificationErrorStatusModelID',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    $scope.EmailVerificationSuccessStatusModel = {
        animationTime: 1,
        autoFadeOut: false,
        content: '',
        headingLevel: '2',
        id: 'emailVerificationSuccessStatusModelID',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: false
    };

    // console.log(getResponseVO);

    verifyAccountService.verifyEmailViaLink(getVerifyToken).then(function(response) {
        $scope.isButtonEnbaled = response.data.displayBtn;
        $scope.isRetToSignInButtonEnabled = false;
        $scope.isCodeExpired = false;
        $scope.isCodeNotFound = false;
        $scope.messageContent = response.data.msg;
        $scope.showHeaderFooter = true;

        if (response.data.msgType === 'ERROR') {
            $scope.showHeaderFooter = true;
            $scope.EmailVerificationErrorStatusModel.visible = true;
            $scope.EmailVerificationSuccessStatusModel.visible = false;
            $scope.EmailVerificationErrorStatusModel.content = '<span>' + response.data.msg + '</span>';                       
        } else if (response.data.msgType === 'SUCCESS') {
            $scope.showHeaderFooter = true;
            $scope.EmailVerificationErrorStatusModel.visible = false;
            $scope.EmailVerificationSuccessStatusModel.visible = true;
            $scope.EmailVerificationSuccessStatusModel.content = '<span>' + response.data.msg + '</span>';
        } else if (response.data.msgType === 'VERIFIED' || response.data.msgType === 'EXPIRED' || response.data.msgType === 'NOTFOUND') {
            $scope.showHeaderFooter = true;
            $scope.EmailVerificationErrorStatusModel.visible = false;
            $scope.EmailVerificationSuccessStatusModel.visible = false;
            $scope.mainMsg = response.data.msg;
            if(response.data.msgType === 'EXPIRED') {
            	$scope.verifyLinkHeader = "verifyLinkExpiredHeader";
            	$scope.isCodeExpired = true;            	
            } else if(response.data.msgType === 'NOTFOUND') {
            	$scope.verifyLinkHeader = "verifyLinkExpiredHeader";            	 
            	$scope.isCodeNotFound = true;            	
            } else {
            	$scope.isRetToSignInButtonEnabled = true;
            }            
        } else if (response.data.nextStateUrl && response.data.nextStateUrl !== "") {
            $scope.showHeaderFooter = false;
            $window.location.href = response.data.nextStateUrl;
        }
    });
    
    $scope.resendEmail = function () {                               
        verifyAccountService.resendEmail(getVerifyToken).then(function (response) {
        	$scope.EmailVerificationErrorStatusModel.visible = false;
            $scope.EmailVerificationSuccessStatusModel.visible = false;
        	if (response.data.msgType === 'SUCCESS') {
        		$scope.mainMsg = response.data.msg;           		
        	} else if (response.data.msgType === 'ERROR') {
        		 $scope.EmailVerificationErrorStatusModel.visible = true;
                 $scope.EmailVerificationSuccessStatusModel.visible = false;
                 $scope.EmailVerificationSuccessStatusModel.content = '<span>' + response.data.msg + '</span>';          		
        	}            
        });
    };

    $scope.nextItemOnVerification = function() {
        $window.location.href = "/tb/app/secure/home.do";
    };

    $scope.retBtnClick = function() {
        $state.go("login");
    };
}
