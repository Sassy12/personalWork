package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.AddressVO;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.alps.common.http.HttpUtils;

@ManagedBean(name = "onDemandStepUpRedirectBean")
@ViewScoped
public class OnDemandStepUpRedirectBean extends AbstractBackingBean implements
		Serializable {

	private static final long serialVersionUID = 1L;

	private String errorMsg;
	
	

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}


	
	public void init() {
		String targetUrl = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		targetUrl = constructTargetUrl(targetUrl);
		redirectToRelyingParty(
				targetUrl,
				null,
				null,
				(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
	}

	protected void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	public String constructTargetUrl(String targetUrl) {
		if (null != getSessionAttribute("showDOB")
				&& (Boolean) getSessionAttribute("showDOB")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "dobupdated",
					"y");
		}
		if (null != getSessionAttribute("showAddress")
				&& (Boolean) getSessionAttribute("showAddress")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"addressupdated", "y");
		}
		if (null != getSessionAttribute("showMobilePhone")
				&& (Boolean) getSessionAttribute("showMobilePhone")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"mobilephoneupdated", "y");
		}
		if (null != getSessionAttribute("ShowEmail")
				&& (Boolean) getSessionAttribute("ShowEmail")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "emailupdated",
					"y");
		}
		return targetUrl;
	}

}
