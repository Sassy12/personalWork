'use strict';
angular.module('indexApp').service('RegistrationService',['$http', RegistrationService]);

function RegistrationService($http){
	
	this.validateFirstName = function(postData){
		return $http.post('/tb/services/rest/userservice/validatefirstname', postData);
	};
	
	this.validateLastName = function(postData){
		return $http.post('/tb/services/rest/userservice/validatelastname', postData);
	};
	
	this.validateUserName = function(postData){
		return $http.post('/tb/services/rest/userservice/validateusername', postData);
	};
	
	this.validateEmail = function(postData){
		return $http.post('/tb/services/rest/userservice/validateemail', postData);
	};
	
	this.validateYOB = function(postData){
		 return $http.post('/tb/services/rest/userservice/validateyob', postData);
	};
	
	this.validateDOB = function(postData){
		 return $http.post('/tb/services/rest/userservice/validatedob', postData);
	};
	
	this.validatepwd = function(postData){
		 return $http.post('/tb/services/rest/userservice/validatepwd', postData);
	};
	
	this.initializedata = function() {
		return $http.get('/tb/services/rest/registration/initializedata?'+window.location.search.split("?")[1]);
	};
	 
	this.registerUser = function(postData){
		 return $http.post('/tb/services/rest/registration/createuser?'+window.location.search.split("?")[1], postData);
	};
	
}
