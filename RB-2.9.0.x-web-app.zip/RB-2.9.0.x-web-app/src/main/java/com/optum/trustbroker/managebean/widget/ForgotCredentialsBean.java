package com.optum.trustbroker.managebean.widget;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.ChallengeVerificationServiceRequest;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;

@ManagedBean(name = "wForgotCredentialsBean")
@ViewScoped
public class ForgotCredentialsBean extends AbstractBackingBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final BaseLogger LOGGER = new BaseLogger(ForgotCredentialsBean.class);

    private String firstName;

    private String lastName;

    private String emailId;

    //protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");
    String securityQuesPage = "/views/forgotusernamesecurityquesverificationpage.xhtml?faces-redirect=true";

    String emailNotVerifiedPage = "/views/emailnotverifiedpage.xhtml?faces-redirect=true";

    String userLockedPage = "/views/userlocked.xhtml?faces-redirect=true";

    String confirmationPage = "/views/forgotcredentialsconfirmationpagew.xhtml?faces-redirect=true";

    private String emailErrorMsg;

    private String errorMsg;

    @PostConstruct
    public void init() {
        @SuppressWarnings("unchecked")
        Map<String, String> userDetailsMap = (HashMap<String, String>) getSessionAttribute(
                TrustBrokerWebAppConstants.USER_DETAILS_MAP);
        addRelyingPartyAlias(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null
                ? getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString() : null);

        addSessionAttribute(TrustBrokerWebAppConstants.FORGOT_CREDENTIAL_FLOW, "forgotusername");
        addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE, "forgotPassword");
        addSessionAttribute(TrustBrokerWebAppConstants.RECOVERY_BY_EMAIL, getEmailId());
        addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);
        addSessionAttribute(TrustBrokerWebAppConstants.REGISTER_TYPE, "standAlone");

        addSessionAttribute("SELF_ACC_RECOVER_TYPE", "forgotPassword");
    }

    public String continueClicked() {

        if (!validateEmailFields()) {
            getFacesContext().addMessage("forgotUsernameForm:email",
                    new FacesMessage(tbResources.getString("invalidEmailAddress")));
            return null;
        }
        FacesContext context = getFacesContext();
        try {
            UserVO userVO = getUserProfile();
            if (userVO == null) {
                return null;
            }

            ChallengeVerificationServiceRequest request = new ChallengeVerificationServiceRequest();
            request.setEmailUserName(true);
            request.setEmailAddress(this.emailId);
            UserVO uservo = new UserVO();
            uservo.setUuId(userVO.getUuId());
            uservo.setUserName(userVO.getUserName());

            String rpAppId = getRelyingPartyAppId();
            request.setUserName(userVO.getUserName());
            request.setUser(uservo);
            //It will just send an email to user with username
            getContainer().getUserService().verifyChallengeAnswers(request, rpAppId, getUrlLogoOptumId(),
                    getUrlLogoRelyingParty());
            getSessionMap().put(TrustBrokerWebAppConstants.FORGOT_CREDENTIAL_FLOW, "forgotusername");
            return confirmationPage;

        } catch (OperationFailedException ex) {
            LOGGER.error("Exception while retirieving user challenge questions : " + ex);
            if (null != ex.getErrorMessage()) {
                setErrorMsg(
                        ex.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo()));
            } else if (TrustBrokerConstants.USER_LOCKED.equals(ex.getMessage())) {
                getFacesContext().addMessage(null, new FacesMessage("User Locked."));
                LOGGER.info("ForgotCredentialsBean :: " + getEmailId() + " user has been locked ");
                return null;
            }
            if (MapUtils.isNotEmpty(ex.getErrorMessages())) {
                if (ex.getErrorMessages().keySet().contains("USR101")) {
                    context.addMessage("forgotUsernameForm:email",
                            new FacesMessage("Email Address provided does not match our records"));
                } else {
                    context.addMessage("forgotUsernameForm:email", new FacesMessage(ex.getMessage()));
                }
            } else {
                context.addMessage("forgotUsernameForm:email", new FacesMessage(ex.getMessage()));
            }
            return null;
        }
    }

    public String navToLoginpage() {
        return "/views/login.xhtml?faces-redirect=true";
    }

    public String continuePassword() {

        if (!validateEmailFields()) {
            getFacesContext().addMessage("forgotPasswordForm:email",
                    new FacesMessage(tbResources.getString("invalidEmailAddress")));
            return null;
        }
        FacesContext context = getFacesContext();
        try {
            UserVO userVO = getUserProfile();
            if (userVO == null) {
                return null;
            }

            String rpAppId = getRelyingPartyAppId();
            getContainer().getUserService().sendAuthCodeToUser(generateAuthorizationRequest(userVO),
                    TrustBrokerConstants.ACCOUNT_RECOVERY, rpAppId, true, getUrlLogoOptumId(), getUrlLogoRelyingParty());
            getSessionMap().put("selfServiceRecoveryType", "forgotPassword");
        } catch (OperationFailedException ex) {
            LOGGER.error("Exception while getting User AuthCode : " + ex);
            if (null != ex.getErrorMessage()) {
                setErrorMsg(
                        ex.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo()));
            } else if (ex.getMessage().equals(TrustBrokerConstants.USER_LOCKED)) {
                getFacesContext().addMessage(null, new FacesMessage("User Locked."));
                LOGGER.info("ForgotCredentialsBean :: " + getEmailId() + " user has been locked ");
                return null;
            }
            if (ex.getErrorMessages() != null && ex.getErrorMessages().size() > 0) {
                String code = ex.getErrorMessages().keySet().iterator().next();
                if ("USR101".equals(code)) {
                    context.addMessage("forgotPasswordForm:email",
                            new FacesMessage("Email Address provided does not match our records"));
                } else {
                    context.addMessage("forgotPasswordForm:email", new FacesMessage(ex.getMessage()));
                }
            } else {
                context.addMessage("forgotPasswordForm:email", new FacesMessage(ex.getMessage()));
            }
            return null;
        }

        return "/views/sentauthorizationcodew.xhtml?faces-redirect=true";
    }

    public UserVO getUserProfile() throws OperationFailedException {

        UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
        UserVO userValueObject = new UserVO();
        userValueObject.setEmailAddress(getEmailId());
        userProfileServiceRequest.setUser(userValueObject);
        UserRetrievalServiceResponse userRetrievalServiceResponse = getContainer().getUserService()
                .fetchUserProfileByEmail(getEmailId());
        if (!TrustbrokerWebAppUtil.checkResponseStatus(userRetrievalServiceResponse)
                || userRetrievalServiceResponse.getUser().getUuId() == null
                || !userRetrievalServiceResponse.getUser().getFirstName().equalsIgnoreCase(getFirstName())
                || !userRetrievalServiceResponse.getUser().getLastName().equalsIgnoreCase(getLastName())) {
            LOGGER.info("ForgotCredentialsBean | Email Address {} does not match our records", new String[] {getEmailId()});
            SupportContactInfoVO sci = getSupportContactInfo();
            Object[] msgArguments = {sci.getContactComboText()};
            setErrorMsg(TBUtil.formatMessage(tbResources.getString("selfServiceInvalidActError"), msgArguments));
            return null;
        }
        addSessionAttribute(TrustBrokerWebAppConstants.RECOVERY_BY_EMAIL, getEmailId());
        Map<String, String> userDetailsMap = new HashMap<String, String>();
        userDetailsMap.put("emailId", getEmailId());
        userDetailsMap.put("uuId", userRetrievalServiceResponse.getUser().getUuId());
        userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME, userRetrievalServiceResponse.getUser().getUserName());
        addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);
        UserVO userVO = null;

        userVO = userRetrievalServiceResponse.getUser();
        if (!userVO.isIsemailVerified()) {
            LOGGER.info("ForgotCredentialsBean | Email Address {} is not verified", new String[] {getEmailId()});
            SupportContactInfoVO sci = getSupportContactInfo();
            Object[] msgArguments = {sci.getContactComboText()};
            setErrorMsg(TBUtil.formatMessage(tbResources.getString("forgotUserNameEmailNotVerified"), msgArguments));
            return null;
        }

        return userVO;
    }

    /**
     * Gets the faces context
     * 
     * @return current FacesContext otherwise
     */
    @Override
    public FacesContext getFacesContext() {
        if (FacesContext.getCurrentInstance() != null) {
            return FacesContext.getCurrentInstance();
        }
        return super.getFacesContext();
    }

    private boolean validateEmailFields() {
        boolean result = true;
        if (!TBUtil.validateEmailId(getEmailId())) {
            result = false;
        }
        return result;
    }

    public void checkEmailAddress(ValueChangeEvent event) {
        PhaseId phaseId = event.getPhaseId();
        if (phaseId.equals(PhaseId.ANY_PHASE)) {
            event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
            event.queue();
        } else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
            if (StringUtils.isNotEmpty(event.getNewValue().toString())) {
                boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
                LOGGER.debug("result value in email: " + result);
                if (!result)
                    addFacesMessage(((UIComponent) event.getSource()).getClientId(),
                            tbResources.getString("invalidEmailAddress"));
            }
        }
    }

    private void addFacesMessage(String fieldId, String message) {
        getFacesContext().addMessage(fieldId, new FacesMessage(message));
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailExistsMsgId the emailExistsMsgId to set
     */
    public void setEmailErrorMsg(String emailErrorMsg) {
        this.emailErrorMsg = emailErrorMsg;
    }

    /**
     * @return the emailExistsMsgId
     */
    public String getEmailErrorMsg() {
        return emailErrorMsg;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

}
