package com.optum.trustbroker.managebean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.auditlogging.IDProofingAuditTypes;
import com.optum.trustbroker.auditlogging.IDProofingLoggingUtil;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.UuidUtil;
import com.optum.trustbroker.vo.IDProofingQuizAnswer;
import com.optum.trustbroker.vo.IDProofingQuizQuestion;
import com.optum.trustbroker.vo.IDProofingQuizServiceRequest;
import com.optum.trustbroker.vo.IDProofingQuizServiceResponse;
import com.optum.trustbroker.vo.IDProofingQuizVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserTagServiceResponse;

@ManagedBean(name = "kbIdentificationQuizBean")
@ViewScoped
public class KBIdentificationQuizBean extends AbstractBackingBean {
	BaseLogger logger = new BaseLogger(KBIdentificationQuizBean.class);
	private IDProofingQuizVO idProofingQuizVO;
	Map<String, List<SelectItem>> answersOptions = new HashMap<String, List<SelectItem>>();
	private String idProofingErrorMsg;

	public IDProofingQuizVO getIdProofingQuizVO() {
		return idProofingQuizVO;
	}

	public void setIdProofingQuizVO(IDProofingQuizVO idProofingQuizVO) {
		this.idProofingQuizVO = idProofingQuizVO;
	}

	public Map<String, List<SelectItem>> getAnswersOptions() {
		return answersOptions;
	}

	public void setAnswersOptions(Map<String, List<SelectItem>> answersOptions) {
		this.answersOptions = answersOptions;
	}

	public String getIdProofingErrorMsg() {
		return idProofingErrorMsg;
	}

	public void setIdProofingErrorMsg(String idProofingErrorMsg) {
		this.idProofingErrorMsg = idProofingErrorMsg;
	}

	@PostConstruct
	public void init() {
		IDProofingQuizVO quizVO = (IDProofingQuizVO) getSessionAttribute(TrustBrokerWebAppConstants.ID_PROOFING_QUIZ);
		if (null != quizVO) {
			this.setIdProofingQuizVO(quizVO);
			generateAnswers(getIdProofingQuizVO());
		}
	}

	private void generateAnswers(IDProofingQuizVO idProofingQuizVO) {
		for (IDProofingQuizQuestion question : idProofingQuizVO.getQuestions()) {
			List<SelectItem> answersList = new ArrayList<SelectItem>();
			for (IDProofingQuizAnswer answer : question.getAnswers()) {
				SelectItem selectItem = new SelectItem(answer.getAnswerId(),
						answer.getAnswerText());
				answersList.add(selectItem);
			}
			getAnswersOptions().put(question.getQuestionId(), answersList);
		}
	}

	public String processQuiz() {
		UserRetrievalServiceResponse userRetrievalServiceResponse = getContainer().getUserService().fetchUserProfile(
				(String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_UUID), true, false);
		IDProofingQuizServiceRequest idProofingQuizServiceRequest = new IDProofingQuizServiceRequest();
		idProofingQuizServiceRequest.setIdProofingQuizVO(getIdProofingQuizVO());
		boolean isBasic = true;
		
		if (TrustBrokerWebAppConstants.LOA3_VALIDATION_IDPROOFING.equalsIgnoreCase(
				(String) getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG))){
			idProofingQuizServiceRequest.setVerificationFlow(getContainer().getConfigProps().getProperty("loa3_idp_verification_flow"));
			isBasic = false;
		}
		else {
			idProofingQuizServiceRequest.setVerificationFlow(getContainer().getConfigProps().getProperty("basic_idp_verification_flow"));
		}
		HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
        String loginUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
		           + "" + request.getContextPath()+ "/views/login.jsf";	
		try {
			  boolean sendEmail =  getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG) !=null ? false : true;
			 String rpAppId = getRelyingPartyAppId();
			  IDProofingQuizServiceResponse idProofingResponse = getContainer().getIdProofingService().processQuiz(
						idProofingQuizServiceRequest,
						(String) getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_UUID),
						loginUrl, sendEmail, rpAppId, getUrlLogoOptumId(), getUrlLogoRelyingParty());
			String executionStatusCd = idProofingResponse.getExecutionStatus().getStatusCd();
			logger.debug("executionStatusCd code after processQuiz call: " + executionStatusCd);
			if(TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(executionStatusCd)) {
				IDProofingLoggingUtil.info(isBasic ? IDProofingAuditTypes.SVC_IDP_BASIC_QUIZ_SUCCESS : IDProofingAuditTypes.SVC_IDP_LOA3_QUIZ_SUCCESS, 
						getRelyingPartyAppId(), userRetrievalServiceResponse.getUser().getUserName(), getErrorReasonCode(idProofingResponse.getExecutionStatus()), 
						"KBIdentificationQuizBean:processQuiz()", getServletRequest());
				
				if (null != getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG_NAME)) {
					try {
						Object tagName = getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG_NAME);
						UserTagServiceResponse resp = addTagToUser(getCurrentUserVO().getUuId(), tagName.toString(),
								idProofingResponse.getVerificationCode());
						if (resp.getExecutionStatus().getStatusCd().equalsIgnoreCase(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
							return "/secure/idverificationsuccess.xhtml?faces-redirect=true";
						}
						else {
							setIdProofingErrorMsg(resp.getExecutionStatus().getStatusMessage());
							return null;
						}
					} catch (OperationFailedException ope) {
						logger.error("Error while applying tag to user: {}", new String[]{getCurrentUserVO().getUserName(),
								TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
						setIdProofingErrorMsg(ope.getMessage());
						return null;
					}
				} else{
					String selfServiceRecoveryType = (String)getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
					if(selfServiceRecoveryType!=null && TrustBrokerWebAppConstants.LOST_ACCESS_TO_RECOVERY.equals(selfServiceRecoveryType))
						return "/views/resetsecurity.xhtml?faces-redirect=true";
					else if(selfServiceRecoveryType != null && TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK.equals(selfServiceRecoveryType))
						return "/views/resetsecuritycredwithoutsq.xhtml?faces-redirect=true";
					else return "/views/resetsecuritycredentials.xhtml?faces-redirect=true";
				}
			}
			else {
				String response = processStatusCode(idProofingResponse, userRetrievalServiceResponse.getUser().getUserName(), isBasic);
				return response;
			}
		}
		catch (Exception e) {
			String uid = UuidUtil.generateUid();
			logger.error("Error occured while processing Quiz using ID Proofing services - {}" , new String[]{uid}, e);
			setIdProofingQuizVO(new IDProofingQuizVO());
			SupportContactInfoVO sci = getSupportContactInfo();
			Object[] msgArguments = {sci.getContactComboText(), uid};
			setIdProofingErrorMsg(TBUtil.formatMessage(tbResources.getString("systemError"), msgArguments));
			return null;
		}
	}
	
	private String processStatusCode(IDProofingQuizServiceResponse idProofingResponse, String userName, boolean isBasic){
		String response = null;
		String errorMsg = null;
		IDProofingLoggingUtil.info(isBasic ? IDProofingAuditTypes.SVC_IDP_BASIC_QUIZ_FAIL : IDProofingAuditTypes.SVC_IDP_LOA3_QUIZ_FAIL, 
				getRelyingPartyAppId(), userName, getErrorReasonCode(idProofingResponse.getExecutionStatus()), 
				"KBIdentificationQuizBean:processStatusCode()", getServletRequest());
		String executionStatusCd = idProofingResponse.getExecutionStatus().getStatusCd();
		SupportContactInfoVO sci = getSupportContactInfo();

		if (TrustBrokerConstants.SYSTEM_ERROR_CODE_VALUE.equals(executionStatusCd)) {
			String uid = UuidUtil.generateUid();
			logger.error("System Error: {} While processing the quiz for user: {}" , new String[]{
					idProofingResponse.getExecutionStatus().getStatusMessage(), userName, uid});
			setIdProofingQuizVO(new IDProofingQuizVO());
			Object[] msgArguments = {sci.getContactComboText(), uid};
			setIdProofingErrorMsg(TBUtil.formatMessage(tbResources.getString("systemError"), msgArguments));
			response = null;
		}
		else if (TrustBrokerConstants.BAD_REQUEST_CODE_VALUE.equals(executionStatusCd)) {
			logger.error("Bad Request error: "+ idProofingResponse.getExecutionStatus().getStatusMessage());
			setIdProofingQuizVO(new IDProofingQuizVO());
			Object[] msgArguments = {"", sci.getContactComboText()};
			setIdProofingErrorMsg(TBUtil.formatMessage(tbResources.getString("badRequest"), msgArguments));
			response = null;
		}
		else if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(executionStatusCd)
				|| TrustBrokerConstants.PARTIAL_FAILURE_CODE.equals(executionStatusCd)) {

			if (null != idProofingResponse.getIdProofingQuizVO()) {
				logger.debug("Initiated secondary quiz for the user '");
				setIdProofingQuizVO(idProofingResponse.getIdProofingQuizVO());
				generateAnswers(idProofingResponse.getIdProofingQuizVO());
				response = null;
			} else {
				if (null != getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG)) {
					if(getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG).equals(TrustBrokerWebAppConstants.BASIC_VALIDATION_IDPROOFING))
						addSessionAttribute(TrustBrokerWebAppConstants.BROWSE_TITLE, tbResources.getString("basicIDProofingTitle"));
					else if(getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG).equals(TrustBrokerWebAppConstants.LOA3_VALIDATION_IDPROOFING))
						addSessionAttribute(TrustBrokerWebAppConstants.BROWSE_TITLE, tbResources.getString("loa3IDProofingTitle"));
					Object[] arguments = {getSessionAttribute(TrustBrokerWebAppConstants.RP_APP_NAME), sci.getContactComboText()};
					addSessionAttribute(TrustBrokerWebAppConstants.ID_FAILURE_MSG, 
							(TBUtil.formatMessage(tbResources.getString("idVerificationFailure"), arguments)));
				}
				removeSessionAttributes();
				response = "/views/idverificationfailure.xhtml?faces-redirect=true";
			}
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_ID1.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_ID1"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP1.equals(executionStatusCd)){
			if(TrustBrokerWebAppConstants.BASIC_VALIDATION_IDPROOFING.equals(getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG))){
				Object[] msgArguments = {"", sci.getContactComboText()};
				errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP1_Basic"), msgArguments);
			}
			else if(TrustBrokerWebAppConstants.LOA3_VALIDATION_IDPROOFING.equals(getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG))){
				Object[] msgArguments = {"", sci.getContactComboText()};
				errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP1_LOA3"), msgArguments);
			}
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP2.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP2"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP3.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP3"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP4.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP4"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP5.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP5"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP6.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP6"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_SE1.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_SE1"), msgArguments);
		}
		else{
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_GEN"), msgArguments);
		}
		
		if(errorMsg != null){
			logger.error("ID Proofing Failure:"+ idProofingResponse.getExecutionStatus().getStatusMessage());
			String errorCodes = StringUtils.join(idProofingResponse.getExecutionStatus().getStatusCodesList(), ",");
			errorCodes = (idProofingResponse.getExecutionStatus().getStatusCodesList().size() > 1 ? "s ":" ") + errorCodes;
			Object[] arguments = {errorCodes};
			errorMsg = TBUtil.formatMessage(errorMsg, arguments);
			
			setIdProofingErrorMsg(errorMsg);
			response = null;
		}
		
		return response;
		
	}

	private void removeSessionAttributes() {
		removeSessionAttribute("qualifyingTag");
		removeSessionAttribute("qualifyingTagName");
		removeSessionAttribute("userDetailsMap");
		removeSessionAttribute("selfServiceRecoveryType");
	}
	
	public String idVerificationSuccess() {
		removeSessionAttributes();
		return getHomePageURIWithAlias();
	}

	public String idVerificationFailure() {
		removeSessionAttributes();
		String relyingPartyRedirectionParams = getRelyingPartyRedirectionParameters();
		if(StringUtils.isNotBlank(relyingPartyRedirectionParams))
			return "/views/login.xhtml?faces-redirect=true&"+ relyingPartyRedirectionParams;
		else
		return "/views/login.xhtml?faces-redirect=true";
	}
	
}
