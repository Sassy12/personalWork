CREATE SEQUENCE "I18N_MESSAGE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 5 CACHE 20 NOORDER  NOCYCLE;

CREATE TABLE "I18N_MESSAGE" 
("MSG_ID" NUMBER NOT NULL ENABLE, 
"MSG_KEY" VARCHAR2(64 BYTE) NOT NULL ENABLE, 
"MSG_VALUE" BLOB NOT NULL ENABLE,  
"LANGUAGE_TAG" VARCHAR2(64 BYTE) NOT NULL ENABLE, 
"TEMPLATE_TYPE" NUMBER DEFAULT 0 NOT NULL ENABLE, 
"CREATED_BY" VARCHAR2(50 BYTE) NOT NULL ENABLE, 
"MODIFIED_BY" VARCHAR2(50 BYTE) NOT NULL ENABLE, 
"CREATED_TS" TIMESTAMP (6) NOT NULL ENABLE, 
"MODIFIED_TS" TIMESTAMP (6) NOT NULL ENABLE, 
CONSTRAINT "I18N_MESSAGE_PK" PRIMARY KEY ("MSG_ID")
USING INDEX);

insert into I18N_MESSAGE (msg_id, msg_key, msg_value, language_tag, template_type, created_by, modified_by, created_ts, modified_ts)
values (1, 'terms-and-conditions-0.5', (select content from terms_and_conditions where version = '0.5'), 'en', 1,
    'TB_APP_ID', 'TB_APP_ID', (select created_ts from terms_and_conditions where version = '0.5'),
    (select modified_ts from terms_and_conditions where version = '0.5'));

insert into I18N_MESSAGE (msg_id, msg_key, msg_value, language_tag, template_type, created_by, modified_by, created_ts, modified_ts)
values (2, 'terms-and-conditions-1.0', (select content from terms_and_conditions where version = '1.0'), 'en', 1,
    'TB_APP_ID', 'TB_APP_ID', (select created_ts from terms_and_conditions where version = '1.0'),
    (select modified_ts from terms_and_conditions where version = '1.0'));

insert into I18N_MESSAGE (msg_id, msg_key, msg_value, language_tag, template_type, created_by, modified_by, created_ts, modified_ts)
values (3, 'privacy-policy-link-admin',
utl_raw.cast_to_raw('<a href="../views/privacypolicy.jsf" id="footerId"  onclick="newwindow=window.open(this.href, ''privacyPolicy'',''left=20,top=20,toolbar=no, titlebar=yes, location=no, directories=no, status=no, menubar=no,resizable=1,scrollbars=yes'');if (window.focus) {newwindow.focus()}; return false;">Privacy Policy</a>'),
'en', 0, 'TB_APP_ID', 'TB_APP_ID', current_timestamp,  current_timestamp);

insert into I18N_MESSAGE (msg_id, msg_key, msg_value, language_tag, template_type, created_by, modified_by, created_ts, modified_ts)
values (4, 'terms-link-admin',
utl_raw.cast_to_raw('<a href="../views/termsandconditions.jsf" id="footerIdterms"  onclick="termscondtnwindow=window.open(this.href, ''termsAndCondition'',''left=20,top=20,toolbar=no, titlebar=yes, location=no, directories=no, status=no, menubar=no,resizable=1,scrollbars=yes'');if (window.focus) {termscondtnwindow.focus()}; return false;">Terms and Conditions</a>'),
'en', 0, 'TB_APP_ID', 'TB_APP_ID',  current_timestamp,  current_timestamp);

alter table TERMS_AND_CONDITIONS
add I18N_MESSAGE_KEY VARCHAR2(64);

update terms_and_conditions
set i18n_message_key = 'terms-and-conditions-0.5'
where version = '0.5';

update terms_and_conditions
set i18n_message_key = 'terms-and-conditions-1.0'
where version = '1.0';

-- only do these after all versions of the same environment are ready; ie don't do in dev, till dev and dev2 are ready
-- don't do in test, till test and test2 are ready
--alter table terms_and_conditions
--drop column content;
--alter table terms_and_conditions
--drop column created_by;
--alter table terms_and_conditions
--drop column modified_by;
--alter table terms_and_conditions
--drop column created_ts;
--alter table terms_and_conditions
--drop column modified_ts;
