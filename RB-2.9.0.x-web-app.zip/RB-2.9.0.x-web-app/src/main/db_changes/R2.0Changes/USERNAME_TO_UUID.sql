 
--Add a new column UUID in USER_RP_REL
ALTER TABLE TBDEV_ORA.USER_RP_REL ADD UUID varchar2(50);

--Populate UUID in USER_RP_REL
set serveroutput on
declare
user_uuid varchar2(50);
cursor c1 is SELECT * FROM USER_RP_REL; 
begin 
    FOR i in c1 LOOP
         select uuid INTO user_uuid from TB_USER where user_name=i.user_name;
         update USER_RP_REL set uuid=user_uuid where user_name=i.user_name;
    END LOOP;
    commit;
end;

--Delete USER_RP_REL_TB_USER_FK1 
--Delete UNIQUE_UNAME_APP_ID
ALTER TABLE 
   USER_RP_REL 
drop constraint
   USER_RP_REL_TB_USER_FK1;
 ALTER TABLE 
   USER_RP_REL 
drop constraint
   UNIQUE_UNAME_APP_ID;  
   
ALTER TABLE TB_USER enable CONSTRAINT UNIQUE_UUID;
   
 ---Add new constraints
ALTER TABLE USER_RP_REL ADD CONSTRAINT USER_RP_REL_TB_USER_FK1 FOREIGN KEY (UUID) REFERENCES TB_USER(UUID);
ALTER TABLE USER_RP_REL ADD CONSTRAINT UNIQUE_UUID_APP_ID UNIQUE (UUID, APPLICATION_ID);



--Add a new column UUID in AUDIT_USER_CONSENT
ALTER TABLE TBDEV_ORA.AUDIT_USER_CONSENT ADD UUID varchar2(50);

--Populate UUID in AUDIT_USER_CONSENT
set serveroutput on
declare
user_uuid varchar2(50);
cursor c1 is SELECT * FROM AUDIT_USER_CONSENT; 
begin 
    FOR i in c1 LOOP
         select uuid INTO user_uuid from TB_USER where user_name=i.user_name;
         update AUDIT_USER_CONSENT set uuid=user_uuid where user_name=i.user_name;
    END LOOP;
    commit;
end;

--Delete AUDIT_USER_CONSENT_TB_USE_FK1

ALTER TABLE 
   AUDIT_USER_CONSENT 
drop constraint
   AUDIT_USER_CONSENT_TB_USE_FK1;

 ---Add new constraints
ALTER TABLE AUDIT_USER_CONSENT ADD CONSTRAINT AUDIT_USER_CONSENT_TB_USE_FK1 FOREIGN KEY (UUID) REFERENCES TB_USER(UUID);

--Remove user_name columns 

   ALTER TABLE 
   TBDEV_ORA.TB_USER
drop constraint
   UNIQUE_UNAME;
   
   alter table
   TBDEV_ORA.TB_USER
drop column
   USER_NAME;
   
      
   alter table
   TBDEV_ORA.USER_RP_REL
drop column
   USER_NAME;
   
      alter table
   TBDEV_ORA.AUDIT_USER_CONSENT
drop column
   USER_NAME;