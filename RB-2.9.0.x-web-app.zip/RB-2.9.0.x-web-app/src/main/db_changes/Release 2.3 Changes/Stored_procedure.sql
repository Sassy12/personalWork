create or replace
PROCEDURE migrate_users(p_commit_size in number default 500) AS
  counter number(4) default 1;
  error_msg varchar2(100);
BEGIN
    
    FOR c_uuids IN (select id, uuid from user_migration_data where migration_status_cd = 'I') LOOP
    BEGIN
        INSERT INTO TB_USER(id,
                             UUID,
                             CREATED_BY,
                             MODIFIED_BY,
                             CREATED_TS,
                             MODIFIED_TS,
                             USER_ROLE_CD,
                             MIGRATED_USER)
             VALUES(USR_ID_SEQ.NEXTVAL,
                     c_uuids.uuid,
                     'TB_APP_ID',
                     'TB_APP_ID',
                     SYSDATE,
                     SYSDATE,
                     '1',
                     'Y');     

        UPDATE user_migration_data SET migration_status_cd='C' WHERE id=c_uuids.id;
        If counter = 500 then
            counter := 0;
            commit;
        end if;
        counter := counter + 1;
    
    EXCEPTION 
        WHEN OTHERS THEN
            error_msg :=SUBSTR(SQLERRM, 1, 100);
            UPDATE user_migration_data SET migration_status_cd = 'F', EXCEPTION_MSG=error_msg WHERE id=c_uuids.id;
            commit;
    END;    
  END LOOP;  
  commit;
END migrate_users;