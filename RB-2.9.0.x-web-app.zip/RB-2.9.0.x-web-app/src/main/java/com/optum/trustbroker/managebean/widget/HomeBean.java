/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2011.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When          Who         Why
 * Apr 12 2014   bmanna3		Initial version
 ****************************************************************/
package com.optum.trustbroker.managebean.widget;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.domain.UserRelyingPartyRelation;
import com.optum.trustbroker.events.impl.UserSuccessfulSignInEvent;
import com.optum.trustbroker.managebean.EmailConfirmationBean;
import com.optum.trustbroker.managebean.UserStepUpContext;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.esso.schemas.xsd._2013._12.AuthenticationType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

@ManagedBean(name = "wHomeBean")
@RequestScoped
public class HomeBean extends AbstractBackingBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private BaseLogger logger = new BaseLogger(HomeBean.class);
	protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");

	@ManagedProperty(value = "#{emailConfirmationBean}")
	private EmailConfirmationBean emailConfirmationBean;

	private String username;
	private String errorMsg;
	private String confirmationCodeMessages;
	
	private boolean coppaValdnReqd = true;
	
	public String getConfirmationCodeMessages() {
		return confirmationCodeMessages;
	}

	public void setConfirmationCodeMessages(String confirmationCodeMessages) {
		this.confirmationCodeMessages = confirmationCodeMessages;
	}

	public EmailConfirmationBean getEmailConfirmationBean() {
		return emailConfirmationBean;
	}

	public void setEmailConfirmationBean(EmailConfirmationBean emailConfirmationBean) {
		this.emailConfirmationBean = emailConfirmationBean;
	}

	/**
	 * This method gets called before view gets initialized.
	 */
	public void onPreinitialize() {

		reCaptureRPDetails();
		removeSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME); // Clean up step up context from session first
		
		// gtyagi1: raise an event to indicate that a successful login has occurred!, note that 
		// if there are other checks that prevents user to not login (app specific reasons),
		// positioning of this event is critical for SsoBroker linkage mapping, we don't 
		// want to lose that context in doing any of our processing!
		this.getContainer().getEventPublisherService().publish(new UserSuccessfulSignInEvent(this, getCurrentUserVO()));
		
		if(getCurrentUserVO() != null) {
			username = getCurrentUserVO().getUserName();
			RelyingPartyAppVO relyingPartyAppVO = null; 
			UserRelyingPartyRelation userRelyingPartyRelation =null;
			
			//Add relying party access to user.
			if (isSessionContainsRPInfoForLogin()) {
				
				relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(
								(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
				
				//Coppa will be required by default unless configured as N for relying party 
				if(relyingPartyAppVO != null && COPPA_REQD_NO_IND.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
					coppaValdnReqd = false;
				}
				
				if(!checkAddApplicationAccess(relyingPartyAppVO)) return; // Add application access
				
				// Add User RP relation with default consent as NO
				userRelyingPartyRelation = container.getUserService().getAssociationBetweenUserAndRelyingApp(
								getCurrentUserVO().getUuId(),relyingPartyAppVO.getApplicationId());
				if (userRelyingPartyRelation == null && !addUserRelyingPartyRelation(relyingPartyAppVO)) return; 
			}
			
			//Check if user is having useraware flag as false, redirect user to RP
			if(!getCurrentUserVO().isUserAwarenessFlag() && isSessionContainsRPInfoForLogin()) {
				redirectVDSUserBackToRP(relyingPartyAppVO); return;
			}
			
			//Check RP tier configurations and then add the required details in session to refer for step up.
			checkRPTierConfigurations();
			
			//Check if COPPA needs to be performed based on user profile data and RP configuration
			checkifStepUpRequiredForCOPPA(coppaValdnReqd);
			
			//Check 0 - Migrated user or not
			if(getCurrentUserVO().isMigratedUser()){
				UserStepUpContext userStepUpContext = getUserStepUpContext(true);
				userStepUpContext.setShowUserName(getCurrentUserVO().isUserNameChangeRequired());
				userStepUpContext.setShowPassword(getCurrentUserVO().isPasswordChangeRequired());
				redirectToView("/securew/userstepupprofilew.jsf"); return;
			}
			
			//Check 1 for verifying the Primary Email for Normal user - Always needs to be verified first
			if(!isSessionAttributeExists(TrustBrokerWebAppConstants.USER_MIGRATED) && checkPrimaryEmailConfirmationRequired()) return;
			
			// check 2
			// If the user does not have email, mobile number and SQ then take the user to Post login account recovery page.
			if (isSessionAttributeExists(UserStepUpContext.SESSION_NAME_IFRAME) || checkIfUserAccountRecoveryRequired()) {
				redirectToView("/securew/userstepupprofilew.jsf"); return;
			}
			
			//For a migrated user account recovery will take precedence and then verification. 
			if(checkPrimaryEmailConfirmationRequired()) return;
			
			if(isSessionAttributeExists(TrustBrokerWebAppConstants.USER_MIGRATED)){
				redirectToView("/securew/migrationsuccessw.jsf");
			}
			
		}
	}
	
	//Redirect VDS user as it is system generated user only and must not access Optum ID directly 
	private void redirectVDSUserBackToRP(RelyingPartyAppVO relyingPartyAppVO){
		String relyingPartyTargetURL = getRelyingPartyRedirectionURL();
		relyingPartyTargetURL = constructRedirectUrl(relyingPartyTargetURL);
		String partnerID;
		if (relyingPartyAppVO != null) partnerID = relyingPartyAppVO.getPartnerId();
		else partnerID = TrustBrokerWebAppConstants.DEFAULT_PARTNER_ID;
		
		redirection(relyingPartyTargetURL, partnerID);
	}
	
	//Add application access to user 
	public boolean checkAddApplicationAccess(RelyingPartyAppVO relyingPartyAppVO){
		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(getCurrentUserVO());
		try {
			 container.getUserService().checkAddApplicationAccess(userProfileServiceRequest, relyingPartyAppVO);
		} catch (OperationFailedException ofe) {
			logger.error("HomeBean:processRelyingPartyRequest() | Application access for user {} with relying party {} failed - {}", 
					new String[]{username, relyingPartyAppVO.getApplicationName(), TrustbrokerWebAppUtil.getUidFromError(ofe)},ofe);
			handleInvalidSession(ofe.getErrorMessage(), ofe);
			return false;
		}
		logger.debug("HomeBean:processRelyingPartyRequest() | Application access added for user {} with relying party {}", 
				new String[]{username, relyingPartyAppVO.getApplicationId()});
		
		return true;
	}
	
	//Add relying party access to user 
	public boolean addUserRelyingPartyRelation(RelyingPartyAppVO relyingPartyAppVO){
		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(getCurrentUserVO());
		try {
			 container.getUserService().addUserRelyingPartyRelation(userProfileServiceRequest, relyingPartyAppVO);
		} catch (OperationFailedException ofe) {
			logger.error("HomeBean:processRelyingPartyRequest() | User association for user {} with relying party {} failed - {}", 
					new String[]{username, relyingPartyAppVO.getApplicationName(), TrustbrokerWebAppUtil.getUidFromError(ofe)},ofe);
			handleInvalidSession(ofe.getErrorMessage(), ofe);
			return false;
		}
		logger.debug("HomeBean:processRelyingPartyRequest() | Associated user {} with relying party {}", 
				new String[]{username, relyingPartyAppVO.getApplicationId()});
		
		return true;
	}
	
	//Check relying party tier configurations and add details to session
	private void checkRPTierConfigurations(){
		UserStepUpContext stepUpContext = getUserStepUpContext(false);
		
		if(isSessionContainsRPInfoForLogin()) {
		 	List<UserChallengeQuestionVO> securityQuesList = getCurrentUserVO().getUserChallengeQuestions();
		 	String tierId = null;
		 	QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
		 	queryRelyingPartyResponse = container.getConfigService().queryRelyingParty(getSessionAttribute(
		 			TrustBrokerWebAppConstants.RELYING_APP_ALIAS).toString());
		 	List<AuthenticationType> authenticationTypes=null;
			if(queryRelyingPartyResponse!=null &&  queryRelyingPartyResponse.getRelyingParty()!=null) {
				RelyingParty rp = queryRelyingPartyResponse.getRelyingParty();
				if (rp.getTiers() != null && rp.getTiers().size() > 0) {
					TierConfig tierConfig = rp.getTiers().get(0);
					tierId = tierConfig.getTierId();
					authenticationTypes = tierConfig.getAuthenticationTypes();
				}
			}
		 	
			if(securityQuesList == null || (securityQuesList!=null && securityQuesList.size()==0)) {
				if (authenticationTypes != null && authenticationTypes.size() > 0) {
					for (Iterator<AuthenticationType> iterator = authenticationTypes.iterator(); iterator.hasNext();) {
						AuthenticationType authenticationType = iterator.next();
						if (authenticationType.value().equalsIgnoreCase(TrustBrokerConstants.SECURITY_QUESTIONS)) {
							stepUpContext.setSecQuestionRequired(true);
							stepUpContext.setShowSecQuestions(true);
							break;
						}
					}
				}
		 	}
			
			if (StringUtils.isNotBlank(tierId)) {
				QueryTierResponse queryTierResponse = new QueryTierResponse();
				queryTierResponse = container.getConfigService().queryTier(tierId);
				if (queryTierResponse != null && queryTierResponse.getTierDefinition() != null) {
					List<TierAttribute> tierAttributes = queryTierResponse.getTierDefinition().getTierAttributes();
					for (Iterator<TierAttribute> iterator = tierAttributes.iterator(); iterator.hasNext();) {
						TierAttribute tierAttribute = iterator.next();
						if (tierAttribute.getName().equalsIgnoreCase(TrustBrokerConstants.DATE_OF_BIRTH) && getCurrentUserVO().getDob() == null) {
							if (tierAttribute.isMandatory()) {
								stepUpContext.setDobRequired(true);
								stepUpContext.setCoppaRequired(coppaValdnReqd);
								stepUpContext.setShowDob(true);
							}
						} else if(tierAttribute.getName().equalsIgnoreCase(TrustBrokerConstants.EMAIL_ADDRESS)){
							stepUpContext.setEmailUnique(tierAttribute.isUnique());
							stepUpContext.setEmailMandatory(tierAttribute.isMandatory());
							stepUpContext.setShowEmail(checkIfEmailRequiredOnStepUp(true, tierAttribute.isUnique(), tierAttribute.isMandatory()));
						}
					}
				}
			}
			
			if(stepUpContext.isStepUpRequired() || getCurrentUserVO().isMigratedUser()){
				addSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME, stepUpContext);
			}
		 } else {
				if (getCurrentUserVO().getEmailAddress() == null) {
					stepUpContext.setShowEmail(true);
					stepUpContext.setEmailMandatory(true);
					addSessionAttribute(UserStepUpContext.SESSION_NAME_IFRAME, stepUpContext);
				}
		 }
	}
		
	private boolean checkIfEmailRequiredOnStepUp(boolean isRpContextAvailable, boolean isUniqueEmailRequired, boolean isEmailMandatory){
		boolean status = false;
		
		if(isRpContextAvailable){
			if((getCurrentUserVO().getEmailAddress() == null && isEmailMandatory) || 
					(getCurrentUserVO().getEmailAddress() != null && getCurrentUserVO().isIsemailVerified() 
							&& !getCurrentUserVO().isPrimaryEmailUnique() && isUniqueEmailRequired  
							&& !isSessionAttributeExists(TrustBrokerWebAppConstants.USER_MIGRATED))){
				status = true;
			} else if(getCurrentUserVO().isMigratedUser() && getCurrentUserVO().getEmailAddress() != null 
					&& !getCurrentUserVO().isIsemailVerified() && isUniqueEmailRequired
					&& container.getUserService().isEmailExists(getCurrentUserVO().getEmailAddress())){
				status = true;
			}
		}
		
		return status;
	}
	
	/**
	 * This method is called from the widget home page to process relying party application redirect
	 */
	public void onWidgetPreinitialize() {
		
		RelyingPartyAppVO relyingPartyAppVO = null; 
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null && 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)!=null )
		{
			relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(
					(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			 
			 String relyingPartyTargetURL = getRelyingPartyRedirectionURL();
				relyingPartyTargetURL = constructRedirectUrl(relyingPartyTargetURL);
			 redirection(relyingPartyTargetURL, relyingPartyAppVO.getPartnerId());
		}
		
		return;		
	}
	
	/**
	 * This method is used to forward to email confirmation screen if the user primary email is not confirmed
	 * 
	 */
	private boolean checkPrimaryEmailConfirmationRequired(){
		
		/*String loginSessionParam = (String) getSessionAttribute(TrustBrokerWebAppConstants.USER_LOGIN_IND);
		removeSessionAttribute(TrustBrokerWebAppConstants.USER_LOGIN_IND);
		"true".equals(loginSessionParam) && */
		
		if (StringUtils.isNotBlank(getCurrentUserVO().getEmailAddress()) 
				&& !getCurrentUserVO().isIsemailVerified() && (TBUtil.isProdEnv() || isEmailConfirmationRequired())) {				
						
			VerifyCodesContext ctx = new VerifyCodesContext();
			
			if(getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_UPDATED_ON_STEPUP) != null || 
					getSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED) != null){
				ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
				removeSessionAttribute(TrustBrokerWebAppConstants.EMAIL_UPDATED_ON_STEPUP);
			}		
			
			ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			ctx.setHideUpdateButtons(true);
			ctx.setShowDeviceRegistration(false);
			ctx.setNextView(getWidgetHomeURIWithAlias());
			ctx.setUserVO(getCurrentUserVO());
			ctx.setVerifyCodePgDimension(VerifyCodesContext.PAGE_6X4_DIMENSION);
			getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);
			redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
			
			return true;
		}
		
		return false;
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String constructRedirectUrl(String targetUrl)
	{
		if (null != getSessionAttribute("showDOB")
				&& (Boolean) getSessionAttribute("showDOB")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "dobupdated",
					"y");
		}
		if (null != getSessionAttribute("showAddress")
				&& (Boolean) getSessionAttribute("showAddress")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"addressupdated", "y");
		}
		if (null != getSessionAttribute("showMobilePhone")
				&& (Boolean) getSessionAttribute("showMobilePhone")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"mobilephoneupdated", "y");
		}
		if (null != getSessionAttribute("ShowEmail")
				&& (Boolean) getSessionAttribute("ShowEmail")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "emailupdated",
					"y");
		}
		return targetUrl;
	}
	
	public String getHomePageUrl() {
		String homePageURI = "/secure/homew.jsf";
		String alias = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS);
		
		if(StringUtils.isBlank(alias)){
			alias = TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE;
		}
		HttpServletRequest request = getServletRequest();
		Enumeration<String> paramNames = request.getParameterNames();
		if(paramNames != null) {			
			String key = null;
			while(paramNames.hasMoreElements()) {
				key = paramNames.nextElement();
				homePageURI = HttpUtils.addParameterToURL(homePageURI, key, request.getParameter(key));
			}
		}				
		return homePageURI;
		
	}
	
	
	/**
	 * Continue after migration process.
	 */
	public void migrationSuccess(){
		removeSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED);
		redirectToView(getWidgetHomeURIWithAlias());
	}
}
