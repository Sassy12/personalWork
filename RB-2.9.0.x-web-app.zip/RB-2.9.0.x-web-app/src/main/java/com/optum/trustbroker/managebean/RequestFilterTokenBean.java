/*******************************************************************************
 * Copyright (c) 2012 Optum - All Rights Reserved.
 ******************************************************************************/
package com.optum.trustbroker.managebean;

import javax.annotation.PreDestroy;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@SessionScoped
@ManagedBean(name = "requestFilterTokenBean")
public class RequestFilterTokenBean {

	private String csrfId;
	
	public String getCsrfId() {
		return csrfId;
	}

	public void setCsrfId(String csrfId) {
		this.csrfId = csrfId;
	}
	
	@PreDestroy
    public void sessionDestroyed() {
		
    }
		
}