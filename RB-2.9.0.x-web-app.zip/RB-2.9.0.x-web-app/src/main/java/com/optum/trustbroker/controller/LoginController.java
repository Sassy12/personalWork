package com.optum.trustbroker.controller;

import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.LoginEmailVO;
import com.optum.trustbroker.controller.vo.LoginResponseVO;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.WebApplicationCommonUtilities;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RPAppDomainVO;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.ValidationException;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@Path(TBConstants.LOGIN_CONTROLLER_PATH)
public class LoginController extends BaseController {

    @Autowired
    private UserService userService;

    @Autowired
    private WebApplicationCommonUtilities webApplicationCommonUtilities;

    private static final BaseLogger LOGGER = new BaseLogger(LoginController.class);

    @GET
    @Path(value = "/init")
    @Produces(MediaType.APPLICATION_JSON)
    public LoginResponseVO init(@Context HttpServletRequest request, @Context HttpServletResponse response) {
        deleteSiteMinderResponseCookies(request, response);

        String errorMsg = null;
        String requestFailReason = request.getParameter("reason");

        LoginResponseVO loginResponse = new LoginResponseVO();
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();

        /* clean events from previous login */
        cleanEvents(ctx);

        String lockedUserID = ctx.getRequestAttribute(TrustBrokerWebAppConstants.SM_USERID);
        String smresponsecode = ctx.getRequestAttribute(TrustBrokerWebAppConstants.SM_RESPONSE_CODE);
        String smusrmsg = ctx.getRequestAttribute(TrustBrokerWebAppConstants.SM_USER_MSG);
        String requestRelyingAppIdParam = ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);

        ResourceBundle bundle = getBundle();

        //To allow local login
        if (TBUtil.isLocalEnv()) {
            loginResponse.setLocalEnv(true);
        }

        if (TrustBrokerWebAppConstants.REASON_PWD_LOCKED.equalsIgnoreCase(requestFailReason)
                || TrustBrokerWebAppConstants.REASON_RSA_LOCKED.equalsIgnoreCase(requestFailReason)) {

            if (StringUtils.isNotBlank(lockedUserID)) {

                loginResponse.setLockedUserID(lockedUserID);

                SecurityLoggingUtil.warn("User Login", SecurityEventType.E3_DISABLE, request, lockedUserID,
                        "Security Audit Event|CreateUserSession:FAILED| User session denied | Account Disabled, LoginController:init()",
                        SecurityEventResult.FAILURE, requestRelyingAppIdParam, SecuritySubEventType.E3_DISABLE_LDAP);
                String result = unlockUserAccount(lockedUserID);
                if (StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.ACCT_RECOVERY, result)) {
                    WebApplicationContextHolder.getContext().setWorkflowAttribute(
                            WorkflowConstants.WORKFLOW_UNLOCK_USER_ACCOUNT, WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME,
                            lockedUserID);

                    loginResponse.setRedirect(TrustBrokerWebAppConstants.ACCT_RECOVERY);
                    return loginResponse;
                } else {
                    loginResponse.setRedirect(TrustBrokerWebAppConstants.NO_RECOVERY);
                    WebApplicationContextHolder.getContext()
                            .setCurrentWorkflowId(WorkflowConstants.WORKFLOW_UNLOCK_USER_ACCOUNT);
                    return loginResponse;
                }
            }
        } else if (TrustBrokerWebAppConstants.REASON_SESSION_TIMEOUT_1.equalsIgnoreCase(requestFailReason)) {
            errorMsg = bundle.getString("sessionTimeOutLoginAgain");
        } else if (TrustBrokerWebAppConstants.REASON_SESSION_TIMEOUT_2.equalsIgnoreCase(requestFailReason)) {
            errorMsg = bundle.getString("sessionTimeOutTryAgain");
        }else if(TrustBrokerWebAppConstants.REASON_ACCOUNT_VERIFIED.equals(requestFailReason)){
        	
        	loginResponse.setSuccessMessage(bundle.getString("verifyLinkLoginRedirectMsg"));
        } else if (!"0".equals(smresponsecode)) {
            if ("2".equals(smresponsecode)
                    && TrustBrokerWebAppConstants.SM_LOGIN_FAILED_USR_MSG.equalsIgnoreCase(smusrmsg)) {

                if (StringUtils.isNotEmpty(lockedUserID)) {
                    UserVO userVO = userService.fetchUserProfile(lockedUserID, false, true).getUser();

                    if (!TrustBrokerConstants.AA_LOCK_STATUS.equals(userVO.getAaStatus())
                            && (CollectionUtils.isEmpty(userVO.getUserChallengeQuestions()))) {
                        loginResponse.setLockedUserID(lockedUserID);
                        ctx.setWorkflowAttribute(WorkflowConstants.WORKFLOW_SETUP_SECURITY_QUESTIONS,
                                WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME, lockedUserID);

                        //Check if account recovery option is available on profile or not.
                        String result = unlockUserAccount(lockedUserID);

                        if (StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.NO_RECOVERY, result)) {
                            loginResponse.setRedirect(TrustBrokerWebAppConstants.NO_RECOVERY);
                            return loginResponse;
                        } else {
                            loginResponse.setRedirect("sentauthorizationcodesqa");
                            return loginResponse;
                        }
                    }

                    errorMsg = bundle.getString("suspendMsg");

                    loginResponse.setLockedUserID(lockedUserID);
                    SecurityLoggingUtil.warn("User Login", SecurityEventType.E3_DISABLE, request, lockedUserID,
                            "Security Audit Event|CreateUserSession:FAILED| User session denied | Account Suspended, LoginController:init()",
                            SecurityEventResult.FAILURE, requestRelyingAppIdParam, SecuritySubEventType.E3_DISABLE_RSA);

                    String result = unlockUserAccount(lockedUserID);
                    ctx.setWorkflowAttribute(WorkflowConstants.WORKFLOW_UNLOCK_USER_ACCOUNT,
                            WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME, lockedUserID);
                    if (StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.ACCT_RECOVERY, result)) {
                        loginResponse.setRedirect(TrustBrokerWebAppConstants.ACCT_RECOVERY);
                        return loginResponse;
                    }
                    if (StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.NO_RECOVERY, result)) {
                        loginResponse.setRedirect(TrustBrokerWebAppConstants.NO_RECOVERY);
                        return loginResponse;
                    }
                }
            }else if ("1".equals(smresponsecode) || ("2".equals(smresponsecode)&& !TrustBrokerWebAppConstants.RSA_CANCLED_CLICK.equalsIgnoreCase(smusrmsg))) {

                errorMsg = bundle.getString("invalidCredentials");

                SecurityLoggingUtil.warn("User Login", SecurityEventType.E4, request,
                        lockedUserID != null ? lockedUserID : "",
                        "Security Audit Event|CreateUserSession:FAILED| User session denied | Incorrect username or password specified, LoginController:init()",
                        SecurityEventResult.FAILURE, requestRelyingAppIdParam, null);
            } else if ("3".equals(smresponsecode)) {
                errorMsg = bundle.getString("unAuthorizedError");
            }

        }
        loginResponse.setErrorMessage(errorMsg);

        processRelyingPartyInfo(requestRelyingAppIdParam, ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET),
                loginResponse);

        return loginResponse;
    }

    @POST
    @Path(value = "/checkEmail")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public LoginEmailVO checkEmail(LoginEmailVO loginEmailVO) {
        UserProfileServiceRequest userProfileServiceRequest = null;
        LoginEmailVO loginResponse = new LoginEmailVO();
        String emailId = loginEmailVO.getEmail();
        UserVO userVO = null;
        ResourceBundle bundle = getBundle();
        try {
            String uuid = userService.getUserUuid(emailId);
            if (StringUtils.isNotEmpty(uuid)) {
                loginResponse.setUsername(emailId);
            } else {
                if (TBUtil.validateEmailId(emailId)) {
                    try {
                        userProfileServiceRequest = new UserProfileServiceRequest();
                        userVO = new UserVO();
                        userVO.setEmailAddress(emailId);
                        userProfileServiceRequest.setUser(userVO);
                        loginResponse.setUsername(userService.getUserNameDetailByEmail(userProfileServiceRequest));
                    } catch (OperationFailedException exception) {
                        LOGGER.error(exception);
                        loginResponse.setUsername("");
                        if (TrustBrokerConstants.OPT_00A0012.equals(exception.getErrorMessage().getCode())) {
                            loginResponse.setErrorMsg(bundle.getString("duplicateAccountNextGen"));
                        } else {
                            loginResponse.setErrorMsg(bundle.getString("invalidCredentials"));
                        }

                        return loginResponse;
                    }
                } else {
                    loginResponse.setUsername(emailId);
                }
            }

        } catch (OperationFailedException exception) {
            LOGGER.error(exception);
            loginResponse.setUsername(emailId);
        } catch (ValidationException e) {
            LOGGER.error(e);
            loginResponse.setUsername(emailId);
        }
        
        return loginResponse;

    }

    @POST
    @Path(value = "/localLogin")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public LoginEmailVO doLocalLogin(LoginEmailVO loginEmailVO) {
    	 
    	 LoginEmailVO loginResponse = new LoginEmailVO();
         ResourceBundle bundle = getBundle();
         UserRetrievalServiceResponse userRetrievalResponse;
    	 
        if (!TBUtil.isLocalEnv()) {
        	 loginResponse.setErrorMsg(bundle.getString("unAuthorizedError"));
             return loginResponse;
        }
    	
      
        try {
            userRetrievalResponse = userService.fetchUserDetailsForSession(loginEmailVO.getUsername());
        } catch (OperationFailedException exception) {
            LOGGER.error("LoginBean::fetchUserProfile()::Failed to fetch profile " + loginEmailVO.getUsername(), exception);
            loginResponse.setErrorMsg(bundle.getString("invalidCredentials"));
            return loginResponse;
        }

        if (userRetrievalResponse != null && TrustBrokerConstants.SUCCESS_CODE_VALUE
                .equals(userRetrievalResponse.getExecutionStatus().getStatusCd())) {
            //Need to set the user into the Web Application Context
            WebApplicationContext ctx = WebApplicationContextHolder.getContext();
            ctx.setSessionAttribute(TrustBrokerWebAppConstants.USERNAME_LOCAL, loginEmailVO.getUsername());
        } else {
            LOGGER.info("LoginBean::fetchUserProfile()::ExecutionStatus" + TrustBrokerConstants.FAILURE_CODE_VALUE);
            loginResponse.setErrorMsg(bundle.getString("invalidCredentials"));
        }
        return loginResponse;
    }

    public String unlockUserAccount(String username) {

        UserVO userVO = null;
        try {
            userVO = userService.fetchUserProfile(username, false, true).getUser();
            String mobilePhone = null;
            boolean mobilePhoneVerified = false;
            if (StringUtils.isNotBlank(userVO.getPhoneNumber())) {
                mobilePhone = userVO.getPhoneNumber();
                mobilePhoneVerified = userVO.getIsPhoneVerified();
            }
            boolean userHasSecQuestions = false;
            if (!TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(userVO.getAaStatus())) {
                try {
                    UserChallengeQuestionServiceResponse userChallengeResp = userService.getChallengeQuestions(
                            userVO.getUuId(), TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
                    if (CollectionUtils.isNotEmpty(userChallengeResp.getUserChallengeQuestions())) {
                        userHasSecQuestions = true;
                    }
                } catch (OperationFailedException ofe) {
                    LOGGER.error("failure getting challenge questions", ofe);
                }
            }
            if ((StringUtils.isNotBlank(userVO.getEmailAddress()) && userVO.isIsemailVerified()
                    && userVO.isPrimaryEmailUnique())
                    || (StringUtils.isNotBlank(userVO.getSecEmailAddress()) && userVO.isSecEmailVerified()
                            && userVO.isSecEmailUnique())
                    || (StringUtils.isNotBlank(mobilePhone) && mobilePhoneVerified) || (userHasSecQuestions)) {
                return TrustBrokerWebAppConstants.ACCT_RECOVERY;
            } else {
                return TrustBrokerWebAppConstants.NO_RECOVERY;
            }

        } catch (OperationFailedException ofe) {
            LOGGER.error("Exception while fetching the user details for user unlock user account exception details", ofe);
            return null;
        }
    }

    public boolean isDomainValid(List<RPAppDomainVO> domains, String domainName) {
        return TBUtil.isDomainValid(domains, domainName);
    }

    private void processRelyingPartyInfo(String relyingAppId, String relyingPartyTargetURL, LoginResponseVO loginResponse) {
        RelyingPartyAppVO relyingPartyAppVO = webApplicationCommonUtilities.getRelyingPartyApplicationDetailsFromContext();

        if (relyingPartyAppVO != null) {
            loginResponse.setRelyingAppAlias(relyingPartyAppVO.getAlias());
            loginResponse.setRelyingAppId(relyingAppId);
            loginResponse.setTarget(relyingPartyTargetURL);

            if ("N".equalsIgnoreCase(relyingPartyAppVO.getShowRegistration())) {
                loginResponse.setShowRegistrationLink(false);
            }
        }
    }

    protected void deleteSiteMinderResponseCookies(HttpServletRequest request, HttpServletResponse response) {
        String host = request.getServerName();
        String domain = host.indexOf(".") >= 0 ? host.substring(host.indexOf(".")) : host;
        Cookie cookie;
        Cookie cookies[] = request.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i = i + 1) {
                String cookieName = cookies[i].getName();
                if (Arrays.asList(TrustBrokerWebAppConstants.SM_RESPONSE_CODE, TrustBrokerWebAppConstants.SM_USER_MSG,
                        TrustBrokerWebAppConstants.SM_USERID).contains(cookieName)) {
                    cookie = cookies[i];
                    cookie.setPath("/");
                    if (domain != null) {
                        cookie.setDomain(domain);
                    }

                    LOGGER.debug("host: " + host);
                    LOGGER.debug("cookie name: ", cookie.getName());
                    LOGGER.debug("cookie value: ", cookie.getValue());
                    LOGGER.debug("cookie path: ", cookie.getPath());
                    LOGGER.debug("cookie domain: ", cookie.getDomain());

                    cookie.setMaxAge(0);
                    response.addCookie(cookie);
                }
            }
        }
    }

    @Override
    public UserService getUserService() {
        return userService;
    }

    @Override
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @Override
    public WebApplicationCommonUtilities getWebApplicationCommonUtilities() {
        return webApplicationCommonUtilities;
    }

    @Override
    public void setWebApplicationCommonUtilities(WebApplicationCommonUtilities webApplicationCommonUtilities) {
        this.webApplicationCommonUtilities = webApplicationCommonUtilities;
    }

}
