package com.optum.trustbroker.managebean;

import java.io.Serializable;

public class UserStepUpContext implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String SESSION_NAME = "user-stepup-context";
	public static final String SESSION_NAME_IFRAME = "user-stepup-context-iframe";
	
	private boolean emailMandatory;
	private boolean emailUnique;
	private boolean dobRequired;
	private boolean secQuestionRequired;
	private boolean coppaRequired;//By default it is yes until configured to No by RP 
	
	private boolean showUserName;
	private boolean showPassword;
	private boolean showEmail;
	private boolean showDob;
	private boolean showSecQuestions;
	private boolean showYOB;
	
	//Flags for attributes already on the user profile 
	private boolean isUserEmailUnique;
	private boolean isUserProfileHasSecQuestions;
	
	//Operations performed on user attributes
	private boolean userNameUpdated;
	
	//iFrame related booleans
	private boolean infoPageDisplayed;
	private boolean credentialPageDisplayed;
	private boolean questionsPageDisplayed;
	
	public boolean isEmailMandatory() {
		return emailMandatory;
	}
	public void setEmailMandatory(boolean emailMandatory) {
		this.emailMandatory = emailMandatory;
	}
	public boolean isEmailUnique() {
		return emailUnique;
	}
	public void setEmailUnique(boolean emailUnique) {
		this.emailUnique = emailUnique;
	}
	public boolean isDobRequired() {
		return dobRequired;
	}
	public void setDobRequired(boolean dobRequired) {
		this.dobRequired = dobRequired;
	}
	public boolean isSecQuestionRequired() {
		return secQuestionRequired;
	}
	public void setSecQuestionRequired(boolean secQuestionRequired) {
		this.secQuestionRequired = secQuestionRequired;
	}
	public boolean isCoppaRequired() {
		return coppaRequired;
	}
	public void setCoppaRequired(boolean coppaRequired) {
		this.coppaRequired = coppaRequired;
	}
	public boolean isShowUserName() {
		return showUserName;
	}
	public void setShowUserName(boolean showUserName) {
		this.showUserName = showUserName;
	}
	public boolean isShowPassword() {
		return showPassword;
	}
	public void setShowPassword(boolean showPassword) {
		this.showPassword = showPassword;
	}
	public boolean isShowEmail() {
		return showEmail;
	}
	public void setShowEmail(boolean showEmail) {
		this.showEmail = showEmail;
	}
	public boolean isShowSecQuestions() {
		return showSecQuestions;
	}
	public void setShowSecQuestions(boolean showSecQuestions) {
		this.showSecQuestions = showSecQuestions;
	}
	public boolean isUserEmailUnique() {
		return isUserEmailUnique;
	}
	public void setUserEmailUnique(boolean isUserEmailUnique) {
		this.isUserEmailUnique = isUserEmailUnique;
	}
	public boolean isShowDob() {
		return showDob;
	}
	public void setShowDob(boolean showDob) {
		this.showDob = showDob;
	}
	public boolean isStepUpRequired(){
		return (showDob || showEmail || showSecQuestions); 
	}
	public boolean isUserProfileHasSecQuestions() {
		return isUserProfileHasSecQuestions;
	}
	public void setUserProfileHasSecQuestions(boolean isUserProfileHasSecQuestions) {
		this.isUserProfileHasSecQuestions = isUserProfileHasSecQuestions;
	}
	public boolean isDisplayPersonalInformationForStepUp(){
		return (coppaRequired || showDob || showEmail || showSecQuestions || showPassword || showUserName);
	}
	public boolean isUserNameUpdated() {
		return userNameUpdated;
	}
	public void setUserNameUpdated(boolean userNameUpdated) {
		this.userNameUpdated = userNameUpdated;
	}
	public boolean isInfoPageDisplayed() {
		return infoPageDisplayed;
	}
	public void setInfoPageDisplayed(boolean infoPageDisplayed) {
		this.infoPageDisplayed = infoPageDisplayed;
	}
	public boolean isCredentialPageDisplayed() {
		return credentialPageDisplayed;
	}
	public void setCredentialPageDisplayed(boolean credentialPageDisplayed) {
		this.credentialPageDisplayed = credentialPageDisplayed;
	}
	public boolean isQuestionsPageDisplayed() {
		return questionsPageDisplayed;
	}
	public void setQuestionsPageDisplayed(boolean questionsPageDisplayed) {
		this.questionsPageDisplayed = questionsPageDisplayed;
	}
	public boolean isMandatoryOrUnique(){
		return (emailMandatory || emailUnique);
	}
	public boolean isShowYOB() {
		return showYOB;
	}
	public void setShowYOB(boolean showYOB) {
		this.showYOB = showYOB;
	}
}
