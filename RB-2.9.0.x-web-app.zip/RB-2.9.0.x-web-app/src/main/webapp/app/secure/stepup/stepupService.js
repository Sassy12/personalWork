/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 */
'use strict';
angular.module('tbApp').service('StepupService',['$http', StepupService]);

function StepupService($http){
	
	this.validateEmail = function(postData){
		return $http.post('/tb/services/rest/userservice/validateemail', postData);
	};
	this.validateUserName = function(postData){
		return $http.post('/tb/services/rest/userservice/validateusername', postData);
	};
	this.createStepupContext = function(){
		   var promise = $http.get('/tb/services/secure/rest/stepup/createStepupContext');
		      promise.success(function(data) {
		        return data;
		      });
		      return promise;
	};
	this.stepupUser = function(postData){
		return $http.post('/tb/services/secure/rest/stepup/stepupUser', postData);
	};
}