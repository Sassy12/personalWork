//Global Variables

var unamerules_webpage = [      
      {
	'text' : '6-20 characters ',
	'regex' : /^.{6,20}$/i,
	'passval' : true
},{
	'text' : 'One letter ',
	'regex' : /[A-Z]/gi,
	'passval' : true
},{
	'text' : 'No spaces ',
	'regex' : /[ ]/g,
	'passval' : false
},{
	'text' : 'No special characters ',
	'regex' : /^[-A-Za-z0-9 ]*$/g,
	'passval' : true
}];

var unamerules = [ {
	'text' : 'Must be between 6 to 20 characters ',
	'regex' : /^.{6,20}$/i,
	'passval' : true
},{
	'text' : 'Have 1 alpha character ',
	'regex' : /[A-Z]/gi,
	'passval' : true
},{
	'text' : 'No spaces ',
	'regex' : /[ ]/g,
	'passval' : false
},{
	'text' : 'Only alphanumeric and hyphen ',
	'regex' : /^[-A-Za-z0-9 ]*$/g,
	'passval' : true
}];


var ariaHiddenToggle = function(e){
	e.stopPropagation();
    var elementId = $(this).parent('a').attr('aria-describedby');
    if(elementId) {
        //Need to add \\: for jquery
        var $target = $(elementId.replace(':', '\\:'));
        switch (e.type) {
            case 'mouseover':
                $target.attr('aria-hidden', false);
                break;
            case 'mouseout':
                $target.attr('aria-hidden', true);
                break;
        }
    }
};

var tooltipEscape = function(e){
	e.stopPropagation();
	if(e.which == 27){
		$(this).children('img').trigger('mouseout');
	}
};

// Use this function when you want to a proper aria-hidden and escape key behavior for an image w/ tooltip wrapped in an anchor
var tooltipAriaHiddenInvoke = function(formId,elementId){
	var id = '#' + formId + '\\:' + elementId, //the backslashes are to escape the : for jQuery
		$target = $(id);
	$target
		.on('mouseover', ariaHiddenToggle)
		.on('mouseout', ariaHiddenToggle)
		.parent('a').on('keyup', tooltipEscape);

};


function displayUserNameRules(e) {
	var userNameRulesPopUpId = document.getElementById("userRegistrationId:userNameRulesPopUp");
	var userNameValue = document.getElementById("userRegistrationId:userNameId").value;
	checkUserNameRules(userNameValue, userNameRulesPopUpId);
	if(e && e.which == 27){
		hideUserNameRules();
	}
}

var spanRuleText     = '<span class="spanTextUpper"> Your username must have: </span>';
var spanRuleFailText = '<img class="check pass" style="margin-top:-4px;margin-left:-4px;vertical-align:middle;" src="../images/white_icon.jpg" alt="" >';
var spanRulePassText = '<img class="check pass" src="../images/green_check_icon.jpg" style="vertical-align: middle;margin-top:-4px;margin-left:-4px;" alt="">';
var validTrue        = '<span class="oui-a11y-hidden"> Met </span></span> ';
var validFalse       = '<span class="oui-a11y-hidden"> not met </span></span> ';

var oldHtmlText;

function populateUserNameRules(){
	var userNameRulesPopUpId = document.getElementById("userRegistrationId:userNameRulesPopUp");
	var userNameValue = document.getElementById("userRegistrationId:userNameId").value;
	document.getElementById("userRegistrationId:userNameRulesPopUp").style.display = 'block';
	var htmlText = '<div class="oxnamevalidate" style="display: block;"> <div class="usernamesuggestion" > <ul role="presentation">';

	var self  = this, _count, _check, _checkx, _text;
	validname = true;
	htmlText += '<li  class="ruletext" style="margin-left:5px;padding-bottom:2px;"> Your username must have: </li>';
		
			for(_count = 0; _count < unamerules_webpage.length; _count++){		
				_text   = userNameValue;
				_checkx = (_text.match(unamerules_webpage[_count].regex) == null);
				_check  = (_checkx != unamerules_webpage[_count].passval);
			
				if(userNameValue == ""){
					htmlText +='<li id="rule' + _count + '">' + spanRuleFailText + '<span class="ruletext" style="margin-left:7px;">' + unamerules_webpage[_count].text + ' </span></li>';
				}
				else{
					htmlText +=  
						'<li id="rule' + _count + '">'
						+ ((_check == true) ? spanRulePassText : spanRuleFailText)
						+ '<span class="ruletext" style="margin-left:7px;">' + unamerules_webpage[_count].text + ' </span>'
						+ ((_check == true) ? validTrue : validFalse) + '</li>';
					
				}
			}


	htmlText += '</ul></div></div>';
	oldHtmlText = htmlText;
	userNameRulesPopUpId.innerHTML = htmlText;
}

function hideUserNameRules(){
	if(document.getElementById("userRegistrationId:userNameRulesPopUp").innerHTML != "")
		document.getElementById("userRegistrationId:userNameRulesPopUp").innerHTML = "";
	else
		setTimeout(function() {
			document.getElementById("userRegistrationId:userNameRulesPopUp").innerHTML = "";
		}, 200);
}



var curUserName = "";
function checkUserNameRules(userName, userNameRulesPopUpId){
	userNameValue="";
	if(curUserName == userName){
		//no check on same name
		return;
	} else {
		curUserName = userName;
	}
	if(document.getElementById(userName + ":" +"userNameId")){
		userNameValue = document.getElementById(userName + ":" +"userNameId").value;
	} else if(document.getElementById(userName + ":" +"userNameIdAlt") != null){
		userNameValue = document.getElementById(userName + ":" +"userNameIdAlt").value;
	}
	var htmlText = '<div class="oxnamevalidate" style="display: block;"><div class="usernamesuggestion" > <ul role="presentation">';
	var self     = this, _count, _check, _checkx, _text;
	validname    = true;
	htmlText += '<li role="presentation" class="ruletext" style="margin-left:5px;padding-bottom:2px;"> Your username must have: </li>';
		
		 
			for(_count = 0; _count < unamerules_webpage.length; _count++){		
				_text   = userName;
				_checkx = (_text.match(unamerules_webpage[_count].regex) == null);
				_check  = (_checkx != unamerules_webpage[_count].passval);
				
				if(userName == ""){
					htmlText +='<li id="rule' + _count + '">' + spanRuleFailText + '<span class="ruletext" style="margin-left:7px;">' + unamerules_webpage[_count].text + ' </span></li>';
				}
				else{
				htmlText += '<li id="rule' + _count + '">'
					+ ((_check == true) ? spanRulePassText : spanRuleFailText)
					+ '<span class="ruletext" style="margin-left:7px;">' + unamerules_webpage[_count].text + '</span>'
					+ ((_check == true) ? validTrue : validFalse) + '</li>'; }
			}
			
			

	htmlText += '</ul></div></div>';
	if(oldHtmlText!=htmlText){
	userNameRulesPopUpId.innerHTML = htmlText;
	oldHtmlText=htmlText;
	}
}

function populateUserNameRulesStepUp() {
	var userNameValue = "";
	var userNameRulesPopUpId = document.getElementById("userStepupProfileId:userNameRulesPopUp");
	
	if(document.getElementById("userStepupProfileId:userNameId")){
		userNameValue = document.getElementById("userStepupProfileId:userNameId").value;
	} else if(document.getElementById("userStepupProfileId:userNameIdAlt") != null){
		userNameValue = document.getElementById("userStepupProfileId:userNameIdAlt").value;
	}
	
	document.getElementById("userStepupProfileId:userNameRulesPopUp").style.display = 'block';
	
	var htmlText = '<div class="oxnamevalidate" style="display: block;"> <div class="usernamesuggestion" > <ul role="presentation">';
	htmlText += '<li <span class="ruletext" style="margin-left:5px;padding-bottom:2px;"> Your username must have: </span></li>'
	var self = this, _count, _check, _checkx, _text;
	validname = true;
	
	
	
	for (_count = 0; _count < unamerules_webpage.length; _count++) {
		_text = userNameValue;
		_checkx = (_text.match(unamerules_webpage[_count].regex) == null);
		_check = (_checkx != unamerules_webpage[_count].passval);
		

		if(userNameValue == ""){
			htmlText +='<li id="rule' + _count + '">' + spanRuleFailText + '<span class="ruletext" style="margin-left:7px;";>' + unamerules_webpage[_count].text + ' </span></li>'
		}
		else{
		htmlText += '<li id="rule' + _count + '">' 
				+ ((_check == true) ? spanRulePassText : spanRuleFailText) 
				+ '<span class="ruletext" style="margin-left:7px;">' + unamerules_webpage[_count].text
				+ '</span>' + ((_check == true) ? validTrue : validFalse) + '</li>'
		
	} } 
	htmlText += '</ul></div></div>';
	oldHtmlText = htmlText;
	userNameRulesPopUpId.innerHTML = htmlText;
}



function populateUserNameRulesIframe() {
	var userNameRulesPopUpId = document
			.getElementById("userRegistrationId:userNameRulesPopUp");
	var userNameValue = document
			.getElementById("userRegistrationId:userNameId").value;
	document.getElementById("userRegistrationId:userNameRulesPopUp").style.display = 'block';
	var htmlText = '<div class="oxnamevalidate" style="display: block;"> <div style="border:1px solid black;margin-top: 1px;width: 202px;" > <ul>';
	var self = this, _count, _check, _checkx, _text;
	validname = true;
	
	
	for (_count = 0; _count < unamerules.length; _count++) {
		_text = userNameValue;
		_checkx = (_text.match(unamerules[_count].regex) == null);
		_check = (_checkx != unamerules[_count].passval);
		htmlText += '<li id="rule' + _count + '">' + '<span class="check '
				+ ((_check == true) ? 'pass' : 'fail') + '"></span>'
				+ '<span class="ruletext">' + unamerules[_count].text
				+ '</span>' + '</li>'
	}
	htmlText += '</ul></div></div>';
	userNameRulesPopUpId.innerHTML = htmlText;
}

function displayUserNameRulesIframe() {
	var userNameRulesPopUpId = document
			.getElementById("userRegistrationId:userNameRulesPopUp");
	var userNameValue = document
			.getElementById("userRegistrationId:userNameId").value;
	var cell = userNameRulesPopUpId.parentNode;
	checkUserNameRulesIframe(userNameValue, userNameRulesPopUpId);
}

function checkUserNameRulesIframe(userName, userNameRulesPopUpId) {
	var htmlText = '<div class="oxnamevalidate" style="display: block;"><div style="border:1px solid black;margin-top: 1px;width: 202px;" > <ul>';
	var self = this, _count, _check, _checkx, _text;
	validname = true;
	for (_count = 0; _count < unamerules.length; _count++) {
		_text = userName;
		_checkx = (_text.match(unamerules[_count].regex) == null);
		_check = (_checkx != unamerules[_count].passval);
		htmlText += '<li id="rule' + _count + '">' + '<span class="check '
				+ ((_check == true) ? 'pass' : 'fail') + '"></span>'
				+ '<span class="ruletext">' + unamerules[_count].text
				+ '</span>' + '</li>'
	}
	htmlText += '</ul></div></div>';
	userNameRulesPopUpId.innerHTML = htmlText;
}

function onLoginPageLoad() {
	deleteCookies();

}

function deleteCookies() {
	var host = window.location.hostname;
    var domain = host.substring(host.indexOf('.'));
    
}

function trim(myString)     
{     
    return myString.replace(/^s+/g,'').replace(/s+$/g,'');     
}

function disableLoginSubmitButton() {
	var submitButtonHidden =  document.getElementById("submitButtonHidden");
	var submitButton = document.getElementById("submitButton");
	if(submitButtonHidden !=null)
		{
		submitButtonHidden.disabled = true;
		submitButtonHidden.className='ux-btn-disabled  ux-width-7t';
		}
	if(submitButton !=null)
		{
		submitButton.disabled = true;
		submitButton.className='ux-btn-disabled  ux-width-7t';
		}
	var uname = document.getElementById("USER").value;
	var pwd = document.getElementById("PASSWORD").value;
	var email = document.getElementById("EMAIL").value;
	var trimmedpwd = trim(pwd);
	var trimmeduname = trim(uname);
	var trimmedemail = trim(email);
	if((trimmeduname != ''|| trimmedemail !='') && trimmedpwd!='') {
		if(submitButtonHidden !=null)
			{
			submitButtonHidden.disabled = false;
			submitButtonHidden.className='ux-btn-default-action  ux-width-7t';
			}
		if(submitButton !=null)
			{
			submitButton.disabled = false;
			submitButton.className='ux-btn-default-action  ux-width-7t';
			}
		}
}

/* ID Proofing Scripts */
function enableKBIButton() {
	var answerTest = document.getElementById('answerTest').innerHTML;
	var continueBtn = document.getElementById('processQuizBtnId');
	if (answerTest.indexOf("true") != -1) {
		continueBtn.disabled = true;
		continueBtn.className='ux-btn-disabled  ux-width-7t';
	} else {
		continueBtn.disabled = false;
		continueBtn.className='ux-btn-default-action  ux-width-7t';
	}
}
function onKBIPageLoad() {
	var continueBtn = document.getElementById('processQuizBtnId');
	continueBtn.disabled = true;
	continueBtn.className='ux-btn-disabled  ux-width-7t';
}


function allowNumericOnly(evt) {
	var e = evt || window.event;
    var key = e.keyCode || e.which;
    if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
    key >= 48 && key <= 57 ||
    key == 8 || key == 9 || key == 13) {
    }
    else {
        e.returnValue = false;
        if (e.preventDefault) e.preventDefault();
    }
	}

function jumpToNextField(cur,len,nextElement,formID) {
	if (cur.value.length == len) {
		cur.form.elements[formID + ':' +nextElement].focus();
	}
	}

function checkIsEmpty(formId, componentId, errorMsgID, boxWidth) {
	if (document.getElementById(formId + ':' + componentId).value != "") {
		document.getElementById(formId + ':' + componentId)
				.getAttributeNode('class').value = "componentDefaultColor" + " " + boxWidth;
		var errorMsg = document.getElementById(formId + ':' + errorMsgID);
		if(errorMsg != null) errorMsg.innerHTML = '';
	}
}

function setValidity(inputid, spanid, formId) {
	setTimeout(function() {
		setFieldValidity(inputid, spanid, formId)
	}, 500);
}

function setFieldValidity(inputid, spanid, formId) {
	
	if(formId != null){
		spanid = formId + ":" + spanid;  
		inputid = formId + ":" + inputid;  
	}
	
	var span = document.getElementById(spanid);
	var target = document.getElementById(inputid);
	
	if (span == null || target == null) {
		console.log("span or target was null")
	} else {
		if (span.innerHTML.length > 1) {
			target.setAttribute('aria-invalid', true);
			appendDescribedByAttribute(inputid, spanid);
		} else {
			target.setAttribute('aria-invalid', false);
			removeDescribedByAttribute(inputid, spanid);
		}
	}
}

function appendDescribedByAttribute(attrId, descrById){
	attrId = attrId.replace(":", "\\:");
	var attrVal = $("#" + attrId).attr("aria-describedby");
	if(attrVal == undefined) attrVal = descrById;
	else if(attrVal.indexOf(descrById) == -1) {
		attrVal = attrVal + " " + descrById;
	}
	
	$("#" + attrId).attr("aria-describedby", attrVal);
}

function removeDescribedByAttribute(attrId, attrIdValue){
	attrId = attrId.replace(":", "\\:");
	var attrVal = $("#" + attrId).attr("aria-describedby");
	
	if(attrVal != undefined && attrVal != null){
		attrVal = attrVal.replace(attrIdValue, "").trim();
		if(attrVal.length == 0) $("#" + attrId).removeAttr("aria-describedby");
		else $("#" + attrId).attr("aria-describedby", attrVal);
	}
}

function setAriaAttributesPostFormSubmit(FIELDS, formId, formErrorMsgId, doNotSetAlert){
	
	if(formId != null) formErrorMsgId = formId + ":" + formErrorMsgId;
	
	//Add tabindex to every error field always.
	for (i=FIELDS.length-1;i>=0;i--) {
		if(formId != null)  $("#" + formId + "\\:" + FIELDS[i].msg).attr("tabindex", "-1");
		else $("#" + FIELDS[i].msg).attr("tabindex", "-1");
	}
	
	if(document.getElementById(formErrorMsgId) != null){
		
		for (i=FIELDS.length-1;i>=0;i--) {                         	
	        if (document.getElementById(formId + ":" + FIELDS[i].msg) != null  && document.getElementById(formId + ":" + FIELDS[i].msg).innerHTML!="" ) {                        	
	            document.getElementById(formId + ":" + FIELDS[i].fld).focus();
	            $("#" + formId + "\\:" + FIELDS[i].fld).attr("aria-invalid","true");
	            appendDescribedByAttribute(formId + ":" + FIELDS[i].fld, formId + ":" + FIELDS[i].msg);
	        }
	    }
	    //read form level alert message
	    var inputfield = document.getElementById(formErrorMsgId);
	    
	    if(inputfield != null && inputfield.innerHTML.length > 1 && !doNotSetAlert) {			                        
	          setTimeout( function(){
	        	  addRoleAlert(formErrorMsgId);
	          }, 350);
	    }
	}
}

function addRoleAlert(formErrorMsgId){
	formErrorMsgId = '#' + formErrorMsgId.replace(':', '\\:');
    $(formErrorMsgId).css("display", "none");
    $(formErrorMsgId).parent().attr("role","alert");
    $(formErrorMsgId).delay(200).css("display", "block");
}

function hasAttributeValue(currentAttrVal,valToTestFor) {
	if(currentAttrVal && valToTestFor) {
		return !!currentAttrVal.match(new RegExp('(\\s|^)' + valToTestFor + '(\\s|$)'));
	}
	else{
		return false;
	}
}

function addAttributeValue(elementId, attributeName, valueToAdd) {
    //Doing this so the elementId doesn't have to be delimited by \\
    var rawElement = document.getElementById(elementId);
	var ele = $(rawElement);
	if(ele.length > 0) {
		var eleAttr = ele.attr(attributeName);
		if (!hasAttributeValue(eleAttr, valueToAdd)) {
			var attrValue = ele.attr(attributeName)? ele.attr(attributeName) + " " + valueToAdd: valueToAdd;
			ele.attr(attributeName, attrValue.trim());
		}
	}
}

function removeAttributeValue(elementId,attributeName, valueToRemove) {
    //Doing this so the elementId doesn't have to be delimited by \\
    var rawElement = document.getElementById(elementId);
	var ele = $(rawElement);
	if(ele.length > 0){
		var eleAttr = ele.attr(attributeName);
		if (eleAttr) {
			if (hasAttributeValue(ele.attr(attributeName), valueToRemove)) {
				var reg = new RegExp('(\\s|^)' + valueToRemove + '(\\s|$)');
				if(attributeName.indexOf('aria-describedby') != -1){
					removeDescribedByAttribute(elementId, valueToRemove);
				} else{
					ele.attr(attributeName, ele.attr(attributeName).replace(reg, ' ').trim());
					removeAttributeValue(elementId,attributeName, valueToRemove)
				}
			}
		}
	}
}