package com.optum.trustbroker.controller.vo;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ManageProfileVO extends ResponseVO {

    private ProfileVO profile;

    private List<LabelValueVO> states;

    private RpAppVO rpContext;

    private SecurityQuestionVO securityContext;

    private boolean securityQuestionsReq;

    private boolean secEmailEnabled;

    private boolean mobileEnabled;

    private List<String> modifiedFields;

    public ProfileVO getProfile() {
        return profile;
    }

    public void setProfile(ProfileVO profile) {
        this.profile = profile;
    }

    public List<LabelValueVO> getStates() {
        return states;
    }

    public void setStates(List<LabelValueVO> states) {
        this.states = states;
    }

    public RpAppVO getRpContext() {
        return rpContext;
    }

    public void setRpContext(RpAppVO rpContext) {
        this.rpContext = rpContext;
    }

    public SecurityQuestionVO getSecurityContext() {
        return securityContext;
    }

    public void setSecurityContext(SecurityQuestionVO securityContext) {
        this.securityContext = securityContext;
    }

    public boolean isSecurityQuestionsReq() {
        return securityQuestionsReq;
    }

    public void setSecurityQuestionsReq(boolean securityQuestionsReq) {
        this.securityQuestionsReq = securityQuestionsReq;
    }

    public boolean isSecEmailEnabled() {
        return secEmailEnabled;
    }

    public void setSecEmailEnabled(boolean secEmailEnabled) {
        this.secEmailEnabled = secEmailEnabled;
    }

    public boolean isMobileEnabled() {
        return mobileEnabled;
    }

    public void setMobileEnabled(boolean mobileEnabled) {
        this.mobileEnabled = mobileEnabled;
    }

    public List<String> getModifiedFields() {
        return modifiedFields;
    }

    public void setModifiedFields(List<String> modifiedFields) {
        this.modifiedFields = modifiedFields;
    }
}
