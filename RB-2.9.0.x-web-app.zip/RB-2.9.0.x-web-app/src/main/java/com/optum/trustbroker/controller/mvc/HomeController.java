/*
 * Copyright (C) 2016 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.controller.mvc;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.optum.trustbroker.analytics.AnalyticsUtils;
import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.StepupContextVO;
import com.optum.trustbroker.domain.UserRelyingPartyRelation;
import com.optum.trustbroker.enums.PreferenceType;
import com.optum.trustbroker.events.impl.UserSuccessfulSignInEvent;
import com.optum.trustbroker.service.EventPublisherService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.service.UserTagService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.WebApplicationCommonUtilities;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.TagVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

/**
 * A controller bean that implements the logic to resolve the next view based upon
 * relying party configuration and user profile attributes. It contains the key logic
 * to drive next flow post login.
 *
 * @author Sachin Kumar
 * @version 1.0
 */

@Controller
@RequestMapping("/")
public class HomeController {
	
	public static final String COPPA_REQD_NO_IND ="N";
	BaseLogger logger = new BaseLogger(HomeController.class);
	protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserTagService userTagService;
	
	@Autowired
	private EventPublisherService eventPublisherService;
	
	@Autowired
	private WebApplicationCommonUtilities webApplicationCommonUtilities;
	

	@Autowired
	private AnalyticsUtils analyticsUtils;
	
	private static String errorPageView =  "/app/index.html#/errorPage";
	private static String errorPageViewWithLogout = "/app/index.html?LOGOUT=TRUE#/errorPage?";
	private static String stepupView = "/app/secure/home.html#/stepup";
	private static String userConsentView = "/app/secure/home.html#consent";
	private static String migratedInfoView = "/app/secure/home.html#/migrationsuccess";
	private static String manageProfileView = "/app/secure/home.html#/profileinfo";
	private static String confirmEmailView = "/app/index.html#/confirmEmailAddress";
	private static String idverificationView = "/app/secure/home.html#lexisNexis";
	private static String verifyRecoveryOptionView = "/app/secure/home.html#/verifyRecoveryOptions";
	
	private final int MIN_AGE_LIMIT = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userMinAgeLimit"));
	
	@RequestMapping(value = "/app/secure/home.do", method = RequestMethod.GET)
    public void resolveNextWorkflow(@Context HttpServletRequest request, @Context HttpServletResponse response) {
		
    	boolean isUserMigrated = false; 
    	boolean isCoppaRequired = true; //COPPA is required by default until turned off for an application
    	WebApplicationContext ctx = WebApplicationContextHolder.getContext();
    	
    	UserVO userVO = webApplicationCommonUtilities.getCurrentUserDetailsFromWebApplicationContext();
    	RelyingPartyAppVO relyingPartyAppVO = webApplicationCommonUtilities.getRelyingPartyApplicationDetailsFromContext();
    	
    	//If user is not available then redirected to error page and return control from here.
    	if(userVO == null) {
    		webApplicationCommonUtilities.redirectToErrorPage(response, errorPageView);
    		return;
    	} else if(ctx.getSessionAttribute(TrustBrokerWebAppConstants.USER_SIGNIN_EVENT) == null){
    		
    		//raise an event to indicate that a successful login has occurred for SSO broker.
    		this.getEventPublisherService().publish(new UserSuccessfulSignInEvent(this, userVO));
    		ctx.setSessionAttribute(TrustBrokerWebAppConstants.USER_SIGNIN_EVENT, "true");
    		
    		//Post data to analytics on successful login.
    		postSuccessfullAuthenticationEventAnalytics(request);

			if(userVO.getPhoneNumber() != null && !userVO.getIsPhoneVerified()){
				logger.debug("updating signin count for mobile");
				userService.updateSigninCount(userVO.getUuId(), PreferenceType.MOBILE);
			}

			if(userVO.getSecEmailAddress() != null && !userVO.isSecEmailVerified()){

				boolean emailShared = userService.isEmailExistsWithOtherUser(userVO.getSecEmailAddress(),userVO.getUserName());
				if(!emailShared){
					logger.debug("updating signin count for email");
					userService.updateSigninCount(userVO.getUuId(), PreferenceType.SECONDARY_EMAIL);
				}
			}

    		//Log a successful IRM login event
    		SecurityLoggingUtil.info("User Login", SecurityEventType.E1_CREATE, request, userVO.getUserName(),
					"Security Audit Event|CreateUserSession:SUCCESS | User has established session, HomeController:resolveNextWorkflow()", 
					SecurityEventResult.SUCCESS, relyingPartyAppVO != null ? relyingPartyAppVO.getApplicationId() : null, null);
    	}
    	
    	//Check if user is having user aware flag as false, redirect user to RP without any processing
		if(!userVO.isUserAwarenessFlag() && relyingPartyAppVO != null) {
			boolean status = webApplicationCommonUtilities.redirectUserBackToRelyingPartyApplication(userVO, request, response);
			if(!status) webApplicationCommonUtilities.redirectToErrorPage(response, errorPageView); 
			return;
		}
		
		if(request.getParameter(TBConstants.MANAGE_OID_PARAM) != null){
    		redirectToAnotherView(response, manageProfileView);
    		return;
    	}
		
		//Check if user is migrated already
		if(ctx.getSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED) != null){
			isUserMigrated = Boolean.parseBoolean(WebApplicationContextHolder.getContext()
					.getSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED));
		}
    			
    	// Update the invitation with user details if user registered through invitation process, 
		// or link with invitation if already registered
		webApplicationCommonUtilities.updateUserInvitaionIfAvailableWithinContext(userVO);
		
		//Check if COPPA processing required as per RP configuration
		if(relyingPartyAppVO != null && COPPA_REQD_NO_IND.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
			isCoppaRequired = false;
		}else{
			//Block user if his DOB is less than minimum coppa age. Send to error page and invalidate the session
			if(userVO.getDob()!=null && DateUtil.validateAge(userVO.getDob(), MIN_AGE_LIMIT)){
				webApplicationCommonUtilities.redirectToCoppaErrorPage(response, errorPageViewWithLogout);
	    		return;
			}
		}
		
		//Add application access if consent not required
		if(relyingPartyAppVO != null && !TrustBrokerConstants.SHOW_CONSENT_FORM_YES.equalsIgnoreCase(relyingPartyAppVO.getShowConsentForm())){
			addApplicationAccessToUserProfie(relyingPartyAppVO, userVO);
		}
		
		//Step 1 - Check if migrated flag is on the user profile.
		if(userVO.isMigratedUser()){
			//redirect to migration flow.
			redirectToAnotherView(response, stepupView);
			return;
		}
		
		//Step 2 - Check if primary email verification required for non migrated user, as user needs to be verified first always
		if(!isUserMigrated && webApplicationCommonUtilities.checkIfPrimaryEmailConfirmationRequiredForUser(userVO, 
				relyingPartyAppVO)){
			ctx.setCurrentWorkflowId(WorkflowConstants.EMAIL_CONFIRMATION_POST_LOGIN);
			redirectToAnotherView(response, confirmEmailView);
			return;
		}
		
		//Step 3 - Check if step up required for non-migrated user
		StepupContextVO context = webApplicationCommonUtilities.getUserStepUpcontext(userVO, relyingPartyAppVO, 
				isCoppaRequired, isUserMigrated);
		if(context.isStepUpRequired()){
			//Redirect to step up page
			redirectToAnotherView(response, stepupView);
			return;
		}
		
		/*
		*  Step 4 - Check if verification required for mobile or secondary email
		*  Prompt the user to verify mobile/secondary email if they're not verified already.
		*  Skip this step if user is already prompted for verification in current session and add skip event to cookies
		*/

		if (ctx.getSessionAttribute(TrustBrokerWebAppConstants.SKIP_RECOVERY_EVENT) == null) {
			logger.debug("recovery event is not skipped. checking for recovery options");
			if (webApplicationCommonUtilities.getRecoveryOptionToVerify(userVO) != null) {
				//Redirect user to verify recovery options flow
				redirectToAnotherView(response, verifyRecoveryOptionView);
				return;
			}
		}

		//Step 5- Check if an email confirmation required for a migrated user as account recovery will take precedence in step - 4. 
		if(webApplicationCommonUtilities.checkIfPrimaryEmailConfirmationRequiredForUser(userVO, relyingPartyAppVO)) {
			ctx.setCurrentWorkflowId(WorkflowConstants.EMAIL_CONFIRMATION_POST_LOGIN);
			redirectToAnotherView(response, confirmEmailView);
			return;
		}
		
		//Step 6 - Process user tag information
		if(relyingPartyAppVO!= null && !checkIfUserTagAssociationRquired(relyingPartyAppVO, userVO)) {
			redirectToAnotherView(response, idverificationView);
			return;
		}
		
		//Step 7 - In stand alone case where relying party context is not available then display the migration success screen
		if(isUserMigrated) {
			//Redirect user to migration success screen and remove the attribute
			ctx.removeSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED);
			redirectToAnotherView(response, migratedInfoView);
			return;
		}
		
		//Step 8 - Check if user consent required
		if(checkIfUserConsentRequired(relyingPartyAppVO, userVO)){
			redirectToAnotherView(response, userConsentView);
			return;
		}
		
		//Finally redirect back to relying party application if context exist.
		if(relyingPartyAppVO != null) {
			boolean status = webApplicationCommonUtilities.redirectUserBackToRelyingPartyApplication(userVO, request, response);
			if(!status) webApplicationCommonUtilities.redirectToErrorPage(response, errorPageView); 
			return;
		}
		
		//If none of the above case then by default update profile needs to be displayed for stand alone
		redirectToAnotherView(response, manageProfileView);
    }
	
	/**
	 * Redirect to another view.
	 * 
	 * @param response HTTP response object.
	 * 
	 * @return
	 */
	private boolean redirectToAnotherView(HttpServletResponse response, String viewUrl){
		try{
			response.sendRedirect(viewUrl);
			return true;
		}catch(IOException ioEx){
			logger.error("Error while redirectingt internally", ioEx);
		}
		return false;
	}
	
	/**
	 * Add application access to user profile if not present, in case of failure redirect to an error page.
	 * @param relyingPartyAppVO
	 * @param userVO
	 * @return
	 */
	private boolean addApplicationAccessToUserProfie(RelyingPartyAppVO relyingPartyAppVO, UserVO userVO) {
		boolean status = false;
		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(userVO);
		try {
			//Adding application access
			this.getUserService().checkAddApplicationAccess(userProfileServiceRequest, relyingPartyAppVO);
			
			//Check user relying party relation and if not available then add it.
			UserRelyingPartyRelation userRelyingPartyRelation = getUserService().getAssociationBetweenUserAndRelyingApp(
					userVO.getUuId(), relyingPartyAppVO.getApplicationId());
			
			if (userRelyingPartyRelation == null ) {
				this.getUserService().addUserRelyingPartyRelation(userProfileServiceRequest, relyingPartyAppVO);
			}
			
			status = true;
		} catch (OperationFailedException ofe) {
			logger.error("Application access for user {} with relying party {} failed - {}",
					new String[] { userVO.getUserName(), relyingPartyAppVO.getApplicationName(),
							TrustbrokerWebAppUtil.getUidFromError(ofe) }, ofe);
		}
		
		return status;
	}
	
	
	/**
	 * Check if tag association required for user according to relying party configured tags.
	 * 
	 * @param relyingPartyAppVO relying party application object.
	 * @param userVO user value object.
	 * @return true if tagging is required otherwise false.
	 */
	private boolean checkIfUserTagAssociationRquired(RelyingPartyAppVO relyingPartyAppVO, UserVO userVO){
		List<TagVO> tagVOList= relyingPartyAppVO.getTags();
		Collections.sort(tagVOList);
		boolean isUserTagAssociatedWithTag = true;
		String tagName = null;
		for(TagVO tagVO: tagVOList) {
			
			if(tagVO.getVerifyAtSignIn()) {
				//TO-Do Add the qualifying tag information in session
				try {
					tagName = tagVO.getName();
					UserTagServiceResponse resp =  getUserTagService().queryAllUserTag(buildUserTagServiceRequest(userVO.getUuId(), null));
					
					if(TrustbrokerWebAppUtil.checkResponseStatus(resp)) {
						isUserTagAssociatedWithTag = isTagAlreadyExists(resp.getTagVOList(), tagName);										
					}
				} catch (OperationFailedException ope) {
					//Add error to session and redirect to error page
					return false;
				}
			} else {
				// Skip id proofing process
				isUserTagAssociatedWithTag = true;
			}
		}
		return isUserTagAssociatedWithTag;
	}
	
	/**
	 * Build the user tag service request object.
	 * 
	 * @param uuid user uuid string.
	 * @param tagName tag name.
	 * @return
	 */
	private UserTagServiceRequest buildUserTagServiceRequest(String uuid, String tagName) {
		UserTagServiceRequest userTagServiceRequest = new UserTagServiceRequest();
		if(null != tagName) userTagServiceRequest.setTagName(tagName);
		UserVO userVO = new UserVO();
		userVO.setUuId(uuid);
		userTagServiceRequest.setUser(userVO);
		return userTagServiceRequest;
	}
	
	/**
	 * Check if tag already exist on user profile
	 * 
	 * @param userTags List of existing user tags on the profile
	 * @param tagName tag name 
	 * @return
	 */
	private boolean isTagAlreadyExists(List<TagVO> userTags, String tagName) {
		boolean tagExists = false;
		if (tagName != null && userTags != null && userTags.size() > 0) {
			Iterator<TagVO> userTagsItr = userTags.iterator();
			TagVO userTag = null;
			while(userTagsItr.hasNext()) {
				userTag = userTagsItr.next();
				if(userTag.getName() != null && userTag.getName().equalsIgnoreCase(tagName)) {
					tagExists = true;
					return tagExists;
				}
			}
		}
		return tagExists;
	}
	
	/**
	 * Check if user consent required 
	 * @param relyingPartyAppVO
	 * @param userVO
	 * @return
	 */
	private boolean checkIfUserConsentRequired(RelyingPartyAppVO relyingPartyAppVO, UserVO userVO){
		
		if(relyingPartyAppVO == null) return false;
		
		//Check user relying party relation and if not available then add it.
		UserRelyingPartyRelation userRelyingPartyRelation = getUserService().getAssociationBetweenUserAndRelyingApp(
				userVO.getUuId(), relyingPartyAppVO.getApplicationId());
		
		if(null == userRelyingPartyRelation || TrustBrokerConstants.USER_CONSENT_NO.equalsIgnoreCase(userRelyingPartyRelation.getUserConsent())) {
			if(TrustBrokerConstants.SHOW_CONSENT_FORM_YES.equalsIgnoreCase(relyingPartyAppVO.getShowConsentForm())) 
				return true;
		}
		
		return false;
	}
	
	/*
	 * Post successful authentication event data to analytics server
	 */
	public void postSuccessfullAuthenticationEventAnalytics(HttpServletRequest request){
		Map<String, String> postEventData = new HashMap<String, String>();
		RelyingPartyAppVO relyingPartyAppVO = webApplicationCommonUtilities.getRelyingPartyApplicationDetailsFromContext();
		String rpAppId = relyingPartyAppVO !=null ? relyingPartyAppVO.getApplicationId() : tbResources.getString("TB_APP_ID");
		postEventData.put(TrustBrokerConstants.EVAR_4, "OptumID:" + rpAppId);
		postEventData.put(TrustBrokerConstants.PAGE_NAME, "Home");
		postEventData.put(TrustBrokerConstants.EVENTS_TAG, TrustBrokerConstants.EVENT_11);
		try {
		analyticsUtils.postAnalyticsDataRequest(getVidCookieValue(request), postEventData);
		} catch (IOException ioe) {
			logger.error("Error while posting analytics: " + ioe);
		}
	}
	private String getVidCookieValue(HttpServletRequest request){
		Cookie cookies[] = request.getCookies();
		String visitorIDValue = "";
				
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i=i+1) {
				if (TrustBrokerWebAppConstants.VISITOR_ID.equals(cookies[i].getName())){
					if(cookies[i].getValue().contains(TrustBrokerWebAppConstants.MCMID)){
						//DACO team provided cookie splitting range.
						int index=cookies[i].getValue().indexOf(TrustBrokerWebAppConstants.MCMID);
						visitorIDValue=cookies[i].getValue().substring(index+8, index+46);
						break;
					}
				}
			}
		}
		
		return visitorIDValue;
	}
	public EventPublisherService getEventPublisherService() {
		return eventPublisherService;
	}

	public void setEventPublisherService(EventPublisherService eventPublisherService) {
		this.eventPublisherService = eventPublisherService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public UserTagService getUserTagService() {
		return userTagService;
	}

	public void setUserTagService(UserTagService userTagService) {
		this.userTagService = userTagService;
	}
}
