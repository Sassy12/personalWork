'use strict';

angular.module('indexApp').controller('resetPwdVLinkCtrl', resetPwdVLinkCtrl);

resetPwdVLinkCtrl.$inject = ['$scope', 'trustbrokerAriaService', '$state', '$timeout', 'LanguageService', 'HelpObj', 'ResetPasswordService', 'userDetails'];

function resetPwdVLinkCtrl($scope, trustbrokerAriaService, $state, $timeout, LanguageService, HelpObj, ResetPasswordService, userDetails) {
    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1032_Set_Up_Security_Questions_Verification_Link.htm' });

    $scope.setFieldValidity = function(inputid, spanid) {
        trustbrokerAriaService.setFieldValidity(inputid, spanid);
    };

    LanguageService.doTranslate("selfservice");

    $scope.rpvl = {};
    $scope.rpvl.resetPwdVerLinkHdr = "RESET_PWD_V_LINK_HDR";
    // $scope.rpvl.successMsg = "RESET_PWD_V_LINK_S_MSG";

    $scope.successMsg = {
        animationTime: 1,
        autoFadeOut: false,
        content: '<span translate="RESET_PWD_V_LINK_S_MSG"></span>',
        headingLevel: '2',
        id: 'rpvlSuccess',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: true
    };

    $scope.rpvl.resendMsg = "RESEND_MAIL_MSG";
    $scope.rpvl.resendEmailLinkStr = "RESEND_MAIL";

    $scope.rpvl.mainMsg = "RESET_PWD_V_LINK_MAIN_MSG";

    $scope.rpvl.otherOptnMsg = "RESET_PWD_V_LINK_O_OPTS";
    $scope.rpvl.retLinkStr = "RET_V_IDENTITY_OPTS";

    $scope.rpvl.resendEmailClick = function() {
        ResetPasswordService.resendEmailToUser(userDetails).then(function(response) {
            if (!response.data.errorMap) {
                $scope.successMsg.content = '<span translate="RESET_PWD_V_LINK_S_MSG_RESEND"></span>';
            }

            $timeout(function() {
                $("#rpvlSuccess").focus();
            }, 300);
        });
    };

    $scope.rpvl.retLinkClick = function() {
        $state.go("forgotCredByIdentity");
    };
}
