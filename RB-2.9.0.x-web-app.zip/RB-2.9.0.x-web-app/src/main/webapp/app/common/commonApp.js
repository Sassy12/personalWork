'use strict';

var commonApp = angular.module('common.modules', ['ui.router','uitk.uitkUtility']);
commonApp.constant('basePath', '/tb/app');

commonApp.config(['$stateProvider', 'basePath', function($stateProvider, basePath) {

    $stateProvider.state("congratulations", {
        url: "/congratulations",
        title: "Congratulations - Optum ID",
        templateUrl: basePath + '/common/emailconfirmation/views/congratulations.html',
        params: {
            'flowName': null
        },
        controller: function($scope, $window, $stateParams, $translate, HelpObj) {
            var msgContent = '';
            HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1006_Email_Address_Confirmed.htm' });

            pageDataLayer.content.pageName = "emailVerificationSuccess";
            pageDataLayer.content.siteSectionL1 = "";

            if (typeof _satellite !== "undefined") {
                _satellite.track('trackPageView');
            }

            if ($stateParams.flowName === 'secEmailVerification') {
                $scope.emailVerificationFlow = true;
                msgContent = '<span translate="emailVerificationSuccessContent"></span>';
            } else {
                msgContent = '<span translate="emailConfirmationSuccessContent"></span>';
            }

            $scope.congratulationSuccessModel = {
                animationTime: 1,
                autoFadeOut: false,
                content: msgContent,
                headingLevel: '2',
                id: "congratsSuccessId",
                messageRole: 'alert',
                messageType: "success",
                position: 'inline',
                visible: true
            };

            $scope.continueToPostRegistration = function() {
                $window.location.href = basePath + "/secure/home.do";
            };
        }
    }).state("confirmEmailAddress", {
        url: "/confirmEmailAddress",
        templateUrl: basePath + '/common/emailconfirmation/views/confirmEmailAddressUpdated.html',
        controller: 'verifyController',
        params: {
            verifyCodesCtx: {},
            fromState: null,
            emailShared: null
        },
        resolve: {
            langData: function(LanguageService) {
                return LanguageService.doTranslate('/tb/app/common/emailconfirmation');
            },
            initialData: function(verifyService, $stateParams) {
                if (Object.keys($stateParams.verifyCodesCtx).length === 0) {
                    return verifyService.getVerifyCodesCtx().then(function(response) {
                        $stateParams.verifyCodesCtx = response.data;
                        return verifyService.checkForPreVerification(response.data);
                    });
                } else {
                    return verifyService.checkForPreVerification($stateParams.verifyCodesCtx);
                }
            }
        }
    }).state("updateEmailAddress", {
        url: "/updateEmailAddress",
        title: "Update Email Address-Optum ID",
        templateUrl: basePath + '/common/updateemail/views/updateEmailAddress.html',
        controller: "updateEmailAddressController",
        params: {
            vo: {},
            emailShared: null
        },
        resolve: {
            langData: function(LanguageService) {
                return LanguageService.doTranslate('/tb/app/common/updateemail');
            },
            pageData: function(updateEmailAddressService, $stateParams) {
                var verifyCodesVO = $stateParams.vo;
                if (verifyCodesVO && Object.keys(verifyCodesVO).length === 0) {
                    return updateEmailAddressService.getUpdateEmailContext().then(function(response) {
                        var responseData = response.data;
                        $stateParams.vo = responseData;
                        $stateParams.emailShared = responseData.emailShared;
                    });
                }
            }
        }
    });

}]);
