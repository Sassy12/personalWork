/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When          Who         Why
 * Jan 15, 2016  bmanna3	Initial version
 ****************************************************************/
package com.optum.trustbroker.controller;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.service.UploadedImageService;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.RPWhiteLabelVO;
import com.optum.trustbroker.vo.RelyingPartyAppVO;

/**
 * The service class provides REST services for retrieving Relying Party LOGO.
 * 
 */

@Path(TBConstants.RELYINGPARTY_CONTROLLER_PATH)
public class RelyingPartyApplicationController extends BaseController {

    private static final long EXPIRATION_IN_MILLIS = 3600000;

    private static final Logger LOG = Logger.getLogger(RelyingPartyApplicationController.class);

    private static final int DEFAULT_BUFFER_SIZE = 10240;

    private String defaultImageName = "OPTUM-footer-logo.png";

    private String blankImageName = "blanklogo.png";

    @Autowired
    private UploadedImageService uploadedImageService;

    /**
     * This service method is to get the relying party application logo image
     * for the given RP app id or throught context. If RP app id is not passed
     * as parameter, then it will try to get the RP app id from web application
     * context intialized from cookie state. If RP app id is invalid or empty,
     * returns default optumid logo.
     * 
     * @param rpAppId
     *            String
     * @param request
     *            http request
     * @return Response
     */

    @GET
    @Path(value = "/rpapplogo")
    @Produces("image/*")
    public Response getRPAppLogo(@Context HttpServletRequest request, @Context HttpServletResponse httpResp) {
        String contentType = "image";
        Response response = null;
        RPWhiteLabelVO uploadedImage = null;
        String defImgName = "/images/" + defaultImageName;
        BufferedImage img = null;

        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        String relyingAppId = ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);

        if (StringUtils.isNotBlank(relyingAppId)) {
            LOG.debug(" getRPAppLogo rpAppId  " + relyingAppId);
            uploadedImage = uploadedImageService.fetchUploadedImageByAppId(relyingAppId);
        }

        if (uploadedImage == null || uploadedImage.getFileContent() == null) {
            // Find default image logo

            try {

                String ctxPath = request.getContextPath();
                String reqUrl = request.getRequestURL().toString();
                String urlStr = reqUrl.substring(0, reqUrl.indexOf(ctxPath)) + ctxPath + defImgName;

                URL url = new URL(urlStr);
                img = ImageIO.read(url);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ImageIO.write(img, "png", baos);
                baos.flush();
                byte[] imageInByte = baos.toByteArray();
                TrustBrokerUtil.safeClose(baos);

                contentType = "image/png";
                response = Response.ok(imageInByte, contentType).build();
            } catch (IOException e) {
                LOG.debug("caught exception loading default trustbroker image. msg: " + e);
                response = Response.status(HttpServletResponse.SC_NOT_FOUND).build();
                this.sendHttpError(httpResp);
                return response;
            }
        } else {
            contentType = "image/" + uploadedImage.getContentType();
            response = Response.ok(uploadedImage.getFileContent(), contentType).build();
        }

        return response;
    }

    /**
     * This service method is to get the default Optum ID logo image if any RP
     * app id exists in context. If RP app id is not passed as parameter, then
     * it will try to get the RP app id from web application context initialized
     * from cookie state. If RP app id is invalid or empty, returns blank logo.
     *
     * @param request
     *            http request
     * @param httpResp
     *            http request
     * @return Response
     */
    @GET
    @Path(value = "/footerlogo")
    @Produces("image/*")
    public Response getFooterLogo(@Context HttpServletRequest request, @Context HttpServletResponse httpResp) {
        String contentType = "image";
        Response response = null;
        final String defImgName = "/images/" + defaultImageName;
        final String blankImgName = "/images/" + blankImageName;

        byte[] imageInByte = null;
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        String relyingAppId = ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
        try {
            if (StringUtils.isNotBlank(relyingAppId)) {
                imageInByte = readImage(request, defImgName);
            } else {
                imageInByte = readImage(request, blankImgName);
            }
        } catch (IOException e) {
            LOG.error("caught exception loading footer image. msg: " + e);
            response = Response.status(HttpServletResponse.SC_NOT_FOUND).build();
            this.sendHttpError(httpResp);
            return response;
        }

        contentType = "image/png";
        response = Response.ok(imageInByte, contentType).build();
        return response;
    }

    @GET
    @Path(value = "/checkIfRPExists")
    @Produces(MediaType.APPLICATION_JSON)
    public RpAppVO checkIfRPExists() {
        RelyingPartyAppVO relyingPartyAppVO = getRPContext();
        RpAppVO rpAppVO = new RpAppVO();
        if (relyingPartyAppVO != null) {
            rpAppVO.setApplicationName(relyingPartyAppVO.getApplicationName());
            rpAppVO.setAppId(relyingPartyAppVO.getApplicationId());
        }
        return rpAppVO;
    }

    @GET
    @Path(value = "/isRPOldGen")
    @Produces(MediaType.TEXT_PLAIN)
    public Boolean isRPOldGen() {
        RelyingPartyAppVO relyingPartyAppVO = getRPContext();
        Boolean oldGenRP = false;
        final String oldGenVersion = tbResources.getString(TrustBrokerConstants.OLD_GEN_APP_VERSION);
        if (relyingPartyAppVO != null && oldGenVersion.equals(relyingPartyAppVO.getTbVersion())) {
            oldGenRP = true;
        }
        return oldGenRP;
    }

    /**
     * This service method is to read the given image content from the
     * application path and returns the byte content.
     * 
     * @param request
     *            http request
     * @param imgName
     *            String
     * @return byte[]
     */
    private byte[] readImage(HttpServletRequest request, String imgName) throws IOException {
        byte[] imageInByte = null;
        ByteArrayOutputStream baos = null;
        BufferedImage img = null;
        try {
            String ctxPath = request.getContextPath();
            String reqUrl = request.getRequestURL().toString();
            String urlStr = reqUrl.substring(0, reqUrl.indexOf(ctxPath)) + ctxPath + imgName;
            URL url = new URL(urlStr);
            img = ImageIO.read(url);
            baos = new ByteArrayOutputStream();
            ImageIO.write(img, "png", baos);
            baos.flush();
            imageInByte = baos.toByteArray();
        } finally {
            TrustBrokerUtil.safeClose(baos);
        }
        return imageInByte;
    }

    private void sendHttpError(HttpServletResponse httpResp) {
        byte[] bytes = new byte[0];
        writeImageOut(httpResp, "", bytes, null, true, false);
    }

    private void writeImageOut(HttpServletResponse resp, String contentType, byte[] imageBytes, BufferedImage bi,
            boolean isError, boolean useImage) {
        LOG.debug(" writeImageOut useImage " + useImage + " isError " + isError + " image " + bi);
        InputStream input = null;
        OutputStream output = null;
        resp.setHeader("ETag", "*");
        resp.setHeader("Cache-Control", "public, max-age=" + (EXPIRATION_IN_MILLIS / 1000));
        resp.setHeader("Vary", "Accept-Encoding,User-Agent");
        resp.setContentType(contentType);

        try {
            InputStream is = new ByteArrayInputStream(imageBytes);
            resp.setHeader("Content-Length", String.valueOf(imageBytes.length));
            if (!useImage) {
                input = new BufferedInputStream(is, DEFAULT_BUFFER_SIZE);
                output = new BufferedOutputStream(resp.getOutputStream(), DEFAULT_BUFFER_SIZE);
                byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
                int length;
                while ((length = input.read(buffer)) > 0) {
                    output.write(buffer, 0, length);
                }
            } else {
                LOG.debug("using IMAGEIO write");
                ImageIO.write(bi, contentType, output);

            }
            if (isError) {
                resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            LOG.error("error while displaying relying party logo: ", e);
        } finally {
            // Gently close streams.
            TrustBrokerUtil.safeClose(output);
            TrustBrokerUtil.safeClose(input);
        }
    }

    public UploadedImageService getUploadedImageService() {
        return uploadedImageService;
    }

    public void setUploadedImageService(UploadedImageService uploadedImageService) {
        this.uploadedImageService = uploadedImageService;
    }

    public String getDefaultImageName() {
        return this.defaultImageName;
    }

    public void setDefaultIamgeName(String val) {
        this.defaultImageName = val;
    }

}