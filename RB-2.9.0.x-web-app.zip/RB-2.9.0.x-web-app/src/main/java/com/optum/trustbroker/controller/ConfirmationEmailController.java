package com.optum.trustbroker.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.ConfirmationEmailVO;
import com.optum.trustbroker.controller.vo.MessageType;
import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.controller.vo.VerifyCodesCtx;
import com.optum.trustbroker.message.MessageUtils;
import com.optum.trustbroker.service.RelyingPartyAppService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.service.UserVerifyCodesService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.CryptAgentUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.UserVerifyCdCtxVO;
import com.optum.trustbroker.vo.UserVerifyCodesServiceResponse;
import com.optum.trustbroker.vo.UserVerifyCodesVO;
import com.optum.trustbroker.vo.VerificationCodeRequest;
import com.optum.trustbroker.vo.VerificationCodeResponse;
import com.uhg.iam.alps.common.http.HttpUtils;

@Path(TBConstants.CONFIRM_EMAIL_CONTROLLER_LINK)
public class ConfirmationEmailController extends BaseController {

    @Autowired
    public CryptAgentUtil cryptAgentUtil;

    @Autowired
    public UserVerifyCodesService userVerifyCodesService;

    @Autowired
    public UserService userService;

    @Autowired
    public RelyingPartyAppService relyingPartyAppService;

    @Autowired
    @Qualifier("tb_service_errorMessageResource")
    public MessageSource errorMessageSource;

    private static final BaseLogger LOGGER = new BaseLogger(ConfirmationEmailController.class);

    @Path(TBConstants.VERIFY_LINK)
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ConfirmationEmailVO verifyLink(String verificationToken, @Context HttpServletRequest request,
            @Context HttpServletResponse resp) {

        Map<String, String> verificationDetails = null;
        CommunicationChannel commChannel = null;
        UserVerifyCodesVO userVerifyCodesVO = null;
        SupportContactInfoVO sci = null;
        ConfirmationEmailVO confirmationEmailVO = null;

        if (StringUtils.isNotEmpty(verificationToken)) {

            try {
                verificationDetails = cryptAgentUtil.getCryptAgent().getAttributesFromToken(verificationToken, true);
                UserVerifyCodesServiceResponse verifyCodeResponse = userVerifyCodesService
                        .getUserVerifyCodesByRequestToken(verificationDetails.get(TrustBrokerConstants.REQUEST_TOKEN));

                sci = webApplicationCommonUtilities.getApplicationSupportContactInformation(true);

                addRPDetailsFromVerificationDetailsContext(verifyCodeResponse.getUserVerifyCodesVO());

                UserRetrievalServiceResponse response = userService
                        .fetchUserProfile(verificationDetails.get(TrustBrokerConstants.USER_UUID), true, false);
                UserVO verificationUserVO = response.getUser();

                commChannel = getCommunicationChannel(verificationDetails);

                if (TrustbrokerWebAppUtil.checkResponseStatus(verifyCodeResponse)) {
                    userVerifyCodesVO = verifyCodeResponse.getUserVerifyCodesVO();
                    if ((CommunicationChannel.SECONDARY_EMAIL == commChannel && verificationUserVO.isSecEmailVerified())
                            || (CommunicationChannel.PRIMARY_EMAIL == commChannel
                                    && verificationUserVO.isIsemailVerified())) {
                        userVerifyCodesService
                                .deleteUserVerifyCodes(verifyCodeResponse.getUserVerifyCodesVO().getUserVerifyCdId());
                        confirmationEmailVO = nextActionOnVerification(verificationUserVO, request);
                        confirmationEmailVO.setDisplayBtn(false);
                        return confirmationEmailVO;
                    }
                    return verifyEmail(userVerifyCodesVO, commChannel, verificationUserVO, request);

                } else if (TrustbrokerWebAppUtil.checkExpiredRespStatus(verifyCodeResponse)) {
                   
                    RpAppVO appVO = buildRPFromVerificationDetailsContext(verifyCodeResponse.getUserVerifyCodesVO());                    
                    VerificationCodeRequest verfCodeReq = getVerificationCodeRequest(commChannel, verificationUserVO,
                             request, appVO);
                    userService.sendVerificationCode(verfCodeReq);
                    String verificationEmail = verificationDetails.get(TrustBrokerConstants.USER_EMAIL);
                    confirmationEmailVO = new ConfirmationEmailVO();
                    confirmationEmailVO.setMsgType(MessageType.EXPIRED);
                    String maskedEmail = TBUtil.emailMask(verificationEmail);                       
                    confirmationEmailVO.setMsg(StringUtils.replace(
                            tbResources.getString("emailVerfnLinkExpCd"), "{0}", maskedEmail));
                    return confirmationEmailVO;
                } else {
                    String verificationEmail = verificationDetails.get(TrustBrokerConstants.USER_EMAIL);

                    if (CommunicationChannel.PRIMARY_EMAIL == commChannel) {
                        // Case 1
                        confirmationEmailVO = processVerificationIfDetailsNotFound(verificationUserVO.getEmailAddress(),
                                verificationEmail, verificationUserVO.isIsemailVerified(), sci, verificationUserVO,
                                commChannel);
                    } else if (CommunicationChannel.SECONDARY_EMAIL == commChannel) {
                        // Case 2
                        confirmationEmailVO = processVerificationIfDetailsNotFound(verificationUserVO.getSecEmailAddress(),
                                verificationEmail, verificationUserVO.isSecEmailVerified(), sci, verificationUserVO,
                                commChannel);
                    }
                    return confirmationEmailVO;
                }
            } catch (OperationFailedException ofe) {
                LOGGER.error("Error while verifying email with verification token {}, error code - {}",
                        new String[] {verificationToken, TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
                return buildErrorMsgDetails(ofe);                
            } catch (RuntimeException ex) {
                String referenceCode = MessageUtils.getErrorUid();
                sci = webApplicationCommonUtilities.getApplicationSupportContactInformation(true);
                LOGGER.error("Unexpected error while verifying email, error code - {}", new String[] {referenceCode}, ex);

                confirmationEmailVO = new ConfirmationEmailVO();
                confirmationEmailVO.setDisplayBtn(false);
                confirmationEmailVO.setMsgType(MessageType.ERROR);
                confirmationEmailVO.setMsg(TBUtil.formatMessage(tbResources.getString("verifysystemException"),
                        new String[] {sci.getContactComboText(), referenceCode}));
                return confirmationEmailVO;
            }
        } else {
            String referenceCode = MessageUtils.getErrorUid();
            LOGGER.error("Verification details missing in URL or not properly encoded - {}", new String[] {referenceCode});
            sci = webApplicationCommonUtilities.getApplicationSupportContactInformation(true);
            confirmationEmailVO = new ConfirmationEmailVO();
            confirmationEmailVO.setDisplayBtn(false);
            confirmationEmailVO.setMsgType(MessageType.ERROR);
            confirmationEmailVO.setMsg(TBUtil.formatMessage(tbResources.getString("linkExpiredOrVerifyDetailsMissing"),
                    new String[] {sci.getContactComboText()}));
            return confirmationEmailVO;
        }
    }

    /**
     * This method is used to resend the email confirmation code.
     * 
     * @param verificationToken
     * @param request servlet request
     * @return ConfirmationEmailVO
     */
    @Path(TBConstants.CONFRM_EMAIL_RESEND_CODE)
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ConfirmationEmailVO resendEmail(String verificationToken, @Context HttpServletRequest request) {
                        
            Map<String, String> verificationDetails = null;
            CommunicationChannel commChannel = null;
            ConfirmationEmailVO confirmationEmailVO = new ConfirmationEmailVO();
            try {
                                                
                verificationDetails = cryptAgentUtil.getCryptAgent().getAttributesFromToken(verificationToken, true);
                UserVerifyCodesServiceResponse verifyCodeResponse = userVerifyCodesService
                        .getUserVerifyCodesByRequestToken(verificationDetails.get(TrustBrokerConstants.REQUEST_TOKEN));
                
                UserRetrievalServiceResponse response = userService
                        .fetchUserProfile(verificationDetails.get(TrustBrokerConstants.USER_UUID), true, false);
                UserVO verificationUserVO = response.getUser();
                RpAppVO appVO = buildRPFromVerificationDetailsContext(verifyCodeResponse.getUserVerifyCodesVO());
                
                commChannel = getCommunicationChannel(verificationDetails);
                
                VerificationCodeRequest verfCodeReq = getVerificationCodeRequest(commChannel, verificationUserVO,
                        request, appVO);
                userService.sendVerificationCode(verfCodeReq);
                confirmationEmailVO.setMsgType(MessageType.SUCCESS);
                confirmationEmailVO.setMsg(tbResources.getString("emailVerfFailOldCodeResent"));
            
            } catch (OperationFailedException ofe) {
                LOGGER.error("Error while verifying email with verification token {}, error code - {}",
                        new String[] {verificationToken, TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
                confirmationEmailVO = buildErrorMsgDetails(ofe);
            }            
            return confirmationEmailVO;
    }
    
    /**
     * This method is to build emailVO object using the exception detail and returns it.
     * 
     * @param ofe OperationFailedException
     * @return ConfirmationEmailVO
     */
    private ConfirmationEmailVO buildErrorMsgDetails(OperationFailedException ofe) {
        ConfirmationEmailVO confirmationEmailVO = new ConfirmationEmailVO();
        SupportContactInfoVO sci = webApplicationCommonUtilities.getApplicationSupportContactInformation(true);
        if (ofe != null && ofe.getErrorMessage() != null
                && TrustBrokerConstants.OPT_00A003.equalsIgnoreCase(ofe.getErrorMessage().getCode())) {
            // Case 6 - User not found            
            confirmationEmailVO.setMsgType(MessageType.ERROR);
            confirmationEmailVO.setDisplayBtn(false);
            confirmationEmailVO
                    .setMsg(TBUtil.formatMessage(tbResources.getString("linkExpiredOrVerifyDetailsMissing"),
                            new String[] {sci.getContactComboText()}));            
        } else {            
            confirmationEmailVO.setMsgType(MessageType.ERROR);
            confirmationEmailVO.setDisplayBtn(false);
            confirmationEmailVO.setMsg(ofe.getErrorMessage() != null
                    ? ofe.getErrorMessage().getEndUserMessage(errorMessageSource, sci) : ofe.getMessage());            
        }
        return confirmationEmailVO;
    }
    
    private ConfirmationEmailVO verifyEmail(UserVerifyCodesVO userVerifyCodesVO, CommunicationChannel commChannel,
            UserVO verificationUserVO, HttpServletRequest request) {

        ConfirmationEmailVO confirmationEmailVO = null;
        try {

            VerificationCodeResponse respVerify = userService.verifyChannel(commChannel, userVerifyCodesVO.getCode(), "");
            if (TrustbrokerWebAppUtil.checkResponseStatus(respVerify)) {
                confirmationEmailVO = nextActionOnVerification(verificationUserVO, request);
                if (StringUtils.isNotBlank(confirmationEmailVO.getNextStateUrl())) {
                    return confirmationEmailVO;
                } else {
                    String msgKey = (commChannel == CommunicationChannel.SECONDARY_EMAIL) ?
                            "secondaryEmailVerifiedSuccess" : "emailVerifiedSuccessOnLinkNextGen";
                    confirmationEmailVO.setMsg(tbResources.getString(msgKey));
                    confirmationEmailVO.setMsgType(MessageType.SUCCESS);
                    confirmationEmailVO.setDisplayBtn(true);
                    return confirmationEmailVO;
                }
            } else {
                confirmationEmailVO = new ConfirmationEmailVO();
                confirmationEmailVO.setMsgType(MessageType.ERROR);
                confirmationEmailVO.setDisplayBtn(false);
                confirmationEmailVO.setMsg(tbResources.getString("emailVerificationFailedEsso"));
                return confirmationEmailVO;
            }

        } catch (OperationFailedException e) {
            LOGGER.error("secondary email verification failed", e);
            if (checkVerificationError(e) != null) {
                return checkVerificationError(e);
            }

            confirmationEmailVO = new ConfirmationEmailVO();
            confirmationEmailVO.setMsgType(MessageType.ERROR);
            confirmationEmailVO.setDisplayBtn(false);
            confirmationEmailVO.setMsg(TBUtil.formatMessage(tbResources.getString("linkExpiredOrVerifyDetailsMissing"),
                    new String[] {webApplicationCommonUtilities.getApplicationSupportContactInformation(true)
                            .getContactComboText()}));
            return confirmationEmailVO;
        }

    }

    private void addRPDetailsFromVerificationDetailsContext(UserVerifyCodesVO userVerifyCodeDetails) {

        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        if (null != userVerifyCodeDetails && null != userVerifyCodeDetails.getUserVerifyCdCtxVO()) {
            for (UserVerifyCdCtxVO usrVerifyCdCtx : userVerifyCodeDetails.getUserVerifyCdCtxVO()) {

                if (TrustBrokerWebAppConstants.RELYING_APP_ID.equals(usrVerifyCdCtx.getCtxName())) {

                    ctx.setSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, usrVerifyCdCtx.getCtxValue());

                }
                if (TrustBrokerWebAppConstants.RELYING_APP_URL.equals(usrVerifyCdCtx.getCtxName())) {

                    ctx.setSessionAttribute(TrustBrokerWebAppConstants.TARGET, usrVerifyCdCtx.getCtxValue());

                }

            }
        }

    }
    /**
     * This method is used to build RPapp obj from verify code details.
     * @param userVerifyCodeDetails
     * @return
     */
    private RpAppVO buildRPFromVerificationDetailsContext(UserVerifyCodesVO userVerifyCodeDetails) {
 
        WebApplicationContext webAppCtx = WebApplicationContextHolder.getContext();
        String rpAppID = webAppCtx.getSessionAttribute(TrustBrokerConstants.RELYING_APP_ID_PARAM);
        String rpTargetUrl = webAppCtx.getSessionAttribute(TrustBrokerConstants.TARGET);
        RpAppVO appVO = new RpAppVO();
        appVO.setAppId(rpAppID);
        appVO.setTargetURL(rpTargetUrl);
        return appVO;
    }

    private ConfirmationEmailVO checkVerificationError(OperationFailedException e) {
        ConfirmationEmailVO confirmationEmailVO = null;
        Map<String, String> errMsgs = e.getErrorMessages();
        if (MapUtils.isEmpty(errMsgs) && e.getCause() != null) {
            errMsgs = ((OperationFailedException) e.getCause()).getErrorMessages();
        }
        if (errMsgs != null && CollectionUtils.containsAny(new ArrayList<>(errMsgs.keySet()),
                Arrays.asList("EMAIL_VERIFICATION_CODE_MISMATCH", "PHN_NO_VERIFICATION_CODE_MISMATCH",
                        "VERIFICATION_CODE_EXPIRED", "VALIDATION_ERROR"))) {
            confirmationEmailVO = new ConfirmationEmailVO();
            confirmationEmailVO.setMsgType(MessageType.ERROR);
            confirmationEmailVO.setDisplayBtn(false);
            confirmationEmailVO.setMsg(TBUtil.formatMessage(tbResources.getString("linkExpiredOrVerifyDetailsMissing"),
                    new String[] {webApplicationCommonUtilities.getApplicationSupportContactInformation(true)
                            .getContactComboText()}));

            return confirmationEmailVO;
        }
        return confirmationEmailVO;
    }

    private CommunicationChannel getCommunicationChannel(Map<String, String> verificationDetails) {

        CommunicationChannel commChannel = null;

        if (CommunicationChannel.PRIMARY_EMAIL.name()
                .equals(verificationDetails.get(TrustBrokerConstants.VERIFICATION_TYPE))) {
            commChannel = CommunicationChannel.PRIMARY_EMAIL;
        } else if (CommunicationChannel.SECONDARY_EMAIL.name()
                .equals(verificationDetails.get(TrustBrokerConstants.VERIFICATION_TYPE))) {
            commChannel = CommunicationChannel.SECONDARY_EMAIL;
        }

        return commChannel;
    }

    private ConfirmationEmailVO processVerificationIfDetailsNotFound(String currentEmail, String verificationEmail,
            boolean isCurrentEmailVerified, SupportContactInfoVO sci, UserVO verificationUserVO,
            CommunicationChannel commChannel) {

        ConfirmationEmailVO confirmationEmailVO = null;
        if ((StringUtils.isBlank(currentEmail) || (!currentEmail.equalsIgnoreCase(verificationEmail)))) {

            confirmationEmailVO = new ConfirmationEmailVO();
            confirmationEmailVO.setMsgType(MessageType.ERROR);
            confirmationEmailVO.setMsg(TBUtil.formatMessage(tbResources.getString("emailNotExistOnProfile"),
                    new String[] {sci.getContactComboText()}));

        } else if (isCurrentEmailVerified) { // Case 3 and 4

            confirmationEmailVO = new ConfirmationEmailVO();
            confirmationEmailVO.setMsgType(MessageType.VERIFIED);
            confirmationEmailVO.setMsg(tbResources.getString("emailAlreadyVerifiedSuccess"));

        } else if (!isCurrentEmailVerified) { // Case 2
            confirmationEmailVO = new ConfirmationEmailVO();
            confirmationEmailVO.setMsgType(MessageType.NOTFOUND);
            confirmationEmailVO.setMsg(TBUtil.formatMessage(tbResources.getString("emailVerificationFailedOldCode"),
                        new String[] {TBUtil.emailMask(currentEmail)}));
            confirmationEmailVO.setDisplayBtn(false);

        }
        return confirmationEmailVO;
    }

    private ConfirmationEmailVO nextActionOnVerification(UserVO verificationUserVO, HttpServletRequest request) {
        ConfirmationEmailVO confirmationEmailVO = new ConfirmationEmailVO();

        if (isActiveSMSessionForUser(verificationUserVO.getUserName(), request)) {
            confirmationEmailVO.setDisplayBtn(true);
        } else {
            String loginURL = "/tb/app/index.html";
            loginURL = HttpUtils.addParameterToURL(loginURL, TrustBrokerWebAppConstants.LOGIN_FAIL_REASON,
                    TrustBrokerWebAppConstants.REASON_ACCOUNT_VERIFIED);
            loginURL = constructURLWithRPParams(loginURL);

            confirmationEmailVO.setDisplayBtn(false);
            confirmationEmailVO.setNextStateUrl(loginURL);
            return confirmationEmailVO;
        }
        return confirmationEmailVO;
    }

    public CryptAgentUtil getCryptAgentUtil() {
        return cryptAgentUtil;
    }

    public void setCryptAgentUtil(CryptAgentUtil cryptAgentUtil) {
        this.cryptAgentUtil = cryptAgentUtil;
    }

    public UserVerifyCodesService getUserVerifyCodesService() {
        return userVerifyCodesService;
    }

    public void setUserVerifyCodesService(UserVerifyCodesService userVerifyCodesService) {
        this.userVerifyCodesService = userVerifyCodesService;
    }

    @Override
    public UserService getUserService() {
        return userService;
    }

    @Override
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @Override
    public RelyingPartyAppService getRelyingPartyAppService() {
        return relyingPartyAppService;
    }

    @Override
    public void setRelyingPartyAppService(RelyingPartyAppService relyingPartyAppService) {
        this.relyingPartyAppService = relyingPartyAppService;
    }

    @Override
    public MessageSource getErrorMessageSource() {
        return errorMessageSource;
    }

    @Override
    public void setErrorMessageSource(MessageSource errorMessageSource) {
        this.errorMessageSource = errorMessageSource;
    }
}
