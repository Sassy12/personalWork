'use strict';

angular.module('indexApp').controller('ResetPassCtrl', ['$scope', '$timeout', '$state', 'trustbrokerAriaService', 'LanguageService', 'userNameDetails', 'ResetPasswordService', 'GeneralService', '$translate', 'uitkLiveRegionService', '$rootScope', 'HelpObj', ResetPassCtrl]);

function ResetPassCtrl($scope, $timeout, $state, trustbrokerAriaService, LanguageService, userNameDetails, ResetPasswordService, GeneralService, $translate, uitkLiveRegionService, $rootScope, HelpObj) {
    LanguageService.doTranslate('selfservice');

    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1028_Reset_Password_after_providing_mobile_verification_code.htm' });

    $scope.pwdRulesMet = 0;
    $scope.showPwdErr = false;
    $scope.serverError = "";
    $scope.retainServerError = "";
    $scope.passwordEntered = "";
    $scope.passwordIsValid = false;
    $scope.constants = $rootScope.constants;
    if (userNameDetails.data) {
        $scope.userName = userNameDetails.data.userName;
    } else {
        $scope.userName = userNameDetails;
    }

    
  //Need this for getting the value of password on leaving the field
    $rootScope.$on('pwdValue', function(event, args){
    	if (args.value && $scope.confirmPwd && args.value !== $scope.confirmPwd) {
    		 $scope.confirmPwdErrorMsg = $translate.instant('pwdDoNotMatch');
    	}
    	else {
    		$scope.confirmPwdErrorMsg = "";
    	}
    	var passFldValue = $scope.newPassword;
    	if ($scope.passwordEntered !== passFldValue) {
            $scope.serverError = "";
            $rootScope.$emit('serverError',{msg: null});		//emitting server side error
        } else {
            $scope.serverError = $scope.retainServerError;
            $rootScope.$emit('serverError',{msg: $scope.serverError});		//emitting the server side error
        }
    });
    
    //function for setting field validity (WCAG)
    $scope.setFieldValidity = function(inputid, spanid) {
        $scope.showPwdErr = true;
        var passFldValue = angular.element("#" + inputid).val();
        if ($scope.passwordEntered !== passFldValue) {
            $scope.serverError = "";
        } else {
            $scope.serverError = $scope.retainServerError;
            $rootScope.$emit('serverError',{msg: $scope.serverError});
        }

        trustbrokerAriaService.setFieldValidity(inputid, spanid);
    };

    $scope.errorMessageModel = {
        animationTime: 1,
        ariaAttributes: true,
        content: '<span translate="genericFormError"></span>',
        headingLevel: '2',
        id: 'errorMessage',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    $scope.successMessageModel = {
        ariaAttributes: true,
        autoFadeOut: false,
        content: '<span><span translate="verifiedIdentityMsg"></span><span class="change-to-bold">' + $scope.userName + '</span>.<span translate="goAheadAndReset"></span></span>',
        headingLevel: '2',
        id: 'Success',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: true
    };
    //function for checking if password and confirm password field matches
    $scope.pwdMatchValidation = function() {
        if ($scope.newPassword === undefined || $scope.newPassword === "") {
            return true;
        }
        if ($scope.confirmPassword === undefined || $scope.confirmPassword === "") {
            return true;
        }
        if ($scope.newPassword !== $scope.confirmPassword) {
            return false;
        } else {
            return true;
        }
    };


  //passwordFieldForm is sub form for password coming form directive (checking if password field is valid)
    $rootScope.$on('IsPasswordValid', function(event, args){
    	$scope.passwordIsValid = args.msg;
    });
    $scope.next = function() {
        var FIELDS = [
            { fld: "newPasswordId_input",     msg: "newPasswordId_err" },
            { fld: "confirmPasswdId_input", msg: "confirmPasswdId_err" }
        ];
        if (!$scope.passwordIsValid || $scope.resetPasswordForm.confirmPassword.$error.required) {
            $scope.errorMessageModel.visible = true;

            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);

            $rootScope.fireErrorTracker = true;
            return;
        }
        
        if (!$scope.passwordIsValid || !$scope.pwdMatchValidation()) {
            $scope.errorMessageModel.visible = true;
            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);
            $rootScope.fireErrorTracker = true;
            return;
        } 

        var formData = {
            pwd: $scope.newPassword,
            confirmPwd: $scope.confirmPassword
        };

        var serviceResponse = [];
        $scope.passwordEntered = $scope.newPassword;
        ResetPasswordService.submitForm(formData).then(function(response) {
            serviceResponse = response;

            if (serviceResponse.data.errorMap) {
                $scope.errorMessageModel.visible = true;
                if (serviceResponse.data.errorMap.pwd) {
                    $scope.serverError = serviceResponse.data.errorMap.pwd;
                    $rootScope.$emit('serverError',{msg: $scope.serverError});		//emitting server side error
                    $scope.retainServerError = serviceResponse.data.errorMap.pwd;
                } else {
                    $scope.serverError = serviceResponse.data.errorMap.confirmPwd;
                    $rootScope.$emit('serverError',{msg: $scope.serverError});		//emitting server side error
                }

                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                }, 300);

                $rootScope.fireErrorTracker = true;
            } else {
                $state.go("login", { 'prevState': 'resetPasswordSuccess' });
            }
        });
    };
}
