package com.optum.trustbroker.managebean.widget;

import java.io.IOException;
import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.ExecutionStatus;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RPAppDomainVO;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserAuthorizationRequest;
import com.optum.trustbroker.vo.UserChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.commons.beans.EmailDetail;
import com.uhg.iam.commons.utils.ValidationUtilities;

@ManagedBean(name = "wLoginBean")
@ViewScoped
public class LoginBean extends AbstractBackingBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final BaseLogger LOGGER = new BaseLogger(LoginBean.class);

    private static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");

    private static final String SIGN_IN_PAGE_VIEW_ID = "/views/loginw.xhtml";

    private static final String LOGOUT_PAGE = tbResources.getString("LogOutPage");

    String userUnlockSuccess = "/views/userunlocksuccessw.xhtml?faces-redirect=true";

    String forgotUserNamePage = "/views/forgotusernamepagew.xhtml?faces-redirect=true";

    String forgotPwdPage = "/views/forgotpasswordpagew.xhtml?faces-redirect=true";

    String loginPage = "/views/loginw.xhtml?faces-redirect=true";

    private String action = "/siteminderagent/forms/login.fcc";

    private String targetUrl = "/tb/securew/homew.jsf";

    private String pwdChangeSuccessMsg;

    private String localenv = "false";

    private String relyingPartyTargetURL = null;

    private String errorMsg = null;

    private String relyingAppErroMsg = null;

    private String relyingAppstatusMsg = null;

    private String relyingAppUpdateProfileMsg = null;

    private String rpTargetURL = null;

    private String relyingPartyApplicationId = null;

    private boolean unlockAccount;

    private String username;

    private String password;

    private String emailMsg;

    private String emailId;

    private boolean showRegistration = true;

    private String duplicateAccountErrorMsg = null;

    private String accountrecoveryoptions = "/views/accountrecoveryoptionsw.xhtml?faces-redirect=true";

    public void preRenderView() {
        // makes sure init is called before any rendering
    }

    @PostConstruct
    public void init() {
        setErrorMsg("");
        setUnlockAccount(false);

        try {
            setRpSuppParam(getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),
                    getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT));
            if (getRequestParameter(TrustBrokerWebAppConstants.RP_APP_REDIRECT_PARAM) != null
                    && isParamContainsRelyingPartyInfo()) {
                captureRelyingPartyInfo(false);

                String relyingPartyTargetURL = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null
                        ? (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL)
                        : (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);
                String invitationToken = (String) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE);
                relyingPartyTargetURL = invitationToken != null
                        ? (relyingPartyTargetURL + "?" + TrustBrokerWebAppConstants.INVITATION_CODE + "=" + invitationToken)
                        : relyingPartyTargetURL;

                redirectionNonSso(relyingPartyTargetURL, (String) getSessionAttribute(TrustBrokerWebAppConstants.ACTION),
                        (String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS),
                        (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));

                clearSessionAttributes(new String[] {TrustBrokerWebAppConstants.RELYING_APP_URL,
                        TrustBrokerWebAppConstants.RELYING_APP_URL_PROF, TrustBrokerWebAppConstants.ACTION,
                        TrustBrokerWebAppConstants.STATUS});
            }

            if (getSessionAttribute(TrustBrokerWebAppConstants.NA_USER_NM) != null) {
                errorMsg = (String) getSessionAttribute(TrustBrokerWebAppConstants.NA_USER_NM);
                removeSessionAttribute(TrustBrokerWebAppConstants.NA_USER_NM);
            }

            if (TBUtil.isLocalEnv()) {
                setLocalEnv("true");
            }

            String showRegStr = getRequestParameterCaseInsensitive(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP);
            if (showRegStr == null) {
                showRegStr = getRequestParameterCaseInsensitive(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP_ALT);
            }
            if (showRegStr != null) {
                addSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP, showRegStr);
                if (TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP_VAL.equalsIgnoreCase(showRegStr)) {
                    setShowRegistration(false);
                }
                LOGGER.debug("LoginBean.init() - set session attribute for showRegistration. session attribute: "
                        + getSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP));
            }
            HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
            Cookie cookies[] = request.getCookies();

            String smresponsecode = "0";
            String smusrmsg = "0";
            String reason = "";
            String lockedUserID = "";

            // Read cookie SMRESPONSECODE value
            if (cookies != null) {
                for (int i = 0; i < cookies.length; i++) {
                    if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_RESPONSE_CODE)) {
                        smresponsecode = cookies[i].getValue();
                        LOGGER.debug("LoginBean::SMRESPONSECODE-", smresponsecode);
                        deleteCookie(cookies[i]);
                    } else if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_USER_MSG)) {
                        smusrmsg = cookies[i].getValue();
                        LOGGER.debug("LoginBean::SMUSRMSG-", smusrmsg);
                        deleteCookie(cookies[i]);
                    } else if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_USERID)) {
                        lockedUserID = cookies[i].getValue();
                        LOGGER.debug("LoginBean::USERID-", lockedUserID);
                        deleteCookie(cookies[i]);
                    }
                }
            }

            // Retrieve reason for unauthorization.
            if (StringUtils.isNotBlank(getRequestParameter(TrustBrokerWebAppConstants.LOGIN_FAIL_REASON))) {
                reason = getRequestParameter(TrustBrokerWebAppConstants.LOGIN_FAIL_REASON);
                LOGGER.debug("LoginBean::Reason=" + reason);
            }

            if (TrustBrokerWebAppConstants.REASON_PWD_LOCKED.equalsIgnoreCase(reason)
                    || TrustBrokerWebAppConstants.REASON_RSA_LOCKED.equalsIgnoreCase(reason)) {
                errorMsg = TrustBrokerWebAppConstants.REASON_PWD_LOCKED.equalsIgnoreCase(reason)
                        ? tbResources.getString("accountLockMsg") : tbResources.getString("suspendMsg");

                if (StringUtils.isNotBlank(lockedUserID)) {
                    setUnlockAccount(true);
                    Map<String, String> userDetailsMap = new HashMap<String, String>();
                    userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME, lockedUserID);
                    addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);

                    SecurityLoggingUtil.warn("User Login", SecurityEventType.E1_CREATE, getServletRequest(), lockedUserID,
                            "Security Audit Event|CreateUserSession:FAILED| User session denied | Account Disabled, LoginBean:init()",
                            SecurityEventResult.FAILURE, getRelyingPartyAppId(), SecuritySubEventType.E3_DISABLE_LDAP);
                }
            } else if (TrustBrokerWebAppConstants.REASON_SESSION_TIMEOUT_1.equalsIgnoreCase(reason)) {
                errorMsg = "Session time out. Please login again.";
            } else if (TrustBrokerWebAppConstants.REASON_SESSION_TIMEOUT_2.equalsIgnoreCase(reason)) {
                errorMsg = "Session time out. Please try again.";
            } else if (!"0".equals(smresponsecode)) {
                
                if ("2".equals(smresponsecode)
                        && TrustBrokerWebAppConstants.SM_LOGIN_FAILED_USR_MSG.equalsIgnoreCase(smusrmsg)) {
                    if (StringUtils.isNotEmpty(lockedUserID)) {

                        UserVO userVO = container.getUserService().fetchUserProfile(lockedUserID, false, true).getUser();
                        userVO.setCreatedBy(getRelyingPartyName());

                        String rpAppId = getRelyingPartyAppId();
                        if (!TrustBrokerConstants.AA_LOCK_STATUS.equals(userVO.getAaStatus())
                                && (CollectionUtils.isEmpty(userVO.getUserChallengeQuestions()))) {
                            UserAuthorizationRequest userAuthorizationRequest = generateAuthorizationRequest(userVO);
                            container.getUserService().sendAuthCodeToUser(userAuthorizationRequest, TrustBrokerConstants.SQA,
                                    rpAppId, true, getUrlLogoOptumId(), getUrlLogoRelyingParty());
                            SecurityLoggingUtil.info("SQA Missing ", SecurityEventType.E3_CREATE, getServletRequest(),
                                    userVO.getUserName(),
                                    "Security Audit Event|SQA Missing authorization code :SUCCESS|Authorization Code sent to User, LoginBean:init()",
                                    SecurityEventResult.SUCCESS, getRelyingPartyAppId(),
                                    SecuritySubEventType.E3_CREATE_AUTH_CODE);
                            redirectToView("/views/sentauthorizationcodesqaw.jsf");
                            return;
                        }

                        errorMsg = tbResources.getString("suspendMsg");
                        Map<String, String> userDetailsMap = new HashMap<String, String>();
                        userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME, lockedUserID);
                        addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);

                        SecurityLoggingUtil.warn("User Login", SecurityEventType.E3_DISABLE, getServletRequest(),
                                lockedUserID,
                                "Security Audit Event|CreateUserSession:FAILED| User session denied | Account Suspended, LoginBean:init()",
                                SecurityEventResult.FAILURE, getRelyingPartyAppId(), SecuritySubEventType.E3_DISABLE_RSA);

                        setUnlockAccount(true);
                    }
                } else if ("1".equals(smresponsecode) || "2".equals(smresponsecode)) {
                    errorMsg = "Invalid Username/Email or Password";
                    if (StringUtils.isNotBlank(lockedUserID)) {
                        SecurityLoggingUtil.warn("User Login", SecurityEventType.E4, getServletRequest(),
                                StringUtils.trimToEmpty(lockedUserID),
                                "Security Audit Event|CreateUserSession:FAILED| User session denied | Incorrect username or password specified, LoginBean:init()",
                                SecurityEventResult.FAILURE, getRelyingPartyAppId(), null);
                    }
                } else if ("3".equals(smresponsecode)) {
                    errorMsg = "You are not authorized";
                }

            }

            if (StringUtils.isBlank(errorMsg)) {
                LOGGER.error("User Login Error | Message -'{}' | User {}", new String[] {errorMsg, lockedUserID});
            }

            if (isSessionAttributeExists(TrustBrokerWebAppConstants.PWD_CHANGE_MSG)) {
                setPwdChangeSuccessMsg((String) getSessionAttribute(TrustBrokerWebAppConstants.PWD_CHANGE_MSG));
                removeSessionAttribute(TrustBrokerWebAppConstants.PWD_CHANGE_MSG);
            }

            if (StringUtils.isBlank((String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID))
                    && StringUtils.isBlank(getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM))) {
                setRelyingAppErroMsg(buildErrorMessage(TrustBrokerConstants.OPT_00J006));
                return;
            }

            String viewId = getFacesContext().getViewRoot().getViewId();
            if (StringUtils.startsWithIgnoreCase(viewId, SIGN_IN_PAGE_VIEW_ID)) {
                //Keep same session variables as is if target URL contains -SM- (Site minder redirected URL). Otherwise clear out everything.
                if ((getRequestParameter(TrustBrokerWebAppConstants.TARGET) == null && getRequestParameter("reason") == null)
                        || (getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null
                                && !getRequestParameter(TrustBrokerWebAppConstants.TARGET).contains("-SM-")
                                && !getRequestParameter(TrustBrokerWebAppConstants.TARGET).contains("$SM$"))
                                && "0".equals(smresponsecode)) {
                    clearSessionAttributes(new String[] {TrustBrokerWebAppConstants.RELYING_APP_URL,
                            TrustBrokerWebAppConstants.RELYING_APP_ID, TrustBrokerWebAppConstants.RELYING_APP_URL_PROF,
                            TrustBrokerWebAppConstants.ACTION, TrustBrokerWebAppConstants.STATUS,
                            TrustBrokerWebAppConstants.TERMS_CONDITON_ACCEPTED, TrustBrokerWebAppConstants.CURRENT_USER,
                            TrustBrokerWebAppConstants.LOGIN_TARGET, TrustBrokerWebAppConstants.RP_LOGO_NAME});
                    this.relyingAppUpdateProfileMsg = null;
                    addLoginTarget();
                    addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS,
                            TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE);
                }
                setRpSuppParam(getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),
                        getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT));

                if (isRequestParamExists(TrustBrokerWebAppConstants.TARGET)
                        && isRequestParamExists(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM)
                        && "0".equals(smresponsecode)) {
                    captureRelyingPartyInfo(getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true : false);
                    processRelyingPartyInfo();
                } else if (getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null
                        && getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) == null
                        && "0".equals(smresponsecode)) {
                    processRelyingPartyInfoForUpdateProfile();
                }
                addSessionAttribute(TrustBrokerWebAppConstants.USER_LOGIN_IND, "true");
                addLoginTarget();
            }
        } catch (Exception ex) {
            LOGGER.error("LoginBean:init() | Error while processing the pramaters and cookies for login request", ex);
        }
    }

    @SuppressWarnings("unchecked")
    public void sendAuthLink() throws IOException {
        Map<String, String> userDetailMap = (Map<String, String>) getSessionAttribute(
                TrustBrokerWebAppConstants.USER_DETAILS_MAP);
        String userName = userDetailMap.get(TrustBrokerWebAppConstants.USER_NAME);
        UserVO userVO = container.getUserService().fetchUserProfile(userName, false, true).getUser();
        userVO.setCreatedBy(getRelyingPartyName());

        String rpAppId = null;
        if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null)
            rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);

        UserAuthorizationRequest userAuthorizationRequest = generateAuthorizationRequest(userVO);
        container.getUserService().sendAuthCodeToUser(userAuthorizationRequest, TrustBrokerConstants.SQA, rpAppId, true,
                getUrlLogoOptumId(), getUrlLogoRelyingParty());
        SecurityLoggingUtil.info("SQA Missing ", SecurityEventType.E3_CREATE, getServletRequest(), userVO.getUserName(),
                "Security Audit Event|SQA Missing authorization code :SUCCESS|Authorization Code sent to User, LoginBean:init()",
                SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_CREATE_AUTH_CODE);
        redirectToView("/views/sentauthorizationcodesqaw.jsf");
    }

    /**
     * Request Handler[POST] for login page.
     *
     * The form fields are validated and authenticate method is called.
     *
     *
     * @return the string - valid sign in navigation page URL if authentication
     *         is success. otherwise returns null [appropriate face error
     *         message is set]
     */
    @RequestMapping(method = RequestMethod.POST)
    public String doNavigation() {
        LOGGER.debug("com.optum.trustbroker.managebean.LoginBean.doNavigation() :Email check" + emailId);
        UserProfileServiceRequest userProfileServiceRequest = null;
        if (validateEmailId(emailId)) {
            try {
                LOGGER.debug(
                        "com.optum.trustbroker.managebean.LoginBean.checkEmail(ValueChangeEvent) :Valid Email " + emailId);
                userProfileServiceRequest = new UserProfileServiceRequest();
                UserVO userVO = new UserVO();
                userVO.setEmailAddress(emailId);
                userProfileServiceRequest.setUser(userVO);
                this.username = container.getUserService().getUserNameDetailByEmail(userProfileServiceRequest);
            } catch (OperationFailedException exception) {
                LOGGER.debug("com.optum.trustbroker.managebean.LoginBean.checkEmail(ValueChangeEvent) :Error  " + emailId);
                this.username = "";
                if (exception.getErrorMessage().getCode().equals(TrustBrokerConstants.OPT_00A0012)) {
                    errorMsg = tbResources.getString("duplicateAccount");
                } else {
                    errorMsg = "No user record was found with this email. Please verify your email address and try again.";
                }
                return null;
            }
        } else {
            this.username = emailId;
        }

        LOGGER.info("LoginBean::doNavigation()");

        if (!validateLoginFields()) {
            return null;
        }

        return fetchUserProfile(getUsername());
    }

    @RequestMapping(method = RequestMethod.GET)
    public String register() {
        if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null) {
            String relAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
            String relAppTarget = "";
            if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null)
                relAppTarget = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
            String retStr = "/views/userregistrationw?" + TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM + "=" + relAppId
                    + "&" + TrustBrokerWebAppConstants.TARGET + "=" + relAppTarget + "&faces-redirect=true";
            LOGGER.debug("gegister() - RP return string: " + retStr);
            return retStr;
        } else {
            getSessionMap().put("registerType", "standAlone");
            return "/views/userregistrationw?faces-redirect=true";
        }
    }

    private void processRelyingPartyInfo() {
        String relyingAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
        relyingPartyTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);

        if (relyingAppId != null) {
            RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService()
                    .fetchRelyingPartyAppByAppId(relyingAppId);
            SupportContactInfoVO sci = getSupportContactInfo();

            if (relyingPartyAppVO == null) {
                setRelyingAppErroMsg(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J003)
                        .getEndUserMessage(container.getErrorMessageSource(), sci));

            } else if (StringUtils.isNotBlank(relyingPartyTargetURL)) {
                addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
                try {
                    String rpDomainName = TBUtil.getDomainName(relyingPartyTargetURL);
                    boolean isdomainValid = false;
                    if (relyingPartyAppVO.getRpAppDomains() != null && relyingPartyAppVO.getRpAppDomains().size() > 0)
                        isdomainValid = isDomainValid(relyingPartyAppVO.getRpAppDomains(), rpDomainName);

                    if (!isdomainValid
                            && (relyingPartyAppVO.getStatusId().intValue() == TrustBrokerConstants.ACTIVE_STATUS)) {
                        setRelyingAppErroMsg(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J002)
                                .getEndUserMessage(container.getErrorMessageSource(), sci));
                    }

                    if (relyingPartyAppVO.getStatusId().intValue() == TrustBrokerConstants.SUSPENDED) {
                        setRelyingAppstatusMsg(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J004)
                                .getEndUserMessage(container.getErrorMessageSource(), sci));
                        if (relyingPartyAppVO.getApplicationName().length() > 0) {
                            setRelyingAppstatusMsg(relyingAppstatusMsg += "</br></br></br>"
                                    + tbResources.getString("denialMessage1") + " " + relyingPartyAppVO.getApplicationName()
                                    + " " + tbResources.getString("denialMessage2"));
                        } else {
                            setRelyingAppstatusMsg(
                                    relyingAppstatusMsg += "</br></br></br>" + tbResources.getString("denialMessage"));
                        }
                    } else if (relyingPartyAppVO.getStatusId().intValue() == TrustBrokerConstants.DEACTIVE_STATUS) {
                        setRelyingAppErroMsg(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J005)
                                .getEndUserMessage(container.getErrorMessageSource(), sci));
                    } else if (StringUtils.isBlank(relyingPartyAppVO.getPartnerId())) {
                        setRelyingAppErroMsg(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00J001)
                                .getEndUserMessage(container.getErrorMessageSource(), sci));
                    }
                } catch (URISyntaxException e) {
                    LOGGER.error(e.getMessage());
                }
            }

            if (StringUtils.isNotBlank(getRelyingAppErroMsg()) || StringUtils.isNotBlank(getRelyingAppstatusMsg())) {
                clearSessionAttributes(new String[] {TrustBrokerWebAppConstants.RELYING_APP_URL,
                        TrustBrokerWebAppConstants.RELYING_APP_ID});
            } else {
                addSessionAttribute(TrustBrokerWebAppConstants.RP_LOGO_NAME, relyingPartyAppVO.getRpLogoFileName());

                removeSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET);

                if (getSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET) != null) {
                    this.targetUrl = (String) getSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET);
                }

                String loginTarget = HttpUtils.addParameterToURL(this.targetUrl,
                        TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, relyingPartyAppVO.getAlias());

                loginTarget = HttpUtils.addParameterToURL(loginTarget, TrustBrokerWebAppConstants.TARGET,
                        relyingPartyTargetURL);
                loginTarget = HttpUtils.addParameterToURL(loginTarget, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM,
                        relyingAppId);
                addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, loginTarget);
            }
        }
        setRpSuppParam(getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),
                getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT));
    }

    private void addLoginTarget() {
        if (!isSessionAttributeExists(TrustBrokerWebAppConstants.LOGIN_TARGET)) {
            addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, HttpUtils.addParameterToURL(getTargetUrl(),
                    TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE));
        }
    }

    private void processRelyingPartyInfoForUpdateProfile() {
        String target = getRequestParameter(TrustBrokerWebAppConstants.TARGET);
        try {
            LOGGER.debug("LoginBean:processRelyingPartyInfoForUpdateProfile() url captured in case of profile update {}",
                    new String[] {target});

            URI targetURL = URI.create(target);
            String hostURI = targetURL.getPath();
            String queryString = targetURL.getQuery();

            if (hostURI != null
                    && (hostURI.contains(tbResources.getString("updateProfileURI"))
                            || hostURI.contains(tbResources.getString("changePasswordURI"))
                            || hostURI.contains(tbResources.getString("updateSecurityQuestion")))
                    && TrustbrokerWebAppUtil.isQueryContainsRelyingPartyContext(queryString)) {

                for (String param : queryString.split("&")) {
                    String pair[] = param.split("=");
                    String key = URLDecoder.decode(pair[0], "UTF-8");
                    String value = "";
                    if (pair.length > 1) {
                        value = URLDecoder.decode(pair[1], "UTF-8");
                    }

                    if (key.equals(TrustBrokerWebAppConstants.TARGET) && StringUtils.isNotBlank(value)) {
                        addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL, value);
                        LOGGER.debug("LoginBean:processRelyingPartyInfoForUpdateProfile() target url parsed {}:",
                                new String[] {value});
                    } else if (key.equals(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM)
                            && StringUtils.isNotBlank(value)) {
                        LOGGER.debug("LoginBean:processRelyingPartyInfoForUpdateProfile() relyingAppId parsed {}:",
                                new String[] {value});
                        addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, value);
                    }
                }

                setTargetUrl(targetURL.getPath());
                addSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET, this.targetUrl); //In case user goes through self-service, preserve it.
                LOGGER.debug("LoginBean:processRelyingPartyInfoForUpdateProfile() SM Login target URL set to :",
                        new String[] {targetURL.getPath()});
                this.relyingAppUpdateProfileMsg = tbResources.getString("updateProfileOTPMsg");
                processRelyingPartyInfo();
            }
        } catch (Exception ex) {
            //Eat up the exception
        }
    }

    /**
     * This is for local environment login only, and is not part of any env login.
     * @param username
     * @return
     */
    private String fetchUserProfile(String username) {
        FacesContext context = getFacesContext();
        UserRetrievalServiceResponse userRetrievalResponse = null;
        ExecutionStatus executionStatus = null;
        UserVO user = null;

        try {
            userRetrievalResponse = container.getUserService().fetchUserDetailsForSession(username);
        } catch (OperationFailedException exception) {
            LOGGER.error("LoginBean::fetchUserProfile()::Failed to fetch profile " + username, exception);
            setUsername("");
            setErrorMsg("");
            context.addMessage(null, new FacesMessage("Invalid Username/Email or Password"));
            context.addMessage(null, new FacesMessage("Reminder: Username and Password are case sensitive"));
            return null;
        }

        executionStatus = userRetrievalResponse.getExecutionStatus();
        user = userRetrievalResponse.getUser();

        if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(executionStatus.getStatusCd()) && user != null) {
            setCurrentUserVO(user);
            return getWidgetHomeURIWithAlias();
        } else {
            LOGGER.info("LoginBean::fetchUserProfile()::ExecutionStatus" + TrustBrokerConstants.FAILURE_CODE_VALUE);
            setUsername("");
            context.addMessage(null, new FacesMessage("Invalid Username/Email or Password "));
            context.addMessage(null, new FacesMessage("Reminder: Username and Password are case sensitive"));
            setErrorMsg("");
            return null;
        }
    }

    /**
     * Server side form fields validation.
     *
     * @return true - if the validation is success. returns false otherwise
     */
    public boolean validateLoginFields() {

        FacesContext context = getFacesContext();

        if (StringUtils.isBlank(getUsername())) {
            context.addMessage(null, new FacesMessage("Invalid Username/Email or Password "));
            context.addMessage(null, new FacesMessage("Reminder: Username and Password are case sensitive"));
            setErrorMsg("");
            return false;
        }

        if (StringUtils.isBlank(getPassword())) {
            context.addMessage(null, new FacesMessage("Invalid Username/Email or Password"));
            setErrorMsg("");
            return false;
        }

        return true;
    }

    /**
     * Gets the faces context
     *
     * @return current FacesContext otherwise
     */
    @Override
    public FacesContext getFacesContext() {
        if (FacesContext.getCurrentInstance() != null) {
            return FacesContext.getCurrentInstance();
        } else {
            if (super.getFacesContext() != null) {
                return super.getFacesContext();
            }
        }
        return super.getFacesContext();
    }

    public String forgotUserNameClicked() {
        removeSessionWithoutRelyingPartyInfo();
        rpTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
        relyingPartyApplicationId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);

        return forgotUserNamePage;
    }

    public String forgotPasswordClicked() {
        removeSessionWithoutRelyingPartyInfo();
        rpTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
        relyingPartyApplicationId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
        return forgotPwdPage;
    }

    @RequestMapping(method = RequestMethod.POST)
    public String signOut() {
        String loggedInUser = null;

        if (getCurrentUserVO() != null) {
            loggedInUser = getCurrentUserVO().getUserName();
            LOGGER.debug("LoginBean:: " + loggedInUser + " Signed out from application");
        }

        String relyintPartyRedirectionParams = getRelyingPartyRedirectionParameters();

        getFacesContext().getExternalContext().invalidateSession();

        if (loggedInUser != null) {
            SecurityLoggingUtil.info("User Login", SecurityEventType.E1_TERMINATE, getServletRequest(), loggedInUser,
                    "Security Audit Event|TerminateUserSession:SUCCESS | User session TERMINATED, LoginBean:signOut()",
                    SecurityEventResult.SUCCESS, getRelyingPartyAppId(), null);
        }

        return relyintPartyRedirectionParams != null ? (LOGOUT_PAGE + "&" + relyintPartyRedirectionParams + "&"
                + TrustBrokerWebAppConstants.RP_APP_REDIRECT_PARAM + "=true") : LOGOUT_PAGE;
    }

    public String unlockUserAccount() {
        addSessionAttribute(TrustBrokerWebAppConstants.ACCOUNT_RECOVERY_BY, TrustBrokerWebAppConstants.USER_NAME);
        addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE,
                TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK);

        addSessionAttribute("SELF_ACC_RECOVER_TYPE", TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK);
        removeSessionAttribute(TrustBrokerWebAppConstants.RECOVERY_BY_EMAIL);

        rpTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
        relyingPartyApplicationId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);

        @SuppressWarnings("unchecked")
        Map<String, String> userDetails = (Map<String, String>) getSessionAttribute(
                TrustBrokerWebAppConstants.USER_DETAILS_MAP);
        UserVO userVO = null;
        try {
            userVO = container.getUserService()
                    .fetchUserProfile((userDetails.get(TrustBrokerWebAppConstants.USER_NAME)), false, true).getUser();
            userDetails.put("emailId", userVO.getEmailAddress());
            userDetails.put("uuId", userVO.getUuId());
            String mobilePhone = null;
            boolean mobilePhoneVerified = false;
            if (StringUtils.isNotBlank(userVO.getPhoneNumber())) {
                mobilePhone = userVO.getPhoneNumber();
                mobilePhoneVerified = userVO.getIsPhoneVerified();
            }
            boolean userHasSecQuestions = false;
            if (!TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(userVO.getAaStatus())) {
                try {
                    UserChallengeQuestionServiceResponse userChallengeResp = getContainer().getUserService()
                            .getChallengeQuestions(userVO.getUuId(),
                                    TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
                    if (null != userChallengeResp
                            && CollectionUtils.isNotEmpty(userChallengeResp.getUserChallengeQuestions())) {
                        userHasSecQuestions = true;
                    }
                } catch (OperationFailedException ofe) {}
            }
            if ((StringUtils.isNotBlank(userVO.getEmailAddress()) && userVO.isIsemailVerified()
                    && userVO.isPrimaryEmailUnique())
                    || (StringUtils.isNotBlank(userVO.getSecEmailAddress()) && userVO.isSecEmailVerified()
                            && userVO.isSecEmailUnique())
                    || (StringUtils.isNotBlank(mobilePhone) && mobilePhoneVerified) || (userHasSecQuestions)) {
                return accountrecoveryoptions;
            } else {
                SupportContactInfoVO sci = getSupportContactInfo();
                Object[] msgArguments = {sci.getContactComboText()};
                setErrorMsg(TBUtil.formatMessage(tbResources.getString("acctNotVerifiedMsg"), msgArguments));
                setUnlockAccount(false);
                return null;
            }
        } catch (OperationFailedException ofe) {
            LOGGER.error("Exception while fetching the user details for user {}", new String[] {
                    userDetails.get(TrustBrokerWebAppConstants.USER_NAME), TrustbrokerWebAppUtil.getUidFromError(ofe)}, ofe);
            return constructURLWithRPParams(loginPage);
        } catch (Exception e) {
            return constructURLWithRPParams(loginPage);
        }
    }

    public boolean getShowRegistration() {
        setShowRegistrationFromSession();
        return showRegistration;
    }

    public void setShowRegistration(boolean val) {
        showRegistration = val;
    }

    public void setShowRegistrationFromSession() {
        String showRegStr = (String) getSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP);
        if (TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP_VAL.equals(showRegStr)) {
            setShowRegistration(false);
        }

    }

    public void checkEmail(ValueChangeEvent event) {
        emailId = event.getNewValue().toString();
        LOGGER.debug("com.optum.trustbroker.managebean.LoginBean.checkEmail(ValueChangeEvent) :Email check" + emailId);
        UserRetrievalServiceResponse userRetrievalResponse = null;
        if (TBUtil.validateEmailId(emailId)) {
            try {
                LOGGER.debug(
                        "com.optum.trustbroker.managebean.LoginBean.checkEmail(ValueChangeEvent) :Valid Email " + emailId);
                userRetrievalResponse = container.getUserService().fetchUserDetailsForSession(emailId);
                this.username = userRetrievalResponse.getUser().getUserName();

            } catch (OperationFailedException exception) {
                LOGGER.error("Error while fetching user details by email id ", emailId);
                setUsername(StringUtils.EMPTY);
                setErrorMsg("No user record was found with this email. Please verify your email address and try again.");
            }
        } else {
            setUsername(getEmailId());
        }
    }

    public void actionListener(ActionEvent event) {
        emailId = getServletRequest().getParameter("EMAIL");
        UserProfileServiceRequest userProfileServiceRequest = null;
        duplicateAccountErrorMsg = null;
        setErrorMsg(null);

        if (TBUtil.validateEmailId(emailId)) {
            try {
                userProfileServiceRequest = new UserProfileServiceRequest();
                UserVO userVO = new UserVO();
                userVO.setEmailAddress(emailId);
                userProfileServiceRequest.setUser(userVO);
                setUsername(container.getUserService().getUserNameDetailByEmail(userProfileServiceRequest));
            } catch (OperationFailedException exception) {
                LOGGER.error("Error while fetching user details by email id ", emailId);
                this.username = "";
                if (exception.getErrorMessage().getCode().equals(TrustBrokerConstants.OPT_00A0012)) {
                    setDuplicateAccountErrorMsg(tbResources.getString("duplicateAccount"));
                } else {
                    setErrorMsg("No user record was found with this email. Please verify your email address and try again.");
                }
            }
        } else {
            setUsername(getEmailId());
        }
    }

    public static boolean validateEmailId(String enteredEmailId) {
        if (StringUtils.isNotEmpty(enteredEmailId)) {
            EmailDetail emailDetail = new EmailDetail();
            emailDetail.setEmailAddress(enteredEmailId);
            emailDetail.setLabel("EMAIL");
            try {
                ValidationUtilities.isValidEmail(emailDetail);
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    public String getRelyingAppUpdateProfileMsg() {
        return relyingAppUpdateProfileMsg;
    }

    public void setRelyingAppUpdateProfileMsg(String relyingAppUpdateProfileMsg) {
        this.relyingAppUpdateProfileMsg = relyingAppUpdateProfileMsg;
    }

    private String buildErrorMessage(String errorCode) {
        String errMsg = null;
        errMsg = TrustBrokerUtil.getErrorMessage(errorCode).getEndUserMessage(container.getErrorMessageSource(),
                getSupportContactInfo());
        return errMsg;
    }

    public boolean isDomainValid(List<RPAppDomainVO> domains, String domainName) {
        return TBUtil.isDomainValid(domains, domainName);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = StringUtils.trim(username);
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = StringUtils.trim(password);
    }

    public String getDuplicateAccountErrorMsg() {
        return duplicateAccountErrorMsg;
    }

    public void setDuplicateAccountErrorMsg(String duplicateAccountErrorMsg) {
        this.duplicateAccountErrorMsg = duplicateAccountErrorMsg;
    }

    public String getEmailMsg() {
        return emailMsg;
    }

    public void setEmailMsg(String emailMsg) {
        this.emailMsg = emailMsg;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPwdChangeSuccessMsg() {
        return pwdChangeSuccessMsg;
    }

    public void setPwdChangeSuccessMsg(String pwdChangeSuccessMsg) {
        this.pwdChangeSuccessMsg = pwdChangeSuccessMsg;
    }

    public String getRelyingAppstatusMsg() {
        return relyingAppstatusMsg;
    }

    public void setRelyingAppstatusMsg(String relyingAppstatusMsg) {
        this.relyingAppstatusMsg = relyingAppstatusMsg;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getTargetUrl() {
        return targetUrl;
    }

    public void setTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
    }

    public String getLocalenv() {
        return localenv;
    }

    public void setLocalEnv(String localenv) {
        this.localenv = localenv;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getRelyingAppErroMsg() {
        return relyingAppErroMsg;
    }

    public void setRelyingAppErroMsg(String relyingAppErroMsg) {
        this.relyingAppErroMsg = relyingAppErroMsg;
    }

    public boolean isUnlockAccount() {
        return unlockAccount;
    }

    public void setUnlockAccount(boolean unlockAccount) {
        this.unlockAccount = unlockAccount;
    }

    public String signInClicked() {
        return loginPage;
    }
}