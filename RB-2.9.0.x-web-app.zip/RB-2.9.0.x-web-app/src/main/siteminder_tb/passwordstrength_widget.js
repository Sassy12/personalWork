
function checkPasswordStrength(pwdFieldId, username){

        var weak='<strong><font color="white">Weak</font></strong>';
        var medium='<strong><font color="white">Good</font></strong>';
        var strong='<strong><font color="white">Strong</font></strong>';
        var barId =  'bar';
        var pwdId =  pwdFieldId;
        var bar = document.getElementById(barId);
        var cell = bar.parentNode;
         
        var password =  document.getElementById(pwdId).value;
        
        
        var checks = new Array();
        var strength = getStrength(password, checks, username);
        
        var returnVal = 'Weak';
        
		if(strength== 'N')
        {
             bar.innerHTML='';
             cell.className='nocolor';
        }
		else if(strength =='W')
		{
			 returnVal = 'Weak';            
			bar.innerHTML=weak;
           cell.className='weak';
		}
		else if(strength =='S')
		{             
			returnVal = 'Strong'; 
                        bar.innerHTML=strong;	
                        cell.className='strong';
		}
		else if(strength =='M')
        {               
			returnVal = 'Good'; 
                        bar.innerHTML=medium;;
                        cell.className='medium';	
		}
		else
		{
			returnVal = 'Good'; 
                       bar.innerHTML=medium;
                       cell.className='medium';
		}
		
		return returnVal;
  };
 
  
function  getStrength(pwd, checks, username){
  
   var minLength=8;
   var maxLength=100;
   var strength='N';
   var upperPresent=false;
   var lowerPresent=false;
   var numberPresent=false;
   var specialCharPresent=false;
   var isEmpty=false;
   var incorrectLength=false;
   var ampersandPresent=false;
   
   if(!String.prototype.trim){  
       pwd = strTrim(pwd);     
   }else
       pwd = pwd.trim();
   
   if(pwd =="")
     isEmpty=true;
   
   var array = new Array(127);
   for(i=0; i <=127; i++)
     array[i]=0;
  
  
   for(i=0;i<pwd.length;i++){
    var a = pwd.charAt(i).charCodeAt(0);
     if(a > -1 && a<= 126 ){ //non ascii actually not allowed
        if(a>=65 && a<=90)
            upperPresent = true;
        else  if(a>=97 && a<=122)
            lowerPresent=true;
        else if(a>=48 && a<=57)
            numberPresent =true;
        else if(a==38)
        	ampersandPresent=true;
        else if(a != 32)
            specialCharPresent=true;
            
        array[a] = array[a]+1;
     }
   }
  
  
    
   var strengthCounter=0;
   
   if(upperPresent)
      strengthCounter++;
   if(lowerPresent)
      strengthCounter++;
   if(numberPresent)
      strengthCounter++;
   if(specialCharPresent)
	  strengthCounter++;
   if(incorrectLength)
      strengthCounter=0;

   strength='W';   
   if(strengthCounter == 2)
        strength= 'W'; 
   if(strengthCounter == 3 && upperPresent && lowerPresent && numberPresent)
       strength= 'M'; 
   if(strengthCounter == 4)
        strength= 'S';
   

  if (pwd.length < minLength){
     incorrectLength=true;
     strength= 'W';
   }
   
   if (pwd.length > maxLength){
	     incorrectLength=true;
	     strength= 'W';
   }
   
  
   if(isEmpty)
      strength='N';
  
   checks[0] = incorrectLength;
   checks[1] = lowerPresent;
   checks[2] = upperPresent;
   checks[3] = numberPresent;
   checks[4] = specialCharPresent;
   checks[5] = ampersandPresent;
   checks[6] = isEmpty;
  
  
   return strength;
 };

 var charLenght;
 var upperCase;
 var lowerCase;
 var numeric;
 var nonAlpha;
 
  function displayPasswordRules( pwdFieldId, popUpId, username){
      
	  var strength =  checkPasswordStrength(pwdFieldId,username);
	  
    var fntSz="";
    if (navigator.appName == 'Microsoft Internet Explorer')
       fntSz=" font-size: 12px;";

    var popUp = document.getElementById(popUpId);
    var password =  document.getElementById(pwdFieldId).value;
    var checks = new Array(false,false,false,false,false,false,false,false,false,false,false);
    getStrength(password, checks, username);
    
    var htmlText = '<div class="oxnamevalidate" style="display: block;'+fntSz+'"><div style="border:1px solid black;margin-top: 1px;" > <ul>';
    //var spanRuleFailText='<span class="met"></span>';
   // var spanRulePassText='<span class="not met"></span>';
    var spanRuleFailText='<img style="margin-top:-4px;vertical-align:middle;" alt="" src="checkfail.png" >';
    var spanRulePassText='<img style="margin-top:-4px;vertical-align:middle;" alt="" src="checkpass.png" >';

    var spanNonAlphaText='<span class="nonalpha"></span>';

    var validTrue = '&#160;<span class="oui-a11y-hidden">&#160;has been met</span></span> ';
    var validFalse = '&#160;<span class="oui-a11y-hidden">&#160;not yet met</span></span> ';    
    var incorrectLength =  checks[0];
    var lowerPresent = checks[1];
    var upperPresent = checks[2];
    var numberPresent = checks[3];
    var specialCharPresent = checks[4];
    var ampersandPresent = checks[5];
    var isEmpty = checks[6];
   
    var validMsg0=validFalse;
    var validMsg1=validFalse;
    var validMsg2=validFalse;
    var validMsg3=validFalse; 	

    htmlText +='<li id="passwordInput:rule5" role="presentation">';
    htmlText += '<span class="oui-a11y-hidden">Password strength: '+ strength +' </span></li>';

    htmlText +='<li id="rule0">';
    htmlText += (incorrectLength) ? spanRuleFailText : spanRulePassText;
    if( !incorrectLength)
     validMsg0 = validTrue;
    htmlText += '<span class="ruletext">8 characters or more </span>'+validMsg0+'</li>';
    
    htmlText +='<li id="rule1">'; 
    if( upperPresent)
     validMsg1 = validTrue;    
    htmlText += (!(upperPresent)) ? spanRuleFailText : spanRulePassText;
    htmlText += '<span class="ruletext">Uppercase characters </span>'+validMsg1+'</li>';
    
    htmlText +='<li id="rule2">';
    if( lowerPresent)
     validMsg2 = validTrue;   
    htmlText += ((!lowerPresent)) ? spanRuleFailText : spanRulePassText;   
    htmlText += '<span class="ruletext">Lowercase characters </span>'+validMsg2+'</li>';
    
    htmlText +='<li id="rule3">';
    if( numberPresent)
     validMsg3 = validTrue;
    htmlText += ((!numberPresent)) ? spanRuleFailText : spanRulePassText;   
    htmlText += '<span class="ruletext">Numeric </span>'+validMsg3+'</li>';
    
    var nonAlphaValid= ((specialCharPresent)) ? validTrue : "";
    htmlText +='<li id="passwordInput:rule4" class="rulenonalphatext">';
    htmlText += ((specialCharPresent)) ? spanRulePassText : spanNonAlphaText;
    htmlText += '<span class="ruletext">Non-alphanumeric characters  </span>&#160;<span class="oui-a11y-hidden"> optional '+nonAlphaValid+'</span></li>';
    
    popUp.style.display = 'block';
    popUp.innerHTML = htmlText;
    
    //check change in the popup and accordingly add aria-live
    var charLenghtTemp = document.getElementById("rule0").innerHTML;
 	var upperCaseTemp = document.getElementById("rule1").innerHTML;
 	var lowerCaseTemp = document.getElementById("rule2").innerHTML ;
 	var numericTemp = document.getElementById("rule3").innerHTML; 
 	var nonAlphaTemp = document.getElementById("passwordInput:rule4").innerHTML;
 	

 	var rawElement = document.getElementById("passwordPanel");
 	
 	
 	
 	if(charLenght!=charLenghtTemp || upperCase!=upperCaseTemp || lowerCase!= lowerCaseTemp || numeric!=numericTemp || nonAlpha!= nonAlphaTemp  ){
 		//aria live assertive
 		rawElement.setAttribute("aria-live", "assertive");
 	}else{
 		//remove aria live asseritve
 		rawElement.removeAttribute("aria-live");
 	}
 	
 	if(charLenght!=charLenghtTemp)
 		charLenght=charLenghtTemp;
 	
 	if(upperCase!=upperCaseTemp)
 	upperCase=upperCaseTemp;
 	
 	if(lowerCase!= lowerCaseTemp)
 		lowerCase= lowerCaseTemp;
 	
 	if(numeric!=numericTemp)
 		numeric=numericTemp;
 	
 	if(nonAlpha!= nonAlphaTemp)
 		nonAlpha= nonAlphaTemp;
  }
  
  function hidePasswordRules( popUpId) {
	document.getElementById(popUpId).style.display = 'none';
  }
  function strTrim(x) {
	    return x.replace(/^\s+|\s+$/gm,'');
  }