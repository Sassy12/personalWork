package com.optum.trustbroker.controller.vo.idproof;

import com.optum.trustbroker.vo.IDProofingQuizVO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.optum.trustbroker.vo.IDProofingQuizAnswer;
import com.optum.trustbroker.vo.IDProofingQuizQuestion;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class ProofQuizRequest implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
	private String transactionId;
	private List<Question> questions;
	private boolean sendFailureEmail;

	public IDProofingQuizVO buildToIdProofingQuizVO() {
		IDProofingQuizVO ipqVo = new IDProofingQuizVO();
		ipqVo.setQuizId(id);
		ipqVo.setQuizTransactionId(transactionId);
		ipqVo.setQuestions(new ArrayList<IDProofingQuizQuestion>());
		for (Question q : getQuestions()) {
			if (q != null) {
				IDProofingQuizQuestion ipqQ = new IDProofingQuizQuestion();
				ipqQ.setAnswerId(q.getAnswerId());
				ipqQ.setQuestionId(q.getQuestionId());
				ipqQ.setQuestionText(q.getText());
				ipqQ.setAnswers(new ArrayList<IDProofingQuizAnswer>());
				for (Answer a : q.getAnswers()) {
					if (a != null) {
						IDProofingQuizAnswer ipqA = new IDProofingQuizAnswer();
						ipqA.setAnswerId(a.getId());
						ipqA.setAnswerText(a.getText());
						ipqQ.getAnswers().add(ipqA);
					}
				}
				ipqVo.getQuestions().add(ipqQ);
			}
		}
		return ipqVo;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public List<Question> getQuestions() {
		if (questions == null) {
			questions = new ArrayList<Question>();
		}
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	public boolean isSendFailureEmail() {
		return sendFailureEmail;
	}

	public void setSendFailureEmail(boolean sendFailureEmail) {
		this.sendFailureEmail = sendFailureEmail;
	}
}
