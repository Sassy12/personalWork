/*
 *Copyright (c) Optum 2016 - All Rights Reserved.
 */
'use strict';
angular.module('tbApp').controller('ConsentCtrl',['$scope','rpData','LanguageService','$window','ConsentService', 'HelpObj', ConsentCtrl]);

function ConsentCtrl($scope,rpData,LanguageService,$window, ConsentService, HelpObj){
	
	HelpObj.setHelpObj({url:'../../webHelp/Default_CSH.htm#Optum ID CSH/entry_1018_Consent.htm'});
	
	LanguageService.doTranslate('consent');
	$scope.appName=rpData.data.rpAppName;
	$scope.showDob=rpData.data.showDob;
	
	$scope.agreeToConsent =function(){
		ConsentService.agreeConsent().then(function(){
			$window.location= '/tb/app/secure/home.do';
	    	});
	};
	
	$scope.onCancel =function(){
		$window.location= '/tb/app/index.html';
	};
}