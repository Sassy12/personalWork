package com.optum.trustbroker.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.ImmutableMap;
import com.optum.trustbroker.auditlogging.IDProofingAuditTypes;
import com.optum.trustbroker.auditlogging.IDProofingLoggingUtil;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.controller.vo.idproof.GenerateQuizRequest;
import com.optum.trustbroker.controller.vo.idproof.GenerateQuizResponse;
import com.optum.trustbroker.controller.vo.idproof.ProofQuizRequest;
import com.optum.trustbroker.controller.vo.idproof.ProofQuizResponse;
import com.optum.trustbroker.controller.vo.idproof.ProofUserInfoRequest;
import com.optum.trustbroker.controller.vo.idproof.ProofUserInfoResponse;
import com.optum.trustbroker.controller.vo.idproof.TypeResponse;
import com.optum.trustbroker.service.IDProofingService;
import com.optum.trustbroker.service.UserTagService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.UuidUtil;
import com.optum.trustbroker.vo.AddressVO;
import com.optum.trustbroker.vo.ExecutionStatus;
import com.optum.trustbroker.vo.IDProofingQuizServiceRequest;
import com.optum.trustbroker.vo.IDProofingQuizServiceResponse;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.TagVO;
import com.optum.trustbroker.vo.UserTagServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceResponse;
import com.optum.trustbroker.vo.UserVO;

/**
 * basic info to verify: first name, last name, date of birth, street address, city, state, zip
 *
 * LOA3 info to verify: credit card number, ssn
 *
 * either approach can get quiz questions
 *
 * @author nvaneps
 */
@Service
@Path(TBConstants.ID_PROOFING_CONTROLLER_PATH)
public class IdProofingController extends BaseController {

    public static final String LOA3_IDP_TAG_CD_PARAM_KEY = "loa3_idp_tag_code";

    public static final String BASIC_IDP_TAG_CD_PARAM_KEY = "basic_idp_tag_code";

    public static final String LOA3NQ_IDP_TAG_CD_PARAM_KEY = "loa3_nq_idp_tag_code";

    public static final String BASICNQ_IDP_TAG_CD_PARAM_KEY = "basic_nq_idp_tag_code";
    
    private static final BaseLogger LOG = new BaseLogger(IdProofingController.class);

    @Autowired
    private UserTagService userTagService;

    @Autowired
    private IDProofingService idProofingService;

    @GET
    @Path("/user")
    @Produces(MediaType.APPLICATION_JSON)
    public UserInfoVO getUser(@Context HttpServletResponse httpServletResponse) {
        UserInfoVO userInfoVo = new UserInfoVO();
        UserVO userVo = getCurrentUser();
        if (userVo != null) {
            userInfoVo.setUuid(userVo.getUuId());
            userInfoVo.setFirstName(userVo.getFirstName());
            userInfoVo.setLastName(userVo.getLastName());
            userInfoVo.setUserName(userVo.getUserName());
            userInfoVo.setEmailAddress(userVo.getEmailAddress());
            if (null != userVo.getDob()) {
                userInfoVo.setDateOfBirth(DateUtil.formatDate(userVo.getDob(), DateUtil.EXT_DATE_FORMAT2));
            }

            List<AddressVO> addresses = userVo.getAddresses();
            if (CollectionUtils.isNotEmpty(addresses)) {
                for (AddressVO address : addresses) {
                    if (address.isDefaultAddress()
                            || TrustBrokerConstants.ADDRESS_TYPE_WORK.equalsIgnoreCase(address.getAddressType())) {
                        userInfoVo.setAddress(new com.optum.trustbroker.controller.vo.AddressVO());
                        userInfoVo.getAddress().fromAddress(address);
                    }
                }
            }
            buildSuccess(userInfoVo, httpServletResponse);
        } else {
            buildBadRequest("missing.user", userInfoVo);
        }
        return userInfoVo;
    }

    @GET
    @Path(value = "/type")
    @Produces(MediaType.APPLICATION_JSON)
    public TypeResponse type(@Context HttpServletResponse httpServletResponse) {
        TypeResponse typeResp = new TypeResponse();
        UserVO userVo = getCurrentUser();
        if (userVo == null) {
            buildBadRequest("missing.user", typeResp);
            return typeResp;
        }
        buildSuccess(typeResp, httpServletResponse);
        RelyingPartyAppVO rpAppVo = getRPContext();
        if (rpAppVo != null) {
            TagVO tagVo = relyingPartyIdProofingTag(rpAppVo);
            LOG.debug("user uuid: " + userVo.getUuId());
            if (tagVo != null) {
                LOG.debug(String.format("id proofing name & code: %s & %s", tagVo.getName(), tagVo.getTagCode()));
                if (BooleanUtils.isFalse(isUserAlreadyIdProofed(userVo, tagVo))) {
                    typeResp.setCode(tagVo.getTagCode());
                    return typeResp;
                }
                LOG.debug("user is already id proofed");
            }
        }
        LOG.debug("no id proofing required");
        typeResp.setCode("none");
        return typeResp;
    }

    @POST
    @Path(value = "/proof-user-info")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public ProofUserInfoResponse proofUserInfo(ProofUserInfoRequest req, @Context HttpServletRequest httpServletRequest,
            @Context HttpServletResponse httpServletResponse) {

        ProofUserInfoResponse resp = new ProofUserInfoResponse();
        // Validate request before processing further
        if (req == null) {
            buildBadRequest("missing.request.data", resp);
            return resp;
        }

        final UserVO userVo = getCurrentUser();
        if (userVo == null) {
            buildBadRequest("missing.user", resp);
            return resp;
        }
        RelyingPartyAppVO rpAppVo = getRPContext();
        if (rpAppVo == null) {
            buildBadRequest("missing.relying.party", resp);
            return resp;
        }
        TagVO tagVo = relyingPartyIdProofingTag(rpAppVo);
        if (tagVo == null) {
            buildBadRequest("id.proofing.not.required", resp);
            return resp;
        }

        List<String> errors = validUserInfo(userVo, req.getSocialSecurityNumber(), req.getCreditCardNumber(), tagVo);
        if (CollectionUtils.isNotEmpty(errors)) {
            buildBadRequest("invalid.request.data", resp);
            for (String error : errors) {
                resp.getErrorMap().put(error, error);
            }
            return resp;
        }

        IDProofingQuizServiceRequest proofReq = new IDProofingQuizServiceRequest();
        proofReq.setVerificationFlow(getVerificationFlow(tagVo));
        proofReq.setUser(userVo);
        if (isLoa3Flow(tagVo)) {
            proofReq.setCreditCardNumber(req.getCreditCardNumber());
            if (StringUtils.isNotEmpty(req.getSocialSecurityNumber())) {
                proofReq.setSsn(req.getSocialSecurityNumber().replace("-", ""));
            }
        }
        IDProofingQuizServiceResponse proofResp = idProofingService.generateQuiz(proofReq);
        LOG.debug("execution status code after generateQuiz call: " + proofResp.getExecutionStatus().getStatusCd());
        LOG.debug("execution status message after generateQuiz call: " + proofResp.getExecutionStatus().getStatusMessage());
        IDProofingLoggingUtil.info(getIDProofingAuditType(proofReq.getVerificationFlow(), true), rpAppVo.getApplicationId(),
                userVo.getUserName(), getErrorReasonCode(proofResp.getExecutionStatus()),
                "IdProofingController:proofUserInfo()", httpServletRequest);
        if (TrustbrokerWebAppUtil.checkResponseStatus(proofResp)) {
            UserTagServiceRequest userTagRequest = new UserTagServiceRequest();
            userTagRequest.setTagName(tagVo.getName());
            userTagRequest.setUser(userVo);
            userTagService.addUserTag(userTagRequest, proofResp.getVerificationCode());
            buildSuccess(resp, httpServletResponse);
        } else {
            processStatusCode(proofResp, resp, tagVo);
        }
        return resp;
    }

    @POST
    @Path(value = "/generate-quiz")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public GenerateQuizResponse generateQuiz(GenerateQuizRequest req, @Context HttpServletRequest httpServletRequest,
            @Context HttpServletResponse httpServletResponse) {
        
        /* TODO proofUserInfo() and generateQuiz methods are using same logic to validate user data.  
                Please create common method and reuse when we implement id proofing with knowledge base questions */
        
        GenerateQuizResponse resp = new GenerateQuizResponse();
        if (req == null) {
            buildBadRequest("missing.request.data", resp);
            return resp;
        }
        UserVO userVo = getCurrentUser();

        if (userVo == null) {
            buildBadRequest("missing.user", resp);
            return resp;
        }
        RelyingPartyAppVO rpAppVo = getRPContext();
        if (rpAppVo == null) {
            buildBadRequest("missing.relying.party", resp);
            return resp;
        }
        TagVO tagVo = relyingPartyIdProofingTag(rpAppVo);
        if (tagVo == null) {
            buildBadRequest("id.proofing.not.required", resp);
            return resp;
        }
        List<String> errors = validUserInfo(userVo, req.getSocialSecurityNumber(), req.getCreditCardNumber(), tagVo);
        if (!errors.isEmpty()) {
            buildBadRequest("invalid.request.data", resp);
            for (String error : errors) {
                resp.getErrorMap().put(error, error);
            }
            return resp;
        }

        IDProofingQuizServiceRequest proofReq = new IDProofingQuizServiceRequest();
        proofReq.setVerificationFlow(getVerificationFlow(tagVo));
        proofReq.setUser(userVo);
        if (isLoa3Flow(tagVo)) {
            proofReq.setCreditCardNumber(req.getCreditCardNumber());
            proofReq.setSsn(req.getSocialSecurityNumber());
        }
        IDProofingQuizServiceResponse proofResp = idProofingService.generateQuiz(proofReq);
        LOG.debug("execution status code after generateQuiz call: " + proofResp.getExecutionStatus().getStatusCd());
        LOG.debug("execution status message after generateQuiz call: " + proofResp.getExecutionStatus().getStatusMessage());
        IDProofingLoggingUtil.info(getIDProofingAuditType(proofReq.getVerificationFlow(), true), rpAppVo.getApplicationId(),
                userVo.getUserName(), getErrorReasonCode(proofResp.getExecutionStatus()),
                "IdProofingController:generateQuiz()", httpServletRequest);
        if (TrustbrokerWebAppUtil.checkResponseStatus(proofResp)) {
            resp.buildFrom(proofResp);
            buildSuccess(resp, httpServletResponse);
        } else {
            processStatusCode(proofResp, resp, tagVo);
        }
        return resp;
    }

    @POST
    @Path(value = "/proof-quiz")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public ProofQuizResponse proofQuiz(ProofQuizRequest req, @Context HttpServletRequest httpServletRequest,
            @Context HttpServletResponse httpServletResponse) {
        ProofQuizResponse resp = new ProofQuizResponse();
        if (req == null) {
            buildBadRequest("missing.request.data", resp);
            return resp;
        }
        resp.setId(req.getId());
        resp.setTransactionId(req.getTransactionId());
        UserVO userVo = getCurrentUser();
        if (userVo == null) {
            buildBadRequest("missing.user", resp);
            return resp;
        }
        RelyingPartyAppVO rpAppVo = getRPContext();
        if (rpAppVo == null) {
            buildBadRequest("missing.relying.party", resp);
            return resp;
        }
        TagVO tagVo = relyingPartyIdProofingTag(rpAppVo);
        if (tagVo == null) {
            buildBadRequest("id.proofing.not.required", resp);
            return resp;
        }

        IDProofingQuizServiceRequest idqsReq = new IDProofingQuizServiceRequest();
        idqsReq.setIdProofingQuizVO(req.buildToIdProofingQuizVO());
        idqsReq.setVerificationFlow(getVerificationFlow(tagVo));

        IDProofingQuizServiceResponse ipResp = idProofingService.processQuiz(idqsReq, userVo.getEmailAddress(),
                getUrlLogin(httpServletRequest), req.isSendFailureEmail(), rpAppVo.getApplicationId(),
                getUrlLogoOptumId(httpServletRequest), getUrlLogoRelyingParty(httpServletRequest));

        LOG.debug("execution status code after processQuiz call: " + ipResp.getExecutionStatus().getStatusCd());
        LOG.debug("execution status message after processQuiz call: " + ipResp.getExecutionStatus().getStatusMessage());
        if (TrustbrokerWebAppUtil.checkResponseStatus(ipResp)) {
            IDProofingLoggingUtil.info(
                    isLoa3Flow(tagVo) ? IDProofingAuditTypes.SVC_IDP_LOA3_QUIZ_SUCCESS
                            : IDProofingAuditTypes.SVC_IDP_BASIC_QUIZ_SUCCESS,
                    rpAppVo.getApplicationId(), userVo.getUserName(), getErrorReasonCode(ipResp.getExecutionStatus()),
                    "IdProofingController:proofQuiz()", httpServletRequest);
            UserTagServiceRequest userTagRequest = new UserTagServiceRequest();
            userTagRequest.setTagName(tagVo.getName());
            userTagRequest.setUser(userVo);
            userTagService.addUserTag(userTagRequest, ipResp.getVerificationCode());
            buildSuccess(resp, httpServletResponse);
        } else {
            buildForbidden(ipResp.getExecutionStatus().getStatusMessage(), resp);
        }
        return resp;
    }

    private boolean isLoa3Flow(TagVO tagVo) {
        if (StringUtils.isNotBlank(tagVo.getTagAlias())) {
            return Arrays.asList(TrustBrokerWebAppConstants.LOA3_ID_PROOF, TrustBrokerWebAppConstants.LOA3_ID_PROOF_NO_KBQ)
                    .contains(tagVo.getTagAlias().toUpperCase());
        }
        return false;
    }

    private String getVerificationFlow(TagVO tagVo) {
        LOG.debug("In getVerificationFlow method");
        if (StringUtils.isNotBlank(tagVo.getTagAlias())) {
            LOG.debug("Tag Alias value: " + tagVo.getTagAlias());
            Map<String, String> flowMap = ImmutableMap.of(TrustBrokerWebAppConstants.BASIC_ID_PROOF,
                    configProps.getProperty(TrustBrokerWebAppConstants.BASIC_IDP_VERIFN_FLOW_PARAM_KEY),
                    TrustBrokerWebAppConstants.BASIC_ID_PROOF_NO_KBQ,
                    configProps.getProperty(TrustBrokerWebAppConstants.BASICNQ_IDP_VERIFN_FLOW_PARAM_KEY),
                    TrustBrokerWebAppConstants.LOA3_ID_PROOF,
                    configProps.getProperty(TrustBrokerWebAppConstants.LOA3_IDP_VERIFN_FLOW_PARAM_KEY),
                    TrustBrokerWebAppConstants.LOA3_ID_PROOF_NO_KBQ,
                    configProps.getProperty(TrustBrokerWebAppConstants.LOA3NQ_IDP_VERIFN_FLOW_PARAM_KEY));
            LOG.debug("flowMap: " + flowMap);
            LOG.debug("Verification flow in controller: " + flowMap.get(tagVo.getTagAlias().toUpperCase()));
            return flowMap.get(tagVo.getTagAlias().toUpperCase());
        }
        return null;
    }

    /**
     * This method is to get the Id proofing audit event type based on verification flow and success/failure flag
     *
     * @param verificationFlow
     * @param success
     * @return IDProofingAuditTypes
     */
    private IDProofingAuditTypes getIDProofingAuditType(String verificationFlow, boolean success) {
        Map<String, IDProofingAuditTypes> successMap = ImmutableMap.of(
                configProps.getProperty(TrustBrokerWebAppConstants.BASIC_IDP_VERIFN_FLOW_PARAM_KEY),
                IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_SUCCESS,
                configProps.getProperty(TrustBrokerWebAppConstants.BASICNQ_IDP_VERIFN_FLOW_PARAM_KEY),
                IDProofingAuditTypes.SVC_IDP_BASICNQ_LOCATE_SUCCESS,
                configProps.getProperty(TrustBrokerWebAppConstants.LOA3_IDP_VERIFN_FLOW_PARAM_KEY),
                IDProofingAuditTypes.SVC_IDP_LOA3_LOCATE_SUCCESS,
                configProps.getProperty(TrustBrokerWebAppConstants.LOA3NQ_IDP_VERIFN_FLOW_PARAM_KEY),
                IDProofingAuditTypes.SVC_IDP_LOA3NQ_LOCATE_SUCCESS);

        Map<String, IDProofingAuditTypes> failureMap = ImmutableMap.of(
                configProps.getProperty(TrustBrokerWebAppConstants.BASIC_IDP_VERIFN_FLOW_PARAM_KEY),
                IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_FAIL,
                configProps.getProperty(TrustBrokerWebAppConstants.BASICNQ_IDP_VERIFN_FLOW_PARAM_KEY),
                IDProofingAuditTypes.SVC_IDP_BASICNQ_LOCATE_FAIL,
                configProps.getProperty(TrustBrokerWebAppConstants.LOA3_IDP_VERIFN_FLOW_PARAM_KEY),
                IDProofingAuditTypes.SVC_IDP_LOA3_LOCATE_FAIL,
                configProps.getProperty(TrustBrokerWebAppConstants.LOA3NQ_IDP_VERIFN_FLOW_PARAM_KEY),
                IDProofingAuditTypes.SVC_IDP_LOA3NQ_LOCATE_FAIL);

        return success ? successMap.get(verificationFlow) : failureMap.get(verificationFlow);
    }

    private String getErrorReasonCode(ExecutionStatus exStatus) {
        String errorReasonCD = "";
        if (exStatus.getStatusCodesList() != null) {
            for (String code : exStatus.getStatusCodesList()) {
                errorReasonCD += code + ",";
            }
        }
        if (errorReasonCD.length() > 0) {
            errorReasonCD = errorReasonCD.substring(0, errorReasonCD.length() - 1);
        }
        return errorReasonCD;
    }

    private AddressVO getHomeAddress(UserVO userVO) {
        for (AddressVO add : userVO.getAddresses()) {
            if (TrustBrokerConstants.ADDRESS_TYPE_HOME.equals(add.getAddressType())) {
                return add;
            }
        }
        return userVO.getAddresses().get(0);
    }

    private List<String> validUserInfo(UserVO userVo, String ssn, String ccn, TagVO tagVo) {
        List<String> errors = new ArrayList<String>();
        if (StringUtils.isBlank(userVo.getFirstName())) {
            errors.add("missing first name");
        }
        if (StringUtils.isBlank(userVo.getLastName())) {
            errors.add("missing last name");
        }
        if (userVo.getDob() == null) {
            errors.add("missing date of birth");
        }
        AddressVO homeAddresss = getHomeAddress(userVo);
        if (StringUtils.isBlank(homeAddresss.getStreetAddress())) {
            errors.add("missing street address");
        }
        if (StringUtils.isBlank(homeAddresss.getCity())) {
            errors.add("missing city");
        }
        if (StringUtils.isBlank(homeAddresss.getZip())) {
            errors.add("missing zip");
        }
        if (StringUtils.isBlank(homeAddresss.getState())) {
            errors.add("missing state");
        }
        if (isLoa3Flow(tagVo)) {
            if (StringUtils.isBlank(ssn)) {
                errors.add("blank ssn");
            } else if (ssn.length() != 11) {
                errors.add("ssn not a 11 digit number");
            }
            if (StringUtils.isBlank(ccn)) {
                errors.add("blank credit card number");
            } else if (ccn.length() != 5 || !StringUtils.isNumeric(ccn)) {
                errors.add("credit card not a 5 digit number");
            }
        }
        return errors;
    }

    // relying party id proofing tags are mutually exclusive
    private TagVO relyingPartyIdProofingTag(RelyingPartyAppVO relyingPartyAppVO) {
        List<TagVO> tagVOList = relyingPartyAppVO.getTags();
        if (tagVOList != null) {
            for (TagVO tagVO : tagVOList) {
                if (tagVO != null && tagVO.getVerifyAtSignIn()) {
                    LOG.debug("verify at sign in: " + tagVO.getVerifyAtSignIn());
                    LOG.debug("tag code: " + tagVO.getTagCode());
                    if (Arrays.asList(configProps.getProperty(BASIC_IDP_TAG_CD_PARAM_KEY),
                            configProps.getProperty(BASICNQ_IDP_TAG_CD_PARAM_KEY),
                            configProps.getProperty(LOA3_IDP_TAG_CD_PARAM_KEY),
                            configProps.getProperty(LOA3NQ_IDP_TAG_CD_PARAM_KEY)).contains(tagVO.getTagCode())) {
                        return tagVO;
                    }
                }
            }
        }
        return null;
    }

    private boolean isUserAlreadyIdProofed(UserVO userVo, TagVO tagVo) {
        String tagName = tagVo.getName();
        UserTagServiceRequest userTagServiceRequest = new UserTagServiceRequest();
        userTagServiceRequest.setTagName(tagName);
        userTagServiceRequest.setUser(userVo);
        UserTagServiceResponse userTagResp = userTagService.queryAllUserTag(userTagServiceRequest);
        if (TrustbrokerWebAppUtil.checkResponseStatus(userTagResp)) {
            if (tagName != null && CollectionUtils.isNotEmpty(userTagResp.getTagVOList())) {
                for (TagVO userTag : userTagResp.getTagVOList()) {
                    if (StringUtils.equals(userTag.getName(), tagName)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void processStatusCode(IDProofingQuizServiceResponse serviceResponse, ResponseVO respVo, TagVO tagVo) {
        Map<String, String> internalServerErrorMap = ImmutableMap.of(TrustBrokerConstants.SYSTEM_ERROR_CODE_VALUE,
                "systemError", TrustBrokerConstants.BAD_REQUEST_CODE_VALUE, "systemError");

        Map<String, String> badReqErrorMap = ImmutableMap.<String, String> builder()
                .put(TrustBrokerConstants.FAILURE_CODE_VALUE, "verifyIDInvalidAccount")
                .put(TrustBrokerConstants.ID_PROOFING_ERROR_ID1, "errorMsg_ID1")
                .put(TrustBrokerConstants.ID_PROOFING_ERROR_QP2, "errorMsg_QP2")
                .put(TrustBrokerConstants.ID_PROOFING_ERROR_QP3, "errorMsg_QP3")
                .put(TrustBrokerConstants.ID_PROOFING_ERROR_QP4, "errorMsg_QP4")
                .put(TrustBrokerConstants.ID_PROOFING_ERROR_QP5, "errorMsg_QP5")
                .put(TrustBrokerConstants.ID_PROOFING_ERROR_QP6, "errorMsg_QP6")
                .put(TrustBrokerConstants.ID_PROOFING_ERROR_SE1, "errorMsg_SE1").build();

        ExecutionStatus es = serviceResponse.getExecutionStatus();
        String executionStatusCd = es.getStatusCd();
        String uuid = UuidUtil.generateUid();
        String errorMsg = es.getStatusMessage() + " - " + uuid;
        String errorMsgProperty = StringUtils.EMPTY;
        String supportInfoText = getWebApplicationCommonUtilities().getApplicationSupportContactInformation(true)
                .getContactComboText();
        if (es.getStatusCodesList() == null) {
            es.setStatusCodesList(new ArrayList<String>());
        }
        List<String> codes = es.getStatusCodesList();
        for (int idx = 0; idx < codes.size(); idx++) {
            respVo.getErrorMap().put("code" + String.valueOf(idx), codes.get(idx));
        }

        if (internalServerErrorMap.containsKey(executionStatusCd)) {
            buildInternalServerError(errorMsg, respVo);
            errorMsgProperty = internalServerErrorMap.get(executionStatusCd);
            LOG.error("System Error: " + errorMsg);
        } else if (TrustBrokerConstants.ID_PROOFING_ERROR_QP1.equals(executionStatusCd)) {
            if (isLoa3Flow(tagVo)) {
                errorMsgProperty = "errorMsg_QP1_LOA3";
            } else {
                errorMsgProperty = "errorMsg_QP1_Basic";
            }
            buildBadRequest(errorMsg, respVo);
        } else if (badReqErrorMap.containsKey(executionStatusCd)) {
            buildInternalServerError(errorMsg, respVo);
            errorMsgProperty = badReqErrorMap.get(executionStatusCd);
        } else {
            errorMsgProperty = "errorMsg_GEN";
            buildBadRequest(errorMsg, respVo);
        }
        if (StringUtils.isNotEmpty(errorMsgProperty)) {
            respVo.getErrorMap().put("lexisNexisErrorMsg",
                    TBUtil.formatMessage(getBundle().getString(errorMsgProperty), new String[] {supportInfoText, uuid}));
        }
    }

}