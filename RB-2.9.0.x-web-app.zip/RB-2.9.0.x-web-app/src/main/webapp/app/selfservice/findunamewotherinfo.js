(function() {

    'use strict';

    var module = angular.module('indexApp');

    module.controller('findUnameOtherInfoCtlr', ['$scope', '$state', '$timeout', 'trustbrokerAriaService', 'LanguageService', 'forgotAccessService', '$rootScope', '$translate', 'HelpObj',
    function($scope, $state, $timeout, trustbrokerAriaService, LanguageService, forgotAccessService, $rootScope, $translate, HelpObj) {
        HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1023_Forgot_Optum_ID_Other_Infor_from_Forgot_Optum_ID_or_Password_screen.htm' });

        LanguageService.doTranslate("selfservice");
        $scope.accountSearchCount = 0;
        $scope.disableNext = false;

        $scope.errorMessageModel = {
            animationTime: 1,
            content: '',
            headingLevel: '2',
            id: 'errorMessage',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: false
        };

        $scope.firstNameErr = false;
        $scope.lastNameErr = false;
        $scope.errors = {};

        // calendar (date of birth) component configurations
        $scope.dobViewModel = {
           	required:false,
           	invalid: false,
           	labelledBy: 'dobLabel',
           	displayAgeInformation:false,
           	textFieldClassName: 'tk-height-2t tk-width-10t',
           	enableValidation: false,
           	requiredMessage: 'dateOfBirthReq',
            invalidFormatMessage: 'invalidDateFormat',
            invalidDateMessage: 'invalidDate',
            dobInvalidFutureMessage: 'futureDate',
            invalidYearMessage: 'invalidYear',
            maxYear: new Date().getFullYear()
        };
        
        $scope.myViewModel = {
            textFieldClassName: 'tk-height-2t',
            maxYear: new Date().getFullYear(),
            requiredMessage: 'Date of birth is required.',
            invalidFormatMessage: 'The format must be mm-dd-yyyy.',
            invalidDateMessage: 'The format must be mm-dd-yyyy'
        };

        $scope.onKeyUp = function(fieldId, errorId, fldErrFlag, fldErrMsg) {
            var fldValue = angular.element("#" + fieldId).val();

            if (fldValue !== '' && fldValue !== undefined) {
                trustbrokerAriaService.removeDescribedByAttribute(fieldId, errorId);
                $scope[fldErrFlag] = false;
            } else if ($scope[fldErrMsg] !== "" && $scope[fldErrMsg] !== undefined) {
                trustbrokerAriaService.appendDescribedByAttribute(fieldId, errorId);
                $scope[fldErrFlag] = true;
            }
        };

        $scope.setFieldDefaults = function() {
            $scope.firstNameErr = false;
            $scope.lastNameErr = false;
            trustbrokerAriaService.removeDescribedByAttribute('firstNameText_input', 'firstNameId_err');
            trustbrokerAriaService.removeDescribedByAttribute('lastNameText_input', 'lastNameId_err');
            trustbrokerAriaService.removeDescribedByAttribute('userDob_dob', 'userDob_err');
            $scope.errors = {};
            $scope.formatErrorFlag = false;
        };

        $scope.disableNextButton = function() {
            $scope.errorMessageModel.content = '<span translate="disablePageMsg" />';
            $scope.errorMessageModel.visible = true;
            $scope.disableNext = true;

            // For WCAG
            $timeout(function() {
                angular.element('#errorMessage').focus();
            }, 300);

            // To enable the field after 2 mins
            $timeout(function() {
                $state.reload();
            }, 120000);
        };

        $scope.disableNextButtonWarning = function() {
            $scope.errorMessageModel.content = '<span translate="disablePageWarningMsg" />';
            $scope.errorMessageModel.visible = true;

            // For WCAG
            $timeout(function() {
                angular.element('#errorMessage').focus();
            }, 300);
        };

        // function for checking if date entered is valid
        $scope.verifyDate = function() {
        	$scope.wrongDateOfBirth = false;
        	if(!validators.checkIfEmpty($scope.dobViewModel.dateText)) {
	        	var dateErrorMsg = validators.isValidDate($scope.dobViewModel);
	        	if(!validators.checkIfEmpty(dateErrorMsg)) {
	        		$scope.wrongDateOfBirth = true;
	        		$scope.dobErrorMsg = $translate.instant(dateErrorMsg);
	        		$scope.setFormErrMsg(); // calling function to display form level error msg
	        		return;
	        	}
        	}
        };

        $scope.nextScreen = function() {
            // console.log("the date of birth is: ", $scope.userDateOfBirth);
            $scope.setFieldDefaults();

            if ($scope.firstName === '' || $scope.firstName === undefined) {
                $scope.firstNmNotEntered();
            }

            if ($scope.lastName === '' || $scope.lastName === undefined) {
                $scope.lastNmNotEntered();
            }

            $scope.verifyDate(); // calling function to verify date format

            if ($scope.phoneErrorFlag) {
                $scope.setFormErrMsg();
            }

            if (!$scope.firstNameErr && !$scope.lastNameErr && !$scope.wrongDateOfBirth && !$scope.phoneErrorFlag) {
                $scope.findUser();
            } else {
                $scope.ariaUpdate();
                $rootScope.fireErrorTracker = true;
            }
        };

        $scope.findUser = function() {
            var dobVal = angular.element('#userDob_dob').val();

            var postData = {
                "firstName": $scope.firstName,
                "lastName": $scope.lastName,
                "dateOfBirth": dobVal,
                "mobilePhone": $scope.mobile
            };

            forgotAccessService.findUserWOtherInfo(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status && responseVO.uniqueEmail) {
                    $state.go('forgotCredByIdentity', { userinfo: { 'userName': responseVO.userName } });
                } else if (!status && responseVO.invalidRecoveryOptns) {
                    $state.go("norecoveryoption");
                } else {
                    $scope.processErrMsgs(responseVO);
                    $rootScope.fireErrorTracker = true;
                }
            });
        };

        $scope.processErrMsgs = function(responseVO) {
            var messages = responseVO.messages;

            if (messages.formerr !== undefined) {
                $scope.errorMessageModel.content = '<span>' + messages.formerr + '</span>';
                $scope.errorMessageModel.visible = true;
                pageDataLayer.content.siteErrorFields = "";
                pageDataLayer.content.siteErrorType = "wrong credentials entered";
            }

            var firstNameErr = messages.firstnameerr,
                lastNameErr = messages.lastnameerr,
                dobErr = messages.doberr,
                phoneErr = messages.phoneerr;

            if (firstNameErr !== '' && firstNameErr !== undefined) {
                $scope.firstNameErr = true;
                $scope.firstNameErrorMsg = firstNameErr;
                trustbrokerAriaService.appendDescribedByAttribute('firstNameText_input', 'firstNameId_err');
            }

            if (lastNameErr !== '' && lastNameErr !== undefined) {
                $scope.lastNameErr = true;
                $scope.lastNameErrorMsg = lastNameErr;
                trustbrokerAriaService.appendDescribedByAttribute('lastNameText_input', 'lastNameId_err');
            }

            if (dobErr !== '' && dobErr !== undefined) {
                $scope.errors.dateInvalid = true;
                $scope.dobErrorMsg = dobErr;
            }

            if (phoneErr !== '' && phoneErr !== undefined) {
                $scope.phoneErrorFlag = true;
            }

            if (!firstNameErr && !lastNameErr && !dobErr && !phoneErr) {
                $scope.accountSearchCount++;
            }

            $scope.ariaUpdate();

            if ($scope.accountSearchCount === 4) {
                $scope.disableNextButtonWarning();
            }

            if ($scope.accountSearchCount >= 5) {
                $scope.disableNextButton();
            }
        };

        $scope.ariaUpdate = function() {
            var FIELDS = [];
            var ind = 0;

            if ($scope.firstNameErr) {
                FIELDS[ind] = { fld: "firstNameText_input", msg: "firstNameId_err" };
                ind++;
            }

            if ($scope.lastNameErr) {
                FIELDS[ind] = { fld: "lastNameText_input", msg: "lastNameId_err" };
                ind++;
            }

            if ($scope.dobErrorMsg) {
                FIELDS[ind] = { fld: "userDob_dob", msg: "userDob_err" };
                ind++;
            }

            if ($scope.phoneErrorFlag) {
                FIELDS[ind] = { fld: "mobileText_input", msg: "mobileText_format_err" };
                ind++;
            }

            if (FIELDS.length > 0) {
                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    $scope.formErrorIsHidden = false;
                }, 300);
            } else {
                $timeout(function() {
                    angular.element('#errorMessage').focus();
                }, 300);
            }
            return;
        };

        $scope.cancelNav = function() {
            $state.go("login");
        };

        $scope.firstNmNotEntered = function() {
            $scope.firstNameErr = true;
            $scope.firstNameErrorMsg = "FndUsrOthrInfFnmReqd";
            trustbrokerAriaService.appendDescribedByAttribute('firstNameText_input', 'firstNameId_err');
            $scope.setFormErrMsg();
        };

        $scope.lastNmNotEntered = function() {
            $scope.lastNameErr = true;
            $scope.lastNameErrorMsg = "FndUsrOthrInfLnmReqd";
            trustbrokerAriaService.appendDescribedByAttribute('lastNameText_input', 'lastNameId_err');
            $scope.setFormErrMsg();
        };

        $scope.setFormErrMsg = function() {
            $scope.errorMessageModel.content = '<span translate="genericFormError" />';
            // console.log("before set for err msg ");
            $scope.errorMessageModel.visible = true;
            // console.log("after set for err msg");
        };
    }]);

})();
