			// Create a window object for post-load communication. 
			window.publishPostPageData = function(name, obj) { 
				try { 
					obj = JSON.stringify(obj, false, 4); 
					console.log(name, obj); 
				} 
				catch(e) {} 
			};
		
			function appendToDataLayer(key, keyVal) {
				if (pageDataLayer.hasOwnProperty(key)) {
					pageDataLayer[key] += "|" + keyVal;
				}
				else {
					pageDataLayer[key] = keyVal;
				}
			}
			
			
			function appendOnce(key, keyVal) {
				if (pageDataLayer.hasOwnProperty(key)) {
					var value = pageDataLayer[key];
					if(value.indexOf(keyVal) < 0){
						pageDataLayer[key] += "|" + keyVal;
					}
				}
				else {
					pageDataLayer[key] = keyVal;
				}
			}
			
			function findKey(map, message) {	
				if(message != undefined) {
					for(var key in map)
				   		if (message.indexOf(key)> -1) 
				    		return key;
				}				
			  	return "";
			}