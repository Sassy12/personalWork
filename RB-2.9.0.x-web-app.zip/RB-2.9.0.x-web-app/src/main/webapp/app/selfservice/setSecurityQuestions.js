'use strict';

angular.module('indexApp').controller('createSecurityQuestionsCtrl', createSecurityQuestionsCtrl);

createSecurityQuestionsCtrl.$inject = ['$scope', '$rootScope', 'trustbrokerAriaService', '$state', 'GeneralService', 'secQuestionsVO', 'userInfo', '$translate', '$timeout', 'GeneralService', 'HelpObj'];

function createSecurityQuestionsCtrl($scope, $rootScope, trustbrokerAriaService, $state, generalService, secQuestionsVO, userInfo, $translate, $timeout, GeneralService, HelpObj) {
    $scope.genericErrorMessageModel = {
        animationTime: 1,
        content: '<span translate="genericFormError"></span>',
        headingLevel: '2',
        id: 'genericErrorMessage',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1030_Create_Security_Questions_Verify_Your_Identity.htm' });

    $scope.setFieldValidity = function(inputid, spanid) {
        trustbrokerAriaService.setFieldValidity(inputid, spanid);
    };

    if (userInfo !== undefined) {
        $scope.userName = (userInfo.data) ? userInfo.data.userName : userInfo;
    } else {
        $scope.userName = ''; // Read it from web app context
    }

    pageDataLayer.content.pageName = "setsecurityquestions";
    pageDataLayer.content.siteSectionL1 = "";

    if (typeof _satellite !== "undefined") {
        _satellite.track('trackPageView');
    }

    var select = {
        label: $translate.instant('select'),
        value: ''
    };

    $scope.authCode = "";

    $scope.status = {
        'secQues1Valid': false,
        'secQues2Valid': false,
        'secQues3Valid': false
    };

    /* UITK 3.7 update */
    var allQuestions = [];

    if (undefined !== secQuestionsVO) {
        angular.forEach(secQuestionsVO.questions, function(securityQues) {
            this.push({
                label: securityQues.label,
                value: securityQues.value
            });
        }, allQuestions);
    }

    allQuestions.unshift(select);

    $scope.secList1 = $scope.secList2 = $scope.secList3 = allQuestions;
    $scope.secQues1 = $scope.secQues2 = $scope.secQues3 = allQuestions[0];

    $scope.questionSelected = function(index) {
        $timeout(function() {
            var i = 0;
            var questionsLen = allQuestions.length;

            // Filter Question one when question 2 or 3 are changed
            if (index !== '1') {
                i = 0;
                $scope.secList1 = [];

                for (var key1index = 0; key1index < questionsLen; key1index++) {
                    if (allQuestions[key1index] === allQuestions[0]) {
                        $scope.secList1[i] = allQuestions[key1index];
                        i++;
                    } else if (!(allQuestions[key1index].label === $scope.secQues2.label || allQuestions[key1index].label === $scope.secQues3.label)) {
                        $scope.secList1[i] = allQuestions[key1index];
                        i++;
                    }
                }
            }

            // Filter Question two when question 1 or 3 are changed
            if (index !== '2') {
                i = 0;
                $scope.secList2 = [];

                for (var key2index = 0; key2index < questionsLen; key2index++) {
                    if (allQuestions[key2index] === allQuestions[0]) {
                        $scope.secList2[i] = allQuestions[key2index];
                        i++;
                    } else if (!(allQuestions[key2index].label === $scope.secQues1.label || allQuestions[key2index].label === $scope.secQues3.label)) {
                        $scope.secList2[i] = allQuestions[key2index];
                        i++;
                    }
                }
            }

            // Filter Question three when question 1 or 2 are changed
            if (index !== '3') {
                i = 0;
                $scope.secList3 = [];

                for (var key3index = 0; key3index < questionsLen; key3index++) {
                    if (allQuestions[key3index] === allQuestions[0]) {
                        $scope.secList3[i] = allQuestions[key3index];
                        i++;
                    } else if (!(allQuestions[key3index].label === $scope.secQues1.label || allQuestions[key3index].label === $scope.secQues2.label)) {
                        $scope.secList3[i] = allQuestions[key3index];
                        i++;
                    }
                }
            }
        }, 300);
    };
    /* END: UITK 3.7 update */

    $scope.validateSecAnsText = function(event) {
        return validators.validateSecAns(event);
    };

    $scope.isFormValid = function() {
        return $scope.setSecQns.$valid && $scope.status.secQues1Valid && $scope.status.secQues2Valid && $scope.status.secQues3Valid;
    };

    $scope.setAriaAttributes = function(inputid, spanid) {
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        }, 300);
    };

    $scope.focusToErrFields = function() {
        var FIELDS = [
            { fld: "secQues1Id",                msg: "secQuestionOneId_err" },
            { fld: "secAnswerOneId_input",      msg: "secAnswerOneId_err" },
            { fld: "secAnswerOneId_input",      msg: "secAnswer1ValidationError" },
            { fld: "secQues2Id",                msg: "secQuestionTwoId_err" },
            { fld: "secAnswerTwoId_input",      msg: "secAnswerTwoId_err" },
            { fld: "secAnswerTwoId_input",      msg: "secAnswer2ValidationError" },
            { fld: "secQues3Id",                msg: "secQuestionThreeId_err" },
            { fld: "secAnswerThreeId_input",    msg: "secAnswerThreeId_err" },
            { fld: "secAnswerThreeId_input",    msg: "secAnswer3ValidationError" }
        ];

        $timeout(function() {
            trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
        }, 300);
    };

    $scope.onKeyUp = function(fieldId, reqErrorId, errorId, fldErrMsg) {
        var fldValue = angular.element("#" + fieldId).val();
        var fldVldnErr = ($scope[fldErrMsg] === "" || $scope[fldErrMsg] === undefined);

        if (fldValue !== '' && fldValue !== undefined && (fldVldnErr)) {
            trustbrokerAriaService.removeDescribedByAttribute(fieldId, errorId);
            trustbrokerAriaService.removeDescribedByAttribute(fieldId, reqErrorId);
        } else if ((fldValue === '' || fldValue === undefined) && $scope.nxtBtnClicked) {
            trustbrokerAriaService.removeDescribedByAttribute(fieldId, errorId);
            trustbrokerAriaService.appendDescribedByAttribute(fieldId, reqErrorId);
        } else if (!fldVldnErr) {
            trustbrokerAriaService.removeDescribedByAttribute(fieldId, reqErrorId);
            trustbrokerAriaService.appendDescribedByAttribute(fieldId, errorId);
        }
    };

    $scope.nxtBtnClick = function() {
        $scope.nxtBtnClicked = true;
        $scope.setSecQns.submitted = true;

        if (GeneralService.getURLParameter("authCode")) {
            $scope.authCode = GeneralService.getURLParameter("authCode");
        }

        if ($scope.isFormValid()) {
            $scope.genericErrorMessageModel.visible = false;

            var postData = {
                'securityQuestionVO': {
                    questionOne: $scope.secQues1.value,
                    ansOne: $scope.secAnswerOne,
                    questionTwo: $scope.secQues2.value,
                    ansTwo: $scope.secAnswerTwo,
                    questionThree: $scope.secQues3.value,
                    ansThree: $scope.secAnswerThree
                }
            };

            generalService.postData('/tb/services/rest/securityQuestions/addSecQns', postData).then(function(response) {
                var responseData = response.data;

                if (Object.keys(responseData.errorMap).length !== 0) {
                    var errorMap = responseData.errorMap;
                    $scope.secAns1ErrorMsg = errorMap.secAns1ErrorMsg || "";
                    $scope.secAns2ErrorMsg = errorMap.secAns2ErrorMsg || "";
                    $scope.secAns3ErrorMsg = errorMap.secAns3ErrorMsg || "";

                    if (response.data.errorMap.responseStatus) {
                        $scope.genericErrorMessageModel.content = '<span>' + response.data.errorMap.responseStatus + '</span>';
                    }

                    $scope.genericErrorMessageModel.visible = true;
                    $scope.focusToErrFields();
                    $rootScope.fireErrorTracker = true;
                } else if (response.data.nextState !== "") {
                    $state.go("login", { 'prevState': 'createSecurityQuestions' });
                }
            });
        } else {
            $scope.genericErrorMessageModel.visible = true;
            $rootScope.fireErrorTracker = true;
            $scope.focusToErrFields();
        }
    };
}
