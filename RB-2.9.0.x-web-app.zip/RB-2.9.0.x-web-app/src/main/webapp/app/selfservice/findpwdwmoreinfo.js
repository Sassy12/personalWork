(function() {
    'use strict';

    var module = angular.module('indexApp');

    module.controller('findPwdWMoreInfoCtlr', ['$scope', '$state', '$timeout', 'trustbrokerAriaService', 'LanguageService', 'forgotAccessService', '$rootScope', 'HelpObj',
    function($scope, $state, $timeout, trustbrokerAriaService, LanguageService, forgotAccessService, $rootScope, HelpObj) {

        LanguageService.doTranslate("selfservice");

        HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1025_Forgot_Password_Shared_Email_Address.htm' });

        $scope.errorMessageModel = {
            animationTime: 1,
            content: '',
            headingLevel: '2',
            id: 'errorMessage',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: false
        };

        $scope.accountSearchCount = 0;
        $scope.disableNext = false;
        $scope.errors = {};
        $scope.usernameErrFlag = false;
        $scope.accountSearchCount = 0;
        $scope.disableNext = false;

        $scope.onKeyUp = function(fieldId, errorId, fldErrFlag, fldErrMsg) {
            var fldValue = angular.element("#" + fieldId).val();

            if (fldValue !== '' && fldValue !== undefined) {
                trustbrokerAriaService.removeDescribedByAttribute(fieldId, errorId);
                $scope[fldErrFlag] = false;
            } else if ($scope[fldErrMsg] !== "" && $scope[fldErrMsg] !== undefined) {
                trustbrokerAriaService.appendDescribedByAttribute(fieldId, errorId);
                $scope[fldErrFlag] = true;
            }
        };

        $scope.setFieldDefaults = function() {
            $scope.usernameErrFlag = false;
            trustbrokerAriaService.removeDescribedByAttribute('usernameText_input', 'usernameId_err');
            $scope.errors = {};
        };

        $scope.nextScreen = function() {
            $scope.setFieldDefaults();

            if ($scope.username === '' || $scope.username === undefined) {
                $scope.usernameNotEntered();
                $scope.ariaUpdate();
                $rootScope.fireErrorTracker = true;
            } else {
                $scope.findUser();
            }
        };

        $scope.disableNextButton = function() {
            $scope.errorMessageModel.content = '<span translate="disablePageMsg" />';
            $scope.errorMessageModel.visible = true;
            $scope.disableNext = true;

            // For WCAG
            $timeout(function() {
                angular.element('#errorMessage').focus();
            }, 300);

            // To enable the field after 2 mins
            $timeout(function() {
                $state.reload();
            }, 120000);
        };

        $scope.disableNextButtonWarning = function() {
            $scope.errorMessageModel.content = '<span translate="disablePageWarningMsg" />';
            $scope.errorMessageModel.visible = true;

            // For WCAG
            $timeout(function() {
                angular.element('#errorMessage').focus();
            }, 300);
        };

        $scope.findUser = function() {
            var postData = { "userName": $scope.username };

            forgotAccessService.findPwdWMoreInfo(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status && responseVO.uniqueEmail) {
                    $state.go('forgotCredByIdentity', { userinfo: { 'userName': responseVO.userName } });
                } else if (!status && responseVO.invalidRecoveryOptns) {
                    $state.go("norecoveryoption");
                } else {
                    $scope.processErrMsgs(responseVO);
                    $rootScope.fireErrorTracker = true;
                }
            });
        };

        $scope.processErrMsgs = function(responseVO) {
            if (responseVO.messages.formerr !== undefined) {
                $scope.errorMessageModel.content = '<span>' + responseVO.messages.formerr + '</span>';
                $scope.errorMessageModel.visible = true;
            }

            var usernameErr = responseVO.messages.usernameerr;

            if (usernameErr !== '' && usernameErr !== undefined) {
                $scope.usernameErrFlag = true;
                $scope.usernameErrorMsg = usernameErr;
                trustbrokerAriaService.appendDescribedByAttribute('usernameText_input', 'usernameId_err');
            } else {
                $scope.accountSearchCount++;
            }

            $scope.ariaUpdate();

            if ($scope.accountSearchCount === 4) {
                $scope.disableNextButtonWarning();
            }

            if ($scope.accountSearchCount >= 5) {
                $scope.disableNextButton();
            }
        };

        $scope.ariaUpdate = function() {
            if ($scope.usernameErrFlag) {
                var FIELDS = [{ fld: "usernameText_input", msg: "usernameId_err" }];

                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    $scope.formErrorIsHidden = false;
                }, 300);
            } else {
                $timeout(function() {
                    angular.element('#errorMessage').focus();
                }, 300);
            }
            return;
        };

        $scope.cancelNav = function() {
            $state.go("login");
        };

        $scope.unameUnknownNav = function() {
            $state.go("forgotcredentialPage");
        };

        $scope.usernameNotEntered = function() {
            $scope.usernameErrFlag = true;
            $scope.usernameErrorMsg = "FndPwdMrInfUnmReqd";
            trustbrokerAriaService.appendDescribedByAttribute('usernameText_input', 'usernameId_err');
            $scope.setFormErrMsg();
        };

        $scope.setFormErrMsg = function() {
            $scope.errorMessageModel.content = '<span translate="genericFormError" />';
            $scope.errorMessageModel.visible = true;
        };
    }]);
})();
