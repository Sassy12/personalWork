package com.optum.trustbroker.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.controller.vo.ErrorResponseVO;
import com.optum.trustbroker.controller.vo.ManageProfileVO;
import com.optum.trustbroker.controller.vo.ProfileVO;
import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.service.CredentialService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.ValidationUtils;
import com.optum.trustbroker.vo.UserChangePasswordServiceRequest;
import com.optum.trustbroker.vo.UserChangePasswordServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@Component
@Path(TBConstants.CHANGE_PWD_CONTROLLER_PATH)
public class ChangePwdController extends BaseController {

	private static final String CONFIRM_PWD_FIELD = "confirmPwd";

	private static final BaseLogger LOGGER = new BaseLogger(ChangePwdController.class);

	@Autowired
	private CredentialService credentialService;

	@Autowired
	private ValidationUtils validationUtils;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response changePwd(@FormParam("newPwd") String newPwd, @FormParam(CONFIRM_PWD_FIELD) String confirmPwd,
							  @Context HttpServletRequest request) {

		Response response = null;

		UserVO currentUser = getCurrentUser();
		String relyingAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);

		Map<String, String> validationErrors = validatePwdFields(newPwd, confirmPwd, currentUser.getUserName());
		if (validationErrors != null && !validationErrors.isEmpty()) {
			LOGGER.error("Pwd validations failed with errors - {}", validationErrors);
			ResponseVO errorResponse = new ResponseVO();
			errorResponse.setErrorMap(validationErrors);
			errorResponse.setStatus(TrustBrokerWebAppConstants.ERROR);
			response = Response.status(TrustBrokerWebAppConstants.HTTP_BAD_REQUEST).entity(errorResponse).build();
			return response;
		}

		UserChangePasswordServiceRequest userChangePwdRequest = new UserChangePasswordServiceRequest();
		userChangePwdRequest.setPassword(newPwd);
		userChangePwdRequest.setUser(currentUser);

		UserChangePasswordServiceResponse userChangePwdResponse = credentialService.changePwd(userChangePwdRequest);

		if (TrustbrokerWebAppUtil.checkResponseStatus(userChangePwdResponse)) {

			// send profile update notification to user
			sendProfileUpdateNotification(request, relyingAppId, currentUser, currentUser, true);

			ResponseVO responseVO = new ResponseVO();
			responseVO.setStatus(TrustBrokerWebAppConstants.SUCCESS);

			response = Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(responseVO).build();

			SecurityLoggingUtil.info("User Account Modifications", SecurityEventType.E3_MODIFY, request,
					currentUser.getUserName(),
					"Security Audit Event | ModifyUserPassword:SUCCESS | User Account Password Modified, ChangePwdController:changePwd()",
					SecurityEventResult.SUCCESS, relyingAppId, SecuritySubEventType.E3_MODIFY_PASSWORD);
		} else {
			String errorMessage = userChangePwdResponse.getReasonMessage();
			//LOGGER.error("Pwd change request for {} failed due to {}", currentUser.getUserName(), errorMessage);
			ErrorResponseVO errorResponse = new ErrorResponseVO();
			errorResponse.setMessage(errorMessage);
			response = Response.status(TrustBrokerWebAppConstants.HTTP_BAD_REQUEST).entity(errorResponse).build();
		}

		return response;

	}
	
    @Path(TBConstants.CONTEXT)
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response getDetails() {
		String userName = getContextAttribute(TrustBrokerWebAppConstants.USER_ID);
		String targetURL = getSessionAttribute(TrustBrokerWebAppConstants.TARGET);
		ManageProfileVO manageProfileVO = new ManageProfileVO();
		ProfileVO profileVO = new ProfileVO();
		profileVO.setUserName(userName);
		manageProfileVO.setProfile(profileVO);
		processRelyingPartyInfo(manageProfileVO, targetURL);
		Response response = Response.status(TBConstants.HTTP_SUCCESS).entity(manageProfileVO).build();
		return response;
	}

    private Map<String, String> validatePwdFields(String newPwd, String confirmPwd, String userName) {

        UserInfoVO userInfoVO = new UserInfoVO();

        userInfoVO.setPwd(newPwd);
        userInfoVO.setConfirmPwd(confirmPwd);
        userInfoVO.setUserName(userName);

        validationUtils.validatePwd(userInfoVO);

		return userInfoVO.getErrorMap();

    }

	public CredentialService getCredentialService() {
		return credentialService;
	}

	public void setCredentialService(CredentialService credentialService) {
		this.credentialService = credentialService;
	}

	public ValidationUtils getValidationUtils() {
		return validationUtils;
	}

	public void setValidationUtils(ValidationUtils validationUtils) {
		this.validationUtils = validationUtils;
	}
}
