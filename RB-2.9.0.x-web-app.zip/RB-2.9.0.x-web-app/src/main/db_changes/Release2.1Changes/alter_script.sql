-- Alter USER_AUTHORIZATION table to support both account recovery and Security Questions missing cases.
alter table USER_AUTHORIZATION add (PURPOSE VARCHAR2(3));
update USER_AUTHORIZATION set PURPOSE='ARC';
