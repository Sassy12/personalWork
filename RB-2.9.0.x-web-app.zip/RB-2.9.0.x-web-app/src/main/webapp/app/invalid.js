'use strict';

var invalidApp = angular.module('invalidApp',['common.services']);

invalidApp.controller('invalidCtl', ['$scope',  'GeneralService','AnalyticsService', InvalidController]);

     function InvalidController($scope ,  GeneralService,AnalyticsService) {
	
	 $scope.getInvalidMsg = function() {
	        GeneralService.postData('/tb/services/rest/commonController/getErrorMessageWithSupportInfo', 'exceptionErrorMessageUnregisteredRPUrl').then(function(response) {
	            //$scope.invalidMsg = response.data.message;
	            var invElem = angular.element('#invalidMsgId');	        		    
	    		invElem.html(response.data.message);	
	        });
	        
	    };
		pageDataLayer.content.pageName="unabletodisplaypage";
	    pageDataLayer.content.siteSectionL1="";
		
	    if(typeof _satellite !== "undefined"){
	        _satellite.track('trackPageView');
	    }
	    
		AnalyticsService.postErrorPageInfo("404");
     }



