/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2011.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When          Who         Why
 * May 07 2014   bmanna3		Initial version
 ****************************************************************/
package com.optum.trustbroker.managebean.widget;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name = "wCommonBean")
@RequestScoped
public class CommonBean extends AbstractBackingBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/**
	 * This method gets called before view gets initialized.
	 */
	public void onPreinitialize() {
		//Creates user session information
		createUserSession();
	
	}
	
}
