package com.optum.trustbroker.controller;

import java.util.ResourceBundle;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.ImmutableMap;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.MessageVO;
import com.optum.trustbroker.controller.vo.MobileOtpVO;
import com.optum.trustbroker.enums.AuthorizationCodeStatus;
import com.optum.trustbroker.securemessaging.SecureMessagingService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserAuthorizationResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;

@Path(TBConstants.MOBILE_OTP_CONTROLLER_PATH)
public class MobileOtpController extends BaseController {

    private static final BaseLogger logger = new BaseLogger(ResetPasswordController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private SecureMessagingService secureMessagingService;

    @POST
    @Path(value = "/sendAnotherOTP")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public MessageVO sendAnotherOTP(String userName) {

        MessageVO messageVO = new MessageVO();
        ResourceBundle bundle = getBundle();
        try {
            if (StringUtils.isBlank(userName)) {
                userName = WebApplicationContextHolder.getContext()
                        .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME);
            }

            UserRetrievalServiceResponse userRetrievalServiceResponse = userService.fetchUserProfile(userName, false, true);

            UserAuthorizationResponse response = userService
                    .generateAuthCodeToUser(userRetrievalServiceResponse.getUser().getUuId(), TrustBrokerConstants.SMSOTP);

            secureMessagingService.sendText(userRetrievalServiceResponse.getUser().getPhoneNumber(),
                    bundle.getString("OtpAccessCodeMsg") + response.getUserAuthCode());
            messageVO.setMessage(bundle.getString("mobileOptText"));
        } catch (OperationFailedException e) {
            messageVO.setErrorMap(ImmutableMap.<String, String> of("otpSendErrMsg", bundle.getString("otpSendErrMsg")));
            logger.error("Error in sending OTP to your mobile number: ", e);
        }
        return messageVO;
    }

    @POST
    @Path(value = "/confirmOTP")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public MessageVO confirmOTP(MobileOtpVO mobileOtpVO) {
        MessageVO messageVO = new MessageVO();
        ResourceBundle bundle = getBundle();
        WebApplicationContext context = WebApplicationContextHolder.getContext();
        context.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN);
        context.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_AUTH_CODE);
        if (mobileOtpVO == null) {
            messageVO.setErrorMap(ImmutableMap.<String, String> of("invalid", bundle.getString("authActInvalidCdHead")));
        } else {
            if (StringUtils.isBlank(mobileOtpVO.getUserName())) {
                mobileOtpVO.setUserName(WebApplicationContextHolder.getContext()
                        .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME));
                messageVO.setUserName(mobileOtpVO.getUserName());
            }

            final String otp = mobileOtpVO.getOtp();
            if (StringUtils.isEmpty(otp)) {
                messageVO.setErrorMap(ImmutableMap.<String, String> of("optError", bundle.getString("OTPmsg")));
            } else {
                UserAuthorizationResponse response = userService.validateAuthCode(otp);
                if (response == null) {
                    messageVO.setErrorMap(
                            ImmutableMap.<String, String> of("optError", bundle.getString("invalidMobileOTPNextGen")));
                } else if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
                    if (!response.getUser().getUserName().equalsIgnoreCase(mobileOtpVO.getUserName())) {
                        messageVO.setErrorMap(ImmutableMap.<String, String> of("optError", bundle.getString("invalidMobileOTPNextGen")));
                    } else if (response.getAuthStatus().equals(AuthorizationCodeStatus.PROCESSED.toString())) {
                        messageVO.setErrorMap(ImmutableMap.<String, String> of("optError", bundle.getString("mobileOtpAlreadyUsed")));
                    } else {                        
                        context.setSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN, context
                                .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME));
                    }
                } else if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
                    messageVO.setErrorMap(ImmutableMap.<String, String> of("optExpired", bundle.getString("mobileOtpExpired")));
                }
            }
        }
        return messageVO;
    }

    @Override
    public UserService getUserService() {
        return userService;
    }

    @Override
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public SecureMessagingService getSecureMessagingService() {
        return secureMessagingService;
    }

    public void setSecureMessagingService(SecureMessagingService secureMessagingService) {
        this.secureMessagingService = secureMessagingService;
    }

    public static BaseLogger getLogger() {
        return logger;
    }

}
