package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.net.URISyntaxException;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserVO;

@ManagedBean(name = "congratulationsBean")
@ViewScoped
public class CongratulationsBean extends AbstractBackingBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private BaseLogger logger = new BaseLogger(CongratulationsBean.class);
	private UserVO userVO;
	private String action = "/siteminderagent/forms/login.fcc";
	private String localenv = "false";
	private String errorMsg;
	private boolean relyinPartyTrusted = true;

	@PostConstruct
	public void init() {
		if (TBUtil.isLocalEnv()) {
			localenv = "true";
		}
		userVO = getCurrentUserVO();
		String relyingAppId = getRelyingPartyAppId();
		if (relyingAppId != null) {
			RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
			if (logger.isDebugEnabled()) {
				logger.debug("checkRelyingPartyTrust() - relyingPartyApp: " + relyingPartyAppVO);
			}
			if (relyingPartyAppVO == null) {
				relyinPartyTrusted = false;
				errorMsg = tbResources.getString("invalidRelyingAppMsg");
			}
			else if (isSessionAttributeExists(TrustBrokerWebAppConstants.RELYING_APP_URL)) {
				try {
					String rpDomainName = TBUtil.getDomainName(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL).toString());
					boolean isdomainValid;
					if (relyingPartyAppVO.getRpAppDomains() != null && relyingPartyAppVO.getRpAppDomains().size() > 0) {
						isdomainValid = TBUtil.isDomainValid(relyingPartyAppVO.getRpAppDomains(), rpDomainName);
					}
					else {
						isdomainValid = relyingPartyAppVO.getAppDomainName().equals(rpDomainName);
					}
					if (!isdomainValid) {
						relyinPartyTrusted = false;
						errorMsg = tbResources.getString("securityThreatMsg");
					}
				}
				catch (URISyntaxException e) {
					logger.error(e);
				}
			}
		}
	}

	/**
	 * Method to redirect into relying party url after successful registration
	 *
	 * @return
	 */
	public String continueToApp() {
		if (relyinPartyTrusted) {
			redirectionNonsso((String) getSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET), null, null, null);
		}
		else {
			redirectToView(getHomePageURIWithAlias());
		}
		return null;
	}

	public boolean getRelyinPartyTrusted() {
		return relyinPartyTrusted;
	}

	public void setRelyinPartyTrusted(boolean relyinPartyTrusted) {
		this.relyinPartyTrusted = relyinPartyTrusted;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getLocalenv() {
		return localenv;
	}

	public void setLocalenv(String localenv) {
		this.localenv = localenv;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}
