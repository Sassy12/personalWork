'use strict';
(function(){
	function Validators(){}
	
	Validators.prototype.isValidDate = validateDate;
	Validators.prototype.isValidEmail = validateEmail;
	Validators.prototype.checkIfEmpty = checkForEmpty;
	//Validators.prototype.isFutureDate = isFutureDate;
	Validators.prototype.passwordValidation = passwordValidation;
	Validators.prototype.userNameValidation = userNameValidation;
	Validators.prototype.isValidMobileNo = validateMobile;
	//Validators.prototype.findFutureDate = findFutureDate;
	Validators.prototype.formatSSN = formatSSN;
	Validators.prototype.validateSecAns = validateSecAns;
	Validators.prototype.isValidYOB = validateYOB;

	var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	var MOBILE_REGEX = /^(\d{3})(-\d{3}-\d{4}|\d{7})$/;

	window.validators =  new Validators();
	
	/* Returns 
	 *  - String value if date is not valid 
	 */
	function validateDate(dobModel){
		var errorMsg = "";
		if (dobModel.invalid) {
			errorMsg = dobModel.errorMessage;
        } else if(dobModel.dateText === "") {
        	errorMsg = dobModel.requiredMessage;
        } else if(!validateYOB(dobModel.dateText)){
        	errorMsg = dobModel.invalidYearMessage;
        }
		return errorMsg;
	}
	
	/*function isFutureDate(dateString){
		var parts = dateString.split("-");
		var month = parseInt(parts[0], 10),
			day = parseInt(parts[1], 10),
			year = parseInt(parts[2], 10);
	    
	    var enteredDate = new Date(year, month-1, day);
		var currentDate = new Date();
	    if(enteredDate >= currentDate){
	    	return true;
	    }
	}*/
	
	//function for finding future date(new function)
	/*function findFutureDate(userDate) {
		var todayDate = new Date().getTime();
		var enteredDate = new Date(userDate).getTime();
		if (enteredDate >= todayDate) {
			return true;
		}
	}*/
	
	function validateEmail(email){
		var isValid = true;

		if(email) {
			if(email.trim().length === 0) {
				isValid = false;
			}else if(!EMAIL_REGEX.test(email)) {
				isValid = false;
			}
		}else{
			isValid = false;
		}
		
		return isValid;
	}

	function validateMobile(mobile){
		var isValid = true;

		if(mobile) {
			if(mobile.trim().length === 0) {
				isValid = false;
			}else if(!MOBILE_REGEX.test(mobile)) {
				isValid = false;
			}
		}else{
			isValid = false;
		}

		return isValid;
	}
	
	/* Returns 
	 *  - true if value is empty 
	 *  - false if date is not empty
	 */
	function checkForEmpty(value){
		return (value === undefined || value === "" || value.toString().trim().length === 0);
	}
	function passwordValidation(pwdValue){

		var pwdlengthValidation = 0,
			pwdUpperCaseValidation = 0,
			pwdLowerCaseValidation = 0,
			pwdSpaceValidation = 0,
			pwdNumericValidation = 0,
			pwdRulesMet = 0;
		
        if(pwdValue !== "" && pwdValue !==undefined) {
            if(pwdValue.length >= 8){
            	pwdlengthValidation = 1;
			}

			/* Look for upper case english alphabets and other upper case
			 * letters from acceptable characters list */
            var regex = /[A-ZÍÚÑÜÆÀÁÂÉÈÉËÎÏÓÔÙÛŒÇÄÖ]/g;
            if(regex.exec(pwdValue)) {
				pwdUpperCaseValidation = 1;
			}

			/* Look for lower case english alphabets and other lower case
			 * letters from acceptable characters list */
            regex = /[a-zíúüàáâéèêëîïóôùûæœçßäöñ]/g;
            if(regex.exec(pwdValue)) {
				pwdLowerCaseValidation = 1;
			}
            
            regex = /^\S+$/;
            if(regex.exec(pwdValue)) {
				pwdSpaceValidation = 1;
			}
            /*
             * The below checks for an & through the pwdValue.
             */
            regex = /&+/g;
            if(regex.exec(pwdValue)) {
				pwdSpaceValidation = 0;
			}
            
            regex = /[0-9]/g;                
            if(regex.exec(pwdValue)) {
				pwdNumericValidation = 1;
			}
            
            	pwdRulesMet = pwdlengthValidation + pwdUpperCaseValidation +
								pwdLowerCaseValidation + pwdSpaceValidation + pwdNumericValidation;
        }
		
        return {
        	"pwdValue":pwdValue,
        	"pwdlengthValidation":pwdlengthValidation,
        	"pwdUpperCaseValidation":pwdUpperCaseValidation,
        	"pwdLowerCaseValidation":pwdLowerCaseValidation,
        	"pwdSpaceValidation":pwdSpaceValidation,
        	"pwdNumericValidation":pwdNumericValidation,
        	"pwdRulesMet":pwdRulesMet
        };
	}
	
	function userNameValidation(unameValue) {
			var unameLengthValidation = 0,
				unameLetterValidation = 0,
				unamespCharacterValidation = 0,
				unameSpaceValidation = 0,
				unameRulesMet = 0;

            if ("" !== unameValue && undefined !== unameValue) {
                if (unameValue.length >= 6 && unameValue.length <= 50) {
                    unameLengthValidation = 1;
                }

				/* Look for all english alphabets and upper & lower case letters from
				 * acceptable characters list*/
                var regex = /[A-Za-zÍÚÑÜÆÀÁÂÉÈÉËÎÏÓÔÙÛŒÇÄÖíúüàáâéèêëîïóôùûæœçßäöñ]/g;
                if (regex.exec(unameValue)) {
                    unameLetterValidation = 1;
                }

                /* updating regex to filter-out left,right parenthesis, asterisk and ampersand */
                regex = new RegExp('[&\*\(\)]');
                if (!regex.test(unameValue)) {
                    unamespCharacterValidation = 1;
                }

                regex = /^\S+$/;
                if (regex.exec(unameValue)) {
                    unameSpaceValidation = 1;
                }

                unameRulesMet = unameLengthValidation + unameLetterValidation +
                        unamespCharacterValidation + unameSpaceValidation;
            }
            return {
                "unameValue": unameValue,
                "unameLengthValidation": unameLengthValidation,
                "unameLetterValidation": unameLetterValidation,
                "unamespCharacterValidation": unamespCharacterValidation,
                "unameSpaceValidation": unameSpaceValidation,
                "unameRulesMet": unameRulesMet
            };
	}
	
	//function definition for formatting SSN number========================================================================================
	function formatSSN(number){
		if(!validateInputNumber(number) || number.replace(/[^0-9]/g,"").length !== 9){
    		var errorMessage = {
    				format : '555-55-5555',
    				formatErrorFlag: true
    		};
    		return errorMessage;
    	}
		var tempNumber = number.replace(/-/g, '').replace(' ','');
        if (!tempNumber) { return ''; }
        var formattedNumber = String(tempNumber);
		var front = tempNumber.substring(0,3);
		var mid = tempNumber.substring(3, 5);
		var end = tempNumber.substring(5, 9);
		if (mid) {
			formattedNumber = (front + "-" + mid);	
		}
		if (end) {
			formattedNumber += ("-" + end);
		}
		if(formattedNumber.length === 3 && number.length === 4 && number.charAt(3) === '-') {
			formattedNumber += "-";
		}
		if(formattedNumber.length === 6 && number.length === 7 && number.charAt(6) === '-') {
			formattedNumber += "-";
		}
		return formattedNumber;
	}
	//function for validating the number=========================================================================================
	function validateInputNumber(number){
		var regex = new RegExp('^[0-9 -]*$');
		return regex.test(number);
	}

	function validateSecAns(event){
		if (event.charCode !== 0) {
	            var regex = new RegExp("^[a-zA-Z0-9!,:_/\\s\*\$\.\-]+$");
	            var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
	            if (!regex.test(key)) {
	                event.preventDefault();
	                return false;
	            }
	    }
	    return true;
	}
	
	/* Returns 
	 *  - true if YOB is valid 
	 *  - false if YOB is invalid
	 */
	function validateYOB(dateString){
		var year;
		
		if(dateString.indexOf("-") !== -1){
			var parts = dateString.split("-");
			year = parseInt(parts[2], 10);
		} else {
			year = parseInt(dateString, 10);
		}
		
		var cYear = new Date().getFullYear();
		cYear = parseInt(cYear, 10);
		
	    if ((cYear - year) > 140) { 
	    	return false; 
	    }		   
	    
	    return true;
	}

})();
