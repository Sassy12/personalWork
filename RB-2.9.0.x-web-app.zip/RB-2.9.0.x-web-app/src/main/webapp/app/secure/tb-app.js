'use strict';

var tbApp = angular.module('tbApp', [
    'common.modules',
    'common.services',
    'ngResource',
    'oid.component.oidTextSelectCombo',
    'pascalprecht.translate',
    'trustbroker.AriaLibrary',
    'ui.router',
    'uitk.component.busyIndicator',
    'uitk.component.header',
    'uitk.component.sessionTimeout',
    'uitk.component.tabs',
    'uitk.component.uitkButton',
    'uitk.component.uitkCalendar',
    'uitk.component.uitkCheckboxGroup',
    'uitk.component.uitkDialog',
    'uitk.component.uitkDynamicTable',
    'uitk.component.uitkFooter',
    'uitk.component.uitkGlobalNavigation',
    'uitk.component.uitkLabel',
    'uitk.component.uitkMessage',
    'uitk.component.uitkPanel',
    'uitk.component.uitkPrimaryNavigation',
    'uitk.component.uitkRadioGroup',
    'uitk.component.uitkSelect',
    'uitk.component.uitkTextarea',
    'uitk.component.uitkTextField',
    'uitk.component.uitkTooltip',
    'uitk.component.uitkVerticalNavigation',
    'uitk.component.uitkDateOfBirth',
    'uitk.uitkUtility',
    'uitk.component.uitkHelp'
]);

/* Router configuration for all states */
tbApp.config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$translateProvider', '$httpProvider', 'uitkDateOfBirthDefaultsProvider',
    function($stateProvider, $urlRouterProvider, $locationProvider, $translateProvider, $httpProvider, uitkDateOfBirthDefaultsProvider) {

        $translateProvider.useLoader("$translatePartialLoader", {
            urlTemplate: "{part}/i18n/{lang}.json"
        });

        $translateProvider.translations('en_US', {
            P_POLICY: 'Privacy Policy',
            T_O_USE: 'Terms of Use',
            LINK_INFO: 'Opens in a new window',
            RQD_VAR: 'required',
            busyIndicatorText : 'The application will be available shortly.'
        });
        
        uitkDateOfBirthDefaultsProvider.set('minYear', '0000');

        $translateProvider.preferredLanguage('en_US');
        $translateProvider.useSanitizeValueStrategy('escaped');
        // Push service response interceptor to default interceptors array
        $httpProvider.interceptors.push('ServiceResponseInterceptor');

        // Push service request interceptor to default interceptors array for random token
        $httpProvider.interceptors.push('httpRequestInterceptor');

        $locationProvider.html5Mode(false);
        $urlRouterProvider.otherwise('/profileinfo');

        $stateProvider.state('profile', {
            templateUrl: "manageid/views/profileinfo.html",
            abstract : true,
            controller: 'TabsController',
            resolve: {
                'langData': function(LanguageService) {
                    return LanguageService.doTranslate("manageid");
                },
                'rpDetails' : function (ProfileService) {
                    return ProfileService.getRPContext();
                }
            }
        }).state('profile.profileinfo', {
            url: "/profileinfo",
            views: {
                'profileTab': {
                    templateUrl: 'manageid/views/profiletab.html',
                    controller: 'ProfileInfoController',
                    resolve: {
                        'initData': function(ProfileService) {
                            ProfileService.updateTabIndex(0);
                            return ProfileService.getProfileInfo();
                        }
                    }
                }
            }
        }).state('profile.changepwd', {
            url: "/changepwd",
            views: {
                'changePwdTab': {
                    templateUrl: 'manageid/views/changepwd.html',
                    controller: 'ChangePwdController',
                    resolve: {
                        'initData': function(ProfileService) {
                            ProfileService.updateTabIndex(1);
                            return ProfileService.getPasswordPageData();
                        }
                    }
                }
            }
        }).state('profile.verifyoptions', {
            url: "/verifyoptions",
            views: {
                'verificationOptionsTab': {
                    templateUrl: 'manageid/views/verifyoptions.html',
                    controller: 'VerifyOptionsController',
                    controllerAs: 'vm',
                    resolve: {
                        'initData': function(ProfileService) {
                            ProfileService.updateTabIndex(2);
                            return ProfileService.getVerifyOptionsData().then(function(response){
                                ProfileService.saveVerifyOptionsPageData(response.data);
                            });
                        }
                    }
                }
            }
        }).state('optumIdSuccessNoVerification', {
            url: "/optumIdSuccessNoVerification",
            templateUrl: "manageid/views/OptumIdSuccessNoVerification.html",
            controller: 'noVerificationCtrl',
            resolve: {
                'langData': function(LanguageService) {
                    LanguageService.doTranslate("manageid");
                }
            }
        }).state('stepup', {
            url: "/stepup",
            templateUrl: "stepup/views/stepup.html",
            controller: 'StepupCtrl',
            resolve: {
                stepupVO:function(StepupService) {
                    return StepupService.createStepupContext();
                }
            }
        }).state('migrationsuccess', {
            url: "/migrationsuccess",
            templateUrl: "stepup/views/migrationSuccess.html",
            controller: 'StepupCtrl',
            resolve: {
                stepupVO:function(StepupService) {
                    return StepupService.createStepupContext();
                }
            }
        }).state('consent', {
            url: "/consent",
            templateUrl: "consent/views/consent.html",
            controller: 'ConsentCtrl',
            resolve: {
                rpData:function(ConsentService) {
                    return ConsentService.getConsentVO();
                }
            }
        }).state('optumIdSuccessVerificationNeeded', {
            url: "/optumIdSuccessVerificationNeeded/",
            templateUrl: "manageid/views/OptumIdSuccessVerificationNeeded.html",
            params: {
                fields: null,
                hideSuccessMsg : false
            },
            controller: 'VerificationNeededCtrl',
            resolve: {
                'langData': function(LanguageService) {
                    LanguageService.doTranslate("manageid");
                },
                vfData: function(verifyService) {
                    return verifyService.getModifiedFields();
                }
            }
        }).state("tbErrorPage", {
            // need to call $state.go(tbErrorPage, { errorCode: code number, referenceCode: code number }) for redirecting to error page
            url: "/errorPage/",
            templateUrl: "tb-error/views/errorPage.html",
            controller: "errorPageController",
            params: {
                errorCode: null,
                referenceCode: null
            },
            resolve: {
                'langData': function(LanguageService) {
                    LanguageService.doTranslate("tb-error");
                },
                // calling errorService to get the error messages
                errorData: function(errorService, $state, $stateParams) {
                    return errorService.getErrorMessages($stateParams.errorCode, $stateParams.referenceCode);
                }
            }
        }).state("lexisNexis", {
            url: "/lexisNexis",
            templateUrl: "idproofing/views/lexisNexis.html",
            controller: "lexisNexisCtrl",
            resolve: {
                'langData': function(LanguageService) {
                    return LanguageService.doTranslate("idproofing");
                }
            }
        }).state("lexisNexisSuccess", {
            url: "/lexisNexisSuccess",
            templateUrl: "idproofing/views/lexisNexisSuccess.html",
            controller: "lexisNexisCtrl"
        }).state("addAccountRecovery", {
            url: "/addAccountRecovery",
            controller: "AddAccountRevoceryCtrl",
            resolve: {
                'recovInfo': function(addAccountRecoveryService) {
                    return addAccountRecoveryService.getRecovInfo();
                }
            },
            templateUrl: "addaccountrecovery/views/addAccountRecovery.html"
        }).state('mobileVerification', {
            url: '/mobileVerification',
            controller: 'mobileVerificationCtrl',
            params: {
                fieldToVerify: null,
                fromState : null
            },
            templateUrl: 'mobileverification/views/mobileVerification.html'
        }).state('mobileVerificationSuccess', {
            url: "/mobileVerificationSuccess",
            controller: 'mobileVerificationCtrl',
            templateUrl: 'mobileverification/views/mobileVerificationSuccess.html'
        }).state('verifyRecoveryOptions', {
            url: "/verifyRecoveryOptions",
            templateUrl: "verifyrecoveryoptions/views/verifyRecoveryOptions.html",
            resolve: {
                'langData': function(LanguageService) {
                    return LanguageService.doTranslate("verifyrecoveryoptions");
                },
                'initData': function(VerifyRecoveryOptionsService) {
                    return VerifyRecoveryOptionsService.getRecoveryOptions().then(function(responseData) {
                        VerifyRecoveryOptionsService.saveRecoveryOptionsData(responseData);
                    });
                }
            }
        }).state('signOut', {
            url: '/signOut',
            template: '',
            controller: function($window, $http, $scope) {
                $http.get('/tb/services/rest/user/signoutuser').then(function() {
                    $scope.rpAppId = null;
                    $window.location = '../index.html?LOGOUT=TRUE#/login';
                });
            }
        });
    }]);

tbApp.run(function($rootScope, $injector, AnalyticsService) {
    AnalyticsService.postPageViewData($rootScope,$injector);
});

tbApp.controller('HomeController', [
    '$scope',
    '$location',
    '$window',
    '$http',
    'GeneralService',
    '$translate',
    '$rootScope',
    '$timeout',
    'AnalyticsService',
    'HelpObj',
    HomeController
]);

function HomeController($scope, $location, $window, $http, GeneralService, $translate, $rootScope, $timeout, AnalyticsService, HelpObj) {
    $scope.policyLabel = $translate.instant('P_POLICY');
    $scope.touselabel = $translate.instant('T_O_USE');
    $scope.linkinfo = $translate.instant('LINK_INFO');

    $rootScope.constants = {
        pwdFieldLen : "100",
        userNameFieldLen : "50",
        emailAddressFieldLen : "250",
        firstNameFieldLen : "50",
        middleNameFieldLen : "50",
        lastNameFieldLen : "50",
        suffixFieldLen : "50",
        yobFieldLen : "4",
        mobilePhoneFieldLen : "18",
        sqaFieldLen : "50",
        confirmCodeLen : "10"
    };

    $scope.constants = $rootScope.constants;

    ////new help component has been added for help link in header
    HelpObj.setHelpObj({url:'../webHelp/Default_CSH.htm'});

    // preventing default behaviour of anchor tags on footer
    $('.outer-footer-wrapper').on("click", "a", function(event) {
        event.preventDefault();
    });

    // function for checking which link is clicked and open associated link in a new window
    $scope.checkLinks = function(linkLabel) {
        if (linkLabel === "privacyLink") {
            var newWindow = $window.open('/tb/app/index.html#/privacyPolicy', 'Optum ID', 'left=20, top=20, toolbar=no, titlebar=yes, location=no, directories=no, status=no, menubar=no, resizable=1, scrollbars=yes');
            newWindow.focus();
        }
        if (linkLabel === "termsLink") {
            $window.open('/tb/app/index.html#/termsOfUse', 'Optum ID', 'left=20, top=20, toolbar=no, titlebar=yes, location=no, directories=no, status=no, menubar=no, resizable=1, scrollbars=yes');
        }
    };

    $scope.isTBUserLoggedIn = false;
    $scope.smuser = "";
    $scope.rpAppId = null;
    $scope.rpUrl = null;
    $scope.ftrImgUrl = null;

    function getUserName() {
        var email = {
            email: 'normal-mode'
        }; // test-mode for moc test response

        var userNameResponse = [];
        var user;
        var error;
        $http.post('/tb/services/secure/rest/commonSecureController/getUser', email).then(function(response) {
            userNameResponse = response;
            if (userNameResponse.data.errorMsg) {
                error = userNameResponse.data.errorMsg;
            } else {
                user = userNameResponse.data.username;
                $scope.smuser = "Welcome, " + user;
                angular.element('.welcome-user').text($scope.smuser);       //displaying username on header
                $scope.currentUser = user;
                if ($scope.rpAppId === null || $scope.rpAppId === "" || $scope.rpAppId === "undefined") {
                    $scope.isTBUserLoggedIn = true;
                }
            }
        });
    }

    $scope.sessionTimeoutModel = {
        sessionTimeoutUrl:'/app/index.html?reason=sl#/login',
        sessionWarningTimeInMinutes: 10,
        sessionLogoutTimeInMinutes: 16 // min 2
    };

    $scope.busyIndicatorModel = {
        imageUrl: "/tb/images/loader.gif",
        busyIndicatorDelay : 0,
        text: $translate.instant("busyIndicatorText")
    };

    $scope.signOut = function() {
        $http.get('/tb/services/rest/user/signoutuser').then(function() {
            $scope.rpAppId = null;
            $window.location = '../index.html?LOGOUT=TRUE#/login';
        });
    };

    $scope.help = function() {

        //Send a tracking event when help link is clicked
        if(typeof _satellite !== "undefined"){
            pageDataLayer.content.siteErrorType = "";
            pageDataLayer.content.siteErrorFields = "";
            pageDataLayer.content.siteSectionL1="";
            pageDataLayer.content.pageName="helpPage";
            _satellite.track('trackPageView');
        }
    };

    $scope.checkForRp = function() {
        getUserName();
        GeneralService.getData('/tb/services/rest/rp/checkIfRPExists').then(function(response) {
            $scope.isRPContextExist = response;
        });
        $scope.rpUrl="/tb/services/rest/rp/rpapplogo";
        $scope.ftrImgUrl = "/tb/services/rest/rp/footerlogo";
    };

    // WCAG Focus Management
    // This is similar to index-app.js implementation,
    // except here we do not want to put :focus on <main> if you are on the uitk:tab pages
    $rootScope.$on("$stateChangeSuccess", function(e, toState) {
        var bodyStr = "body"; // Sonar FIX

        if (toState.url !== "/verifyoptions" && toState.url !== "/profileinfo" && toState.url !== "/changepwd") {
            // For WCAG: To solve SPA issue. To get screen readers to announce the changed content.
            $timeout(function() {
                $(bodyStr).append("<span class='loading-message' tabindex='-1'>loading</span>");
                $(".loading-message").focus();

                $timeout(function() {
                    $("main").attr("aria-label", angular.element(document.getElementsByTagName("h1")[0]).text());
                    $("main").attr("tabindex", -1).focus();
                    $(".loading-message").remove();
                    $("main").removeAttr("tabindex");
                }, 1000);
            }, 10);
        }
    });

    // For analytics
    var reqVar = $translate.instant('RQD_VAR');

    $rootScope.$watch(function() {
        return $rootScope.fireErrorTracker;
    }, function(val) {
        if (AnalyticsService.globalAnalyticsObj.elemCount && val) { // &&val todo
            $timeout(function() {
                $scope.trackError(AnalyticsService.globalAnalyticsObj.postCallCount, true);
            });
        }
    });

    $rootScope.fireErrorTracker = false;

    $rootScope.trackError = function(count, isCallMadeFrmWatch) {
        if ($rootScope.fireErrorTracker && AnalyticsService.globalAnalyticsObj.elemCount && (count === AnalyticsService.globalAnalyticsObj.elemCount || isCallMadeFrmWatch)) {
            AnalyticsService.globalAnalyticsObj.postCallCount = 0;
            $rootScope.fireErrorTracker = false;

            var errorStr = "";
            var fName = "";
            var errStatus = "";
            var objKeys = Object.keys(AnalyticsService.globalAnalyticsObj.errorTrackObj);
            var objKeyLen = objKeys.length;
            var tempObj;

            for (var keys = 0; keys < objKeyLen; keys++) {
                tempObj = AnalyticsService.globalAnalyticsObj.errorTrackObj[objKeys[keys]];
                // errorStr = errorStr + tempObj.fieldName + ":" + AnalyticsService.errorMapObj.en_US[tempObj.errorElem.html()] + "|";
                if (tempObj.errorElem.text().indexOf(reqVar) !== -1) {
                    errStatus = ":missing field";
                } else {
                    errStatus = ":invalid field";
                }

                if (tempObj.fieldName.indexOf("||") !== -1) {
                    fName = tempObj.fieldName.split('||')[0];
                } else {
                    fName = tempObj.fieldName;
                }

                errorStr = errorStr + fName + errStatus + "|";
            }
            var retStr = errorStr.substring(0, errorStr.length-1);
            AnalyticsService.postErrorTrackInfo("field validation error", retStr);
        }
    };
}
