package com.optum.trustbroker.controller.vo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.optum.trustbroker.vo.CommunicationChannel;


@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class VerifyCodesVO extends ResponseVO {

	public VerifyCodesVO(){}
	
	private String infoMessage;
	private String nextState;
	private String primaryEMailCode;
	private StringBuilder alertBuilder;
	private String registerDevice;
	private String devicePrint;
	private VerifyCodesCtx ctx;
	private boolean showPrmEmail;
	private String email;
	private CommunicationChannel channel;
	private boolean emailShared;
	private String maskedEmail;
	//private Map<String, String> errorMap;
	
	public String getMaskedEmail() {
		return maskedEmail;
	}
	public void setMaskedEmail(String maskedEmail) {
		this.maskedEmail = maskedEmail;
	}
	public boolean isEmailShared() {
		return emailShared;
	}
	public void setEmailShared(boolean emailShared) {
		this.emailShared = emailShared;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public CommunicationChannel getChannel() {
		return channel;
	}
	public void setChannel(CommunicationChannel channel) {
		this.channel = channel;
	}
	/*public Map<String, String> getErrorMap() {
		return errorMap;
	}
	public void setErrorMap(Map<String, String> errorMap) {
		this.errorMap = errorMap;
	}*/
	public String getPrimaryEMailCode() {
		return primaryEMailCode;
	}
	public void setPrimaryEMailCode(String primaryEMailCode) {
		this.primaryEMailCode = primaryEMailCode;
	}
	public StringBuilder getAlertBuilder() {
		return alertBuilder;
	}
	public void setAlertBuilder(StringBuilder alertBuilder) {
		this.alertBuilder = alertBuilder;
	}
	public String getRegisterDevice() {
		return registerDevice;
	}
	public void setRegisterDevice(String registerDevice) {
		this.registerDevice = registerDevice;
	}
	public String getDevicePrint() {
		return devicePrint;
	}
	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}
	public boolean isShowPrmEmail() {
		return showPrmEmail;
	}
	public void setShowPrmEmail(boolean showPrmEmail) {
		this.showPrmEmail = showPrmEmail;
	}
	public String getInfoMessage() {
		return infoMessage;
	}
	public void setInfoMessage(String infoMessage) {
		this.infoMessage = infoMessage;
	}
	public String getNextState() {
		return nextState;
	}
	public void setNextState(String nextState) {
		this.nextState = nextState;
	}

	public VerifyCodesCtx getCtx() {
		return ctx;
	}

	public void setCtx(VerifyCodesCtx ctx) {
		this.ctx = ctx;
	}
}
