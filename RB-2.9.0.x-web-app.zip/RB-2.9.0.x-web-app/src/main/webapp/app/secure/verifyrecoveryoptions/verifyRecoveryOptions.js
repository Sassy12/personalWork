(function () {

    'use strict';

    var tbApp = angular.module('tbApp');

    tbApp.controller("VerifyRecoveryOptionsController", VerifyRecoveryOptionsController);

    VerifyRecoveryOptionsController.$inject = ['$window', '$translate', 'VerifyRecoveryOptionsService','$state'];

    function VerifyRecoveryOptionsController($window, $translate, VerifyRecoveryOptionsService, $state) {

        // initializing flags
        var self = this;

        var initData = VerifyRecoveryOptionsService.getRecoveryOptionsData().data;
        self.pageData = initData;

        if(initData.preferenceType === 'MOBILE'){
            self.verifyMobilePhone = true;
            self.phoneNo = initData.maskedValue;
        }else{
            self.verifyEmail = true;
            self.email = initData.maskedValue;
        }
        
        
        pageDataLayer.content.siteSectionL1="";
        
        if(self.verifyMobilePhone){
            self.pageHeading = $translate.instant('mobPhoneHeading');
            pageDataLayer.content.pageName="verifyYourMobilePhone";
        }else{
            self.pageHeading = $translate.instant('emailHeading');
            pageDataLayer.content.pageName="verifyYourSecondaryEmail";
        }
        
        if(typeof _satellite !== "undefined"){
            _satellite.track('trackPageView');
        }
        self.savePreferences = function (skipAlways) {

            var postData = {
                'skipForever' : skipAlways,
                'preferenceType' : initData.preferenceType
            };
            // save preferences in backend
            VerifyRecoveryOptionsService.savePreferences(postData)
                .then(function (response) {
                    if (response.data.status === 'proceedNext') {
                        $window.location.href = "/tb/app/secure/home.do";
                    }
                });

        };

        self.verifyOption = function(fieldName){

            if(fieldName === 'Mobile'){
                $state.go('mobileVerification', { fieldToVerify : 'mobileNo', fromState : 'home' });
            }else{
                $state.go('confirmEmailAddress', {
                    verifyCodesCtx: {
                        viewChannels : ['SECONDARY_EMAIL'],
                        sendChannels : ['SECONDARY_EMAIL'],
                        chann : 'SECONDARY_EMAIL',
                        nextView : 'congratulations',
                        optionValue : initData.preferenceValue
                    },
                    fromState: 'home'
                });
            }

        };

    }

})();

