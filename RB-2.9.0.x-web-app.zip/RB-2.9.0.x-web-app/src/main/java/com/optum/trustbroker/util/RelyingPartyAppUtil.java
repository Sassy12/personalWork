package com.optum.trustbroker.util;

import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.context.ApplicationContext;
import com.optum.trustbroker.context.ApplicationContextHolder;
import com.optum.trustbroker.context.persistence.ApplicationContextRepository;
import com.optum.trustbroker.esso.sso.SsoContext;
import com.optum.trustbroker.esso.sso.utils.SsoUtils;
import com.optum.trustbroker.service.InvitationService;
import com.optum.trustbroker.service.RelyingPartyAppService;
import com.optum.trustbroker.service.UserVerifyCodesService;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserVerifyCdCtxVO;
import com.optum.trustbroker.vo.UserVerifyCodesServiceResponse;
import com.uhg.iam.alps.common.crypto.CryptAgent;

public class RelyingPartyAppUtil {
    private static final BaseLogger LOG = new BaseLogger(RelyingPartyAppUtil.class);
    private final RelyingPartyAppService rpService;
    private final CryptAgent cryptAgent;
    private final InvitationService invitationService;
    private final UserVerifyCodesService userVerifyCodesService;
    private final String oldGenVersion;
    private final ApplicationContextRepository appCtxRepo;

    public RelyingPartyAppUtil(RelyingPartyAppService rpService, CryptAgent cryptAgent, InvitationService invitationService,
        UserVerifyCodesService userVerifyCodesService, ApplicationContextRepository acr) {
        this.rpService = rpService;
        this.cryptAgent = cryptAgent;
        this.invitationService = invitationService;
        this.userVerifyCodesService = userVerifyCodesService;
        ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");
        oldGenVersion = tbResources.getString(TrustBrokerConstants.OLD_GEN_APP_VERSION);
        appCtxRepo = acr;
    }

    public RelyingPartyAppVO getRelyingParty(HttpServletRequest hsReq, HttpServletResponse hsResp) {
        String encryptInd = hsReq.getParameter(TrustBrokerWebAppConstants.ENCRYPT);
        String rpAppId = hsReq.getParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
        if (encryptInd != null) {
            rpAppId = cryptAgent.decrypt(rpAppId);
        }
        // Check if SSO context available or not, if not then load the context.
        ApplicationContext ctx = ApplicationContextHolder.getContext();
        if (ctx == null) {
            ctx = appCtxRepo.loadContext(hsReq);
            // set it now
            if (ctx != null) {
                ctx.setHttpServletRequest(hsReq);
                ctx.setHttpServletResponse(hsResp);
                ApplicationContextHolder.setContext(ctx);
            }
        }
        // Check if it is SSO broker operation and get the RP details from app context.
        if (rpAppId == null && SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
            try {
                rpAppId = ApplicationContextHolder.getContext().retrieve(SsoContext.class).getDestinationApp();
            }
            catch (Exception ex) {
                LOG.error("Failed to obtain RP ID from SSO broker request", ex);
            }
        }

        // determine rp app id from invitation if in this flow
        String invitation = hsReq.getParameter(TrustBrokerWebAppConstants.INVITATION);
        if (StringUtils.isNotBlank(invitation)) {
            Map<String, String> invitationMap = invitationService.decodeInvitationDetails(invitation);
            if (invitationMap != null) {
                invitationMap = invitationService.decodeInvitationDetails(invitation);
                rpAppId = invitationMap.get(InvitationConstants.KEY_REPLYING_PARTY_APP_ID);
            }
        }
        // determine rp app id from verification details
        String paramVerfication = hsReq.getParameter(TrustBrokerConstants.VERIFICATION_DETAILS);
        if (StringUtils.isNotBlank(paramVerfication)) {
            Map<String, String> verificationDetails = cryptAgent.getAttributesFromToken(paramVerfication, true);
            if (verificationDetails != null) {
                UserVerifyCodesServiceResponse verifyCodeResponse = userVerifyCodesService
                    .getUserVerifyCodesByRequestToken(verificationDetails.get(TrustBrokerConstants.REQUEST_TOKEN));
                if (verifyCodeResponse != null && verifyCodeResponse.getUserVerifyCodesVO() != null
                    && verifyCodeResponse.getUserVerifyCodesVO().getUserVerifyCdCtxVO() != null) {
                    for (UserVerifyCdCtxVO usrVerifyCdCtx : verifyCodeResponse.getUserVerifyCodesVO().getUserVerifyCdCtxVO()) {
                        if (usrVerifyCdCtx != null) {
                            if (StringUtils.equals(usrVerifyCdCtx.getCtxName(), TrustBrokerWebAppConstants.RELYING_APP_ID)) {
                                rpAppId = usrVerifyCdCtx.getCtxValue();
                                break;
                            }
                        }
                    }
                }
            }
        }
        if (LOG.isTraceEnabled()) {
            LOG.trace("rpAppId: " + rpAppId);
        }
        if (StringUtils.isNotBlank(rpAppId)) {
            return rpService.fetchRelyingPartyAppByAppId(rpAppId);
        }
        return null;
    }

    public boolean isNextGen(RelyingPartyAppVO rpApp) {
        if (rpApp != null) {
            if (StringUtils.equals(oldGenVersion, rpApp.getTbVersion())) {
                return false;
            }
        }
        return true;
    }
}
