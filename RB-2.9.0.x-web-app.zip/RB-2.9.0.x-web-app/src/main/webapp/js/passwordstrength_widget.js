
function checkPasswordStrength(formId, pwdFieldId, passwordStrengthId, unameFieldId){

        var weak='Weak';
        var medium='Good';
        var strong='Strong';
        var barId = formId + ':bar';
        var passwordStrengthValueId = formId + ':' + passwordStrengthId;
        var pwdId = formId + ':' + pwdFieldId;
        var unameId = formId + ':' + unameFieldId;
        var bar = document.getElementById(barId);
        var pwdStrengthValue = document.getElementById(passwordStrengthValueId);
        var startValue=pwdStrengthValue.value;
 
       
        var cell = bar.parentNode;
         
        var password =  document.getElementById(pwdId).value;  
        var username = document.getElementById(unameId).value;
        
        var checks = new Array();
        var strength = getStrength(password, checks, username);
        var returnVal = weak;
       /* bar.setAttribute("role", "");*/
        
		if(strength== 'N')
        {
             bar.innerHTML='';
             cell.className='nocolor';
             pwdStrengthValue.value = '';
        }
		else if(strength =='W')
		{
            returnVal = weak;
            bar.innerHTML='<strong><font color="white">' + weak + '</span></font></strong>';
            cell.className='weak';
            pwdStrengthValue.value = weak;
		}
		else if(strength =='S')
		{
            returnVal = strong;
            bar.innerHTML='<strong><font color="white">' + strong + '</span></font></strong>';
            cell.className='strong';
            pwdStrengthValue.value = strong;
		}
		else if(strength =='M')
        {
            returnVal = medium;
            bar.innerHTML='<strong><font color="white">' + medium + '</span></font></strong>';
            cell.className='medium';
            pwdStrengthValue.value = medium;
		}
		else
		{
            returnVal = medium;
            bar.innerHTML='<strong><font color="white">' + medium + '</span></font></strong>';
            cell.className='medium';
            pwdStrengthValue.value = medium;
		}
		
	return returnVal;
  };
 
  
function  getStrength(pwd, checks, username){
  
   var minLength=8;
   var maxLength=100;
   var strength='N';
   var upperPresent=false;
   var lowerPresent=false;
   var numberPresent=false;
   var specialCharPresent=false;
   var isEmpty=false;
   var incorrectLength=false;
   var ampersandPresent=false;
   
 
  
   if(pwd =="")
     isEmpty=true;
   
  
   var array = new Array(127);
   for(var j=0; j <=127; j++) {
     array[j]=0;
   }
  
   for(var i=0;i<pwd.length;i++){
    var a = pwd.charAt(i).charCodeAt(0);
     if(a > -1 && a<= 126 ){ //non ascii actually not allowed
        if(a>=65 && a<=90)
            upperPresent = true;
        else  if(a>=97 && a<=122)
            lowerPresent=true;
        else if(a>=48 && a<=57)
            numberPresent =true;
        else if(a==38)
        	ampersandPresent=true;
        else if(a != 32)
            specialCharPresent=true;
            
        array[a] = array[a]+1;
       
     }
   }
  
   var strengthCounter=0;
   
   if(upperPresent)
      strengthCounter++;
   if(lowerPresent)
      strengthCounter++;
   if(numberPresent)
      strengthCounter++;
   if(specialCharPresent)
	      strengthCounter++;
   if(incorrectLength)
      strengthCounter=0;
  
   strength='W';
   
   if(strengthCounter == 2)
        strength= 'W'; 
   if(strengthCounter == 3 && upperPresent && lowerPresent && numberPresent)
       strength= 'M'; 
   if(strengthCounter == 4)
        strength= 'S';
         
   if (pwd.length < minLength){
     incorrectLength=true;
     strength= 'W';
   }
   
   if (pwd.length > maxLength){
	     incorrectLength=true;
	     strength= 'W';
   }
   
    if(isEmpty)
      strength='N';
      
   checks[0] = incorrectLength;
   checks[1] = lowerPresent;
   checks[2] = upperPresent;
   checks[3] = numberPresent;
   checks[4] = specialCharPresent;
   checks[5] = ampersandPresent;
   checks[6] = isEmpty;
     
   
   return strength;
 };

var charLenght;
var upperCase;
var lowerCase;
var numeric;
var nonAlpha;

function checkPasswordRulesChange(formId, passwordPanelId){
	var charLenghtTemp = document.getElementById("passwordInput:rule0").innerHTML;
	var upperCaseTemp = document.getElementById("passwordInput:rule1").innerHTML;
	var lowerCaseTemp = document.getElementById("passwordInput:rule2").innerHTML ;
	var numericTemp = document.getElementById("passwordInput:rule3").innerHTML; 
	var nonAlphaTemp = document.getElementById("passwordInput:rule4").innerHTML;
	
	var rawElement = document.getElementById(formId+":"+passwordPanelId);
	var ele = $(rawElement);
	
	if(charLenght!=charLenghtTemp || upperCase!=upperCaseTemp || lowerCase!= lowerCaseTemp || numeric!=numericTemp || nonAlpha!= nonAlphaTemp  ){
		//aria live assertive
		ele.attr("aria-live", "assertive");
	}else{
		//remove aria live asseritve
		ele.removeAttr("aria-live");
	}
	
	if(charLenght!=charLenghtTemp)
		charLenght=charLenghtTemp;
	
	if(upperCase!=upperCaseTemp)
	upperCase=upperCaseTemp;
	
	if(lowerCase!= lowerCaseTemp)
		lowerCase= lowerCaseTemp;
	
	if(numeric!=numericTemp)
		numeric=numericTemp;
	
	if(nonAlpha!= nonAlphaTemp)
		nonAlpha= nonAlphaTemp;
}
 
  function displayPasswordRules(formId, pwdFieldId, popUpId, unameFieldId){

     var strength =  checkPasswordStrength(formId,pwdFieldId, popUpId, unameFieldId);

    var popUp = document.getElementById(formId+":"+popUpId);
    var password =  document.getElementById(formId+":"+pwdFieldId).value;
    var username = document.getElementById(formId+":"+unameFieldId).value;
    var checks = new Array(false,false,false,false,false,false,false,false,false,false,false);
    getStrength(password, checks, username);
    
    var htmlText = '<div class="oxnamevalidate" style="display: block;"><div style="border:1px solid black;border-radius:11px;" > <ul>';
    var spanRuleFailText='<img style="margin-top:-4px;vertical-align:middle;" src="../images/checkfail.png" alt="" >';
    var spanRulePassText='<img style="margin-top:-4px;vertical-align:middle;" src="../images/checkpass.png" alt="">';
    var spanNonAlphaText='<span class="check nonalpha"></span>';

    var validTrue = '<span class="oui-a11y-hidden"> has been met.</span></span> ';
    var validFalse = '<span class="oui-a11y-hidden"> not yet met.</span></span> ';
    
    var incorrectLength =  checks[0];
    var lowerPresent = checks[1];
    var upperPresent = checks[2];
    var numberPresent = checks[3];
    var specialCharPresent = checks[4];
    var ampersandPresent = checks[5];
    var isEmpty = checks[6];
  
    var validMsg0=validFalse;
    var validMsg1=validFalse;
    var validMsg2=validFalse;
    var validMsg3=validFalse;

    htmlText +='<li id="passwordInput:rule5" role="presentation">';
    htmlText += '<span class="oui-a11y-hidden">Password strength: '+ strength +' </span></li>';

    htmlText +='<li id="passwordInput:rule0">';
    htmlText += (incorrectLength) ? spanRuleFailText : spanRulePassText;
    if( !incorrectLength)
        validMsg0 = validTrue;    
    htmlText += '<span class="ruletext">8 characters or more </span>'+validMsg0+'</li>';
           
    htmlText +='<li id="passwordInput:rule1">';
    if( upperPresent)
        validMsg1 = validTrue;     
    htmlText += (!(upperPresent)) ? spanRuleFailText : spanRulePassText;   
    htmlText += '<span class="ruletext">Uppercase characters </span>'+validMsg1+'</li>' ; 
            
    htmlText +='<li id="passwordInput:rule2">';
    if( lowerPresent)
        validMsg2 = validTrue;       
    htmlText += ((!lowerPresent)) ? spanRuleFailText : spanRulePassText;  
    htmlText += '<span class="ruletext">Lowercase characters </span>'+validMsg2+'</li>';
    
    htmlText +='<li id="passwordInput:rule3">';
    if( numberPresent)
        validMsg3 = validTrue;    
    htmlText += ((!numberPresent)) ? spanRuleFailText : spanRulePassText;  
    htmlText += '<span class="ruletext">Numeric </span>'+validMsg3+'</li>';
    

    var nonAlphaValid= ((specialCharPresent)) ? validTrue : "";
    htmlText +='<li id="passwordInput:rule4" class="rulenonalphatext">';
    htmlText += ((specialCharPresent)) ? spanRulePassText : spanNonAlphaText;
    htmlText += '<span class="ruletext">Non-alphanumeric characters </span><span class="oui-a11y-hidden"> optional '+nonAlphaValid+'</span></li>';

        
	popUp.style.display = 'block';
	popUp.innerHTML = htmlText;
  }

function displayPasswordRulesOnKeyUP(e,formId, pwdFieldId, popUpId, unameFieldId){
    if(e && e.which == 27) hidePasswordRules(formId, popUpId);
    else displayPasswordRules(formId, pwdFieldId, popUpId, unameFieldId);
}
  
  //function displayPasswordRulesResetpasswordWidget(formId, pwdFieldId, popUpId, unameFieldId){
	//
	//
	//    var popUp = document.getElementById(formId+":"+popUpId);
	//    var password =  document.getElementById(formId+":"+pwdFieldId).value;
	//    var username = document.getElementById(formId+":"+unameFieldId).value;
	//    var checks = new Array(false,false,false,false,false,false,false,false,false,false,false);
	//    getStrength(password, checks, username);
	//
	//    var htmlText = '<div class="oxnamevalidate" style="display: block;"><div style="border:1px solid black;border-radius:11px;" > <ul >';
	//    var spanRuleFailText='<IMG SRC="../images/checkfail.png" style="margin-left:8px;" alt="">';
	//    var spanRulePassText='<IMG SRC="../images/checkpass.png" style="margin-left:8px;" alt="">';
	//    var spanNonAlphaText='<span class="check nonalpha"></span>';
	//
	//    var incorrectLength =  checks[0];
	//    var lowerPresent = checks[1];
	//    var upperPresent = checks[2];
	//    var numberPresent = checks[3];
	//    var specialCharPresent = checks[4];
	//    var ampersandPresent = checks[5];
	//    var isEmpty = checks[6];
  //
  //      htmlText +='<li id="rule0" ><span class="ruletext" ><div style="margin-left:0px;" >';
  //      htmlText += (incorrectLength) ? spanRuleFailText : spanRulePassText;
  //      htmlText += '</div><div style="margin-left:30px;margin-top:-15px;">8 to 12 characters</div></span></li>';
  //
	//
	//    htmlText +='<li id="rule0" ><span class="ruletext" ><div style="margin-left:0px;" >';
	//    htmlText += (incorrectLength) ? spanRuleFailText : spanRulePassText;
	//    htmlText += '</div><div style="margin-left:30px;margin-top:-15px;">8 to 12 characters</div></span></li>';
	//
	//    htmlText +='<li id="rule1"><span class="ruletext" ><div style="margin-left:0px;" >';
	//    htmlText += (!(upperPresent)) ? spanRuleFailText : spanRulePassText;
	//    htmlText += '</div><div style="margin-left:30px;margin-top:-15px;">Uppercase characters</div></span></li>' ;
	//
	//    htmlText +='<li id="rule2"><span class="ruletext" ><div style="margin-left:0px;" >';
	//    htmlText += ((!lowerPresent)) ? spanRuleFailText : spanRulePassText;
	//    htmlText += '</div><div style="margin-left:30px;margin-top:-15px;">Lowercase characters</div></span></li>';
	//
	//    htmlText +='<li id="rule3"><span class="ruletext" ><div style="margin-left:0px;" >';
	//    htmlText += ((!numberPresent)) ? spanRuleFailText : spanRulePassText;
	//    htmlText += '</div><div style="margin-left:30px;margin-top:-15px;">Numeric</div></span></li>';
	//
	//    htmlText +='<li id="rule4"><span class="ruletext" ><div style="margin-left:0px;" >';
	//    htmlText += ((specialCharPresent)) ? spanRulePassText : spanNonAlphaText;
	//    htmlText += '</div><div style="margin-left:30px;margin-top:10px;">Non-alphanumeric characters</div></span></li><br/>';
	//
	//	popUp.style.display = 'block';
	//
	//	popUp.innerHTML = htmlText;
	//  }
  
  function hidePasswordRules(formId, popUpId) {
	document.getElementById(formId+":"+popUpId).style.display = 'none';
  }
  function strTrim(x) {
	    return x.replace(/^\s+|\s+$/gm,'');
  }
