'use strict';
var indexApp = angular.module('indexApp');
indexApp.controller('termsOfUsePreLoginCtrl', ['termsOfUseService', function(termsOfUseService){
	//Invoking the function to get the terms of use data
	termsOfUseService.getTermsData().then(function(data){
		var el = angular.element('#mainContent');
		el.html(data.content);
	});
}]);