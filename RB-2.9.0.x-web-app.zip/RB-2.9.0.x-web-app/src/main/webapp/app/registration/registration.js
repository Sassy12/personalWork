'use strict';

angular.module('indexApp').controller('RegistrationController', [
    '$scope',
    '$state',
    'trustbrokerAriaService',
    '$timeout',
    'LanguageService',
    '$translate',
    'RegistrationService',
    'regInitData',
    'uitkLiveRegionService',
    'AnalyticsService',
    '$rootScope',
    'HelpObj',
    RegistrationController
]);

function RegistrationController($scope, $state, trustbrokerAriaService, $timeout, LanguageService, $translate, RegistrationService, regInitData, uitkLiveRegionService, AnalyticsService, $rootScope, HelpObj) {
    var helpObj = { url: '../webHelp/Default.htm#Optum ID CSH/entry_1003_Create_an_Optum_ID.htm' };
    HelpObj.setHelpObj(helpObj);

    LanguageService.doTranslate('registration');

    $scope.rpAppVO = regInitData.data.rpAppVO;
    $scope.data = {};
    $scope.prevSharedEmail = "";
    $scope.prevNameEmail = "";
    $scope.userSuggestionsArray = [];
    $scope.showSuggestion = false;
    $scope.userSuggestionsInfoMsg = $translate.instant('userNameSuggMsg');
    $scope.selectOptumIdMsg = $translate.instant('selectOptumIdMsg');
    $scope.prevFocusSharedEmail = "";
    $scope.constants = $rootScope.constants;
    if(window.screen.width <= 420) {
        $scope.tooltipvalue = "tooltip-placement=left";
    } else {
        $scope.tooltipvalue = "";
    }

    if (undefined !== regInitData.data.rpAppVO && undefined !== regInitData.data.rpAppVO.appId) {
        var rpAppVO = regInitData.data.rpAppVO;
        $scope.showSQA = rpAppVO.showQuestions;

        if (rpAppVO.showDob) {
            $scope.showDOB = true;
            $scope.dobViewModel = {
                required:true,
                invalid: false,
                labelledBy:'dateOfBirthLabelId',
                displayAgeInformation:false,
                textFieldClassName: 'tk-height-2t',
                enableValidation: false,
                requiredMessage: 'dateOfBirthReq',
                invalidFormatMessage: 'invalidDateFormat',
                invalidDateMessage: 'invalidDate',
                dobInvalidFutureMessage: 'futureDate',
                invalidYearMessage: 'invalidYear',
                maxYear: new Date().getFullYear()
            };
        } else if (rpAppVO.coppaValidationReqd) {
            $scope.showYOB = true;
        }
    } else {
        $scope.showYOB = true;
        $scope.showSQA = true;
    }

    $scope.formLevelerrorMsgModel = {
        animationTime: 1,
        content: '<span translate="registrationFormErrorMsg" />',
        headingLevel: '2',
        id: 'registrationFormMsgID',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: true
    };

    if (undefined !== regInitData.data.errorMap && undefined !== regInitData.data.errorMap.errorMsg) {
        $scope.errorMsgModel = {
            animationTime: 1,
            content: '<span> ' + regInitData.data.errorMap.errorMsg + '</span>',
            headingLevel: '2',
            id: 'errorMsgId',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: true
        };
    }

    $scope.showSecQuestionBasedonSharedEmail = false;
    //$scope.pwdRulesMet = 0;
    //$scope.unameRulesMet = 0;
    $scope.coppaCount = 0;
    $scope.emailAddressReqError = false;
    $scope.yobReqError = false;
    $scope.unameReqError = false;
    $scope.confirmPwdReqError = false;
    $scope.secAns1ReqError = false;
    $scope.secAns2ReqError = false;
    $scope.secAns3ReqError = false;

    $scope.status = {
        'secQues1Valid': false,
        'secQues2Valid': false,
        'secQues3Valid': false
    };

    var select = {
        label: $translate.instant('select'),
        value: ''
    };

    $timeout(function(){
        var e1 = document.getElementById('dob_id_dob');

        if (null !== e1 && undefined !== e1) {
            e1.addEventListener('blur', function(){
                $scope.validateDOBFormat();
                $scope.setFieldValidity('dob_id_dob', 'dob_id_err');
            }, true);
        }
    }, 100);

    /* UITK 3.7 update */
    var allQuestions = [];
    if (undefined !== regInitData.data.securityQuestionVO) {
        angular.forEach(regInitData.data.securityQuestionVO.questions, function(securityQues) {
            this.push({
                label: securityQues.label,
                value: securityQues.value
            });
        }, allQuestions);
    }

    allQuestions.unshift(select);

    $scope.secList1 = $scope.secList2 = $scope.secList3 = allQuestions;
    $scope.secQues1 = $scope.secQues2 = $scope.secQues3 = allQuestions[0];

    $scope.questionSelected = function(index) {
        $timeout(function() {
            var i = 0;
            var questionsLen = allQuestions.length;

            // Filter Question one when question 2 or 3 are changed
            if (index !== '1') {
                i = 0;
                $scope.secList1 = [];

                for (var key1index = 0; key1index < questionsLen; key1index++) {
                    if (allQuestions[key1index] === allQuestions[0]) {
                        $scope.secList1[i] = allQuestions[key1index];
                        i++;
                    } else if (!(allQuestions[key1index].label === $scope.secQues2.label || allQuestions[key1index].label === $scope.secQues3.label)) {
                        $scope.secList1[i] = allQuestions[key1index];
                        i++;
                    }
                }
            }

            // Filter Question two when question 1 or 3 are changed
            if (index !== '2') {
                i = 0;
                $scope.secList2 = [];
                for (var key2index = 0; key2index < questionsLen; key2index++) {
                    if (allQuestions[key2index] === allQuestions[0]) {
                        $scope.secList2[i] = allQuestions[key2index];
                        i++;
                    } else if (!(allQuestions[key2index].label === $scope.secQues1.label || allQuestions[key2index].label === $scope.secQues3.label)) {
                        $scope.secList2[i] = allQuestions[key2index];
                        i++;
                    }
                }
            }

            // Filter Question three when question 1 or 2 are changed
            if (index !== '3') {
                i = 0;
                $scope.secList3 = [];
                for (var key3index = 0; key3index < questionsLen; key3index++) {
                    if (allQuestions[key3index] === allQuestions[0]) {
                        $scope.secList3[i] = allQuestions[key3index];
                        i++;
                    } else if (!(allQuestions[key3index].label === $scope.secQues1.label || allQuestions[key3index].label === $scope.secQues2.label)) {
                        $scope.secList3[i] = allQuestions[key3index];
                        i++;
                    }
                }
            }
        }, 300);

    };
    /* END: UITK 3.7 update */

    $scope.validateSecAnsText = function(event) {
        return validators.validateSecAns(event);
    };

    $scope.validateYOBFormat = function() {
        if ($scope.yob && !validators.checkIfEmpty($scope.yob)) {
            var yobValue = $scope.yob;
            $scope.yobReqError = false;

            if (isNaN(yobValue) || yobValue.length !== 4) {
                $scope.yobErrorMsg = $translate.instant('yobFormatErrorMsg');
                return;
            } else if (!validators.isValidYOB($scope.yob)) {
                $scope.yobErrorMsg = $translate.instant('invalidYear');
                return;
            }

            var postData = {
                yearOfBirth: yobValue,
                rpAppVO: $scope.rpAppVO
            };
            var coppaCountVal = $scope.coppaCount;

            RegistrationService.validateYOB(postData).then(function(response) {
                if (undefined !== response.data.errorMap && Object.keys(response.data.errorMap).length > 0) {
                    $scope.yobErrorMsg = response.data.errorMap.yobErrorMsg;
                    $scope.coppaCount = coppaCountVal;
                    $scope.setFieldValidity("yobId_input", "yobId_err");
                    return;
                }
            });

            $scope.yobErrorMsg = "";
        } else {
            $scope.yobReqError = true;
            $scope.yobErrorMsg = "";
        }

    };

    $scope.validateDOBFormat = function() {
        $scope.dobErrorMsg = "";

        if (!validators.checkIfEmpty($scope.dobViewModel.dateText)) {
            var dateErrorMsg = validators.isValidDate($scope.dobViewModel);

            if (!validators.checkIfEmpty(dateErrorMsg)) {
                $scope.dobErrorMsg = $translate.instant(dateErrorMsg);

                $timeout(function() {
                    $rootScope.fireErrorTracker = true;
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit("dob_id_dob", "dob_id_err");
                }, 300);

                return;
            }

            var postData = {
                dateOfBirth: $scope.dobViewModel.dateText,
                rpAppVO: $scope.rpAppVO
            };
            var coppaCountVal = $scope.coppaCount;

            RegistrationService.validateDOB(postData).then(function(response) {
                if (undefined !== response.data.errorMap && Object.keys(response.data.errorMap).length > 0) {
                    $scope.dobErrorMsg = response.data.errorMap.dobErrorMsg;
                    $scope.coppaCount = coppaCountVal;
                    $scope.setFieldValidity("dob_id_dob", "dob_id_err");
                    return;
                }
            });
        }
    };

    $scope.userNameChanged = function() {
        $scope.showSuggestion = false;
    };

    $scope.validateUserName = function() {
        $scope.setFieldValidity("userNameId_input", "userNameId_err");
        $scope.setFieldValidity("userNameId_input", "userNameId1_err");
        $scope.setFieldValidity("userNameId_input", "userNameId_info");

        if ($scope.userName && !validators.checkIfEmpty($scope.userName)) {
            $scope.unameReqError = false;

            if ($scope.unameRulesMet !== 4 && $scope.unameRulesMet !== 0) {
                $scope.userNameErrorMsg = $translate.instant('usernameMustMeetRequirement');
                $scope.showUserNameSuggestions = false;

                return;
            } else {
                $scope.userNameErrorMsg = '';
            }

            var postData = {
                userName: $scope.userName,
                firstName: $scope.firstName,
                lastName: $scope.lastName
            };
            RegistrationService.validateUserName(postData).then(function(response) {
                $scope.addUsernameSuggestions(response);
            });
        } else {
            $scope.unameReqError = true;
            $scope.userNameErrorMsg = "";
            $scope.showSuggestion = false;
        }
    };

    $scope.setFieldValidity = function(inputid, spanid) {
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        }, 300);
    };

    $scope.setEmailFieldValidity = function(inputid, spanid) {
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        }, 2000);
    };

    // For WCAG: Adding tooltip describedBy in our new username component
    $timeout(function() {
        angular.element(document.getElementById('userNameId_input')).attr("aria-describedby", "userNameTipId");
    }, 300);

    $scope.addUsernameSuggestions = function(response) {
        if (undefined === response.data.userNameSuggestionsList && Object.keys(response.data.errorMap).length === 0) {
            $scope.showSuggestion = false;
        } else if (undefined !== response.data.errorMap && undefined !== response.data.errorMap.userName) {
            $scope.userNameErrorMsg = response.data.errorMap.userName;
            $scope.showSuggestion = false;
        } else if (undefined !== response.data.userNameSuggestionsList && response.data.userNameSuggestionsList.length > 0 && !$scope.showSuggestion) {
            var suggestions = [];
            angular.forEach(response.data.userNameSuggestionsList, function(uNameSuggestion) {
                this.push({
                    label: uNameSuggestion + " ",
                    value: uNameSuggestion
                });
            }, suggestions);

            $scope.userSuggestionsArray = suggestions;
            $scope.showSuggestion = true;
            $scope.userNameErrorMsg = "";
            $timeout(function() {
                angular.element(document.getElementById('userNameId_input')).attr("aria-describedby", "userNameId_info userNameId_suggestions");
            }, 300);
        }
    };
    
    $scope.dialogCallBackHide = function() {
        
        if($scope.sharedEmailNotificationMsg) {
            $scope.prevSharedEmail = $scope.emailAddress;
        }
        if($scope.userExistswithNameAndEmail) {
            $scope.prevNameEmail = $scope.firstName+$scope.lastName+$scope.emailAddress;
        }
        $scope.sharedEmailNotificationMsg = false;
        $scope.userExistswithNameAndEmail = false;
        $scope.prevFocusSharedEmail.focus();
    };
    
    $scope.validateEmail = function() {
        if ($scope.emailAddress && !validators.checkIfEmpty($scope.emailAddress)) {
            
            $scope.emailAddressReqError = false;

            var postData = {
                firstName: $scope.firstName,
                lastName: $scope.lastName,
                emailAddress: $scope.emailAddress,
                rpAppVO: $scope.rpAppVO
            };

            RegistrationService.validateEmail(postData).then(function(response) {
                $scope.showSecQuestionBasedonSharedEmail = false;
                $scope.userExistswithNameAndEmail = false;
                $scope.sharedEmailNotificationMsg = false;
                $scope.emailAddressErrorMsg = "";

                if (undefined !== response.data.errorMap && Object.keys(response.data.errorMap).length > 0) {
                    $scope.emailAddressErrorMsg = response.data.errorMap.email;
                    $scope.showSecQuestionBasedonSharedEmail = response.data.showSecQuestionBasedonSharedEmail;
                    $scope.userExistswithNameAndEmail = "";
                    $scope.sharedEmailNotificationMsg = false;
                }

                if (undefined !== response.data.notificationMap && Object.keys(response.data.notificationMap).length > 0) {
                    
                    if(response.data.notificationMap.sharedEmail === "true" && 
                        $scope.prevSharedEmail !== $scope.emailAddress) {
                        $scope.sharedEmailNotificationMsg = response.data.notificationMap.sharedEmail;
                        $scope.prevFocusSharedEmail = document.activeElement;
                    }
                    if(response.data.notificationMap.userExists === "true" &&
                            $scope.prevNameEmail !== $scope.firstName+$scope.lastName+$scope.emailAddress) {    
                        $scope.userExistswithNameAndEmail = response.data.notificationMap.userExists;
                        $scope.prevFocusSharedEmail = document.activeElement;
                    }
                    $scope.showSecQuestionBasedonSharedEmail = response.data.showSecQuestionBasedonSharedEmail;
                    $scope.emailAddressErrorMsg = "";
                }
            });
        } else {
            $scope.emailAddressReqError = true;
            $scope.emailAddressErrorMsg = "";
            $scope.sharedEmailNotificationMsg = false;
            $scope.userExistswithNameAndEmail = false;
            $scope.showSecQuestionBasedonSharedEmail = false;
        }
    };

    // For Invitation service pre populate details
    if (regInitData.data.firstName) {
        // timeout required as uitk directive must be allowed to load before model can be populated
        $timeout(function() {
            $scope.firstName = regInitData.data.firstName;
        });

        if (regInitData.data.errorMap && undefined !== regInitData.data.errorMap.firstNameError) {
            $scope.firstNameErrorMsg = regInitData.data.errorMap.firstNameError;
        }
    }

    // For Invitation service pre populate details
    if (regInitData.data.lastName) {
        // timeout required as uitk directive must be allowed to load before model can be populated
        $timeout(function() {
            $scope.lastName = regInitData.data.lastName;
        });

        if (regInitData.data.errorMap && undefined !== regInitData.data.errorMap.lastNameError) {
            $scope.lastNameErrorMsg = regInitData.data.errorMap.lastNameError;
        }
    }

    // For Invitation service pre populate details
    if (regInitData.data.dateOfBirth) {
        // timeout required as uitk directive must be allowed to load before model can be populated
        $timeout(function() {
            angular.element('#dob_id_dob').val(regInitData.data.dateOfBirth);
        });
    }

    if (regInitData.data.emailAddress) {
        $timeout(function() {
            $scope.emailAddress = regInitData.data.emailAddress;
            $scope.validateEmail();
        });
    }

    // For Invitation service pre populate details
    if (regInitData.data.userName) {
        // timeout required as uitk directive must be allowed to load before model can be populated
        $timeout(function() {
            $scope.userName = regInitData.data.userName;
        });
        $scope.addUsernameSuggestions(regInitData);
    }

    $scope.clearFrstNameErrMsg = function() {
        $scope.firstNameErrorMsg = "";
        $scope.setFieldValidity('firstNameId_input', 'firstNameId_err');
    };

    $scope.clearLastNameErrMsg = function() {
        $scope.lastNameErrorMsg = "";
        $scope.setFieldValidity('lastNameId_input', 'lastNameId_err');
    };

    $scope.userNameRulesValidation = function() {
        var validationRules = validators.userNameValidation($scope.userName);
        var previousRulesMet = $scope.unameRulesMet;
        $scope.unameLengthValidation = validationRules.unameLengthValidation;
        $scope.unameLetterValidation = validationRules.unameLetterValidation;
        $scope.unamespCharacterValidation = validationRules.unamespCharacterValidation;
        $scope.unameSpaceValidation = validationRules.unameSpaceValidation;
        $scope.unameRulesMet = validationRules.unameRulesMet;

        // For WCAG
        if (previousRulesMet !== $scope.unameRulesMet) {
            if ($scope.unameRulesMet === 4) {
                uitkLiveRegionService.alertMessage($translate.instant('UsernameValidAlert'));
            } else {
                uitkLiveRegionService.alertMessage($translate.instant('UsernameNotValidAlert') + $scope.unameRulesMet + $translate.instant('UsernameNumberMetAlert'));
            }
        }
    };

    //Need this for getting the value of password on leaving the field
    $rootScope.$on('pwdValue', function(event, args){
        if (args.value && $scope.confirmPwd && args.value !== $scope.confirmPwd) {
             $scope.confirmPwdErrorMsg = $translate.instant('pwdDoNotMatch');
        }
        else {
            $scope.confirmPwdErrorMsg = "";
        }
    });
    //This function will only work for confirm password field
    $scope.validatePwds = function() {
        var pwd = "";
        var confirmPwd = "";
        $scope.confirmPwdReqError = false;

        if ($scope.pwd && !validators.checkIfEmpty($scope.pwd)) {
            pwd = $scope.pwd;
        }

        if ($scope.confirmPwd && !validators.checkIfEmpty($scope.confirmPwd)) {
            confirmPwd = $scope.confirmPwd;
        }

        if (pwd !== "" && confirmPwd !== "" && pwd !== confirmPwd) {
            $scope.confirmPwdErrorMsg = $translate.instant('pwdDoNotMatch');
        } else {
            $scope.confirmPwdErrorMsg = "";
        }

        if (confirmPwd === "") {
            $scope.confirmPwdReqError = true;
            $scope.confirmPwdErrorMsg = "";
        }
    };

    $scope.validateSecAns1 = function() {
        if ($scope.secAnswerOne && !validators.checkIfEmpty($scope.secAnswerOne)) {
            $scope.secAns1ReqError = false;
        } else {
            $scope.secAns1ReqError = true;
            $scope.secAns1ErrorMsg = false;
        }
    };

    $scope.validateSecAns2 = function() {
        if ($scope.secAnswerTwo && !validators.checkIfEmpty($scope.secAnswerTwo)) {
            $scope.secAns2ReqError = false;
        } else {
            $scope.secAns2ReqError = true;
            $scope.secAns2ErrorMsg = false;
        }
    };

    $scope.validateSecAns3 = function() {
        if ($scope.secAnswerThree && !validators.checkIfEmpty($scope.secAnswerThree)) {
            $scope.secAns3ReqError = false;
        } else {
            $scope.secAns3ReqError = true;
            $scope.secAns3ErrorMsg = false;
        }
    };

    $scope.firstName = '';
    $scope.lastName = '';
    $scope.dateOfBirth = '';
    $scope.yob = '';
    $scope.emailAddress = '';
    $scope.userName = '';
    $scope.pwd = '';
    $scope.confirmPwd = '';
    $scope.confirmPwdError = false;

    $scope.secQues1 = '';
    $scope.secQues2 = '';
    $scope.secQues3 = '';
    $scope.secAnswerOne = '';
    $scope.secAnswerTwo = '';
    $scope.secAnswerThree = '';

    //getting the password field validity from directive
    $rootScope.$on('IsPasswordValid', function(event, args) {
        $scope.passwordFieldValid = args.msg;
    });
    $scope.registerForm = function() {
        var FIELDS = [
            { fld: "firstNameId_input",         msg: "firstNameId_err" },
            { fld: "lastNameId_input",          msg: "lastNameId_err" },
            { fld: "yobId_input",               msg: "yobId_err" },
            { fld: "dob_id_dob",                msg: "dob_id_err" },
            { fld: "emailAddressId_input",      msg: "emailAddressId_err" },
            { fld: "userNameId_input",          msg: "userNameId_err" },
            { fld: "userNameId_input",          msg: "userNameId1_err" },
            { fld: "userNameId_input",          msg: "userNameId_info" },
            { fld: "pwdId_input",               msg: "pwdId_err" },
            { fld: "pwdId_input",               msg: "pwdId1_err" },
            { fld: "confirmPwdId_input",        msg: "confirmPwdId_err" },
            { fld: "secQues1Id",                msg: "secQuestionOneId_err" },
            { fld: "secAnswerOneId_input",      msg: "secAnswerOneId_err" },
            { fld: "secQues2Id",                msg: "secQuestionTwoId_err" },
            { fld: "secAnswerTwoId_input",      msg: "secAnswerTwoId_err" },
            { fld: "secQues3Id",                msg: "secQuestionThreeId_err" },
            { fld: "secAnswerThreeId_input",    msg: "secAnswerThreeId_err" }
        ];
        pageDataLayer.content.siteErrorCode = "";
        $scope.errorMsgModel = "";
        validateFormData();
        var dateString;
        
        if ($scope.showDOB) {
            var dateErrorMsg = validators.isValidDate($scope.dobViewModel);
            dateString = $scope.dobViewModel.dateText;
            if (!validators.checkIfEmpty(dateErrorMsg) || $scope.registrationForm.$invalid) {
                $scope.dobErrorMsg = $translate.instant(dateErrorMsg);
                $scope.registrationForm.submitted = true;

                $timeout(function() {
                    $rootScope.fireErrorTracker = true;
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                }, 300);

                return;
            }
        }

        if ($scope.registrationForm.$valid && !$scope.secQuestionsError && $scope.passwordFieldValid) {
            var postData = {
                'firstName': $scope.firstName,
                'lastName': $scope.lastName,
                'yearOfBirth': $scope.yob,
                'emailAddress': $scope.emailAddress,
                'userName': $scope.userName,
                'pwd': $scope.pwd,
                'confirmPwd': $scope.confirmPwd,
                'dateOfBirth': dateString,
                'coppaCount': $scope.coppaCount,
                'securityQuestionVO': {
                    questionOne: $scope.secQues1.value,
                    ansOne: $scope.secAnswerOne,
                    questionTwo: $scope.secQues2.value,
                    ansTwo: $scope.secAnswerTwo,
                    questionThree: $scope.secQues3.value,
                    ansThree: $scope.secAnswerThree
                },
                rpAppVO: $scope.rpAppVO
            };
            
            RegistrationService.registerUser(postData).then(function(responseData) {
                if (undefined !== responseData.data.errorMap && Object.keys(responseData.data.errorMap).length > 0) {
                    pageDataLayer.content.siteErrorCode = "";
                    pageDataLayer.content.siteErrorType = "";
                    $scope.registrationForm.submitted = true;
                    var errorMap = responseData.data.errorMap;

                    $scope.firstNameErrorMsg = undefined !== errorMap.firstNameError ? errorMap.firstNameError : "";
                    $scope.lastNameErrorMsg = undefined !== errorMap.lastNameError ? errorMap.lastNameError : "";
                    $scope.pwdErrorMsg = undefined !== errorMap.pwd ? errorMap.pwd : "";
                    $rootScope.$emit('serverError', {msg: $scope.pwdErrorMsg});             //emitting server side error
                    $scope.userNameErrorMsg = undefined !== errorMap.userName ? errorMap.userName : "";
                    $scope.emailAddressErrorMsg = undefined !== errorMap.email ? errorMap.email : "";
                    $scope.confirmPwdErrorMsg = undefined !== errorMap.confirmPwd ? errorMap.confirmPwd : "";
                    $scope.dobErrorMsg = undefined !== errorMap.dobErrorMsg ? errorMap.dobErrorMsg : "";
                    $scope.yobErrorMsg = undefined !== errorMap.yobErrorMsg ? errorMap.yobErrorMsg : "";
                    $scope.coppaCount = responseData.data.coppaCount;

                    if (undefined !== errorMap.yobErrorExceededMsg) {
                        $scope.yobErrorExceededMsg = errorMap.yobErrorExceededMsg;
                        $scope.yobErrorMsg = "";
                    }

                    if (undefined !== errorMap.dobErrorExceededMsg) {
                        $scope.dobErrorExceededMsg = errorMap.dobErrorExceededMsg;
                        $scope.dobErrorMsg = "";
                    }

                    $scope.secAns1ErrorMsg = undefined !== errorMap.secAns1ErrorMsg ? errorMap.secAns1ErrorMsg : "";
                    $scope.secAns2ErrorMsg = undefined !== errorMap.secAns2ErrorMsg ? errorMap.secAns2ErrorMsg : "";
                    $scope.secAns3ErrorMsg = undefined !== errorMap.secAns3ErrorMsg ? errorMap.secAns3ErrorMsg : "";

                    if (undefined !== errorMap.errorMsg) {
                        $scope.errorMsgModel = {
                            animationTime: 1,
                            content: '<span> ' + errorMap.errorMsg + '</span>',
                            headingLevel: '2',
                            id: 'errorMsg',
                            messageRole: 'alert',
                            messageType: 'error',
                            position: 'inline',
                            visible: true
                        };

                        var formErrorCode = getFormLevelErrorCode(errorMap.errorMsg);

                        if (formErrorCode) {
                            pageDataLayer.content.siteErrorCode = formErrorCode;
                            pageDataLayer.content.siteErrorFields = "";
                            pageDataLayer.content.siteErrorType = "Esso Error";
                            AnalyticsService.callAnalyticsForErrorTracking();
                        }
                    }

                    if (undefined !== errorMap.yobErrorExceededMsg) {
                        $scope.yobErrorExceededMsgModel = {
                            animationTime: 1,
                            content: '<span> ' + errorMap.yobErrorExceededMsg + '</span>',
                            headingLevel: '2',
                            id: 'yobErrorExceededMsgId',
                            messageRole: 'alert',
                            messageType: 'error',
                            position: 'inline',
                            visible: true
                        };
                    }

                    if (undefined !== errorMap.dobErrorExceededMsg) {
                        $scope.dobErrorExceededMsgModel = {
                            animationTime: 1,
                            content: '<span> ' + errorMap.dobErrorExceededMsg + '</span>',
                            headingLevel: '2',
                            id: 'dobErrorExceededMsgId',
                            messageRole: 'alert',
                            messageType: 'error',
                            position: 'inline',
                            visible: true
                        };
                    }

                    $timeout(function() {
                        $rootScope.fireErrorTracker = true;
                        trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    }, 300);

                    $timeout(function() {
                        $rootScope.fireErrorTracker = true;
                    }, 700);
                }

                if (responseData.data.nextState !== "") {
                    if (responseData.data.nextState === "confirmemail") {
                        $state.go("confirmEmailAddress", {
                            'verifyCodesCtx': responseData.data.verifyCodesCtx,
                            "emailShared": $scope.rpAppVO.emailShared
                        });
                    } else if (responseData.data.nextState === "congrats") {
                        $state.go("congratulations");
                    } else if (responseData.data.nextState === "home") {
                        window.location.href = "/tb/app/secure/home.do";
                    }
                }
            });
        } else {
            $scope.registrationForm.submitted = true;

            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);

            $timeout(function() {
                $rootScope.fireErrorTracker = true;
            }, 700);
        }
    };

    function getFormLevelErrorCode(errorMsg) {
        var formErrorCode;

        if (errorMsg) {
            if (errorMsg.indexOf(':') !== -1) {
                var errorMsgArray = errorMsg.split(':');
                var errorCode = errorMsgArray[0];

                if (errorCode.indexOf('-') !== -1) {
                    if (errorCode.split('-')[0] === 'OPT') {
                        formErrorCode = errorCode.trim();
                    }
                }
            }
        }
        return formErrorCode;
    }

    function validateFormData() {
        $scope.registrationForm.submitted = false;

        if (validators.checkIfEmpty($scope.emailAddress)) {
            $scope.emailAddressReqError = true;
            $scope.emailAddressErrorMsg = "";
        }

        if (validators.checkIfEmpty($scope.userName)) {
            $scope.unameReqError = true;
        }

        if (validators.checkIfEmpty($scope.confirmPwd)) {
            $scope.confirmPwdReqError = true;
        }

        if ($scope.showYOB) {
            var yobValue = $scope.yob;

            if (validators.checkIfEmpty($scope.yob)) {
                $scope.yobReqError = true;
            }

            if (yobValue !== "") {
                if (!validators.checkIfEmpty(yobValue) && (isNaN(yobValue) || yobValue.length !== 4)) {
                    $scope.yobErrorMsg = $translate.instant('yobFormatErrorMsg');
                    $scope.yobReqError = false;
                    return;
                }
            } else {
                $scope.yobErrorMsg = "";
            }
        }

        if ($scope.showSQA) {
            if (validators.checkIfEmpty($scope.secAnswerOne)) {
                $scope.secAns1ReqError = true;
            }

            if (validators.checkIfEmpty($scope.secAnswerTwo)) {
                $scope.secAns2ReqError = true;
            }

            if (validators.checkIfEmpty($scope.secAnswerThree)) {
                $scope.secAns3ReqError = true;
            }

            var status = $scope.status;

            if (!status.secQues1Valid || !status.secQues2Valid || !status.secQues3Valid) {
                $scope.secQuestionsError = true;
            } else {
                $scope.secQuestionsError = false;
            }
        }
    }
}
