package com.optum.trustbroker.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.LabelValueVO;
import com.optum.trustbroker.controller.vo.MessageVO;
import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.controller.vo.SecurityQuestionVO;
import com.optum.trustbroker.controller.vo.StepupContextVO;
import com.optum.trustbroker.controller.vo.StepupVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.service.ConfigurationService;
import com.optum.trustbroker.service.CredentialService;
import com.optum.trustbroker.service.ReferenceService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.ValidationUtils;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.ServiceResponse;
import com.optum.trustbroker.vo.TermsAndConditionsRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserChangePasswordServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.authentication.sm.HttpLoginRequest;
import com.uhg.iam.alps.authentication.sm.LoginRequest;
import com.uhg.iam.alps.authentication.sm.core.RedirectingLoginServiceWrapper;

@Path(TBConstants.STEPUP_CONTROLLER_PATH)
public class UserStepupController extends BaseController {

    @Autowired
    private ValidationUtils validationUtils;

    @Autowired
    private CredentialService credentialService;

    @Autowired
    private ReferenceService referenceService;

    @Autowired
    private RedirectingLoginServiceWrapper optumidSMDlwsBasedLoginService;

    private static final BaseLogger LOGGER = new BaseLogger(UserStepupController.class);

    @GET
    @Path(value = "/createStepupContext")
    @Produces(MediaType.APPLICATION_JSON)
    public StepupVO createStepupContext() {
        StepupVO stepupVO = new StepupVO();
        stepupVO.setUserInfoVO(new UserInfoVO());
        stepupVO.getUserInfoVO().setRpAppVO(new RpAppVO());

        boolean isCoppaRequired = true; //COPPA is required by default until turned off for an application

        UserVO userVO = getWebApplicationCommonUtilities().getCurrentUserDetailsFromWebApplicationContext();
        RelyingPartyAppVO relyingPartyAppVO = getWebApplicationCommonUtilities()
                .getRelyingPartyApplicationDetailsFromContext();

        if (relyingPartyAppVO != null && "N".equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
            isCoppaRequired = false;
        }
        StepupContextVO context = getWebApplicationCommonUtilities().getUserStepUpcontext(userVO, relyingPartyAppVO,
                isCoppaRequired, false);

        //Add if shared email is allowed by RP or not
        if (context.isShowEmail()) {
            stepupVO.getUserInfoVO().getRpAppVO().setEmailShared(!context.isEmailUnique());
        }

        //If I require security questions or shared email allowed I must get the list of questions
        if ((context.isShowSecQuestions() || !context.isEmailUnique()) && !context.isUserProfileHasSecQuestions()) {
            ChallengeQuestionServiceResponse challengeQuestionServiceResponse = configService.getSecurityQuestions();
            List<LabelValueVO> quesLists = createSecQuestionsModel(
                    challengeQuestionServiceResponse.getUserChallengeQuestions());
            SecurityQuestionVO secQuesVO = new SecurityQuestionVO();
            secQuesVO.setQuestions(quesLists);
            stepupVO.getUserInfoVO().setSecurityQuestionVO(secQuesVO);
        }
        stepupVO.setStepupContext(context);
        stepupVO.getUserInfoVO().getRpAppVO().setCoppaValidationReqd(isCoppaRequired);

        if (relyingPartyAppVO != null) {
            stepupVO.getUserInfoVO().getRpAppVO().setAppId(relyingPartyAppVO.getApplicationId());
            //Application Access is added only if consent is accepted after this. So if consent is required we will modify user using standalone configuration.
            if (!TrustBrokerConstants.SHOW_CONSENT_FORM_YES.equalsIgnoreCase(relyingPartyAppVO.getShowConsentForm())) {
                stepupVO.getUserInfoVO().getRpAppVO().setAlias(relyingPartyAppVO.getAlias());
            }
            if (TrustBrokerWebAppConstants.COPPA_REQUIRED_VALUE.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
                stepupVO.getUserInfoVO().getRpAppVO().setCoppaValidationReqd(true);
            } else {
                stepupVO.getUserInfoVO().getRpAppVO().setCoppaValidationReqd(false);
            }
        }
        //Initial Coppa Count is zero
        stepupVO.getUserInfoVO().setCoppaCount(0);

        //First and lastname added as need for username suggestions
        stepupVO.getUserInfoVO().setFirstName(userVO.getFirstName());
        stepupVO.getUserInfoVO().setLastName(userVO.getLastName());

        //Username added as need to display old username in view
        if (context.isShowUserName()) {
            stepupVO.getUserInfoVO().setUserName(userVO.getUserName());
        }
        return stepupVO;
    }

    @POST
    @Path(value = "/stepupUser")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public MessageVO stepupUser(StepupVO stepupVO, @Context HttpServletRequest httpRequest,
            @Context HttpServletResponse httpResponse) {
        MessageVO message = new MessageVO();
        UserInfoVO userInfoVO = stepupVO.getUserInfoVO();
        StepupContextVO ctx = stepupVO.getStepupContext();

        //All validations done here
        MessageVO validationMessage = validateAllStepupFields(userInfoVO, ctx);

        if (MapUtils.isNotEmpty(validationMessage.getErrorMap())) {
            return validationMessage;
        }

        List<String> modifiedUserAttrLst = new ArrayList<String>();
        UserVO userVO = getWebApplicationCommonUtilities().getCurrentUserDetailsFromWebApplicationContext();
        if (ctx.isShowEmail()) {
            modifiedUserAttrLst.add("MODIFY_EMAILS");
        }
        if (ctx.isMigratedUser()) {
            modifiedUserAttrLst.add(TrustBrokerConstants.MODIFY_MIGRATED_USER);
        }
        if (ctx.isShowUserName()) {
            userVO.setUserName(userInfoVO.getUserName());
        }
        if (ctx.isShowDob()) {
            modifiedUserAttrLst.add("MODIFY_DOB");
            userVO.setDob(DateUtil.parseDateMultipleFormats(userInfoVO.getDateOfBirth()));
            if (ctx.isCoppaRequired()) {
                userVO.setIsCoppaAccepted(TrustBrokerWebAppConstants.YES);
            }
        }
        if (ctx.isShowYOB()) {
            userVO.setIsCoppaAccepted(TrustBrokerWebAppConstants.YES);
        }
        //Email validation after submit sets isShowSecQuestionBasedonSharedEmail
        if ((ctx.isShowSecQuestions() || userInfoVO.isShowSecQuestionBasedonSharedEmail())
                && !ctx.isUserProfileHasSecQuestions()) {
            if (userInfoVO.getSecurityQuestionVO() != null) {
                modifiedUserAttrLst.add("MODIFY_CHALLENGE_RESPONSE_QUESTIONS");
                populateSecurityQuestions(userVO, userInfoVO);
            }
        }
        ServiceResponse servResponse;
        UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();

        userVO.setRpId(userInfoVO.getRpAppVO().getAlias());
        userProfileServiceRequest.setUser(userVO);

        //Update Password for migration first as user might provide older one so i needs to be validated first
        if (ctx.isShowPassword()) {
            UserChangePasswordServiceRequest userChangePwdRequest = new UserChangePasswordServiceRequest();
            userChangePwdRequest.setPassword(userInfoVO.getPwd());
            userChangePwdRequest.setUser(userVO);
            servResponse = credentialService.changePwd(userChangePwdRequest);
            if (!TrustbrokerWebAppUtil.checkResponseStatus(servResponse)) {
                message.setErrorMap(new HashMap<String, String>());
                if (StringUtils.isNotBlank(servResponse.getReasonMessage())) {
                    message.getErrorMap().put("pwd", servResponse.getReasonMessage());
                } else {
                    message.getErrorMap().put("pwd", tbResources.getString("failedPassUpdate"));
                }
                return message;
            }
        }

        //Update user name for migration
        if (ctx.isShowUserName()) {
            servResponse = credentialService.changeUserName(userProfileServiceRequest);
            if (!TrustbrokerWebAppUtil.checkResponseStatus(servResponse)) {
                message.setErrorMap(new HashMap<String, String>());
                message.getErrorMap().put("userName", tbResources.getString("failedUsernameUpdate"));
                return message;
            }
        }
        if (userVO.isMigratedUser()) {
            acceptTermsAndConditions(userVO);
        } //Agree terms and conditions

        UserProfileServiceResponse response = null;
        if (CollectionUtils.isNotEmpty(modifiedUserAttrLst)) {
            if (ctx.isShowEmail()) {
                userVO.setEssoPrimaryEmail(userVO.getEmailAddress());//First set the current email address to user.
                userVO.setEmailAddress(userInfoVO.getEmailAddress());
                userProfileServiceRequest.setUser(userVO);
            }
            response = userService.modifyUserForStepUp(userProfileServiceRequest, modifiedUserAttrLst);
        }

        if (TrustBrokerWebAppConstants.YES.equalsIgnoreCase(userVO.getIsCoppaAccepted()) && ctx.isCoppaRequired()) {
            userService.updateUserCoppaComplianceAccpeted(userVO);
        }

        if (CollectionUtils.isNotEmpty(modifiedUserAttrLst)) {
            if (!TrustbrokerWebAppUtil.checkResponseStatus(response)) {
                message.setResponseCode("500");
                message.setStatus("FAILS");
                return message;
            }
        }
        LOGGER.info("User profile updated successfuly on step up/migration for user {}",
                new String[] {userVO.getUserName()});
        
        
        SecurityLoggingUtil.info(SecurityLoggingUtil.buildAuditLogRequestVO("User Account Modifications",SecurityEventType.E3_MODIFY,
       			httpRequest, userVO.getUserName(), "Security Audit Event|ModifyUserProfile:SUCCESS | User Profile Modified during  Step Up, UsrSteupController:stepupUser()", SecurityEventResult.SUCCESS, 
       			getAppId(), SecuritySubEventType.E3_MODIFY_PROFILE));
     
        

        if (ctx.isShowUserName()) {
            LoginRequest loginRequest = new HttpLoginRequest(userVO.getUserName(), null, httpRequest, httpResponse);
            //TO-DO change according to home.do
            loginRequest.setProtectedUrl("/app/secure/home.do?relyingAppAlias=" + userInfoVO.getRpAppVO().getAlias());
            optumidSMDlwsBasedLoginService.login(loginRequest);
        }

        if (ctx.isMigratedUser()) {
            WebApplicationContextHolder.getContext().setSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED, "true");
        }

        return message;
    }

    private void populateSecurityQuestions(UserVO userVO, UserInfoVO userInfo) {

        UserChallengeQuestionVO question1 = new UserChallengeQuestionVO();

        String secQuestion1 = userInfo.getSecurityQuestionVO().getQuestionOne();
        String secQuestion1Array[] = secQuestion1.split("_");
        question1.setQuestionId(secQuestion1Array[0]);
        question1.setQuestion(secQuestion1Array[1]);
        question1.setAnswer(userInfo.getSecurityQuestionVO().getAnsOne());

        UserChallengeQuestionVO question2 = new UserChallengeQuestionVO();
        String secQuestion2 = userInfo.getSecurityQuestionVO().getQuestionTwo();
        String secQuestion2Array[] = secQuestion2.split("_");
        question2.setQuestionId(secQuestion2Array[0]);
        question2.setQuestion(secQuestion2Array[1]);
        question2.setAnswer(userInfo.getSecurityQuestionVO().getAnsTwo());

        UserChallengeQuestionVO question3 = new UserChallengeQuestionVO();
        String secQuestion3 = userInfo.getSecurityQuestionVO().getQuestionThree();

        String secQuestion3Array[] = secQuestion3.split("_");
        question3.setQuestionId(secQuestion3Array[0]);
        question3.setQuestion(secQuestion3Array[1]);
        question3.setAnswer(userInfo.getSecurityQuestionVO().getAnsThree());

        List<UserChallengeQuestionVO> securityQuestions = new ArrayList<UserChallengeQuestionVO>();
        securityQuestions.add(question1);
        securityQuestions.add(question2);
        securityQuestions.add(question3);
        userVO.setUserChallengeQuestions(securityQuestions);
    }

    private MessageVO validateAllStepupFields(UserInfoVO userInfoVO, StepupContextVO ctx) {
        MessageVO message = new MessageVO();
        if (ctx.isShowEmail()) {
            validationUtils.validateEmail(userInfoVO);
        }
        if (ctx.isShowUserName()) {
            validationUtils.validateUserName(userInfoVO);
        }
        if (ctx.isShowPassword()) {
            //If username was not updated then need to check with old username
            if (ctx.isShowUserName()) {
                validationUtils.validatePwd(userInfoVO);
            } else {
                UserVO userVO = getWebApplicationCommonUtilities().getCurrentUserDetailsFromWebApplicationContext();
                userInfoVO.setUserName(userVO.getUserName());
                validationUtils.validatePwd(userInfoVO);
                userInfoVO.setUserName(null);
            }

        }
        if (ctx.isShowDob()) {
            final int initialCoppa = userInfoVO.getCoppaCount();
            validationUtils.validateDOB(userInfoVO);
            if (initialCoppa != userInfoVO.getCoppaCount()) {
                String coppaCount = String.valueOf(userInfoVO.getCoppaCount());
                userInfoVO.addErrorMessage("coppaCount", coppaCount);
            }
            if (userInfoVO.getCoppaCount() >= 2) {
                userInfoVO.getErrorMap().remove("dobErrorMsg");
                userInfoVO
                        .addErrorMessage(
                                "dobErrorMsg", TBUtil
                                        .formatMessage(tbResources.getString("ageNotElibleMsgStepup"),
                                                new String[] {getWebApplicationCommonUtilities()
                                                        .getApplicationSupportContactInformation(true)
                                                        .getContactComboText()}));
            }

        }
        if (ctx.isShowYOB()) {
            int initialCoppa = userInfoVO.getCoppaCount();
            validationUtils.validateYOB(userInfoVO);
            if (initialCoppa != userInfoVO.getCoppaCount()) {
                String coppaCount = String.valueOf(userInfoVO.getCoppaCount());
                userInfoVO.addErrorMessage("coppaCount", coppaCount);
            }
            if (userInfoVO.getCoppaCount() >= 2) {
                userInfoVO.getErrorMap().remove("yobErrorMsg");
                userInfoVO
                        .addErrorMessage(
                                "yobErrorMsg", TBUtil
                                        .formatMessage(tbResources.getString("ageNotElibleMsgStepup"),
                                                new String[] {getWebApplicationCommonUtilities()
                                                        .getApplicationSupportContactInformation(true)
                                                        .getContactComboText()}));
            }
        }
        if (ctx.isShowSecQuestions() || !ctx.isEmailUnique()) {
            if (userInfoVO.getSecurityQuestionVO() != null) {
                validationUtils.validateSecurityInfo(userInfoVO);

            }
        }

        if (MapUtils.isNotEmpty(userInfoVO.getErrorMap())) {
            message.setErrorMap(userInfoVO.getErrorMap());
        }
        return message;
    }

    private boolean acceptTermsAndConditions(UserVO userVO) {

        try {
            TermsAndConditionsRetrievalServiceResponse response = referenceService.fetchTermsAndConditions(null);

            userService.updateUserAcceptedTermsAndConditionVersion(response.getTermsandConditions(), userVO);

            return true;
        } catch (OperationFailedException ope) {
            LOGGER.error("Error while excepting terms and condition for user: {}",
                    new String[] {userVO.getUserName(), TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
        }
        return false;
    }

    @Override
    public ConfigurationService getConfigService() {
        return configService;
    }

    @Override
    public void setConfigService(ConfigurationService configService) {
        this.configService = configService;
    }

    public ValidationUtils getValidationUtils() {
        return validationUtils;
    }

    public void setValidationUtils(ValidationUtils validationUtils) {
        this.validationUtils = validationUtils;
    }

    public CredentialService getCredentialService() {
        return credentialService;
    }

    public void setCredentialService(CredentialService credentialService) {
        this.credentialService = credentialService;
    }

    public ReferenceService getReferenceService() {
        return referenceService;
    }

    public void setReferenceService(ReferenceService referenceService) {
        this.referenceService = referenceService;
    }

    @Override
    public RedirectingLoginServiceWrapper getOptumidSMDlwsBasedLoginService() {
        return optumidSMDlwsBasedLoginService;
    }

    @Override
    public void setOptumidSMDlwsBasedLoginService(RedirectingLoginServiceWrapper optumidSMDlwsBasedLoginService) {
        this.optumidSMDlwsBasedLoginService = optumidSMDlwsBasedLoginService;
    }

}
