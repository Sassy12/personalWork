package com.optum.trustbroker.controller;


import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.controller.vo.LoginEmailVO;
import com.optum.trustbroker.domain.UserRelyingPartyRelation;
import com.optum.trustbroker.service.UserRelyingPartyRelationService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;


@Path(TBConstants.COMMON_SECURE_CONTROLLER_PATH)
public class CommonSecureController extends BaseController {
	
	private static final BaseLogger LOGGER = new BaseLogger(CommonSecureController.class);
	
	@Autowired
	private UserRelyingPartyRelationService userRelyingPartyRelationService;

	@POST
    @Path(value = "/getUser")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public LoginEmailVO getUser(LoginEmailVO loginEmailVO, @Context HttpServletRequest request) {
        
		LoginEmailVO loginResponse = new LoginEmailVO();
        String option = loginEmailVO.getEmail();
        LOGGER.debug("getUser option: " + option);//for future options
        UserVO userVO = new UserVO();
        String smuser = null;

        if ("test-mode".equals(option)) {
            loginResponse.setUsername("testUser");
            return loginResponse;
        }

        userVO = getWebApplicationCommonUtilities().getCurrentUserDetailsFromWebApplicationContext();

        LOGGER.debug("UserNameController getUser() - userVO from webApplicationCommonUtilities -" + userVO);
        if (userVO == null) {
            loginResponse.setUsername(StringUtils.EMPTY);
            LOGGER.debug(
                    "UserNameController getUser() - userVO null from common utilities. getting userid from request header");
            
            if ("test-smuser-mode".equals(option)) {
                smuser = "ngenuser";
            } else {
                smuser = request.getHeader("SM_USER");
            }
                
            if (smuser != null) {
                LOGGER.debug("UserNameController getUser() - userid from request header - " + smuser);
                UserRetrievalServiceResponse userResponse = getUserService().fetchUserProfile(smuser, false, false);
                LOGGER.debug("UserNameController getUser() userResponse from userService.fetchUserProfile " + userResponse);
                if (userResponse != null) {
                    userVO = userResponse.getUser();
                    loginResponse.setUsername(userVO.getUserName());
                    LOGGER.debug("UserNameController getUser() userVO from userService.fetchUserProfile " + userVO);
                }
            }
        } else {
            loginResponse.setUsername(userVO.getUserName());
        }

        return loginResponse;
    }
	
	@GET
	@Path(value = "/agreeConsent")
    public void agreeConsent() {
		UserVO userVO = getWebApplicationCommonUtilities().getCurrentUserDetailsFromWebApplicationContext();
		RelyingPartyAppVO relyingPartyAppVO = getWebApplicationCommonUtilities().getRelyingPartyApplicationDetailsFromContext();
		
		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(userVO);
		this.getUserService().checkAddApplicationAccess(userProfileServiceRequest, relyingPartyAppVO);
		UserRelyingPartyRelation userRelyingPartyRelation = userService.getAssociationBetweenUserAndRelyingApp(userVO.getUuId(), relyingPartyAppVO.getApplicationId());
		if(userRelyingPartyRelation == null){
			//Bad coding - Needs to be improved, one single method must be able to take care of consent
			userService.addUserRelyingPartyRelation(userProfileServiceRequest, relyingPartyAppVO);
			userRelyingPartyRelation = userService.getAssociationBetweenUserAndRelyingApp(userVO.getUuId(), relyingPartyAppVO.getApplicationId());
			userRelyingPartyRelation.setUserConsent(TrustBrokerWebAppConstants.YES);
		} else {
			userRelyingPartyRelation.setUserConsent(TrustBrokerConstants.USER_CONSENT_YES);
		}

		userRelyingPartyRelationService.updateUserRelyingPartyRelation(userRelyingPartyRelation);
		userService.saveUserConsent(userRelyingPartyRelation.getRelyingPartyApp(),userRelyingPartyRelation.getUser());
		
		LOGGER.debug("HomeBean:agreeConsent() | Processing agree consent for user ='" + userVO.getUserName() + "' with relying party ='" + relyingPartyAppVO.getApplicationId() +
				"' and TARGET URL='" + relyingPartyAppVO.getDefaultTargetUrl()+ "'");
    }
    
}