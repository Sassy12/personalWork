/*
 * Copyright 2016 Optum
 */
package com.optum.trustbroker.controller.vo;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.optum.trustbroker.util.TrustBrokerWebAppConstants;

/**
 * @author nvaneps
 */
@JsonIgnoreProperties
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AddressVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer addressId;
	private String streetAddress;
	private String city;
	private String state;
	private String country;
	private String zip;
	private String zipAreaCode;
	private String addressType;
	private boolean primaryAddress;

	public void fromAddress(com.optum.trustbroker.vo.AddressVO add) {
		if (add != null) {
			addressId = add.getAddressId();
			streetAddress = add.getStreetAddress();
			city = add.getCity();
			state = add.getState();
			country = add.getCountry();
			zip = add.getZip();
			zipAreaCode = add.getZipAreaCode();
			addressType = add.getAddressType();
			primaryAddress = TrustBrokerWebAppConstants.YES.equals(add.getIsPrimaryAddress());
		}
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getZipAreaCode() {
		return zipAreaCode;
	}

	public void setZipAreaCode(String zipAreaCode) {
		this.zipAreaCode = zipAreaCode;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public boolean isPrimaryAddress() {
		return primaryAddress;
	}

	public void setPrimaryAddress(boolean primaryAddress) {
		this.primaryAddress = primaryAddress;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}
}
