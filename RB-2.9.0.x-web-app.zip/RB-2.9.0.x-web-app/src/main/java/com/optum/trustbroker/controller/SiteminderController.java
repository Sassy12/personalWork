package com.optum.trustbroker.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.MessageVO;
import com.optum.trustbroker.controller.vo.SiteminderVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.ValidationUtils;

@Path(TBConstants.SITEMINDER_CONTROLLER_PATH)
public class SiteminderController extends BaseController {
	
	private static final BaseLogger logger = new BaseLogger(SiteminderController.class);

	@GET
	@Path(value = "/getAboutToExpiredMsg")
	@Produces(MediaType.APPLICATION_JSON)
	public SiteminderVO getAboutToExpiredMsg() {
		SiteminderVO siteminderVO = new SiteminderVO();
		WebApplicationContext ctx = WebApplicationContextHolder.getContext();
		String smAboutToExpiredMsg = ctx.getSessionAttribute(TrustBrokerWebAppConstants.SM_ABOUT_TO_EXPIRED_MSG);
		siteminderVO.setAboutToExpiredMsg(smAboutToExpiredMsg);
		return siteminderVO;
	}
	
	@GET
	@Path(value = "/removeAboutToExpiredMsg")
	@Produces(MediaType.APPLICATION_JSON)
	public SiteminderVO removeAboutToExpiredMsg() {
		SiteminderVO siteminderVO = new SiteminderVO();
		WebApplicationContext ctx = WebApplicationContextHolder.getContext();
		String smAboutToExpiredMsg = ctx.getSessionAttribute(TrustBrokerWebAppConstants.SM_ABOUT_TO_EXPIRED_MSG);
		if(StringUtils.isNotEmpty(smAboutToExpiredMsg))
			ctx.removeSessionAttribute(TrustBrokerWebAppConstants.SM_ABOUT_TO_EXPIRED_MSG);
		return siteminderVO;
	}
	
	@POST
	@Path(value = "/validatePwd")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public MessageVO validatePwd(SiteminderVO siteminderVO,
			@Context HttpServletRequest request, @Context HttpServletResponse response) {

		WebApplicationContext ctx = WebApplicationContextHolder.getContext();

		MessageVO messageVO = new MessageVO();
		Map<String, String> errorMap = new HashMap<String, String>();
		messageVO.setErrorMap(errorMap);
		
		// Validating Passwords from validations util
		UserInfoVO userInfoVO = new UserInfoVO();
		userInfoVO.setUserName(siteminderVO.getUserName());
		userInfoVO.setPwd(siteminderVO.getPwd());
		userInfoVO.setConfirmPwd(siteminderVO.getConfirmPwd());
		
		if(StringUtils.isNotEmpty(siteminderVO.getAboutToExpiredMsg())) { 
			ctx.setSessionAttribute(TrustBrokerWebAppConstants.SM_ABOUT_TO_EXPIRED_MSG, siteminderVO.getAboutToExpiredMsg());
		}

		ValidationUtils validationUtil = new ValidationUtils();
		validationUtil.validatePwd(userInfoVO);
		if (null != userInfoVO.getErrorMap() && userInfoVO.getErrorMap().get("confirmPwd") != null) {
			messageVO.getErrorMap().put("confirmPwd", userInfoVO.getErrorMap().get("confirmPwd"));
			return messageVO;
		}
		
		
		
		if (null != userInfoVO.getErrorMap() && userInfoVO.getErrorMap().get("pwd") != null) {
			messageVO.getErrorMap().put("pwd", userInfoVO.getErrorMap().get("pwd"));
			return messageVO;
		}
		
		return null;
	}

}
