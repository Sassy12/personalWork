package com.optum.trustbroker.controller.vo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class LoginResponseVO extends ResponseVO {

    private String redirect;

    private String errorMessage;

    private String successMessage;

    private String relyingAppAlias;

    private String relyingAppId;

    private String target;

    private boolean showRegistrationLink = true; // By default button has to be always displayed

    private String lockedUserID;

    private boolean localEnv;

    public LoginResponseVO() {

    }

    public String getRedirect() {
        return redirect;
    }

    public void setRedirect(String redirect) {
        this.redirect = redirect;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getSuccessMessage() {
        return successMessage;
    }

    public void setSuccessMessage(String successMessage) {
        this.successMessage = successMessage;
    }

    public boolean isShowRegistrationLink() {
        return showRegistrationLink;
    }

    public void setShowRegistrationLink(boolean showRegistrationLink) {
        this.showRegistrationLink = showRegistrationLink;
    }

    public String getLockedUserID() {
        return lockedUserID;
    }

    public void setLockedUserID(String lockedUserID) {
        this.lockedUserID = lockedUserID;
    }

    public String getRelyingAppAlias() {
        return relyingAppAlias;
    }

    public void setRelyingAppAlias(String relyingAppAlias) {
        this.relyingAppAlias = relyingAppAlias;
    }

    public String getRelyingAppId() {
        return relyingAppId;
    }

    public void setRelyingAppId(String relyingAppId) {
        this.relyingAppId = relyingAppId;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public boolean isLocalEnv() {
        return localEnv;
    }

    public void setLocalEnv(boolean localEnv) {
        this.localEnv = localEnv;
    }

}
