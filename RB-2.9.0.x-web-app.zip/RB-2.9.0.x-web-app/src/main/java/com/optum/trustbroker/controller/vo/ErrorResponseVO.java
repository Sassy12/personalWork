package com.optum.trustbroker.controller.vo;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.optum.trustbroker.message.MessageUtils;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class ErrorResponseVO implements Serializable {

	private String errorCode;
	private String referenceCode;
	private String message;
	
	public ErrorResponseVO(){
	}
	
	public ErrorResponseVO(String errorCode){
		this.errorCode = errorCode;
		this.referenceCode = MessageUtils.getErrorUid();
	}
	
	public ErrorResponseVO(String errorCode, String referenceCode, String message){
		this.errorCode = errorCode;
		this.referenceCode = referenceCode;
		this.message = message;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getReferenceCode() {
		return referenceCode;
	}
	public void setReferenceCode(String referenceCode) {
		this.referenceCode = referenceCode;
	}
}
