'use strict';
var tbApp = angular.module('tbApp');
tbApp.service('lexisNexisService', ['$http', '$q', function($http, $q){
	//function for getting the list of states
	this.getStates = function() {
		var deferred = $q.defer();
		$http.get('/tb/services/rest/states')
		.success(function(res){
			deferred.resolve(res);
		}).error(function(err){
			deferred.reject(err);
		});
		return deferred.promise;
	};
	//function for getting existing user information
	this.getInfo = function() {
		var deferred = $q.defer();
		//TODO:make http get call
		$http.get('/tb/services/secure/rest/id-proofing/user')
		.success(function(res){
			deferred.resolve(res);
		}).error(function(err){
			deferred.reject(err);
		});
		return deferred.promise;
	};
	//function for getting the user type
	this.getUserType = function() {
		var deferred = $q.defer();
		$http.get('/tb/services/secure/rest/id-proofing/type')
		.success(function(res) {
			deferred.resolve(res);
		}).error(function(err) {
			deferred.reject(err);
		});
		return deferred.promise;
	};
	//function for updating info
	this.saveInfo = function(postData) {
		var deferred = $q.defer();
		//TODO: make http post call to save data
		$http.post('/tb/services/secure/rest/manageid/profileinfo', postData)
		.success(function(res){
			deferred.resolve(res);
		}).error(function(err){
			deferred.reject(err);
		});
		return deferred.promise;
	};
	//function for posting ssn and credit card information
	this.proofUser = function(postData){
		var deferred = $q.defer();
		$http.post('/tb/services/secure/rest/id-proofing/proof-user-info', postData)
		.success(function(res) {
			deferred.resolve(res);
		}).error(function(err) {
			deferred.reject(err);
		});
		return deferred.promise;
	};
}]);
