'use strict';
var siteminderApp = angular.module('siteminderApp', [
    'common.services',
    'indexApp',
    'ngResource',
    'pascalprecht.translate',
    'trustbroker.AriaLibrary',
    'ui.router',
    'uitk.component.header',
    'uitk.component.uitkButton',
    'uitk.component.uitkFooter',
    'uitk.component.uitkHelp',
    'uitk.component.uitkLabel',
    'uitk.component.uitkMessage',
    'uitk.component.uitkTextField',
    'uitk.uitkUtility'
]);

siteminderApp.config(['$translateProvider', '$httpProvider', function($translateProvider, $httpProvider) {
    $translateProvider.useStaticFilesLoader({
        prefix: '/tb/app/siteminder/i18n/',
        suffix: '.json'
    });

    // Push service request interceptor to default interceptors array for random token
    $httpProvider.interceptors.push('httpRequestInterceptor');
    
    $translateProvider.preferredLanguage('en_US');
    $translateProvider.useSanitizeValueStrategy('escaped');
}]);


siteminderApp.controller('SMController', ['$rootScope', '$scope', 'trustbrokerAriaService', '$translate', '$window', '$timeout', 'uitkLiveRegionService', 'GeneralService', 'SiteminderService', 'HelpObj', 'AnalyticsService', SMController]);

function SMController($rootScope, $scope, trustbrokerAriaService, $translate, $window, $timeout, uitkLiveRegionService, GeneralService, SiteminderService, HelpObj, AnalyticsService) {

    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1036_Siteminder_Screens.htm' });

    $timeout(function() {
        if (document.getElementsByTagName("h1")[0]) {
            $rootScope.title = angular.element(document.getElementsByTagName("h1")[0]).text() + " - " + $translate.instant('optumID');
        } else {
            $rootScope.title = $translate.instant('optumID');
        }
    }, 1000);
    
    //setting the width of password component
    $timeout(function() {
    	$("#NEWPASSWORDId #NEWPASSWORDId_input").removeClass("tk-width-20t");
        $("#NEWPASSWORDId #NEWPASSWORDId_input").addClass("tk-width-22t");
    },300);
    

    $translate.refresh();

    var reqVar = $translate.instant('RQD_VAR');

    $rootScope.$watch(function() {
        return $rootScope.fireErrorTracker;
    }, function(val) {
        if (AnalyticsService.globalAnalyticsObj.elemCount && val) { // &&val todo
            $timeout(function() {
                $scope.trackError(AnalyticsService.globalAnalyticsObj.postCallCount, true);
            });
        }
    });

    $rootScope.fireErrorTracker = false;

    $scope.trackError = function(count, isCallMadeFrmWatch) {
        if ($rootScope.fireErrorTracker && AnalyticsService.globalAnalyticsObj.elemCount && (count === AnalyticsService.globalAnalyticsObj.elemCount || isCallMadeFrmWatch)) {
            AnalyticsService.globalAnalyticsObj.postCallCount = 0;
            $rootScope.fireErrorTracker = false;
            var errorStr = "";
            var fName = "";
            var errStatus = "";
            var objKeys = Object.keys(AnalyticsService.globalAnalyticsObj.errorTrackObj);
            var objKeyLen = objKeys.length;
            var tempObj;

            for (var keys = 0; keys < objKeyLen; keys++) {
                tempObj = AnalyticsService.globalAnalyticsObj.errorTrackObj[objKeys[keys]];

                if (tempObj.errorElem.text().indexOf(reqVar) !== -1) {
                    errStatus = ":missing field";
                } else {
                    errStatus = ":invalid field";
                }

                if (tempObj.fieldName.indexOf("||") !== -1) {
                    fName = tempObj.fieldName.split('||')[0];
                } else {
                    fName = tempObj.fieldName;
                }

                errorStr = errorStr + fName + errStatus + "|";
            }

            var retStr = errorStr.substring(0, errorStr.length - 1);
            AnalyticsService.postErrorTrackInfo("field validation error", retStr);
        }
    };
    //collection of input field id's and associated error id's
    var FIELDS = [
        { fld: "PASSWORDId_input",      msg: "PASSWORDId_err" },
        { fld: "NEWPASSWORDId_input",   msg: "NEWPASSWORDId_err" },
        { fld: "CONFIRMATIONId_input",  msg: "CONFIRMATIONId_err" },
        { fld: "CONFIRMATIONId_input",  msg: "CONFIRMATION1_err" }
    ];

    $scope.smauthreason = document.getElementById('smauthreasonid').value;
    $scope.targetUrl = document.getElementById('targetId').value;
    $scope.userMessage = document.getElementById('userMessage').value;
    $scope.userName = document.getElementById('USERNAMEId').value;
    $scope.confirmPwdReqError = false;
    $scope.oldGenReq = false;
    //model configurations for error messages
    $scope.errorMessageModel = {
        animationTime: 1,
        ariaAttributes: true,
        content: '<span translate="genericFormError"></span>',
        headingLevel: '2',
        id: 'errorMessage',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: true
    };

    $scope.onPageLoad = function() {
        var prevAuthReason = getParameterByName("prevAuthReason");

        if ($scope.smauthreason === "23") {
            if (prevAuthReason === "18") {
                SiteminderService.removeAboutToExpiredMsg();
            }

            document.PWChange.submit();
        }

        pageDataLayer.content.siteSectionL1 = "siteminder";

        if ($scope.smauthreason === "7" || $scope.smauthreason === "19" || $scope.smauthreason === "24" || $scope.smauthreason === "25") {
            HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1037_Account_Locked.htm' });
            pageDataLayer.content.pageName = "accountLocked";
        } else {
            pageDataLayer.content.pageName = "changePassword";
        }
        
        
        if ("" !== prevAuthReason) {
            $scope.smauthreason = prevAuthReason;
        }

        if ($scope.smauthreason === "18") {
            SiteminderService.getAboutToExpiredMsg().then(function(responseData) {
                if (null !== responseData.data.aboutToExpiredMsg) {
                    $scope.aboutToExpireMsg = responseData.data.aboutToExpiredMsg;
                } else {
                    $scope.aboutToExpireMsg = $scope.userMessage;
                }
            });
        }

        if ("" !== $scope.userMessage && "" !== prevAuthReason) {
            $scope.smErrorMessageModel = {
                animationTime: 1,
                ariaAttributes: true,
                content: '<span>' + $scope.userMessage + '</span>',
                headingLevel: '2',
                id: 'smErrorMessage',
                messageRole: 'alert',
                messageType: 'error',
                position: 'inline',
                visible: true
            };

            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);
        }

        GeneralService.postData('/tb/services/rest/commonController/getErrorMessageWithSupportInfo', 'siteminderSupportMsg').then(function(response) {
            var getElement = angular.element('#supportMsgId');
            getElement.html(response.data.message);
        });

        $scope.ftrImgUrl = "/tb/services/rest/rp/footerlogo";

        if ($scope.targetUrl.indexOf('.jsf') > -1) {
            $scope.oldGenReq = true;
        } else {
            $scope.oldGenReq = false;
        }
    };


    function getParameterByName(name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");

        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec($scope.targetUrl);

        return results === null ? "" : decodeURIComponent(results[1].replace(
            /\+/g, " "));
    }
    //validating password field and confirm password field matches or not
    $rootScope.$on('pwdValue', function(event, args) {
    	if ($scope.CONFIRMATION && args.msg !== $scope.CONFIRMATION) {
    		$scope.confirmPwdErrorMsg = $translate.instant('pwdDoNotMatchMsg');
    	}
    	else {
    		$scope.confirmPwdErrorMsg = "";
    	}
    });
    //validating confirm password field
    $scope.validatePwds = function() {
        var pwd = "";
        var confirmPwd = "";
        $scope.confirmPwdReqError = false;

        if ($scope.NEWPASSWORD && !validators.checkIfEmpty($scope.NEWPASSWORD)) {
            pwd = $scope.NEWPASSWORD;
        }

        if ($scope.CONFIRMATION && !validators.checkIfEmpty($scope.CONFIRMATION)) {
            confirmPwd = $scope.CONFIRMATION;
        }

        if (pwd !== "" && confirmPwd !== "" && pwd !== confirmPwd) {
            $scope.confirmPwdErrorMsg = $translate.instant('pwdDoNotMatchMsg');
        } else {
            $scope.confirmPwdErrorMsg = "";
        }

        if (confirmPwd === "") {
            $scope.confirmPwdReqError = true;
            $scope.confirmPwdErrorMsg = "";
        }
    };
    //checking if password field is valid
    $rootScope.$on('IsPasswordValid', function(event, args) {
    	$scope.passwordFieldValid = args.msg;
    });

    $scope.formSubmit = function() {
        if ($scope.oldGenReq) {
            document.PWChange.submit();
        }

        if (($scope.smauthreason === "18" || $scope.smauthreason === "20") && "" === getParameterByName("prevAuthReason")) {
            document.getElementById('targetId').value = $scope.targetUrl + "&prevAuthReason=" + $scope.smauthreason;
        }

        if (validators.checkIfEmpty($scope.PASSWORD)) {
            $scope.pwdReqError = true;
        }

        if (validators.checkIfEmpty($scope.NEWPASSWORD)) {
            $scope.newPwdReqError = true;
        }

        if (validators.checkIfEmpty($scope.CONFIRMATION)) {
            $scope.confirmPwdReqError = true;
        }

        $scope.newPwdErrorMsg = "";
        $scope.confirmPwdErrorMsg = "";
        $scope.newPwdServerErrorMsg = "";
        $scope.showFormError = false;

        if ($scope.PWChange.$valid && $scope.passwordFieldValid) {
            var postData = {
                'pwd': $scope.NEWPASSWORD,
                'confirmPwd': $scope.CONFIRMATION,
                'userName': $scope.userName,
                'aboutToExpiredMsg': $scope.aboutToExpireMsg
            };

            SiteminderService.validatePwd(postData).then(function(responseData) {
                $scope.PWChange.submitted = true;

                if (undefined !== responseData.data.errorMap && Object.keys(responseData.data.errorMap).length > 0) {
                    $scope.smErrorMessageModel = "";
                    $scope.showFormError = true;
                    var errorMap = responseData.data.errorMap;
                    $scope.newPwdServerErrorMsg = undefined !== errorMap.pwd ? errorMap.pwd : "";
                    $rootScope.$emit('serverError', {msg: $scope.newPwdServerErrorMsg});	//emitting server side error
                    $scope.confirmPwdErrorMsg = undefined !== errorMap.confirmPwd ? errorMap.confirmPwd : "";
                    $rootScope.fireErrorTracker = true;

                    $timeout(function() {
                        trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    }, 300);

                } else if ($scope.smauthreason === "18" || $scope.smauthreason === "20") {
                    document.PWChange.submit();
                }
            });

        } else {
            $scope.PWChange.submitted = true;
            $rootScope.fireErrorTracker = true;
            $scope.showFormError = true;
            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);
        }
    };

    $scope.notNowSubmit = function() {
        $scope.PASSWORD = "";
        $scope.NEWPASSWORD = "";
        $scope.CONFIRMATION = "";

        if ($scope.smauthreason === "18") {
            document.getElementById('smauthreasonid').value = 23;
            document.PWChange.submit();
        }
    };

    $scope.goToSignIn = function() {
        var uri = "/tb/app/index.html";

        if ($scope.targetUrl.indexOf('homew.jsf') > -1) {
            uri = "/tb/views/loginw.jsf";
        }

        $window.location.href = uri;
    };

    $scope.lockedSubmit = function() {
        var uri = "/tb/app/index.html";

        if ($scope.targetUrl.indexOf('homew.jsf') > -1) {
            uri = "/tb/views/loginw.jsf";
        }

        if ($scope.smauthreason === "24" || $scope.smauthreason === "25") {
            uri = uri + '?reason=l';
        } else if ($scope.smauthreason === "7") {
            uri = uri + '?reason=al';
        }

        $window.location.href = uri;
    };

    $scope.optumIDhelp = function() {
        $window.open('/tb/help/hparent.html');
    };
}
