package com.optum.trustbroker.controller.vo;

import java.io.Serializable;
import java.util.List;

public class StatesVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private List<LabelValueVO> labelValueVOList;
	
	public List<LabelValueVO> getLabelValueVOList() {
		return labelValueVOList;
	}
	public void setLabelValueVOList(List<LabelValueVO> labelValueVOList) {
		this.labelValueVOList = labelValueVOList;
	}

}