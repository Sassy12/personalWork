/*
 * Copyright (C) 2016 Optum ID
 *
 * All rights reserved.
 */
package com.optum.trustbroker.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;

import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.LabelValueVO;
import com.optum.trustbroker.controller.vo.ManageProfileVO;
import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.exceptions.ExceptionUtility;
import com.optum.trustbroker.service.ConfigurationService;
import com.optum.trustbroker.service.RelyingPartyAppService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.WebApplicationCommonUtilities;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.RelyingPartyTierInfoVO;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.VerificationCodeRequest;
import com.uhg.iam.alps.authentication.sm.HttpLoginRequest;
import com.uhg.iam.alps.authentication.sm.LoginRequest;
import com.uhg.iam.alps.authentication.sm.LoginResponse;
import com.uhg.iam.alps.authentication.sm.core.RedirectingLoginServiceWrapper;
import com.uhg.iam.alps.common.http.HttpUtils;

public class BaseController {

    @Autowired
    protected UserService userService;

    @Autowired
    protected RelyingPartyAppService relyingPartyAppService;

    @Autowired
    protected WebApplicationCommonUtilities webApplicationCommonUtilities;

    @Autowired
    protected RedirectingLoginServiceWrapper optumidSMDlwsBasedLoginService;

    @Autowired
    protected ConfigurationService configService;

    @Autowired
    @Qualifier("tb_service_errorMessageResource")
    protected MessageSource errorMessageSource;

    @Autowired
    protected Properties configProps;

    protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");

    protected static final ResourceBundle verifyCodes = ResourceBundle.getBundle("verifyCodesResources");

    private static final BaseLogger LOGGER = new BaseLogger(BaseController.class);

    protected VerificationCodeRequest getVerificationCodeRequest(CommunicationChannel channel, UserVO userVO,
            HttpServletRequest request, RpAppVO rpAppVO) {
        VerificationCodeRequest req = new VerificationCodeRequest();
        req.setChannel(channel);
        req.setUser(userVO);
        req.setUrlLogoOptumId(getUrlLogoOptumId(request));
        req.setUrlLogoRelyingParty(getUrlLogoRelyingParty(request, rpAppVO.getAppId()));
        req.setRemoteAddress(request.getRemoteAddr());
        req.setLocalAddress(request.getLocalAddr());
        req.setSessionId(request.getSession().getId());
        if (rpAppVO != null) {
            req.setRpAppId(rpAppVO.getAppId());
            req.setUrlRelyingApp(rpAppVO.getTargetURL());
        }
        //TO-DO add invitation code for this 
        req.setUrlVerification(constructURL(tbResources.getString(TrustBrokerConstants.VERIFICATION_URL_NEXT_GEN), request));
        return req;
    }

    public RelyingPartyAppVO getRelyingPartyApp(String rpAppId) {

        if (rpAppId != null) {
            return relyingPartyAppService.fetchRelyingPartyAppByAppId(rpAppId);
        }
        return null;
    }

    public String getUrlLogoRelyingParty(HttpServletRequest req) {
        RelyingPartyAppVO rpApp = getRPContext();
        if (rpApp != null && rpApp.getUploadedImageVO() != null && rpApp.getUploadedImageVO().getBytes() != null) {
            return constructURL("/dispimage?appID=" + rpApp.getApplicationId(), req);
        }
        return null;
    }

    // TODO replace usages with getUrlLogoRelyingParty(HttpServletRequest req)
    public String getUrlLogoRelyingParty(HttpServletRequest req, String rpAppId) {
        RelyingPartyAppVO rpApp = getRelyingPartyApp(rpAppId);
        if (rpApp != null && rpApp.getUploadedImageVO() != null && rpApp.getUploadedImageVO().getBytes() != null) {
            return constructURL("/dispimage?appID=" + rpApp.getApplicationId(), req);
        }
        return null;
    }

    public String getUrlLogoOptumId(HttpServletRequest req) {
        return constructURL("/images/lockup-product-name-lg.png", req);
    }

    // TODO
    protected String getUrlLogin(HttpServletRequest req) {
        return constructURL("/views/login.jsf", req);
    }

    public String constructURL(String view, HttpServletRequest request) {

        try {
            URL url = new URL(request.getRequestURL().toString());
            int port = url.getPort();
            LOGGER.debug("hsreq scheme: " + request.getScheme());
            LOGGER.debug("hsreq server port: " + request.getServerPort());
            LOGGER.debug("url: " + request.getRequestURL());
            LOGGER.debug("url protocol: " + url.getProtocol());
            LOGGER.debug("url port: " + port);
            String returnURL = "";
            if (port == -1) {
                returnURL = url.getProtocol() + "://" + url.getHost() + request.getContextPath() + view;
            } else {
                returnURL = url.getProtocol() + "://" + url.getHost() + ":" + port + request.getContextPath() + view;
            }
            return returnURL;
        } catch (MalformedURLException ex) {
            throw new OperationFailedException("Exception while constructing url", ex);
        }
    }

    public String extractErrorMessageFromOFE(OperationFailedException ofe, String rpAppID) {
        return ExceptionUtility.extractErrorMessageFromOFE(ofe, errorMessageSource, relyingPartyAppService, rpAppID);
    }

    protected boolean isActiveSMSessionForUser(String userName, HttpServletRequest request) {

        Cookie cookies[] = request.getCookies();
        String smsession = "";

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (TrustBrokerWebAppConstants.SM_SESSION.equals(cookie.getName())) {
                    smsession = cookie.getValue();
                    break;
                }
            }
        }

        LOGGER.debug("Inside isActiveSession, cookie {} and userid {}",
                new String[] {String.valueOf(StringUtils.isNotBlank(smsession)), userName});
        return (StringUtils.isNotBlank(smsession) && !"LOGGEDOFF".equals(smsession)) ? true : false;
    }

    protected boolean redirectToAnotherView(HttpServletResponse response, String viewUrl) {
        try {
            response.sendRedirect(viewUrl);
            return true;
        } catch (IOException ioEx) {
            LOGGER.error("Error while redirectingt internally", ioEx);
        }
        return false;
    }

    protected String constructURLWithRPParams(String targetURL) {

        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        if (isSessionContainsRelyingPartyInfo()) {
            targetURL = HttpUtils.addParameterToURL(targetURL, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM,
                    ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM));
            String target = ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET) != null
                    ? ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET)
                    : ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);
            targetURL = HttpUtils.addParameterToURL(targetURL, TrustBrokerWebAppConstants.TARGET, target);
        }

        if (ctx.getSessionAttribute(TrustBrokerConstants.INVITATION_CODE) != null) {
            targetURL = HttpUtils.addParameterToURL(targetURL, TrustBrokerWebAppConstants.INVITATION_CODE,
                    ctx.getSessionAttribute(TrustBrokerConstants.INVITATION_CODE));
        }
        return targetURL;
    }

    private boolean isSessionContainsRelyingPartyInfo() {

        WebApplicationContext ctx = WebApplicationContextHolder.getContext();

        return StringUtils.isNotEmpty(ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM))
                && StringUtils.isNotEmpty(ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET));

    }

    protected String getNextGenHomePageURIWithAlias(String alias) {

        String homePageURI = "/secure/home.html";
        String rpAliasValue;
        if (StringUtils.isEmpty(alias)) {
            rpAliasValue = TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE;
        } else {
            rpAliasValue = alias;
        }

        homePageURI = HttpUtils.addParameterToURL(homePageURI, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM,
                rpAliasValue);
        return homePageURI;
    }

    protected UserVO getCurrentUser() {
        UserVO userVO = webApplicationCommonUtilities.getCurrentUserDetailsFromWebApplicationContext();
        return userVO;
    }

    protected String getErrorMsg(Exception ex) {
        String errorMsg;
        if (ex instanceof OperationFailedException) {
            errorMsg = ((OperationFailedException) ex).getErrorMessage().getCode();
        } else {
            errorMsg = ex.getMessage();
        }
        return errorMsg;
    }

    protected String getContextAttribute(String attrName) {
        WebApplicationContext context = WebApplicationContextHolder.getContext();
        return context.getRequestAttribute(attrName);
    }

    protected String getSessionAttribute(String attrName) {
        WebApplicationContext context = WebApplicationContextHolder.getContext();
        return context.getSessionAttribute(attrName);
    }

    protected ResourceBundle getBundle() {
        ResourceBundle bundle = null;
        String userLocale = getContextAttribute(TrustBrokerWebAppConstants.USER_LOCALE);
        if (userLocale != null) {
            Locale locale = new Locale(userLocale);
            bundle = ResourceBundle.getBundle(TrustBrokerWebAppConstants.TB_BUNDLE_NAME, locale);
        } else {
            bundle = ResourceBundle.getBundle(TrustBrokerWebAppConstants.TB_BUNDLE_NAME);
        }

        return bundle;
    }

    protected String getMessage(String messageKey) {
        return getBundle().getString(messageKey);
    }

    /**
     * This method is to get the message from resource properties
     * and formats it with support info before returning it.
     * 
     * @param msgKey
     *            String
     * @return String
     */
    protected String getFormattedMessage(String msgKey) {
        String message = getMessage(msgKey);
        String formattedMsg = TBUtil.formatMessage(message, new String[] {
                webApplicationCommonUtilities.getApplicationSupportContactInformation(true).getContactComboText()});
        return formattedMsg;
    }

    protected void createUserSMSession(HttpServletRequest req, HttpServletResponse res, String userName, String alias) {

        LoginRequest loginRequest = new HttpLoginRequest(userName, null, req, res);
        loginRequest.setProtectedUrl(getNextGenHomePageURIWithAlias(alias));
        LoginResponse loginResponse = optumidSMDlwsBasedLoginService.login(loginRequest);
        LOGGER.debug(String.format(
                "User Authentication status at siteminder during registration [UserName, isAuthenticated] : {%s, %s}",
                userName, loginResponse.isAuthenticated()));
    }

    protected RelyingPartyAppVO getRPContext() {
        return webApplicationCommonUtilities.getRelyingPartyApplicationDetailsFromContext();
    }

    protected RelyingPartyTierInfoVO getRPTierInfo(String tierId) {
        return configService.getTierInfoforRP(tierId);
    }

    protected void processRelyingPartyInfo(ManageProfileVO manageProfileVO, String targetURL) {
        RelyingPartyAppVO relyingPartyAppVO = getRPContext();

        if (relyingPartyAppVO != null) {

            RpAppVO rpContext = new RpAppVO();
            RelyingPartyTierInfoVO rpTierInfo = getRPTierInfo(relyingPartyAppVO.getAlias());
            if (rpTierInfo.isDobRequired()) {
                rpContext.setShowDob(true);
            }

            rpContext.setAlias(relyingPartyAppVO.getAlias());
            rpContext.setAppId(relyingPartyAppVO.getApplicationId());
            rpContext.setTargetURL(targetURL);
            rpContext.setApplicationName(relyingPartyAppVO.getApplicationName());

            LOGGER.debug(" COPPA indicator for RP App ", relyingPartyAppVO.getCoppaReqdInd());
            if (TrustBrokerWebAppConstants.COPPA_REQUIRED_VALUE.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
                rpContext.setCoppaValidationReqd(true);
            }
            manageProfileVO.setRpContext(rpContext);
        }
    }

    protected List<LabelValueVO> createSecQuestionsModel(List<UserChallengeQuestionVO> usrChalQuesVOList) {
        List<LabelValueVO> queslist = new ArrayList<LabelValueVO>();
        for (UserChallengeQuestionVO usrChalQuesVO : usrChalQuesVOList) {
            LabelValueVO slctVo = new LabelValueVO();
            slctVo.setValue(usrChalQuesVO.getQuestionId() + "_" + usrChalQuesVO.getQuestion());
            slctVo.setLabel(usrChalQuesVO.getQuestion());
            queslist.add(slctVo);
        }
        return queslist;
    }

    protected void buildSuccess(ResponseVO respVo, HttpServletResponse httpServletResponse) {
        respVo.setStatus(Status.OK.toString());
        httpServletResponse.setStatus(HttpServletResponse.SC_OK);
    }

    protected void buildBadRequest(String responseCode, ResponseVO respVo) {
        respVo.setStatus(Status.BAD_REQUEST.toString());
        respVo.setResponseCode(responseCode);
    }

    protected void buildInternalServerError(String responseCode, ResponseVO respVo) {
        respVo.setStatus(Status.INTERNAL_SERVER_ERROR.toString());
        respVo.setResponseCode(responseCode);
    }

    protected void buildForbidden(String responseCode, ResponseVO respVo) {
        respVo.setStatus(Status.FORBIDDEN.toString());
        respVo.setResponseCode(responseCode);
    }

    protected void cleanEvents(WebApplicationContext ctx) {
        /* Removing events from previous login.
        *  Need to remove them from context before accessing in HomeController in login and
        *  registration entry points. This is done to reset the events state stored in session cookies
        *  to provide fresh context when the user just logs out without closing the browser.
        * */
        ctx.removeSessionAttribute(TrustBrokerWebAppConstants.USER_SIGNIN_EVENT);
        ctx.removeSessionAttribute(TrustBrokerWebAppConstants.SKIP_RECOVERY_EVENT);
    }

    /**
     * This method will clear current work flow ID and attributes associated
     * with that workflow ID
     */
    protected void clearWorkFlowAndAttributes(){
        WebApplicationContextHolder.getContext().removeCurrentWorkflowAndAttributes();
    }

    protected void removeWorkFlowAttribute(String attributeName){
        WebApplicationContext context = WebApplicationContextHolder.getContext();
        context.removeWorkflowAttribute(context.getcurrentWorkflowId(),attributeName);
    }

    protected void addSkipRecoveryOptionsEvent() {
        // add skip event to suppress verify recovery options prompt in the session
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        ctx.setSessionAttribute(TrustBrokerWebAppConstants.SKIP_RECOVERY_EVENT, "true");
    }

    protected String getAppId() {
        String appId = tbResources.getString("TB_APP_ID");
        if (getRPContext() != null)
            appId = getRPContext().getApplicationId();

        return appId;
    }

    protected void sendProfileUpdateNotification(HttpServletRequest request, String relyingAppId,
                                                 UserVO userVO, UserVO eSSOUserVO, boolean pwdFlow) {
        List<String> modifiedUserAttrLst = null;
        if (pwdFlow) {
            modifiedUserAttrLst = new ArrayList<>();
            modifiedUserAttrLst.add("MODIFY_PWD");
        } else {
            modifiedUserAttrLst = userService.getModifiedAttributes(userVO, eSSOUserVO);
        }

        String emailToNotify = null;
        if (modifiedUserAttrLst.contains("MODIFY_EMAILS")) {
            // if primary email has changed, send to previous verified email
            emailToNotify = eSSOUserVO.getEmailAddress();
        } else {
            // otherwise, send to current verified email
            emailToNotify = userVO.getEmailAddress();
        }

        userService.sendUserEmailUpdInfo(emailToNotify, userVO, relyingAppId,
                getUrlLogoOptumId(request), getUrlLogoRelyingParty(request, relyingAppId),
                modifiedUserAttrLst.toArray(new String[0]));
    }

    /**
     * This method returns the userService.
     * 
     * @return the userService.
     */
    public UserService getUserService() {
        return userService;
    }

    /**
     * This method sets the given userService value to userService.
     * 
     * @param userService
     *            the userService to set.
     */
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    /**
     * This method returns the webApplicationCommonUtilities.
     *
     * @return the webApplicationCommonUtilities
     */
    public WebApplicationCommonUtilities getWebApplicationCommonUtilities() {
        return webApplicationCommonUtilities;
    }

    /**
     * This method sets the given webApplicationCommonUtilities value to webApplicationCommonUtilities.
     *
     * @param webApplicationCommonUtilities the webApplicationCommonUtilities to set
     */
    public void setWebApplicationCommonUtilities(WebApplicationCommonUtilities webApplicationCommonUtilities) {
        this.webApplicationCommonUtilities = webApplicationCommonUtilities;
    }

    public RedirectingLoginServiceWrapper getOptumidSMDlwsBasedLoginService() {
        return optumidSMDlwsBasedLoginService;
    }

    public void setOptumidSMDlwsBasedLoginService(RedirectingLoginServiceWrapper optumidSMDlwsBasedLoginService) {
        this.optumidSMDlwsBasedLoginService = optumidSMDlwsBasedLoginService;
    }

    public ConfigurationService getConfigService() {
        return configService;
    }

    public void setConfigService(ConfigurationService configService) {
        this.configService = configService;
    }

    public Properties getConfigProps() {
        return configProps;
    }

    public void setConfigProps(Properties configProps) {
        this.configProps = configProps;
    }

    public MessageSource getErrorMessageSource() {
        return errorMessageSource;
    }

    public void setErrorMessageSource(MessageSource errorMessageSource) {
        this.errorMessageSource = errorMessageSource;
    }

    /**
     * This method returns the relyingPartyAppService.
     *
     * @return the relyingPartyAppService
     */
    public RelyingPartyAppService getRelyingPartyAppService() {
        return relyingPartyAppService;
    }

    /**
     * This method sets the given relyingPartyAppService value to relyingPartyAppService.
     *
     * @param relyingPartyAppService the relyingPartyAppService to set
     */
    public void setRelyingPartyAppService(RelyingPartyAppService relyingPartyAppService) {
        this.relyingPartyAppService = relyingPartyAppService;
    }

}
