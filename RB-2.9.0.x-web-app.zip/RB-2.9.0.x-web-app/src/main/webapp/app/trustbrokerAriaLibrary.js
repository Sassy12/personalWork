/**
 * A reusable module for all WCAG 2.0 related requirements for the TrustBroker Project
 * 
 */
'use strict';
angular.module('trustbroker.AriaLibrary', [])
.service('trustbrokerAriaService',TrustbrokerAriaService);

function TrustbrokerAriaService() {

	/**
	 * This method sets focus to the first field in error in the form, adds described by the input field and puts aria-invalid true
	 */
	this.setAriaAttributesPostFormSubmit = function(FIELDS) {
		var elem, i;
		for (i = FIELDS.length - 1; i >= 0; i--) {
			if (document.getElementById(FIELDS[i].msg) !== null &&
				document.getElementById(FIELDS[i].msg).innerHTML !== "") {
				elem = angular.element(document.getElementById(FIELDS[i].fld));
				elem.focus();
				elem.attr("aria-invalid", "true");
				this.appendDescribedByAttribute(FIELDS[i].fld, FIELDS[i].msg);
			}
		}
	};
	/**
	 * Used onBlur on an input feild to add and remove describedBy element
	 */
	this.setFieldValidity = function(inputid, spanid) {
		var span = document.getElementById(spanid);
		if (span === null) {
			this.removeDescribedByAttribute(inputid, spanid);
		} else {
			if (span.innerHTML.length > 1) {
				this.appendDescribedByAttribute(inputid, spanid);
			} else {
				this.removeDescribedByAttribute(inputid, spanid);
			}
		}

	};
	/**
	 * Used on change on a checkBox to change aria invalid
	 */
	this.setAriaInvalid = function(inputid, spanid) {
		var span = document.getElementById(spanid);
		var elem = angular.element(document.getElementById(inputid));
		if (span === null) {
			elem.attr("aria-invalid", "false");
		} else {
			if (span.innerHTML.length > 1) {
				elem.attr("aria-invalid", "true");
			} else {
				elem.attr("aria-invalid", "false");
			}
		}

	};
	
	
	
	this.removeDescribedByAttribute = function (attrId, attrIdValue) {
		var attrVal = angular.element(document.getElementById(attrId)).attr(
				"aria-describedby");

		if (attrVal !== undefined && attrVal !== null) {
			angular.element(document.getElementById(attrId)).attr(
					"aria-invalid", "false");
			attrVal = attrVal.replace(attrIdValue, "").trim();
			if (attrVal.length === 0) {
				angular.element(document.getElementById(attrId)).removeAttr(
						"aria-describedby");
			} else {
				angular.element(document.getElementById(attrId)).attr(
						"aria-describedby", attrVal);
			}
		}
	};

	this.appendDescribedByAttribute = function(attrId, descrById) {
		var attrVal = angular.element(document.getElementById(attrId)).attr(
				"aria-describedby");
		if (attrVal === undefined) {
			attrVal = descrById;
		} else if (attrVal.indexOf(descrById) === -1) {
			attrVal = descrById + " " + attrVal;
		}
		angular.element(document.getElementById(attrId)).attr(
				"aria-invalid", "true");
		angular.element(document.getElementById(attrId)).attr(
				"aria-describedby", attrVal);
	};
}