package com.optum.trustbroker.helpers;

import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.LabelValueVO;
import com.optum.trustbroker.controller.vo.ManageProfileVO;
import com.optum.trustbroker.controller.vo.ProfileVO;
import com.optum.trustbroker.controller.vo.SecurityQuestionVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.controller.vo.ValidationData;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.ValidationUtils;
import com.optum.trustbroker.vo.AddressVO;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.RelyingPartyTierInfoVO;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserVO;

@Component
public class UserHelper {

    public static final String FLD_NAME_EMAIL = "email";

    public static final String PRIMARY_EMAIL = "primaryEmail";

    public static final String SECONDARY_EMAIL = "secondaryEmail";

    public static final String MOBILE = "mobileNo";

    @Autowired
    private ValidationUtils validationUtils;

    protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");

    public void updateUserFlags(UserVO trustBrokerUserVO, UserVO updateUserVO) {

        updateUserVO.setUserId(trustBrokerUserVO.getUserId());
        updateUserVO.setUuId(trustBrokerUserVO.getUuId());
        updateUserVO.setUserRoleCd(trustBrokerUserVO.getUserRoleCd());

        updateUserVO.setIsTncAccepted(trustBrokerUserVO.getIsTncAccepted());
        updateUserVO.setTncAgreementVersion(trustBrokerUserVO.getTncAgreementVersion());
        updateUserVO.setTncAgreedTs(trustBrokerUserVO.getTncAgreedTs());
        updateUserVO.setIdentityProofingId(trustBrokerUserVO.getIdentityProofingId());
        updateUserVO.setIsPriPolyAccepted(trustBrokerUserVO.getIsPriPolyAccepted());
        updateUserVO.setPrivPolyAgreementVersion(trustBrokerUserVO.getPrivPolyAgreementVersion());
        updateUserVO.setPriPolyyAgreedTs(trustBrokerUserVO.getPriPolyyAgreedTs());
        updateUserVO.setIsCoppaAccepted(trustBrokerUserVO.getIsCoppaAccepted());
    }

    public void populateUserFromProfile(ProfileVO profileVO, UserVO userVO) {

        userVO.setFirstName(profileVO.getFirstName());
        userVO.setMiddleName(profileVO.getMiddleName());
        userVO.setLastName(profileVO.getLastName());
        userVO.setPrefix(profileVO.getPrefix());
        userVO.setSuffix(profileVO.getSuffix());
        userVO.setDobStr(profileVO.getDateOfBirth());

        /* UUID & UserName are required for modify request */
        userVO.setUuId(profileVO.getUuid());
        userVO.setUserName(profileVO.getUserName());

        List<AddressVO> addresses = new ArrayList<AddressVO>();
        AddressVO addressVO = new AddressVO();

        /* Ensure address type and default address flag are populated always */
        addressVO.setDefaultAddress(true);
        addressVO.setAddressType(TrustBrokerConstants.ADDRESS_TYPE_WORK);

        /* For address change, all address fields should be populated */
        if (StringUtils.isNotBlank(profileVO.getHomeAddress()) && StringUtils.isNotBlank(profileVO.getZip())
                && StringUtils.isNotBlank(profileVO.getCity()) && StringUtils.isNotBlank(profileVO.getState())) {
            addressVO.setStreetAddress(profileVO.getHomeAddress());
            addressVO.setZip(profileVO.getZip());
            addressVO.setCity(profileVO.getCity());
            addressVO.setState(profileVO.getState());
            addressVO.setDefaultAddress(true);
            addressVO.setAddressType(TrustBrokerConstants.ADDRESS_TYPE_WORK);
        }

        /* If all fields are not populated, user is removing existing address, so send blank object to service
         * with out above 4 field values. */

        addresses.add(addressVO);
        userVO.setAddresses(addresses);
    }

    public void populateProfileFromUser(UserVO userVO, ProfileVO profileVO) {

        profileVO.setFirstName(userVO.getFirstName());
        profileVO.setMiddleName(userVO.getMiddleName());
        profileVO.setLastName(userVO.getLastName());
        profileVO.setPrefix(userVO.getPrefix());
        profileVO.setSuffix(userVO.getSuffix());

        List<AddressVO> addresses = userVO.getAddresses();
        if (addresses != null & !addresses.isEmpty()) {
            for (AddressVO address : addresses) {
                if (address.isDefaultAddress()
                        || TrustBrokerConstants.ADDRESS_TYPE_WORK.equalsIgnoreCase(address.getAddressType())) {
                    profileVO.setHomeAddress(address.getStreetAddress());
                    profileVO.setCity(address.getCity());
                    profileVO.setState(address.getState());
                    profileVO.setZip(address.getZip());
                }
            }
        }
        if (userVO.getDob() != null) {
            profileVO.setDateOfBirth(DateUtil.formatDate(userVO.getDob(), DateUtil.EXT_DATE_FORMAT2));
        }
        profileVO.setUuid(userVO.getUuId());
        profileVO.setUserName(userVO.getUserName());
    }

    public static UserVO buildUserInfo(UserInfoVO userInfoVO) {
        UserVO userVO = new UserVO();
        userVO.setFirstName(userInfoVO.getFirstName());
        userVO.setLastName(userInfoVO.getLastName());
        if (StringUtils.isNotEmpty(userInfoVO.getDateOfBirth()))
            userVO.setDob(DateUtil.parseDateMultipleFormats(userInfoVO.getDateOfBirth()));
        userVO.setEmailAddress(userInfoVO.getEmailAddress());
        userVO.setUserName(userInfoVO.getUserName());
        userVO.setPassword(userInfoVO.getPwd());
        userVO.setIsTncAccepted(tbResources.getString("isTncAccepted"));
        userVO.setTncAgreementVersion(tbResources.getString("tncAgreementVersion"));
        userVO.setIsPriPolyAccepted(tbResources.getString("isPriPolyAccpeted"));
        userVO.setIsCoppaAccepted("Y");
        if (null != userInfoVO.getRpAppVO().getAppId() && !userInfoVO.getRpAppVO().isCoppaValidationReqd())
            userVO.setIsCoppaAccepted("N");
        userVO.setPrivPolyAgreementVersion(tbResources.getString("privPolyAgreementVersion"));

        if (null != userInfoVO.getRpAppVO().getTierId())
            userVO.setTierId(userInfoVO.getRpAppVO().getTierId());

        if (StringUtils.isNotEmpty(userInfoVO.getSecurityQuestionVO().getQuestionOne())
                && StringUtils.isNotEmpty(userInfoVO.getSecurityQuestionVO().getQuestionTwo())
                && StringUtils.isNotEmpty(userInfoVO.getSecurityQuestionVO().getQuestionThree())) {
            if (userInfoVO.getRpAppVO().isShowQuestions() || userInfoVO.isShowSecQuestionBasedonSharedEmail()) {
                populateSecurityQuestions(userVO, userInfoVO.getSecurityQuestionVO());
            }

        }
        return userVO;
    }

    /**
     * Populates list of security questions and corresponding answers to {@link UserVO}
     * 
     * @param userVO {@link UserVO}
     * @param quesVO {@link SecurityQuestionVO}
     */
    public static void populateSecurityQuestions(UserVO userVO, SecurityQuestionVO quesVO) {
        List<UserChallengeQuestionVO> securityQuestions = new ArrayList<UserChallengeQuestionVO>();

        splitSecurityQuestions(quesVO.getQuestionOne(), quesVO.getAnsOne(), securityQuestions);
        splitSecurityQuestions(quesVO.getQuestionTwo(), quesVO.getAnsTwo(), securityQuestions);
        splitSecurityQuestions(quesVO.getQuestionThree(), quesVO.getAnsThree(), securityQuestions);

        userVO.setUserChallengeQuestions(securityQuestions);
    }

    private static void splitSecurityQuestions(String question, String answer,
            List<UserChallengeQuestionVO> securityQuestions) {
        UserChallengeQuestionVO question1 = new UserChallengeQuestionVO();
        String secQuestion1Array[] = question.split("_");
        if (secQuestion1Array != null) {
            if (secQuestion1Array.length > 0) {
                question1.setQuestionId(secQuestion1Array[0]);
            }
            if (secQuestion1Array.length > 1) {
                question1.setQuestion(secQuestion1Array[1]);
            }
        }
        question1.setAnswer(answer);
        securityQuestions.add(question1);
    }

    public void populateRecoveryOptions(UserVO userVO, ProfileVO profileVO) {
        profileVO.setPrimaryEmailAddress(userVO.getEmailAddress());
        /* Email should be verified by the time user comes to profile page but 
         * capturing verification status again*/
        profileVO.setPrimaryEmailVerified(userVO.isIsemailVerified());
        profileVO.setSecondaryEmailAddress(userVO.getSecEmailAddress());
        profileVO.setSecondaryEmailVerified(userVO.isSecEmailVerified());
        if (userVO.getPhoneNumber() != null && userVO.getPhoneNumber().length() == 13) {
            /* changing phone number from ESSO format (555)555-5555 to UI format 555-555-5555 */
            String phoneNo = userVO.getPhoneNumber();
            phoneNo = phoneNo.substring(1);
            phoneNo = StringUtils.replaceOnce(phoneNo, ")", "-");
            profileVO.setPhoneNo(phoneNo);
        }
        profileVO.setPhoneNoVerified(userVO.getIsPhoneVerified());
    }

    public void populateRecoveryOptionsFromView(UserVO userVO, ManageProfileVO manageProfileVO) {

        ProfileVO profileVO = manageProfileVO.getProfile();
        userVO.setEmailAddress(profileVO.getPrimaryEmailAddress());
        userVO.setSecEmailAddress(profileVO.getSecondaryEmailAddress());
        /* changing phone number from UI format 555-555-5555 to ESSO format (555)555-5555 */
        if (StringUtils.isNotBlank(profileVO.getPhoneNo())) {
            String phoneNo = profileVO.getPhoneNo();
            phoneNo = StringUtils.replaceOnce(phoneNo, "-", ")");
            StringBuilder builder = new StringBuilder(13);
            builder.append("(").append(phoneNo);
            userVO.setPhoneNumber(builder.toString());
        } else {
            userVO.setPhoneNumber("");
        }

        List<UserChallengeQuestionVO> oldQuestionsList = userVO.getUserChallengeQuestions();
        SecurityQuestionVO securityQuestionVO = manageProfileVO.getSecurityContext();

        boolean questionsUpdated = isSecurityInfoUpdated(oldQuestionsList, securityQuestionVO);

        if (questionsUpdated) {
            List<UserChallengeQuestionVO> securityQuestions = new ArrayList<UserChallengeQuestionVO>();

            UserChallengeQuestionVO question1 = new UserChallengeQuestionVO();
            question1.setQuestionId(securityQuestionVO.getId1());
            question1.setAnswer(securityQuestionVO.getAnsOne());

            UserChallengeQuestionVO question2 = new UserChallengeQuestionVO();
            question2.setQuestionId(securityQuestionVO.getId2());
            question2.setAnswer(securityQuestionVO.getAnsTwo());

            UserChallengeQuestionVO question3 = new UserChallengeQuestionVO();
            question3.setQuestionId(securityQuestionVO.getId3());
            question3.setAnswer(securityQuestionVO.getAnsThree());

            securityQuestions.add(question1);
            securityQuestions.add(question2);
            securityQuestions.add(question3);

            userVO.setUserChallengeQuestions(securityQuestions);
        } else {
            /* If security info is not updated, set challenge questions list to null to prevent
            *  from adding it to Modified attributes list in service layer */
            userVO.setUserChallengeQuestions(null);
        }

    }

    public boolean isSecurityInfoUpdated(List<UserChallengeQuestionVO> oldQuestionsList,
            SecurityQuestionVO securityQuestionVO) {

        boolean questionsUpdated = false;
        /* no security questions initially but added from UI */
        if ((oldQuestionsList == null || oldQuestionsList.isEmpty()) && securityQuestionVO.getId1() != null) {
            questionsUpdated = true;
        } else {
            /* security questions exist but modified from UI */
            UserChallengeQuestionVO firstQuestion = oldQuestionsList.get(0);
            UserChallengeQuestionVO secondQuestion = oldQuestionsList.get(1);
            UserChallengeQuestionVO thirdQuestion = oldQuestionsList.get(2);

            boolean firstQuesChanged = isQuestionModified(securityQuestionVO.getId1(), securityQuestionVO.getAnsOne(),
                    firstQuestion.getQuestionId(), firstQuestion.getAnswer());

            boolean secondQuesChanged = isQuestionModified(securityQuestionVO.getId2(), securityQuestionVO.getAnsTwo(),
                    secondQuestion.getQuestionId(), secondQuestion.getAnswer());

            boolean thirdQuesChanged = isQuestionModified(securityQuestionVO.getId3(), securityQuestionVO.getAnsThree(),
                    thirdQuestion.getQuestionId(), thirdQuestion.getAnswer());

            if (firstQuesChanged || secondQuesChanged || thirdQuesChanged) {
                questionsUpdated = true;
            }
        }
        return questionsUpdated;
    }

    private boolean isQuestionModified(String questionId, String answer, String oldQuesId, String oldAns) {
        if (!oldQuesId.equals(questionId) || !oldAns.equals(answer)) {
            return true;
        } else {
            return false;
        }

    }

    public void populateSecurityQuestions(UserVO userVO, ChallengeQuestionServiceResponse challengeQuestionServiceResponse,
            SecurityQuestionVO securityQuestionVO) {

        List<UserChallengeQuestionVO> securityQuestions = challengeQuestionServiceResponse.getUserChallengeQuestions();
        if (securityQuestions != null) {
            List<LabelValueVO> questions = new ArrayList<LabelValueVO>();
            for (UserChallengeQuestionVO userChallengeQuestionVO : securityQuestions) {
                LabelValueVO labelValueVO = new LabelValueVO();
                labelValueVO.setValue(userChallengeQuestionVO.getQuestionId());
                labelValueVO.setLabel(userChallengeQuestionVO.getQuestion());
                questions.add(labelValueVO);
            }
            securityQuestionVO.setQuestions(questions);
        }

        List<UserChallengeQuestionVO> userSecurityQuestions = userVO.getUserChallengeQuestions();
        if (userSecurityQuestions != null && !userSecurityQuestions.isEmpty()) {
            UserChallengeQuestionVO firstQuestion = userSecurityQuestions.get(0);
            securityQuestionVO.setQuestionOne(firstQuestion.getQuestion());
            securityQuestionVO.setAnsOne(firstQuestion.getAnswer());
            securityQuestionVO.setId1(firstQuestion.getQuestionId());

            UserChallengeQuestionVO secondQuestion = userSecurityQuestions.get(1);
            securityQuestionVO.setQuestionTwo(secondQuestion.getQuestion());
            securityQuestionVO.setAnsTwo(secondQuestion.getAnswer());
            securityQuestionVO.setId2(secondQuestion.getQuestionId());

            UserChallengeQuestionVO thirdQuestion = userSecurityQuestions.get(2);
            securityQuestionVO.setQuestionThree(thirdQuestion.getQuestion());
            securityQuestionVO.setAnsThree(thirdQuestion.getAnswer());
            securityQuestionVO.setId3(thirdQuestion.getQuestionId());
        }
    }

    public List<String> checkIfVerificationNeeded(ManageProfileVO manageProfileVO, UserVO currentUserVO) {

        List<String> modifiedFields = new ArrayList<>();
        ProfileVO profile = manageProfileVO.getProfile();
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();

        if (!profile.getPrimaryEmailAddress().equalsIgnoreCase(currentUserVO.getEmailAddress())) {
            modifiedFields.add(PRIMARY_EMAIL);
            ctx.setWorkflowAttribute(WorkflowConstants.WORKFLOW_MANAGE_ID_VERIFY_OPTIONS, WorkflowConstants.WORKFLOW_ATTRIBUTE_EMAIL, PRIMARY_EMAIL);
        }
        if (StringUtils.isNotBlank(profile.getPhoneNo())) {
            String phoneNo = currentUserVO.getPhoneNumber();
            if (StringUtils.isNotBlank(phoneNo)) {
                phoneNo = phoneNo.substring(1);
                phoneNo = StringUtils.replaceOnce(phoneNo, ")", "-");
            }
            if (!StringUtils.equals(profile.getPhoneNo(), phoneNo)) {
                modifiedFields.add(MOBILE);
                ctx.setWorkflowAttribute(WorkflowConstants.WORKFLOW_MANAGE_ID_VERIFY_OPTIONS, WorkflowConstants.WORKFLOW_ATTRIBUTE_MOBILE_NUMBER, MOBILE);
            }
        }
        if (StringUtils.isNotBlank(profile.getSecondaryEmailAddress()) &&
                !StringUtils.equalsIgnoreCase(profile.getSecondaryEmailAddress(), currentUserVO.getSecEmailAddress())) {
            modifiedFields.add(SECONDARY_EMAIL);
            ctx.setWorkflowAttribute(WorkflowConstants.WORKFLOW_MANAGE_ID_VERIFY_OPTIONS, WorkflowConstants.WORKFLOW_ATTRIBUTE_SEC_EMAIL, SECONDARY_EMAIL);
        }

        return modifiedFields;
    }

    public static void updateUserVOWithSecurityQuestions(UserVO userVO, SecurityQuestionVO quesVO) {
        populateSecurityQuestions(userVO, quesVO);
    }

    /* This method validates Account Recovery/Verification Options form fields */
    public void validateFormFields(ManageProfileVO manageProfileVO, RelyingPartyTierInfoVO rpTierInfo, UserVO currentUser) {

        ProfileVO profileVO = manageProfileVO.getProfile();
        String primaryEmail = profileVO.getPrimaryEmailAddress().trim();
        String secondaryEmail = profileVO.getSecondaryEmailAddress() != null ? profileVO.getSecondaryEmailAddress().trim()
                : null;
        String mobileNo = profileVO.getPhoneNo();

        ValidationData validationData = ValidationData.builder().setEmail(primaryEmail).setPhoneNo(mobileNo);

        if (rpTierInfo == null || rpTierInfo.isEmailShared()) {
            validationData.allowSharedEmail(true);
        }

        if (rpTierInfo == null || rpTierInfo.isSecQuesRequied()) {
            validationData.requireSecQstns(true);
        }

        /* Email validations */
        boolean primaryValid = false, secondaryValid = false;

        if (StringUtils.equalsIgnoreCase(currentUser.getEmailAddress(), primaryEmail)) {
            primaryValid = true;
            boolean uniqueEmail = currentUser.isPrimaryEmailUnique();
            validationData.setSharedEmail(!uniqueEmail);
        } else {
            validationUtils.validateEmail(validationData);
            if (validationData.getErrorMap() != null) {
                manageProfileVO.getErrorMap().putAll(validationData.getErrorMap());
            } else {
                primaryValid = true;
            }
        }

        boolean secQstnsRequired = false;
        if (validationData.isRpRequiresSecQstns() || validationData.isEmailSharedByOthers()) {
            secQstnsRequired = true;
        }

        if (StringUtils.isNotBlank(secondaryEmail)) {

            if (StringUtils.equalsIgnoreCase(currentUser.getSecEmailAddress(), secondaryEmail)) {
                secondaryValid = true;
            } else {

                validationData.resetErrors();
                validationData.setEmail(secondaryEmail);
                validationUtils.validateEmail(secondaryEmail);

                if (validationData.getErrorMap() != null) {
                    String errorMsg = validationData.getErrorMap().get(FLD_NAME_EMAIL);
                    manageProfileVO.addErrorMessage("secondaryEmail", errorMsg);
                } else {
                    secondaryValid = true;
                }
            }
        }

        if (primaryValid && secondaryValid && primaryEmail.equals(secondaryEmail)) {
            manageProfileVO.addErrorMessage(FLD_NAME_EMAIL, "priAndSecEmailSame");
        }

        /* Mobile number validations */
        validationUtils.validateMobile(validationData);
        if (validationData.getErrorMap() != null) {
            manageProfileVO.getErrorMap().putAll(validationData.getErrorMap());
        }

        /* Security Questions validations */

        validationData.resetErrors();
        validationData.addSecurityQuestions(manageProfileVO.getSecurityContext());
        boolean allQstnsExist = validationUtils.validateSecurityQstns(validationData);

        /* User already created security questions and trying to remove them from UI */
        if (currentUser.getUserChallengeQuestions() != null && !allQstnsExist) {
            manageProfileVO.addErrorMessage("form", tbResources.getString("secQnAnsBlankMsg"));
        }

        if (secQstnsRequired || !allQstnsExist) {
            if (validationData.getErrorMap() != null) {
                manageProfileVO.getErrorMap().putAll(validationData.getErrorMap());
                return;
            }
        }

        validationUtils.validateSecurityInfo(validationData);
        if (validationData.getErrorMap() != null) {
            manageProfileVO.getErrorMap().putAll(validationData.getErrorMap());
        }

    }

    public ValidationUtils getValidationUtils() {
        return validationUtils;
    }

    public void setValidationUtils(ValidationUtils validationUtils) {
        this.validationUtils = validationUtils;
    }
}
