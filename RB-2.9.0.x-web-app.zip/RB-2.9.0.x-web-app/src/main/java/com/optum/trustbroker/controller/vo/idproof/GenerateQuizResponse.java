package com.optum.trustbroker.controller.vo.idproof;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.vo.IDProofingQuizAnswer;
import com.optum.trustbroker.vo.IDProofingQuizQuestion;
import com.optum.trustbroker.vo.IDProofingQuizServiceResponse;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class GenerateQuizResponse extends ResponseVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
	private String transactionId;
	private List<Question> questions;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public List<Question> getQuestions() {
		if (questions == null) {
			questions = new ArrayList<Question>();
		}
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	public void buildFrom(IDProofingQuizServiceResponse proofResp) {
		if (proofResp != null && proofResp.getIdProofingQuizVO() != null) {
			setId(proofResp.getIdProofingQuizVO().getQuizId());
			if (proofResp.getIdProofingQuizVO().getQuestions() != null) {
				for (IDProofingQuizQuestion idq : proofResp.getIdProofingQuizVO().getQuestions()) {
					if (idq != null) {
						Question q = new Question();
						q.setQuestionId(idq.getQuestionId());
						q.setAnswerId(idq.getAnswerId());
						q.setText(idq.getQuestionText());
						for (IDProofingQuizAnswer ida : idq.getAnswers()) {
							Answer a = new Answer();
							a.setId(ida.getAnswerId());
							a.setText(ida.getAnswerText());
							q.getAnswers().add(a);
						}
						getQuestions().add(q);
					}
				}
			}
		}
	}
}
