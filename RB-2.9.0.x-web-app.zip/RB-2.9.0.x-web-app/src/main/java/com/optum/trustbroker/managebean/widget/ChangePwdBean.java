/*******************************************************************************
 * Copyright (c) 2012 Optum - All Rights Reserved.
 ******************************************************************************/
package com.optum.trustbroker.managebean.widget;

import java.io.Serializable;
import java.util.HashMap;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserChangePasswordServiceRequest;
import com.optum.trustbroker.vo.UserChangePasswordServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@ManagedBean(name = "wChangePwdBean")
@RequestScoped
public class ChangePwdBean extends AbstractBackingBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String newPwd;
	private String confirmNewPwd;
	private String pwdChangeSuccessMsg="";
	private String pwdStrength;
	private boolean pwdSpcErrInd;
	private boolean pwdDoNotMatch;

	
	@ManagedProperty(value = "#{userVO}")
	private UserVO userVO;


	private final BaseLogger logger = new BaseLogger(this.getClass());

	private String errorMessage="";

	@PostConstruct
	public void init() {
		//Builds user session if not exists
		getCurrentUserDetails();	
		addRelyingPartyRequestParam(TrustBrokerWebAppConstants.TARGET, TrustBrokerWebAppConstants.RELYING_APP_URL_PROF,
				getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
		addRelyingPartyRequestParam(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, TrustBrokerWebAppConstants.RELYING_APP_ID,
				getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
		addRelyingPartyAlias(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)!=null? 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString():null);
		addSessionAttribute(TrustBrokerWebAppConstants.ACTION, TrustBrokerWebAppConstants.CHANGE_PSWD);
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getNewPwd() {
		return newPwd;
	}

	public void setNewPwd(String newPwd) {
		this.newPwd = newPwd.trim();
	}

	public String getConfirmNewPwd() {
		return confirmNewPwd;
	}

	public void setConfirmNewPwd(String confirmNewPwd) {
		this.confirmNewPwd = confirmNewPwd.trim();
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public String getPwdChangeSuccessMsg() {
		return pwdChangeSuccessMsg;
	}


	public void setPwdChangeSuccessMsg(String pwdChangeSuccessMsg) {
		this.pwdChangeSuccessMsg = pwdChangeSuccessMsg;
	}

	public String getPwdStrength() {
		return pwdStrength;
	}

	public void setPwdStrength(String pwdStrength) {
		this.pwdStrength = pwdStrength;
	}

	/**
	 * Request Handler[POST] for ChangePassword page.
	 *
	 * The form fields are validated and changePassword method is called.
	 *
	 *
	 * @return the string - Change Password success page URL
	 *         otherwise returns null [appropriate face error
	 *         message is set]
	 */

	public String doNavigation() {
		boolean result=false;
		if (!validateFormFields()) {
			//Validate form fields
			//clearMessages();
			setPwdChangeSuccessMsg("");
			getUserVO().setPassword("");
			setNewPwd("");
			setConfirmNewPwd("");
			return null;
		}
		
		try {
			result = changePwd(userVO.getPassword());
			if(result){
				errorMessage="";				
				clearMessages();
				setPwdChangeSuccessMsg("Your password has been changed successfully");
			}
		}
		catch (OperationFailedException e) {
			logger.error("Error while updating the password for user {}", new String[]{getCurrentUserVO().getUserName(), 
					TrustbrokerWebAppUtil.getUidFromError(e)}, e);
			clearMessages();
			errorMessage = e.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(), getSupportContactInfo());
			return null;
		}
		return null;
	}

	public void clearMessages() {
		setPwdChangeSuccessMsg("");
		setErrorMessage("");
		getUserVO().setPassword("");
		setNewPwd("");
		setConfirmNewPwd("");
	}

	/**
	 * Change user password.
	 * @param pwd the old password for user profile.
	 * 
	 * @return success or failure flag.
	 */
	private boolean changePwd(String pwd) {
		UserChangePasswordServiceRequest userChangePwdRequest = new UserChangePasswordServiceRequest();
		userChangePwdRequest.setOldPassword(pwd);
		userChangePwdRequest.setPassword(getNewPwd());
		userChangePwdRequest.setUser(getCurrentUserVO());

		UserChangePasswordServiceResponse userChangePwdResponse = container.getCredentialService().changePwd(userChangePwdRequest);
		
		if (TrustbrokerWebAppUtil.checkResponseStatus(userChangePwdResponse)) {
			addSessionAttribute(TrustBrokerWebAppConstants.PWD_CHANGE_MSG, getPwdChangeSuccessMsg());
			
			SecurityLoggingUtil.info("User Account Modifications",SecurityEventType.E3_MODIFY, getServletRequest(), 
					getCurrentUserVO().getUserName(), 
					"Security Audit Event|ModifyUserPassword:SUCCESS | User Account Password Modified, ChangePwdBean:changePwd()",
					SecurityEventResult.SUCCESS, getRelyingPartyAppId(), SecuritySubEventType.E3_MODIFY_PASSWORD);
			return true;
		} else {
			errorMessage = userChangePwdResponse.getReasonMessage();
			if(errorMessage != null && !"".equals(errorMessage) && errorMessage.equalsIgnoreCase("Old Password is wrong"))
				errorMessage = "Current password is wrong";
			
			logger.error("Pwd Change Request | Failed | Reason Code : {} | Reason Message : {} | User: {}", 
					new Object[]{userChangePwdResponse.getReasonCode(),userChangePwdResponse.getReasonMessage(),
					getCurrentUserVO().getUserName()});
			return false;
		}

	}


	/**
	 * Server side form fields validation.
	 *
	 * @return true - if the validation is success. returns false otherwise
	 */
	public boolean validateFormFields() {
		setPwdChangeSuccessMsg("");
		if (getNewPwd().contains(PWD_INVALID_SPL_CHAR)) {
			errorMessage =  
					tbResources.getString("pwdSplCharErrMasg");
			return false;
		}
		if(isPwdDoNotMatch()) {
			errorMessage = "New Password does not match the Confirm New Password";
			return false;
		} 
		if (!getNewPwd().equals(getConfirmNewPwd())) {
			logger.info("SetPwdBean::validateFormFields():: Pwds do not match");
			errorMessage = "New Password does not match the Confirm New Password";
			return false;
		}

		if (getUserVO().getPassword().equals(getNewPwd())) {
			logger.info("SetPwdBean::validateFormFields():: Current and new pwds cannot be the same");
			errorMessage = "Current and new passwords cannot be same";
			//context.addMessage(null, new FacesMessage("Old and new passwords cannot be same"));
			return false;
		}
		
		if(isPwdSpcErrInd()) {
			errorMessage = tbResources.getString("pwdCannotContainSpaces");
			return false;
		} 
		
		if(!checkPwdContent()) return false;
		
		if(!TBUtil.isPwdStrengthValid(getNewPwd())) {
			logger.info("SetPwdBean::validateFormFields():: Weak pwd can not be stored");
			errorMessage = "Good or Strong password is required";
			//getFacesContext().addMessage(null,new FacesMessage("Passwords Strength is weak"));
			return false;
		}


		return true;
	}
	/**
	 * Gets the faces context
	 *
	 * @return current FacesContext otherwise
	 */
	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	public String cancel()
	{		
		clearMessages();
		String returnUrl = "/securew/changepwdw.jsf?faces-redirect=true";
		return returnUrl;
	}
	
	public String getUserName() {
		String userName = null;
		UserVO user = getCurrentUserVO();
		if(user != null) {
			userName = user.getUserName();
		}
		return userName;		
	}
	
	public void setUserName(String userName) {
		userName = null;
	}
	
	private boolean checkPwdContent(){
		boolean result=true;
		UserVO tmpVO = new UserVO();
		tmpVO.setPassword(getNewPwd());
		tmpVO.setUserName(getCurrentUserVO().getUserName());
		 HashMap validatePwdMap = TrustbrokerWebAppUtil.validatePwdContent(tmpVO);
			if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME)) {
				errorMessage = (String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_USERNAME);
				result=false;
			}
			if (validatePwdMap.containsKey(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE)) {
				errorMessage=(String)validatePwdMap.get(TrustBrokerWebAppConstants.PWD_CONTAINS_SPACE);
				result=false;
			}
			
			return result;
	}

	public boolean isPwdSpcErrInd() {
		return pwdSpcErrInd;
	}

	public void setPwdSpcErrInd(boolean pwdSpcErrInd) {
		this.pwdSpcErrInd = pwdSpcErrInd;
	}

	public boolean isPwdDoNotMatch() {
		return pwdDoNotMatch;
	}

	public void setPwdDoNotMatch(boolean pwdDoNotMatch) {
		this.pwdDoNotMatch = pwdDoNotMatch;
	}
	
	
}
