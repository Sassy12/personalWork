'use strict';

var tbApp = angular.module('tbApp');

tbApp.controller('lexisNexisCtrl', ['$scope', 'lexisNexisService', 'trustbrokerAriaService', '$timeout', 'LanguageService', '$translate', '$state', '$window', 'HelpObj', '$rootScope',
function($scope, lexisNexisService, trustbrokerAriaService, $timeout, LanguageService, $translate, $state, $window, HelpObj, $rootScope) {
    LanguageService.doTranslate('idproofing');

    HelpObj.setHelpObj({ url: '../../webHelp/Default_CSH.htm#Optum ID CSH/entry_1019_ID_Proofing_Screen.htm' });

    // ================================================================================================================
    // initial scope values============================================================================================
    // ================================================================================================================

    // $scope.dob = "";
    $scope.selectedState = '';
    $scope.errors = {};
    $scope.showErrorMsgModel = false;
    var select = {
        label: $translate.instant('select'),
        value: ''
    };
    $scope.stateNames = [select];
    var idProofingData = {};
    $scope.buttonText = 'nextBtn'; // initial button text

    // calendar (date of birth) component configurations
    $scope.dobViewModel = {
        required:true,
        invalid: false,
    	displayAgeInformation:false,
    	labelledBy: 'dobLabel',
    	textFieldClassName: 'tk-height-2t',
    	enableValidation: false,
    	requiredMessage: 'dateOfBirthReq',
        invalidFormatMessage: 'invalidDateFormat',
        invalidDateMessage: 'invalidDate',
        dobInvalidFutureMessage: 'futureDate',
        invalidYearMessage: 'invalidYear',
        maxYear: new Date().getFullYear()
    };

    // for reading error message by screen readers
    var FIELDS = [
        { fld: "firstNameId_input",     msg: "firstNameId_err" },
        { fld: "lastNameId_input",      msg: "lastNameId_err" },
        { fld: "dateOfBirth_dob",       msg: "dateOfBirth_err" },
        { fld: "homeAddressId_input",   msg: "homeAddressId_err" },
        { fld: "zipcodeId_input",       msg: "zipcodeId_err" },
        { fld: "cityId_input",          msg: "cityId_err" },
        { fld: "stateId",               msg: "stateId_err" },
        { fld: "ssnId_input",           msg: "ssnId_err" },
        { fld: "ssnId_input",           msg: "ssnId_tip" },
        { fld: "creditCardId_input",    msg: "creditCardId_err" }
    ];
    
    $timeout(function(){
        var dobElement = document.getElementById('dateOfBirth_dob');
        dobElement.addEventListener('blur', function(){
        	$scope.validateDob();
            // setting describedBy attribute
            $timeout(function() {
                trustbrokerAriaService.setFieldValidity('dateOfBirth_dob', 'dateOfBirth_err');
            }, 300);
        }, true);
    },10);

    // ================================================================================================================
    // Message models==================================================================================================
    // ================================================================================================================

    // error message for form level error
    $scope.errorMsgModel = {
        animationTime: 1,
        autoFadeOut: false,
        content: '<span translate="formLevelError"></span>',
        headingLevel: '2',
        id: 'Success',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: true
    };

    // success message model
    $scope.successMsgModel = {
        animationTime: 1,
        autoFadeOut: false,
        content: '<span translate="verifyIdentitySuccessMsg"></span>',
        headingLevel: '2',
        id: 'Success',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: true
    };

    // ================================================================================================================
    // calling GET methods to get relevant data from server============================================================
    // ================================================================================================================

    // calling service for getting lexis nexis information
    lexisNexisService.getInfo().then(function(response) {
        if (response) {
            $scope.data = response;
            $scope.dob = response.dateOfBirth;
            $scope.uuid = response.uuid;
            $scope.userName = response.userName;

            // storing user information to check for any updates in the value
            $scope.userOriginalInfo = {
                firstName: response.firstName,
                lastName: response.lastName,
                zip: undefined !== response.address ? response.address.zip : '',
                city: undefined !== response.address ? response.address.city : '',
                homeAddress: undefined !== response.address ? response.address.streetAddress : '',
                state: undefined !== response.address ? response.address.state : '',
                dateOfBirth: response.dateOfBirth
            };

            // calling service for getting the list of states
            lexisNexisService.getStates().then(function(data) {
                var stateNames = data.labelValueVOList;
                stateNames.unshift(select);
                $scope.stateNames = stateNames;

                stateNames.forEach(function(stateObj) {
                    if (undefined !== response.address && stateObj.label === response.address.state) {
                        $scope.selectedState = stateObj;
                    }
                });
            });
        }
    });

    /* different user types ======================== */
    // basic id proofing with questions is: BAS54387
    // basic id proofing without questions is: BASNQ543
    // loa3 id proofing with questions is: LOA32384
    // loa3 id proofing without questions is: LOANQ323

    // $scope.needToRemoveThis = true;
    // function for getting user type
    lexisNexisService.getUserType().then(function(response) {
        if (response.code === 'BASNQ543' || response.code === 'BAS54387') {
            $scope.showIfLoa3User = false;
            $scope.buttonText = 'nextBtn';
        } else if (response.code === 'LOA32384' || response.code === 'LOANQ323') {
            $scope.showIfLoa3User = true;
            $scope.buttonText = 'agreeBtn';
        }
    });

    // ================================================================================================================
    // Custom Error Validations========================================================================================
    // ================================================================================================================

    // function for validating future DATE OF BIRTH ONLY
    $scope.validateDob = function() {
    	var dateErrorMsg = validators.isValidDate($scope.dobViewModel);
    	if(!validators.checkIfEmpty(dateErrorMsg)) {
    		$scope.dobError = $translate.instant(dateErrorMsg);
    		return;
    	}
    	$scope.dobError = '';
        return;
    };

    // function DEFINITION for checking if the zip code consists of only numbers
    $scope.checkNumber = function(num) {
        var pattern = /^[0-9]*$/g;
        return pattern.test(num);
    };

    // function definition for validating ZIP CODE
    $scope.validateZipCode = function() {
        // checking if address is not empty
        if ($scope.data.address) {
            // checking if zip is valid
            if (!$scope.data.address.zip) {
                $scope.lexisNexisForm.zipcode.$invalid = true;
                $scope.errors.zipCodeError = true;
                $scope.errors.zipCodeFormatError = false;
            } else if ($scope.checkNumber($scope.data.address.zip) !== true || $scope.data.address.zip.length !== 5) {
                $scope.lexisNexisForm.zipcode.$invalid = true;
                $scope.lexisNexisForm.zipcode.$valid = false;
                $scope.errors.zipCodeFormatError = true;
                $scope.errors.zipCodeError = false;
            } else {
                $scope.lexisNexisForm.zipcode.$invalid = false;
                $scope.errors.zipCodeError = false;
                $scope.errors.zipCodeFormatError = false;
            }
        } else {
            $scope.lexisNexisForm.zipcode.$invalid = true;
            $scope.errors.zipCodeError = true;
            $scope.errors.zipCodeFormatError = false;
        }
    };

    // function definition for validating state
    $scope.validateState = function() {
        var selectedStateName = angular.element('#stateId option:selected').text();

        if (selectedStateName === "" || selectedStateName === $translate.instant('select')) {
            $scope.lexisNexisForm.state.$invalid = true;
        } else {
            $scope.lexisNexisForm.state.$invalid = false;
        }
    };

    //function definition for validating SSN NUMBER
    $scope.validateSsnNumber = function() {
        if ($scope.data.ssnNumber) {
            $scope.ssnRequiredError = false;
            $scope.formattedSsn = validators.formatSSN($scope.data.ssnNumber);

            if ($scope.formattedSsn.formatErrorFlag) {
                $scope.ssnNumberErrorMsg = 'InvalidSsnNumber';
                $scope.lexisNexisForm.ssnNumber.$invalid = true;
            } else {
                angular.element('#ssnId_input').val($("<div/>").html('&bull;&bull;&bull;-&bull;&bull;-&bull;&bull;&bull;&bull;').text());
                $scope.data.finalSsnNumber = $scope.formattedSsn;
                $scope.invalidSsnFlag = false;
                $scope.ssnNumberErrorMsg = false;
                $scope.lexisNexisForm.ssnNumber.$invalid = false;
            }
        } else {
            $scope.lexisNexisForm.ssnNumber.$invalid = true;
            $scope.ssnRequiredError = true;
            $scope.ssnNumberErrorMsg = false;
        }
    };

    // function definition for validating CREDIT CARD INFO
    $scope.validateCreditCard = function() {
        // checking if credit card field has 5 digits
        var creditCardPattern = /^\d{5}$/;
        if ($scope.data.creditCard) {
            $scope.creditCardRequiredError = false;

            if (!creditCardPattern.test($scope.data.creditCard)) {
                $scope.creditCardErrorMsg = "creditCardInvalidInfo";
                $scope.lexisNexisForm.creditCard.$invalid = true;
            } else {
                $scope.creditCardErrorMsg = false;
                $scope.lexisNexisForm.creditCard.$invalid = false;
            }
        } else {
            $scope.lexisNexisForm.creditCard.$invalid = true;
            $scope.creditCardRequiredError = true;
            $scope.creditCardErrorMsg = false;
        }
    };

    // ================================================================================================================
    // ON BLUR EVENTS==================================================================================================
    // ================================================================================================================

    // function for setting describedBy attribute for (first name, last name, home address and city)
    $scope.commonBlurValidation = function(inputId, spanId) {
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity(inputId, spanId);
        }, 300);
    };

    // function for checking zip code on BLUR EVENT
    $scope.checkZipCodeOnBlur = function() {
        $scope.validateZipCode(); // checking if zip is valid

        // setting describedBy attribute
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity('zipcodeId_input', 'zipcodeId_err');
        }, 300);
    };

    // function for checking if ssn is valid and the formatting it.
    $scope.checkSsnOnBlur = function() {
        $scope.validateSsnNumber(); // calling function for validating ssn 

        // setting describedBy attribute
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity('ssnId_input', 'ssnId_err');
        }, 300);
    };

    //credit card error validation ON BLUR EVENT
    $scope.checkCreditCardOnBlur = function() {
        $scope.validateCreditCard(); // validating credit card info

        // setting describedBy attribute
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity('creditCardId_input', 'creditCardId_err');
        }, 300);
    };

    // ================================================================================================================
    // ON CHANGE EVENTS================================================================================================
    // ================================================================================================================

    // function for checking for state
    $scope.checkStateOnChange = function() {
        $scope.validateState(); // calling function for validating state

        // setting describedBy attribute
        $timeout(function() {
            trustbrokerAriaService.setFieldValidity('stateId', 'stateId_err');
        }, 300);
    };

    // ================================================================================================================
    // FORM SUBMISSION (ALSO VALIDATING ALL FIELDS ON SUBMIT)==========================================================
    // ================================================================================================================

    $scope.updateInfo = function(data) {
        $scope.lexisNexisForm.submitted = true; // marking form submit flag as true

        // validating dob
        $scope.validateDob(); 

        $scope.validateState(); // validating if state is not empty

        // validating properties of data object only if data object is not empty
        if (data) {
            if ($scope.showIfLoa3User) {
                $scope.validateSsnNumber(); // calling function for validating ssn 
                $scope.validateCreditCard(); // calling function for validating credit card details
            }

            $scope.validateZipCode(); // validating zip on submit
        } else {
            $scope.lexisNexisForm.zipcode.$invalid = true;
            $scope.errors.zipCodeError = true;
            $scope.errors.zipCodeFormatError = false;
        }

        // checking if form has no errors
        if ($scope.lexisNexisForm.$invalid || $scope.dobError || $scope.lexisNexisForm.zipcode.$invalid) {
            $scope.showErrorMsgModel = true;
            $rootScope.fireErrorTracker = true;
            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);
            return;
        } else {
            // calling lexis nexis service to save user profile information
            $scope.showErrorMsgModel = false;
            var dateOfBirth = angular.element('#dateOfBirth_dob').val();
            var profileData = {
                firstName: data.firstName,
                lastName: data.lastName,
                zip: data.address.zip,
                city: data.address.city,
                homeAddress: data.address.streetAddress,
                state: $scope.selectedState.value,
                dateOfBirth: dateOfBirth,
                uuid: $scope.uuid,
                userName: $scope.userName
            };

            // encapsulating user information 
            $scope.userDuplicateInfo = {
                firstName: data.firstName,
                lastName: data.lastName,
                zip: data.address.zip,
                city: data.address.city,
                homeAddress: data.address.streetAddress,
                state: $scope.selectedState.value,
                dateOfBirth: $scope.dob
            };

            // if there is any update in user information, then only it will make a saveInfo service call
            idProofingData = {
                creditCardNumber: data.creditCard,
                socialSecurityNumber: data.finalSsnNumber
            };

            // if there is any change in user info, then only service call will happen
            if (!angular.equals($scope.userOriginalInfo, $scope.userDuplicateInfo)) {
                lexisNexisService.saveInfo(profileData).then(function(response) {
                    if (response.status === 'success') {
                        processIDProofing(idProofingData);
                    }
                },
                function(error) {
                    $scope.showErrorMsgModel = true;

                    if (error.errorMap) {
                        var map = error.errorMap,
                            prop,
                            serverErrors = {};

                        for (prop in map) {
                            if (map.hasOwnProperty(prop) && prop !== 'addressFieldsError') {
                                var errorKey = map[prop];
                                var translatedMsg = $translate.instant(errorKey);

                                if (translatedMsg !== errorKey) {
                                    serverErrors[prop] = translatedMsg;
                                } else {
                                    serverErrors[prop] = errorKey;
                                }
                            }
                        }

                        $scope.serverErrors = serverErrors;

                        if ($scope.serverErrors && $scope.serverErrors.dob) {
                            $scope.dobError = $scope.serverErrors.dob;
                        }
                    } else if ('message' in error) {
                        $scope.errorMsgModel.content = ['<span>', error.message, '</span>'].join('');
                    }

                    $rootScope.fireErrorTracker = true;

                    $timeout(function() {
                        trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    }, 300);

                    return;
                });
            } else {
                // Invoking id proofing process for the user
                processIDProofing(idProofingData);
            }
        }
    }; //end of updateInfo function

    function processIDProofing(idProofingData) {
        lexisNexisService.proofUser(idProofingData).then(function(responseData) {
            if (undefined !== responseData.errorMap && Object.keys(responseData.errorMap).length > 0) {
                if (undefined !== responseData.errorMap.lexisNexisErrorMsg) {
                    $scope.serverErrorMsgModel = {
                        animationTime: 1,
                        content: '<span> ' + responseData.errorMap.lexisNexisErrorMsg + '</span>',
                        headingLevel: '2',
                        id: 'serverErrorMsg',
                        messageRole: 'alert',
                        messageType: 'error',
                        position: 'inline',
                        visible: true
                    };
                }
            }

            if (responseData.status === "OK") {
                $state.go('lexisNexisSuccess');
            }
        });
    }

    // ================================================================================================================
    // NAVIGATION METHODS==============================================================================================
    // ================================================================================================================

    $scope.goToRpHomePage = function() {
        $window.location = '/tb/app/secure/home.do';
    };

    $scope.goToLogin = function() {
        $window.location = '/tb/app/index.html';
    };
}]);
