var gulp        = require('gulp'),              // https://github.com/gulpjs/gulp/blob/master/docs/getting-started.md
    concat      = require('gulp-concat'),       // https://github.com/contra/gulp-concat
    cssnano     = require('gulp-cssnano'),      // https://github.com/ben-eb/gulp-cssnano
    htmlhint    = require("gulp-htmlhint"),     // https://github.com/bezoerb/gulp-htmlhint
    gulpif      = require('gulp-if'),           // https://github.com/robrich/gulp-if
    jshint      = require('gulp-jshint'),       // https://github.com/spalger/gulp-jshint
    ngAnnotate  = require('gulp-ng-annotate'),  // https://github.com/Kagami/gulp-ng-annotate
    uglify      = require('gulp-uglify'),       // https://github.com/terinjokes/gulp-uglify
    runSequence = require('run-sequence'),      // https://github.com/OverZealous/run-sequence
    args        = require('yargs').argv;        // https://github.com/yargs/yargs


gulp.task('default', function(callback) {
    runSequence('lint', 'generate-min', callback);
});


gulp.task('generate-min', ['minify-libs', 'minify-uitk-req-deps', 'minify-prelogin', 'minify-postlogin', 'minify-uitk-req-css', 'copy-fonts']);


gulp.task('copy-fonts', function() {
    return gulp.src('src/main/bower_components/uitk-core/css/fonts/*')
        .pipe(gulp.dest('src/main/webapp/static/css/fonts/'));
});


gulp.task('lint', function() {
    return gulp.src([
        'src/main/webapp/app/**/*.js',
        'src/test/javascript/**/*.js'
    ])
    .pipe(jshint())
    .pipe(jshint.reporter('jshint-stylish'))
    .pipe(jshint.reporter('fail'));
});


/*  == HTML Lint Gulp Task ==
    See these pages for additional info:
    https://github.com/yaniswang/HTMLHint/wiki/Rules
    https://www.npmjs.com/package/gulp-htmlhint */

gulp.task('htmlhint', function() {
    return gulp.src([
        /* == Project Folders: == */
        "src/main/webapp/app/common/**/*.html",
        "src/main/webapp/app/login/**/*.html",
        "src/main/webapp/app/privacyPolicy/**/*.html",
        "src/main/webapp/app/registration/**/*.html",
        "src/main/webapp/app/secure/**/*.html",
        "src/main/webapp/app/selfservice/**/*.html",
        "src/main/webapp/app/siteminder/**/*.html",
        "src/main/webapp/app/tb-error/**/*.html",
        "src/main/webapp/app/termsOfUse/**/*.html",

        /* == Project root files: == */
        "src/main/webapp/app/*.html",
        // "src/main/webapp/app/index.html",
        // "src/main/webapp/app/secure/home.html",
        // "src/main/webapp/app/invalidapplication.html"
    ])
    .pipe(htmlhint('.htmlhintrc'))
    .pipe(htmlhint.reporter());
    // .pipe(htmlhint.failReporter());
});


gulp.task('minify-libs', function() {
    return gulp.src([
        'src/main/bower_components/uitk-core/lib/jquery/jquery.js',
        'src/main/bower_components/uitk-core/lib/lodash/lodash.js',
        'src/main/bower_components/uitk-core/lib/angular/angular.js',
        'src/main/bower_components/uitk-core/lib/angular/angular-resource.js',
        'src/main/bower_components/uitk-core/lib/angular-translate/angular-translate.js',
        'src/main/bower_components/uitk-core/lib/ng-csv/ng-csv.js',
        'src/main/bower_components/uitk-core/browser-detection/js/bowser.min.js',
        'src/main/bower_components/uitk-core/browser-detection/js/detectSupportedBrowsers.js',
        'src/main/bower_components/uitk-core/browser-detection/js/setCookiesForBrowserDetection.js',
        'src/main/webapp/static-assets/lib/js/angular-translate-loader-partial.js',
        'src/main/webapp/static-assets/angular-cookies.js',
        'src/main/webapp/static-assets/lib/js/angular-ui-router.js',
        'src/main/webapp/static-assets/lib/js/angular-css.js'
    ])
    .pipe(concat('lib-min.js'))
    .pipe(ngAnnotate())
    .pipe(gulpif(args.ci, uglify()))
    .pipe(gulp.dest('src/main/webapp/static/js/'));
});


gulp.task('minify-uitk-req-deps', function() {
    return gulp.src([
        'src/main/bower_components/uitk-core/slideanimation/js/uitk-slide-animation.js',
        'src/main/bower_components/uitk-core/utility/js/uitk-utility.js',
        'src/main/bower_components/uitk-core/configs/js/uitk-consumer-configs.js',
        'src/main/bower_components/uitk-core/navigable/js/uitk-navigable.js',
        'src/main/bower_components/uitk-core/busy-indicator/js/uitk-busy-indicator.js',
        'src/main/bower_components/uitk-core/js/uitk/uitk_api.js',
        'src/main/bower_components/uitk-core/maxlength/js/uitk-maxlength.js',
        'src/main/bower_components/header/js/uitk-header.js',
        'src/main/bower_components/help/js/uitk-help.js',
        'src/main/bower_components/accordion/js/uitk-accordion.js',
        'src/main/bower_components/button/js/uitk-button.js',
        'src/main/bower_components/dynamic-table/js/uitk-dynamic-table.js',
        'src/main/bower_components/error-handler/js/uitk-error-handler.js',
        'src/main/bower_components/footer/js/uitk-footer.js',
        'src/main/bower_components/global-navigation/js/uitk-global-navigation.js',
        'src/main/bower_components/input-masking/js/uitk-input-masking.js',
        'src/main/bower_components/label/js/uitk-label.js',
        'src/main/bower_components/dialog/js/uitk-dialog.js',
        'src/main/bower_components/message/js/uitk-message.js',
        'src/main/bower_components/panel/js/uitk-panel.js',
        'src/main/bower_components/primary-navigation/js/uitk-primary-navigation.js',
        'src/main/bower_components/single-select-dropdown/js/uitk-single-select-dropdown.js',
        'src/main/bower_components/calendar/js/uitk-calendar.js',
        'src/main/bower_components/checkbox-group/js/uitk-checkbox-group.js',
        'src/main/bower_components/tabs/js/uitk-tabs.js',
        'src/main/bower_components/radio-select-group/js/uitk-radio-select-group.js',
        'src/main/bower_components/textarea/js/uitk-textarea.js',
        'src/main/bower_components/textfield/js/uitk-text-field.js',
        'src/main/bower_components/tooltip/js/uitk-tooltip.js',
        'src/main/bower_components/session-timeout/js/uitk-session-timeout.js',
        'src/main/bower_components/vertical-navigation/js/uitk-vertical-navigation.js',
        'src/main/bower_components/date-of-birth/js/uitk-date-of-birth.js',
        'src/main/webapp/static-assets/oid/js/TextSelectCombo.js'
    ])
    .pipe(concat('uitk-req-min.js'))
    .pipe(ngAnnotate())
    .pipe(gulpif(args.ci, uglify()))
    .pipe(gulp.dest('src/main/webapp/static/js/'));
});


gulp.task('minify-prelogin', function() {
    return gulp.src([
        'src/main/webapp/app/common/validations.js',
        'src/main/webapp/app/common/commonservices.js',
        'src/main/webapp/app/common/commonApp.js',
        'src/main/webapp/app/common/emailconfirmation/verifyService.js',
        'src/main/webapp/app/common/emailconfirmation/verifyController.js',
        'src/main/webapp/app/common/updateemail/updateEmailAddressService.js',
        'src/main/webapp/app/common/updateemail/updateEmailAddressController.js',
        'src/main/webapp/app/index-app.js',
        'src/main/webapp/app/invalid.js',
        'src/main/webapp/app/trustbrokerAriaLibrary.js',
        'src/main/webapp/app/login/login.js',
        'src/main/webapp/app/login/loginService.js',
        'src/main/webapp/app/registration/registration.js',
        'src/main/webapp/app/registration/registrationservice.js',
        'src/main/webapp/app/selfservice/forgot_unamepwd_service.js',
        'src/main/webapp/app/selfservice/forgot_username_password.js',
        'src/main/webapp/app/selfservice/forgot_password.js',
        'src/main/webapp/app/selfservice/findunamewotherinfo.js',
        'src/main/webapp/app/selfservice/findunamewithmoredetails.js',
        'src/main/webapp/app/selfservice/findUserNameDetailsByIdentity.js',
        'src/main/webapp/app/selfservice/verifyIdentityBySecurityQuestions.js',
        'src/main/webapp/app/selfservice/findpwdwmoreinfo.js',
        'src/main/webapp/app/selfservice/setupsecqns.js',
        'src/main/webapp/app/selfservice/mobileVerification.js',
        'src/main/webapp/app/selfservice/mobileVerificationService.js',
        'src/main/webapp/app/selfservice/resetPassword.js',
        'src/main/webapp/app/selfservice/resetPasswordService.js',
        'src/main/webapp/app/selfservice/footermsg.js',
        'src/main/webapp/app/termsOfUse/termsOfUse.js',
        'src/main/webapp/app/termsOfUse/termsOfUseService.js',
        'src/main/webapp/app/selfservice/linkExpiredPage.js',
        'src/main/webapp/app/selfservice/resetCredentialsVerificationLink.js',
        'src/main/webapp/app/tb-error/errorPage.js',
        'src/main/webapp/app/tb-error/errorService.js',
        'src/main/webapp/app/tb-error/genErrorPage.js',
        'src/main/webapp/app/tb-error/genErrorService.js',
        'src/main/webapp/app/selfservice/setSecurityQuestions.js',
        'src/main/webapp/app/selfservice/setSecurityQuestionsVerifyIdentity.js',
        'src/main/webapp/app/selfservice/noAccountRecovery.js',
        'src/main/webapp/app/siteminder/siteminder.js',
        'src/main/webapp/app/siteminder/siteminderservice.js',
        'src/main/webapp/app/registration/verifyAccount.js',
        'src/main/webapp/app/registration/verifyAccountService.js'
    ])
    .pipe(concat('prelogin.min.js'))
    .pipe(ngAnnotate())
    .pipe(gulpif(args.ci, uglify()))
    .pipe(gulp.dest('src/main/webapp/static/js/'));
});


gulp.task('minify-postlogin', function() {
    return gulp.src([
        'src/main/webapp/app/common/validations.js',
        'src/main/webapp/app/common/commonservices.js',
        'src/main/webapp/app/trustbrokerAriaLibrary.js',
        'src/main/webapp/app/common/commonApp.js',
        'src/main/webapp/app/common/emailconfirmation/verifyService.js',
        'src/main/webapp/app/common/emailconfirmation/verifyController.js',
        'src/main/webapp/app/common/updateemail/updateEmailAddressService.js',
        'src/main/webapp/app/common/updateemail/updateEmailAddressController.js',
        'src/main/webapp/app/secure/tb-app.js',
        'src/main/webapp/app/secure/manageid/profileservice.js',
        'src/main/webapp/app/secure/manageid/manageprofile.js',
        'src/main/webapp/app/secure/stepup/stepup.js',
        'src/main/webapp/app/secure/stepup/stepupService.js',
        'src/main/webapp/app/secure/consent/consent.js',
        'src/main/webapp/app/secure/consent/consentService.js',
        'src/main/webapp/app/secure/manageid/changepwd.js',
        'src/main/webapp/app/secure/manageid/verifyoptions.js',
        'src/main/webapp/app/secure/manageid/OptumIdSuccessNoVerification.js',
        'src/main/webapp/app/secure/manageid/OptumIdSuccessVerificationNeeded.js',
        'src/main/webapp/app/secure/tb-error/errorPage.js',
        'src/main/webapp/app/secure/tb-error/errorService.js',
        'src/main/webapp/app/secure/idproofing/lexisNexis.js',
        'src/main/webapp/app/secure/idproofing/lexisNexisService.js',
        'src/main/webapp/app/secure/addaccountrecovery/addAccntRecoveryController.js',
        'src/main/webapp/app/secure/addaccountrecovery/addAccntRecoveryService.js',
        'src/main/webapp/app/secure/mobileverification/mobileVerificationCtrl.js',
        'src/main/webapp/app/secure/mobileverification/mobileVerificationService.js',
        'src/main/webapp/app/secure/verifyrecoveryoptions/verifyRecoveryOptionsService.js',
        'src/main/webapp/app/secure/verifyrecoveryoptions/verifyRecoveryOptions.js'

    ])
    .pipe(concat('postlogin.min.js'))
    .pipe(ngAnnotate())
    .pipe(gulpif(args.ci, uglify()))
    .pipe(gulp.dest('src/main/webapp/static/js/'));
});


gulp.task('minify-uitk-req-css', function() {
    return gulp.src([
        'src/main/bower_components/uitk-core/css/uitk-defaults.css',
        'src/main/bower_components/uitk-core/busy-indicator/css/uitk-busy-indicator.css',
        'src/main/webapp/static/css/uitk-grids.css',
        'src/main/bower_components/header/css/header.css',
        'src/main/bower_components/accordion/css/uitk-accordion.css',
        'src/main/bower_components/button/css/uitk-button.css',
        'src/main/bower_components/dynamic-table/css/uitk-dynamic-table.css',
        'src/main/bower_components/footer/css/uitk-footer.css',
        'src/main/bower_components/header/css/header.css',
        'src/main/bower_components/label/css/uitk-label.css',
        'src/main/bower_components/textfield/css/uitk-text-field.css',
        'src/main/bower_components/input-masking/css/uitk-input-masking.css',
        'src/main/bower_components/dialog/css/uitk-dialog.css',
        'src/main/bower_components/panel/css/uitk-panel.css',
        'src/main/bower_components/tabs/css/tabs.css',
        'src/main/bower_components/tabs/css/tabs-tablet.css',
        'src/main/bower_components/radio-select-group/css/uitk-radio-select-group.css',
        'src/main/bower_components/textarea/css/uitk-textarea.css',
        'src/main/bower_components/single-select-dropdown/css/uitk-single-select-dropdown.css',
        'src/main/bower_components/calendar/css/uitk-calendar.css',
        'src/main/bower_components/checkbox-group/css/uitk-checkbox-group.css',
        'src/main/bower_components/tooltip/css/uitk-tooltip.css',
        'src/main/bower_components/primary-navigation/css/primary-navigation.css',
        'src/main/bower_components/vertical-navigation/css/vertical-navigation.css',
        'src/main/bower_components/global-navigation/css/uitk-global-navigation.css',
        'src/main/bower_components/message/css/message.css'
    ])
    .pipe(concat('uitk-req-min.css'))
    .pipe(gulpif(args.ci, cssnano()))
    .pipe(gulp.dest('src/main/webapp/static/css/'));
});


gulp.task('generate-min-watch', function(callback) {
    runSequence('lint', 'minify-prelogin', 'minify-postlogin', callback);
});

/* Adding this task for watch & react for JS files*/
gulp.task('watch', function(callback) {
    gulp.watch(['src/main/webapp/app/**/*.js', 'src/test/javascript/**/*.js'], ['generate-min-watch']);
});
