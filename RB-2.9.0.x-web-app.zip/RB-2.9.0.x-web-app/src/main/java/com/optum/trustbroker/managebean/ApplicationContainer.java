/*******************************************************************************
 * Copyright (c) 2012 Optum - All Rights Reserved.
 ******************************************************************************/
package com.optum.trustbroker.managebean;

import java.util.Properties;
import java.util.ResourceBundle;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import com.pingidentity.opentoken.Agent;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ResourceBundleMessageSource;

import com.optum.trustbroker.EmailSender;
import com.optum.trustbroker.aa.web.actions.SetDeviceDetailsAction;
import com.optum.trustbroker.aa.web.helpers.DeviceHelper;
import com.optum.trustbroker.analytics.AnalyticsUtils;
import com.optum.trustbroker.securemessaging.SecureMessagingService;
import com.optum.trustbroker.service.ConfigurationService;
import com.optum.trustbroker.service.CredentialService;
import com.optum.trustbroker.service.EventPublisherService;
import com.optum.trustbroker.service.IDProofingService;
import com.optum.trustbroker.service.InvitationService;
import com.optum.trustbroker.service.ReferenceService;
import com.optum.trustbroker.service.RelyingPartyAppService;
import com.optum.trustbroker.service.TagService;
import com.optum.trustbroker.service.UploadedImageService;
import com.optum.trustbroker.service.UserRelyingPartyRelationService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.service.UserTagService;
import com.optum.trustbroker.service.UserVerifyCodesService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.CryptAgentUtil;
import com.uhg.iam.alps.authentication.sm.core.RedirectingLoginServiceWrapper;
import com.uhg.iam.alps.common.http.RedirectingHttpResponseExecutorImpl;
import com.uhg.iam.alps.sso.SsoService;
import com.uhg.iam.commons.converter.DataConverter;
@ApplicationScoped
@ManagedBean(name="container", eager=true)
public class ApplicationContainer   {

	BaseLogger logger = new BaseLogger(ApplicationContainer.class);

	@ManagedProperty(value = "#{cryptAgentUtil}")
	private CryptAgentUtil cryptAgentUtil;

	@ManagedProperty(value = "#{redirectingHttpResponseExecutorImpl}")
	private RedirectingHttpResponseExecutorImpl redirectingHttpResponseExecutorImpl;

	@ManagedProperty(value = "#{relyingPartyAppService}")
	private RelyingPartyAppService relyingPartyAppService;
	
	@ManagedProperty(value = "#{uploadedImageService}")
	private UploadedImageService uploadedImageService;
	
	@ManagedProperty(value = "#{userTagService}")
	private UserTagService userTagService;
	
	@ManagedProperty(value = "#{tb_service_errorMessageResource}")
	private MessageSource errorMessageSource;
	
	@ManagedProperty(value = "#{referenceService}")
	private ReferenceService referenceService;
	
	@ManagedProperty(value = "#{invitationService}")
	private InvitationService invitationService;
	
	@ManagedProperty(value = "#{configurationService}")
	private ConfigurationService configService;
	
	@ManagedProperty(value = "#{credentialService}")
	private CredentialService credentialService;
	
	@ManagedProperty(value = "#{userService}")
	private UserService userService;
	
	@ManagedProperty(value = "#{configProps}")
	private Properties configProps;
	
	@ManagedProperty(value = "#{tagService}")
	private TagService tagService;
	
	@ManagedProperty(value = "#{userRelyingPartyRelationService}")
	private UserRelyingPartyRelationService userRelyingPartyRelationService;
	
	@ManagedProperty(value = "#{setDeviceDetailsAction}")
	private SetDeviceDetailsAction setDeviceDetailsAction;
	
	@ManagedProperty(value = "#{deviceHelper}")
	private DeviceHelper deviceHelper;
	
	@ManagedProperty(value="#{optumid_dataConverterSsoContextToUserVO}")
	private DataConverter ssoContextUserVoDataConverter;
	
	@ManagedProperty(value = "#{idProofingService}")
	private IDProofingService idProofingService;
	
	@ManagedProperty(value = "#{secureMessagingService}")
	private SecureMessagingService secureMessagingService;
	
	@ManagedProperty(value = "#{optumidSMDlwsBasedLoginService}")
	private RedirectingLoginServiceWrapper optumidSMDlwsBasedLoginService;

	@ManagedProperty(value = "#{emailSenderCommon}")
  private EmailSender emailSenderCommon;

	@ManagedProperty(value = "#{emailMessageSource}")
	private ResourceBundleMessageSource emailMessageSource;
	
	@ManagedProperty(value = "#{userVerifyCodesService}")
	private UserVerifyCodesService userVerifyCodesService;
	
	@ManagedProperty(value = "#{optumId_eventPublisherService}")
	private EventPublisherService eventPublisherService;
	
	@ManagedProperty(value = "#{analyticsUtils}")
	private AnalyticsUtils analyticsUtils;

    @ManagedProperty(value = "#{openTokenAgent}")
    private Agent openTokenAgent;

	public SetDeviceDetailsAction getSetDeviceDetailsAction() {
		return setDeviceDetailsAction;
	}

	public void setSetDeviceDetailsAction(
			SetDeviceDetailsAction setDeviceDetailsAction) {
		this.setDeviceDetailsAction = setDeviceDetailsAction;
	}

	public DeviceHelper getDeviceHelper() {
		return deviceHelper;
	}

	public void setDeviceHelper(DeviceHelper deviceHelper) {
		this.deviceHelper = deviceHelper;
	}

	public UserRelyingPartyRelationService getUserRelyingPartyRelationService() {
		return userRelyingPartyRelationService;
	}

	public void setUserRelyingPartyRelationService(
			UserRelyingPartyRelationService userRelyingPartyRelationService) {
		this.userRelyingPartyRelationService = userRelyingPartyRelationService;
	}

	public TagService getTagService() {
		return tagService;
	}

	public void setTagService(TagService tagService) {
		this.tagService = tagService;
	}

	public Properties getConfigProps() {
		return configProps;
	}

	public void setConfigProps(Properties configProps) {
		this.configProps = configProps;
	}

	public static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");
	
	public RelyingPartyAppService getRelyingPartyAppService() {
		return relyingPartyAppService;
	}

	public void setRelyingPartyAppService(
			RelyingPartyAppService relyingPartyAppService) {
		this.relyingPartyAppService = relyingPartyAppService;
	}
   
	public UploadedImageService getUploadedImageService() {
		return uploadedImageService;
	}

	public void setUploadedImageService(UploadedImageService uploadedImageService) {
		this.uploadedImageService = uploadedImageService;
	}

	public RedirectingHttpResponseExecutorImpl getRedirectingHttpResponseExecutorImpl() {
		return redirectingHttpResponseExecutorImpl;
	}

	public UserTagService getUserTagService() {
		return userTagService;
	}

	public void setUserTagService(UserTagService userTagService) {
		this.userTagService = userTagService;
	}

	public void setRedirectingHttpResponseExecutorImpl(
			RedirectingHttpResponseExecutorImpl redirectingHttpResponseExecutorImpl) {
		this.redirectingHttpResponseExecutorImpl = redirectingHttpResponseExecutorImpl;
	}

	@ManagedProperty(value = "#{providerDelegatingSsoService}")
	public SsoService providerDelegatingSsoService;

	public SsoService getProviderDelegatingSsoService() {
		return providerDelegatingSsoService;
	}

	public void setProviderDelegatingSsoService(
			SsoService providerDelegatingSsoService) {
		this.providerDelegatingSsoService = providerDelegatingSsoService;
	}

	public ReferenceService getReferenceService() {
		return referenceService;
	}

	public void setReferenceService(ReferenceService referenceService) {
		this.referenceService = referenceService;
	}
	
	public InvitationService getInvitationService() {
		return invitationService;
	}

	public void setInvitationService(InvitationService invitationService) {
		this.invitationService = invitationService;
	}
	
	public ConfigurationService getConfigService() {
		return configService;
	}

	public void setConfigService(ConfigurationService configService) {
		this.configService = configService;
	}
	
	public CredentialService getCredentialService() {
		return credentialService;
	}

	public void setCredentialService(CredentialService credentialService) {
		this.credentialService = credentialService;
	}

	
	/**
	 * @return the cryptAgentUtil
	 */
	public CryptAgentUtil getCryptAgentUtil() {
		return cryptAgentUtil;
	}

	/**
	 * @param cryptAgentUtil the cryptAgentUtil to set
	 */
	public void setCryptAgentUtil(CryptAgentUtil cryptAgentUtil) {
		this.cryptAgentUtil = cryptAgentUtil;
	}
	

	public MessageSource getErrorMessageSource() {
		return errorMessageSource;
	}

	public void setErrorMessageSource(MessageSource errorMessageSource) {
		this.errorMessageSource = errorMessageSource;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
	public DataConverter getSsoContextUserVoDataConverter() {
		return ssoContextUserVoDataConverter;
	}

	public void setSsoContextUserVoDataConverter(
			DataConverter ssoContextUserVoDataConverter) {
		this.ssoContextUserVoDataConverter = ssoContextUserVoDataConverter;
	}

	public IDProofingService getIdProofingService() {
		return idProofingService;
	}

	public void setIdProofingService(IDProofingService idProofingService) {
		this.idProofingService = idProofingService;
	}

	public SecureMessagingService getSecureMessagingService() {
		return secureMessagingService;
	}

	public void setSecureMessagingService(
			SecureMessagingService secureMessagingService) {
		this.secureMessagingService = secureMessagingService;
	}

	public RedirectingLoginServiceWrapper getOptumidSMDlwsBasedLoginService() {
		return optumidSMDlwsBasedLoginService;
	}

	public void setOptumidSMDlwsBasedLoginService(
			RedirectingLoginServiceWrapper optumidSMDlwsBasedLoginService) {
		this.optumidSMDlwsBasedLoginService = optumidSMDlwsBasedLoginService;
	}

	public EmailSender getEmailSenderCommon() {
		return emailSenderCommon;
	}

	public void setEmailSenderCommon(EmailSender emailSenderCommon) {
		this.emailSenderCommon = emailSenderCommon;
	}

	public ResourceBundleMessageSource getEmailMessageSource() {
		return emailMessageSource;
	}

	public void setEmailMessageSource(ResourceBundleMessageSource emailMessageSource) {
		this.emailMessageSource = emailMessageSource;
	}

	public UserVerifyCodesService getUserVerifyCodesService() {
		return userVerifyCodesService;
	}

	public void setUserVerifyCodesService(
			UserVerifyCodesService userVerifyCodesService) {
		this.userVerifyCodesService = userVerifyCodesService;
	}

	public EventPublisherService getEventPublisherService() {
		return eventPublisherService;
	}

	public void setEventPublisherService(EventPublisherService eventPublisherService) {
		this.eventPublisherService = eventPublisherService;
	}

	public AnalyticsUtils getAnalyticsUtils() {
		return analyticsUtils;
	}

	public void setAnalyticsUtils(AnalyticsUtils analyticsUtils) {
		this.analyticsUtils = analyticsUtils;
	}

    /**
     * Retrieve the Open Token agent.
     */
    public Agent getOpenTokenAgent() {
        return openTokenAgent;
    }

    /**
     * Sets the open token agent associated with this container.
     *
     * @param openTokenAgent The open token agent
     */
    public void setOpenTokenAgent(Agent openTokenAgent) {
        this.openTokenAgent = openTokenAgent;
    }
}
