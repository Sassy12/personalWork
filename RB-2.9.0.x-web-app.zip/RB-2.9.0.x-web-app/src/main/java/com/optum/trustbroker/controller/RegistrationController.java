package com.optum.trustbroker.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.ApplicationContext;
import com.optum.trustbroker.context.ApplicationContextHolder;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.LabelValueVO;
import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.controller.vo.SecurityQuestionVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.controller.vo.VerifyCodesCtx;
import com.optum.trustbroker.esso.sso.SsoContext;
import com.optum.trustbroker.esso.sso.utils.SsoUtils;
import com.optum.trustbroker.helpers.RelyingPartyHelper;
import com.optum.trustbroker.helpers.UserHelper;
import com.optum.trustbroker.service.InvitationService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.InvitationConstants;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.ValidationUtils;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.InvitationContextPropertyVO;
import com.optum.trustbroker.vo.InvitationServiceResponse;
import com.optum.trustbroker.vo.InvitationVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.RelyingPartyTierInfoVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.commons.converter.DataConverter;

@Component
@Path(TBConstants.REGISTRATION_CONTROLLER_PATH)
public class RegistrationController extends BaseController {

    @Autowired
    private ValidationUtils validationUtils;

    @Autowired
    private InvitationService invitationService;

    @Autowired
    private DataConverter optumid_dataConverterSsoContextToUserVO;

    static final BaseLogger logger = new BaseLogger(RegistrationController.class);

    @Path(TBConstants.REGISTRATION_INITIALIZE_DATA)
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public UserInfoVO initializeData(@Context HttpServletRequest request) {
        UserInfoVO userInfoVO = new UserInfoVO();

        if (TBUtil.isLocalEnv()) {
            userInfoVO.setLocalEnv("true");
        }
        try {
            RpAppVO rpAppVO = new RpAppVO();
            userInfoVO.setRpAppVO(rpAppVO);
            WebApplicationContext ctx = WebApplicationContextHolder.getContext();

            /* clean events from previous login */
            cleanEvents(ctx);

            String relyingAppId = ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
            String requestTarget = ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET);
            rpAppVO.setTargetURL(requestTarget);

            RelyingPartyTierInfoVO rpTierInfo = null;
            RelyingPartyAppVO relyingPartyAppVO = null;

            if (StringUtils.isNotEmpty(relyingAppId)) {
                relyingPartyAppVO = relyingPartyAppService.fetchRelyingPartyAppByAppId(relyingAppId);
                rpTierInfo = configService.getTierInfoforRP(relyingPartyAppVO.getAlias());
            }

            RelyingPartyHelper.buildRelyingPartyVO(rpAppVO, relyingPartyAppVO, rpTierInfo);

            ChallengeQuestionServiceResponse challengeQuestionServiceResponse = configService.getSecurityQuestions();
            List<LabelValueVO> quesLists = createSecQuestionsModel(
                    challengeQuestionServiceResponse.getUserChallengeQuestions());
            SecurityQuestionVO secQuesVO = new SecurityQuestionVO();
            secQuesVO.setQuestions(quesLists);
            userInfoVO.setSecurityQuestionVO(secQuesVO);

            if (StringUtils.isNotEmpty(request.getParameter(TrustBrokerWebAppConstants.INVITATION))) {
                String invitation = request.getParameter(TrustBrokerWebAppConstants.INVITATION);
                Map<String, String> invitationMap = invitationService.decodeInvitationDetails(invitation);

                if (MapUtils.isNotEmpty(invitationMap)) {
                    captureInvitationInfo(invitationMap, userInfoVO);
                }
            }

            // gtyagi1: Check for Sso Broker request!
            final ApplicationContext appCtx = ApplicationContextHolder.getContext();
            if (SsoUtils.isSsoBrokerDrivenOperation(appCtx)) {
                captureDetailsFromSsoContext(userInfoVO, appCtx);
            }
        } catch (OperationFailedException ope) {
            logger.error("Exception while initialization user registration bean: ",
                    new String[] {TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
            logger.error(ope);
            String rpAppId = null != userInfoVO.getRpAppVO() ? userInfoVO.getRpAppVO().getAppId() : "";
            userInfoVO.addErrorMessage("errorMsg", extractErrorMessageFromOFE(ope, rpAppId));
        }

        return userInfoVO;

    }

    @Path(TBConstants.REGISTRATION_CREATE_USER)
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public UserInfoVO createUser(UserInfoVO userInfoVO, @Context HttpServletRequest request,
            @Context HttpServletResponse response) {

        getValidationUtils().validateName(userInfoVO, TrustBrokerWebAppConstants.FIRST_NAME);
        getValidationUtils().validateName(userInfoVO, TrustBrokerWebAppConstants.LAST_NAME);
        getValidationUtils().validateEmail(userInfoVO);
        getValidationUtils().validateUserName(userInfoVO);
        getValidationUtils().validatePwd(userInfoVO);
        getValidationUtils().validateSecurityInfo(userInfoVO);
        if (userInfoVO.getRpAppVO().isShowDob()) {
        	getValidationUtils().validateDOB(userInfoVO);
        } else if (userInfoVO.getRpAppVO().isCoppaValidationReqd()) {
        	getValidationUtils().validateYOB(userInfoVO);
            userInfoVO.setDateOfBirth(null);
        }

        if (MapUtils.isNotEmpty(userInfoVO.getErrorMap())) {
            return userInfoVO;
        }

        // set up userVO
        UserVO userVO = UserHelper.buildUserInfo(userInfoVO);

        boolean isRegistrationSuccess = registerUser(request, response, userVO, userInfoVO);

        if (isRegistrationSuccess) {

            // TODO Add Invitation stuff when registration is successful
            getWebApplicationCommonUtilities().updateUserInvitaionIfAvailableWithinContext(userVO);
            WebApplicationContextHolder.getContext().removeSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE);

            if (!"home".equalsIgnoreCase(userInfoVO.getNextState())) {
                if (null != userInfoVO.getRpAppVO().getAppId() && !userInfoVO.getRpAppVO().isEmailConfirmationRequired()) {
                    userInfoVO.setNextState("congrats");
                } else {
                    if(userInfoVO.getVerifyCodesCtx() != null){
                        userInfoVO.getVerifyCodesCtx().setChann(CommunicationChannel.PRIMARY_EMAIL);
                    }
                    userInfoVO.setNextState("confirmemail");
                }
            }
        }
        return userInfoVO;

    }

    private boolean registerUser(HttpServletRequest req, HttpServletResponse res, UserVO userVO, UserInfoVO userInfoVO) {
        boolean isRegistrationSuccess = false;
        WebApplicationContext webAppCtx = WebApplicationContextHolder.getContext();
        try {

            UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();

            userProfileServiceRequest.setUser(userVO);

            if (null != userInfoVO.getRpAppVO().getAppId()) {
                userVO.setRpId(userInfoVO.getRpAppVO().getAlias());
            }

            String preVerifyEmail = webAppCtx.getSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL);

            if (userVO.getEmailAddress().equalsIgnoreCase(preVerifyEmail)) {
                userProfileServiceRequest.setPreVerify(true);
            }

            UserProfileServiceResponse response = userService.registerUser(userProfileServiceRequest, true,
                    getVerificationCodeRequest(CommunicationChannel.PRIMARY_EMAIL, userVO, req, userInfoVO.getRpAppVO()));

            logger.debug("Status code: " + response.getExecutionStatus().getStatusCd() + " Status Message: "
                    + response.getExecutionStatus().getStatusMessage());
            SecurityLoggingUtil.info("User Registration", SecurityEventType.E3_CREATE, req, userVO.getUserName(),
                    "Security Audit Event|RegisterUser:SUCCESS | User Registered, RegistrationController:registerUser()",
                    SecurityEventResult.SUCCESS, userInfoVO.getRpAppVO().getAppId(), SecuritySubEventType.E3_CREATE_USER);

            if (null == userVO.getRpId()) {
                userVO.setRpId(TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE);
            }

            createUserSMSession(req, res, userVO.getUserName(), userVO.getRpId());
            userVO.setUuId(response.getUser().getUuId());
            userVO.setUserId(response.getUser().getUserId());

            if (userProfileServiceRequest.isPreVerify() && response.getUser().isIsemailVerified()) {
                webAppCtx.removeSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL);
                userInfoVO.setNextState("home");
            } else if (StringUtils.isNotBlank(userVO.getEmailAddress())) {
                VerifyCodesCtx ctx = new VerifyCodesCtx();
                ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
                ctx.setShowDeviceRegistration(userInfoVO.getRpAppVO().isRsaRequired());
                ctx.setNextView("congratulations");
                ctx.setUserVO(userVO);
                userInfoVO.setVerifyCodesCtx(ctx);
            }

            isRegistrationSuccess = true;

        } catch (OperationFailedException ope) {
            logger.error("Exception during user registration on submit - {}",
                    new String[] {TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
            logger.error(ope);

            String rpAppId = null != userInfoVO.getRpAppVO().getAppId() ? userInfoVO.getRpAppVO().getAppId() : "";
            userInfoVO.addErrorMessage("errorMsg", extractErrorMessageFromOFE(ope, rpAppId));
            ResourceBundle bundle = getBundle();
            if (ope.getMessage().contains("User persistence failed at TB database and ESSO User deleted")) {
                userInfoVO.addErrorMessage("failureReason", "dbfailure");
            } else if (ope.getMessage().contains(bundle.getString("blackListedPasswordMsg"))) {
                userInfoVO.addErrorMessage("pwd", bundle.getString("blackListedPasswordMsg"));
            }
        }
        return isRegistrationSuccess;
    }

    private void captureInvitationInfo(Map<String, String> invitationMap, UserInfoVO userInfoVO) {
        String token = invitationMap.get(InvitationConstants.KEY_INVITATION_TOKEN);
        String relyingAppId = invitationMap.get(InvitationConstants.KEY_REPLYING_PARTY_APP_ID);

        InvitationServiceResponse invitationServiceResponse = invitationService.getInvitationByTokenAndRelyingAppId(token,
                relyingAppId);

        if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(invitationServiceResponse.getExecutionStatus().getStatusCd())) {

            InvitationVO invitationVO = invitationServiceResponse.getInvitationVO();
            int invtnExpirationDays = Integer
                    .parseInt(PropertyLoader.getInstance().getPortalConfigValue("userInvitationExpiration"));

            if (TrustBrokerWebAppConstants.REGISTERED.equals(invitationVO.getInvtnStts().getStatusState())
                    || invitationVO.getInvtnAccptdDttm() != null) {

                userInfoVO.setNextState("invitationExpired");

            } else if (TrustBrokerWebAppConstants.EXPIRED.equals(invitationVO.getInvtnStts().getStatusState())) {
                userInfoVO.setNextState("invitationExpired");
            } else if (invitationVO.getInvtnExprtnDttm() != null
                    && invitationVO.getInvtnExprtnDttm().before(DateUtil.getInstance().getCurrentDateTime())) {
                userInfoVO.setNextState("invitationExpired");
            } else if (invitationVO.getInvtnGenDttm() != null && invitationVO.getInvtnExprtnDttm() == null
                    && DateUtil.validateDateByDays(invitationVO.getInvtnGenDttm(), invtnExpirationDays)) {
                userInfoVO.setNextState("invitationExpired");
            } else {

                WebApplicationContext ctx = WebApplicationContextHolder.getContext();
                ctx.setSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE, token);

                userInfoVO.setEmailAddress(invitationVO.getInvtnToEmail());
                for (InvitationContextPropertyVO invitationContextPropertyVO : invitationVO.getInvitationCtxProperties()) {
                    if (StringUtils.isNotEmpty(invitationContextPropertyVO.getName())) {
                        if (TrustBrokerConstants.FIRSTNAME.equalsIgnoreCase(invitationContextPropertyVO.getName())) {
                            userInfoVO.setFirstName(invitationContextPropertyVO.getValue());
                        } else if (TrustBrokerConstants.LASTNAME.equalsIgnoreCase(invitationContextPropertyVO.getName())) {
                            userInfoVO.setLastName(invitationContextPropertyVO.getValue());
                        } else if (TrustBrokerConstants.USERNAME.equalsIgnoreCase(invitationContextPropertyVO.getName())) {
                            userInfoVO.setUserName(invitationContextPropertyVO.getValue());
                        } else if (TrustBrokerConstants.DOB.equalsIgnoreCase(invitationContextPropertyVO.getName())) {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

                            sdf.setLenient(false);
                            Date testDate = null;
                            boolean isDOBvalid = false;
                            String strDate = invitationContextPropertyVO.getValue();
                            try {
                                testDate = sdf.parse(strDate);
                                isDOBvalid = true;
                            } catch (ParseException e) {
                                isDOBvalid = false;
                            }
                            if (isDOBvalid) {
                                userInfoVO
                                        .setDateOfBirth(new SimpleDateFormat("MM-dd-yyyy", Locale.ENGLISH).format(testDate));
                            }
                        }
                    }
                }

                if (StringUtils.isNotEmpty(userInfoVO.getUserName())) {
                    //Check if username is valid
                	getValidationUtils().validateUserName(userInfoVO);
                }
                if (StringUtils.isNotEmpty(userInfoVO.getFirstName())) {
                	getValidationUtils().validateName(userInfoVO, TrustBrokerWebAppConstants.FIRST_NAME);

                }
                if (StringUtils.isNotEmpty(userInfoVO.getLastName())) {
                	getValidationUtils().validateName(userInfoVO, TrustBrokerWebAppConstants.LAST_NAME);
                }
            }
        } else {
            userInfoVO.setNextState("invitationExpired");
        }
    }

    /**
     * gtyagi1: Method captures details from SsoContext to pre-populate 
     * UserVo from SsoContext
     */
    private void captureDetailsFromSsoContext(UserInfoVO userInfoVO, ApplicationContext appCtx) {
        SsoContext ssoContext = appCtx.retrieve(SsoContext.class);

        try {
            UserVO userVO = new UserVO();
            getOptumid_dataConverterSsoContextToUserVO().convert(ssoContext, userVO);

            userInfoVO.setEmailAddress(userVO.getEmailAddress());
            userInfoVO.setFirstName(userVO.getFirstName());
            userInfoVO.setLastName(userVO.getLastName());
            userInfoVO.setUserName(userVO.getUserName());

            // gtyagi1 note - relying on the correctness of config that
            // attribute used to obtain verified email is same as the
            // one's that's populating email in VO inside DataConverter.
            // Note that although SSOBroker config allows email
            // attribute to vary but DataConverter used to populate
            // UserVO is global and relies on a static well-known
            // name.Relying on config correctness is ok for now,
            // ideally DataConverterShould also use EmailAttribute name
            // from SSO Broker ...to be analyzed later!
            if (StringUtils.isNotBlank(ssoContext.getPreVerifiedEmail())) {
                WebApplicationContextHolder.getContext().setSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL,
                        ssoContext.getPreVerifiedEmail());
            }
        } catch (Exception ex) {
            // gtyagi1: let's not break the UX because of conversion
            // issue, not a big deal as it stands
            logger.error("Exception occured (will be swallowed) in populating user from SsoContext, details - \n{}", ex);
        }

    }

    public InvitationService getInvitationService() {
        return invitationService;
    }

    public void setInvitationService(InvitationService invitationService) {
        this.invitationService = invitationService;
    }

    public ValidationUtils getValidationUtils() {
        return validationUtils;
    }

    public void setValidationUtils(ValidationUtils validationUtils) {
        this.validationUtils = validationUtils;
    }

    public static BaseLogger getLogger() {
        return logger;
    }

    @Override
    public UserService getUserService() {
        return userService;
    }

    @Override
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public DataConverter getOptumid_dataConverterSsoContextToUserVO() {
        return optumid_dataConverterSsoContextToUserVO;
    }

    public void setOptumid_dataConverterSsoContextToUserVO(DataConverter optumid_dataConverterSsoContextToUserVO) {
        this.optumid_dataConverterSsoContextToUserVO = optumid_dataConverterSsoContextToUserVO;
    }

}
