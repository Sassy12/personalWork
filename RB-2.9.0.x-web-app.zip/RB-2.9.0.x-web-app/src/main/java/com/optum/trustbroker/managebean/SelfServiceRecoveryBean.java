package com.optum.trustbroker.managebean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;

import com.optum.trustbroker.auditlogging.IDProofingAuditTypes;
import com.optum.trustbroker.auditlogging.IDProofingLoggingUtil;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.util.UuidUtil;
import com.optum.trustbroker.vo.AddressVO;
import com.optum.trustbroker.vo.IDProofingQuizServiceRequest;
import com.optum.trustbroker.vo.IDProofingQuizServiceResponse;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserTagServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.alps.common.http.HttpUtils;

@ManagedBean
@SessionScoped
public class SelfServiceRecoveryBean extends AbstractBackingBean {
	BaseLogger logger = new BaseLogger(SelfServiceRecoveryBean.class);
	private String firstName;
	private String lastName;
	private String email;
	private boolean invalidUserActError;
	private boolean emailReadOnly;
	private String emailErrorMsg;
	private String idProofingErrorMsg;
	private String verifyIDInvalidAccountMsg;
	private boolean showUpdateProfileLink;
	private UserVO userVO;
	private AddressVO addressVO;
	private String dateOfBirth;
	private String ssnpart1;
	private String ssnpart2;
	private String ssnpart3;
	private String creditCardNumber;
	private boolean agree; 

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		if (isSessionAttributeExists(TrustBrokerWebAppConstants.ACCOUNT_RECOVERY_BY)
				&& "email".equals(getSessionAttribute(TrustBrokerWebAppConstants.ACCOUNT_RECOVERY_BY))) {
			return (String) getSessionAttribute(TrustBrokerWebAppConstants.RECOVERY_BY_EMAIL);
		} else
			return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isInvalidUserActError() {
		return invalidUserActError;
	}

	public void setInvalidUserActError(boolean invalidUserActError) {
		this.invalidUserActError = invalidUserActError;
	}

	public boolean isEmailReadOnly() {
		return emailReadOnly;
	}

	public void setEmailReadOnly(boolean emailReadOnly) {
		this.emailReadOnly = emailReadOnly;
	}

	
	private String generateQuizForUser(IDProofingQuizServiceRequest idProofingQuizServiceRequest) {
		try {
			
			UserVO userVO = idProofingQuizServiceRequest.getUser();
			
			if (checkUserDataForIDProofing(userVO)) {
				setShowUpdateProfileLink(true);
				addMessageToFlash("idProofingErrorMsg", getVerifyIDInvalidAccountMsg());
				return null;
			}
			
			String verificationFlow = idProofingQuizServiceRequest.getVerificationFlow();
			IDProofingQuizServiceResponse idProofingQuizServiceResponse = getContainer().getIdProofingService().generateQuiz(idProofingQuizServiceRequest);
			String executionStatusCd = idProofingQuizServiceResponse.getExecutionStatus().getStatusCd();
			
			logger.debug("executionStatusCd code after generateQuiz call: "+ executionStatusCd);
						
			if(!TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(executionStatusCd)){
				processStatusCode(idProofingQuizServiceResponse, userVO, verificationFlow);
				return null;
			}
			
			IDProofingLoggingUtil.info(getIDProofingAuditType(verificationFlow, true), 
					getRelyingPartyAppId(),userVO.getUserName(), getErrorReasonCode(idProofingQuizServiceResponse.getExecutionStatus()), 
					"SelfServiceRecoveryBean:generateQuizForUser()", getServletRequest());
			Properties configProps = getContainer().getConfigProps();
			
			//If basic or loa3 no quiz flows, redirect to id verification page
			if(configProps.getProperty(TrustBrokerWebAppConstants.BASICNQ_IDP_VERIFN_FLOW_PARAM_KEY).equals(verificationFlow) ||
					configProps.getProperty(TrustBrokerWebAppConstants.LOA3NQ_IDP_VERIFN_FLOW_PARAM_KEY).equals(verificationFlow)){
				return processNQFlows(idProofingQuizServiceResponse);
			} else {
				addSessionAttribute(TrustBrokerWebAppConstants.ID_PROOFING_QUIZ, idProofingQuizServiceResponse.getIdProofingQuizVO());			
				return "/views/knowledgeBasedIdentification.xhtml?faces-redirect=true";
			}
		}
		catch (Exception e) {
			String uid = UuidUtil.generateUid();
			logger.error("Error occured while generating questions using ID Proofing services - {}", new String[]{uid}, e);
			SupportContactInfoVO sci = getSupportContactInfo();
			Object[] msgArguments = {sci.getContactComboText(), uid};
			addMessageToFlash("idProofingErrorMsg", TBUtil.formatMessage(tbResources.getString("systemError"), msgArguments));
			return null;
		}
	}
	
	/**
	 * This method is to process the no quiz basic or loa3 verification flows and add the tag to the user 
	 * and return the control to ide verification success page.
	 * 
	 * @param idProofingQuizServiceResponse
	 * @return String
	 */
	private String processNQFlows(IDProofingQuizServiceResponse idProofingQuizServiceResponse) {
		if (null != getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG_NAME)) {
			try {
				Object tagName = getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG_NAME);
				UserTagServiceResponse resp = addTagToUser(getCurrentUserVO().getUuId(), tagName.toString(),
						idProofingQuizServiceResponse.getVerificationCode());
				if (resp.getExecutionStatus().getStatusCd().equalsIgnoreCase(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
					return "/secure/idverificationsuccess.xhtml?faces-redirect=true";
				}
				else {
					setIdProofingErrorMsg(resp.getExecutionStatus().getStatusMessage());
					return null;
				}
			} catch (OperationFailedException ope) {
				logger.error("Error while applying tag to user: {}", new String[]{getCurrentUserVO().getUserName(),
						TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
				setIdProofingErrorMsg(ope.getMessage());
				return null;
			}
		} else{
			String selfServiceRecoveryType = (String)getSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE);
			if(selfServiceRecoveryType!=null && TrustBrokerWebAppConstants.LOST_ACCESS_TO_RECOVERY.equals(selfServiceRecoveryType))
				return "/views/resetsecurity.xhtml?faces-redirect=true";
			else if(selfServiceRecoveryType != null && TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK.equals(selfServiceRecoveryType))
				return "/views/resetsecuritycredwithoutsq.xhtml?faces-redirect=true";
			else return "/views/resetsecuritycredentials.xhtml?faces-redirect=true";
		}
	}
	
	private boolean processStatusCode(IDProofingQuizServiceResponse serviceResponse, UserVO userVO, String verificationFlow){
		String executionStatusCd = serviceResponse.getExecutionStatus().getStatusCd();
		String errorMsg = null; 
		
		IDProofingLoggingUtil.info(getIDProofingAuditType(verificationFlow, false), 
				getRelyingPartyAppId(),userVO.getUserName(), getErrorReasonCode(serviceResponse.getExecutionStatus()), 
				"SelfServiceRecoveryBean:processStatusCode()", getServletRequest());
		
		SupportContactInfoVO sci = getSupportContactInfo();
		if (TrustBrokerConstants.SYSTEM_ERROR_CODE_VALUE.equals(executionStatusCd)) {
			String uid = UuidUtil.generateUid();
			logger.error("System Error: "+ serviceResponse.getExecutionStatus().getStatusMessage() + " - " + uid);
			Object[] msgArguments = {sci.getContactComboText(), uid};
			addMessageToFlash("idProofingErrorMsg", TBUtil.formatMessage(tbResources.getString("systemError"), msgArguments));
			return false;
		}
		else if (TrustBrokerConstants.BAD_REQUEST_CODE_VALUE.equals(executionStatusCd)) {
			logger.error("Bad Request error: " + serviceResponse.getExecutionStatus().getStatusMessage());
			setShowUpdateProfileLink(true);
			addMessageToFlash("idProofingErrorMsg", getVerifyIDInvalidAccountMsg());
			return false;
		}
		else if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(executionStatusCd)) {
			logger.error("Failure error: "+ serviceResponse.getExecutionStatus().getStatusMessage());
			Object[] msgArguments = {sci.getContactComboText()};
			addMessageToFlash("idProofingErrorMsg", TBUtil.formatMessage(tbResources.getString("verifyIDInvalidAccount"), msgArguments));
			setShowUpdateProfileLink(true);
			return false;
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_ID1.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_ID1"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP1.equals(executionStatusCd)){
			if(TrustBrokerWebAppConstants.BASIC_VALIDATION_IDPROOFING.equals(getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG))){
				Object[] msgArguments = {"", sci.getContactComboText()};
				errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP1_Basic"), msgArguments);
			}
			else if(TrustBrokerWebAppConstants.LOA3_VALIDATION_IDPROOFING.equals(getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG))){
				Object[] msgArguments = {"", sci.getContactComboText()};
 				errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP1_LOA3"), msgArguments);
			}
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP2.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP2"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP3.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP3"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP4.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP4"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP5.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP5"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_QP6.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_QP6"), msgArguments);
		}
		else if(TrustBrokerConstants.ID_PROOFING_ERROR_SE1.equals(executionStatusCd)){
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_SE1"), msgArguments);
		}
		else {
			Object[] msgArguments = {"", sci.getContactComboText()};
			errorMsg = TBUtil.formatMessage(tbResources.getString("errorMsg_GEN"), msgArguments);
		}
		
		if(errorMsg != null){
			logger.error("ID Proofing Failure:"+ serviceResponse.getExecutionStatus().getStatusMessage());
			String errorCodes = StringUtils.join(serviceResponse.getExecutionStatus().getStatusCodesList(), ", ");
			errorCodes = (serviceResponse.getExecutionStatus().getStatusCodesList().size() > 1 ? "s ":" ") + errorCodes;
			Object[] arguments = {errorCodes};
			errorMsg = TBUtil.formatMessage(errorMsg, arguments);
			addMessageToFlash("idProofingErrorMsg", errorMsg);
			setShowUpdateProfileLink(true);
		}
		
		return true;
	}

	private boolean checkUserDataForIDProofing(UserVO userVO) {
		
		
		if(isSessionAttributeExists(TrustBrokerWebAppConstants.QUALIFYING_TAG))
			return false;
		
		List<String> missingData = new ArrayList<String>();
		if (StringUtils.isEmpty(userVO.getFirstName()))
			missingData.add("First Name");
		if (StringUtils.isEmpty(userVO.getLastName()))
			missingData.add("Last Name");
		if (null == userVO.getDob())
			missingData.add("Date of Birth");

		if (userVO.getAddresses() != null && userVO.getAddresses().size() > 0) {
			logger.debug("user address is not null");
			AddressVO addressVO = userVO.getAddresses().get(0);
			if (StringUtils.isEmpty(addressVO.getStreetAddress()))
				missingData.add("Street Address");
			if (StringUtils.isEmpty(addressVO.getCity()))
				missingData.add("City");
			if (StringUtils.isEmpty(addressVO.getZip()))
				missingData.add("Zip");
			if (StringUtils.isEmpty(addressVO.getState()))
				missingData.add("State");
		} else
			missingData.add("Home Address");
		StringBuilder message = new StringBuilder();
		for (int i = 0; i < missingData.size() - 1; i++) {
			if(i == missingData.size()-2)
				message.append(missingData.get(i) + " and ");
			else
				message.append(missingData.get(i) + ", ");
		}

		if (missingData.size() > 0)
			message.append(missingData.get(missingData.size() - 1));

		SupportContactInfoVO sci = getSupportContactInfo();
		if (null!=userVO.getDob() && !DateUtil.validateDate(DateUtil.formatDate(userVO.getDob(), "MM/dd/yyyy"))) {
			if (StringUtils.isNotEmpty(message.toString())) {
				message.append(", Invalid Date of Birth");
				Object[] msgArguments = {sci.getContactComboText(), message.toString()};
				setVerifyIDInvalidAccountMsg(TBUtil.formatMessage(tbResources.getString("selfServiceMissingDataMsgForIDP"), msgArguments));
			}
			else {
				message.append("Invalid Date of Birth");
				Object[] msgArguments = {sci.getContactComboText(), message.toString()};
				setVerifyIDInvalidAccountMsg(TBUtil.formatMessage(tbResources.getString("selfServiceMissingDataMsgForIDP"), msgArguments));
			}
		}
		else {
			Object[] msgArguments = {sci.getContactComboText(), message.toString()};
			setVerifyIDInvalidAccountMsg(TBUtil.formatMessage(tbResources.getString("selfServiceMissingDataMsgForIDP"), msgArguments));
		}
		logger.debug(message + " data is missing from " + userVO.getUserName());
		if (StringUtils.isNotEmpty(message.toString()))
			return true;
		else
			return false;
	}

	public String unlockUserAccount() {
		addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_RECOVERY_TYPE,
				TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK);
		addSessionAttribute("SELF_ACC_RECOVER_TYPE", TrustBrokerWebAppConstants.SELF_SERVICE_RECOVER_UNLOCK);
		@SuppressWarnings("unchecked")
		Map<String, String> userDetails = (HashMap<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP);
		UserVO userVO = getContainer().getUserService().fetchUserProfile((userDetails.get(
				TrustBrokerWebAppConstants.USER_NAME)), false, true).getUser();
		userDetails.put("emailId", userVO.getEmailAddress());
		userDetails.put("uuId", userVO.getUuId());
		String rpAppId = getRelyingPartyAppId();
		if (TrustBrokerConstants.AA_LOCK_STATUS.equalsIgnoreCase(userVO.getAaStatus())) {
			getContainer().getUserService().sendAuthCodeToUser(generateAuthorizationRequest(userVO),
					TrustBrokerConstants.ACCOUNT_RECOVERY, rpAppId, true, getUrlLogoOptumId(), getUrlLogoRelyingParty());
			return "/views/sentauthorizationcode.xhtml?faces-redirect=true";
		}
		else {
			return "/views/unlockuseraccount.xhtml?faces-redirect=true";
		}
	}
	
	public void checkEmailAddress(ValueChangeEvent event) {	
		setEmailErrorMsg("");
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			if (StringUtils.isNotEmpty(event.getNewValue().toString())) {
				boolean result = TBUtil.validateEmailId(event.getNewValue().toString());
				if (!result)
					setEmailErrorMsg(tbResources.getString("invalidEmailAddress"));
			}
		}
	
	}
	
	public void checkSSNField(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			validateSSN(ssnpart1, ssnpart2, ssnpart3);
		}
	}
	/**
	 * This method is to validate the social security number to check for empty value, numeric and total length as 9 
	 * 
	 * @param ssnPart1
	 * @param ssnPart2
	 * @param ssnPart3
	 * @return boolean
	 */
	private boolean validateSSN(String ssnPart1, String ssnPart2, String ssnPart3) {
		boolean validVal = true;
		String errMsg = "";			
		if(StringUtils.isBlank(ssnpart1) && StringUtils.isBlank(ssnpart2) && StringUtils.isBlank(ssnpart3)) {
			errMsg = tbResources.getString("loa3SSNReqMsg");
			validVal = false;
		} else  {
			String ssn[] = {ssnpart1, ssnpart2, ssnpart3};
			String ssnFull = StringUtils.join(ssn);
			if(ssnFull.length() != 9 || !StringUtils.isNumeric(ssnFull)) {
				errMsg = tbResources.getString("ssnValidationMsg");
				validVal = false;
			} 
		}
		
		if(!validVal) {
			addFacesMessage("loa3AdditionalInfoFormID:ssnPart1Id", errMsg);
		}
		return validVal;
	}
	
	public void checkCreditCardField(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			validateCreditCard(creditCardNumber);
		}
	}
	/**
	 * This method is to validate the credit card number to check for empty value, numeric and length as 5 
	 * 
	 * @param creditCardNum
	 * @return boolean
	 */
	private boolean validateCreditCard(String creditCardNum) {
		boolean validNum = true;
		String errMsg = "";			
		if(StringUtils.isBlank(creditCardNum) ) {
			errMsg = tbResources.getString("loa3CreditCardReqMsg");
			validNum = false;
		} else  {
			if(creditCardNum.length() != 5 || !StringUtils.isNumeric(creditCardNum)) {
				errMsg = tbResources.getString("creditCardNoValidationMsg");
				validNum = false;
			} 
		}
		if(!validNum) {
			addFacesMessage("loa3AdditionalInfoFormID:creditCardNumberId", errMsg);
		}
		return validNum;
	}
	
	public void validateCheckbox(FacesContext context, UIComponent component, Object value) {   
	    if (value instanceof Boolean && ((Boolean) value).equals(Boolean.FALSE)) {   
	    	validateAgreeCheckbox(false);
	    }   
	}  

	public boolean validateAgreeCheckbox(boolean value) {   
	    if (!value) {   
	    	addFacesMessage("loa3AdditionalInfoFormID:agreeChkBox", tbResources.getString("loa3AgreeBoxReqMsg"));
	    }  
	    return value;
	}  
	
	private void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	public String cancel() {
		
		String redirectURL = "/views/login.xhtml?faces-redirect=true";
		
		String relyingPartyAppId = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		String relyingPartyTargetURL =  (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);		
		
		if (StringUtils.isNotBlank(relyingPartyAppId) && StringUtils.isNotBlank(relyingPartyTargetURL)) {
			redirectURL = HttpUtils.addParameterToURL(redirectURL, TrustBrokerConstants.RELYING_APP_ID_PARAM, relyingPartyAppId);
			redirectURL = HttpUtils.addParameterToURL(redirectURL, TrustBrokerConstants.TARGET, relyingPartyTargetURL);
		} 
		
		return redirectURL;
	}
	
	/**
	 * @param emailExistsMsgId the emailExistsMsgId to set
	 */
	public void setEmailErrorMsg(String emailErrorMsg) {
		this.emailErrorMsg = emailErrorMsg;
	}

	/**
	 * @return the emailExistsMsgId
	 */
	public String getEmailErrorMsg() {
		return emailErrorMsg;
	}

	public String getIdProofingErrorMsg() {
		return idProofingErrorMsg;
	}

	public void setIdProofingErrorMsg(String idProofingErrorMsg) {
		this.idProofingErrorMsg = idProofingErrorMsg;
	}

	public String getVerifyIDInvalidAccountMsg() {
		return verifyIDInvalidAccountMsg;
	}

	public void setVerifyIDInvalidAccountMsg(String verifyIDInvalidAccountMsg) {
		this.verifyIDInvalidAccountMsg = verifyIDInvalidAccountMsg;
	}

	public boolean isShowUpdateProfileLink() {
		return showUpdateProfileLink;
	}

	public void setShowUpdateProfileLink(boolean showUpdateProfileLink) {
		this.showUpdateProfileLink = showUpdateProfileLink;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}
	
	public AddressVO getAddressVO() {
		return addressVO;
	}

	public void setAddressVO(AddressVO addressVO) {
		this.addressVO = addressVO;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getSsnpart1() {
		return ssnpart1;
	}

	public void setSsnpart1(String ssnpart1) {
		this.ssnpart1 = ssnpart1;
	}

	public String getSsnpart2() {
		return ssnpart2;
	}

	public void setSsnpart2(String ssnpart2) {
		this.ssnpart2 = ssnpart2;
	}

	public String getSsnpart3() {
		return ssnpart3;
	}

	public void setSsnpart3(String ssnpart3) {
		this.ssnpart3 = ssnpart3;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	
	public boolean isAgree() {
		return agree;
	}

	public void setAgree(boolean agree) {
		this.agree = agree;
	}

	public void populateUserData() {
		
		try {
			String qualifyingTag = (String) getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG);
			boolean result = false;
			if (null != getCurrentUserVO()) {
				logger.debug("Checking the authorization for basic and loa3 page access for " + getCurrentUserVO().getUserName());
				if (null == qualifyingTag) {
					result = true;
				} else if (!qualifyingTag.equalsIgnoreCase(TrustBrokerWebAppConstants.BASIC_VALIDATION_IDPROOFING)
						&& !qualifyingTag.equalsIgnoreCase(TrustBrokerWebAppConstants.LOA3_VALIDATION_IDPROOFING)
						&& !qualifyingTag.equalsIgnoreCase(TrustBrokerWebAppConstants.BASIC_NQ_VALIDATION_IDPROOFING)
						&& !qualifyingTag.equalsIgnoreCase(TrustBrokerWebAppConstants.LOA3_NQ_VALIDATION_IDPROOFING))
					result = true;
				if (result) {
					removeSessionWithoutRelyingPartyInfo();
					getFacesContext().getExternalContext().redirect(
							getFacesContext().getExternalContext().getRequestContextPath() + "/views/unauthorized.jsf");
					return;
				}
			}
		} catch (IOException ioe) {
			logger.error("Authorization Check Error for basic and loa3 " + ioe);
		}

		addressVO = new AddressVO();
		userVO = getContainer().getUserService().fetchUserProfile(getCurrentUserVO().getUserName(), false, false).getUser();
		if(null!=userVO.getDob())
			setDateOfBirth(DateUtil.formatDate(userVO.getDob(), "MM/dd/yyyy"));
		boolean isAddressMatched = false;
		
		for (AddressVO address : userVO.getAddresses()) {
			if (TrustBrokerConstants.ADDRESS_TYPE.equalsIgnoreCase(address
					.getAddressType())) {
				BeanUtils.copyProperties(address, addressVO);
				isAddressMatched = true;
				break;
			}
		}
		if (!isAddressMatched) {
			if (userVO.getAddresses() != null
					&& userVO.getAddresses().size() > 0) {
				addressVO = userVO.getAddresses().get(0);
			}
		}
		
		if (checkUserDataForIDProofing(userVO)) {
			setIdProofingErrorMsg(getVerifyIDInvalidAccountMsg());
		}
	}
	
	public String verifyIdentityVerification() {
		userVO = getContainer().getUserService().fetchUserProfile(getCurrentUserVO().getUserName(),
				false, false).getUser();
		addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_UUID, getCurrentUserVO().getUuId());
		String qualifyingTag = (String) getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG);
		if (TrustBrokerWebAppConstants.LOA3_VALIDATION_IDPROOFING.equalsIgnoreCase(qualifyingTag) || 
				TrustBrokerWebAppConstants.LOA3_NQ_VALIDATION_IDPROOFING.equalsIgnoreCase(qualifyingTag))
			return "/secure/additionalverification.xhtml?faces-redirect=true";
		else {
			IDProofingQuizServiceRequest idProofingQuizServiceRequest = new IDProofingQuizServiceRequest();
			idProofingQuizServiceRequest.setUser(userVO);
			Properties configProps = getContainer().getConfigProps();
			if (TrustBrokerWebAppConstants.BASIC_VALIDATION_IDPROOFING.equalsIgnoreCase(qualifyingTag)) {
				idProofingQuizServiceRequest.setVerificationFlow(configProps.getProperty(TrustBrokerWebAppConstants.BASIC_IDP_VERIFN_FLOW_PARAM_KEY));
			} else  {
				idProofingQuizServiceRequest.setVerificationFlow(configProps.getProperty(TrustBrokerWebAppConstants.BASICNQ_IDP_VERIFN_FLOW_PARAM_KEY));
			}
			
			return generateQuizForUser(idProofingQuizServiceRequest);
		}
	}

	public String verifyAdditionalLOA3Information() {
		if(!validateCreditCard(creditCardNumber) || !validateSSN(ssnpart1, ssnpart2, ssnpart3) || !validateAgreeCheckbox(isAgree())) {
			return null;
		}
		Properties configProps = getContainer().getConfigProps();
		String qualifyingTag = (String) getSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG);
		IDProofingQuizServiceRequest idProofingQuizServiceRequest = new IDProofingQuizServiceRequest();
		UserVO userVO = getContainer().getUserService().fetchUserProfile(getCurrentUserVO().getUserName(),false, false).getUser();
		addSessionAttribute(TrustBrokerWebAppConstants.SELF_SERVICE_UUID, getCurrentUserVO().getUuId());
		idProofingQuizServiceRequest.setUser(userVO);
		idProofingQuizServiceRequest.setCreditCardNumber(getCreditCardNumber());
		idProofingQuizServiceRequest.setSsn(getSsnpart1() + getSsnpart2() + getSsnpart3());
		if (TrustBrokerWebAppConstants.LOA3_VALIDATION_IDPROOFING.equalsIgnoreCase(qualifyingTag)) {
			idProofingQuizServiceRequest.setVerificationFlow(configProps.getProperty(TrustBrokerWebAppConstants.LOA3_IDP_VERIFN_FLOW_PARAM_KEY));
		} else  {
			idProofingQuizServiceRequest.setVerificationFlow(configProps.getProperty(TrustBrokerWebAppConstants.LOA3NQ_IDP_VERIFN_FLOW_PARAM_KEY));
		}
		String redirectionURL = generateQuizForUser(idProofingQuizServiceRequest);
		if(null!=redirectionURL)
			return redirectionURL;
		else
			return "/secure/idverification.xhtml?faces-redirect=true";
	}
	
	/**
	 * This method is to get the Id proofing audit event type based on verification flow and success/failure flag
	 * 
	 * @param verificationFlow
	 * @param success
	 * @return IDProofingAuditTypes
	 */
	private IDProofingAuditTypes getIDProofingAuditType(String verificationFlow, boolean success) {
		
		IDProofingAuditTypes idProofAuditTyp = null;
		Properties configProps = getContainer().getConfigProps();		
		if(configProps.getProperty(TrustBrokerWebAppConstants.BASIC_IDP_VERIFN_FLOW_PARAM_KEY).equals(verificationFlow)) {
			if(success) {
				idProofAuditTyp = IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_SUCCESS;
			} else {
				idProofAuditTyp = IDProofingAuditTypes.SVC_IDP_BASIC_LOCATE_FAIL;
			}			
		} else if(configProps.getProperty(TrustBrokerWebAppConstants.BASICNQ_IDP_VERIFN_FLOW_PARAM_KEY).equals(verificationFlow)) {
			if(success) {
				idProofAuditTyp = IDProofingAuditTypes.SVC_IDP_BASICNQ_LOCATE_SUCCESS;
			} else {
				idProofAuditTyp = IDProofingAuditTypes.SVC_IDP_BASICNQ_LOCATE_FAIL;
			}			
		} else if(configProps.getProperty(TrustBrokerWebAppConstants.LOA3_IDP_VERIFN_FLOW_PARAM_KEY).equals(verificationFlow)) {
			if(success) {
				idProofAuditTyp = IDProofingAuditTypes.SVC_IDP_LOA3_LOCATE_SUCCESS;
			} else {
				idProofAuditTyp = IDProofingAuditTypes.SVC_IDP_LOA3_LOCATE_FAIL;
			}			
		} else if(configProps.getProperty(TrustBrokerWebAppConstants.LOA3NQ_IDP_VERIFN_FLOW_PARAM_KEY).equals(verificationFlow)) {
			if(success) {
				idProofAuditTyp = IDProofingAuditTypes.SVC_IDP_LOA3NQ_LOCATE_SUCCESS;
			} else {
				idProofAuditTyp = IDProofingAuditTypes.SVC_IDP_LOA3NQ_LOCATE_FAIL;
			}			
		}		
		return idProofAuditTyp;
	}

}
