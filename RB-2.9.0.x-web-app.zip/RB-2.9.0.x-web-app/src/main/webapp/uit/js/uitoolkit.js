function selectCheckBoxFocusFix(formId) {
	selectManyElem = document.getElementById(formId + ":selectedPermissions");
	var selectManyLabelArray = selectManyElem.getElementsByTagName('label');
	var newLabel;
	var labeltext;
	var elem;
	for ( var i = 0; i < selectManyLabelArray.length; i++) {
		newLabel = document.createElement("label");
		labeltext = document.createTextNode(selectManyLabelArray[i].innerHTML);
		newLabel.setAttribute("for", formId + ":selectedPermissions:" + i);
		newLabel.setAttribute("onclick", "alert('blabla');");
		newLabel.onclick = function() {
			elem = document.getElementById(this.getAttribute("for"));
			elem.checked = !elem.checked;
		}
		newLabel.appendChild(labeltext);
		elem = selectManyLabelArray[i].parentElement;
		elem.removeChild(selectManyLabelArray[i]);
		elem.appendChild(newLabel);
	}
}

function clearUserFormFields(formId) {
	var form = document.getElementById(formId);
	form[formId + ":firstname"].value = "";
	form[formId + ":lastname"].value = "";
	form[formId + ":email"].value = "";
	form[formId + ":username"].value = "";
	var rolesAvailable = form[formId + ":selectedRoles"];
	if (typeof rolesAvailable != "undefined") {
		var rolesAvailableLength = rolesAvailable.length;
		var isAnyRoleSelected = false;
		for ( var i = 0; i < rolesAvailableLength; i++) {
			if (rolesAvailable[i].checked) {
				rolesAvailable[i].checked = false;
			}
		}
	}
}

function trimAddUserFormFields(formId) {
	String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g, "");
	};
	var form = document.forms[formId];
	form[formId + ":firstname"].value = form[formId + ":firstname"].value
			.trim();
	form[formId + ":lastname"].value = form[formId + ":lastname"].value.trim();
	form[formId + ":username"].value = form[formId + ":username"].value.trim();
	form[formId + ":email"].value = form[formId + ":email"].value.trim();
}

function onAddUserCancel(formId, emptyRoles) {
	trimAddUserFormFields(formId);
	String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g, "");
	};
	var form = document.forms[formId];
	var firname = form[formId + ":firstname"].value;
	var lasname = form[formId + ":lastname"].value;
	var emailid = form[formId + ":email"].value;
	var usrname = form[formId + ":username"].value;

	if ((firname.trim().length == 0) && (lasname.trim().length == 0)
			&& (emailid.trim().length == 0) && (usrname.trim().length == 0)
			&& (emptyRoles == true)) {
		window.location.reload(true);
		return false;
	} else {
		return true;
	}
}

function onAddRoleCancel(formId) {
	String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g, "");
	};
	var form = document.forms[formId];
	var roleName = form[formId + ":rolename"].value;
	var roleDesc = form[formId + ":roleDesc"].value;
	var permissionsAvailable = form[formId + ":selectedPermissions"];
	var isAnyPermissionSelected = false;
	if (typeof permissionsAvailable != "undefined") {
		var permissionsAvailableLength = permissionsAvailable.length;
		for ( var i = 0; i < permissionsAvailableLength; i++) {
			if (permissionsAvailable[i].checked)
				isAnyPermissionSelected = true;
		}
	}
	if ((roleName.trim().length == 0) && (roleDesc.trim().length == 0)
			&& !isAnyPermissionSelected) {
		window.location.reload(true);
		return false;
	} else {
		return true;
	}
}

function centerUserInfo(popupHeight) {
	var iebody = (document.compatMode && document.compatMode != "BackCompat") ? document.documentElement
			: document.body;
	var dsoctop = document.all ? iebody.scrollTop : pageYOffset;
	var windowHeight = 0;
	if (self.innerHeight) {
		windowHeight = self.innerHeight;// all except explorer
	} else if (document.documentElement
			&& document.documentElement.clientHeight) {
		windowHeight = document.documentElement.clientHeight; // explorer 6
		// strict mode
	} else if (document.body) {
		windowHeight = document.body.clientHeight;// other explorers
	}
	position = dsoctop + windowHeight / 2 - popupHeight / 2;
	bodyPosition = document.body.offsetHeight - popupHeight;

	if ((position > 26) && (position < bodyPosition))
		return position;
	else if (bodyPosition / 2 > 26)
		return bodyPosition / 2;
	else
		return 26;
}

function addTitleForCalendar(formId, calendarId, title) {
	var elem1, elem2;
	if ((formId != null) && (formId != "")) {
		elem1 = document.getElementById(formId + ":" + calendarId
				+ "PopupButton");
		elem2 = document
				.getElementById(formId + ":" + calendarId + "InputDate");
	} else {
		elem1 = document.getElementById(calendarId + "PopupButton");
		elem2 = document.getElementById(calendarId + "InputDate");
	}
	
	if(elem1 != null){
		elem1.title = title;
		elem1.alt = title;
	}
	
    if(elem2 != null){
    	elem2.title = title;
    	elem2.alt = title;
    }
}

function removeClassFromElement(formId, elementId, removedClass) {
	var elem = document.getElementById(formId + ':' + elementId);
	elem.className = elem.className.replace(removedClass, '');
}

function ifUsingIE() {
	return '\v' == 'v';// a bit tricky, but the fastest way to check if you use
	// IE as your browser
}

function showSource() {
	// shows "Source Code" section on reusable components page
	source = document.getElementById('sourcePanel');
	source.style.display = "inline";
	hideBtn = document.getElementById('hideSourceBtn');
	hideBtn.style.display = "inline";
	showBtn = document.getElementById('showSourceBtn');
	showBtn.style.display = "none";
}

function hideSource() {
	// hides "Source Code" section on reusable components page
	source = document.getElementById('sourcePanel');
	source.style.display = "none";
	showBtn = document.getElementById('showSourceBtn');
	showBtn.style.display = "inline";
	hideBtn = document.getElementById('hideSourceBtn');
	hideBtn.style.display = "none";
}

function showSource2(sourcePanelClass,hideBtnClass,showBtnClass) {
	// shows "Source Code" section on reusable components page
	$('.'+sourcePanelClass).removeClass('ux-util-hidden').addClass('ux-util-visible');
	$('.'+hideBtnClass).removeClass('ux-util-hidden').addClass('ux-util-visible');
	$('.'+showBtnClass).removeClass('ux-util-visible').addClass('ux-util-hidden');
}

function hideSource2(sourcePanelClass,hideBtnClass,showBtnClass) {
	// hides "Source Code" section on reusable components page
	$('.'+sourcePanelClass).addClass('ux-util-hidden').removeClass('ux-util-visible');
	$('.'+hideBtnClass).addClass('ux-util-hidden').removeClass('ux-util-visible');
	$('.'+showBtnClass).addClass('ux-util-visible').removeClass('ux-util-hidden');
}

function showBeanSource() {
	// shows "Source Code" section on reusable components page
	source = document.getElementById('beanSourcePanel');
	source.style.display = "inline";
	hideBtn = document.getElementById('hideBeanSourceBtn');
	hideBtn.style.display = "inline";
	showBtn = document.getElementById('showBeanSourceBtn');
	showBtn.style.display = "none";
}

function hideBeanSource() {
	// hides "Source Code" section on reusable components page
	source = document.getElementById('beanSourcePanel');
	source.style.display = "none";
	showBtn = document.getElementById('showBeanSourceBtn');
	showBtn.style.display = "inline";
	hideBtn = document.getElementById('hideBeanSourceBtn');
	hideBtn.style.display = "none";
}

function addTabButtonBehaviourForPopups() {
	// Add right "Tab" button behavior for popups to switch between input fields
	
}

function addAlternatingColors() {
	// Adds alternating colors in Add/Edit role popups on MAnage Roles page
	$(function() {
		$('table.color1 tr:even').addClass('ux-tabl-alt-row');
		$('table.color1 tr:odd').addClass('tableOddRow');
		$('table.color2 tr:even').addClass('ux-tabl-alt-row');
		$('table.color2 tr:odd').addClass('tableOddRow');
	});
}

function wrapLongWordsInTable(formId, tableId) {
	// wrap words in tables (e.g. Data tables) by adding in long words unseen
	// symbols of wrapping
	// To use this method you need to add 'ux-tabl-wide-col' style class to
	// column that you want to wrap
	var gridRef;
	if ((tableId == null) || (tableId == "")) {
		tableId = 'paginationTable';
	}

	if ((formId != null) && (formId != "")) {
		gridRef = document.getElementById(formId + ":" + tableId);
	} else {
		gridRef = document.getElementById(tableId);
	}

	var tdTagArray = gridRef.getElementsByTagName('td');

	for ( var i = 0; i < tdTagArray.length; i++) {
		if (tdTagArray[i].className.indexOf('ux-tabl-wide-col') != -1) {
			if (tdTagArray[i].childNodes[0] == undefined) {
				var tdText = tdTagArray[i].innerHTML;
				tdTagArray[i].innerHTML = tdText.replace(
						/([^\s-]{5})(?=[^\s-])/g, '$1&#173;');
			} else if (tdTagArray[i].childNodes[0].id == undefined) {
				var tdText = tdTagArray[i].innerHTML;
				tdTagArray[i].innerHTML = tdText.replace(
						/([^\s-]{5})(?=[^\s-])/g, '$1&#173;');
			}
		}
	}
}

function focusFirstInput(containerId) {
	// set focus on first input element on popup or lightbox component.
	var firstInputToFocusOn = $('#' + containerId + '_content').find(
			":input:visible:enabled:first");
	if (firstInputToFocusOn.length != 0) {
		firstInputToFocusOn[0].focus();
		if (firstInputToFocusOn[0].type == 'text') {
			firstInputToFocusOn[0].select();
		}
	}
}

function redirectColumnSortingToRichfacesControl(columnId){
	 var columnSortControl = $('.rf-edt-srt[data-columnid='+columnId+']');
	 columnSortControl.click();
}

function selectExpandebleRow(element){
	var table = $(element).closest('.ui-datatable');
	var row = $(element).closest('.ui-widget-content');
	var elems = table.find('.ui-state-highlight');
	elems.removeClass('ui-state-highlight');
	elems.removeClass('ui-state-hover');
	row.addClass('ui-state-highlight');
}

function removeRichFacesSortBehaviour(){
	//remove RichFaces sort event on header click in ExtendedDatatable. 
	//needed to provide filters in header, without this function input field will sort column
	// not filter it
	$('.rf-edt-c-srt').live('click',function(e){
		e.stopPropagation();
		$('.rf-edt-c-srt').unbind();
	});
	$('.rf-edt-c-srt').live('mousedown',function(e){
		e.stopPropagation();
		$('.rf-edt-c-srt').unbind();
	});	
}

function changeHightlightForExpandebleRows(){
	var expadeRow = {
			ready : function() {
				$('.ui-row-toggler.ui-icon.ui-icon-circle-triangle-e')
						.live('click', function() {
							selectExpandebleRow(this);
						});
			}
		};

	$(document).ready(expadeRow.ready);
}

function addTitlesForEditIcons(){
	var addTitles = {
			ready : function() {
				$('.ui-row-editor .ui-icon.ui-icon-pencil').live('mouseover',function(e){
					$(e.currentTarget).attr('title', 'Edit');
				});		
				$('.ui-row-editor .ui-icon.ui-icon-check').live('mouseover',function(e){
					$(e.currentTarget).attr('title', 'Save');
				});	
				$('.ui-row-editor .ui-icon.ui-icon-close').live('mouseover',function(e){
					$(e.currentTarget).attr('title', 'Cancel');
				});					
			}
		};
	$(document).ready(addTitles.ready);	
}
function removeRearrange(columnCss){
		$(columnCss).live('mouseover', function(e) {
			$(e.currentTarget).unbind();
		});

}

function enableOneClickOnlyButtons(){
//Enables button that has been disabled with oneClickOnly() script from ux.js
	$(".ux-js-one-click-only").prop("disabled", false);
}

function richDataTableRowSelect(data){ 
	$(data.parentElement).find('.rf-dt-r').removeClass('rf-dt-r-select');
	$(data).addClass('rf-dt-r-select');
}

function richExtDataTableRowUnSelect(data){
	$((((data.parentElement).parentElement).parentElement).parentElement).removeClass('rf-dt-r-select');
}
function richExtDataTableRowSelect(data){
	$((((data.parentElement).parentElement).parentElement).parentElement).addClass('rf-dt-r-select');
}

function fixSafariScrollableTable(){
	//fix safari scrollable table columns alignment
	var is_chrome = navigator.userAgent.indexOf('Chrome') > -1;
	var is_safari = navigator.userAgent.indexOf('Safari') > -1;
	if ((is_safari == true)&&(is_chrome == false)){
		$('.ui-datatable-scrollable-header-box th').each(function(i,e){
			var col = $('.ui-datatable-scrollable-body table colgroup col')[i];
			$(e).css('width',$(col).css('width'));
		});
	}
}

function fixLightBoxVisibilityToDisplay(lightboxId){
	var elem = $('#'+lightboxId);
	if (elem.length !=0) {
		elem.css('display','none');
	}
}

/*Overriding the Primefaces javascript function clearSelection to solve IE javascript error when clicked on sortable datatable column. 
 * Need to update this method each time we upgrade primefaces jar 
 * added exception to continue the javascript executioin*/
(function(a){
	if(typeof PrimeFaces != 'undefined'){
		PrimeFaces.clearSelection = function() {
			if (a.getSelection) {
				if (a.getSelection().empty) {
					a.getSelection().empty();
				} else {
					if (a.getSelection().removeAllRanges) {
						a.getSelection().removeAllRanges();
					}
				}
			} else {
				if (typeof document.selection != 'undefined' &&  document.selection && document.selection.empty) {
					try{
						document.selection.empty();
					}catch(err){
						//ignore error and continue the javascript execution
					}
				}
			}
		};
	}
})(window);
