'use strict';

angular.module('indexApp').controller('LoginCtrl', [
    '$scope',
    '$rootScope',
    '$translate',
    '$state',
    '$timeout',
    '$window',
    'initData',
    'LanguageService',
    'LoginService',
    'trustbrokerAriaService',
    'forgotAccessService',
    'HelpObj',
    LoginController
]);

function LoginController($scope, $rootScope, $translate, $state, $timeout, $window, initData, LanguageService, LoginService, trustbrokerAriaService, forgotAccessService, HelpObj) {
    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1001_Sign_In.htm' });

    $scope.errorMessageModel = {
        animationTime: 1,
        content: '',
        headingLevel: '2',
        id: 'errorMessage',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    $scope.genericErrorMessageModel = {
        animationTime: 1,
        content: '<span translate="genericFormError"></span>',
        headingLevel: '2',
        id: 'genericErrorMessage',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    $scope.successMessageModel = {
        animationTime: 1,
        autoFadeOut: false,
        content: '',
        headingLevel: '2',
        id: 'Success',
        messageRole: 'alert',
        messageType: 'success',
        position: 'inline',
        visible: false
    };

    if (initData.data.successMessage) {
        $scope.successMessageModel.visible = true;

        if (initData.data.resendInfo) {
            $scope.resendInfo = initData.data.resendInfo;
            forgotAccessService.scopeRef = $scope;
            var linkStr = "";
            var newMsgStr = "";

            if (initData.data.resendType === "txt") {
                linkStr = '<a href="" onclick="handleResendInfo();">' + '<span translate="RESEND_TXT"></span>' + '</a>';
                newMsgStr = '<span translate="ResendUserNameSuccessViaPhone"></span>';
            } else {
                linkStr = '<a href="" onclick="handleResendInfo();">' + '<span translate="RESEND_MAIL"></span>' + '</a>';
                newMsgStr = '<span translate="ResendUserNameSuccessViaEmail"></span>';
            }

            $scope.linkStr = linkStr;
            $scope.newMsgStr = newMsgStr;
            $scope.successMessageModel.content = '<span>' + initData.data.successMessage + linkStr + '</span>';
        } else {
            $scope.successMessageModel.content = '<span>' + initData.data.successMessage + '</span>';
        }
    }

    LanguageService.doTranslate('login');

    if (initData.data.errorMessage) {
        $scope.errorMessageModel.content = '<span>' + initData.data.errorMessage + '</span>';
        $scope.errorMessageModel.visible = true;
    }

    $scope.showRegistrationLink = initData.data.showRegistrationLink;
    $scope.userNameValue = "";

    if (initData.data.userName) {
        $scope.userNameValue = initData.data.userName;
    }

    $scope.pageAnalytics = function() {
        if ($scope.isManageYourOptumId) {
            pageDataLayer.content.pageName = "manageyouroptumID";
            pageDataLayer.content.siteSectionL1 = "signin";
        } else {
            pageDataLayer.content.pageName = "login";
            pageDataLayer.content.siteSectionL1 = "";
        }

        if (typeof _satellite !== "undefined") {
            _satellite.track('trackPageView');
        }
    };

    $scope.loginSpecificErrorAnalytics = function() {
        if ($scope.errorMessageModel.visible) {
            var errorType = "invalid credentials";

            if ($scope.errorMessageModel.content.indexOf($translate.instant('duplicateAnalytics')) !== -1) {
                errorType = "duplicate accounts";
            }

            if ($scope.errorMessageModel.content.indexOf($translate.instant('sessionAnalytics')) !== -1) {
                errorType = "account timed out";
            }

            pageDataLayer.content.siteErrorFields = "";
            pageDataLayer.content.siteErrorType = errorType;

            if (typeof _satellite !== "undefined") {
                _satellite.track('errorTracking');
            }
        }
    };

    $scope.signInForm = [];
    $scope.signInForm.userName = [];
    $scope.signInForm.userName.$error = [];
    $scope.signInForm.userPwd = [];
    $scope.signInForm.userPwd.$error = [];

    var string = LoginService.getUrlParams();
    var substring = "manageOid";

    if (string.indexOf(substring) > -1) {
        $scope.isManageYourOptumId = true;
        $scope.pageAnalytics();
    } else {
        $scope.isManageYourOptumId = false;
        $scope.pageAnalytics();
    }

    $scope.loginSpecificErrorAnalytics();

    $scope.goToManageYourOptumID = function($event) {
        $event.preventDefault();
        HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1002_Sign_In_to_Manage_Your_Optum_ID.htm' });
        $scope.isManageYourOptumId = true;
        $scope.pageAnalytics();
        $scope.$emit('$viewContentLoaded');
    };

    $scope.goToSignIn = function() {
        $scope.isManageYourOptumId = false;
        $scope.pageAnalytics();
        HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1001_Sign_In.htm' });
        $scope.$emit('$viewContentLoaded');
    };


    $scope.goToForgotOptumID = function() {
        $state.go("forgotOptumID");
    };
    $scope.goToForgotPwd = function() {
        $state.go("forgotpwd");
    };
    $scope.goToCreateOptumID = function($event) {
        $event.preventDefault();
        $state.go("registration");
    };

    $scope.setFieldValidity = function(inputid, spanid) {
        trustbrokerAriaService.setFieldValidity(inputid, spanid);
    };

    // function when sign in button is clicked
    $scope.login = function() {
        $scope.successMessageModel.visible = false;
        $scope.genericErrorMessageModel.visible = false;

        if ($scope.userName === '' || $scope.userName === undefined) {
            $scope.signInForm.submitted = true;
            $scope.signInForm.userName.$invalid = true;
            $scope.signInForm.userName.$error.required = true;
        }

        if ($scope.userPwd === '' || $scope.userPwd === undefined) {
            $scope.signInForm.submitted = true;
            $scope.signInForm.userPwd.$invalid = true;
            $scope.signInForm.userPwd.$error.required = true;
        }

        if ($scope.signInForm.$invalid) {
            var FIELDS = [{
                fld: "userNameId_input",
                msg: "userNameId_err"
            }, {
                fld: "passwdId_input",
                msg: "passwdId_err"
            }];

            $scope.errorMessageModel.visible = false;
            $scope.genericErrorMessageModel.visible = true;
            $rootScope.fireErrorTracker = true;

            // Form Level error
            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);

            return;
        }

        var email = { email: $scope.userName };
        var userNameResponse = [];
        LoginService.checkEmail(email).then(function(response) {
            userNameResponse = response;

            if (userNameResponse.data.errorMsg) {
                $scope.errorMessageModel.content = '<span>' + userNameResponse.data.errorMsg + '</span>';
                $scope.errorMessageModel.visible = true;
                angular.element(document.getElementById('userNameId_input')).focus();
                $scope.loginSpecificErrorAnalytics();
            } else {
                var user, targetUrl;
                user = userNameResponse.data.username;

                if (initData.data.relyingAppId !== null && initData.data.relyingAppId !== undefined) {
                    targetUrl = '/tb/app/secure/home.do?relyingAppAlias=' + initData.data.relyingAppAlias;
                } else {
                    targetUrl = '/tb/app/secure/home.do?relyingAppAlias=tsa';
                }

                if ($scope.isManageYourOptumId) {
                    targetUrl = targetUrl + '&manageOid=true';
                }

                $("#target").attr('value', targetUrl);
                $("#USER").attr('value', user);
                $("#PASSWORD").attr('value', $scope.userPwd);
                $("#signInForm").attr('action', '/siteminderagent/forms/login.fcc');

                // This is for local login
                if (initData.data.localEnv) {
                    var postData = { username: user };

                    LoginService.localLogin(postData).then(function(r) {
                        if (r.data.errorMsg) {
                            $scope.errorMessageModel.content = '<span>' + r.data.errorMsg + '</span>';
                            $scope.errorMessageModel.visible = true;
                            angular.element(document.getElementById('userNameId_input')).focus();
                        } else {
                            $window.location = '/tb/app/secure/home.do?USERNAME=' + user;
                        }
                    });
                } else {
                    LoginService.submitForm();
                }
            }
        });
    };
}
