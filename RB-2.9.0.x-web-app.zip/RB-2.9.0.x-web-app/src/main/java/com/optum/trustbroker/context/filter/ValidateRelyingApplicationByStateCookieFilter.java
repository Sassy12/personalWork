package com.optum.trustbroker.context.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;

/**
 * A filter that validates the relying party application domain.
 *
 * @author Sachin Kumar
 * @version 1.0
 */
public class ValidateRelyingApplicationByStateCookieFilter implements Filter {

    private static final BaseLogger LOGGER = new BaseLogger(ValidateRelyingApplicationByStateCookieFilter.class);

    public static final String OID_COOKIE = "oid_data";

    public static final String X_FRAME_OPTIONS = "X-FRAME-OPTIONS";

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        //No initialization required
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        try {
            HttpServletResponse res = (HttpServletResponse) response;

            Map<String, String> sessionAttributes = WebApplicationContextHolder.getContext().getSessionAttributes();

            String rpAppId = sessionAttributes.get(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
            String target = sessionAttributes.get(TrustBrokerWebAppConstants.TARGET);

            if (StringUtils.isNotBlank(target) && StringUtils.isNotBlank(rpAppId)) {
                res.addHeader(X_FRAME_OPTIONS, "ALLOW-FROM " + TBUtil.getURIWithPort(target));
            } else {
                res.addHeader(X_FRAME_OPTIONS, "SAMEORIGIN");
            }

            chain.doFilter(request, response);
        } catch (Exception ex) {
            LOGGER.error(
                    "Validate Relying Appliction filter | Error while applying filter chaining and setting X-FRAME-OPTIONS",
                    ex);
        }
    }

    @Override
    public void destroy() {

    }

}
