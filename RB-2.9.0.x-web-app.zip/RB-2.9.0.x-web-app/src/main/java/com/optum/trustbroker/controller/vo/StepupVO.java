package com.optum.trustbroker.controller.vo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class StepupVO {
	
	public StepupVO(){
		
	}
	
	private UserInfoVO userInfoVO;
	private StepupContextVO stepupContext;
	public UserInfoVO getUserInfoVO() {
		return userInfoVO;
	}
	public void setUserInfoVO(UserInfoVO userInfoVO) {
		this.userInfoVO = userInfoVO;
	}
	public StepupContextVO getStepupContext() {
		return stepupContext;
	}
	public void setStepupContext(StepupContextVO stepupContext) {
		this.stepupContext = stepupContext;
	}
	
	
}
