/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 * 
 ***********************************************
 * Modification History
 * When          Who         Why
 * Jan 26, 2016  bmanna3        Initial version
 ****************************************************************/

package com.optum.trustbroker.controller.vo;

import java.util.HashMap;
import java.util.Map;

/**
 * This VO is to store forgot user access credentials flow response information.
 * 
 * @author bmanna3
 */
public class ForgotAccessResponseVO extends ResponseVO {

        private String email;
        
        private String userName;
        
        private boolean uniqueEmail;
        
        private boolean status;
        
        private boolean invalidRecoveryOptns;
        
        private Map<String, String> messages = new HashMap<String, String>();

        private boolean primaryEmailVerified;
        
        private boolean secondaryEmailVerified;
        
        private boolean phoneVerified;
        
        private boolean secQuestionAvailable;
        
        private String primaryEmail;
        
        private String secEmail;
        
        private String phone;
        
        private String primaryEmailMask;
        
        private String secEmailMask;
        
        private String phoneMask;
        
        private String secQuestion1;
        
        private String secQuestion2;
        
        private String secQuestion3;
        
        private boolean primaryEmailAndSecEmailVerified;
        
        private String relyingAppAlias;
        
        private String relyingAppId;
        
        private String target;
        
        private String accountLockedStatus;
        
        private boolean skipAccountRecovery;
        
        private String successMessageKey;
        
        private String requestType;
        
        private String  recoveryType;
        
        private String secAnswer3;
       
		/**
         * Default constructor.
         */
        public ForgotAccessResponseVO() {
            super();
        }
        
        /**
         * This method returns the email.
         * 
         * @return the email
         */
        public String getEmail() {
                return email;
        }

        /**
         * This method sets the given email value to email.
         * 
         * @param email
         *            the email to set
         */
        public void setEmail(String email) {
                this.email = email;
        }

        /**
         * This method returns the userId.
         * 
         * @return the userId
         */
        public String getUserName() {
                return userName;
        }

        /**
         * This method sets the given userId value to userId.
         * 
         * @param userId
         *            the userId to set
         */
        public void setUserName(String userName) {
                this.userName = userName;
        }

        /**
         * This method returns the uniqueEmail.
         * 
         * @return the uniqueEmail
         */
        public boolean isUniqueEmail() {
                return uniqueEmail;
        }

        /**
         * This method sets the given uniqueEmail value to uniqueEmail.
         * 
         * @param uniqueEmail
         *            the uniqueEmail to set
         */
        public void setUniqueEmail(boolean uniqueEmail) {
                this.uniqueEmail = uniqueEmail;
        }

        /**
         * This method returns the status.
         * 
         * @return the status
         */
        public boolean isStatus() {
                return status;
        }

        /**
         * This method sets the given status value to status.
         * 
         * @param status
         *            the status to set
         */
        public void setStatus(boolean status) {
                this.status = status;
        }

        /**
         * This method returns the messages.
         * 
         * @return the messages
         */
        public Map<String, String> getMessages() {
                return messages;
        }

        /**
         * This method sets the given messages value to messages.
         * 
         * @param messages
         *            the messages to set
         */
        public void setMessages(Map<String, String> messages) {
                this.messages = messages;
        }

        /**
         * This method sets the given messages value to messages.
         * 
         * @param key
         *            message key
         * @param message
         *            the message to set
         */
        public void addMessage(String key, String message) {
                getMessages().put(key, message);
        }

        /**
         * This method returns the invalidRecoveryOptns.
         * 
         * @return the invalidRecoveryOptns
         */
        public boolean isInvalidRecoveryOptns() {
                return invalidRecoveryOptns;
        }

        /**
         * This method sets the given invalidRecoveryOptns value to
         * invalidRecoveryOptns.
         * 
         * @param invalidRecoveryOptns
         *            the invalidRecoveryOptns to set
         */
        public void setInvalidRecoveryOptns(boolean invalidRecoveryOptns) {
                this.invalidRecoveryOptns = invalidRecoveryOptns;
        }

		/**
		 * This method returns the primaryEmailVerified.
		 * 
		 * @return the primaryEmailVerified
		 */
		public boolean isPrimaryEmailVerified() {
			return primaryEmailVerified;
		}

		/**
		 *  This method sets the given primaryEmailVerified value to
         *  primaryEmailVerified.
         * 
		 * @param primaryEmailVerified the primaryEmailVerified to set
		 */
		public void setPrimaryEmailVerified(boolean primaryEmailVerified) {
			this.primaryEmailVerified = primaryEmailVerified;
		}

		/**
		 * This method returns the secondaryEmailVerified.
		 * 
		 * @return the secondaryEmailVerified
		 */
		public boolean isSecondaryEmailVerified() {
			return secondaryEmailVerified;
		}

		/**
		 * @param secondaryEmailVerified the secondaryEmailVerified to set
		 */
		public void setSecondaryEmailVerified(boolean secondaryEmailVerified) {
			this.secondaryEmailVerified = secondaryEmailVerified;
		}

		/**
		 * This method returns the phoneVerified.
		 *  
		 * @return the phoneVerified
		 */
		public boolean isPhoneVerified() {
			return phoneVerified;
		}

		/**
		 * @param phoneVerified the phoneVerified to set
		 */
		public void setPhoneVerified(boolean phoneVerified) {
			this.phoneVerified = phoneVerified;
		}

		/**
		 * @return the secQuestionAvailable
		 */
		public boolean isSecQuestionAvailable() {
			return secQuestionAvailable;
		}

		/**
		 * @param secQuestionAvailable the secQuestionAvailable to set
		 */
		public void setSecQuestionAvailable(boolean secQuestionAvailable) {
			this.secQuestionAvailable = secQuestionAvailable;
		}

		/**
		 * @return the primaryEmail
		 */
		public String getPrimaryEmail() {
			return primaryEmail;
		}

		/**
		 * @param primaryEmail the primaryEmail to set
		 */
		public void setPrimaryEmail(String primaryEmail) {
			this.primaryEmail = primaryEmail;
		}

		/**
		 * @return the secEmail
		 */
		public String getSecEmail() {
			return secEmail;
		}

		/**
		 * @param secEmail the secEmail to set
		 */
		public void setSecEmail(String secEmail) {
			this.secEmail = secEmail;
		}

		/**
		 * @return the phone
		 */
		public String getPhone() {
			return phone;
		}

		/**
		 * @param phone the phone to set
		 */
		public void setPhone(String phone) {
			this.phone = phone;
		}

		/**
		 * @return the primaryEmailMask
		 */
		public String getPrimaryEmailMask() {
			return primaryEmailMask;
		}

		/**
		 * @param primaryEmailMask the primaryEmailMask to set
		 */
		public void setPrimaryEmailMask(String primaryEmailMask) {
			this.primaryEmailMask = primaryEmailMask;
		}

		/**
		 * @return the secEmailMask
		 */
		public String getSecEmailMask() {
			return secEmailMask;
		}

		/**
		 * @param secEmailMask the secEmailMask to set
		 */
		public void setSecEmailMask(String secEmailMask) {
			this.secEmailMask = secEmailMask;
		}

		/**
		 * @return the phoneMask
		 */
		public String getPhoneMask() {
			return phoneMask;
		}

		/**
		 * @param phoneMask the phoneMask to set
		 */
		public void setPhoneMask(String phoneMask) {
			this.phoneMask = phoneMask;
		}

		/**
		 * @return the secQuestion1
		 */
		public String getSecQuestion1() {
			return secQuestion1;
		}

		/**
		 * @param secQuestion1 the secQuestion1 to set
		 */
		public void setSecQuestion1(String secQuestion1) {
			this.secQuestion1 = secQuestion1;
		}

		/**
		 * @return the secQuestion2
		 */
		public String getSecQuestion2() {
			return secQuestion2;
		}

		/**
		 * @param secQuestion2 the secQuestion2 to set
		 */
		public void setSecQuestion2(String secQuestion2) {
			this.secQuestion2 = secQuestion2;
		}

		/**
		 * @return the secQuestion3
		 */
		public String getSecQuestion3() {
			return secQuestion3;
		}

		/**
		 * @param secQuestion3 the secQuestion3 to set
		 */
		public void setSecQuestion3(String secQuestion3) {
			this.secQuestion3 = secQuestion3;
		}

		/**
		 * @return the primaryEmailAndSecEmailVerified
		 */
		public boolean isPrimaryEmailAndSecEmailVerified() {
			return primaryEmailAndSecEmailVerified;
		}

		/**
		 * @param primaryEmailAndSecEmailVerified the primaryEmailAndSecEmailVerified to set
		 */
		public void setPrimaryEmailAndSecEmailVerified(
				boolean primaryEmailAndSecEmailVerified) {
			this.primaryEmailAndSecEmailVerified = primaryEmailAndSecEmailVerified;
		}

		/**
		 * @return the relyingAppAlias
		 */
		public String getRelyingAppAlias() {
			return relyingAppAlias;
		}

		/**
		 * @param relyingAppAlias the relyingAppAlias to set
		 */
		public void setRelyingAppAlias(String relyingAppAlias) {
			this.relyingAppAlias = relyingAppAlias;
		}

		/**
		 * @return the relyingAppId
		 */
		public String getRelyingAppId() {
			return relyingAppId;
		}

		/**
		 * @param relyingAppId the relyingAppId to set
		 */
		public void setRelyingAppId(String relyingAppId) {
			this.relyingAppId = relyingAppId;
		}

		/**
		 * @return the target
		 */
		public String getTarget() {
			return target;
		}

		/**
		 * @param target the target to set
		 */
		public void setTarget(String target) {
			this.target = target;
		}

		/**
		 * @return the accountLockedStatus
		 */
		public String getAccountLockedStatus() {
			return accountLockedStatus;
		}

		/**
		 * @param accountLockedStatus the accountLockedStatus to set
		 */
		public void setAccountLockedStatus(String accountLockedStatus) {
			this.accountLockedStatus = accountLockedStatus;
		}

		/**
		 * @return the skipAccountRecovery
		 */
		public boolean isSkipAccountRecovery() {
			return skipAccountRecovery;
		}

		/**
		 * @param skipAccountRecovery the skipAccountRecovery to set
		 */
		public void setSkipAccountRecovery(boolean skipAccountRecovery) {
			this.skipAccountRecovery = skipAccountRecovery;
		}

		/**
		 * @return the successMessageKey
		 */
		public String getSuccessMessageKey() {
			return successMessageKey;
		}

		/**
		 * @param successMessageKey the successMessageKey to set
		 */
		public void setSuccessMessageKey(String successMessageKey) {
			this.successMessageKey = successMessageKey;
		}

        /**
         * @return the requestType
         */
        public String getRequestType() {
            return requestType;
        }

        /**
         * @param requestType the requestType to set
         */
        public void setRequestType(String requestType) {
            this.requestType = requestType;
        }

        /**
         * @return the recoveryType
         */
        public String getRecoveryType() {
            return recoveryType;
        }

        /**
         * @param recoveryType the recoveryType to set
         */
        public void setRecoveryType(String recoveryType) {
            this.recoveryType = recoveryType;
        }

        /**
         * @return the secAnswer3
         */
        public String getSecAnswer3() {
            return secAnswer3;
        }

        /**
         * @param secAnswer3 the secAnswer3 to set
         */
        public void setSecAnswer3(String secAnswer3) {
            this.secAnswer3 = secAnswer3;
        }

}
