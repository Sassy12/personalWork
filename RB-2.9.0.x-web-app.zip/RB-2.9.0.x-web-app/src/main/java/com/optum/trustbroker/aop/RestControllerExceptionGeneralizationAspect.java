/*
 * Copyright (C) 2016 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.aop;

import java.util.Set;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;

import com.optum.trustbroker.controller.vo.ErrorResponseVO;
import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.message.MessageUtils;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.vo.OperationFailedException;

/**
 * An AOP aspect that converts runtime exceptions generated from a rest
 * service controller into a generic error response object.
 *
 * @author Sachin Kumar
 * @version 1.0
 */

public class RestControllerExceptionGeneralizationAspect {

    private static final BaseLogger LOG = new BaseLogger(RestControllerExceptionGeneralizationAspect.class);

    @Autowired
    @Qualifier("tb_service_errorMessageResource")
    private MessageSource errorMessageSource;

    /**
     * the list of RuntimeClass class throwable types which will be
     * rethrown if an instance of said class is processed by this handler.
     */
    private Set<Class<? extends RuntimeException>> rethrowList;

    /**
     * Handles the execution processing.
     *
     * @param pjp The join point being processed.
     * @return The join point response
     * @throws Throwable Thrown if the exception is not handled.
     */
    public Object execute(ProceedingJoinPoint pjp) throws Throwable {
        try {
            return pjp.proceed();
        } catch (Exception t) {
            LOG.error("Unhandled exception thrown during controller execution", t);

            if (rethrowList.contains(t.getClass())) {
                // throw a normalized exception
                throw t;
            }

            String uid = null;
            String code = null;
            String message = null;

            if (t instanceof OperationFailedException) {
                OperationFailedException ex = (OperationFailedException) t;
                if (ex.getErrorMessage() != null) {
                    uid = ex.getErrorMessage().getUid();
                    code = ex.getErrorMessage().getCode();
                    message = ex.getMessage();
                }
            }

            if (uid == null) { // Unknown exception
                uid = MessageUtils.getErrorUid();
                code = TrustBrokerConstants.OPT_00Z000;
                message = MessageUtils.getMessage(errorMessageSource, code + ".end.user.message");
                LOG.error("Unhandled exception thrown during controller execution - {}", new String[] {uid}, t);
            }

            Class<?> returnType = ((MethodSignature) pjp.getSignature()).getReturnType();

            if (returnType != null) {
                //Handling 2 types of response types- Need to check if there is third kind of response being returned
                if (ResponseVO.class.isAssignableFrom(returnType)) {
                    ResponseVO responseVO = (ResponseVO) returnType.newInstance();
                    responseVO.setErrorResponse(new ErrorResponseVO(code, uid, message));
                    responseVO.setResponseCode(Integer.toString(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
                    return responseVO;
                } else if (Response.class.isAssignableFrom(returnType)) {
                    ResponseVO responseVO = new ResponseVO();
                    responseVO.setResponseCode(Integer.toString(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
                    responseVO.setErrorResponse(new ErrorResponseVO(code, uid, message));
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(responseVO).build();
                }
            }

            throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR); // // throw a normalized exception 
        }
    }

    public Set<Class<? extends RuntimeException>> getRethrowList() {
        return rethrowList;
    }

    public void setRethrowList(Set<Class<? extends RuntimeException>> rethrowList) {
        this.rethrowList = rethrowList;
    }

}