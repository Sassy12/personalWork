package com.optum.trustbroker.managebean.widget;

import java.util.Enumeration;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.uhg.iam.alps.common.http.HttpUtils;

@RequestScoped
@ManagedBean(name = "wLogoutBean")
public class LogoutBean extends AbstractBackingBean {

	public void logout() {
		String error = (String) getSessionAttribute("error");
		HttpServletRequest request = (HttpServletRequest) getFacesContext()
				.getExternalContext().getRequest();

		String redirectView = StringUtils.isBlank(error) ? "/views/loginw.jsf"
				: "/views/tberrorpage.jsf";
		Enumeration enumeration = request.getParameterNames();
		while (enumeration.hasMoreElements()) {
			String enumKey = (String) enumeration.nextElement();
			redirectView = HttpUtils.addParameterToURL(redirectView, enumKey,
					request.getParameter(enumKey));
		}
		redirectToView(redirectView);
	}

}
