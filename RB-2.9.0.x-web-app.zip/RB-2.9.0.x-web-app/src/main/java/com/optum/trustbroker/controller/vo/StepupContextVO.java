package com.optum.trustbroker.controller.vo;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class StepupContextVO {
	
	public StepupContextVO(){
		
	}
	
	private boolean emailMandatory;
	private boolean emailUnique;
	private boolean dobRequired;
	private boolean secQuestionRequired;
	private boolean coppaRequired;
	private boolean showUserName;
	private boolean showPassword;
	private boolean showEmail;
	private boolean showDob;
	private boolean showSecQuestions;
	private boolean showYOB;
	private boolean migratedUser;
	private boolean userProfileHasSecQuestions;
	private boolean stepUpRequired;
	
	public void setStepUpRequired(boolean stepUpRequired) {
		this.stepUpRequired = stepUpRequired;
	}
	public boolean isStepUpRequired(){
		stepUpRequired=(showDob || showEmail || showSecQuestions || showYOB); 
		return stepUpRequired;
	}
	public boolean isEmailMandatory() {
		return emailMandatory;
	}

	public void setEmailMandatory(boolean emailMandatory) {
		this.emailMandatory = emailMandatory;
	}

	public boolean isEmailUnique() {
		return emailUnique;
	}

	public void setEmailUnique(boolean emailUnique) {
		this.emailUnique = emailUnique;
	}

	public boolean isDobRequired() {
		return dobRequired;
	}

	public void setDobRequired(boolean dobRequired) {
		this.dobRequired = dobRequired;
	}

	public boolean isSecQuestionRequired() {
		return secQuestionRequired;
	}

	public void setSecQuestionRequired(boolean secQuestionRequired) {
		this.secQuestionRequired = secQuestionRequired;
	}

	public boolean isCoppaRequired() {
		return coppaRequired;
	}

	public void setCoppaRequired(boolean coppaRequired) {
		this.coppaRequired = coppaRequired;
	}

	public boolean isShowUserName() {
		return showUserName;
	}

	public void setShowUserName(boolean showUserName) {
		this.showUserName = showUserName;
	}

	public boolean isShowPassword() {
		return showPassword;
	}

	public void setShowPassword(boolean showPassword) {
		this.showPassword = showPassword;
	}

	public boolean isShowEmail() {
		return showEmail;
	}

	public void setShowEmail(boolean showEmail) {
		this.showEmail = showEmail;
	}

	public boolean isShowDob() {
		return showDob;
	}

	public void setShowDob(boolean showDob) {
		this.showDob = showDob;
	}

	public boolean isShowSecQuestions() {
		return showSecQuestions;
	}

	public void setShowSecQuestions(boolean showSecQuestions) {
		this.showSecQuestions = showSecQuestions;
	}

	public boolean isShowYOB() {
		return showYOB;
	}

	public void setShowYOB(boolean showYOB) {
		this.showYOB = showYOB;
	}
	public boolean isMigratedUser() {
		return migratedUser;
	}
	public void setMigratedUser(boolean migratedUser) {
		this.migratedUser = migratedUser;
	}
	public boolean isUserProfileHasSecQuestions() {
		return userProfileHasSecQuestions;
	}
	public void setUserProfileHasSecQuestions(boolean userProfileHasSecQuestions) {
		this.userProfileHasSecQuestions = userProfileHasSecQuestions;
	}


	
}
