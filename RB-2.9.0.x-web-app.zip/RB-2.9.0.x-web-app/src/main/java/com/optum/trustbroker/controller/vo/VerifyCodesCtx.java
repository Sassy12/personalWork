package com.optum.trustbroker.controller.vo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.UserVO;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class VerifyCodesCtx {
	
	public VerifyCodesCtx(){}
	
	private List<CommunicationChannel> viewChannels;
	private List<CommunicationChannel> sendChannels;
	private boolean showDeviceRegistration;
	private String nextView;
	private UserVO userVO;
	private CommunicationChannel chann;
	private boolean autoVerify;
	private Map<CommunicationChannel, String> prePopulatedCodes;
	private String primaryCode;
	/* actual value of primary/secondary email/mobile no*/
	private String optionValue;
	private String maskedEmail;
	
	public CommunicationChannel getChann() {
		return chann;
	}
	public String getMaskedEmail() {
		return maskedEmail;
	}
	public void setMaskedEmail(String maskedEmail) {
		this.maskedEmail = maskedEmail;
	}
	public void setChann(CommunicationChannel chann) {
		this.chann = chann;
	}
	public List<CommunicationChannel> getSendChannels() {
		if (sendChannels == null) {
			sendChannels = new ArrayList<CommunicationChannel>();
		}
		
		return sendChannels;
	}
	public void setSendChannels(List<CommunicationChannel> sendChannels) {
		this.sendChannels = sendChannels;
	}
	
	public boolean isAutoVerify() {
		return autoVerify;
	}
	public void setAutoVerify(boolean autoVerify) {
		this.autoVerify = autoVerify;
	}
	public Map<CommunicationChannel, String> getPrePopulatedCodes() {
		return prePopulatedCodes;
	}
	public void setPrePopulatedCodes(Map<CommunicationChannel, String> prePopulatedCodes) {
		this.prePopulatedCodes = prePopulatedCodes;
	}
	public String getPrimaryCode() {
		return primaryCode;
	}
	public void setPrimaryCode(String primaryCode) {
		this.primaryCode = primaryCode;
	}
	
	public List<CommunicationChannel> getViewChannels() {
		if (viewChannels == null) {
			viewChannels = new ArrayList<CommunicationChannel>();
		}
		return viewChannels;
	}
	public void setViewChannels(List<CommunicationChannel> viewChannels) {
		this.viewChannels = viewChannels;
	}
	public boolean isShowDeviceRegistration() {
		return showDeviceRegistration;
	}
	public void setShowDeviceRegistration(boolean showDeviceRegistration) {
		this.showDeviceRegistration = showDeviceRegistration;
	}
	public String getNextView() {
		if (nextView == null) {
			nextView = "";
		}
		return nextView;
	}
	public void setNextView(String nextView) {
		this.nextView = nextView;
	}
	public UserVO getUserVO() {
		return userVO;
	}
	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public String getOptionValue() {
		return optionValue;
	}

	public void setOptionValue(String optionValue) {
		this.optionValue = optionValue;
	}
}
