package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.CommunicationChannel;


@ManagedBean(name = "userRegnConfStatusBean")
@ViewScoped
public class UserRegnConfStatusBean extends AbstractBackingBean implements Serializable {

	/**
	 * Serialize version id
	 */
	private static final long serialVersionUID = 1L;
	
	private String activeItem = "userregistration";
	
	public String getActiveItem() {
		return activeItem;
	}

	public void setActiveItem(String activeItem) {
		this.activeItem = activeItem;
	}

	public void processRegConfStatus() {
		
		String regConfStatusParam = getRequestParameter(TrustBrokerWebAppConstants.REGN_CONF_STAT_PARAM);
		//UserRegistrationBean userRegnBean = getUserRegnBean();
		UserRegistrationBean userRegnBean = (UserRegistrationBean) getSessionAttribute("UserRegnConfStatusBean");
		if(userRegnBean != null) {
			userRegnBean.setCurrentActiveItem(UserRegistrationBean.EMAIL_CONFRM_ACTIVE_ITEM);
			if(regConfStatusParam != null) {
				String errorCode = null;
				if(regConfStatusParam.equalsIgnoreCase("USER_AUTHENTICATION_FAILED")) {
					errorCode = TrustBrokerConstants.OPT_00A006;
				} else if(regConfStatusParam.equalsIgnoreCase("VERIFICATION_CODE_EXPIRED") || regConfStatusParam.equalsIgnoreCase("EMAIL_VERIFICATION_CODE_MISMATCH")) {
					errorCode = TrustBrokerConstants.OPT_00A005;
				} else if(regConfStatusParam.equalsIgnoreCase("NO_EMAIL_FOR_USER")) {
					errorCode = TrustBrokerConstants.OPT_00A009;
				} else if(regConfStatusParam.equalsIgnoreCase("EMAIL_VERIFICATION_CODE_NOT_FOUND")) {
					errorCode = TrustBrokerConstants.OPT_00A0010;
				} else if(regConfStatusParam.equalsIgnoreCase("NOT_FOUND")) {
					errorCode = TrustBrokerConstants.OPT_00A0011;
				} else {
					errorCode = TrustBrokerConstants.OPT_00A0011;
				}
				userRegnBean.setErrorMsg(buildErrorMessage(errorCode));		
			}
			//addSessionAttribute("UserRegnConfStatusBean", userRegnBean);
		}
				
		if(userRegnBean != null && userRegnBean.isVerifyNowFlag()) {
			setActiveItem("userregistration");
			VerifyCodesContext ctx = new VerifyCodesContext();
			ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			ctx.setHideUpdateButtons(true);
			ctx.setShowDeviceRegistration(false);
			ctx.setNextView("/views/userregistration.jsf");
			ctx.setUserVO(getCurrentUserVO());
			getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);	
			redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
		}
		else {
			setActiveItem("userregistration");
			redirectToView("/views/userregistration.jsf");
		}
		
	}
	
	private UserRegistrationBean getUserRegnBean() {
		
		final String USER_REGN_BEAN = "userRegistrationBean";
		UserRegistrationBean userRegnBean = (UserRegistrationBean) getSessionAttribute(USER_REGN_BEAN);
		Map<String, Object> sessionMap = getSessionMap();
		userRegnBean = (UserRegistrationBean) getSessionAttribute(USER_REGN_BEAN);
		
		if(userRegnBean == null && !sessionMap.values().isEmpty()) {
			Iterator level1Values = null;
			Map valueMap = null;
			Iterator values = sessionMap.values().iterator();
			Object value = null;
			Object level2Value = null;
			while(values.hasNext()) {
				value = values.next();
				if(value instanceof Map)  {
					valueMap = (Map) value;
					userRegnBean = (UserRegistrationBean) valueMap.get(USER_REGN_BEAN);
					if(isValidUserRegnBean(userRegnBean) ) {
						return userRegnBean;
					} else {
						level1Values = valueMap.values().iterator();
						while(level1Values.hasNext()) {
							level2Value = level1Values.next();
							if(level2Value instanceof Map)  {
								userRegnBean = (UserRegistrationBean) ((Map)level2Value).get(USER_REGN_BEAN);
								if(isValidUserRegnBean(userRegnBean)) {
									return userRegnBean;
								}
							}
						}
					}
				}				
			}
		}
		
		return userRegnBean;
	}
	
	private boolean isValidUserRegnBean(UserRegistrationBean userRegnBean) {
		boolean validBean = false;
		if (userRegnBean != null && (UserRegistrationBean.EMAIL_CONFRM_ACTIVE_ITEM.equals(
				userRegnBean.getCurrentActiveItem()))) {
			validBean = true;
		}
		return validBean;
	}
}
