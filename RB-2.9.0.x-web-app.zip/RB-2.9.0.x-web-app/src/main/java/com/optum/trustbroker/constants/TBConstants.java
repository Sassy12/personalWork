package com.optum.trustbroker.constants;

public class TBConstants {
	public static final String MANAGE_PROFILE_CONTROLLER_PATH = "/secure/rest/manageid/profileinfo";
	public static final String GET_RPCONTEXT_PATH = "/rpContext";

	public static final String STATUS_SUCCESS = "success";
	public static final int HTTP_SERVER_ERROR = 500;
	public static final int HTTP_SUCCESS = 200;
	public static final String PHONE_INFO = "phoneNumber";
	public static final String ALL_INFO = "allContactInfo";
	
	public static final String USER_CONTROLLER_PATH = "/rest/userservice";
	public static final String USER_SERVICE_VALIDATEFIRSTNAME_PATH = "/validatefirstname";
	public static final String USER_SERVICE_VALIDATELASTNAME_PATH = "/validatelastname";
	public static final String USER_SERVICE_VALIDATEUSERNAME_PATH = "/validateusername";
	public static final String USER_SERVICE_VALIDATEEMAIL_PATH = "/validateemail";
	public static final String USER_SERVICE_VALIDATEYOB= "/validateyob";
	public static final String USER_SERVICE_VALIDATEDOB= "/validatedob";
	public static final String USER_SERVICE_VALIDATEPWD= "/validatepwd";
	
	public static final String TERMS_CONDITIONS_CONTROLLER_PATH = "/rest/terms-and-conditions";
	public static final String WHITE_LBL_CONTROLLER_PATH = "/rest/whitelabel";
	
	public static final String REGISTRATION_CONTROLLER_PATH = "/rest/registration";
	public static final String REGISTRATION_INITIALIZE_DATA = "/initializedata";
	public static final String REGISTRATION_CREATE_USER = "/createuser";
	
	public static final String CHANGE_PWD_CONTROLLER_PATH = "/secure/rest/manageid/changepwd";
	public static final String CONTEXT = "/context";
	public static final String ACCOUNT_RECOVERY_CONTROLLER_PATH = "/secure/rest/manageid/accountrecovery";
	public static final String VERIFY_RECOVERY_OPTIONS_CONTROLLER_PATH = "/secure/rest/verifyrecoveryoptions";
	
	public static final String VERIFY_CODES_CONTROLLER_PATH="/secure/rest/verifyCodes/";
	public static final String VERIFY_CODES_CHECKFOR_PREVERIFICATION="/checkForPreVerification";
	public static final String VERIFY_CODES_RESEND_EMAIL="/resendEmail";
	public static final String VERIFY_CODES_VERIFY="/verify";
	public static final String VERIFY_PHONECODES_VERIFY="/verifyPhoneCodeInSession";
	
	public static final String CONFIRM_EMAIL_CONTROLLER_LINK="/rest/confirmationEmail";
	public static final String FORGOTACCESS_CONTROLLER_PATH="/rest/forgotaccess";
	public static final String VERIFY_LINK="/verifyLink";
	
	public static final String COMMON_CONTROLLER_PATH= "/rest/commonController";
	public static final String LOGIN_CONTROLLER_PATH= "/rest/login";
	public static final String SITEMINDER_CONTROLLER_PATH= "/rest/siteminderservice";
	public static final String USERNAME_CONTROLLER_PATH = "/rest/user";
	public static final String STATES_CONTROLLER_PATH = "/rest/states";
	public static final String RELYINGPARTY_CONTROLLER_PATH = "/rest/rp";
	public static final String MOBILE_OTP_CONTROLLER_PATH = "/rest/mobileOtp";
	
	public static final String ID_PROOFING_CONTROLLER_PATH = "/secure/rest/id-proofing";
	public static final String STEPUP_CONTROLLER_PATH = "/secure/rest/stepup/";
	public static final String RESET_PWD_CONTROLLER_PATH = "/rest/resetPassword";
	public static final String SET_SQA_CONTROLLER_PATH = "/rest/securityQuestions";
	
	public static final String VERIFY_CODES_UPDATE_CONTROLLER_PATH="/secure/rest/verifyCodesUpdate";
	public static final String VERIFY_CODES_UPDATE_FIELD="/update";
	public static final String SET_UPDATE_EMAIL_CONTEXT="/setUpdateEmailContext/{channel}";
	public static final String GET_UPDATE_EMAIL_CONTEXT="/getUpdateEmailContext";
	
	public static final String MANAGE_OID_PARAM = "manageOid";
	
	public static final String ADD_ACCOUNT_RECOVERY_CONTROLLER_PATH="/secure/rest/addAccountRecovery";
	
	public static final String ADD_ACC_RECOV_GET_RECOV_METHODS="/recoveryInfo";
	
	public static final String SKIP_ACC_RECOVERY="/skipAccountRecovery";
	
	public static final String UPDATE_RECOV_INFO="/updateRecoveryInfo";
	
	public static final String COMMON_SECURE_CONTROLLER_PATH = "/secure/rest/commonSecureController";

	public static final String CONGRATULATIONS = "congratulations";
	
	public static final String CONFRM_EMAIL_RESEND_CODE="/resendEmail";
}
