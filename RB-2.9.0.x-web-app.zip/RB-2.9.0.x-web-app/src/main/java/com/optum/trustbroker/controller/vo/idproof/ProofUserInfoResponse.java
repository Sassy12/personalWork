package com.optum.trustbroker.controller.vo.idproof;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.optum.trustbroker.controller.vo.ResponseVO;

@JsonIgnoreProperties
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class ProofUserInfoResponse extends ResponseVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
	private String transactionId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
}
