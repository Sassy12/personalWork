package com.optum.trustbroker.controller.vo;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonIgnoreProperties
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class UserInfoVO extends ResponseVO {
    private String uuid;

    private String userName;

    private String firstName;

    private String lastName;
    
    private String middleName;

    private String yearOfBirth;

    private String dateOfBirth;

    private String emailAddress;

    private String authCode;

    private String mobilePhoneNum;

    private List<String> recoveryMethods;

    // TODO: this is not needed, it is an artifact of JSF field mapping, analyze
    private String confirmEmailAddress;

    // TODO: this does not belong, consider delivering in a different object, analyze
    private List<String> userNameSuggestionsList;

    // TODO: this is not needed, it is an artifact of JSF field mapping, analyze
    private String pwd;

    // TODO: this is not needed, it is an artifact of JSF field mapping, analyze
    private String confirmPwd;

    private SecurityQuestionVO securityQuestionVO;

    // TODO: this is not needed, analyze
    private RpAppVO rpAppVO;

    // TODO: analyze whether this is necessary; perhaps just a shared email flag would be sufficient
    private boolean showSecQuestionBasedonSharedEmail;

    // TODO: this is not needed, analyze
    private String localEnv;

    private String nextState;

    // TODO: why an int? isn't the user either > 13 or <= 13 years old, analyze
    private int coppaCount;

    // TODO: this probably shouldn't be here, analyze
    private VerifyCodesCtx verifyCodesCtx;

    private AddressVO address;
    
    private boolean authCodeValid;

    /**
     * @return the authCodeValid
     */
    public boolean isAuthCodeValid() {
        return authCodeValid;
    }

    /**
     * @param authCodeValid the authCodeValid to set
     */
    public void setAuthCodeValid(boolean authCodeValid) {
        this.authCodeValid = authCodeValid;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public List<String> getUserNameSuggestionsList() {
        return userNameSuggestionsList;
    }

    public void setUserNameSuggestionsList(List<String> userNameSuggestionsList) {
        this.userNameSuggestionsList = userNameSuggestionsList;
    }

    public String getConfirmEmailAddress() {
        return confirmEmailAddress;
    }

    public void setConfirmEmailAddress(String confirmEmailAddress) {
        this.confirmEmailAddress = confirmEmailAddress;
    }

    public boolean isShowSecQuestionBasedonSharedEmail() {
        return showSecQuestionBasedonSharedEmail;
    }

    public void setShowSecQuestionBasedonSharedEmail(boolean showSecQuestionBasedonSharedEmail) {
        this.showSecQuestionBasedonSharedEmail = showSecQuestionBasedonSharedEmail;
    }

    public RpAppVO getRpAppVO() {
        return rpAppVO;
    }

    public void setRpAppVO(RpAppVO rpAppVO) {
        this.rpAppVO = rpAppVO;
    }

    public String getLocalEnv() {
        return localEnv;
    }

    public void setLocalEnv(String localEnv) {
        this.localEnv = localEnv;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getConfirmPwd() {
        return confirmPwd;
    }

    public void setConfirmPwd(String confirmPwd) {
        this.confirmPwd = confirmPwd;
    }

    public SecurityQuestionVO getSecurityQuestionVO() {
        return securityQuestionVO;
    }

    public void setSecurityQuestionVO(SecurityQuestionVO securityQuestionVO) {
        this.securityQuestionVO = securityQuestionVO;
    }

    public String getNextState() {
        return nextState;
    }

    public void setNextState(String nextState) {
        this.nextState = nextState;
    }

    public String getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(String yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public int getCoppaCount() {
        return coppaCount;
    }

    public void setCoppaCount(int coppaCount) {
        this.coppaCount = coppaCount;
    }

    public VerifyCodesCtx getVerifyCodesCtx() {
        return verifyCodesCtx;
    }

    public void setVerifyCodesCtx(VerifyCodesCtx verifyCodesCtx) {
        this.verifyCodesCtx = verifyCodesCtx;
    }

    public String getMobilePhoneNum() {
        return mobilePhoneNum;
    }

    public void setMobilePhoneNum(String mobilePhoneNum) {
        this.mobilePhoneNum = mobilePhoneNum;
    }

    public List<String> getRecoveryMethods() {
        return recoveryMethods;
    }

    public void setRecoveryMethods(List<String> recoveryMethods) {
        this.recoveryMethods = recoveryMethods;
    }

    public AddressVO getAddress() {
        return address;
    }

    public void setAddress(AddressVO address) {
        this.address = address;
    }

}