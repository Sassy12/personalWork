/*******************************************************************************
 * Copyright (c) 2012 Optum - All Rights Reserved.
 ******************************************************************************/
package com.optum.trustbroker.managebean;

import java.io.IOException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.SecureRandom;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.optum.trustbroker.util.TBHttpUtils;
import com.uhg.iam.alps.common.crypto.CryptException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang.StringUtils;

import com.ingenix.uitoolkit.pojos.AbsBackingBean;
import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.context.ApplicationContextHolder;
import com.optum.trustbroker.esso.sso.SsoContext;
import com.optum.trustbroker.esso.sso.SsoDestinationDeterminationStrategy;
import com.optum.trustbroker.esso.sso.utils.SsoUtils;
import com.optum.trustbroker.exceptions.ExceptionUtility;
import com.optum.trustbroker.message.ErrorMessage;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.ExecutionStatus;
import com.optum.trustbroker.vo.InvitationServiceRequest;
import com.optum.trustbroker.vo.InvitationVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.StatusVO;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.TermsAndConditionsRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserAuthorizationRequest;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserTagServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.VerificationCodeRequest;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.common.Attribute;
import com.uhg.iam.alps.common.DefaultUser;
import com.uhg.iam.alps.common.User;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.alps.sso.SsoRequest;
import com.uhg.iam.esso.schemas.xsd._2013._12.AuthenticationType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

public abstract class AbstractBackingBean extends AbsBackingBean {

	static final BaseLogger logger = new BaseLogger(AbstractBackingBean.class);

	@ManagedProperty("#{container}")
	protected ApplicationContainer container;
	
	@ManagedProperty("#{requestFilterTokenBean}")
	private RequestFilterTokenBean rtn;
	
	
	public final String PWD_INVALID_SPL_CHAR = "&";
	
	public final String COPPA_REQD_NO_IND ="N";
	
	public final String EMAIL_CONFM_REQD_NO_IND ="N";
	
	private String csrfToken;

	public AbstractBackingBean() {
			

	}
	
	public ApplicationContainer getContainer() {
		return container;
	}
	public void setContainer(ApplicationContainer container) {
		this.container = container;
	}
	String sensitiveDataErrormsgpage = "/views/errorpagesensitivedata.jsf";
	private String targetUrl = "/tb/secure/home.jsf";
	protected String alias;
	protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");
	protected static final ResourceBundle verifyCodes = ResourceBundle.getBundle("verifyCodesResources");
	protected boolean questionsRequired;
	
	protected boolean dobRequired;
	
	public UserVO getCurrentUserVO() {
		UserVO user = null;
		if(isSessionAttributeExists(TrustBrokerWebAppConstants.CURRENT_USER)){
			user = (UserVO) getSessionAttribute(TrustBrokerWebAppConstants.CURRENT_USER);
		}
		return user;
	}

	public void setCurrentUserVO(UserVO currentUserVO) {
		if (null != currentUserVO) {
			addSessionAttribute(TrustBrokerWebAppConstants.CURRENT_USER, currentUserVO);
		}
	}

	protected void setRpSuppParam(String rpAppId, String needsDecrypt){
		if(needsDecrypt!= null){
				rpAppId = container.getCryptAgentUtil().doDecryption(rpAppId);
		}
		if(getSessionAttribute("SupportRPId")==null && rpAppId !=null)
		   addSessionAttribute("SupportRPId",rpAppId);
	}
	
	public HttpServletRequest getServletRequest(){
		return (HttpServletRequest)getFacesContext().getExternalContext().getRequest();
	}
	
	public HttpServletResponse getServletResponse(){
		return (HttpServletResponse)getFacesContext().getExternalContext().getResponse();
	}

	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	public String getUrlLogoOptumId() {
		return constructURL("/images/lockup-product-name-lg.png");
	}

	public String getToolTipLogoOptumId() {
		return "Optum ID";
	}

	public RelyingPartyAppVO getRelyingPartyApp() {
		String rpAppId = getRelyingPartyAppId();		
		return getRelyingPartyApp(rpAppId);
	}
	
        public RelyingPartyAppVO getRelyingPartyApp(String rpAppId) {           
            if (rpAppId != null) {
                    return container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpAppId);
            }
            return null;
        }	

	public String getUrlLogoRelyingParty() {
		RelyingPartyAppVO rpApp = getRelyingPartyApp();
		if (rpApp != null && rpApp.getUploadedImageVO() != null && rpApp.getUploadedImageVO().getBytes() != null) {
			return constructURL("/dispimage?appID=" + rpApp.getApplicationId());
		}
		return null;
	}

	public String getToolTipLogoRelyingParty() {
		return "Optum ID";
	}

	public boolean isSessionAttributeExists(String attributeName){
		return getSessionMap().containsKey(attributeName);
	}
	
	public boolean isRequestParamExists(String paramName){
		return StringUtils.isNotBlank(getRequestParameter(paramName));
	}

	public Object getSessionAttribute(String attributeName){
		Object attributeValue = null;
		if(getSessionMap().containsKey(attributeName) && getSessionMap().get(attributeName) != null
				&& !"".equals(getSessionMap().get(attributeName))){
			attributeValue = getSessionMap().get(attributeName);
		}

		// ================================================================================================
		// gtyagi1: PHEW! another hack just because Relying Party APP ID is fetched from 
		// so many places so really can't elegantly counter it, for now just put an ugly check
		// here! Why are we dumping everything to session like that? for obtaining relying
		// party APP URL, we at minimum had one method in this base class where we changed
		if ( attributeValue == null && 
				StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.RELYING_APP_ID, attributeName) &&
				SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
			try {
				attributeValue = ApplicationContextHolder.getContext().retrieve(SsoContext.class).getDestinationApp();
				logger.debug("Loaded RP ID '{}' from '{}'", 
						new Object[]{attributeValue != null ? attributeValue.toString() : null, 
								SsoContext.class.getSimpleName()});
			}
			catch ( Exception ex ) {
				logger.error("Failed to obtain RP ID from SSO broker request", ex);
			}
		}
		else if ( attributeValue == null && 
				StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.RELYING_APP_URL, attributeName) &&
				SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
			try {
				attributeValue = 
						ApplicationContextHolder.getContext().retrieve(SsoContext.class).getTargetDestinationUrl();
				logger.debug("Loaded final destination URL '{}' from '{}'", 
						new Object[]{attributeValue != null ? attributeValue.toString() : null,
								SsoContext.class.getSimpleName()});
			}
			catch ( Exception ex ) {
				logger.error("Failed to obtain target final destination url for SSO broker request", ex);
			}
		}
		else if ( attributeValue == null && 
				StringUtils.equalsIgnoreCase(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, attributeName) &&
				SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
			try {
				attributeValue = 
						ApplicationContextHolder.getContext().retrieve(SsoDestinationDeterminationStrategy.APPLICATION_CONTEXT_SSO_DESTINATION_RP_KEY, 
								RelyingPartyAppVO.class).getAlias();
				logger.debug("Loaded {} as - '{}' from '{}'", 
						new Object[]{TrustBrokerWebAppConstants.RELYING_APP_ALIAS, attributeValue != null ? attributeValue.toString() : null,
								SsoContext.class.getSimpleName()});
			}
			catch ( Exception ex ) {
				logger.error("Failed to obtain target final destination url for SSO broker request", ex);
			}
		}
		// ================================================================================================
		
		return attributeValue;
	}

	public void addSessionAttribute(String attributeName, Object attributeValue){
		getSessionMap().put(attributeName, attributeValue);
	}

	public void removeSessionAttribute(String attributeName){
		getSessionMap().remove(attributeName);
	}

	public void clearSessionAttributes(String[] attributes){
		for(String attributeName:attributes){
			removeSessionAttribute(attributeName);
		}
	}

	public String getRequestParameter(String attributeName){
		String attributeValue = null;
		attributeValue = getServletRequest().getParameter(attributeName);
		return !StringUtils.isBlank(attributeValue) ? attributeValue : null;
	}

	public void addRelyingPartyRequestParam(String paramName, String mappingName, Boolean decryptionRequired){
		String attributeValue = getRequestParameter(paramName);
		if(attributeValue != null) addSessionAttribute(mappingName, attributeValue);
	}
	public void addRelyingPartyAlias(String relyingAppId){
		if(StringUtils.isEmpty(relyingAppId))
			return ;
		RelyingPartyAppVO relyingPartyAppVO =container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
		if (relyingPartyAppVO != null) 
			addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
	
	}

	public void captureRelyingPartyInfo(Boolean decryptionRequired){
		//Moved the capturing relying party info logic over here so that decryption can be performed at one single place.
		String relyingPartyTargetURL = getRequestParameter(TrustBrokerWebAppConstants.TARGET);
		if(relyingPartyTargetURL != null && decryptionRequired) relyingPartyTargetURL = container.getCryptAgentUtil().doDecryption(relyingPartyTargetURL);

		if(relyingPartyTargetURL != null){
			addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL, relyingPartyTargetURL);
			logger.debug("AbstractBackingBean:postConstruct | Capturing relying party target url information | Relying party URL ='" +
					relyingPartyTargetURL + "'");
		}

		if(isRequestParamExists(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM)){
			String relyingAppId = getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
			
			if(decryptionRequired) {
				relyingAppId = container.getCryptAgentUtil().doDecryption(relyingAppId);
				if(relyingAppId != null) addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, relyingAppId);
			}
			else addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, relyingAppId);
			
			addRelyingPartySettingsToSession();
			logger.debug("AbstractBackingBean:postConstruct | Capturing relying party app id information | Relying party ID ='" + relyingAppId + "'");
		}

		if(isRequestParamExists(TrustBrokerWebAppConstants.FIRST_NAME_PARAM)){
			String firstName = getRequestParameter(TrustBrokerWebAppConstants.FIRST_NAME_PARAM);
			if(decryptionRequired){
				firstName =container. getCryptAgentUtil().doDecryption(firstName);
				if(firstName != null) addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM, firstName);
			}
			else addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM, firstName);
		}

		if(isRequestParamExists(TrustBrokerWebAppConstants.LAST_NAME_PARAM)){
			String lastName = getRequestParameter(TrustBrokerWebAppConstants.LAST_NAME_PARAM);
			if(decryptionRequired){
				lastName = container.getCryptAgentUtil().doDecryption(lastName);
				if(lastName != null) addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM, lastName);
			}
			else addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM, lastName);
		}

		String email = getRequestParameter(TrustBrokerWebAppConstants.EMAIL_PARAM);
		if(StringUtils.isNotBlank(email)){
			if(decryptionRequired){
				email = container.getCryptAgentUtil().doDecryption(email);
				if(email != null) addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL, email);
			}
			else addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL, email);
		}
	// jchowda:Changes related to pre verify email address from RP by on demand bases.
		String userdetailMapString = getRequestParameter(TrustBrokerWebAppConstants.USER_DETAIL);
		if(StringUtils.isNotBlank(userdetailMapString)){
			if(decryptionRequired){
			Map<String,String>	userDetailsMap = container.getCryptAgentUtil().getCryptAgent().getAttributesFromToken(userdetailMapString,true);
				if(MapUtils.isNotEmpty(userDetailsMap))
				{	
					if(StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.PRE_VERIFY_KEY))&&StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.EMAIL_PARAM)))
						addSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL, userDetailsMap.get(TrustBrokerWebAppConstants.EMAIL_PARAM));
					if(StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.FIRST_NAME_PARAM)))
					addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_FIRST_NM, userDetailsMap.get(TrustBrokerWebAppConstants.FIRST_NAME_PARAM));
					if(StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.LAST_NAME_PARAM)))
						addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_LAST_NM, userDetailsMap.get(TrustBrokerWebAppConstants.LAST_NAME_PARAM));
					if(StringUtils.isNotBlank(userDetailsMap.get(TrustBrokerWebAppConstants.EMAIL_PARAM)))
						addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_EMAIL, userDetailsMap.get(TrustBrokerWebAppConstants.EMAIL_PARAM));
				}
			} 
			
			else{
				redirectToView(sensitiveDataErrormsgpage);
			}
		}else
		{
			removeSessionAttribute(TrustBrokerWebAppConstants.RP_PRE_VERIFY_EMAIL);
		}
		//End  jchowda.
		String inbs=getRequestParameter(TrustBrokerWebAppConstants.INBOUND_SSO);
		if(inbs != null&&(decryptionRequired?container.getCryptAgentUtil().doDecryption(inbs).equalsIgnoreCase(TrustBrokerConstants.STATUS_YES):inbs.equalsIgnoreCase(TrustBrokerConstants.STATUS_YES))){

				if(email != null) addSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO, email);
				else addSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO, email);
		}
		if(getRequestParameter(TrustBrokerWebAppConstants.ACTION) != null){
			addSessionAttribute(TrustBrokerWebAppConstants.ACTION, getRequestParameter(TrustBrokerWebAppConstants.ACTION));
		}
		
		if(getRequestParameter(TrustBrokerWebAppConstants.STATUS) != null){
			addSessionAttribute(TrustBrokerWebAppConstants.STATUS, getRequestParameter(TrustBrokerWebAppConstants.STATUS));
		}
		
		if(getRequestParameter(TrustBrokerWebAppConstants.INVITATION_CODE) != null){
			addSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE, getRequestParameter(TrustBrokerWebAppConstants.INVITATION_CODE));
		}
		if(getRequestParameter(TrustBrokerWebAppConstants.EMAIL_MODOFIED) != null){
			addSessionAttribute(TrustBrokerWebAppConstants.EMAIL_MODOFIED, getRequestParameter(TrustBrokerWebAppConstants.EMAIL_MODOFIED));
		}
		if(getRequestParameter("dobupdated")!=null)
			addSessionAttribute(TrustBrokerWebAppConstants.ON_DEMAND_SHOW_DOB, true);
		if(getRequestParameter("addressupdated")!=null)
			addSessionAttribute(TrustBrokerWebAppConstants.SHOW_ADDRESS, true);
		if(getRequestParameter("mobilephoneupdated")!=null)
			addSessionAttribute(TrustBrokerWebAppConstants.SHOW_MOB_PHONE, true);
		if(getRequestParameter("emailupdated")!=null)
			addSessionAttribute(TrustBrokerWebAppConstants.SHOW_EMAIL, true);

        String oidData;
        if ((oidData = getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA)) != null) {
            try {
                Map<String, String> mOidData = container.getCryptAgentUtil().getCryptAgent().getAttributesFromToken(oidData, true);
                addSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA, mOidData);
                addSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_TOKEN_ENCODED, TBHttpUtils.encodeValue(oidData));
            }
            catch (CryptException e) {
                logger.error("Retrieval of OpenId Connect data from parameter failed", e);
            }
        }
        else {
            // make sure oid data is removed if it was not provided
            removeSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
            removeSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_TOKEN_ENCODED);
        }

	}
	
	protected void addRelyingPartySettingsToSession(){
		String relyingAppId = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		if(StringUtils.isBlank(relyingAppId)) return;
		
		RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(relyingAppId);
		if (relyingPartyAppVO != null) {
			addSessionAttribute(TrustBrokerWebAppConstants.EMAIL_EDIT, relyingPartyAppVO.getEditEmail());
			addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAppVO.getAlias());
			addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_NAME, relyingPartyAppVO.getApplicationName());
			removeSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET);

            String loginTarget
                    = TBHttpUtils.addParametersToUrl(this.targetUrl,
                                                     TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, relyingPartyAppVO.getAlias(),
                                                     TrustBrokerWebAppConstants.TARGET,  (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL),
                                                     TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, relyingAppId);
            
            loginTarget = addOIDCParam(loginTarget);

			addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, loginTarget);
		    
		    if(this.getSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP) == null ){//not set
		    	if(relyingPartyAppVO.getShowRegistration() != null){
		    		addSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP, relyingPartyAppVO.getShowRegistration());	
		    	}
		    }
		    
		}
	}
	
	/**
	 * This method is to append open id token parameter to the given url if exists in session
	 * and returns it.
	 * 
	 * @param url java.lang.String
	 * @return java.lang.String
	 */
	@SuppressWarnings("unchecked")
	protected String addOIDCParam(String url) {	    
	    Map<String, String> mOidData = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
            if (mOidData != null) {
                String oidData = container.getCryptAgentUtil().getCryptAgent().createToken(mOidData);
                url
                        = TBHttpUtils.addParametersToUrl(url,
                                                         TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA, oidData);
            }
            return url;
	}
	
	/**
	 * This method redirects to relying party application.
	 * 
	 * @param targetUrl target where need to redirect the application.
	 * @param action if there was any specified action performed before redirection. 
	 * @param status status of the action (success/failure).
	 * @param rpAppIdentifier relying party application identifier.
	 * @return
	 */
	public String redirectToRelyingParty(String targetUrl, String action, String status, String rpAppIdentifier) {
		String relyingPartySuccessUrl = targetUrl;
		
		if(action != null){
			relyingPartySuccessUrl = HttpUtils.addParameterToURL(relyingPartySuccessUrl, TrustBrokerWebAppConstants.ACTION , action);
			relyingPartySuccessUrl = HttpUtils.addParameterToURL(relyingPartySuccessUrl, TrustBrokerWebAppConstants.STATUS, 
					(StringUtils.isNotBlank(status) ? status : TrustBrokerWebAppConstants.CANCEL));
		}

		logger.debug("AbstractBackingBean:redirectToRelyingParty() | Initiating redirection process for relying party: {} and user: {}",
				new String[]{rpAppIdentifier, getCurrentUserVO().getUserName()});
		
		String partnerId=null;
		try{
			if(StringUtils.isNotEmpty(rpAppIdentifier)){
				partnerId=container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpAppIdentifier).getPartnerId();
			}
			redirection(relyingPartySuccessUrl, partnerId);
		}catch (Exception e) {
			logger.error("AbstractBackingBean:redirectToRelyingParty() | Redirecting to relying party Failed | User Name={} " +
					"Partner ID={} Target URL={}", new String[]{getCurrentUserVO().getUserName(),partnerId,relyingPartySuccessUrl}, e);
		}
		
		return null;
	}

	/**
	 * Redirect to relying party target URL with specified partner identifier.
	 * @param url target URL where need to redirect.
	 * @param partnerId partner identifier.
	 */
	public boolean redirection(String url,String partnerId){
		String userName=null;
		try{
			
			if(StringUtils.isEmpty(partnerId)){
				logger.error("AstractBackingBean:redirection | Redirection Failure | Partner ID is blank for target {}", new String[]{url});
				return false;
			}

            HttpServletRequest httpServletRequest=(HttpServletRequest)getFacesContext().getExternalContext().getRequest();
            HttpServletResponse httpServletResponse=(HttpServletResponse)getFacesContext().getExternalContext().getResponse();

            UserVO userVO = getCurrentUserVO();

            @SuppressWarnings("unchecked")
            Map<String, String> mOidData = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
            if (mOidData != null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Performing OpenID Connect redirection to {}", new Object[] {partnerId});
                }                  
                String authServerUrl = PropertyLoader.getInstance().getPortalConfigValue("openid.connect.auth-server.url");
                String resumeUrl = authServerUrl + mOidData.get(TrustBrokerWebAppConstants.OpenIDConnect.RESUME_URI);
                Map<String, String> postParams = new HashMap<String, String>();
                //Checks if OIDC session is valid by checking diff between current time and oidc request time 
                //if valid session redirects to oidc url else redirects to default RP target url
                if(validateOIDSession(mOidData)) {
                    MultiMap attributes = new MultiValueMap();
                    attributes.put("subject", userVO.getUuId());
                    attributes.put("userid", userVO.getUserName());                        
                    String token = container.getOpenTokenAgent().writeToken(attributes);                                            
                    postParams.put(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_TOKEN, token);
                } else {
                    //Gets RP default target url           
                    RelyingPartyAppVO rpAppVO = getRelyingPartyApp(mOidData.get(TrustBrokerWebAppConstants.OpenIDConnect.CLIENT_ID));
                    if(rpAppVO != null && rpAppVO.getDefaultTargetUrl() != null) {
                        resumeUrl = rpAppVO.getDefaultTargetUrl();
                    }
                }
                String htmlForm
                        = HttpUtils.getHttpAutoPostFormWithParameters(resumeUrl, postParams);
                httpServletResponse.setContentType("text/html");
                HttpUtils.writeHttpServletResponse(htmlForm, httpServletResponse);
            }
            else {
                SsoRequest ssoRequest = new SsoRequest(httpServletRequest, httpServletResponse);
                userName= userVO.getUserName();
                User user = new DefaultUser(userName); // Always set User's userName
                ssoRequest.setUser(user);
                ssoRequest.setDestinationUrl(url);

                // ==================================================================================================================
                // gtyagi1: 2/4/2014 - START: introduce a little check for SSO Broker requests and relay
                // ==================================================================================================================
                if ( SsoUtils.isSsoBrokerDrivenOperation( ApplicationContextHolder.getContext() ) ) {
                    SsoContext ssoCtx = ApplicationContextHolder.getContext().retrieve(SsoContext.class); // null-safe since we just figured its a SSO broker request
                    Set<Attribute> ssoAttrs = ssoCtx.getOutboundRelayedSsoAttributes();
                    if ( CollectionUtils.isNotEmpty( ssoAttrs ) ) {
                        logger.debug("Setting Attributes for SSO to: {}, attributes size: {}", new Object[]{partnerId,
                                ssoAttrs.size()} );
                        ssoRequest.getUser().setAttributes( ssoAttrs );
                    }
                }
                // ==================================================================================================================
                // gtyagi1: 2/4/2014 - FINISH: introduce a little check for SSO Broker requests and relay
                // ==================================================================================================================
                logger.debug("AbstractBackingBean:redirection() | Redirecting to relying party with partner id={} and url {} " +
                        "for user = {}", new String[]{partnerId, url, userName});

                container.providerDelegatingSsoService.doSso(partnerId, ssoRequest);
            }
            getFacesContext().responseComplete();
			removeSessionData();
		}catch (Exception e) {
			ErrorMessage msg = TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00E002);
			logger.error("AstractBackingBean:redirection | Redirection method Exception in alps sdk redirection for user {} - {}",
					new String[] {userName, msg.getUid()}, e);
			handleInvalidSession(msg, e);
			return false;
		} 
		return true;
	}

	/**
         * This method is to check if the open id token has expired by comparing
         * against the default timeout. If timed out, then redirects false else true
         * 
         * @param mOidData Map<String, String> open id parameters.
         * @return boolean
         */
	private boolean validateOIDSession(Map<String, String> mOidData) {
	    boolean validSession = false;
	    String oidDateVal = mOidData.get(
	            TrustBrokerWebAppConstants.OpenIDConnect.REQUEST_TIME);
	    if(oidDateVal != null) {	        	      	        	       
	        //gets difference between token time and current time to
                Date iodDate = DateUtil.parseDate(
                        oidDateVal, DateUtil.DATE_TIME_FORMAT_WITH_MILIS);
                Date cntDtTime = DateUtil.getInstance().getCurrentDateinGMT();                
                long diffSecs = (cntDtTime.getTime() - iodDate.getTime()) / 1000;
                //Gets default timeout from prop file
                int oidTimeoutSecs = Integer.parseInt(tbResources.getString(
                        TrustBrokerWebAppConstants.OpenIDConnect.OIDC_TIMEOUT));
                if(diffSecs <= oidTimeoutSecs) {
                    validSession = true;
                    
                }                
	    }
	    return validSession;
	}
	
	/**
	 * This method redirects to relying party without performing SSO operation.
	 * 
	 * @param targetUrl target where need to redirect the application.
	 * @param action if there was any specified action performed before redirection. 
	 * @param status status of the action (success/failure).
	 * @param rpId relying party application identifier.
	 */
	public void redirectionNonsso(String targetUrl, String action, String status, String rpId) {
		String relyingPartySuccessUrl = targetUrl;
		if (action != null && status != null) {
			relyingPartySuccessUrl = HttpUtils.addParameterToURL(relyingPartySuccessUrl, TrustBrokerWebAppConstants.ACTION , action);
			relyingPartySuccessUrl = HttpUtils.addParameterToURL(relyingPartySuccessUrl, TrustBrokerWebAppConstants.STATUS, 
					(StringUtils.isNotBlank(status) ? status : TrustBrokerWebAppConstants.CANCEL));
		}
		HttpServletResponse httpServletResponse=(HttpServletResponse)getFacesContext().getExternalContext().getResponse();
		container.getRedirectingHttpResponseExecutorImpl().handle(relyingPartySuccessUrl, null, httpServletResponse);
	}
	
	/**
	 * Checks if there is any active SM session using session cookie.
	 * @return active session flag.
	 */
	protected boolean isActiveSMSessionForUser(String userName) {

		Cookie cookies[] = getServletRequest().getCookies();
		String smsession = "";

		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals(TrustBrokerWebAppConstants.SM_SESSION)) {
					smsession = cookies[i].getValue();
					break;
				}
			}
		}
		
		logger.debug("Inside isActiveSession, cookie {} and userid {}", new String[]{
				(StringUtils.isNotBlank(smsession) ? "true":"false"), userName});
		return (StringUtils.isNotBlank(smsession) && !"LOGGEDOFF".equals(smsession)) ? true : false;
	}
	
	protected UserTagServiceResponse addTagToUser(String uuid, String tagName,
			String idpVerificationCode) {
		UserTagServiceRequest request = buildUserTagServiceRequest(uuid,
				tagName);
		return container.getUserTagService().addUserTag(request, idpVerificationCode);
	}

	protected void deleteCookie(Cookie cookie) {
		HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
		HttpServletResponse response = (HttpServletResponse) getFacesContext().getExternalContext().getResponse();
		// TODO why are we changing the path and domain of cookie we want to delete?
		String host = request.getServerName();
		String domain = host.indexOf(".") >= 0 ? host.substring(host.indexOf(".")) : null;
		
		cookie.setPath("/");
		if ( domain != null ) {
			cookie.setDomain(domain);
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("host: " + host);
			logger.debug("cookie name: ", cookie.getName());
			logger.debug("cookie value: ", cookie.getValue());
			logger.debug("cookie path: ", cookie.getPath());
			logger.debug("cookie domain: ", cookie.getDomain());
		}
		cookie.setMaxAge(0);
		response.addCookie(cookie);
	}
	
	protected UserAuthorizationRequest generateAuthorizationRequest(UserVO userVO) {
		UserAuthorizationRequest userAuthorizationRequest = new UserAuthorizationRequest();
		userAuthorizationRequest.setUser(userVO);
		HttpServletRequest request = (HttpServletRequest) getFacesContext()
				.getExternalContext().getRequest();
		String resetAccountURL = TBUtil.generateContextPath(request) + "/views/resetaccount.jsf";
		String oidParam = getOIDToken();
                if(oidParam != null) {
                    resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, 
                            TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA, oidParam);
                }
		if (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null
				&& getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null) {
			resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, 
					(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.TARGET, 
					(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL));
			resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.AUTH_CODE, "");
		} else {
		    resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.AUTH_CODE, "");
		}				
		userAuthorizationRequest.setResetAccountLink(resetAccountURL);
		return userAuthorizationRequest;
	}
	
	/**
	 * This method build the Open ID token from the parameters and returns it.
	 * 
	 * @return String
	 */
	@SuppressWarnings("unchecked")
       protected String getOIDToken() {
	    
	    String oidParam = null;
	    Map<String, String> mOidData = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
            if (mOidData != null) {
                oidParam = container.getCryptAgentUtil().getCryptAgent().createToken(mOidData);               
            }
            return oidParam;
	}
	
        /**
         * This method build the Open ID paramters from the token and returns it.
         * 
         * @return Map<String, String>
         */	
	protected Map<String, String> getOIDParamsFromToken(String oidToken) {
	    Map<String, String> mOidData = container.getCryptAgentUtil().getCryptAgent().getAttributesFromToken(oidToken, true);
	    return mOidData;
	}
	
	public boolean isEmailConfirmationRequired() {
		boolean status = true;
		
		String rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		if(rpAppId != null) {
			RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpAppId);
			if(relyingPartyAppVO != null && EMAIL_CONFM_REQD_NO_IND.equalsIgnoreCase(relyingPartyAppVO.getEmailconfirmreqd())) {
				status = false;
			}
		}
		return status;
	}
	
	public void addMessageToFlash(String key, String message) {
		getFacesContext().getExternalContext().getFlash().put(key, message);
	}
	
	public boolean isSessionContainsRelyingPartyInfo(){
		return ((getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null && 
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null) ||
					(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null && 
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF) != null));
	}
	
	public boolean isSessionContainsRPInfoForLogin(){
		return (getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null && 
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null);
	}
	
	public boolean isParamContainsRelyingPartyInfo(){
		return ((getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null && 
				getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) != null));
	}

    public String getRelyingPartyRedirectionParameters() {
        String relyintPartyRedirectionURL = null;
        String relyingPartyId = null;
        String relyingPartyTargetURL = null;
        String invitationToken = null;

        if (isSessionContainsRelyingPartyInfo()) {
            relyingPartyId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
            relyingPartyTargetURL = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null ?
                    (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) :
                    (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);

            if (relyingPartyTargetURL.contains(TrustBrokerWebAppConstants.INVITATION_CODE)) {
                invitationToken = relyingPartyTargetURL.substring(relyingPartyTargetURL.indexOf("=") + 1);
                relyingPartyTargetURL = relyingPartyTargetURL.substring(0, relyingPartyTargetURL.indexOf("?"));
            }

            if (getSessionAttribute(TrustBrokerWebAppConstants.ACTION) != null) {
                relyingPartyTargetURL = relyingPartyTargetURL + "&" + TrustBrokerWebAppConstants.ACTION +
                        "=" + getSessionAttribute(TrustBrokerWebAppConstants.ACTION) + "&" + TrustBrokerWebAppConstants.STATUS + "=" +
                        (getSessionAttribute(TrustBrokerWebAppConstants.STATUS) != null ? getSessionAttribute(TrustBrokerWebAppConstants.STATUS) :
                                TrustBrokerWebAppConstants.CANCEL);
            }

            relyintPartyRedirectionURL = constructRedirectUrl();

            if (relyintPartyRedirectionURL != null) {
                relyintPartyRedirectionURL = relyintPartyRedirectionURL + TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM + "=" + relyingPartyId + "&" +
                        TrustBrokerWebAppConstants.TARGET + "=" + relyingPartyTargetURL;
            }
            else {
                relyintPartyRedirectionURL = TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM + "=" + relyingPartyId + "&" +
                        TrustBrokerWebAppConstants.TARGET + "=" + relyingPartyTargetURL;
            }

            relyintPartyRedirectionURL = invitationToken != null ? (relyintPartyRedirectionURL + "&" + TrustBrokerWebAppConstants.INVITATION_CODE
                    + "=" + invitationToken) : relyintPartyRedirectionURL;

            // this is ugly having it here
            @SuppressWarnings("unchecked")
            Map<String, String> mOidData = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
            if (mOidData != null) {
                String oidData = container.getCryptAgentUtil().getCryptAgent().createToken(mOidData);
                relyintPartyRedirectionURL += '&'
                        + TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA
                        + '=' + TBHttpUtils.encodeValue(oidData);
            }

        }

        return relyintPartyRedirectionURL;
    }

    public String constructRedirectUrl()
	{
		String targetUrl = null;
		if(null != getSessionAttribute("showDOB") && (Boolean) getSessionAttribute("showDOB")) {
			targetUrl = "dobupdated=y&" ;
		}
		if(null != getSessionAttribute("showAddress") && (Boolean) getSessionAttribute("showAddress")) {
			targetUrl = "addressupdated=y&" ;
		}
		if(null != getSessionAttribute("showMobilePhone") && (Boolean) getSessionAttribute("showMobilePhone")) {
			targetUrl = "mobilephoneupdated=y&" ;
		}
		if(null != getSessionAttribute("ShowEmail") && (Boolean) getSessionAttribute("ShowEmail")) {
			targetUrl = "emailupdated=y&" ;
		}
		return targetUrl;
	}

	protected String getRelyingPartyRedirectionURL(boolean ...addInvitationCode){
		String relyintPartyRedirectionURL = null;
		
		relyintPartyRedirectionURL = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		
		if(null == relyintPartyRedirectionURL)
			relyintPartyRedirectionURL = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);
		
		// ==================================================================================================================
		// gtyagi1: no elegant way to set this explicitly since everything is being dumped to session directly now
		// by current application, just put a little fallback and check for SSO operation
		if ( StringUtils.isBlank(relyintPartyRedirectionURL) && 
				SsoUtils.isSsoBrokerDrivenOperation(ApplicationContextHolder.getContext())) {
			try {
				relyintPartyRedirectionURL = 
						ApplicationContextHolder.getContext().retrieve(SsoContext.class).getTargetDestinationUrl();
				logger.debug("Loaded final destination URL '{}' from '{}'", 
						new Object[]{relyintPartyRedirectionURL, SsoContext.class.getSimpleName()});
			}
			catch ( Exception ex ) {
				logger.error("Failed to obtain target final destination url for SSO broker request", ex);
			}
		}
		// ==================================================================================================================		
		
		if(getSessionAttribute(TrustBrokerWebAppConstants.ACTION) != null){
			relyintPartyRedirectionURL = HttpUtils.addParameterToURL(relyintPartyRedirectionURL, 
					TrustBrokerWebAppConstants.ACTION, (String)getSessionAttribute(TrustBrokerWebAppConstants.ACTION));
			relyintPartyRedirectionURL = HttpUtils.addParameterToURL(relyintPartyRedirectionURL,TrustBrokerWebAppConstants.STATUS,
					((String)getSessionAttribute(TrustBrokerWebAppConstants.STATUS) != null ? 
							(String)getSessionAttribute(TrustBrokerWebAppConstants.STATUS) :
						TrustBrokerWebAppConstants.CANCEL));
		}
		
		if(addInvitationCode.length == 0 && getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE) != null) {
				relyintPartyRedirectionURL = HttpUtils.addParameterToURL(relyintPartyRedirectionURL, 
						TrustBrokerWebAppConstants.INVITATION_CODE, (String)getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE));
		}
		
		return relyintPartyRedirectionURL;
	}
	
	protected void removeSessionWithoutRelyingPartyInfo() {
		String rpTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		String relyingPartyApplicationId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		String action = (String) getSessionAttribute(TrustBrokerWebAppConstants.ACTION);
		String status = (String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS);
		String relyingPartyAlias = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS);
		String showRegistrationStr = (String)getSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP);
		String smTarget = (String) getSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET);
		String loginTarget = (String) getSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET);
        Object oidData = getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
        String CSRF_ID = (String) getSessionAttribute("CSRF_ID");
		getSessionMap().clear(); // Only remove data from session map, as we are putting application session data only in this map.
		

        if (CSRF_ID != null) {
            addSessionAttribute("CSRF_ID", CSRF_ID);
        }
		
		if (rpTargetURL != null && relyingPartyApplicationId != null) {
			addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL, rpTargetURL);
			addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID, relyingPartyApplicationId);
			addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_NAME, getRelyingPartyName());
			//Preserve session attributes as well.
			getServletRequest().getSession().setAttribute(TrustBrokerWebAppConstants.TARGET, rpTargetURL);
			getServletRequest().getSession().setAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, relyingPartyApplicationId);
		}

        if (oidData != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA, oidData);
        }
		if(action != null) addSessionAttribute(TrustBrokerWebAppConstants.ACTION, action);
		if(status != null) addSessionAttribute(TrustBrokerWebAppConstants.STATUS, status);
		if(smTarget != null) addSessionAttribute(TrustBrokerWebAppConstants.SM_TARGET, smTarget);
		if(relyingPartyAlias != null) addSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS, relyingPartyAlias);
		if(showRegistrationStr != null) addSessionAttribute(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP, showRegistrationStr);
		if(loginTarget != null) addSessionAttribute(TrustBrokerWebAppConstants.LOGIN_TARGET, loginTarget);
	}
	
	public UserTagServiceRequest buildUserTagServiceRequest(String uuid, String tagName) {
		UserTagServiceRequest userTagServiceRequest = new UserTagServiceRequest();
		if(null != tagName) userTagServiceRequest.setTagName(tagName);
		UserVO userVO = new UserVO();
		userVO.setUuId(uuid);
		userTagServiceRequest.setUser(userVO);
		return userTagServiceRequest;
	}
	
	public String getErrorReasonCode(ExecutionStatus exStatus){
		String errorReasonCD = "";
		
		if(exStatus.getStatusCodesList() != null){
			for(String code :exStatus.getStatusCodesList()){
				errorReasonCD += code + ",";
			}
		}
		if(errorReasonCD.length() > 0) errorReasonCD = errorReasonCD.substring(0, errorReasonCD.length() -1);
		return errorReasonCD;
	}
	
	public boolean removeSessionData(){
		try{
			getServletRequest().getSession(false).invalidate();
		}catch(Exception ex){
			logger.error("AbstractBackingBean:removeSessionData() | Error while removing session data", ex);
			return false;
		}
		
		return true;
	}

	public SupportContactInfoVO getSupportContactInfo() {
		RelyingPartyAppVO rpApp = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(getRelyingPartyAppId());
		return TBUtil.getSupportContactInfo(rpApp);
	}	

	protected void handleInvalidSession(ErrorMessage errorMessage, Throwable th) {
		if (errorMessage == null) return;
		logger.error(errorMessage.getTechnicalUserMesssage(container.getErrorMessageSource()), th);
		SupportContactInfoVO sci = getSupportContactInfo();
		removeSessionData();
		try {
			addSessionAttribute(TrustBrokerWebAppConstants.ERROR, errorMessage.getEndUserMessage(
					container.getErrorMessageSource(), sci));
		}
		catch(Exception ex){
			logger.error("AbstractBackingBean:handleInvalidSession() | Error while adding session attribute", ex);
		}
		redirectToView(tbResources.getString("LogOutPage"));
	}

	public String extractErrorMessageFromOFE(OperationFailedException ofe) {
		return ExceptionUtility.extractErrorMessageFromOFE(ofe, container.getErrorMessageSource(), getSessionMap(),
				container.getRelyingPartyAppService());
	}
	
	protected void updateUserInvitaion(UserVO userVO){
		try{
			
			InvitationVO invitationVO = (InvitationVO) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION);
			if(invitationVO != null) {
				invitationVO.setInvtnAccptdDttm(DateUtil.getInstance().getCurrentDate());
				invitationVO.setInvtnToUsr(userVO.getUserId());
				
				StatusVO status = container.getReferenceService().fetchStatusByStatusState(
						PropertyLoader.getInstance().getPortalConfigValue("REGISTERED"));
				if(status != null) invitationVO.setInvtnStts(status);
				
				InvitationServiceRequest request = new InvitationServiceRequest();
				request.setInvitationVO(invitationVO);
				 container.getInvitationService().updateInvitation(request);
			}
		}catch(Exception ex){
			logger.error("UserRegistrationBean:updateUserInvitaion() | Error while updating the invitation", ex);
		}
	}
	/**
	 * This method redirects to the specified view.
	 * 
	 * @param viewURI is the URI of view where redirection is required.
	 */
	public boolean redirectToView(String viewURI){
		try{
			getFacesContext().getExternalContext().redirect(getFacesContext().getExternalContext().getRequestContextPath()+ viewURI);
			return true;
		}catch(IOException ioEx){
			logger.error("AbstractBackingBean:redirectToView() | Error while redirecting to view: {}", new String[]{viewURI}, ioEx);
			return false;
		}
	}
	
	public boolean redirect(String url) {
		try{
			getFacesContext().getExternalContext().redirect(url);
			return true;
		}catch(IOException ioEx){
			logger.error("AbstractBackingBean:redirectToView() | Error while redirecting to view: {}", new String[]{url}, ioEx);
			return false;
		}
	}
	
	/**
	 * This method forwards to the specified view.
	 * 
	 * @param viewURI is the URI of view to be forwarded.
	 */
	public boolean forwardToView(String viewURI){
		try{
			getFacesContext().getExternalContext().dispatch(viewURI);
			return true;
		}catch(IOException ioEx){
			logger.error("AbstractBackingBean:forwardToView() | Error while redirecting to view: {}", new String[]{viewURI}, ioEx);
			return false;
		}
	}
	
	/**
	 * Returns the relying party application identifier if exists in session.
	 * 
	 * @return relying party app identifier.
	 */
	public String getRelyingPartyAppId(){
		String appId = null;
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null && 
				!"".equals(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID))){
			appId = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		}
		return appId;
	}

	public String getRelyingPartyApAlias(boolean... skipDefaultAlias){
		String alias = null;
		
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS) != null && 
				!"".equals(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS))){
			alias = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS);
		}
		
		if(skipDefaultAlias.length > 0 && skipDefaultAlias[0] && TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE.equals(alias)){
			alias = null;
		}
		return alias;
	}

	public String constructURL(String view){
		HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
		try {
			URL url = new URL(request.getRequestURL().toString());
			int port = url.getPort();
			if (logger.isDebugEnabled()) {
				logger.debug("hsreq scheme: " + request.getScheme());
				logger.debug("hsreq server port: " + request.getServerPort());
				logger.debug("url: " + request.getRequestURL());
				logger.debug("url protocol: " + url.getProtocol());
				logger.debug("url port: " + port);
			}
			if (port == -1) {
				return url.getProtocol() + "://" + url.getHost() + request.getContextPath() + view;
			}
			else {
				return url.getProtocol() + "://" + url.getHost() + ":" + port + request.getContextPath() + view;
			}
		}
		catch (MalformedURLException ex) {
			throw new RuntimeException(ex);
		}
	}
	
	public String constructURLWithRPParams(final String targetURL){
		String rtnUrl = targetURL;

		if(isSessionContainsRelyingPartyInfo()){
            String target = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null ?
                    (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) :
                    (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);

            rtnUrl
                    = TBHttpUtils.addParametersToUrl(rtnUrl,
                                                     TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID),
                                                     TrustBrokerWebAppConstants.TARGET,  target);

            @SuppressWarnings("unchecked")
            Map<String, String> mOidData = (Map<String, String>) getSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
            if (mOidData != null) {
                String oidData = container.getCryptAgentUtil().getCryptAgent().createToken(mOidData);
                rtnUrl
                        = TBHttpUtils.addParametersToUrl(rtnUrl,
                                                         TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA, oidData);
            }
		}
		
		if(getSessionAttribute(TrustBrokerConstants.INVITATION_CODE) != null){
            rtnUrl
                    = TBHttpUtils.addParametersToUrl(rtnUrl,
                                                     TrustBrokerWebAppConstants.INVITATION_CODE, (String) getSessionAttribute(TrustBrokerConstants.INVITATION_CODE));
		}
		return rtnUrl;
	}
	
	public String getRelyingPartyName() {
		String rpName = "";
		String rpId = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		if(rpId != null) {
			RelyingPartyAppVO rpApp =  container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(rpId);
			if(rpApp != null) {
				rpName = rpApp.getApplicationName();
			}
		}
		return rpName;
	}
	
	public boolean getRelyPartyOrigin() {
		boolean  isRelyPartyOrigin = false;
		if((getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF) != null &&
				 getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null) || 
				 (getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null &&
						 getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) != null)) {
			isRelyPartyOrigin = true; 
		}
		return isRelyPartyOrigin;
	}
	
	
		
	public boolean isQuestionsRequired() {
		return questionsRequired;
	}

	public void setQuestionsRequired(boolean questionsRequired) {
		this.questionsRequired = questionsRequired;
	}

	public boolean isDobRequired() {
		return dobRequired;
	}

	public void setDobRequired(boolean dobRequired) {
		this.dobRequired = dobRequired;
	}

	protected void getRPRegProfileAATypeinfo() {
		
		if(getRelyPartyOrigin()){									
			QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
			queryRelyingPartyResponse =  container.getConfigService().queryRelyingParty(
					getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS).toString());
			if(queryRelyingPartyResponse!=null &&  queryRelyingPartyResponse.getRelyingParty() !=null)	{
				RelyingParty relyParty = queryRelyingPartyResponse.getRelyingParty();
					if(null != relyParty) {
					
					if(relyParty.getTiers() != null && !relyParty.getTiers().isEmpty()) {
						
						//String tierId = relyParty.getTiers().get(0);
						TierConfig tierConfig = relyParty.getTiers().get(0);
						
						
						List<AuthenticationType> authenticationTypes= tierConfig.getAuthenticationTypes();
						if(authenticationTypes != null && !authenticationTypes.isEmpty()) {
							Iterator<AuthenticationType> authTypeItr = authenticationTypes.iterator();
							AuthenticationType authenticationType = null;
							while ( authTypeItr.hasNext()) {
								authenticationType = (AuthenticationType) authTypeItr.next();					
								if (AuthenticationType.SECURITY_QUESTIONS.toString().equalsIgnoreCase(authenticationType.value())) 	{					
									questionsRequired = true;					
								}					
							}
						}
						
						QueryTierResponse queryTierResponse = container.getConfigService().queryTier(tierConfig.getTierId());
						if(queryTierResponse !=null && queryTierResponse.getTierDefinition() !=null)
						{
							List<TierAttribute> tierAttributes= queryTierResponse.getTierDefinition().getTierAttributes();
							Iterator<TierAttribute> tierAttrItr = tierAttributes.iterator();
							TierAttribute tierAttribute = null;
							while (tierAttrItr.hasNext()) {
								tierAttribute = (TierAttribute) tierAttrItr.next();
								if(TrustBrokerConstants.DATE_OF_BIRTH.equalsIgnoreCase(tierAttribute.getName())
										 && tierAttribute.isMandatory()) {								
									dobRequired = true;								
								}									
							}
						}
					}				
					
				}
			}
		} else {
			questionsRequired = false;
			dobRequired = false;	
		}
		
	}

	protected String getHomePageURIWithAlias(){
		String homePageURI = "/secure/home.jsf";
		String alias = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ALIAS);
		
		if(StringUtils.isBlank(alias)){
			alias = TrustBrokerWebAppConstants.RELYING_APP_ALIAS_VALUE;
		}
		
		homePageURI = HttpUtils.addParameterToURL(homePageURI, TrustBrokerWebAppConstants.RELYING_APP_ALIAS_PARAM, alias);
		homePageURI = HttpUtils.addParameterToURL(homePageURI, "faces-redirect", "true");
		return homePageURI;
	}
	
	protected void createUserSession(){
		addSessionAttribute("usernameFromRequestHeader", getServletRequest().getHeader(TrustBrokerWebAppConstants.USER_NM_HEADER));
		String usernameFromRequestHeader = (String)getSessionAttribute("usernameFromRequestHeader");
		
		if(usernameFromRequestHeader == null && getCurrentUserVO() == null){
			handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00C001), null); return;
		}
		
		if(getCurrentUserVO() == null || (getCurrentUserVO() != null && usernameFromRequestHeader!= null 
				&& !getCurrentUserVO().getUserName().equals(usernameFromRequestHeader))) {
			clearSessionAttributes(new String[]{TrustBrokerWebAppConstants.TERMS_CONDITON_ACCEPTED,
					TrustBrokerWebAppConstants.CURRENT_USER});
			UserRetrievalServiceResponse userRetrievalResponse = null;
			try{
				userRetrievalResponse = container.getUserService().fetchUserDetailsForSession(usernameFromRequestHeader);
				
				if (userRetrievalResponse != null && userRetrievalResponse.getUser() != null 
						&& userRetrievalResponse.getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
					
					setCurrentUserVO(userRetrievalResponse.getUser());
					SecurityLoggingUtil.info("User Login", SecurityEventType.E1_CREATE, getServletRequest(), getCurrentUserVO().getUserName(),
							"Security Audit Event|CreateUserSession:SUCCESS | User has established session, AbstractBackingBean:createUserSession()", 
							SecurityEventResult.SUCCESS, getRelyingPartyAppId(), null);
				} else {
					handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00A003), null); return;
				}
				
				if(!checkIfUserCoppaCompliant()) handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00K000), null); return;
				
			} catch (OperationFailedException exception) {
				handleInvalidSession(exception.getErrorMessage(), exception); return;
			}
		}
	}
	
	private boolean checkIfUserCoppaCompliant(){
		
		boolean coppaValdnReqd = true;
		if(isSessionContainsRPInfoForLogin()) {
			RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(
					(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			//Coppa will be required by default unless configured as N for relying party 
			if(relyingPartyAppVO != null && COPPA_REQD_NO_IND.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
				coppaValdnReqd = false;
			} 
		}
		if(!coppaValdnReqd || TrustBrokerConstants.STATUS_YES.equalsIgnoreCase(getCurrentUserVO().getIsCoppaAccepted())){
			return true;
		}
		else if(getCurrentUserVO().getDob()!= null) {
			int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance().getPortalConfigValue("userMinAgeLimit"));
			return !DateUtil.validateAge(getCurrentUserVO().getDob(), minAgeLimit);
		}
		return true;
	}
	
	protected void checkifStepUpRequiredForCOPPA(boolean coppaValdnReqd){
		UserStepUpContext stepUpCtxt = getUserStepUpContext(false);
		
		if(!TrustBrokerConstants.STATUS_YES.equalsIgnoreCase(getCurrentUserVO().getIsCoppaAccepted()) && 
				getCurrentUserVO().getDob() == null && coppaValdnReqd && !stepUpCtxt.isShowDob()){
			stepUpCtxt.setCoppaRequired(coppaValdnReqd);
			stepUpCtxt.setShowYOB(true);
			addSessionAttribute(UserStepUpContext.SESSION_NAME, stepUpCtxt);
		}
	}
	
	public String buildErrorMessage(String errorCode) {
		String errorMsg = null;
		if (errorCode != null) {
			errorMsg = TrustBrokerUtil.getErrorMessage(errorCode).getEndUserMessage(container.getErrorMessageSource(), 
					getSupportContactInfo());
		}
		return errorMsg;
	}

	protected RelyingPartyAppVO getRelingAppByAlias(String alias){
		return container.getRelyingPartyAppService().getRelyingPartyAppByAlias(alias);
	}
	
	protected void addUserDetailMapToSession(String userName){
		Map<String, String> userDetailsMap = new HashMap<String, String>();
		userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME, userName);
		addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);
	}
	
	/**
	 * This method is used to check if user email is shared or not
	 * 
	 * @param userVO UserVO
	 * @return boolean
	 */
	public boolean isUserEmailShared(UserVO userVO) {
		boolean userEmailShared = false;		
		try{
			if(container.getUserService().isEmailExists(userVO.getEmailAddress())) {
				userEmailShared = true;
			}		
		} catch(OperationFailedException ofe) {
			logger.error("ResetSecurityCredentials Bean:isUserEmailShared | Error checking duplicate email", ofe);
		}
		return userEmailShared;
	}
	
	/**
	 * This method is used to check if user has security questions or not
	 * 
	 * @param userVO UserVO
	 * @return boolean
	 */
	public boolean isUserSecQuestionsNotExists(UserVO userVO) {
		boolean userSecQuestsNotexists = false;
		if(userVO.getUserChallengeQuestions() == null || userVO.getUserChallengeQuestions().isEmpty()) {
			userSecQuestsNotexists = true;
		}
		return userSecQuestsNotexists;
	}
	
	//In case if request is redirected to other server post login then it might not have reference to RP so capture RP details again. 
	protected void reCaptureRPDetails(){
		if(isParamContainsRelyingPartyInfo() && !isSessionContainsRelyingPartyInfo()){
			logger.debug("HomeBean:onPreinitialize() | Session do not contain relying party data but exist with parameters: " +
					"APP ID - {}, Target - {}", new String[]{getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM),
					getRequestParameter(TrustBrokerWebAppConstants.TARGET)});
			captureRelyingPartyInfo(getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
		}
	}
	
	public boolean checkIfUserAccountRecoveryRequired() {

		if(getSessionAttribute(TrustBrokerWebAppConstants.SKIP_VERIFY_FLOW) == null
				&& getSessionAttribute("SKIP_VERIFY_FLOW_REGISTRATION") == null  
			 && (TBUtil.isProdEnv() || isEmailConfirmationRequired())){	
			
			List<UserChallengeQuestionVO> securityQuesList = getCurrentUserVO().getUserChallengeQuestions();
			
			//Check if there is a recovery method available on profile.
			if ((StringUtils.isNotBlank(getCurrentUserVO().getPhoneNumber()) && getCurrentUserVO().getIsPhoneVerified())
					|| (StringUtils.isNotBlank(getCurrentUserVO().getSecEmailAddress()) && getCurrentUserVO().isSecEmailUnique()) 
					|| !(securityQuesList == null || securityQuesList.isEmpty()) 
					|| (StringUtils.isNotBlank(getCurrentUserVO().getEmailAddress()) && (getCurrentUserVO().isPrimaryEmailUnique() ||
							!container.getUserService().isEmailExists(getCurrentUserVO().getEmailAddress()))) ) {
				return false;
			} else return true;
		} else{
			return false;
		}
	
	}
	/**
	 * This method is to update the updateUserVO obj from userVO with user terms, privacy policy and copaa info.
	 * 
	 * @param userVO
	 * @param updateUserVO
	 */
	protected void updUserRepoObj(UserVO userVO, UserVO updateUserVO) {
		updateUserVO.setUserId(userVO.getUserId());
		updateUserVO.setUuId(userVO.getUuId());
		updateUserVO.setUserRoleCd(userVO.getUserRoleCd());
		
		updateUserVO.setIsTncAccepted(userVO.getIsTncAccepted());
		updateUserVO.setTncAgreementVersion(userVO.getTncAgreementVersion());	
		updateUserVO.setTncAgreedTs(userVO.getTncAgreedTs());	
		updateUserVO.setIdentityProofingId(userVO.getIdentityProofingId());	
		updateUserVO.setIsPriPolyAccepted(userVO.getIsPriPolyAccepted());
		updateUserVO.setPrivPolyAgreementVersion(userVO.getPrivPolyAgreementVersion());
		updateUserVO.setPriPolyyAgreedTs(userVO.getPriPolyyAgreedTs());
		updateUserVO.setIsCoppaAccepted(userVO.getIsCoppaAccepted());				
	}
	
	/**
	 * This method is used to check if user email is shared or not
	 * 
	 * @param email String
	 * @return boolean
	 */
	protected boolean isUserEmailShared(String email) {
		boolean userEmailShared = false;		
		try{
			if(container.getUserService().isEmailExists(email)) {
				userEmailShared = true;
			}		
		} catch(OperationFailedException ofe) {
			logger.error("UserRegistrationBean:isUserEmailShared | Error checking duplicate email", ofe);
		}
		return userEmailShared;
	}
	
	/**
	 * This method is used to check if user email is shared or not
	 * 
	 * @param email String
	 * @return boolean
	 */
	protected boolean isEmailExistsWithOtherUser(String email) {
		boolean userEmailShared = false;		
		try{
			if(container.getUserService().isEmailExistsWithOtherUser(email, getCurrentUserVO().getUserName())) {
				userEmailShared = true;
			}		
		} catch(OperationFailedException ofe) {
			logger.error("UserRegistrationBean:isUserEmailShared | Error checking duplicate email", ofe);
		}
		return userEmailShared;
	}
	
	protected String getPartnerId(){
		
		if(isSessionContainsRelyingPartyInfo()){
			RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(
					(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			if(relyingPartyAppVO != null) return relyingPartyAppVO.getPartnerId();
		}
		
		return TrustBrokerWebAppConstants.DEFAULT_PARTNER_ID;
	}
	
	protected VerificationCodeRequest getVerificationCodeRequest(CommunicationChannel channel, UserVO userVO) {
		VerificationCodeRequest req = new VerificationCodeRequest();
		req.setChannel(channel);
		req.setUser(userVO);
		req.setUrlLogoOptumId(getUrlLogoOptumId());
		req.setUrlLogoRelyingParty(getUrlLogoRelyingParty());
		req.setRemoteAddress(getServletRequest().getRemoteAddr());
		req.setLocalAddress(getServletRequest().getLocalAddr());
		req.setSessionId(getServletRequest().getSession().getId());
		if (isSessionContainsRelyingPartyInfo()){
			req.setUrlRelyingApp(getRelyingPartyRedirectionURL(false));
			req.setRpAppId(getRelyingPartyAppId());
		}
		if (isSessionAttributeExists(TrustBrokerWebAppConstants.INVITATION_CODE)){
			req.setInvitationCode((String)getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE));
		}
		
                String oidParams = getOIDToken();
                if(oidParams != null) {
                    req.setOidToken(oidParams);
                }
		req.setUrlVerification(constructURL(tbResources.getString(TrustBrokerConstants.VERIFICATION_URL)));
		return req;
	}
	
	protected UserStepUpContext getUserStepUpContext(boolean addToSession){
		UserStepUpContext userStepUpContext = (UserStepUpContext) getSessionAttribute(UserStepUpContext.SESSION_NAME); 
		
		if(null == userStepUpContext) {
			userStepUpContext = new UserStepUpContext();
			if(addToSession) addSessionAttribute(UserStepUpContext.SESSION_NAME, userStepUpContext);
		}
		
		return userStepUpContext;
	}
	
	protected boolean validateDate(String componentID, String dobStr) {
		
		boolean isValid = false;
		
		// check for accepted formats
		boolean resultDob = DateUtil.validateDateMultipleFormats(dobStr);
		if (!resultDob && !StringUtils.isBlank(dobStr)) {
			isValid = resultDob;
			getFacesContext().addMessage(componentID, new FacesMessage(tbResources.getString("dobFormatErrorMsg508")));
			return isValid; // no need to check it further
		}
		
		// check if date entered is in future
		boolean resultDobFuture = DateUtil.validateDateFuture(dobStr);
		if (!resultDobFuture && !StringUtils.isBlank(dobStr)) {
			isValid = resultDobFuture;
			getFacesContext().addMessage(componentID, new FacesMessage(tbResources.getString("dobFutureErrorMsg508"))); // Date must be in past
			return isValid; // no need to check it further
		}
		
		// check if date entered is earlier than 01-Jan-1890
		boolean resultDobPast = DateUtil.validateDatePast(dobStr);
		if (!resultDobPast && !StringUtils.isBlank(dobStr)) {
			isValid = resultDobPast;
			getFacesContext().addMessage(componentID, new FacesMessage(tbResources.getString("dobPastErrorMsg508"))); // Date must be in past
			return isValid; // no need to check it further
		}
		
		// all validations have been successful till now
		return true;

	}
	
	
	protected boolean validatePhoneMultipleFormats(String componentID, String phoneNumber) {
		
		boolean checkformat = false;
		
		String mobileNum = phoneNumber;
		
		if(!StringUtils.isEmpty(mobileNum)) {
			
			if (mobileNum.matches("([0-9]{10})")) { // 5555555555
				checkformat=true;
			} else if (mobileNum.matches("([0-9]{3})-([0-9]{7})")) { // 555-5555555
				checkformat=true;
			} else if (mobileNum.matches("([0-9]{3})-([0-9]{3})-([0-9]{4})")) { // 555-555-5555
				checkformat=true;
			} else if (mobileNum.matches("([0-9]{6})-([0-9]{4})")) { // 555555-5555
				checkformat=true;
			} else if (mobileNum.matches("([(]{1})([0-9]{3})([)]{1})([0-9]{3})-([0-9]{4})")) { // (555)555-5555
				checkformat=true;
			} else if (mobileNum.matches("([(]{1})([0-9]{3})([)]{1})([0-9]{7})")) { // (555)5555555
				checkformat=true;	
			} else if (mobileNum.matches("([(]{1})([0-9]{3})([)]{1})-([0-9]{3})-([0-9]{4})")) { // (555)-555-5555
				checkformat=true;	
			}			
			
			// none of the acceptable pattern matches
			if(checkformat == false) {
				getFacesContext().addMessage(componentID, new FacesMessage(tbResources.getString("invalidMobileMsg508")));
				return false;
			}
		}	

		// mobileNum is either empty or has passed one of the patterns 
		return true;
	}
	
	protected String getPhoneNumberInAcceptedBackendFormat(String phoneNumber) {
		
		if (phoneNumber == null || StringUtils.isEmpty(phoneNumber.trim())) return null;
		// remove non-digit chracters from mobile phone
		String phoneNumberInAcceptedBackendFormat = phoneNumber.replaceAll("\\D+","");
		// convert all-digit mobile nubmer 5555555555 to format (555)555-5555 accepted by ESSO
		return "("+phoneNumberInAcceptedBackendFormat.substring(0, 3) + ")" + phoneNumberInAcceptedBackendFormat.substring(3, 6) + "-" + phoneNumberInAcceptedBackendFormat.substring(6);
	}
	
	protected String getVidCookieValue(){
		HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
		Cookie cookies[] = request.getCookies();
		String visitorIDValue = "";
				
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals(TrustBrokerWebAppConstants.VISITOR_ID)) {
					if(cookies[i].getValue().contains(TrustBrokerWebAppConstants.MCMID)){
						//DACO team provided cookie splitting range.
						int index=cookies[i].getValue().indexOf(TrustBrokerWebAppConstants.MCMID);
						visitorIDValue=cookies[i].getValue().substring(index+8, index+46);
						break;
					}
				}
			}
		}
		
		
		return visitorIDValue;
	}
	
	
	
	public String getTermsAndConditionsText(){
		String content = "";
		try {
			TermsAndConditionsRetrievalServiceResponse termsAndConditionsResponse =  container.getReferenceService().fetchTermsAndConditionsByVersion("");

			if (termsAndConditionsResponse != null && TrustBrokerConstants.SUCCESS_CODE_VALUE
							.equals(termsAndConditionsResponse.getExecutionStatus().getStatusCd())) {
				content = termsAndConditionsResponse.getTermsandConditions().getContent();
				content = content.replace("[URL_TERMS]", tbResources.getString("termslink"));
				content = content.replace("[URL_PRIVACY]", tbResources.getString("privacypolicylink"));
			}
		} catch (OperationFailedException opEx) {
			logger.error("Error while fetching terms and conditions", opEx);
		}
		return content;
	}
	
	
	
	
	

    /**
     * Performs OpenId Connection logic specific to application entry points.  The logic
     * converts the OpenID Connect specific request parameters into the application expected
     * format for processing.  If the URL has already been processed, then this method does not
     * perform any additional processing.
     *
     * <p>
     *     If this method detects OpenId Connect specific parameters, then it encodes them into
     *     an encoded OpenID parameter and adds them as a parameter value for the standard
     *     entry point parameter list.
     * </p>
     *
     * @param pageUrl The entry point URL which is being accessed.
     * @return Whether or not processing should continue.  This method will automatically
     *         redirect the client in the case that URL modifications were made.
     */
    protected boolean initOpenIdConnectForEntry(String pageUrl) {
        boolean isContinue = true;

        // let's first check to see if we already have the openid
        String oid = getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA);
        if (oid == null) {

            // check one parameter first to see if it is an OpenID Connect initialization
            String clientId = getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.CLIENT_ID);
            if (clientId != null) {
                String resumeUri = getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.RESUME_URI);
                String redirectUri = getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.REDIRECT_URI);
                String state = getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.STATE);
                String responseType = getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.RESPONSE_TYPE);

                // check if all required params are here
                if (resumeUri != null && redirectUri != null) {
                    Map<String, String> oidMap = new HashMap<>();
                    oidMap.put(TrustBrokerWebAppConstants.OpenIDConnect.CLIENT_ID, clientId);
                    oidMap.put(TrustBrokerWebAppConstants.OpenIDConnect.RESUME_URI, resumeUri);
                    oidMap.put(TrustBrokerWebAppConstants.OpenIDConnect.REDIRECT_URI, redirectUri);
                    DateUtil dateUtil = DateUtil.getInstance();                    
                    String cntGMTDate = DateUtil.formatDate(
                            dateUtil.getCurrentDateinGMT(), DateUtil.DATE_TIME_FORMAT_WITH_MILIS);
                    oidMap.put(TrustBrokerWebAppConstants.OpenIDConnect.REQUEST_TIME, cntGMTDate);

                    // add in optional params
                    if (!StringUtils.isEmpty(state)) {
                        oidMap.put(TrustBrokerWebAppConstants.OpenIDConnect.STATE, state);
                    }
                    if (!StringUtils.isEmpty(responseType)) {
                        oidMap.put(TrustBrokerWebAppConstants.OpenIDConnect.RESPONSE_TYPE, responseType);
                    }

                    String oidData = container.getCryptAgentUtil().getCryptAgent().createToken(oidMap);

                    // convert login page URL to standard format
                    String rUrl
                            = TBHttpUtils.addParametersToUrl(pageUrl,
                                                             TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, clientId,
                                                             TrustBrokerWebAppConstants.TARGET, redirectUri,
                                                             TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA, oidData);

                    redirectToView(rUrl);
                    isContinue = false;
                }
            }
        }

        return isContinue;
    }
    
    /**
	 * This method is to add open id connect data encoded value to session from parameter.
	 * 
	 * @param url java.lang.String
	 * @return java.lang.String
	 */
    protected void addOpenIdConnectDataToSession(){
    	String oidData;
        if ((oidData = getRequestParameter(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_DATA)) != null) {
            addSessionAttribute(TrustBrokerWebAppConstants.OpenIDConnect.OPEN_ID_TOKEN_ENCODED, TBHttpUtils.encodeValue(oidData));
        }
    }

	public String getCsrfToken() {
		String aCsrfId = getRtn().getCsrfId();
		String sCsrfId = (String) getSessionAttribute("CSRF_ID");
		String csrfId;
		
		if(aCsrfId != null){
			addSessionAttribute("CSRF_ID", aCsrfId);
			csrfId = aCsrfId;
		} else if(sCsrfId != null){
			getRtn().setCsrfId(sCsrfId);
			csrfId = sCsrfId;
		} else {
			SecureRandom random = new SecureRandom();
			csrfId = new BigInteger(130, random).toString(32);
			
			addSessionAttribute("CSRF_ID", csrfId);
			getRtn().setCsrfId(csrfId);
		}
		
			
		java.util.Date date = new java.util.Date();
		long ts = date.getTime();
		String nCsrfId = csrfId + ":"+ ts;
		
		setCsrfToken(nCsrfId);
		return csrfToken;
	}

	public void setCsrfToken(String csrfToken) {
		this.csrfToken = csrfToken;
	}
	
	public RequestFilterTokenBean getRtn() {
		return rtn;
	}

	public void setRtn(RequestFilterTokenBean rtn) {
		this.rtn = rtn;
	}

}
