package com.optum.trustbroker.controller.vo;

import java.util.HashMap;
import java.util.Map;

public class ValidationData {
	
	private String email;
	private String phoneNo;
	private String name;
	
	private boolean rpRequiresSecQstns;
	private boolean rpAllowsSharedEmail;
	private boolean sharedEmail;
	private boolean showSecQuestions;
	
	private SecurityQuestionVO securityQuestionVO;
	
	private Map<String,String> errorMap;
	private Map<String,String> notificationMap;
	
	public static ValidationData builder(){
		return new ValidationData();
	}
	
	public ValidationData setEmail(String email){
		this.email = email;
		return this;
	}
	
	public ValidationData setPhoneNo(String phoneNo){
		this.phoneNo = phoneNo;
		return this;
	}
	
	public ValidationData setName(String name){
		this.name = name;
		return this;
	}
	
	public ValidationData allowSharedEmail(boolean allowSharedEmail){
		this.rpAllowsSharedEmail = allowSharedEmail;
		return this;
	}
	
	public ValidationData requireSecQstns(boolean requireSecQstns){
		this.rpRequiresSecQstns = requireSecQstns;
		return this;
	}
	
	public ValidationData addSecurityQuestions(SecurityQuestionVO securityQuestionVO){
		this.securityQuestionVO = securityQuestionVO;
		return this;
	}

	public String getEmail() {
		return email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public String getName() {
		return name;
	}

	public boolean isRpRequiresSecQstns() {
		return rpRequiresSecQstns;
	}

	public boolean isSharedEmailAllowedInRP() {
		return rpAllowsSharedEmail;
	}
	
	public SecurityQuestionVO getSecurityQuestionVO() {
		return securityQuestionVO;
	}

	public Map<String, String> getErrorMap() {
		return errorMap;
	}

	public Map<String, String> getNotificationMap() {
		return notificationMap;
	}

	public void addErrorMessage(String key, String value) {
		if (errorMap == null) {
			errorMap = new HashMap<String, String>();
		}
		errorMap.put(key, value);
	}

	public void addNotificationMessage(String key, String value) {
		if (notificationMap == null) {
			notificationMap = new HashMap<String, String>();
		}
		notificationMap.put(key, value);
	}

	public boolean isEmailSharedByOthers() {
		return sharedEmail;
	}

	public void setSharedEmail(boolean sharedEmail) {
		this.sharedEmail = sharedEmail;
	}

	public boolean isShowSecQuestions() {
		return showSecQuestions;
	}

	public void setShowSecQuestions(boolean showSecQuestions) {
		this.showSecQuestions = showSecQuestions;
	}
	
	public void resetErrors(){
		this.errorMap = null;
	}
	
	public void resetNotifications(){
		this.notificationMap = null;
	}
	
}
