'use strict';
//service for getting the error messages based on errorCodes and referenceCode
angular.module('tbApp').service('errorService',['$http', function($http){
	this.getErrorMessages = function(errorCode, referenceCode){
		var data = {
				errorCode: errorCode,
				referenceCode: referenceCode
		};
		return $http.post('/tb/services/rest/commonController/getErrorMessage', data);
	};
}]);
