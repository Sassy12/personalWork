package com.optum.trustbroker.context.filter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;


public class ResponseCookieWrapper extends HttpServletResponseWrapper {

    private ByteArrayPrintWriter output;
    private String redirectLocation;
    private boolean usingWriter;
    private boolean usingOutput;
    private boolean flushed;

    /**
     * The default behavior of this method is to call setContentType(String type)
     * on the wrapped response object.
     *
     * @param type
     */
    @Override
    public void setContentType(String type) {
        super.setContentType(type);
    }

    /**
     * The default behavior of this method is to return setHeader(String name, String value)
     * on the wrapped response object.
     *
     * @param name
     * @param value
     */
    @Override
    public void setHeader(String name, String value) {
        super.setHeader(name, value);
    }

    public ResponseCookieWrapper(HttpServletResponse response) {
        super(response);
        usingWriter = false;
        output = new ByteArrayPrintWriter();
    }

    public byte[] getByteArray() {
        return output.toByteArray();
    }

    /**
     * The default behavior of this method is to call flushBuffer()
     * on the wrapped response object.
     */
    @Override
    public void flushBuffer() throws IOException {
        flushed = true;
    }

    /**
     * Returns whether or not a call to flushBuffer has been executed
     * on this response wrapper.
     *
     * @return Whether or not a call to flushBuffer has been executed
     *         on this response wrapper
     */
    public boolean isFlushed() {
        return flushed;
    }
    
    /**
     * The default behavior of this method is to return sendRedirect(String location)
     * on the wrapped response object.
     *
     * @param location
     */
    @Override
    public void sendRedirect(String location) throws IOException {
        this.redirectLocation = location;
    }

    /**
     * Returns the location passed to the sendRedirect operation.
     */
    public String getSendRedirectLocation() {
        return this.redirectLocation;
    }
    
    /**
     * Return whether a sendRedirect operation was called on this wrapper.
     */
    public boolean isSendRedirect() {
        return this.redirectLocation != null;
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        // will error out, if in use
        if (usingWriter) {
            throw new IllegalStateException("getWriter has already been called on this response");
        }
        usingOutput = true;
        return output.getStream();
    }

    /**
     * The default behavior of this method is to return isCommitted()
     * on the wrapped response object.
     */
    @Override
    public boolean isCommitted() {
        /**
         * Note: this logic is being used here to allow for the ALPS code within
         *       SsoResponseHandlerImpl to be able to detect the scenario where the
         *       ServletResponse has already committed the data back to the client.  As
         *       that commitment is performed due to a data stream flush or close, this
         *       code was added in an attempt to detect that scenario and simulate the
         *       response normally provided by the underlying response class.
         */
        return this.flushed || output.isFlushedOrClosed() || super.isCommitted();
    }

    @Override
    public PrintWriter getWriter() throws IOException {
        // will error out, if in use
        if (usingOutput) {
            throw new IllegalStateException("getOutputStream has already been called on this response");
        }
        usingWriter = true;
        return output.getWriter();
    }

    @Override
    public String toString() {
        return output.toString();
    }

    private static class ByteArrayServletStream extends ServletOutputStream {
        ByteArrayOutputStream baos;

        ByteArrayServletStream(ByteArrayOutputStream baos) {
            this.baos = baos;
        }

        @Override
        public void write(int param) throws IOException {
            baos.write(param);
        }

        /**
         * Flushes this output stream and forces any buffered output bytes
         * to be written out. The general contract of <code>flush</code> is
         * that calling it is an indication that, if any bytes previously
         * written have been buffered by the implementation of the output
         * stream, such bytes should immediately be written to their
         * intended destination.
         * <p/>
         * If the intended destination of this stream is an abstraction provided by
         * the underlying operating system, for example a file, then flushing the
         * stream guarantees only that bytes previously written to the stream are
         * passed to the operating system for writing; it does not guarantee that
         * they are actually written to a physical device such as a disk drive.
         * <p/>
         * The <code>flush</code> method of <code>OutputStream</code> does nothing.
         *
         * @throws java.io.IOException if an I/O error occurs.
         */
        @Override
        public void flush() throws IOException {
            super.flush();
        }

        /**
         * Closes this output stream and releases any system resources
         * associated with this stream. The general contract of <code>close</code>
         * is that it closes the output stream. A closed stream cannot perform
         * output operations and cannot be reopened.
         * <p/>
         * The <code>close</code> method of <code>OutputStream</code> does nothing.
         *
         * @throws java.io.IOException if an I/O error occurs.
         */
        @Override
        public void close() throws IOException {
            super.close();
        }
    }

    private static class ByteArrayPrintWriter {
        // keeps track of whether the data stream has been flushed or closed
        private boolean flushedOrClosed = false;

        private ByteArrayOutputStream baos = new ByteArrayOutputStream();

        private PrintWriter pw = new PrintWriter(baos) {
            /**
             * Flushes the stream.
             *
             * @see #checkError()
             */
            @Override
            public void flush() {
                ByteArrayPrintWriter.this.flushedOrClosed = true;
                super.flush();
            }

            /**
             * Closes the stream and releases any system resources associated
             * with it. Closing a previously closed stream has no effect.
             *
             * @see #checkError()
             */
            @Override
            public void close() {
                ByteArrayPrintWriter.this.flushedOrClosed = true;
                super.close();
            }
        };

        private ServletOutputStream sos = new ByteArrayServletStream(baos) {
            /**
             * Closes this output stream and releases any system resources
             * associated with this stream. The general contract of <code>close</code>
             * is that it closes the output stream. A closed stream cannot perform
             * output operations and cannot be reopened.
             * <p/>
             * The <code>close</code> method of <code>OutputStream</code> does nothing.
             *
             * @throws java.io.IOException if an I/O error occurs.
             */
            @Override
            public void close() throws IOException {
                ByteArrayPrintWriter.this.flushedOrClosed = true;
                super.close();
            }

            /**
             * Flushes this output stream and forces any buffered output bytes
             * to be written out. The general contract of <code>flush</code> is
             * that calling it is an indication that, if any bytes previously
             * written have been buffered by the implementation of the output
             * stream, such bytes should immediately be written to their
             * intended destination.
             * <p/>
             * If the intended destination of this stream is an abstraction provided by
             * the underlying operating system, for example a file, then flushing the
             * stream guarantees only that bytes previously written to the stream are
             * passed to the operating system for writing; it does not guarantee that
             * they are actually written to a physical device such as a disk drive.
             * <p/>
             * The <code>flush</code> method of <code>OutputStream</code> does nothing.
             *
             * @throws java.io.IOException if an I/O error occurs.
             */
            @Override
            public void flush() throws IOException {
                ByteArrayPrintWriter.this.flushedOrClosed = true;
                super.flush();
            }
        };

        /**
         * Returns whether or not the writer/output stream associated with this
         * instance has been flushed or closed.
         *
         * @return True if flush() or close() has been called on either the PrintWriter
         *         or OutputStream associated with this class.
         */
        public boolean isFlushedOrClosed() {
            return flushedOrClosed;
        }

        public PrintWriter getWriter() {
            return pw;
        }

        public ServletOutputStream getStream() {
            return sos;
        }

        byte[] toByteArray() {
            return baos.toByteArray();
        }

    }
}