package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.ChallengeVerificationServiceRequest;
import com.optum.trustbroker.vo.ChallengeVerificationServiceResponse;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;

@ManagedBean(name = "verifysecquests")
@ViewScoped
public class VerifySecurityQuestionsBean extends AbstractBackingBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private BaseLogger logger = new BaseLogger(VerifySecurityQuestionsBean.class);
	private String username;
	private String securityQuestionOne;
	private String securityQuestionTwo;
	private String securityQuestionThree;
	private String securityAnswerOne;
	private String securityAnswerTwo;
	private String securityAnswerThree;
	private List<UserChallengeQuestionVO> questions;
	private int count=0;
	
	@SuppressWarnings("unchecked")
	@PostConstruct
	public void init() {
		questions = (List<UserChallengeQuestionVO>) getSessionAttribute(TrustBrokerWebAppConstants.SEC_QUESTIONS);
		username = (String)getSessionAttribute(TrustBrokerWebAppConstants.USER_NAME);
		populateSecurityQuestions();
	}

	private void populateSecurityQuestions(){
		if (questions !=null && questions.size() > 0) {
			setSecurityQuestionOne(questions.get(0).getQuestion());
			setSecurityQuestionTwo(questions.get(1).getQuestion());
			setSecurityQuestionThree(questions.get(2).getQuestion());
		}
	}

	/**
	 * @return the securityQuestionOne
	 */
	public String getSecurityQuestionOne() {
		return securityQuestionOne;
	}

	/**
	 * @param securityQuestionOne the securityQuestionOne to set
	 */
	public void setSecurityQuestionOne(String securityQuestionOne) {
		this.securityQuestionOne = securityQuestionOne;
	}

	/**
	 * @return the securityQuestionTwo
	 */
	public String getSecurityQuestionTwo() {
		return securityQuestionTwo;
	}

	/**
	 * @param securityQuestionTwo the securityQuestionTwo to set
	 */
	public void setSecurityQuestionTwo(String securityQuestionTwo) {
		this.securityQuestionTwo = securityQuestionTwo;
	}

	/**
	 * @return the securityQuestionThree
	 */
	public String getSecurityQuestionThree() {
		return securityQuestionThree;
	}

	/**
	 * @param securityQuestionThree the securityQuestionThree to set
	 */
	public void setSecurityQuestionThree(String securityQuestionThree) {
		this.securityQuestionThree = securityQuestionThree;
	}

	/**
	 * @return the securityAnswerOne
	 */
	public String getSecurityAnswerOne() {
		return securityAnswerOne;
	}

	/**
	 * @param securityAnswerOne the securityAnswerOne to set
	 */
	public void setSecurityAnswerOne(String securityAnswerOne) {
		this.securityAnswerOne = securityAnswerOne;
	}

	/**
	 * @return the securityAnswerTwo
	 */
	public String getSecurityAnswerTwo() {
		return securityAnswerTwo;
	}

	/**
	 * @param securityAnswerTwo the securityAnswerTwo to set
	 */
	public void setSecurityAnswerTwo(String securityAnswerTwo) {
		this.securityAnswerTwo = securityAnswerTwo;
	}

	/**
	 * @return the securityAnswerThree
	 */
	public String getSecurityAnswerThree() {
		return securityAnswerThree;
	}

	/**
	 * @param securityAnswerThree the securityAnswerThree to set
	 */
	public void setSecurityAnswerThree(String securityAnswerThree) {
		this.securityAnswerThree = securityAnswerThree;
	}

	/**
	 * @return the questions
	 */
	public List<UserChallengeQuestionVO> getQuestions() {
		return questions;
	}

	/**
	 * @param questions the questions to set
	 */
	public void setQuestions(List<UserChallengeQuestionVO> questions) {
		this.questions = questions;
	}

	@RequestMapping(method = RequestMethod.POST)
	public String verifyAnswers() {
		ChallengeVerificationServiceRequest request = new ChallengeVerificationServiceRequest();
		try {
			count++;//Increase count to 3
			questions.get(0).setAnswer(getSecurityAnswerOne());
			questions.get(1).setAnswer(getSecurityAnswerTwo());
			questions.get(2).setAnswer(getSecurityAnswerThree());
			request.setUserChallengeQuestions(questions);
			request.setUserName(getUsername());
			request.setGenerateOtp(true);
			// TODO is user cached?
			request.setUser(container.getUserService().fetchUserProfile(getUsername(), false, false).getUser());
			ChallengeVerificationServiceResponse response = container.getUserService().verifyChallengeAnswers(request,
					getRelyingPartyAppId(), getUrlLogoOptumId(), getUrlLogoRelyingParty());
			if (ChallengeVerificationServiceResponse.VerificationStatus.VERIFICATION_FAILURE.toString().equals(
					response.getVerificationStatus().toString())) {
				if (count >= 3) {
					getSessionMap().put("forgotCredFlow", "forgotpassword");
					logger.info("VerifySecurityQuestionsBean :: " + username + " verification of security questions failed");
					return "/views/securityinfoverificationfailedpage.xhtml?faces-redirect=true";
				}
				else {
					getFacesContext().addMessage(null, new FacesMessage("Security Answers do not match our records"));
					return null;
				}
			}
		}
		catch(OperationFailedException exception) {
			getFacesContext().addMessage(null, new FacesMessage(exception.getMessage()));
			return null;
		}
		logger.info("VerifySecurityQuestionsBean :: "+username + " verification of security questions successful");
		getSessionMap().remove("secquestions");
		getSessionMap().remove("username");
		getSessionMap().put("forgotCredFlow", "forgotpassword");
		return "/views/forgotcredentialsconfirmationpage.xhtml?faces-redirect=true";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String cancel(){
		return "/views/login.xhtml?faces-redirect=true";
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
}
