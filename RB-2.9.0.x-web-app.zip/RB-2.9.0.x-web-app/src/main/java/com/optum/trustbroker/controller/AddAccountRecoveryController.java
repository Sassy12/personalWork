package com.optum.trustbroker.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.LabelValueVO;
import com.optum.trustbroker.controller.vo.SecurityQuestionVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.controller.vo.ValidationData;
import com.optum.trustbroker.helpers.UserHelper;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.ValidationUtils;
import com.optum.trustbroker.vo.ChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserVO;

@Path(TBConstants.ADD_ACCOUNT_RECOVERY_CONTROLLER_PATH)
public class AddAccountRecoveryController extends BaseController {

    private static final String PHONE_NUMBER = "phoneNumber";

    private static final String SEC_QUES = "securityQuestions";

    private static final BaseLogger LOGGER = new BaseLogger(AddAccountRecoveryController.class);

    @Autowired
    private ValidationUtils validationUtils;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path(TBConstants.ADD_ACC_RECOV_GET_RECOV_METHODS)
    public UserInfoVO getRecoveryInfo(@Context HttpServletRequest req) {

        UserInfoVO userInfoVO = new UserInfoVO();
        LOGGER.debug("Request : " + req.getUserPrincipal());
        List<String> recoveryMethods = new ArrayList<String>();
        UserVO userVO = webApplicationCommonUtilities.getCurrentUserDetailsFromWebApplicationContext();
        if (StringUtils.isBlank(userVO.getPhoneNumber())
                || (StringUtils.isNotBlank(userVO.getPhoneNumber()) && !userVO.getIsPhoneVerified())) {

            recoveryMethods.add(PHONE_NUMBER);
        }
        if (CollectionUtils.isEmpty(userVO.getUserChallengeQuestions())) {

            recoveryMethods.add(SEC_QUES);
            SecurityQuestionVO secQuesVO = new SecurityQuestionVO();
            ChallengeQuestionServiceResponse challengeQuestionServiceResponse = configService.getSecurityQuestions();
            List<LabelValueVO> quesLists = createSecQuestionsModel(
                    challengeQuestionServiceResponse.getUserChallengeQuestions());
            secQuesVO.setQuestions(quesLists);
            userInfoVO.setSecurityQuestionVO(secQuesVO);
        }
        userInfoVO.setRecoveryMethods(recoveryMethods);

        return userInfoVO;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path(TBConstants.SKIP_ACC_RECOVERY)
    public void skipAccountRecovery(@Context HttpServletRequest req) {
        LOGGER.debug("Skipping Account Recovery for Request : " + req);
        WebApplicationContextHolder.getContext().setSessionAttribute(TrustBrokerWebAppConstants.DO_NOT_SHOW_ACC_RECOV,
                "true");

    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path(TBConstants.UPDATE_RECOV_INFO)
    public UserInfoVO addAccountRecoveryMethod(@Context HttpServletRequest req, final UserInfoVO userInfoVO) {
        LOGGER.debug("Adding recovery method for Request : " + req);
        UserInfoVO userInfoVOWithRecMethod = null;
        try {
            if (userInfoVO == null) {
                return null;
            }

            validateFormFields(userInfoVO);
            if (MapUtils.isNotEmpty(userInfoVO.getErrorMap())) {
                return userInfoVO;
            }
            userInfoVOWithRecMethod = new UserInfoVO();
            BeanUtils.copyProperties(userInfoVO, userInfoVOWithRecMethod);
            UserVO currentUserVO = getCurrentUser();
            UserVO userVO = new UserVO();
            BeanUtils.copyProperties(currentUserVO, userVO);
            updateUserWithNewInfo(userInfoVOWithRecMethod, userVO);
            UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
            userProfileServiceRequest.setUser(userVO);
            userProfileServiceRequest.setOldUser(currentUserVO);
            // update recovery options

            userService.modifyUser(userProfileServiceRequest, true);
            WebApplicationContextHolder.getContext().setSessionAttribute(TrustBrokerWebAppConstants.DO_NOT_SHOW_ACC_RECOV,
                    "true");
            if (StringUtils.isNotBlank(userInfoVOWithRecMethod.getMobilePhoneNum())) {
                userInfoVOWithRecMethod.setNextState("mobileNumVerification");
            } else {
                userInfoVOWithRecMethod.setNextState("noNextState");
            }

        } catch (Exception ex) {
            String errorMsg = getErrorMsg(ex);
            LOGGER.error("Exception while updating account recovery options ", errorMsg);
        }

        return userInfoVOWithRecMethod;
    }

    private void validateFormFields(UserInfoVO userInfoVO) {

        Map<String, String> errorMap = new HashMap<String, String>();
        validationUtils.checkForReqErrorInSecurityQuestions(userInfoVO, errorMap);
        if (errorMap.isEmpty()) {
            ValidationData validationData = new ValidationData();
            validationData.setPhoneNo(userInfoVO.getMobilePhoneNum());
            validationUtils.validateMobile(validationData);
            validationUtils.validateSecurityInfo(userInfoVO);
            if (validationData.getErrorMap() != null) {
                userInfoVO.getErrorMap().putAll(validationData.getErrorMap());
            }
        } else {
            userInfoVO.setErrorMap(errorMap);
        }
    }

    private void updateUserWithNewInfo(UserInfoVO userInfoVO, UserVO userVO) {

        if (StringUtils.isNotBlank(userInfoVO.getMobilePhoneNum())) {
            String phoneNo = userInfoVO.getMobilePhoneNum();
            phoneNo = StringUtils.replaceOnce(phoneNo, "-", ")");
            StringBuilder builder = new StringBuilder(13);
            builder.append("(").append(phoneNo);
            userVO.setPhoneNumber(builder.toString());
        } else {
            userVO.setPhoneNumber("");
        }

        SecurityQuestionVO securityQuestionVO = userInfoVO.getSecurityQuestionVO();
        if (securityQuestionVO != null) {
            UserHelper.populateSecurityQuestions(userVO, securityQuestionVO);
        }
    }

    public ValidationUtils getValidationUtils() {
        return validationUtils;
    }

    public void setValidationUtils(ValidationUtils validationUtils) {
        this.validationUtils = validationUtils;
    }
}