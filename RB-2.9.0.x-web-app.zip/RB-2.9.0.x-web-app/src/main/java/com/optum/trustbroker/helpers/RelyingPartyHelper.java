package com.optum.trustbroker.helpers;

import com.optum.trustbroker.controller.vo.RpAppVO;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.RelyingPartyTierInfoVO;

public class RelyingPartyHelper {

	public static RpAppVO buildRelyingPartyVO(RpAppVO rpAppVO, RelyingPartyAppVO relyingPartyAppVO, RelyingPartyTierInfoVO rpTierInfo) {
		
		if (relyingPartyAppVO != null) {
			rpAppVO.setEmailEdit(relyingPartyAppVO.getEditEmail());
			rpAppVO.setAlias((relyingPartyAppVO.getAlias()));
			rpAppVO.setApplicationName(relyingPartyAppVO.getApplicationName());
			if(TrustBrokerWebAppConstants.EMAIL_CONFIRMATION_REQUIRED_VALUE.equalsIgnoreCase(relyingPartyAppVO.getEmailconfirmreqd()))
				rpAppVO.setEmailConfirmationRequired(true);
			if(relyingPartyAppVO != null && TrustBrokerWebAppConstants.COPPA_REQUIRED_VALUE.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
				rpAppVO.setCoppaValidationReqd(true);
			}
			rpAppVO.setAppId(relyingPartyAppVO.getApplicationId());
			if(null != rpTierInfo) {
				rpAppVO.setShowQuestions(rpTierInfo.isSecQuesRequied());
				rpAppVO.setShowDob(rpTierInfo.isDobRequired());
				rpAppVO.setEmailShared(rpTierInfo.isEmailShared());
				rpAppVO.setRsaRequired(rpTierInfo.isRsaRequired());
				rpAppVO.setTierId(rpTierInfo.getTierId());
			}
		} else {
			// Stand alone configuration
			rpAppVO.setEmailConfirmationRequired(true);
			rpAppVO.setCoppaValidationReqd(true);
			rpAppVO.setEmailShared(true);
			rpAppVO.setShowQuestions(true);
			rpAppVO.setRsaRequired(true);
		}
		
		return rpAppVO;
	}
	
}
