package com.optum.trustbroker.controller.vo;

public class ConfirmationEmailVO {

	private String msg;
	private boolean displayBtn;
	private MessageType msgType;
	private String nextStateUrl;

	public String getNextStateUrl() {
		return nextStateUrl;
	}

	public void setNextStateUrl(String nextStateUrl) {
		this.nextStateUrl = nextStateUrl;
	}

	public MessageType getMsgType() {
		return msgType;
	}

	public void setMsgType(MessageType msgType) {
		this.msgType = msgType;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public boolean isDisplayBtn() {
		return displayBtn;
	}

	public void setDisplayBtn(boolean displayBtn) {
		this.displayBtn = displayBtn;
	}

}
