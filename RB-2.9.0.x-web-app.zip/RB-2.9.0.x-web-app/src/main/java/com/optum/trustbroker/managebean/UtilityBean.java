package com.optum.trustbroker.managebean;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.ExternalContext;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.trustbroker.enums.AuthorizationCodeStatus;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.SupportContactInfoVO;
import com.optum.trustbroker.vo.UserAuthorizationResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.alps.common.http.HttpUtils;

@ManagedBean(name = "utilityBean")
@RequestScoped
public class UtilityBean extends AbstractBackingBean {

	private static final Logger logger = LoggerFactory.getLogger(UtilityBean.class);

	String loginPage = "/views/login.xhtml?faces-redirect=true";
	String homePage = "/views/login.jsf?faces-redirect=true";
	String homePagew = "/views/loginw.jsf?faces-redirect=true";
	String loginWidgetPage = "/views/loginw.xhtml?faces-redirect=true";
	String forgotUsernamePage = "/views/forgotusernamepage.xhtml?faces-redirect=true";
	private boolean widgetView=false;
	private int appNameSize;
	public void validateUserAuthCode() {
		try {
			removeSessionWithoutRelyingPartyInfo();
			String authCode = getFacesContext().getExternalContext().getRequestParameterMap().get("authCode");
			captureRelyingPartyInfo(false);
			ExternalContext ec = getFacesContext().getExternalContext();
			UserAuthorizationResponse response = container.getUserService().validateAuthCode(authCode);
			if (response == null) {
				logger.error("response from userService.validateAuthCode(...) is null");
				ec.redirect(ec.getRequestContextPath() + "/views/userauthcodenotvalid.jsf");
			}
			if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
				if (response.getAuthStatus().equals(AuthorizationCodeStatus.PROCESSED.toString())) {
					ec.redirect(ec.getRequestContextPath() + "/views/userauthcodeused.jsf");
				}
				Map<String, String> userDetailsMap = new HashMap<String, String>();
				userDetailsMap.put(TrustBrokerWebAppConstants.USER_NAME, response.getUser().getUserName());
				userDetailsMap.put("authCode", authCode);
				addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetailsMap);
				addSessionAttribute(TrustBrokerWebAppConstants.SET_SECURITY_QUESTIONS, "setsecurityquestion");
				if (response.getPurpose().equals(TrustBrokerConstants.ACCOUNT_RECOVERY)) {
					ec.redirect(ec.getRequestContextPath()+ "/views/resetsecuritycredentials.jsf");
				}
				else {
					if (response.getUser().getUserChallengeQuestions() != null && response.getUser().getUserChallengeQuestions().size() > 0) {
						addSessionAttribute("sqaexists", "sqaexists");
						ec.redirect(ec.getRequestContextPath() + "/views/setsecurityques.jsf");
					}
					else {
						String email = getFacesContext().getExternalContext().getRequestParameterMap().get("email");
						email = container.getCryptAgentUtil().getCryptAgent().decrypt(email, true);
						if (email != null && (email.equalsIgnoreCase(response.getUser().getEmailAddress()) ||
								email.equalsIgnoreCase(response.getUser().getSecEmailAddress())))
						{	
							ec.redirect(ec.getRequestContextPath()+ "/views/setsecurityques.jsf");
						}
						else {
							addSessionAttribute("emailModified", "emailModified");
							ec.redirect(ec.getRequestContextPath() + "/views/setsecurityques.jsf");
						}
					}
				}
			}
			else if (TrustBrokerConstants.FAILURE_CODE_VALUE.equals(response.getExecutionStatus().getStatusCd())) {
				ec.redirect(ec.getRequestContextPath() + "/views/userauthorizationcodeexpired.jsf");
			}
		} 
		catch (Exception e) {
			logger.error("error occured while resetting users account with authorization code", e);
		}
	}

	public String goToLogin() {
		return getLoginUrl(loginPage);

	}
	public String goToForgotUsername() {
		return getLoginUrl(forgotUsernamePage);

	}
	
	
	public String goToWidgetLogin() {
		return getLoginUrl(loginWidgetPage);

	}

	private String getLoginUrl(String loginPageName) {
		
		String relyingPartyAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		String relyingPartyTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		String showRegistrationStr = (String) getSessionMap().get(TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP);
		
		if (StringUtils.isNotBlank(relyingPartyAppId) && StringUtils.isNotBlank(relyingPartyTargetURL)) {
			loginPageName = HttpUtils.addParameterToURL(loginPageName, TrustBrokerConstants.RELYING_APP_ID_PARAM, relyingPartyAppId);
			loginPageName = HttpUtils.addParameterToURL(loginPageName, TrustBrokerConstants.TARGET, relyingPartyTargetURL);
			
		}
		
		if(StringUtils.isNotBlank(showRegistrationStr)){
			loginPageName = HttpUtils.addParameterToURL(loginPageName, TrustBrokerWebAppConstants.SHOW_REG_FOR_RELYING_APP, showRegistrationStr);
		}
		loginPageName = addOIDCParam(loginPageName);
		
		return loginPageName;
	}
	
	public void continueClickedw(){
		this.widgetView=true;
		continueClicked();
	}
	
	public void continueClicked() {
	
		String redirectURL=homePage;
		
		if(widgetView) {
			redirectURL=homePagew;
		}
		
		String relyingPartyAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		String relyingPartyTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);

		if (StringUtils.isNotBlank(relyingPartyAppId) && StringUtils.isNotBlank(relyingPartyTargetURL)) {
			redirectURL = HttpUtils.addParameterToURL(redirectURL, TrustBrokerConstants.RELYING_APP_ID_PARAM, relyingPartyAppId);
			redirectURL = HttpUtils.addParameterToURL(redirectURL, TrustBrokerConstants.TARGET, relyingPartyTargetURL);
		}
		redirectURL = addOIDCParam(redirectURL);

		redirectToView(redirectURL);
	}
	
	
	public void captureRPInforForConsent() {
		
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) == null
					&& getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)==null ) {
			
			if(getRequestParameter(TrustBrokerWebAppConstants.TARGET) != null && 
					getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) != null){
				captureRelyingPartyInfo(getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);
				RelyingPartyAppVO relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString());
				addSessionAttribute("rpAppName",relyingPartyAppVO.getApplicationName());
			}
			
			UserVO userVO = getCurrentUserVO();
			if(null == userVO) {
				getSessionMap().put("usernameFromRequestHeader", getServletRequest().getHeader(TrustBrokerWebAppConstants.USER_NM_HEADER));
				String usernameFromRequestHeader = (String)getSessionMap().get("usernameFromRequestHeader");
				UserRetrievalServiceResponse userRetrievalResponse = null;
				if(StringUtils.isNotBlank(usernameFromRequestHeader)) {
				try{
						userRetrievalResponse =container.getUserService().fetchUserDetailsForSession(usernameFromRequestHeader);
						if (userRetrievalResponse != null && userRetrievalResponse.getUser() != null 
								&& userRetrievalResponse.getExecutionStatus().getStatusCd().equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
							setCurrentUserVO(userRetrievalResponse.getUser());
						} else {
							handleInvalidSession(TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00A003), null); return;
						}
					}catch (OperationFailedException exception) {
						logger.error("Error while creating the user session - {}", new String[]{TrustbrokerWebAppUtil.getUidFromError(exception)}, exception);
						handleInvalidSession(exception.getErrorMessage(), exception); return;
					}
				}
			}
		}
	}

	public int getAppNameSize(){
		Object appNameObj = getSessionAttribute("rpAppName");
		if(appNameObj == null)
			return 0;
		String appName=(String) appNameObj;
		appNameSize=appName.length();
		return appNameSize;
	}
	
	
	public void sendAnotherLink() {

	}
	
	public String getContactErrMsg() {
		String message = null;
		String origMessage = tbResources.getString("contactUsMsg");
		if (origMessage != null) {
			SupportContactInfoVO sci = getSupportContactInfo();
			message = MessageFormat.format(origMessage, sci.getContactComboText());
		}
		return message;
	}
	
	
	public String continueToAppPostRegistration() {
		redirectToView(getHomePageURIWithAlias());
		return null;
	}
}
