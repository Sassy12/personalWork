'use strict';

var commonApp = angular.module('common.modules');

/* Defining the services in common modules for re-using
   between pre-login and post-login flows*/

commonApp.service("verifyService",function($http){
	
	
	this.checkForPreVerification=function(ctx){
		
		return $http.post("/tb/services/secure/rest/verifyCodes/checkForPreVerification",ctx);
		
	};
	
	this.resendPrimaryEmail=function(ctx){
		
		return $http.post('/tb/services/secure/rest/verifyCodes/resendEmail',ctx);
		
	};
	
	this.verify=function(vo){
		
		return $http.post('/tb/services/secure/rest/verifyCodes/verify',vo);
		
	};
	
	this.getVerifyCodesCtx = function(){
		return $http.get('/tb/services/secure/rest/verifyCodes/createVerifyCodesCtx');
	};

	this.setupEmailUpdateWorkflow = function(channel){
	    return $http.put('/tb/services/secure/rest/verifyCodesUpdate/setUpdateEmailContext/'+channel);
	};
	
	this.getModifiedFields = function(){
		return $http.get('/tb/services/secure/rest/verifyCodes/getModifiedFields');
	};
	this.clearWorkflow = function(){
		return $http.get('/tb/services/secure/rest/verifyCodes/clearworkflow');
	};
	
});