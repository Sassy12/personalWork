package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.RPWhiteLabelVO;


/**
 * This class is meant as a starting point to cleaning up the management of the referring relying party information.
 * @author nvaneps
 */
@ManagedBean(name = "referringRelyingPartyBean")
@RequestScoped
public class ReferringRelyingPartyBean extends AbstractBackingBean implements Serializable{
	
	/**
	 * Default serial version UID.
	 */
	private static final long serialVersionUID = 6928233638794914191L;

	@PostConstruct
	public void init() {
	}
	
	private Map<String, String> rpLogo = new HashMap<String, String>(); 
	
	// TODO: this logic is duplicated for some requests
	public void populateSession() {
		String reqRelyingAppId = getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
		String reqTarget = getRequestParameter(TrustBrokerWebAppConstants.TARGET);
		if (StringUtils.isBlank((String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)) && 
				StringUtils.isNotBlank(reqRelyingAppId) && StringUtils.isNotBlank(reqTarget)){
			captureRelyingPartyInfo(getRequestParameter(TrustBrokerWebAppConstants.ENCRYPT) != null ? true:false);	
		}
	}

	public String getRpLogo() {

		/*
		 * if(StringUtils.isNotBlank((String)getSessionAttribute(TrustBrokerWebAppConstants.RP_LOGO_NAME))){
		 *  return (String)getSessionAttribute(TrustBrokerWebAppConstants.RP_LOGO_NAME);
		 *  }
		 */

		String rpAppId = getRequestParameter(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
		if (rpAppId == null) {
			rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		}
		if (rpLogo.containsKey(TrustBrokerWebAppConstants.RELYING_APP_ID)
				&& rpLogo.get(TrustBrokerWebAppConstants.RELYING_APP_ID) != null) {
			return rpLogo.get(TrustBrokerWebAppConstants.RELYING_APP_ID);
		}
		RPWhiteLabelVO uploadedImage = container.getUploadedImageService().fetchUploadedImageByAppId(rpAppId);
		if (uploadedImage != null) {
			if (uploadedImage.getFileContent() == null) {
				return null;
			} else {
				rpLogo.put(TrustBrokerWebAppConstants.RELYING_APP_ID,rpAppId);
				return rpAppId;
			}
		}
		return null;
	}
}
