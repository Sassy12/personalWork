$(document).ready(function() {
    $.pollenabled = true;
    var timeout;
    pollSessionStatus(30000);
    window.onfocus = checkSessionStatus; 
});


function pollSessionStatus(interval) {
    if(!checkSessionStatus()) return;
    
	timeout = setTimeout(function() {
        pollSessionStatus(interval);
    }, interval);
}

function checkSessionStatus(){
 if ($.pollenabled) {
        $.get('/tb/check-server-session', function(data) {
            if (data == "0") {
            	clearTimeout(timeout);
            	window.location.href = loginurl;
            	return false;
            }
        }, "text");
    }
 return true;
}

function disableSessionPolling() {
	$.pollenabled = false;
}
function enableSessionPolling() {
	$.pollenabled = true;
}