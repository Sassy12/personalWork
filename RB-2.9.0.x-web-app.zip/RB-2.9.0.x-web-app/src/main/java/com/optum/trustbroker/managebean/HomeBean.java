/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2011.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When          Who         Why
 * Nov 20 12   skum200		Initial version
 ****************************************************************/
package com.optum.trustbroker.managebean;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.domain.UserRelyingPartyRelation;
import com.optum.trustbroker.events.impl.UserSuccessfulSignInEvent;
import com.optum.trustbroker.message.ErrorMessage;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.AttributeVO;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.InvitationVO;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.TagServiceRequest;
import com.optum.trustbroker.vo.TagServiceResponse;
import com.optum.trustbroker.vo.TagVO;
import com.optum.trustbroker.vo.TermsAndConditionsRetrievalServiceResponse;
import com.optum.trustbroker.vo.TermsAndConditionsVO;
import com.optum.trustbroker.vo.UserChallengeQuestionVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceRequest;
import com.optum.trustbroker.vo.UserTagServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optum.trustbroker.vo.UserVerifyCodesServiceResponse;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.esso.schemas.xsd._2013._12.AuthenticationType;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

@ManagedBean(name = "homeBean")
@RequestScoped
public class HomeBean extends AbstractBackingBean implements Serializable {

	private static final long serialVersionUID = 1L;
	protected static final ResourceBundle tbResources = ResourceBundle.getBundle("trustBrokerResources");

	BaseLogger logger = new BaseLogger(HomeBean.class);
	
	private String username;
	private String errorMsg;
	
	private boolean tncAccepted;
	private boolean privacyPolicyAccepted;
	private boolean hideUpdateEmailButton = false;
	boolean coppaValdnReqd = true;
	
	private TermsAndConditionsVO termsAndConditionVO;
	
	private static final String BASIC_IDP_TAG_CD_PARAM_KEY = "basic_idp_tag_code";
	
	private static final String BASICNQ_IDP_TAG_CD_PARAM_KEY = "basic_nq_idp_tag_code";
	
	private static final String LOA3_IDP_TAG_CD_PARAM_KEY = "loa3_idp_tag_code";
	
	private static final String LOA3NQ_IDP_TAG_CD_PARAM_KEY = "loa3_nq_idp_tag_code";

	/**
	 * This method gets called before view gets initialized.
	 */
	public void onPreinitialize() {

		reCaptureRPDetails();
		removeSessionAttribute(UserStepUpContext.SESSION_NAME); // Clean up step up context from session first
		
		// gtyagi1: raise an event to indicate that a successful login has occurred!, note that 
		// if there are other checks that prevents user to not login (app specific reasons),
		// positioning of this event is critical for SsoBroker linkage mapping, we don't 
		// want to lose that context in doing any of our processing!
		this.getContainer().getEventPublisherService().publish(new UserSuccessfulSignInEvent(this, getCurrentUserVO()));
		
		//Post data to analytics on successful login.
		postSuccessfullAuthenticationEventAnalytics();
		
		if(getCurrentUserVO() != null) {
			username = getCurrentUserVO().getUserName();
			RelyingPartyAppVO relyingPartyAppVO = null; 
			UserRelyingPartyRelation userRelyingPartyRelation =null;
			
			//Add relying party access to user.
			if (isSessionContainsRPInfoForLogin()) {
				
				relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(
								(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
				
				//Coppa will be required by default unless configured as N for relying party 
				if(relyingPartyAppVO != null && COPPA_REQD_NO_IND.equalsIgnoreCase(relyingPartyAppVO.getCoppaReqdInd())) {
					coppaValdnReqd = false;
				}
				
				if(!checkAddApplicationAccess(relyingPartyAppVO)) return; // Add application access
				
				// Add User RP relation with default consent as NO
				userRelyingPartyRelation = container.getUserService().getAssociationBetweenUserAndRelyingApp(
								getCurrentUserVO().getUuId(),relyingPartyAppVO.getApplicationId());
				if (userRelyingPartyRelation == null && !addUserRelyingPartyRelation(relyingPartyAppVO)) return; 
			}
			
			//Check if user is having useraware flag as false, redirect user to RP
			if(!getCurrentUserVO().isUserAwarenessFlag() && isSessionContainsRPInfoForLogin()) {
				redirectVDSUserBackToRP(relyingPartyAppVO); return;
			}
			
			//Check RP tier configurations and then add the required details in session to refer for step up.
			checkRPTierConfigurations();
			
			//Check if COPPA needs to be performed based on user profile data and RP configuration
			checkifStepUpRequiredForCOPPA(coppaValdnReqd);
			
			//Check 0 - Migrated user or not
			if(getCurrentUserVO().isMigratedUser()){
				UserStepUpContext userStepUpContext = getUserStepUpContext(true);
				userStepUpContext.setShowUserName(getCurrentUserVO().isUserNameChangeRequired());
				userStepUpContext.setShowPassword(getCurrentUserVO().isPasswordChangeRequired());
				redirectToView("/secure/userstepupprofile.jsf"); return;
			}
			
			//Check 1 for verifying the Primary Email for Normal user - Always needs to be verified first
			if(!isSessionAttributeExists(TrustBrokerWebAppConstants.USER_MIGRATED) && checkPrimaryEmailConfirmationRequired()) return;

			// check 2
			// If the user does not have email, mobile number and SQ then take the user to Post login account recovery page.
			if ((isSessionAttributeExists(UserStepUpContext.SESSION_NAME) || checkIfUserAccountRecoveryRequired())) {
				redirectToView("/secure/userstepupprofile.jsf"); return;
			}
			
			//For a migrated user account recovery will take precedence and then verification. 
			if(checkPrimaryEmailConfirmationRequired()) return;
			
			if(!isSessionContainsRelyingPartyInfo() && isSessionAttributeExists(TrustBrokerWebAppConstants.USER_MIGRATED)){
				redirectToView("/secure/migrationsuccess.jsf");
			}
			
			// check 3
			// Check if terms and conditions accepted by the user.
			if(getSessionAttribute(TrustBrokerWebAppConstants.TERMS_CONDITON_ACCEPTED) == null){
				try{
					TermsAndConditionsRetrievalServiceResponse response =  container.getReferenceService().fetchTermsAndConditions(null);
					if(TrustbrokerWebAppUtil.checkResponseStatus(response)){
						termsAndConditionVO = response.getTermsandConditions();
						addSessionAttribute(TrustBrokerWebAppConstants.TERMS_AND_CONDITON, termsAndConditionVO);
					}else {
						logger.error("Failure while retrieving the terms and conditions. User {} may be redirected to relying party", 
								new String[]{getCurrentUserVO().getUserName()});
					}
					
					if(getCurrentUserVO().getIsTncAccepted() == null || 
							!TrustBrokerWebAppConstants.YES.equalsIgnoreCase(getCurrentUserVO().getIsTncAccepted()) ||
							(termsAndConditionVO != null && !termsAndConditionVO.getVersion().equals(getCurrentUserVO().getTncAgreementVersion()))){
						logger.debug("HomeBean:onPreinitialize() | Redirecting to terms and condition page");
						redirectToView("/secure/viewtermsandconditionslogin.jsf");
						return;
					}else if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null ){
						addSessionAttribute(TrustBrokerWebAppConstants.TERMS_CONDITON_ACCEPTED, true);
						processRelyingPartyRequest(relyingPartyAppVO,userRelyingPartyRelation,getCurrentUserVO());
						return;
					}else{
						removeSessionAttribute(TrustBrokerWebAppConstants.TERMS_AND_CONDITON);
						addSessionAttribute(TrustBrokerWebAppConstants.TERMS_CONDITON_ACCEPTED, true);
						return;
					}
				}catch(OperationFailedException opEx){
					logger.error("HomeBean:onPreinitialize() | Error while fetching terms and condition for user {}", 
							new String[]{getCurrentUserVO().getUserName(), TrustbrokerWebAppUtil.getUidFromError(opEx)},opEx);
					handleInvalidSession(opEx.getErrorMessage(), opEx);
				}
			} else if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null ){
				processRelyingPartyRequest(relyingPartyAppVO,userRelyingPartyRelation, getCurrentUserVO());
				return;
			}
			return;
		}
	}
	
	
	private void redirectVDSUserBackToRP(RelyingPartyAppVO relyingPartyAppVO){
		String relyingPartyTargetURL = getRelyingPartyRedirectionURL();
		relyingPartyTargetURL = constructRedirectUrl(relyingPartyTargetURL);
		String partnerID;
		if (relyingPartyAppVO != null) partnerID = relyingPartyAppVO.getPartnerId();
		else partnerID = TrustBrokerWebAppConstants.DEFAULT_PARTNER_ID;
		
		redirection(relyingPartyTargetURL, partnerID);
	}
	
	//Add application access to user 
	private boolean checkAddApplicationAccess(RelyingPartyAppVO relyingPartyAppVO){
		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(getCurrentUserVO());
		try {
			 container.getUserService().checkAddApplicationAccess(userProfileServiceRequest, relyingPartyAppVO);
		} catch (OperationFailedException ofe) {
			logger.error("HomeBean:processRelyingPartyRequest() | Application access for user {} with relying party {} failed - {}", 
					new String[]{username, relyingPartyAppVO.getApplicationName(), TrustbrokerWebAppUtil.getUidFromError(ofe)},ofe);
			handleInvalidSession(ofe.getErrorMessage(), ofe);
			return false;
		}
		logger.debug("HomeBean:processRelyingPartyRequest() | Application access added for user {} with relying party {}", 
				new String[]{username, relyingPartyAppVO.getApplicationId()});
		
		return true;
	}
	
	//Add relying party access to user 
	public boolean addUserRelyingPartyRelation(RelyingPartyAppVO relyingPartyAppVO){
		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(getCurrentUserVO());
		try {
			 container.getUserService().addUserRelyingPartyRelation(userProfileServiceRequest, relyingPartyAppVO);
		} catch (OperationFailedException ofe) {
			logger.error("HomeBean:processRelyingPartyRequest() | User association for user {} with relying party {} failed - {}", 
					new String[]{username, relyingPartyAppVO.getApplicationName(), TrustbrokerWebAppUtil.getUidFromError(ofe)},ofe);
			handleInvalidSession(ofe.getErrorMessage(), ofe);
			return false;
		}
		logger.debug("HomeBean:processRelyingPartyRequest() | Associated user {} with relying party {}", 
				new String[]{username, relyingPartyAppVO.getApplicationId()});
		
		return true;
	}
	
	//Check if primary email confirmation is required then redirect to confirmation screen.
	private boolean checkPrimaryEmailConfirmationRequired(){
	        UserVO userVO = getCurrentUserVO();
		if (StringUtils.isNotBlank(userVO.getEmailAddress()) && !userVO.isIsemailVerified() 
				&& (TBUtil.isProdEnv() || isEmailConfirmationRequired())) {
			
			if (getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_EDIT) != null && 
					getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_EDIT).toString().equalsIgnoreCase("N")) {
				hideUpdateEmailButton = true;
			} else
				hideUpdateEmailButton = false;
			VerifyCodesContext ctx = new VerifyCodesContext();
			boolean codeExpired = isEmailCnfrmCodeExpired(userVO.getUuId(), 
                                userVO.getEmailAddress(), CommunicationChannel.PRIMARY_EMAIL.name());					
			if(getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_UPDATED_ON_STEPUP) != null || 
					getSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED) != null ||
					codeExpired){
				ctx.getSendChannels().add(CommunicationChannel.PRIMARY_EMAIL);
				removeSessionAttribute(TrustBrokerWebAppConstants.EMAIL_UPDATED_ON_STEPUP);
				ctx.setExpiredResent(codeExpired);				
			}
			
			ctx.getViewChannels().add(CommunicationChannel.PRIMARY_EMAIL);
			ctx.setHideUpdateButtons(hideUpdateEmailButton);
			ctx.setNextView(getHomePageURIWithAlias());
			ctx.setUserVO(getCurrentUserVO());
			getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);
			redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
			
			return true;
		}
		return false;
	}
	
	private boolean isEmailCnfrmCodeExpired(String uuid, String email, String commChannel){
            UserVerifyCodesServiceResponse response = getContainer().getUserVerifyCodesService().getUserVerifyCodes(
                    uuid, email, commChannel.toString());
            return TrustbrokerWebAppUtil.checkExpiredRespStatus(response); 
      }
	
	
	/**
	 * This method is called from the widget home page to process relying party application redirect
	 */
	public void onWidgetPreinitialize() {
		
		RelyingPartyAppVO relyingPartyAppVO = null; 
		UserRelyingPartyRelation userRelyingPartyRelation =null;
		if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL) != null && 
				getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID)!=null )
		{
			UserVO uservo=getCurrentUserVO();
			relyingPartyAppVO = container.getRelyingPartyAppService().fetchRelyingPartyAppByAppId(
					(String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
			 userRelyingPartyRelation =  container.getUserService().getAssociationBetweenUserAndRelyingApp(
					 getCurrentUserVO().getUuId(), relyingPartyAppVO.getApplicationId());
			 processRelyingPartyRequest(relyingPartyAppVO,userRelyingPartyRelation, uservo);
		}
		
		return;		
	}
	
	//Check relying party tier configurations and add details to session
	private void checkRPTierConfigurations(){
		UserStepUpContext stepUpContext = getUserStepUpContext(false);
		
		if(isSessionContainsRPInfoForLogin()) {
		 	List<UserChallengeQuestionVO> securityQuesList = getCurrentUserVO().getUserChallengeQuestions();
		 	String tierId = null;
		 	QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
		 	queryRelyingPartyResponse = container.getConfigService().queryRelyingParty(getSessionAttribute(
		 			TrustBrokerWebAppConstants.RELYING_APP_ALIAS).toString());
		 	List<AuthenticationType> authenticationTypes=null;
			if(queryRelyingPartyResponse!=null &&  queryRelyingPartyResponse.getRelyingParty()!=null) {
				RelyingParty rp = queryRelyingPartyResponse.getRelyingParty();
				if (rp.getTiers() != null && rp.getTiers().size() > 0) {
					TierConfig tierConfig = rp.getTiers().get(0);
					tierId = tierConfig.getTierId();
					authenticationTypes = tierConfig.getAuthenticationTypes();
				}
			}
		 	
			if(securityQuesList == null || (securityQuesList!=null && securityQuesList.size()==0)) {
				if (authenticationTypes != null && authenticationTypes.size() > 0) {
					for (Iterator<AuthenticationType> iterator = authenticationTypes.iterator(); iterator.hasNext();) {
						AuthenticationType authenticationType = iterator.next();
						if (authenticationType.value().equalsIgnoreCase(TrustBrokerConstants.SECURITY_QUESTIONS)) {
							stepUpContext.setSecQuestionRequired(true);
							stepUpContext.setShowSecQuestions(true);
							break;
						}
					}
				}
		 	}
			
			if (StringUtils.isNotBlank(tierId)) {
				QueryTierResponse queryTierResponse = new QueryTierResponse();
				queryTierResponse = container.getConfigService().queryTier(tierId);
				if (queryTierResponse != null && queryTierResponse.getTierDefinition() != null) {
					List<TierAttribute> tierAttributes = queryTierResponse.getTierDefinition().getTierAttributes();
					for (Iterator<TierAttribute> iterator = tierAttributes.iterator(); iterator.hasNext();) {
						TierAttribute tierAttribute = iterator.next();
						if (tierAttribute.getName().equalsIgnoreCase(TrustBrokerConstants.DATE_OF_BIRTH) && getCurrentUserVO().getDob() == null) {
							if (tierAttribute.isMandatory()) {
								stepUpContext.setDobRequired(true);
								stepUpContext.setCoppaRequired(coppaValdnReqd);
								stepUpContext.setShowDob(true);
							}
						} else if(tierAttribute.getName().equalsIgnoreCase(TrustBrokerConstants.EMAIL_ADDRESS)){
							stepUpContext.setEmailUnique(tierAttribute.isUnique());
							stepUpContext.setEmailMandatory(tierAttribute.isMandatory());
							stepUpContext.setShowEmail(checkIfEmailRequiredOnStepUp(true, tierAttribute.isUnique(), tierAttribute.isMandatory()));
						}
					}
				}
			}
			
			if(stepUpContext.isStepUpRequired() || getCurrentUserVO().isMigratedUser()){
				addSessionAttribute(UserStepUpContext.SESSION_NAME, stepUpContext);
			}
		 } else {
				if (getCurrentUserVO().getEmailAddress() == null) {
					stepUpContext.setShowEmail(true);
					stepUpContext.setEmailMandatory(true);
					addSessionAttribute(UserStepUpContext.SESSION_NAME, stepUpContext);
				}
		 }
	}
	
	
	private boolean checkIfEmailRequiredOnStepUp(boolean isRpContextAvailable, boolean isUniqueEmailRequired, boolean isEmailMandatory){
		boolean status = false;
		
		if(isRpContextAvailable){
			if((getCurrentUserVO().getEmailAddress() == null && isEmailMandatory) || 
					(getCurrentUserVO().getEmailAddress() != null && getCurrentUserVO().isIsemailVerified() 
							&& !getCurrentUserVO().isPrimaryEmailUnique() && isUniqueEmailRequired  
							&& !isSessionAttributeExists(TrustBrokerWebAppConstants.USER_MIGRATED))){
				status = true;
			} else if(getCurrentUserVO().isMigratedUser() && getCurrentUserVO().getEmailAddress() != null 
					&& !getCurrentUserVO().isIsemailVerified() && isUniqueEmailRequired
					&& container.getUserService().isEmailExists(getCurrentUserVO().getEmailAddress())){
				status = true;
			}
		}
		
		return status;
	}
	
	/**
	 * This method processes user tags association for given relying party, tag with invitation tag if user registered 
	 * or did login through an invitation, associates user with relying party and finally redirects the user to relying 
	 * party target URL.
	 */
	private void processRelyingPartyRequest(RelyingPartyAppVO relyingPartyAppVO,UserRelyingPartyRelation userRelyingPartyRelation,UserVO user) {

		String relyingPartyTargetURL = getRelyingPartyRedirectionURL();
		relyingPartyTargetURL = constructRedirectUrl(relyingPartyTargetURL);
		try{
			String relyingAppProfUrl = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL_PROF);
			if(relyingAppProfUrl == null) {				
				removeSessionAttribute(TrustBrokerWebAppConstants.TERMS_AND_CONDITON);
				String partnerId=null;
				if(getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID) != null){
					
					String relyingAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString();
					username = getCurrentUserVO().getUserName();
	
					if(username != null && !"".equals(username) && relyingAppId != null && !"".equals(relyingAppId)) {
						logger.debug("HomeBean:processRelyingPartyRequest() | Associating user {} with relying party application {}",
								new String[] { username, relyingAppId });
						
						partnerId=relyingPartyAppVO.getPartnerId();
						addSessionAttribute(TrustBrokerWebAppConstants.RP_APP_NAME,relyingPartyAppVO.getApplicationName());
						
						//If the user sign-in from invitation registration link, update the user invitation information
						if(getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_REGN_SIGNIN) != null){
							updateUserInvitaion(user);
							removeSessionAttribute(TrustBrokerWebAppConstants.INVITATION_REGN_SIGNIN);
						}
						
						// Associate invited tag to the user if not already done and if fails return back.
						if(!associateInvitedTag()) return;
	
						List<TagVO> tagVOList= relyingPartyAppVO.getTags();
						Map<String, String> userDetails = new HashMap<String, String>();
						userDetails.put(TrustBrokerWebAppConstants.USER_NAME, username);
						Collections.sort(tagVOList);
						boolean isUserTagAssociatedWithTag;
						String tagName = null;
						
						for(TagVO tagVO: tagVOList) {
							if(tagVO.getVerifyAtSignIn()) {
								addSessionAttribute(TrustBrokerWebAppConstants.USER_DETAILS_MAP, userDetails);
								addSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG_NAME, tagVO.getName());
								isUserTagAssociatedWithTag = false;
								try {
									UserTagServiceResponse resp =  container.getUserTagService().queryAllUserTag(buildUserTagServiceRequest(getCurrentUserVO().getUuId(), null));
									tagName = tagVO.getName();
									if(TrustbrokerWebAppUtil.checkResponseStatus(resp)) {
										isUserTagAssociatedWithTag = isTagAlreadyExists(resp.getTagVOList(), tagName);										
																				
										if(!isUserTagAssociatedWithTag) {
											String idProofingTag = null;
											if( container.getConfigProps().getProperty(BASIC_IDP_TAG_CD_PARAM_KEY).equals(tagVO.getTagCode())) {
												idProofingTag = TrustBrokerWebAppConstants.BASIC_VALIDATION_IDPROOFING;												
											}
											if(container.getConfigProps().getProperty(BASICNQ_IDP_TAG_CD_PARAM_KEY).equals(tagVO.getTagCode())) {
												idProofingTag = TrustBrokerWebAppConstants.BASIC_NQ_VALIDATION_IDPROOFING;												
											}
											if(container.getConfigProps().getProperty(LOA3_IDP_TAG_CD_PARAM_KEY).equals(tagVO.getTagCode())) {
												idProofingTag = TrustBrokerWebAppConstants.LOA3_VALIDATION_IDPROOFING;												
											}
											if(container.getConfigProps().getProperty(LOA3NQ_IDP_TAG_CD_PARAM_KEY).equals(tagVO.getTagCode())) {
												idProofingTag = TrustBrokerWebAppConstants.LOA3_NQ_VALIDATION_IDPROOFING;												
											}											
											if(idProofingTag != null) {
												logger.debug("Starting "+idProofingTag+" process for user: " + getCurrentUserVO().getUserName());
												addSessionAttribute(TrustBrokerWebAppConstants.QUALIFYING_TAG, idProofingTag);
												redirectToView("/secure/idverification.jsf");
												return;
											}
										}										
									}
								} catch (OperationFailedException ope) {
									handleInvalidSession(ope.getErrorMessage(), ope);
									return;
								}
							}
						}
						
						setUserInSession(user);
						
						if(getSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED)!= null){
							redirectToView("/secure/migrationsuccess.jsf");
							return;
						}
						
						if(null == userRelyingPartyRelation) {
							if(TrustBrokerConstants.SHOW_CONSENT_FORM_YES.equalsIgnoreCase(relyingPartyAppVO.getShowConsentForm())) 
								redirectToView(constructConsentURL("/secure/consentpage.jsf?faces-redirect=true"));
							else
								redirection(getRelyingPartyURLWithoutConsent(),partnerId);
							return;
						} else if(TrustBrokerConstants.USER_CONSENT_NO.equalsIgnoreCase(userRelyingPartyRelation.getUserConsent())) {
							logger.debug("HomeBean:processRelyingPartyRequest() | {} is associated with the relying party but not provided the consent",
									new String[] { username });
							if(TrustBrokerConstants.SHOW_CONSENT_FORM_YES.equalsIgnoreCase(relyingPartyAppVO.getShowConsentForm()))
								redirectToView(constructConsentURL("/secure/consentpage.jsf?faces-redirect=true"));
							else
								redirection(getRelyingPartyURLWithoutConsent(),partnerId);
							return;
						}
					}
					removeSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
				}
				redirection(relyingPartyTargetURL,partnerId);
			} else if(isParamContainsRelyingPartyInfo()){ 
				//Redirect to RP since no pending action and user did not click home page link.
				redirection(relyingPartyTargetURL,relyingPartyAppVO.getPartnerId());
			}
			
			return;
		}catch(OperationFailedException opEx){
			logger.error("HomeBean:onPreinitialize() | Error while redirecting to relying party application: {} for user {}", 
					new String[]{relyingPartyTargetURL, getCurrentUserVO().getUserName(), TrustbrokerWebAppUtil.getUidFromError(opEx)}, opEx);
			handleInvalidSession(opEx.getErrorMessage(), opEx);
		}catch(Exception exception){
			ErrorMessage msg = TrustBrokerUtil.getErrorMessage(TrustBrokerConstants.OPT_00C001);
			logger.error("HomeBean:onPreinitialize() | Error while redirecting to relying party application: {} for user {}", 
					new String[]{relyingPartyTargetURL, getCurrentUserVO().getUserName(), msg.getUid()}, exception);
			handleInvalidSession(msg, exception);
		}
	}
	
	/**
	 * This method is to check if the tag with given name exists in the given user tag list
	 * 
	 * @param userTags List<TagVO>
	 * @param tagName String
	 * @return boolean
	 */
	private boolean isTagAlreadyExists(List<TagVO> userTags, String tagName) {
		boolean tagExists = false;
		if (tagName != null && userTags != null && userTags.size() > 0) {
			Iterator<TagVO> userTagsItr = userTags.iterator();
			TagVO userTag = null;
			while(userTagsItr.hasNext()) {
				userTag = userTagsItr.next();
				if(userTag.getName() != null && userTag.getName().equalsIgnoreCase(tagName)) {
					tagExists = true;
					return tagExists;
				}
			}
		}
		return tagExists;
	}
	
	private String constructConsentURL(String consentUrl) {
		String redirectURL = "";
		String relyingPartyAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
		String relyingPartyTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);

		if (relyingPartyAppId != null && relyingPartyTargetURL != null) {
			redirectURL = consentUrl + "&" + "relyingAppId=" + relyingPartyAppId
					+ "&" + TrustBrokerWebAppConstants.TARGET + "="
					+ TrustbrokerWebAppUtil.encodeURL(relyingPartyTargetURL);
		} else {
			redirectURL = consentUrl;
		}
		return redirectURL;
	}

	/**
	 * Associate the invited tag to the user since user is coming through invitation request only.
	 */
	private boolean associateInvitedTag() {
		boolean result = true;
		try {
			InvitationVO invitationVO = (InvitationVO) getSessionAttribute(TrustBrokerWebAppConstants.INVITATION) ;
			if (invitationVO != null) {

				String invTagCode = container.getConfigProps().getProperty("invited_tag_code");
				TagServiceRequest request = new TagServiceRequest();
				TagVO invitedTagVO = new TagVO();
				invitedTagVO.setTagCode(invTagCode);
				request.setTagVO(invitedTagVO);
				TagServiceResponse response = container.getTagService().getTagByTagCode(request);

				if (TrustbrokerWebAppUtil.checkResponseStatus(response)) {
					boolean isInvitegUserTagMappingExists = false;
					try {
						String invTagName = response.getTagVO().getName();						
						UserTagServiceResponse resp =container. getUserTagService().querySpecificUserTag(buildUserTagServiceRequest(
								getCurrentUserVO().getUuId(), invTagName));
						if (TrustbrokerWebAppUtil.checkResponseStatus(response)) {
							if (null != resp.getTagVOList() && resp.getTagVOList().size() > 0)
								isInvitegUserTagMappingExists = isInvUsrTagExist(resp.getTagVOList(), invTagName, invitationVO);								
							if (!isInvitegUserTagMappingExists) {
								
								UserTagServiceRequest userTagServiceRequest = buildInvUserTagRequest(
										getCurrentUserVO().getUuId(), invTagName, invitationVO);
								container.getUserTagService().addUserTag(userTagServiceRequest, null);
							}
							removeSessionAttribute(TrustBrokerWebAppConstants.INVITATION);
						} else {
							result = false;
							removeSessionWithoutRelyingPartyInfo();
							redirectToView("/views/usertagassocationfailure.jsf");
						}
					} catch (OperationFailedException ope) {
						handleInvalidSession(ope.getErrorMessage(), ope);
					}
				}
			}
		} catch (Exception exception) {
			logger.error("HomeBean:onPreinitialize() | Error while associating the user to invitation tag:" + exception);
		}
		return result;
	}
	
	/**
	 * This method is to check whether the new uer invitation tag to be created already exists for the user in the given tag list.
	 * 
	 * @param tagVOList List<TagVO>
	 * @param invitationTagName String
	 * @param invitationVO InvitationVO
	 * @return boolean
	 */
	private boolean isInvUsrTagExist(List<TagVO> tagVOList, String invitationTagName, InvitationVO invitationVO) {
		boolean usgTagExists = false;
		if(tagVOList != null && !tagVOList.isEmpty()) {
			TagVO tagVO = null;			 			
			Iterator<TagVO> tagVOItr = tagVOList.iterator();
			
			Iterator<AttributeVO> tagAttrVOItr = null;
			AttributeVO attrVO = null;
			String attrToRPId = null;
			String attrFromRPId = null;		
			String dirInvFlag = null;	
			final String toRPIDAttrNm = container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_TO_APP_ATTR_KEY);
			final String fromRPIDAttrNm = container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_FRM_APP_ATTR_KEY);
			final String dirInvAttrNm = container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_KEY);
			final String directInviteYesFlag = container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_YES_FLG);
			final String directInviteNoFlag = container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_NO_FLG);
			//Loop through the tag list got from esso for the user
			while(tagVOItr.hasNext()) {
				attrToRPId = null;
				attrFromRPId = null;		
				dirInvFlag = null;
				tagVO = tagVOItr.next();
				if(invitationTagName.equalsIgnoreCase(tagVO.getName()) && tagVO.getAttributeVOList() != null) {
					tagAttrVOItr = tagVO.getAttributeVOList().iterator();
					//Loop through tag attributes to get the from app, to app and direct invite flag attributes
					while(tagAttrVOItr.hasNext()) {
						attrVO = tagAttrVOItr.next();							
						if(toRPIDAttrNm.equals(attrVO.getName())) {
							attrToRPId = attrVO.getValue();
						} else if(fromRPIDAttrNm.equals(attrVO.getName())) {
							attrFromRPId = attrVO.getValue();
						} else if(dirInvAttrNm.equals(attrVO.getName())) {
							dirInvFlag = attrVO.getValue();
						}												
					}
					//If direct invites is Yes, then check if the to app id (RP id) exists
					if(directInviteYesFlag.equalsIgnoreCase(dirInvFlag) && attrToRPId != null && attrToRPId.equals(invitationVO.getRpAppId()) 
							&& StringUtils.isBlank(invitationVO.getCreatedByRPAppId())) {
						usgTagExists = true;
						break;
						////If direct invites is No, then check if the to app id (RP id) and from app id (created by app id) exists
					} else if (directInviteNoFlag.equalsIgnoreCase(dirInvFlag) && 
							attrToRPId != null && attrToRPId.equals(invitationVO.getRpAppId())
							&& attrFromRPId != null && attrFromRPId.equals(invitationVO.getCreatedByRPAppId())) {
						usgTagExists = true;
						break;
					}	
				}				
			}
		}
		
		return usgTagExists;
	}
	
	/**
	 * This method is to build the user tag service request object from the given parameters. The tag attributes are built from the invitation object
	 * 
	 * @param uuid String
	 * @param tagName String
	 * @param invitationVO InvitationVO
	 * @return UserTagServiceRequest
	 */
	private UserTagServiceRequest buildInvUserTagRequest(String uuid, String tagName, InvitationVO invitationVO) {
		UserTagServiceRequest userTagServiceRequest = buildUserTagServiceRequest(uuid, tagName);
			
		if(invitationVO != null) {
			TagVO tagVO = new TagVO();
			tagVO.setTagCode(tagName);
			
			List<AttributeVO> attrVOList = new ArrayList<AttributeVO>();
			AttributeVO attrVO = new AttributeVO();
			attrVO.setName(container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_TO_APP_ATTR_KEY));
			attrVO.setValue(invitationVO.getRpAppId());
			attrVOList.add(attrVO);
			
			attrVO = new AttributeVO();
			String directInviteFlag = null;
			if(StringUtils.isBlank(invitationVO.getCreatedByRPAppId())) {
				directInviteFlag = container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_YES_FLG);
				attrVO.setName(container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_FRM_APP_ATTR_KEY));
				attrVO.setValue(invitationVO.getRpAppId());
			} else {
				directInviteFlag = container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_NO_FLG);
				attrVO.setName(container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_FRM_APP_ATTR_KEY));
				attrVO.setValue(invitationVO.getCreatedByRPAppId());
			}
			attrVOList.add(attrVO);
			
			attrVO = new AttributeVO();
			attrVO.setName(container.getConfigProps().getProperty(TrustBrokerWebAppConstants.INV_TAG_DIR_INV_ATTR_KEY));
			attrVO.setValue(directInviteFlag);
			attrVOList.add(attrVO);
			
			tagVO.setAttributeVOList(attrVOList);
			List<TagVO> tagVOList = new ArrayList<TagVO>();
			tagVOList.add(tagVO);
			userTagServiceRequest.setTagVOList(tagVOList);
		}
		return userTagServiceRequest;
	}

	/**
	 * Gets the faces context
	 *
	 * @return current FacesContext otherwise
	 */
	@Override
	public FacesContext getFacesContext() {
		if (FacesContext.getCurrentInstance() != null) {
			return FacesContext.getCurrentInstance();
		} else {
			if (super.getFacesContext() != null) {
				return super.getFacesContext();
			}
		}
		return super.getFacesContext();
	}

	
	public void agreeConsent() {
		removeSessionAttribute(TrustBrokerWebAppConstants.RP_APP_NAME);
		try {
			UserVO userVO = getCurrentUserVO();
			
			if(userVO == null || userVO.getUserName() == null){
				//Creating the user session again, it has been seen that sometimes session is lost so creating again the user session. 
				// TO-DO - Find the root cause why user is lost from session, or is being deleted from session somewhere.
				createUserSession(); 
				userVO = getCurrentUserVO();
			}
			
			String userName = userVO.getUserName();
			String relyingAppId = (String)getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
			String relyingPartyTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
			String action = (String) getSessionAttribute(TrustBrokerWebAppConstants.ACTION);
			String status = (String) getSessionAttribute(TrustBrokerWebAppConstants.STATUS);
			String email=userVO.getEmailAddress();
			String inboundemail=(String) getSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO);
			//Inbound sso case 
			boolean isModifedParamadded=false;
			if(StringUtils.isNotBlank(inboundemail))
			{//Email modified case
				if(!inboundemail.equalsIgnoreCase(email))
				relyingPartyTargetURL = relyingPartyTargetURL + (relyingPartyTargetURL.contains("?")? "&" : "?") +
				TrustBrokerWebAppConstants.EMAIL_MODOFIED + "=" + TrustBrokerWebAppConstants.YES;
				else
					relyingPartyTargetURL = relyingPartyTargetURL + (relyingPartyTargetURL.contains("?")? "&" : "?") +
					TrustBrokerWebAppConstants.EMAIL_MODOFIED + "=" + TrustBrokerWebAppConstants.NO;
				isModifedParamadded=true;
			}
			if(!isModifedParamadded&&getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_MODOFIED) != null ) {
				relyingPartyTargetURL = relyingPartyTargetURL + (relyingPartyTargetURL.contains("?")? "&" : "?") +
						TrustBrokerWebAppConstants.EMAIL_MODOFIED + "=" + getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_MODOFIED );
			}
			// End Inbound sso changes.
			if(getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE) != null && 
					!relyingPartyTargetURL.contains(TrustBrokerWebAppConstants.INVITATION_CODE)) {
				relyingPartyTargetURL = relyingPartyTargetURL + (relyingPartyTargetURL.contains("?")? "&" : "?") +
						TrustBrokerWebAppConstants.INVITATION_CODE + "=" + getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE);
			}
			
			UserRelyingPartyRelation userRelyingPartyRelation = container.getUserService()
					.getAssociationBetweenUserAndRelyingApp(userVO.getUuId(), relyingAppId);
			userRelyingPartyRelation.setUserConsent(TrustBrokerConstants.USER_CONSENT_YES);

			logger.debug("HomeBean:agreeConsent() | Processing agree consent for user ='" + userName + "' with relying party ='" + relyingAppId +
					"' and TARGET URL='" + relyingPartyTargetURL+ "'");
			
			container.getUserRelyingPartyRelationService().updateUserRelyingPartyRelation(userRelyingPartyRelation);
			container.getUserService().saveUserConsent(userRelyingPartyRelation.getRelyingPartyApp(),userRelyingPartyRelation.getUser());
			redirectToRelyingParty(relyingPartyTargetURL, action, status, relyingAppId);
		} catch (OperationFailedException ope) {
			handleInvalidSession(ope.getErrorMessage(), ope);
		}
	}
	
	private String getRelyingPartyURLWithoutConsent() {
		UserVO userVO = getCurrentUserVO();
		String relyingPartyTargetURL = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		String email=userVO.getEmailAddress();
		String inboundemail=(String) getSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO);
		//Inbound sso case 
		boolean isModifedParamadded=false;
		if(StringUtils.isNotBlank(inboundemail))
		{//Email modified case
			if(!inboundemail.equalsIgnoreCase(email))
			relyingPartyTargetURL = relyingPartyTargetURL + (relyingPartyTargetURL.contains("?")? "&" : "?") +
			TrustBrokerWebAppConstants.EMAIL_MODOFIED + "=" + TrustBrokerWebAppConstants.YES;
			else
				relyingPartyTargetURL = relyingPartyTargetURL + (relyingPartyTargetURL.contains("?")? "&" : "?") +
				TrustBrokerWebAppConstants.EMAIL_MODOFIED + "=" + TrustBrokerWebAppConstants.NO;
			isModifedParamadded=true;
		}
		if(!isModifedParamadded&&getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_MODOFIED) != null ) {
			relyingPartyTargetURL = relyingPartyTargetURL + (relyingPartyTargetURL.contains("?")? "&" : "?") +
					TrustBrokerWebAppConstants.EMAIL_MODOFIED + "=" + getSessionAttribute(TrustBrokerWebAppConstants.EMAIL_MODOFIED );
		}
		// End Inbound sso changes.
		if(getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE) != null && 
				!relyingPartyTargetURL.contains(TrustBrokerWebAppConstants.INVITATION_CODE)) {
			relyingPartyTargetURL = relyingPartyTargetURL + (relyingPartyTargetURL.contains("?")? "&" : "?") +
					TrustBrokerWebAppConstants.INVITATION_CODE + "=" + getSessionAttribute(TrustBrokerWebAppConstants.INVITATION_CODE);
		}
		return relyingPartyTargetURL;
	}
	
	public String disAgreeConsent() {
		
		String relyingAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID).toString();
		String targetUrl = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL).toString();
		String invitationToken = null;
		
		removeSessionAttribute(TrustBrokerWebAppConstants.RP_APP_NAME);

		String redirectedPage = tbResources.getString("LogOutPage");
		
		if(targetUrl.contains(TrustBrokerWebAppConstants.INVITATION_CODE)) {
			invitationToken = targetUrl.substring(targetUrl.indexOf("=") + 1);
			targetUrl = targetUrl.substring(0, targetUrl.indexOf("?"));
		}
		
		if (StringUtils.isNotBlank(relyingAppId) && StringUtils.isNotBlank(targetUrl)){
			redirectedPage = HttpUtils.addParameterToURL(redirectedPage, TrustBrokerConstants.RELYING_APP_ID_PARAM, relyingAppId);
			redirectedPage = HttpUtils.addParameterToURL(redirectedPage, TrustBrokerConstants.TARGET, targetUrl);
			
			if(StringUtils.isNotBlank(invitationToken)){
				redirectedPage = HttpUtils.addParameterToURL(redirectedPage, TrustBrokerWebAppConstants.INVITATION_CODE, invitationToken);
			}
		}
		
		UserVO userVO = getCurrentUserVO();
		String email = userVO.getEmailAddress();
		String inboundemail = (String) getSessionAttribute(TrustBrokerWebAppConstants.INBOUND_SSO);
		
		//Inbound sso case 
		if(StringUtils.isNotBlank(inboundemail)) {
			//Email modified case
			if(!inboundemail.equalsIgnoreCase(email)) {
				redirectedPage = HttpUtils.addParameterToURL(redirectedPage, TrustBrokerWebAppConstants.EMAIL_MODOFIED, TrustBrokerWebAppConstants.YES);
			} else {
				redirectedPage = HttpUtils.addParameterToURL(redirectedPage, TrustBrokerWebAppConstants.EMAIL_MODOFIED, TrustBrokerWebAppConstants.NO);
			}
		}
		
		getFacesContext().getExternalContext().invalidateSession();
		return redirectedPage;
	}

	public void agreeTermsConditions(){

		try{
			logger.debug("HomeBean:agreeTermsConditions() | Accepting terms and condition for user {}",
					new String[] { getCurrentUserVO().getUserName() });

			container.getUserService().updateUserAcceptedTermsAndConditionVersion(
					(TermsAndConditionsVO) getSessionAttribute(TrustBrokerWebAppConstants.TERMS_AND_CONDITON), getCurrentUserVO());
			getCurrentUserVO().setTermsCondition(TrustBrokerWebAppConstants.YES);
			removeSessionAttribute(TrustBrokerWebAppConstants.TERMS_AND_CONDITON);
			addSessionAttribute(TrustBrokerWebAppConstants.TERMS_CONDITON_ACCEPTED, true);

			redirectToView(getHomePageURIWithAlias());
			return;
		} catch (OperationFailedException ope) {
			logger.error("Error while excepting terms and condition for user: {}", 
					new String[]{getCurrentUserVO().getUserName(), TrustbrokerWebAppUtil.getUidFromError(ope)}, ope);
			handleInvalidSession(ope.getErrorMessage(), ope);
		}catch(Exception ioEx){
			logger.error("HomeBean:agreeTermsConditions() | Error while redirecting away from terms and condition for user '"
					+ getCurrentUserVO().getUserName() + "'", ioEx);
		}
	}

	/**
	 * Continue after migration process.
	 */
	public void migrationSuccess(){
		removeSessionAttribute(TrustBrokerWebAppConstants.USER_MIGRATED);
		redirectToView(getHomePageURIWithAlias());
	}

	/**
	 * Sets the UserVO in session
	 */
	private void setUserInSession(UserVO user) {
		if(getCurrentUserVO() != null){
			UserVO userInsession = getCurrentUserVO();
			user.setUserId(userInsession.getUserId());
			user.setIsTncAccepted(userInsession.getIsTncAccepted());
			user.setTncAgreementVersion(userInsession.getTncAgreementVersion());
			user.setUserRoleCd(userInsession.getUserRoleCd());
		}
		setCurrentUserVO(user);
	}

	public TermsAndConditionsVO getTermsAndConditionVO() {
		return termsAndConditionVO;
	}

	public void setTermsAndConditionVO(TermsAndConditionsVO termsAndConditionVO) {
		this.termsAndConditionVO = termsAndConditionVO;
	}

	public boolean isTncAccepted() {
		return tncAccepted;
	}

	public void setTncAccepted(boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}

	public boolean isPrivacyPolicyAccepted() {
		return privacyPolicyAccepted;
	}

	public void setPrivacyPolicyAccepted(boolean privacyPolicyAccepted) {
		this.privacyPolicyAccepted = privacyPolicyAccepted;
	}


	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String constructRedirectUrl(String targetUrl)
	{
		if (null != getSessionAttribute("showDOB")
				&& (Boolean) getSessionAttribute("showDOB")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "dobupdated",
					"y");
		}
		if (null != getSessionAttribute("showAddress")
				&& (Boolean) getSessionAttribute("showAddress")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"addressupdated", "y");
		}
		if (null != getSessionAttribute("showMobilePhone")
				&& (Boolean) getSessionAttribute("showMobilePhone")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"mobilephoneupdated", "y");
		}
		if (null != getSessionAttribute("ShowEmail")
				&& (Boolean) getSessionAttribute("ShowEmail")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "emailupdated",
					"y");
		}
		return targetUrl;
	}
	
	/*
	 * Post successful authentication event data to analytics server
	 */
	private void postSuccessfullAuthenticationEventAnalytics(){
		Map<String, String> postEventData = new HashMap<String, String>();
		String rpAppId = getRelyingPartyAppId() != null ? getRelyingPartyAppId() : tbResources.getString("TB_APP_ID");
		postEventData.put(TrustBrokerConstants.EVAR_4, "OptumID:" + rpAppId);
		postEventData.put(TrustBrokerConstants.PAGE_NAME, "Home");
		postEventData.put(TrustBrokerConstants.EVENTS_TAG, TrustBrokerConstants.EVENT_11);
		try {
		container.getAnalyticsUtils().postAnalyticsDataRequest(getVidCookieValue(), postEventData);
		} catch (IOException ioe) {
			logger.error("Error while posting analytics: " + ioe);
		}
	}
}
