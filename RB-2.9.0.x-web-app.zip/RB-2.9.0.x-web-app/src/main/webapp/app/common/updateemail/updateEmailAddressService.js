'use strict';

var indexApp = angular.module("common.modules");

indexApp.service("updateEmailAddressService", [ "$http", function($http) {

	this.update = function(vo) {

		return $http.post("/tb/services/secure/rest/verifyCodesUpdate/update", vo);

	};

	this.getUpdateEmailContext = function() {

    	return $http.get("/tb/services/secure/rest/verifyCodesUpdate/getUpdateEmailContext");

    };

}]);
