package com.optum.trustbroker.managebean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.PhaseId;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.auditlogging.SecurityLoggingUtil;
import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.IrmLoggingUtil;
import com.optum.trustbroker.util.PropertyLoader;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.AddressVO;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryRelyingPartyResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.QueryTierResponse;
import com.uhg.iam.esso.schemas.xsd._2013._12.RelyingParty;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierAttribute;
import com.uhg.iam.esso.schemas.xsd._2013._12.TierConfig;

@ManagedBean(name = "onDemandStepUpBean")
@ViewScoped
public class OnDemandStepUpBean extends AbstractBackingBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@ManagedProperty(value = "#{userVO}")
	private UserVO userVO;
	@ManagedProperty(value = "#{addressVO}")
	private AddressVO addressVO;
	private String dateOfBirth;
	private Map<String, String> parameterMap;
	private List<SelectItem> statesList;
	private String errorMsg;
	private String warningMsg;
	private String confirmEmailAddress;
	//private static String onDemandStepupEmailconfirmationPage = "ondemandstepupemailconfirmation.jsf";
	private String emailVerificationCode;
	private String pwd;
	private static int yobLimit = 2;
	private final String INCORRECT_YEAR_OF_BIRTH_COUNT = "_INC_YEAR_OF_BIRTH";

	/**
	 * @return the confirmEmailAddress
	 */
	public String getConfirmEmailAddress() {
		return confirmEmailAddress;
	}

	/**
	 * @param confirmEmailAddress
	 *            the confirmEmailAddress to set
	 */
	public void setConfirmEmailAddress(String confirmEmailAddress) {
		this.confirmEmailAddress = confirmEmailAddress;
	}

	private String emailAddress;
	private boolean emailShared = true;
	private boolean emailWarning = false;

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public AddressVO getAddressVO() {
		return addressVO;
	}

	public void setAddressVO(AddressVO addressVO) {
		this.addressVO = addressVO;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Map<String, String> getParameterMap() {
		return parameterMap;
	}

	public void setParameterMap(Map<String, String> parameterMap) {
		this.parameterMap = parameterMap;
	}

	public List<SelectItem> getStatesList() {
		return statesList;
	}

	public void setStatesList(List<SelectItem> statesList) {
		this.statesList = statesList;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getWarningMsg() {
		return warningMsg;
	}

	public void setWarningMsg(String warningMsg) {
		this.warningMsg = warningMsg;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the emailShared
	 */
	public boolean isEmailShared() {
		return emailShared;
	}

	/**
	 * @param emailShared
	 *            the emailShared to set
	 */
	public void setEmailShared(boolean emailShared) {
		this.emailShared = emailShared;
	}

	/**
	 * @return the emailVerificationCode
	 */
	public String getEmailVerificationCode() {
		return emailVerificationCode;
	}

	/**
	 * @param emailVerificationCode
	 *            the emailVerificationCode to set
	 */
	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}

	/**
	 * @return the pwd
	 */
	public String getPwd() {
		return pwd;
	}

	/**
	 * @param pwd
	 *            the pwd to set
	 */
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	/**
	 * @return the emailWarning
	 */
	public boolean isEmailWarning() {
		return emailWarning;
	}

	/**
	 * @param emailWarning
	 *            the emailWarning to set
	 */
	public void setEmailWarning(boolean emailWarning) {
		this.emailWarning = emailWarning;
	}

	@PostConstruct
	public void init() {
		captureRelyingPartyInfo(false);
		HttpServletRequest request = getServletRequest();
		parameterMap = request.getParameterMap();

		if (parameterMap.containsKey(TrustBrokerWebAppConstants.DOB)
				&& TrustBrokerWebAppConstants.YES
						.equalsIgnoreCase(getRequestParameter(TrustBrokerWebAppConstants.DOB)))
			addSessionAttribute(TrustBrokerWebAppConstants.ON_DEMAND_SHOW_DOB,
					true);
		if (parameterMap.containsKey(TrustBrokerWebAppConstants.ADDRESS)
				&& TrustBrokerWebAppConstants.YES
						.equalsIgnoreCase(getRequestParameter(TrustBrokerWebAppConstants.ADDRESS)))
			addSessionAttribute(TrustBrokerWebAppConstants.SHOW_ADDRESS, true);
		if (parameterMap.containsKey(TrustBrokerWebAppConstants.MOBILE_PHONE)
				&& TrustBrokerWebAppConstants.YES
						.equalsIgnoreCase(getRequestParameter(TrustBrokerWebAppConstants.MOBILE_PHONE)))
			addSessionAttribute(TrustBrokerWebAppConstants.SHOW_MOB_PHONE, true);

		if (parameterMap.containsKey(TrustBrokerWebAppConstants.EMAIL_PARAM)
				&& TrustBrokerWebAppConstants.YES
						.equalsIgnoreCase(getRequestParameter(TrustBrokerWebAppConstants.EMAIL_PARAM)))
			addSessionAttribute(TrustBrokerWebAppConstants.SHOW_EMAIL, true);

		getSessionMap().put("usernameFromRequestHeader",
				request.getHeader(TrustBrokerWebAppConstants.USER_NM_HEADER));
		String usernameFromRequestHeader = (String) getSessionMap().get(
				"usernameFromRequestHeader");
		// String usernameFromRequestHeader = "Testemail3";
		logger.debug("Initiating on demand step up for user: "
				+ usernameFromRequestHeader);

		if (getSessionAttribute(TrustBrokerWebAppConstants.ON_DEMAND_EMAIL_MSG) != null) {

			setErrorMsg(getSessionAttribute(
					TrustBrokerWebAppConstants.ON_DEMAND_EMAIL_MSG).toString());
			removeSessionAttribute(TrustBrokerWebAppConstants.ON_DEMAND_EMAIL_MSG);

		}

		processRP();
		UserRetrievalServiceResponse userRetrievalResponse = null;
		if (StringUtils.isNotBlank(usernameFromRequestHeader)) {
			try {
				userRetrievalResponse = container.getUserService()
						.fetchUserDetailsForSession(usernameFromRequestHeader);
				if (userRetrievalResponse != null
						&& userRetrievalResponse.getUser() != null
						&& userRetrievalResponse
								.getExecutionStatus()
								.getStatusCd()
								.equals(TrustBrokerConstants.SUCCESS_CODE_VALUE)) {
					setUserVO(userRetrievalResponse.getUser());
					if (null != getUserVO()) {
						setCurrentUserVO(getUserVO());
						if (null != getUserVO().getDob())
							setDateOfBirth(DateUtil.formatDate(getUserVO()
									.getDob(), "MM/dd/yyyy"));
						if (null != getUserVO().getEmailAddress()) {
							setEmailAddress(getUserVO().getEmailAddress());
							setConfirmEmailAddress(getUserVO()
									.getEmailAddress());
						}
						boolean isAddressMatched = false;
						if (null != getUserVO().getAddresses()) {
							AddressVO updatedAddressVO = null;
							Iterator<AddressVO> addressIterator = getUserVO()
									.getAddresses().iterator();
							while (addressIterator.hasNext()) {
								AddressVO essoAddressVO = addressIterator
										.next();
								if (null != essoAddressVO.getIsPrimaryAddress()
										&& essoAddressVO
												.getIsPrimaryAddress()
												.equalsIgnoreCase(
														TrustBrokerConstants.ADDRESS_TYPE_WORK)) {
									updatedAddressVO = essoAddressVO;
									isAddressMatched = true;
									break;
								}
							}
							if (!isAddressMatched)
								updatedAddressVO = getUserVO().getAddresses()
										.get(0);
							setAddressVO(updatedAddressVO);
							setCurrentUserVO(getUserVO());
						}
					}
				}
				Map<String, String> statesMap = container.getReferenceService()
						.fetchStates();
				statesList = new ArrayList<SelectItem>();
				SortedSet<String> stateSortedByKey = new TreeSet<String>(
						statesMap.keySet());
				for (String key : stateSortedByKey) {
					SelectItem selectItem = new SelectItem(key, key);
					statesList.add(selectItem);
				}
			}
			catch (OperationFailedException ofe) {
				logger.error("An error occureed while retrieving the user's profile : {}",
						new String[] { usernameFromRequestHeader, TrustbrokerWebAppUtil.getUidFromError(ofe) }, ofe);
				setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(
						container.getErrorMessageSource(), getSupportContactInfo()) : ofe.getMessage());
			}
			catch (Exception e) {
				logger.error("An error occureed while retrieving the user's profile : {}", new String[] { usernameFromRequestHeader }, e);
				setErrorMsg("An error occureed while retrieving the user's profile");
			}
		}
	}

	public void processRP() {
		QueryRelyingPartyResponse queryRelyingPartyResponse = new QueryRelyingPartyResponse();
		queryRelyingPartyResponse = container.getConfigService()
				.queryRelyingParty(
						getSessionAttribute(
								TrustBrokerWebAppConstants.RELYING_APP_ALIAS)
								.toString());
		QueryTierResponse queryTierResponse = new QueryTierResponse();
		if (queryRelyingPartyResponse != null
				&& queryRelyingPartyResponse.getRelyingParty() != null) {
			RelyingParty rp = queryRelyingPartyResponse.getRelyingParty();
			if (rp.getTiers() != null && rp.getTiers().size() > 0) {
				TierConfig tierConfig = rp.getTiers().get(0);
				userVO.setTierId(tierConfig.getTierId());
				queryTierResponse = container.getConfigService().queryTier(
						tierConfig.getTierId());
				if (queryTierResponse != null
						&& queryTierResponse.getTierDefinition() != null) {
					List<TierAttribute> tierAttributes = queryTierResponse
							.getTierDefinition().getTierAttributes();
					for (Iterator<TierAttribute> iterator = tierAttributes
							.iterator(); iterator.hasNext();) {
						TierAttribute tierAttribute = iterator.next();
						if (tierAttribute.getName().equalsIgnoreCase(
								TrustBrokerConstants.EMAIL_ADDRESS)) {
							if (tierAttribute.isUnique()) {
								emailShared = false;
							}

						}
					}
				}

			}
		}
	}

	public boolean validateEmailFields(String email, String confirmEmailAddress) {
		boolean result = true;
		if ((!StringUtils.isEmpty(email) && !email
				.equalsIgnoreCase(confirmEmailAddress))) {
			addFacesMessage("onDemandStepUpFormId:confirmEmail",
					tbResources.getString("emailDoNotMatch"));
			result = false;
		}
		return result;

	}
public void checkPhone(ValueChangeEvent event) {
		
		PhaseId phaseId = event.getPhaseId();
				
		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			
			   boolean valid=validatePhone();
			   if ( !valid) 
				  addFacesMessage("onDemandStepUpFormId:mobilePhone", tbResources.getString("invalidMobileMsg"));
			
		}
	}
	private boolean validatePhone() {
		boolean validPhone = true;	
		
		String mobileNum = userVO.getPhoneNumber();
		
		if(!StringUtils.isEmpty(mobileNum)) {
			if(mobileNum.length() < 13) {
				addFacesMessage("onDemandStepUpFormId:mobilePhone",
						tbResources.getString("invalidMobileMsg"));
				return false;
			}
			String number = mobileNum.substring(1, 4) + mobileNum.substring(5, 8)
					+ mobileNum.substring(9, 13);
			if(StringUtils.isEmpty(number.replace("_", ""))) {
				
				addFacesMessage("onDemandStepUpFormId:mobilePhone",
						tbResources.getString("invalidMobileMsg"));
				return false;
			}
			if(! StringUtils.isNumeric(number)) {
				addFacesMessage("onDemandStepUpFormId:mobilePhoner",
						tbResources.getString("invalidMobileMsg"));
				return false;
			}
		}
		return validPhone;
	}

	public boolean validateEmailAddress(String email) {
		boolean result = true;
		removeSessionAttribute("warnmsg");
		if (StringUtils.isEmpty(email)) {
			addFacesMessage("onDemandStepUpFormId:email",
					tbResources.getString("rpDoNotSupportBlankEmail"));
			result = false;
		} else if (!TBUtil.validateEmailId(email)) {
			addFacesMessage("onDemandStepUpFormId:email",
					tbResources.getString("invalidEmailAddress"));
			result = false;
		} else if (!isEmailShared()
				&& container.getUserService().isEmailExists(email)) {

			addFacesMessage("onDemandStepUpFormId:email",
					tbResources.getString("rpDoNotDuplicateNonMandatoryEmail"));
			result = false;

		} else if (isEmailShared()
				&& container.getUserService().isEmailExists(email)) {
			addFacesMessage("onDemandStepUpFormId:email",
					tbResources.getString("duplicateEmailWarn"));
			addSessionAttribute("warnmsg", true);
		}
		return result;

	}

	public void checkEmailAddress(ValueChangeEvent event) {
		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();
			validateEmailAddress(event.getNewValue().toString());
		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
			boolean result = TBUtil.validateEmailId(event.getNewValue()
					.toString());
			logger.debug("result value in email: " + result);
			if (!result) {
				addFacesMessage("onDemandStepUpFormId:email",
						tbResources.getString("invalidEmailAddress"));
			}
		}
		logger.debug("getEmailExistsMsg()");
	}

	public void saveUserProfile() {
		logger.debug("Saving user profile during on demand step up process");
		boolean result = true;
		setErrorMsg("");
		setWarningMsg("");
		String targetUrl = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);
		userVO.setEmailAddress(emailAddress);
		userVO.setConfirmEmailAddress(confirmEmailAddress);
		if (null != getSessionAttribute(TrustBrokerWebAppConstants.SHOW_EMAIL)
				&& (Boolean) getSessionAttribute(TrustBrokerWebAppConstants.SHOW_EMAIL)) {
			if (!validateEmailAddress(emailAddress))
				result = false;
			if (!validateEmailFields(emailAddress, confirmEmailAddress))
				result = false;
		}
		if (null != getSessionAttribute("showDOB")
				&& (Boolean) getSessionAttribute("showDOB")) {
			if (validateDateOfBirth()) {
				userVO.setIsCoppaAccepted(TrustBrokerWebAppConstants.YES);
				userVO.setDob(DateUtil.parseDate(dateOfBirth,
						DateUtil.EXT_DATE_FORMAT));
			} else
				result = false;
		}

		if (StringUtils.isNotBlank(getAddressVO().getZip())
				&& (!(getAddressVO().getZip().matches("[0-9]+")) || getAddressVO()
						.getZip().length() < 5)) {
			addFacesMessage("onDemandStepUpFormId:zip",
					tbResources.getString("invalidZipCode"));
			result = false;
		}

		if (result) {

			targetUrl = constructTargetUrl(targetUrl);
			try {

				UserRetrievalServiceResponse userRetrievalResponse = container
						.getUserService().fetchUserDetailsForSession(
								getUserVO().getUserName());
				UserVO essoUserVO = userRetrievalResponse.getUser();
				UserVO trustBrokerUserVO = null;
				trustBrokerUserVO = container.getUserService()
						.fetchUserByUUID(getCurrentUserVO().getUuId())
						.getUser();

				UserProfileServiceRequest request = new UserProfileServiceRequest();
				request.setUser(getUserVO());
				request.setOldUser(essoUserVO);
				UserProfileServiceResponse response = container.getUserService().modifyUser(request, false);
				if (getUserVO().getEmailAddress() != null
						&& !(getUserVO().getEmailAddress()
								.equalsIgnoreCase(essoUserVO.getEmailAddress()))) {
					String rpAppId = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID);
					setCurrentUserVO(container
							.getUserService()
							.fetchUserDetailsForSession(
									response.getUser().getUserName()).getUser());
					VerifyCodesContext ctx = new VerifyCodesContext();
					ctx.getViewChannels().add(
							CommunicationChannel.PRIMARY_EMAIL);
					ctx.getSendChannels().add(
							CommunicationChannel.PRIMARY_EMAIL);
					ctx.setHideUpdateButtons(true);
					ctx.setShowDeviceRegistration(false);
					ctx.setNextView("/secure/ondemandstepupemailconfirmation.jsf");
					ctx.setUserVO(getCurrentUserVO());
					getSessionMap().put(VerifyCodesContext.SESSION_NAME, ctx);
					redirectToView(VerifyCodesBean.VERIFY_CODES_VIEW);
					return;
				}

				if (!TrustbrokerWebAppUtil.checkResponseStatus(response)) {
					if (response.getReasonCode() != null
							&& TrustBrokerConstants.OPT_ERR_001.equals(response
									.getReasonCode())) {
						setErrorMsg("");
						setWarningMsg(response.getReasonMessage());
					} else
						setErrorMsg(response.getReasonMessage());
				} else {
					SecurityLoggingUtil
							.info("User Account Modifications",
									SecurityEventType.E3_MODIFY,
									getServletRequest(),
									getUserVO().getUserName(),
									"Security Audit Event|ModifyUserProfile:SUCCESS | User Profile Modified during On Demand Step Up, OnDemandStepUpBean:saveUserProfile()",
									SecurityEventResult.SUCCESS,
									getRelyingPartyAppId(),
									SecuritySubEventType.E3_MODIFY_PROFILE);
					redirectToRelyingParty(targetUrl, null, null,
							(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
				}
			}
			catch (OperationFailedException ofe) {
				logger.error(" An error occureed while updating user profile for user : {}",
						new String[] { getCurrentUserVO().getUserName(), TrustbrokerWebAppUtil.getUidFromError(ofe) }, ofe);
				setErrorMsg(ofe.getErrorMessage() != null ? ofe.getErrorMessage().getEndUserMessage(container.getErrorMessageSource(),
						getSupportContactInfo()) : ofe.getMessage());
			}
			catch (Exception e) {
				logger.error(" An error occureed while updating user profile for user : {}",
						new String[] { getCurrentUserVO().getUserName() }, e);
				setErrorMsg("User Profile update is unsuccessful");
			}
		}
	}

	public void checkdateOfBirth(ValueChangeEvent event) {

		PhaseId phaseId = event.getPhaseId();

		if (phaseId.equals(PhaseId.ANY_PHASE)) {
			event.setPhaseId(PhaseId.UPDATE_MODEL_VALUES);
			event.queue();

		} else if (phaseId.equals(PhaseId.UPDATE_MODEL_VALUES)) {
				boolean resultDob = DateUtil.validateDate(dateOfBirth);
				if (!resultDob)
					addFacesMessage("onDemandStepUpFormId:dob",
							tbResources.getString("dobFormatErrorMsg"));
			
		}
	}

	private boolean checkYearOfBirthEntryLimit() {
		Integer yobCount = this.getIncorrectYobCount();
		if (yobCount >= yobLimit) {
			String idStr = "onDemandStepUpFormId:dob";
			addFacesMessage(idStr, tbResources.getString("ageNotElibleMsg"));
			return false;
		} else {
			return true;
		}
	}

	private void incrementIncorrectYobCount() {
		Integer yobCount = getIncorrectYobCount();
		yobCount++;
		this.addSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT, yobCount);
	}

	private Integer getIncorrectYobCount() {
		Integer yobCount = null;
		Object incorrectYobCountObj = getSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT);
		if (incorrectYobCountObj != null)
			yobCount = (Integer) incorrectYobCountObj;
		else {
			yobCount = new Integer(0);
			this.addSessionAttribute(INCORRECT_YEAR_OF_BIRTH_COUNT, yobCount);
		}
		return yobCount;
	}

	public boolean validateDateOfBirth() {
		boolean result = true;

		boolean isDateValid = true;

		if (StringUtils.isNotBlank(dateOfBirth))
			isDateValid = DateUtil.validateDate(dateOfBirth);

		if (!isDateValid) {
			addFacesMessage("onDemandStepUpFormId:dob",
					tbResources.getString("dobFormatErrorMsg"));
			result = false;
		} else if (StringUtils.isNotBlank(dateOfBirth)) {
			int minAgeLimit = Integer.parseInt(PropertyLoader.getInstance()
					.getPortalConfigValue("userMinAgeLimit"));
			userVO.setDob(DateUtil.parseDate(dateOfBirth,
					DateUtil.EXT_DATE_FORMAT));
			boolean isLimitStillValid = checkYearOfBirthEntryLimit();
			if (isLimitStillValid) {
				SimpleDateFormat dobFormat = new SimpleDateFormat(DateUtil.EXT_DATE_FORMAT);
				Integer ageDifference = DateUtil.validateAge(dateOfBirth,
						minAgeLimit, dobFormat);
				// if (DateUtil.validateAge(dateOfBirth, minAgeLimit)) {
				if (ageDifference != DateUtil.OVERAGE) {
					incrementIncorrectYobCount();
					isLimitStillValid = checkYearOfBirthEntryLimit();
					if (isLimitStillValid) {
						if (ageDifference == DateUtil.OVERAGEEXEEDED)
							addFacesMessage(
									"onDemandStepUpFormId:dob",
									tbResources
											.getString("dobAgeConstraintOverMsg"));
						else if (ageDifference == DateUtil.FUTURE)
							addFacesMessage(
									"onDemandStepUpFormId:dob",
									tbResources
											.getString("dobAgeConstraintFutureMsg"));
						else
							addFacesMessage("onDemandStepUpFormId:dob",
									tbResources
											.getString("dobAgeConstraintMsg"));
					} else {
						handleInvalidSession(
								TrustBrokerUtil
										.getErrorMessage(TrustBrokerConstants.OPT_00K000),
								null);
						return false;
					}
					result = false;
				}
			} else
				result = false;
		}
		return result;
	}

	public void cancel() {

		String targetUrl = (String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_URL);

		if (null != getSessionAttribute(TrustBrokerWebAppConstants.ON_DEMAND_SHOW_DOB)
				&& (Boolean) getSessionAttribute(TrustBrokerWebAppConstants.ON_DEMAND_SHOW_DOB)) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "dobupdated",
					"n");
		}
		if (null != getSessionAttribute(TrustBrokerWebAppConstants.SHOW_ADDRESS)
				&& (Boolean) getSessionAttribute(TrustBrokerWebAppConstants.SHOW_ADDRESS)) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"addressupdated", "n");
		}
		if (null != getSessionAttribute(TrustBrokerWebAppConstants.SHOW_MOB_PHONE)
				&& (Boolean) getSessionAttribute(TrustBrokerWebAppConstants.SHOW_MOB_PHONE)) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"mobilephoneupdated", "n");
		}
		if (null != getSessionAttribute(TrustBrokerWebAppConstants.SHOW_EMAIL)
				&& (Boolean) getSessionAttribute(TrustBrokerWebAppConstants.SHOW_EMAIL)) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "emailupdated",
					"n");
		}
		redirectToRelyingParty(
				targetUrl,
				null,
				null,
				(String) getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID));
	}

	protected void addFacesMessage(String fieldId, String message) {
		getFacesContext().addMessage(fieldId, new FacesMessage(message));
	}

	/**
	 * This method is used to log audit event when an user email id is changed.
	 * 
	 * @param msg
	 *            event message.
	 * @param userVO
	 *            UserVO containing user info
	 */
	private void logUserEmailUpdate(String msg, UserVO userVO) {

		msg = "Security Audit Event|" + msg + "## uuid: ^^" + userVO.getUuId()
				+ "!!";
		IrmLoggingUtil.info(TrustBrokerConstants.EMAIL_UPD_ACTIVITY,
				SecurityEventType.E3_MODIFY, getServletRequest()
						.getRemoteAddr(), getServletRequest().getLocalAddr(),
				getServletRequest().getSession().getId(), userVO.getUserName(),
				msg, SecurityEventResult.SUCCESS, getRelyingPartyAppId(),
				userVO.getEmailAddress(), "",
				SecuritySubEventType.E3_MODIFY_EMAIL);
	}

	public String constructTargetUrl(String targetUrl) {
		if (null != getSessionAttribute("showDOB")
				&& (Boolean) getSessionAttribute("showDOB")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "dobupdated",
					"y");
		}
		if (null != getSessionAttribute("showAddress")
				&& (Boolean) getSessionAttribute("showAddress")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"addressupdated", "y");
		}
		if (null != getSessionAttribute("showMobilePhone")
				&& (Boolean) getSessionAttribute("showMobilePhone")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl,
					"mobilephoneupdated", "y");
		}
		if (null != getSessionAttribute("ShowEmail")
				&& (Boolean) getSessionAttribute("ShowEmail")) {
			targetUrl = HttpUtils.addParameterToURL(targetUrl, "emailupdated",
					"y");
		}
		return targetUrl;
	}
}