/*
 * Copyright (C) 2016 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.filter;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.optum.trustbroker.context.persistence.ApplicationContextRepository;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.RelyingPartyAppUtil;
import com.optum.trustbroker.util.TBHttpUtils;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserAuthorizationResponse;

/**
 * @author nvaneps
 */
public class UrlMappingFilter implements Filter {
    private static final BaseLogger LOG = new BaseLogger(UrlMappingFilter.class);

    private UserService userService;

    private RelyingPartyAppUtil relyingPartyAppUtil;

    private HashMap<String, String> urlPrevGenNextGen;

    private HashMap<String, String> urlIntermediatePrevGen;

    private HashMap<String, String> urlIntermediateNextGen;

    private String uriNextGenLogin;

    private String uriNextGenHome;

    private String uriPrevGenLogin;

    private String uriNextGenResetPassWord;

    private String uriNextGenSetupSecQuestions;

    private String uriPrevGenSpecialResetCase;

    private String uriNextGenAuthCodeExpiredCase;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        WebApplicationContext ctx = WebApplicationContextUtils
            .getRequiredWebApplicationContext(filterConfig.getServletContext());
        if (ctx == null) {
            throw new ServletException("couldn't get spring context");
        }
        userService = (UserService) ctx.getBean("userService");
        if (userService == null) {
            throw new ServletException("couldn't get user service from spring context");
        }
        relyingPartyAppUtil = (RelyingPartyAppUtil) ctx.getBean("relyingPartyAppUtil");
        if (relyingPartyAppUtil == null) {
            throw new ServletException("couldn't get relyingPartyAppUtil from spring context");
        }
        urlPrevGenNextGen = (HashMap<String, String>) ctx.getBean("urlRedirectionMapPrevGenNextGen");
        if (urlPrevGenNextGen == null) {
            throw new ServletException("couldn't get url redirection map previous generation to next generation from spring context");
        }
        urlIntermediatePrevGen = (HashMap<String, String>) ctx.getBean("urlRedirectionMapIntermediatePrevGen");
        if (urlIntermediatePrevGen == null) {
            throw new ServletException("couldn't get url redirection map intermediate to previous generation from spring context");
        }
        urlIntermediateNextGen = (HashMap<String, String>) ctx.getBean("urlRedirectionMapIntermediateNextGen");
        if (urlIntermediateNextGen == null) {
            throw new ServletException("couldn't get url redirection map intermediate to next generation from spring context");
        }
        uriNextGenLogin = (String) ctx.getBean("uriNextGenLogin");
        if (uriNextGenLogin == null) {
            throw new ServletException("couldn't get uriNextGenLogin from spring context");
        }
        uriNextGenHome = (String) ctx.getBean("uriNextGenHome");
        if (uriNextGenHome == null) {
            throw new ServletException("couldn't get uriNextGenHome from spring context");
        }
        uriPrevGenLogin = (String) ctx.getBean("uriPrevGenLogin");
        if (uriPrevGenLogin == null) {
            throw new ServletException("couldn't get uriPrevGenLogin from spring context");
        }
        uriNextGenResetPassWord = (String) ctx.getBean("uriNextGenResetPassWord");
        if (uriNextGenResetPassWord == null) {
            throw new ServletException("couldn't get uriNextGenResetPassWord from spring context");
        }
        uriNextGenSetupSecQuestions = (String) ctx.getBean("uriNextGenSetupSecQuestions");
        if (uriNextGenSetupSecQuestions == null) {
            throw new ServletException("couldn't get uriNextGenSetupSecQuestions from spring context");
        }
        uriPrevGenSpecialResetCase = (String) ctx.getBean("uriPrevGenSpecialResetCase");
        if (uriPrevGenSpecialResetCase == null) {
            throw new ServletException("couldn't get uriPrevGenSpecialResetCase from spring context");
        }
        uriNextGenAuthCodeExpiredCase = (String) ctx.getBean("uriNextGenAuthCodeExpiredCase");
        if (uriNextGenAuthCodeExpiredCase == null) {
            throw new ServletException("couldn't get uriNextGenAuthCodeExpiredCase from spring context");
        }
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
        throws IOException, ServletException {
        try {
            if (servletRequest instanceof HttpServletRequest) {
                HttpServletRequest hsReq = (HttpServletRequest) servletRequest;
                HttpServletResponse hsResp = (HttpServletResponse) servletResponse;
                String path = hsReq.getRequestURI().replaceFirst(hsReq.getContextPath(), "");
                if (LOG.isTraceEnabled()) {
                    LOG.trace("HttpServletRequest: ContextPath: " + hsReq.getContextPath());
                    LOG.trace("HttpServletRequest: PathInfo: " + hsReq.getPathInfo());
                    LOG.trace("HttpServletRequest: RequestURI: " + hsReq.getRequestURI());
                    LOG.trace("HttpServletRequest: RequestURL: " + hsReq.getRequestURL());
                    LOG.trace("HttpServletRequest: QueryString: " + hsReq.getQueryString());
                    LOG.trace("HttpServletRequest: ServerName: " + hsReq.getServerName());
                    LOG.trace("HttpServletRequest: ServerPort: " + hsReq.getServerPort());
                    LOG.trace("HttpServletRequest: ServletPath: " + hsReq.getServletPath());
                }
                // decide what to do for RP
                RelyingPartyAppVO rpApp = relyingPartyAppUtil.getRelyingParty(hsReq, hsResp);
                if (rpApp != null) {
                    if (!relyingPartyAppUtil.isNextGen(rpApp)) {
                        String linkPath = urlIntermediatePrevGen.get(path);
                        if (linkPath != null) {
                            // temporarily redirect intermediate links to previous generation URLs
                            goTemp(linkPath, hsReq, hsResp);
                            return;
                        }
                    }
                    else {
                        if (path.equals(uriPrevGenSpecialResetCase)) {
                            String paramAuthCode = hsReq.getParameter(TrustBrokerWebAppConstants.AUTH_CODE);
                            if (StringUtils.isNotBlank(paramAuthCode)) {
                                UserAuthorizationResponse response = userService.getUserAuthCodeDetails(paramAuthCode);
                                if (response != null) {
                                    if (response.getPurpose().equals(TrustBrokerConstants.ACCOUNT_RECOVERY)) {
                                        // permanently redirect prev generation reset account URL to next generation URL
                                        goPerm(uriNextGenResetPassWord, hsReq, hsResp);
                                        return;
                                    }
                                    else {
                                        // permanently redirect prev generation reset account URL to next generation URL
                                        goPerm(uriNextGenSetupSecQuestions, hsReq, hsResp);
                                        return;
                                    }
                                }
                                else {
                                    goPerm(uriNextGenAuthCodeExpiredCase, hsReq, hsResp);
                                    return;
                                }
                            }
                        }
                        String newPath = urlPrevGenNextGen.get(path);
                        if (newPath != null) {
                            // permanently redirect prev generation URLs to next generation URLs
                            goPerm(newPath, hsReq, hsResp);
                            return;
                        }
                        if (path.startsWith("/views") && path.endsWith(".jsf")) {
                            // permanently redirect prev generation non-secure URLs to next generation default login URL
                            goPerm(uriNextGenLogin, hsReq, hsResp);
                            return;
                        }
                        if (path.startsWith("/secure") && path.endsWith(".jsf")) {
                            // permanently redirect prev generation secure URLs to next generation default home URL
                            goPerm(uriNextGenHome, hsReq, hsResp);
                            return;
                        }
                    }
                }
                // for no rp or next gen rp
                String linkPath = urlIntermediateNextGen.get(path);
                if (linkPath != null) {
                    // temporarily redirect intermediate links to next generation URLs
                    goTemp(linkPath, hsReq, hsResp);
                    return;
                }
            }
        }
        catch (Exception e) {
            LOG.error(e);
            // do no mapping upon exception
            // this is a fail later scenario, but it is an attempt
            // to keep the site operable if the logic is flawed or there is bad data
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    private void goTemp(String newPath, HttpServletRequest hsReq, HttpServletResponse hsResp) {
        String newUrl = TBHttpUtils.replaceWebAppUri(newPath, hsReq);
        if (LOG.isTraceEnabled()) {
            LOG.trace("newUrl: " + newUrl);
        }
        TBHttpUtils.temporaryRedirect(hsResp, newUrl);
    }

    private void goPerm(String newPath, HttpServletRequest hsReq, HttpServletResponse hsResp) {
        String newUrl = TBHttpUtils.replaceWebAppUri(newPath, hsReq);
        if (LOG.isTraceEnabled()) {
            LOG.trace("newUrl: " + newUrl);
        }
        TBHttpUtils.permanentRedirect(hsResp, newUrl);
    }

    @Override
    public void destroy() {
        // no destruction required
    }
}
