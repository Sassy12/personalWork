package com.optum.trustbroker.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Component;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.PreferenceVO;
import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.enums.PreferenceType;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.UserVO;

/**
 * Created by dgopinad on 4/28/2016.
 */
@Component
@Path(TBConstants.VERIFY_RECOVERY_OPTIONS_CONTROLLER_PATH)
public class VerifyRecoveryOptionsController extends BaseController {

    private static final BaseLogger LOGGER = new BaseLogger(VerifyRecoveryOptionsController.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRecoveryOptions() {

        UserVO userVO = getCurrentUser();
        String optionToVerify = getWebApplicationCommonUtilities().getRecoveryOptionToVerify(userVO);
        String optionValue = null;
        String maskedValue = null;

        if (TrustBrokerWebAppConstants.OPTION_MOBILE.equals(optionToVerify)) {

            String phoneNo = userVO.getPhoneNumber().replaceAll("^\\d","");
            maskedValue = TBUtil.phoneMaskForNextGen(phoneNo);
            optionValue = phoneNo;

        } else if (TrustBrokerWebAppConstants.OPTION_SECONDARY_EMAIL.equals(optionToVerify)) {

            maskedValue = TBUtil.emailMask(userVO.getSecEmailAddress());
            optionValue = userVO.getSecEmailAddress();
        }

        PreferenceVO preferenceVO = new PreferenceVO();
        preferenceVO.setPreferenceType(optionToVerify);
        preferenceVO.setPreferenceValue(optionValue);
        preferenceVO.setMaskedValue(maskedValue);

        return Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(preferenceVO).build();

    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response saveRecoveryOptionPreferences(@FormParam("skipForever") boolean skipForever, @FormParam("preferenceType") String preferenceType) {

        UserVO userVO = getCurrentUser();
        String preferenceValue = null;
        if(TrustBrokerWebAppConstants.OPTION_MOBILE.equals(preferenceType)){
            preferenceValue = userVO.getPhoneNumber();
        }else{
            preferenceValue = userVO.getSecEmailAddress();
        }
        userService.savePreferences(userVO.getUuId(), PreferenceType.valueOf(preferenceType), preferenceValue, skipForever);

        addSkipRecoveryOptionsEvent();

        ResponseVO responseVO = new ResponseVO();
        responseVO.setStatus("proceedNext");
        return Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(responseVO).build();
    }

}
