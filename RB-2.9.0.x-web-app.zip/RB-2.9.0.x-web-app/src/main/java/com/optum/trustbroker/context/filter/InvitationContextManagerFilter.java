/*
 * Copyright (C) 2016 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.context.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.service.InvitationService;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.InvitationConstants;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.InvitationServiceResponse;
import com.optum.trustbroker.vo.InvitationVO;

/**
 * A filter bean that manages the creation and cleanup of the web application
 * context during the execution of the services from invitation token.
 *
 * @author Sachin Kumar
 * @version 1.0
 */
public class InvitationContextManagerFilter implements Filter {

    private static final BaseLogger LOGGER = new BaseLogger(InvitationContextManagerFilter.class);

    private transient ApplicationContext applicationContext;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.applicationContext = WebApplicationContextUtils
                .getRequiredWebApplicationContext(filterConfig.getServletContext());
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {

        try {
            // store site-minder context data details
            WebApplicationContextHolder.setContext(loadInvitationContextDetails((HttpServletRequest) servletRequest));
            filterChain.doFilter(servletRequest, servletResponse);
        } catch (Exception ex) {
            LOGGER.error("Error while adding the relying party details to context manager from invitation", ex);
        }
    }

    /**
     * Creates the context from invitation token.
     * 
     * @param request
     * @return {@link WebApplicationContext}
     */
    public WebApplicationContext loadInvitationContextDetails(HttpServletRequest request) {
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        try {
            String invitation = request.getParameter(TrustBrokerWebAppConstants.INVITATION);

            if (StringUtils.isNotBlank(invitation)) {
                InvitationService invitationService = (InvitationService) this.applicationContext
                        .getBean("invitationService");

                Map<String, String> invitationMap = invitationService.decodeInvitationDetails(invitation);
                String token = invitationMap.get(InvitationConstants.KEY_INVITATION_TOKEN);
                String relyingAppId = invitationMap.get(InvitationConstants.KEY_REPLYING_PARTY_APP_ID);

                InvitationServiceResponse invitationServiceResponse = invitationService
                        .getInvitationByTokenAndRelyingAppId(token, relyingAppId);

                if (TrustBrokerConstants.SUCCESS_CODE_VALUE
                        .equals(invitationServiceResponse.getExecutionStatus().getStatusCd())) {
                    InvitationVO invitationVO = invitationServiceResponse.getInvitationVO();

                    if (ctx == null) {
                        ctx = new WebApplicationContext();
                    }

                    ctx.setSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM, invitationVO.getRpAppId());
                    ctx.setSessionAttribute(TrustBrokerWebAppConstants.TARGET, invitationVO.getRpAppTargetURL());
                }
            }
        } catch (Exception ex) {
            LOGGER.error("Exception occured in loading relying party context from invitation", ex);
        }

        return ctx;
    }

    @Override
    public void destroy() {}
}
