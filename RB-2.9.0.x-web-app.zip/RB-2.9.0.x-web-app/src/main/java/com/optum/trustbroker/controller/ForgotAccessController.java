/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 * 
 ***********************************************
 * Modification History
 * When                  Who                 Why
 * Jan 25, 2016  bmanna3                Initial version
 ****************************************************************/

package com.optum.trustbroker.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.ForgotAccessRequestVO;
import com.optum.trustbroker.controller.vo.ForgotAccessResponseVO;
import com.optum.trustbroker.securemessaging.SecureMessagingService;
import com.optum.trustbroker.util.DateUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.vo.AuthenticateChallengeQuestionServiceRequest;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.OperationFailedException;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserAuthorizationRequest;
import com.optum.trustbroker.vo.UserAuthorizationResponse;
import com.optum.trustbroker.vo.UserChallengeQuestionServiceResponse;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserRetrievalServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.uhg.iam.alps.common.http.HttpUtils;
import com.uhg.iam.esso.schemas.xsd._2012._07.EmailAddress;
import com.uhg.iam.esso.schemas.xsd._2012._07.PhoneNumber;
import com.uhg.iam.esso.schemas.xsd._2012._07.UserSearchResultItem;

/**
 * The service class provides REST services for forgot user access
 * functionality.
 * 
 */
@Path(TBConstants.FORGOTACCESS_CONTROLLER_PATH)
public class ForgotAccessController extends BaseController {
    /** logger for this class. */
    private static final Logger LOG = Logger.getLogger(ForgotAccessController.class);

    @Autowired
    private transient SecureMessagingService secureMessagingService;

    /** Form level error property key name. */
    private static final String FORM_ERR_KEY_NAME = "formerr";

    /** Email field error property key name. */
    private static final String EMAIL_FLD_ERR_KEY_NAME = "emailerr";

    /** User name field error property key name. */
    private static final String UNAME_FLD_ERR_KEY_NAME = "usernameerr";

    /** Form error key name. */
    private static final String FORM_ERR_MSG = "fgtuserreqdfrmerr";

    /** Form error key name for account not found. */
    private static final String ACCOUNT_NOT_FOUND = "acctnotfound";

    /** Form error key name for user account locked. */
    private static final String USER_ACCOUNT_LOCKED = "useracctlocked";

    /** Form error key name for sec answer mismatch. */
    private static final String SEC_ANS_MISMATCHED = "secAnswersMisMatch";

    /** Form error key name for user aa locked status. */
    private static final String USER_AA_LOCKED_STATUS = "LOCKED";

    /**
     * Form error key name for account locked due to sec answer mismatch in same
     * page.
     */
    private static final String SEC_ANS_MISMATCHED_LOCKED_SAME_PAGE = "secAnswersMisMatchAccLockedSamepage";

    private static final String FIND_USR_NOT_FOUND = "fndusrnotfound";

    /** Return to verify identity enable flag . */
    private static final String RETURN_VERIFY_IDENTITY_ENABLE = "enable";

    /** Return to verify identity disable flag . */
    private static final String RETURN_VERIFY_IDENTITY_DISABLE = "disable";

    /**
     * This service method is to check if the user exists for the given email or
     * username to process forgot username or password flow.
     * @param request http request
     * @return ForgotAccessResponseVO
     */
    @POST
    @Path(value = "/getuseremailtype/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO getUserEmailType(ForgotAccessRequestVO request) {
        ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        final String recoveryType = request.getRecoveryType();
        ResourceBundle bundle = getBundle();
        if (StringUtils.isBlank(recoveryType)) {
            response.addMessage(FORM_ERR_KEY_NAME, bundle.getString(FORM_ERR_MSG));
        } else if ("ForgotUser".equalsIgnoreCase(recoveryType)) {
            final String emailId = request.getEmail();
            if (StringUtils.isBlank(emailId)) {
                response.addMessage(EMAIL_FLD_ERR_KEY_NAME, bundle.getString("fgtuseremailreqd"));
                response.addMessage(FORM_ERR_KEY_NAME, bundle.getString(FORM_ERR_MSG));
            } else {
                response = processForgotUser(request.getEmail());
            }
        } else if ("ForgotPwd".equalsIgnoreCase(recoveryType)) {
            final String userName = request.getUserName();
            if (StringUtils.isBlank(userName)) {
                response.addMessage(UNAME_FLD_ERR_KEY_NAME, bundle.getString("fgtpwdemailreqd"));
                response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("fgtpwdreqdfrmerr"));
            } else {
                response = processForgotPassword(userName);
            }
        }
        return response;
    }

    /**
     * This service method is to search for user with the given user first,
     * last, data of birth and/or phone.
     * 
     * @param request
     *                        http request
     * @return ForgotAccessResponseVO
     */
    @POST
    @Path(value = "/findunamewothrinfo/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO findUsernameWOtherInfo(ForgotAccessRequestVO request) {
        final ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        final String dateOfBirth = request.getDateOfBirth();
        final String mobilePhone = request.getMobilePhone();
        final String firstNmFldErr = "firstnameerr";
        final String lastNmFldErr = "lastnameerr";
        final String phoneFldErr = "phoneerr";
        ResourceBundle bundle = getBundle();
        if (StringUtils.isBlank(request.getFirstName())) {
            response.addMessage(firstNmFldErr, bundle.getString("firstnamereqd"));
        }
        if (StringUtils.isBlank(request.getLastName())) {
            response.addMessage(lastNmFldErr, bundle.getString("lastnamereqd"));
        }
        if (StringUtils.isNotBlank(dateOfBirth)) {
            validateDate(dateOfBirth, response);
        }
        if (StringUtils.isNotBlank(mobilePhone) && !validatePhoneMultipleFormats(mobilePhone)) {
            response.addMessage(phoneFldErr, bundle.getString("phoneinvmsg"));
        }
        if (response.getMessages().isEmpty()) {
            findUnameOtherInfo(request, response);
        } else {
            response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("genericFormError"));
        }
        return response;
    }

    /**
    * This service method is to search for user with the given username.
    * 
    * @param request
    *                 http request
    * @return ForgotAccessResponseVO
    */
    @POST
    @Path(value = "/findpwdwusername/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO findPasswordWithMoreInfo(ForgotAccessRequestVO request) {
        ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        final String usernameFldErr = "usernameerr";
        ResourceBundle bundle = getBundle();
        if (StringUtils.isBlank(request.getUserName())) {
            response.addMessage(usernameFldErr, bundle.getString("usernamereqd"));
            response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("genericFormError"));
        } else {
            response = findUserPwdWithUsername(request.getUserName());
        }
        return response;
    }

    /**
     * This service method is to search for user with the given user name and to
     * validate the Security question with the DB.
     * 
     * @param request
     *                        http request
     * @return ForgotAccessResponseVO
     */
    @POST
    @Path(value = "/displayUserNameByVerifyingSecurityQuestion/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO displayUserNameByVerifyingSecurityQuestion(ForgotAccessRequestVO request) {
        final ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        ResourceBundle bundle = getBundle();
        final String acctNotFoundMsg = getFormattedMessage(FIND_USR_NOT_FOUND);
        WebApplicationContext context = WebApplicationContextHolder.getContext();
        context.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN);
        context.removeSessionAttribute(TrustBrokerWebAppConstants.SELF_SRVC_AUTH_CODE);
        if (checkSecurityAnswerValidation(request, response)) {
            try {
                UserVO userVO = getUserById(request.getUserName(), false);
                if (userVO == null) {
                    response.addMessage(FORM_ERR_KEY_NAME, acctNotFoundMsg);
                    response.setStatus(false);
                    return response;
                }
                String authChallengeResponse;
                if (TrustBrokerConstants.AA_LOCK_STATUS.equals(userVO.getAaStatus())) {
                    userAccountLocked(response);
                    return response;
                } else {
                    UserChallengeQuestionServiceResponse userChallengeResp = retrieveChallengeQuestionsofUser(userVO,
                            request);
                    authChallengeResponse = verifySecurityAnswers(userVO, userChallengeResp);
                    if (TrustBrokerConstants.SUCCESS_CODE_VALUE.equalsIgnoreCase(authChallengeResponse)) {
                        response.setStatus(true);
                        context.setSessionAttribute(
                                TrustBrokerWebAppConstants.SELF_SRVC_VALIDTN, request.getUserName());
                        return response;
                    } else if (TrustBrokerConstants.FAILURE_CODE_VALUE.equalsIgnoreCase(authChallengeResponse)) {
                        retrieveChallengeQuestionsofUser(userVO, request);
                        response.addMessage(SEC_ANS_MISMATCHED, bundle.getString("secAnswersMisMatch"));
                        response.setStatus(false);
                        return response;
                    }
                }
            } catch (OperationFailedException ex) {
                LOG.error("Error account recovery options  while validating security questions ", ex);
                if (null != ex.getErrorMessage()) {
                    userAccountLocked(response);
                    return response;
                } else if (TrustBrokerConstants.USER_LOCKED.equals(ex.getMessage())) {
                    response.setStatus(false);
                    response.addMessage(USER_ACCOUNT_LOCKED, bundle.getString("useraccountlocked"));
                    return response;
                }
                if (null != ex.getErrorMessages() && !ex.getErrorMessages().isEmpty()) {
                    response.addMessage(ACCOUNT_NOT_FOUND, acctNotFoundMsg);
                    return response;
                }
            }
        } else {
            return response;
        }
        return response;
    }

    /**
     * This service method is to check if the user exists for the given email or
     * username to process forgot username flow.
     * 
     * @param request
     *                        http request
     * @return ForgotAccessResponseVO
     */
    @POST
    @Path(value = "/verifyuserwithfirstnameandlastname/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO getUserDetailsWithFirstNameAndLastName(ForgotAccessRequestVO request) {
        if (StringUtils.isBlank(request.getEmail())) {
            request.setEmail(WebApplicationContextHolder.getContext()
                    .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_EMAIL));
        }
        final ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        ResourceBundle bundle = getBundle();
        final String acctNotFoundMsg = getFormattedMessage(FIND_USR_NOT_FOUND);
        try {
            if (checkValidation(request, response)) {
                UserProfileServiceResponse userProfileServiceResponse = verifyUserAccount(request);
                if (userProfileServiceResponse == null) {
                    response.addMessage(ACCOUNT_NOT_FOUND, acctNotFoundMsg);
                    return response;
                } else {
                    if (!checkUserStatusWithDetails(userProfileServiceResponse, response)) {
                        return response;
                    }
                }
                UserRetrievalServiceResponse userRetSerResponse = fetchUserProfile(userProfileServiceResponse);
                if (userRetSerResponse == null) {
                    response.addMessage(ACCOUNT_NOT_FOUND, acctNotFoundMsg);
                    return response;
                } else {
                    UserVO userVO = userRetSerResponse.getUser();
                    response.setUserName(userVO.getUserName());
                    response.setStatus(true);
                    return response;
                }
            } else {
                return response;
            }
        } catch (OperationFailedException ex) {
            LOG.error("Error while verifying user details for the user {}", ex);
            if (null != ex.getErrorMessage()) {
                response.setStatus(false);
                response.addMessage(ACCOUNT_NOT_FOUND, acctNotFoundMsg);
                return response;
            } else if (TrustBrokerConstants.USER_LOCKED.equals(ex.getMessage())) {
                response.setStatus(false);
                response.addMessage(USER_ACCOUNT_LOCKED, bundle.getString("useraccountlocked"));
                return response;
            }
            if (null != ex.getErrorMessages() && !ex.getErrorMessages().isEmpty()) {
                response.addMessage(ACCOUNT_NOT_FOUND, acctNotFoundMsg);
                return response;
            }
        }
        response.setStatus(true);
        return response;
    }

    /**
     * This service method is to get user details using the user name.
     * 
     * @param request
     *                        http request
     * @return response
     *                        ForgotAccessResponseVO
     */
    @POST
    @Path(value = "/getUserInfoForAccountRecoveryProcess/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO getUserInfoForAccountRecoveryProcess(ForgotAccessRequestVO request,
            @Context HttpServletRequest req) {
        if (StringUtils.isBlank(request.getUserName())) {
            request.setUserName(WebApplicationContextHolder.getContext()
                    .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME));
        }
        final ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        response.setUserName(request.getUserName());
        UserVO userVO = getUserById(request.getUserName(), false);
        response.setRequestType(WebApplicationContextHolder.getContext().getcurrentWorkflowId());
        if (userVO == null) {
            response.addMessage(FORM_ERR_KEY_NAME, getFormattedMessage(FIND_USR_NOT_FOUND));
            response.setStatus(false);
            return response;
        } else {
            checkuserAccountRecovery(userVO, response);
            checkAccountRecoveryAvailablityStatus(userVO, response, req);
            checkSkipAccountRecoveryOption(response);
            response.setAccountLockedStatus(userVO.getAaStatus());
            response.setStatus(true);
            return response;
        }
    }

    /**
     * This service method is to send user name via primary email.
     * 
     * @param request
     *                        http request
     * @return ForgotAccessResponseVO
     */
    @POST
    @Path(value = "/sendUserNameByAccountRecovery/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO sendUserNameByAccountRecovery(ForgotAccessRequestVO request,
            @Context HttpServletRequest req) {
        final ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        UserVO userVO = getUserById(request.getUserName(), false);
        if (userVO == null) {
            response.addMessage(FORM_ERR_KEY_NAME, getFormattedMessage(FIND_USR_NOT_FOUND));
            response.setStatus(false);
            return response;
        } else {
            sendInfoForUser(userVO, response, req, request.getRecoveryType());
            response.setStatus(true);
            return response;
        }
    }

    /**
    * This service method is to used to send the Reset password thru Secondary Email.
    * 
    * @param request
    *             http request
    * @return ForgotAccessResponseVO
    */
    @POST
    @Path(value = "/sendResetPasswordByEmail")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO sendResetPasswordByEmail(ForgotAccessRequestVO request, @Context HttpServletRequest req) {
        ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        String workflowId = WebApplicationContextHolder.getContext().getcurrentWorkflowId();
        if (StringUtils.isBlank(request.getUserName())) {
            request.setUserName(WebApplicationContextHolder.getContext()
                    .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME));
        }

        UserVO userVO = userService.fetchUserProfile(request.getUserName(), false, true).getUser();
        if (userVO == null) {
            ResourceBundle bundle = getBundle();
            response.addMessage(FORM_ERR_KEY_NAME, bundle.getString(FIND_USR_NOT_FOUND));
            response.setStatus(false);
            return response;
        } else {
            boolean emailType = false;
            if (!StringUtils.isBlank(request.getRecoveryType())) {
            	WebApplicationContextHolder.getContext()
                .setWorkflowAttribute(workflowId, WorkflowConstants.WORKFLOW_ATTRIBUTE_RECOVERY_TYPE, request.getRecoveryType());
            }else{
            	request.setRecoveryType(WebApplicationContextHolder.getContext()
                        .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_RECOVERY_TYPE));
            } 
            
            if ("primaryEmail".equals(request.getRecoveryType())) {
                emailType = true;
            }
           
            if (WorkflowConstants.WORKFLOW_FORGOT_PWD.equals(workflowId)
                    || WorkflowConstants.WORKFLOW_UNLOCK_USER_ACCOUNT.equals(workflowId)) {
                constructUserAuthorizationRequestForAccountRecovery(userVO, req, emailType,
                        TrustBrokerConstants.ACCOUNT_RECOVERY);
            } else if (WorkflowConstants.WORKFLOW_SETUP_SECURITY_QUESTIONS.equals(workflowId)) {
                constructUserAuthorizationRequestForAccountRecovery(userVO, req, emailType, TrustBrokerConstants.SQA);
            }
            response.setStatus(true);
            return response;
        }
    }

    /**
    * This service method is to used to send the Reset password thru Secondary Email.
    * 
    * @param request
    *             http request
    * @return ForgotAccessResponseVO
    */
    @POST
    @Path(value = "/sendSQAAuthorizationLink")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO sendSetupSQAAuthorizationLinkByEmail(ForgotAccessRequestVO request,
            @Context HttpServletRequest req) {
        ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        if (StringUtils.isBlank(request.getUserName())) {
            request.setUserName(WebApplicationContextHolder.getContext()
                    .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME));
        }
        UserVO userVO = userService.fetchUserProfile(request.getUserName(), false, true).getUser();
        if (userVO == null) {
            ResourceBundle bundle = getBundle();
            response.addMessage(FORM_ERR_KEY_NAME, bundle.getString(FIND_USR_NOT_FOUND));
            response.setStatus(false);
            return response;
        } else {
            boolean emailType = false;
            if ("primaryEmail".equals(request.getRecoveryType())) {
                emailType = true;
            }
            constructUserAuthorizationRequestForAccountRecovery(userVO, req, emailType, TrustBrokerConstants.SQA);
            response.setStatus(true);
            return response;
        }
    }

    @POST
    @Path(value = "/sendPhoneOTP")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public ForgotAccessResponseVO sendPhoneOTP(ForgotAccessRequestVO request) {
        ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        ResourceBundle bundle = getBundle();
        if (StringUtils.isBlank(request.getUserName())) {
            request.setUserName(WebApplicationContextHolder.getContext()
                    .getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME));
        }
        try {
            UserRetrievalServiceResponse userRetrievalServiceResponse = userService.fetchUserProfile(request.getUserName(),
                    false, true);
            UserAuthorizationResponse userAuthorizationResponse = userService
                    .generateAuthCodeToUser(userRetrievalServiceResponse.getUser().getUuId(), TrustBrokerConstants.SMSOTP);
            secureMessagingService.sendText(userRetrievalServiceResponse.getUser().getPhoneNumber(),
                    bundle.getString("OtpAccessCodeMsg") + userAuthorizationResponse.getUserAuthCode());
            response.setStatus(true);
        } catch (OperationFailedException e) {
            response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("otpSendErrMsg"));
            response.setStatus(false);
            LOG.error("Error in sending OTP to your mobile number: ", e);
        }
        return response;
    }

    /**
     * This method is to process the forgot username initial request. This
     * method checks if user exists for the given email and if exists checks if
     * user has valid recovery options.
     * 
     * @param email
     *                        String
     * @return ForgotAccessResponseVO
     */
    private ForgotAccessResponseVO processForgotUser(String email) {
        ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        response.setStatus(false);
        if (TBUtil.validateEmailId(email)) {
            checkUserByEmail(response, email, WorkflowConstants.WORKFLOW_FORGOT_USER_NAME);
        } else {
            ResourceBundle bundle = getBundle();
            response.addMessage(EMAIL_FLD_ERR_KEY_NAME, bundle.getString("fgtuserinvalidemail"));
            response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("fgtuserinvalidfrmerr"));
        }
        return response;
    }

    /**
     * This method is to process the forgot password initial request. This
     * method checks if user exists for the given email or username and if
     * exisis checks if user has valid recovery options.
     * 
     * @param userName
     *                        String
     * @return ForgotAccessResponseVO
     */
    private ForgotAccessResponseVO processForgotPassword(String userName) {
        ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        response.setStatus(false);
        if (TBUtil.validateEmailId(userName)) {
            checkUserByEmail(response, userName, WorkflowConstants.WORKFLOW_FORGOT_PWD);
        } else {
            UserVO userVO = getUserById(userName, false);
            if (userVO == null) {
                ResourceBundle bundle = getBundle();
                response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("fgtpwdnotfound"));
            } else {
                checkUserRecoveryOptions(userVO, response);
                if (response.isStatus() && response.isUniqueEmail()) {
                    response.setUserName(userVO.getUserName());
                    WebApplicationContextHolder.getContext().setWorkflowAttribute(WorkflowConstants.WORKFLOW_FORGOT_PWD,
                            WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME, userVO.getUserName());
                } else {
                    WebApplicationContextHolder.getContext().setCurrentWorkflowId(WorkflowConstants.WORKFLOW_FORGOT_PWD);
                }
            }
        }
        return response;
    }

    /**
     * This method checks if user exists for the given email and if exists.
     * checks if user has valid recovery options.
     * 
     * @param response
     *                        ForgotAccessResponseVO
     * @param userName
     *                        String
     */
    private void checkUserByEmail(ForgotAccessResponseVO response, String email, String workflowId) {
        UserProfileServiceResponse userResponse = getUserByEmail(email);
        if (!isUserFound(userResponse)) {
            ResourceBundle bundle = getBundle();
            if(WorkflowConstants.WORKFLOW_FORGOT_PWD.equals(workflowId))
            	response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("fgtpwdnotfound"));
            else
              response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("fgtusrpwdnotfound"));
        } else if (isUserDuplicate(userResponse)) {
            response.setUniqueEmail(false);
            response.setStatus(true);
            WebApplicationContextHolder.getContext().setWorkflowAttribute(workflowId,
                    WorkflowConstants.WORKFLOW_ATTRIBUTE_EMAIL, email);
        } else {
            UserVO userVO = userResponse.getUser();
            userVO = getUserById(userVO.getUuId(), true);
            checkUserRecoveryOptions(userVO, response);
            if (response.isStatus() && response.isUniqueEmail()) {
                response.setUserName(userVO.getUserName());
                WebApplicationContextHolder.getContext().setWorkflowAttribute(workflowId,
                        WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME, userVO.getUserName());
            } else {
                WebApplicationContextHolder.getContext().setCurrentWorkflowId(workflowId);
            }
        }
    }

    /**
     * This method checks if user exists for the given user details and if
     * exists. checks if user has valid recovery options.
     * 
     * @param request
     *                        ForgotAccessRequestVO
     * @param response
     *                        ForgotAccessResponseVO
     */
    private void findUnameOtherInfo(ForgotAccessRequestVO request, ForgotAccessResponseVO response) {
        List<UserSearchResultItem> userResponse = findUserByName(request);
        UserVO userVO;
        boolean uniqueUser = false;
        final String userNotFoundMsg = getFormattedMessage(FIND_USR_NOT_FOUND);
        if (userResponse == null || userResponse.isEmpty()) {
            response.addMessage(FORM_ERR_KEY_NAME, userNotFoundMsg);
        } else {
            if (userResponse.size() == 1) {
                uniqueUser = true;
            } else if (StringUtils.isNotBlank(request.getDateOfBirth())
                    || StringUtils.isNotBlank(request.getMobilePhone())) {
                userResponse = findUserByNameAndNumber(request);
                if (userResponse == null || userResponse.size() != 1) {
                    response.addMessage(FORM_ERR_KEY_NAME, userNotFoundMsg);
                } else {
                    uniqueUser = true;
                }
            } else {
                response.addMessage(FORM_ERR_KEY_NAME, userNotFoundMsg);
            }
        }
        if (uniqueUser) {
            userVO = buildUserVO(userResponse.get(0));
            checkUserRecoveryOptions(userVO, response);
            if (response.isStatus() && response.isUniqueEmail()) {
                WebApplicationContextHolder.getContext().setWorkflowAttribute(WorkflowConstants.WORKFLOW_FORGOT_USER_NAME,
                        WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME, userVO.getUserName());
                response.setUserName(userVO.getUserName());
            }
        }
    }

    /**
     * This method checks if user exists for the given username and if
     * exisis checks if user has valid recovery options.
     * 
     * @param userName
     *               String
     * @return ForgotAccessResponseVO
     */
    private ForgotAccessResponseVO findUserPwdWithUsername(String userName) {
        ForgotAccessResponseVO response = new ForgotAccessResponseVO();
        response.setStatus(false);
        UserVO userVO = getUserById(userName, false);
        if (userVO == null) {
            response.addMessage(FORM_ERR_KEY_NAME, getFormattedMessage(FIND_USR_NOT_FOUND));
        } else {
            checkUserRecoveryOptions(userVO, response);
            if (response.isStatus() && response.isUniqueEmail()) {
                response.setUserName(userVO.getUserName());
                WebApplicationContextHolder.getContext().setWorkflowAttribute(WorkflowConstants.WORKFLOW_FORGOT_PWD,
                        WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME, userVO.getUserName());
            }
        }
        return response;
    }

    /**
     * This method is to build userVO object from user search item with user
     * emails and phone number.
     * 
     * @param item
     *                        UserSearchResultItem
     * @return UserVO
     */
    private UserVO buildUserVO(UserSearchResultItem item) {
        UserVO userVO = new UserVO();
        if (item != null && item.getUserPayload() != null) {
            EmailAddress emailAddress;
            List<EmailAddress> emails = item.getUserPayload().getEmails();
            if (emails != null) {
                Iterator<EmailAddress> emailItr = emails.iterator();
                while (emailItr.hasNext()) {
                    emailAddress = emailItr.next();
                    if (emailAddress.isDefault()) {
                        userVO.setEmailAddress(emailAddress.getValue());
                        userVO.setIsemailVerified(emailAddress.isVerified());
                        userVO.setPrimaryEmailUnique(emailAddress.isUnique());
                    } else {
                        userVO.setSecEmailAddress(emailAddress.getValue());
                        userVO.setSecEmailVerified(emailAddress.isVerified());
                        userVO.setSecEmailUnique(emailAddress.isUnique());
                    }
                }
            }
            if (item.getUserPayload().getUserDetail() != null) {
                buildUserPhone(item.getUserPayload().getUserDetail().getPhoneNumbers(), userVO);
            }
            if (item.getUserIdentificationData() != null) {
                if (item.getUserIdentificationData().getUserName() != null) {
                    userVO.setUserName(item.getUserIdentificationData().getUserName().getValue());
                }
                if (item.getUserIdentificationData().getUUID() != null) {
                    userVO.setUuId(item.getUserIdentificationData().getUUID().getValue());
                }
            }
        }
        return userVO;
    }

    /**
     * This method is to build userVO object with user phone number.
     * @param phoneNumbers
     *                        List
     * @param userVO
     *                        UserVO
     */
    private void buildUserPhone(List<PhoneNumber> phoneNumbers, UserVO userVO) {
        if (phoneNumbers != null) {
            PhoneNumber phnNumber;
            Iterator<PhoneNumber> phoneNumberItr = phoneNumbers.iterator();
            while (phoneNumberItr.hasNext()) {
                phnNumber = phoneNumberItr.next();
                if (phnNumber.isVerified()) {
                    userVO.setIsPhoneVerified(phnNumber.isVerified());
                    StringBuilder fmtPhone = new StringBuilder();
                    fmtPhone.append(phnNumber.getCountryCode());
                    fmtPhone.append(phnNumber.getAreaCode());
                    fmtPhone.append(phnNumber.getNumber());
                    userVO.setPhoneNumber(fmtPhone.toString());
                }
            }
        }
    }

    /**
     * This method is to search user using user first and last names.
     * 
     * @param request
     *                        ForgotAccessRequestVO
     * @return UserSearchResultItem List
     */
    private List<UserSearchResultItem> findUserByName(ForgotAccessRequestVO request) {
        UserVO userValueObject = new UserVO();
        userValueObject.setFirstName(request.getFirstName());
        userValueObject.setLastName(request.getLastName());
        return findUser(userValueObject);
    }

    /**
     * This method is to search user using user first, last names and/or date of
     * birth and mobile.
     * 
     * @param request
     *                        ForgotAccessRequestVO
     * @return UserSearchResultItem List
     */
    private List<UserSearchResultItem> findUserByNameAndNumber(ForgotAccessRequestVO request) {
        UserVO userValueObject = new UserVO();
        userValueObject.setFirstName(request.getFirstName());
        userValueObject.setLastName(request.getLastName());
        if (StringUtils.isNotBlank(request.getDateOfBirth())) {
            userValueObject.setDob(DateUtil.parseDate(request.getDateOfBirth(), DateUtil.EXT_DATE_FORMAT));
        }
        if (StringUtils.isNotBlank(request.getMobilePhone())) {
            userValueObject.setPhoneNumber(getFormattedPhoneNumber(request.getMobilePhone()));
        }
        return findUser(userValueObject);
    }

    /**
     * This method checks if the given user has any valid account recovery option.
     * 
     * @param userVO
     *                        UserVO
     * @param response
     *                        ForgotAccessResponseVO
     */
    private void checkUserRecoveryOptions(UserVO userVO, ForgotAccessResponseVO response) {
        if (userVO != null) {
            if ((StringUtils.isNotBlank(userVO.getEmailAddress()) && userVO.isIsemailVerified()
                    && userVO.isPrimaryEmailUnique())
                    || (StringUtils.isNotBlank(userVO.getSecEmailAddress()) && userVO.isSecEmailVerified()
                            && userVO.isSecEmailUnique())
                    || (StringUtils.isNotBlank(userVO.getPhoneNumber()) && userVO.getIsPhoneVerified())) {
                response.setStatus(true);
                response.setUniqueEmail(true);
            } else {
                UserChallengeQuestionServiceResponse userChallengeResp = null;
                try {
                    if (userVO.getUuId() != null) {
                        userChallengeResp = getUserService().getChallengeQuestions(userVO.getUuId(),
                                TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
                    }
                } catch (OperationFailedException ofe) {
                    LOG.error("Exception in getting user challenge questions", ofe);
                    userChallengeResp = null;
                }
                if (null != userChallengeResp && null != userChallengeResp.getUserChallengeQuestions()
                        && !userChallengeResp.getUserChallengeQuestions().isEmpty()) {
                    response.setStatus(true);
                    response.setUniqueEmail(true);
                } else {
                    response.setStatus(false);
                    response.setUniqueEmail(false);
                    response.setInvalidRecoveryOptns(true);
                }
            }
        }
    }

    /**
     * This method is to get user profile for the given username or uuid.
     * 
     * @param username
     *                        String
     * @param isUuid
     *                        boolean
     * @return UserVO
     */
    private UserVO getUserById(String username, boolean isUuid) {
        UserRetrievalServiceResponse response = null;
        UserVO userVO = null;
        try {
            response = getUserService().fetchUserProfile(username, isUuid, false);
            if (response != null) {
                userVO = response.getUser();
            }
        } catch (OperationFailedException ofe) {
            LOG.error("Exception in getting user profile from userservice ", ofe);
            return null;
        }
        return userVO;
    }

    /**
     * This method is to search user for the given email id.
     * 
     * @param email
     *                        String
     * @return UserProfileServiceResponse
     */
    private UserProfileServiceResponse getUserByEmail(String email) {
        UserVO userValueObject = new UserVO();
        userValueObject.setEmailAddress(email);
        UserProfileServiceResponse userProfileServiceResponse = lookupUser(userValueObject);
        return userProfileServiceResponse;
    }

    /**
     * This method is to search user for the given user attributes.
     * 
     * @param userValueObject
     *                        UserVO
     * @return List UserSearchResultItem
     */
    private List<UserSearchResultItem> findUser(UserVO userValueObject) {
        List<UserSearchResultItem> srchResults = new ArrayList<UserSearchResultItem>();
        UserProfileServiceRequest userSearchRequest = new UserProfileServiceRequest();
        userSearchRequest.setAnyEmailLabel(true);
        userSearchRequest.setUser(userValueObject);
        try {
            srchResults = getUserService().lookUpUser(userSearchRequest);
        } catch (OperationFailedException ofe) {
            LOG.error("Exception in searching user from user service - findUser()", ofe);
        }
        return srchResults;
    }

    /**
     * This method is to search user for the given user attributes.
     * 
     * @param userValueObject
     *                        UserVO
     * @return UserProfileServiceResponse
     */
    private UserProfileServiceResponse lookupUser(UserVO userValueObject) {
        UserProfileServiceResponse userProfileServiceResponse = null;
        try {
            userProfileServiceResponse = getUserService().lookupUserByHeuristicEvaluation(userValueObject, "*");
        } catch (OperationFailedException ofe) {
            LOG.error("Exception in searching user from user service - lookupUser() ", ofe);
            return null;
        }
        return userProfileServiceResponse;
    }

    /**
     * This method is to check if any user found in the given profile response.
     * 
     * @param userServiceResponse
     *                        UserProfileServiceResponse
     * @return boolean
     */
    private static boolean isUserFound(UserProfileServiceResponse userServiceResponse) {
        boolean userFound;
        if (userServiceResponse == null || userServiceResponse.getExecutionStatus() == null
                || TrustBrokerConstants.FAILURE_CODE_VALUE.equals(userServiceResponse.getExecutionStatus().getStatusCd())
                || userServiceResponse.getUser() == null) {
            userFound = false;
        } else {
            userFound = true;
        }
        return userFound;
    }

    /**
     * This method is to check if duplicate user accounts found in the given
     * profile response.
     * 
     * @param userServiceResponse
     *                        UserProfileServiceResponse
     * @return boolean
     */
    private static boolean isUserDuplicate(UserProfileServiceResponse userServiceResponse) {
        boolean userDuplicate;
        if (userServiceResponse != null && TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE
                .equals(userServiceResponse.getExecutionStatus().getStatusCd())) {
            userDuplicate = true;
        } else {
            userDuplicate = false;
        }
        return userDuplicate;
    }

    public SecureMessagingService getSecureMessagingService() {
        return secureMessagingService;
    }

    public void setSecureMessagingService(SecureMessagingService secureMessagingService) {
        this.secureMessagingService = secureMessagingService;
    }

    /**
     * This method is to check if the user email is shared profile response.
     * 
     * @param userVO
     *                        UserVO
     * @return boolean
     */
    public boolean isUserEmailShared(UserVO userVO) {
        boolean userEmailShared = false;
        try {
            if (getUserService().isEmailExists(userVO.getEmailAddress())) {
                userEmailShared = true;
            }
        } catch (OperationFailedException ofe) {
            LOG.error("Exception while checking duplicate email", ofe);
        }
        return userEmailShared;
    }

    /**
     * This method is to check if the user email is shared profile response.
     * 
     * @param response
     *                        ForgotAccessResponseVO
     * @return boolean
     */
    private boolean checkValidation(ForgotAccessRequestVO request, ForgotAccessResponseVO response) {
        if (StringUtils.isEmpty(request.getFirstName()) || StringUtils.isEmpty(request.getLastName())
                || StringUtils.isBlank(request.getEmail())) {
            ResourceBundle bundle = getBundle();
            if (StringUtils.isEmpty(request.getFirstName())) {
                response.addMessage("firstnamerequired", bundle.getString("firstnamerequired"));
            }
            if (StringUtils.isEmpty(request.getLastName())) {
                response.addMessage("lastnamerequired", bundle.getString("lastnamerequired"));
            }
            if (StringUtils.isEmpty(request.getEmail())) {
                response.addMessage("emailrequired", bundle.getString("emailrequired"));
            }
            response.setStatus(false);
            return false;
        }
        return true;
    }

    /**
     * This method is to validate the sec question using secAnswers provided by the users.
     * 
     * @return boolean
     */
    private boolean checkSecurityAnswerValidation(ForgotAccessRequestVO request, ForgotAccessResponseVO response) {
        if (StringUtils.isEmpty(request.getSecAns1()) || StringUtils.isEmpty(request.getSecAns2())) {
            ResourceBundle bundle = getBundle();
            if (StringUtils.isEmpty(request.getSecAns1())) {
                response.addMessage("secAnswer1ReqErrorMsg", bundle.getString("secAnswer1ReqErrorMsg"));
            }
            if (StringUtils.isEmpty(request.getSecAns2())) {
                response.addMessage("secAnswer2ReqErrorMsg", bundle.getString("secAnswer2ReqErrorMsg"));
            }
            response.setStatus(false);
            return false;
        }
        return true;
    }

    /**
     * This method is to verify user account details using firstname , lastname and email.
     * @return userProfileServiceResponse
     */
    private UserProfileServiceResponse verifyUserAccount(ForgotAccessRequestVO request) {
        UserProfileServiceResponse userProfileServiceResponse = null;
        try {
            UserVO userValueObject = new UserVO();
            userValueObject.setEmailAddress(request.getEmail());
            userValueObject.setFirstName(request.getFirstName());
            userValueObject.setLastName(request.getLastName());
            userProfileServiceResponse = getUserService().lookupUserByHeuristicEvaluation(userValueObject, "*");
        } catch (OperationFailedException ofe) {
            LOG.error("Exception in searching user from userservice ", ofe);
            return null;
        }
        return userProfileServiceResponse;
    }

    /**
     * This method is to verify user status details.
     * 
     * @param userProfileServiceResponse
     *                                  UserProfileServiceResponse
     * @return boolean
     */
    private boolean checkUserStatusWithDetails(UserProfileServiceResponse userProfileServiceResponse,
            ForgotAccessResponseVO response) {
        boolean userDuplicate = false;
        boolean userNotFound = false;
        if (TrustBrokerConstants.MULTIPLE_USERS_WITH_EMAIL_FAILURE_CODE
                .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
            userDuplicate = true;
        } else if (TrustBrokerConstants.FAILURE_CODE_VALUE
                .equals(userProfileServiceResponse.getExecutionStatus().getStatusCd())) {
            userNotFound = true;
        }
        if (userNotFound || userDuplicate) {
            response.setStatus(false);
            response.addMessage(ACCOUNT_NOT_FOUND, getFormattedMessage(FIND_USR_NOT_FOUND));
            return false;
        }
        return true;
    }

    /**
     * This method is to fetch User Profile.
     * 
     * @param userProfileServiceResponse
     *                           UserProfileServiceResponse
     * @return userRetrievalServiceResponse
     */
    private UserRetrievalServiceResponse fetchUserProfile(UserProfileServiceResponse userProfileServiceResponse) {
        UserRetrievalServiceResponse userRetrievalServiceResponse = null;
        try {
            userRetrievalServiceResponse = getUserService().fetchUserProfile(userProfileServiceResponse.getUser().getUuId(),
                    true, false);
        } catch (OperationFailedException ofe) {
            LOG.error("Exception in searching user from user service - fetchUserProfile() ", ofe);
            return null;
        }
        return userRetrievalServiceResponse;
    }

    /**
     * This method checks if the given user has any valid account recovery.
     * option.
     * 
     * @param userVO
     *                        UserVO
     * @param response
     *                        ForgotAccessResponseVO
     */
    private void checkuserAccountRecovery(UserVO userVO, ForgotAccessResponseVO response) {
        if (userVO != null) {
            boolean primaryUnique = false;
            boolean secEmailUnique = false;
            boolean phoneUnique = false;
            if (StringUtils.isNotBlank(userVO.getEmailAddress()) && userVO.isIsemailVerified()
                    && userVO.isPrimaryEmailUnique()) {
                primaryUnique = true;
            }
            if (StringUtils.isNotBlank(userVO.getSecEmailAddress()) && userVO.isSecEmailVerified()
                    && userVO.isSecEmailUnique()) {
                secEmailUnique = true;
            }
            if (StringUtils.isNotBlank(userVO.getPhoneNumber()) && userVO.getIsPhoneVerified()) {
                phoneUnique = true;
            }
            updateUserAcctRecovery(userVO, response, primaryUnique, secEmailUnique, phoneUnique);
            if (USER_AA_LOCKED_STATUS.equals(userVO.getAaStatus())) {
                response.setSecQuestionAvailable(false);
                checkIfNoAccountRecovery(response);
            } else {
                checkSecQuestionAndAnswer(userVO, response);
            }
        }
    }

    /**
     * This method is to update the response object with primary, secondary email and
     * phone unique/verified indicators.
     * 
     * @param userVO UserVO
     * @param response ForgotAccessResponseVO
     * @param primaryId boolean
     * @param secEmailInd boolean
     * @param phoneInd boolean
     */
    private void updateUserAcctRecovery(UserVO userVO, ForgotAccessResponseVO response, boolean primaryId,
            boolean secEmailInd, boolean phoneInd) {
        if (primaryId) {
            response.setPrimaryEmailVerified(true);
            response.setPrimaryEmail(userVO.getEmailAddress());
            response.setPrimaryEmailMask(emailMask(userVO.getEmailAddress()));
            response.setRecoveryType("primaryEmail");
        }
        if (secEmailInd) {
            response.setSecondaryEmailVerified(true);
            response.setSecEmail(userVO.getSecEmailAddress());
            response.setSecEmailMask(emailMask(userVO.getSecEmailAddress()));
            response.setRecoveryType("secondaryEmail");
        }
        if (phoneInd) {
            response.setPhoneVerified(true);
            response.setPhone(userVO.getPhoneNumber());
            response.setPhoneMask(phoneMask(userVO.getPhoneNumber()));
            response.setRecoveryType("phone");
        }
    }

    /**
     * This method is to check Sec Question And Answer.
     * @param userVO UserVO
     * @param response ForgotAccessResponseVO
     */
    private void checkSecQuestionAndAnswer(UserVO userVO, ForgotAccessResponseVO response) {
        UserChallengeQuestionServiceResponse userChallengeResp = null;
        try {
            userChallengeResp = getUserService().getChallengeQuestions(userVO.getUuId(),
                    TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
        } catch (OperationFailedException ofe) {
            LOG.error("Exception in getting user challenge questions", ofe);
            userChallengeResp = null;
        }
        if (null != userChallengeResp && null != userChallengeResp.getUserChallengeQuestions()
                && !userChallengeResp.getUserChallengeQuestions().isEmpty()) {
            response.setSecQuestionAvailable(true);
            response.setSecQuestion1(userChallengeResp.getUserChallengeQuestions().get(0).getQuestion());
            response.setSecQuestion2(userChallengeResp.getUserChallengeQuestions().get(1).getQuestion());
        } else {
            response.setSecQuestionAvailable(false);
        }
        checkIfNoAccountRecovery(response);
    }

    /**
     * This method is to check if AccountRecovery is there or not for the user.
     * @param response ForgotAccessResponseVO
     */
    private void checkIfNoAccountRecovery(ForgotAccessResponseVO response) {
        if (!response.isPrimaryEmailVerified() && !response.isSecondaryEmailVerified() && !response.isPhoneVerified()
                && !response.isSecQuestionAvailable()) {
            response.setInvalidRecoveryOptns(true);
        }
    }

    /**
     * This method is to check Account Recovery Availablity Status for the user.
     * @param userVO UserVO
     * @param response ForgotAccessResponseVO
     * @param req HttpServletRequest
     */
    private void checkAccountRecoveryAvailablityStatus(UserVO userVO, ForgotAccessResponseVO response,
            HttpServletRequest req) {
        if (response.isPrimaryEmailVerified() && response.isSecondaryEmailVerified()) {
            response.setPrimaryEmailAndSecEmailVerified(true);
        }
        if (response.isSecQuestionAvailable()) {
            response.setSkipAccountRecovery(false);
        } else {
            if (response.isPrimaryEmailAndSecEmailVerified()) {
                response.setSkipAccountRecovery(false);
            } else {
                if (WorkflowConstants.WORKFLOW_FORGOT_USER_NAME.equals(response.getRequestType())) {
                    sendUserNameToUserViaPhoneOrEmail(userVO, response, req);
                } else if (WorkflowConstants.WORKFLOW_FORGOT_PWD.equals(response.getRequestType())
                        || WorkflowConstants.WORKFLOW_UNLOCK_USER_ACCOUNT.equals(response.getRequestType())) {
                    sendResetPasswordToUserViaPhoneOrEmail(userVO, response, req);
                } else if (WorkflowConstants.WORKFLOW_SETUP_SECURITY_QUESTIONS.equals(response.getRequestType())) {
                    sendResetSQAToUserViaPhoneOrEmail(userVO, response, req);
                }
            }
        }

    }

    /**
     * This method is to send user name for user vis email or phone.
     * @param userVO UserVO
     * @param response ForgotAccessResponseVO
     * @param req HttpServletRequest
     */
    private void sendUserNameToUserViaPhoneOrEmail(UserVO userVO, ForgotAccessResponseVO response, HttpServletRequest req) {
        String sendUserNameBy;
        if (response.isPrimaryEmailVerified() && !response.isSecondaryEmailVerified() && !response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            sendUserNameBy = "primaryEmail";
            sendInfoForUser(userVO, response, req, sendUserNameBy);
            response.setSuccessMessageKey("sendUserNameSuccessViaPrimaryEmail");
        } else if (!response.isPrimaryEmailVerified() && response.isSecondaryEmailVerified()
                && !response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            sendUserNameBy = "secondaryEmail";
            sendInfoForUser(userVO, response, req, sendUserNameBy);
            response.setSuccessMessageKey("sendUserNameSuccessViaSecondaryEmail");
        } else if (!response.isPrimaryEmailVerified() && !response.isSecondaryEmailVerified()
                && response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            sendUserNameBy = "phone";
            sendInfoForUser(userVO, response, req, sendUserNameBy);
            response.setSuccessMessageKey("sendUserNameSuccessViaPhone");
        }
    }

    /**
     * This method is to send user name for user vis email or phone.
     * @param userVO UserVO
     * @param response ForgotAccessResponseVO
     * @param req HttpServletRequest
     */
    private void sendResetPasswordToUserViaPhoneOrEmail(UserVO userVO, ForgotAccessResponseVO response,
            HttpServletRequest req) {
        if (response.isPrimaryEmailVerified() && !response.isSecondaryEmailVerified() && !response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            response.setRecoveryType("primaryEmail");
            constructUserAuthorizationRequestForAccountRecovery(userVO, req, true, TrustBrokerConstants.ACCOUNT_RECOVERY);
            response.setSuccessMessageKey("sendPasswordResetSuccessViaPrimaryEmail");
        } else if (!response.isPrimaryEmailVerified() && response.isSecondaryEmailVerified()
                && !response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            response.setRecoveryType("secondaryEmail");
            constructUserAuthorizationRequestForAccountRecovery(userVO, req, false, TrustBrokerConstants.ACCOUNT_RECOVERY);
            response.setSuccessMessageKey("sendPasswordResetSuccessViaSecondaryEmail");
        } else if (!response.isPrimaryEmailVerified() && !response.isSecondaryEmailVerified()
                && response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            sendOTPForPhone(userVO, response);
            response.setRecoveryType("phone");
            response.setSuccessMessageKey("sendPasswordResetSuccessViaPhone");
        }
    }

    /**
     * This method is used to check the skip account recovery options.
     * @param response ForgotAccessResponseVO
     */
    private void checkSkipAccountRecoveryOption(ForgotAccessResponseVO response) {
        if (response.isSkipAccountRecovery()) {
            WebApplicationContextHolder.getContext().setSessionAttribute(WorkflowConstants.WORKFLOW_RETURN_VERIFY_IDENTITY,
                    RETURN_VERIFY_IDENTITY_DISABLE);
        } else {
            WebApplicationContextHolder.getContext().setSessionAttribute(WorkflowConstants.WORKFLOW_RETURN_VERIFY_IDENTITY,
                    RETURN_VERIFY_IDENTITY_ENABLE);
        }
    }

    /**
     * This method is to send user name for user vis email or phone.
     * @param userVO UserVO
     * @param response ForgotAccessResponseVO
     * @param req HttpServletRequest
     */
    private void sendResetSQAToUserViaPhoneOrEmail(UserVO userVO, ForgotAccessResponseVO response, HttpServletRequest req) {
        if (response.isPrimaryEmailVerified() && !response.isSecondaryEmailVerified() && !response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            response.setRecoveryType("primaryEmail");
            constructUserAuthorizationRequestForAccountRecovery(userVO, req, true, TrustBrokerConstants.SQA);
            response.setSuccessMessageKey("sendPasswordResetSuccessViaPrimaryEmail");
        } else if (!response.isPrimaryEmailVerified() && response.isSecondaryEmailVerified()
                && !response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            response.setRecoveryType("secondaryEmail");
            constructUserAuthorizationRequestForAccountRecovery(userVO, req, false, TrustBrokerConstants.SQA);
            response.setSuccessMessageKey("sendPasswordResetSuccessViaSecondaryEmail");
        } else if (!response.isPrimaryEmailVerified() && !response.isSecondaryEmailVerified()
                && response.isPhoneVerified()) {
            response.setSkipAccountRecovery(true);
            sendOTPForPhone(userVO, response);
            response.setRecoveryType("phone");
            response.setSuccessMessageKey("sendPasswordResetSuccessViaPhone");
        }
    }

    /**
     * This method is used to send OTP for phone. 
     * @param userVO UserVO
     * @param response ForgotAccessResponseVO
     */
    private void sendOTPForPhone(UserVO userVO, ForgotAccessResponseVO response) {
        ResourceBundle bundle = getBundle();
        try {
            UserRetrievalServiceResponse userRetrievalServiceResponse = userService.fetchUserProfile(userVO.getUserName(),
                    false, true);
            UserAuthorizationResponse userAuthorizationResponse = userService
                    .generateAuthCodeToUser(userRetrievalServiceResponse.getUser().getUuId(), TrustBrokerConstants.SMSOTP);
            secureMessagingService.sendText(userRetrievalServiceResponse.getUser().getPhoneNumber(),
                    bundle.getString("OtpAccessCodeMsg") + userAuthorizationResponse.getUserAuthCode());
            response.setStatus(true);
        } catch (OperationFailedException e) {
            response.addMessage(FORM_ERR_KEY_NAME, bundle.getString("otpSendErrMsg"));
            response.setStatus(false);
            LOG.error("Error in sending OTP to your mobile number: ", e);
        }
    }

    /**
     * This method is to send user name for the user by primary email , sec
         * email or phone for the user.
     * @param userVO UserVO
     * @param response ForgotAccessResponseVO
     * @param req HttpServletRequest
     * @param sendUserNameBy String
     */
    private void sendInfoForUser(UserVO userVO, ForgotAccessResponseVO response, HttpServletRequest req,
            String sendUserNameBy) {
        RelyingPartyAppVO relyingPartyAppVO = getWebApplicationCommonUtilities()
                .getRelyingPartyApplicationDetailsFromContext();
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        String requestRelyingAppIdParam = ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
        if (relyingPartyAppVO != null) {
            response.setRelyingAppAlias(relyingPartyAppVO.getAlias());
            response.setRelyingAppId(requestRelyingAppIdParam);
        }
        if (TrustBrokerWebAppConstants.PRIMARY_EMAIL.equals(sendUserNameBy)) {
            getUserService().sendForgotUserNameMessage(userVO, CommunicationChannel.PRIMARY_EMAIL, requestRelyingAppIdParam,
                    getUrlLogoOptumId(req), getUrlLogoRelyingParty(req, requestRelyingAppIdParam));
            response.setStatus(true);
        } else if (TrustBrokerWebAppConstants.SECONDARY_EMAIL.equals(sendUserNameBy)) {
            getUserService().sendForgotUserNameMessage(userVO, CommunicationChannel.SECONDARY_EMAIL,
                    requestRelyingAppIdParam, getUrlLogoOptumId(req), getUrlLogoRelyingParty(req, requestRelyingAppIdParam));
            response.setStatus(true);
        } else if (TrustBrokerWebAppConstants.PHONE.equals(sendUserNameBy)) {

            getSecureMessagingService().sendText(userVO.getPhoneNumber(), "Optum ID: " + userVO.getUserName());

            response.setStatus(true);
        }
    }

    /**
     * This method is to validate the date for valid format and future date and
     * if not valid sets appropriate field error to response. 
     * @param mobileNum
     *                        String
     * @return boolean
     */
    private boolean validateDate(String dobStr, ForgotAccessResponseVO response) {
        boolean isValid = false;
        if (!StringUtils.isBlank(dobStr)) {
            final String dobFldErr = "doberr";
            // check for accepted formats
            isValid = DateUtil.validateDateMultipleFormats(dobStr);
            if (!isValid) {
                response.addMessage(dobFldErr, getMessage("dobinvalidmsg"));
            } else {
                // check if date entered is in future
                isValid = DateUtil.validateDateFuture(dobStr);
                if (!isValid) {
                    response.addMessage(dobFldErr, getMessage("dobfuturemsg"));
                }
            }
        }
        return isValid;
    }

    /**
     * This method is to check if the given mobile number is in valid format.
     * 
     * @param mobileNum String
         * @return boolean
     */
    private boolean validatePhoneMultipleFormats(String mobileNum) {
        boolean checkformat = false;
        if (!StringUtils.isEmpty(mobileNum)) {
            // If phone matches : 5555555555, 555-5555555, 555-555-5555, 555555-5555, 
            // (555)555-5555, (555)5555555,(555)-555-5555
            if (mobileNum.matches("([0-9]{10})") || mobileNum.matches("([0-9]{3})-([0-9]{7})")
                    || mobileNum.matches("([0-9]{3})-([0-9]{3})-([0-9]{4})") || mobileNum.matches("([0-9]{6})-([0-9]{4})")
                    || mobileNum.matches("([(]{1})([0-9]{3})([)]{1})([0-9]{3})-([0-9]{4})")
                    || mobileNum.matches("([(]{1})([0-9]{3})([)]{1})([0-9]{7})")
                    || mobileNum.matches("([(]{1})([0-9]{3})([)]{1})-([0-9]{3})-([0-9]{4})")) {
                checkformat = true;
            }
        }
        return checkformat;
    }

    /**
     * This method is to format the given phone number in valid format.
     * 
     * @param phoneNumber String
     * @return String
     */
    private String getFormattedPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || StringUtils.isEmpty(phoneNumber.trim())) {
            return null;
        }
        String phoneNumberInAcceptedBackendFormat = phoneNumber.replaceAll("\\D+", "");
        StringBuilder phone = new StringBuilder();
        phone.append("(");
        phone.append(phoneNumberInAcceptedBackendFormat.substring(0, 3));
        phone.append(")");
        phone.append(phoneNumberInAcceptedBackendFormat.substring(3, 6));
        phone.append("-");
        phone.append(phoneNumberInAcceptedBackendFormat.substring(6));
        return phone.toString();
    }

    /**
     * This method is to retrieve Sec Questions for User.
     * @param userVO UserVO
     * @param request ForgotAccessRequestVO
     * @param request UserChallengeQuestionServiceResponse
     */
    private UserChallengeQuestionServiceResponse retrieveChallengeQuestionsofUser(UserVO userVO,
            ForgotAccessRequestVO request) {
        UserChallengeQuestionServiceResponse userChallengeResp = null;
        try {
            userChallengeResp = getUserService().getChallengeQuestions(userVO.getUuId(),
                    TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
            if (null != userChallengeResp && null != userChallengeResp.getUserChallengeQuestions()
                    && !userChallengeResp.getUserChallengeQuestions().isEmpty()) {
                userChallengeResp.getUserChallengeQuestions().get(0).setAnswer(request.getSecAns1());
                userChallengeResp.getUserChallengeQuestions().get(1).setAnswer(request.getSecAns2());
            }

        } catch (OperationFailedException ofe) {
            LOG.error("Error in getting user security questions: ", ofe);
        }

        return userChallengeResp;
    }

    /** 
     * This method is to mask the phone number.
     * @param phoneNumber String
     * @return String
     */
    public static String phoneMask(String phoneNumber) {
        try {
            if (!StringUtils.isEmpty(phoneNumber)) {
                StringBuilder buf = new StringBuilder(phoneNumber);
                int index = buf.indexOf("(");
                buf.replace(index, index + 1, "");
                index = buf.indexOf(")");
                buf.replace(index, index + 1, "");
                index = buf.indexOf("-");
                buf.replace(index, index + 1, "");
                return buf.replace(0, 6, StringUtils.repeat("*", 6)).toString();
            }
        } catch (IndexOutOfBoundsException e) {
            LOG.error("Error in phone masking: " + phoneNumber + e);
        }
        return phoneNumber;
    }

    /**
     * This method is to mask the email.
     * @param emailAddress String
     * @return String
     */
    public static String emailMask(String emailAddress) {
        try {
            if (!StringUtils.isEmpty(emailAddress)) {
                String[] emailArray = emailAddress.split("@");
                String firstPart = emailArray[0];
                StringBuffer buf = new StringBuffer(firstPart);
                if (firstPart.length() == 3) {
                    buf.replace(1, 2, StringUtils.repeat("*", 1));
                }
                if (firstPart.length() == 4) {
                    buf.replace(1, 3, StringUtils.repeat("*", 2));
                }
                if (firstPart.length() == 5) {
                    buf.replace(2, 4, StringUtils.repeat("*", 2));
                }
                if (firstPart.length() == 6) {
                    buf.replace(2, 4, StringUtils.repeat("*", 2));
                }
                if (firstPart.length() == 7) {
                    buf.replace(2, 5, StringUtils.repeat("*", 3));
                }
                if (firstPart.length() > 7) {
                    buf.replace(3, firstPart.length() - 2, StringUtils.repeat("*", firstPart.length() - 5));
                }
                return emailAddress.replace(firstPart, buf.toString());
            }
        } catch (IndexOutOfBoundsException e) {
            LOG.error("Error in email masking: " + emailAddress + e);
        }
        return emailAddress;
    }

    /**
     * This method is to use account lock status.
     * @param response ForgotAccessResponseVO
     */
    private void userAccountLocked(ForgotAccessResponseVO response) {
        ResourceBundle bundle = getBundle();
        response.setAccountLockedStatus("LOCKED");
        response.addMessage(SEC_ANS_MISMATCHED_LOCKED_SAME_PAGE, bundle.getString("secAnswersMisMatchAccLockedSamepage"));
        response.setStatus(false);
    }

    /**
     * This method is to verify security questions.
     * @param userVO UserVO
     * @return String
     */
    private String verifySecurityAnswers(UserVO userVO, UserChallengeQuestionServiceResponse userChallengeResp) {
        AuthenticateChallengeQuestionServiceRequest authReqObj = new AuthenticateChallengeQuestionServiceRequest();
        authReqObj.setSessionId(userChallengeResp.getSessionId());
        authReqObj.setTransactionId(userChallengeResp.getTransactionId());
        authReqObj.setUserChallengeQuestions(userChallengeResp.getUserChallengeQuestions());
        authReqObj.setUuid(userVO.getUuId());
        authReqObj.setNoOfQuestions(TrustBrokerWebAppConstants.NO_OF_USER_CHALLENGE_QUESTIONS);
        return getUserService().authenticateChallengeQuestion(authReqObj);
    }

    /**
     * This method is to construct URL for Reset Password.
     * @param userVO UserVO
     * @param req HttpServletRequest
     * @param emailType boolean
     */
    private void constructUserAuthorizationRequestForAccountRecovery(UserVO userVO, HttpServletRequest req,
            boolean emailType, String recoveryType) {
        UserAuthorizationRequest userAuthorizationRequest = new UserAuthorizationRequest();
        WebApplicationContext ctx = WebApplicationContextHolder.getContext();
        
        String acctURL = "";
        if (TrustBrokerConstants.SQA.equalsIgnoreCase(recoveryType)) {            
            acctURL = "/link/setup-security-questions";
        } else if (TrustBrokerConstants.ACCOUNT_RECOVERY.equalsIgnoreCase(recoveryType)) {            
            acctURL = "/link/reset-password";
        }

        userAuthorizationRequest.setUser(userVO);
        String resetAccountURL = TBUtil.generateContextPath(req) + acctURL;
        String rpAppId = "";
        if (ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET) != null
                && ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM) != null) {
            rpAppId = ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
            resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM,
                    (String) ctx.getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM));
            resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.TARGET,
                    (String) ctx.getSessionAttribute(TrustBrokerWebAppConstants.TARGET));
            
            resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.AUTH_CODE, "");
        } else {
           
            resetAccountURL = HttpUtils.addParameterToURL(resetAccountURL, TrustBrokerWebAppConstants.AUTH_CODE, "");
        }
        userAuthorizationRequest.setResetAccountLink(resetAccountURL);
        userService.sendAuthCodeToUser(userAuthorizationRequest, recoveryType, rpAppId, emailType, getUrlLogoOptumId(req),
                getUrlLogoRelyingParty(req, rpAppId));
    }
}
