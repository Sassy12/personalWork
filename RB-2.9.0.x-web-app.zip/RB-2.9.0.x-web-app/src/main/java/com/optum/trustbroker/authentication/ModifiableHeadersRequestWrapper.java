/*
 * Copyright (C) 2013 UnitedHealth Group
 *
 * All rights reserved.
 */
package com.optum.trustbroker.authentication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * An HttpServletRequest wrapper which allows for the overriding
 * of HTTP Header values.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
public class ModifiableHeadersRequestWrapper extends HttpServletRequestWrapper {
    private Map<String, String> headerOverride = new HashMap<String, String>();

    private Map<String, String> paramOverride = new HashMap<String, String>();

    /**
     * Initializes the wrapper with the specified request.
     *
     * @param request The request to be wrapped.
     */
    public ModifiableHeadersRequestWrapper(HttpServletRequest request) {
        super(request);
    }

    /**
     * Sets the HTTP Header value to the supplied value.  This
     * value will override any existing HTTP Header value in the
     * wrapped request.
     *
     * @param name  The name of the HTTP Header to be overridden.
     * @param value The value to be set to the header.
     */
    public void setHeaderOverride(String name, String value) {
        headerOverride.put(name, value);
    }

    /**
     * Sets the HTTP Header value to the supplied value.  This
     * value will override any existing HTTP Header value in the
     * wrapped request.
     *
     * @param name  The name of the HTTP Header to be overridden.
     * @param value The value to be set to the header.
     */
    public void setParameterOverride(String name, String value) {
        paramOverride.put(name, value);
    }

    /**
     * Returns the wrapped HttpServletRequest.
     *
     * @return The wrapped HttpServletRequest.
     */
    private HttpServletRequest getHttpServletRequest() {
        return (HttpServletRequest) super.getRequest();
    }

    @Override
    public Enumeration getHeaderNames() {
        if (headerOverride.isEmpty()) {
            return super.getHeaderNames();
        } else {
            HashSet<String> names = new HashSet<String>();
            for (Enumeration eNames = super.getHeaderNames(); eNames.hasMoreElements();) {
                names.add((String) eNames.nextElement());
            }

            names.addAll(headerOverride.keySet());
            return Collections.enumeration(names);
        }

    }

    @Override
    public Enumeration getParameterNames() {
        if (paramOverride.isEmpty()) {
            return super.getParameterNames();
        } else {
            HashSet<String> names = new HashSet<String>();
            for (Enumeration eNames = super.getParameterNames(); eNames.hasMoreElements();) {
                names.add((String) eNames.nextElement());
            }

            names.addAll(paramOverride.keySet());
            return Collections.enumeration(names);
        }

    }

    @Override
    public String getHeader(String name) {
        if (headerOverride.containsKey(name)) {
            return headerOverride.get(name);
        } else {
            return super.getHeader(name);
        }
    }

    @Override
    public String getParameter(String name) {
        if (paramOverride.containsKey(name)) {
            return paramOverride.get(name);
        } else {
            return super.getParameter(name);
        }
    }
}
