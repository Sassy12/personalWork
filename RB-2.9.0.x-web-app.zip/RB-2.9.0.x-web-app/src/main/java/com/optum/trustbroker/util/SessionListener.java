/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2014.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When          Who         Why
 * Nov 18 2014   bmanna3		Initial version
 ****************************************************************/
package com.optum.trustbroker.util;

import java.util.Collections;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.commons.collections.map.LRUMap;

public class SessionListener implements HttpSessionListener {
    
    public static final String ACTIVE_VIEW_MAPS = "com.sun.faces.application.view.activeViewMaps";
   
	/**
	 * This method is to provide functionality when a new session is created .
	 *
	 * @param _se HttpSessionEvent
	 */
	@Override
    public void sessionCreated(final HttpSessionEvent _se) {
        final HttpSession session = _se.getSession();
        session.setAttribute(ACTIVE_VIEW_MAPS, Collections.synchronizedMap(new LRUMap()));
    }
	
	/**
	 * This method is to provide functionality when session is destroyed .
	 *
	 * @param _se HttpSessionEvent
	 */
	@Override
    public void sessionDestroyed(HttpSessionEvent _se) {
    }
}