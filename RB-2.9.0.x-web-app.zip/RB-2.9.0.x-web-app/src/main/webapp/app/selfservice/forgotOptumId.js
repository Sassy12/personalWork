(function() {
    'use strict';

    var module = angular.module('indexApp');

    module.controller('forgotAccessController', ['$scope', '$state', '$timeout', 'trustbrokerAriaService', 'LanguageService', 'forgotAccessService', '$rootScope', 'HelpObj','AnalyticsService',
        function($scope, $state, $timeout, trustbrokerAriaService, LanguageService, forgotAccessService, $rootScope, HelpObj, AnalyticsService) {

            HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1021_Forgot_Optum_ID.htm' });
            $scope.hideInput = true;
            $scope.hideEmailText = true;
            $scope.hideUserNameText = true;
            $scope.selectionChangedToRadio1 = false;
            $scope.selectionChangedToRadio2 = false;
            $scope.emailErrorMsg = '';
            $scope.usernameErrorMsg = '';
            $scope.userNameError = false;
            $scope.userEmailError = false;
            LanguageService.doTranslate("selfservice");
            $scope.accountSearchCount = 0;
            $scope.disableNext = false;
            $scope.forgotUsernameInital = false;

            $scope.errorMessageModel = {
                id: 'errorMessage',
                messageType: 'error',
                messageRole: 'alert',
                content: '',
                visible: false,
                position: 'inline',
                headingLevel: '2',
                animationTime: 1
            };

            $scope.userNameForgot = function() {
                // angular.element('#emailText_input').focus();
                $scope.errorMessageModel.visible = false;
                $scope.setFieldDefaults();
                $scope.hideEmailText = false;
                $scope.hideUserNameText = true;
                $scope.selectionChangedToRadio1 = true;
                $scope.selectionChangedToRadio2 = false;
                $scope.userName = '';
                $scope.usernameErrorMsg = '';
                $scope.userNameError = false;
                $scope.userEmailError = false;
            };

            $scope.forgotPassword = function() {
                // angular.element('#userNameText_input').focus();
                $scope.errorMessageModel.visible = false;
                $scope.setFieldDefaults();
                $scope.hideEmailText = true;
                $scope.hideUserNameText = false;
                $scope.selectionChangedToRadio1 = false;
                $scope.selectionChangedToRadio2 = true;
                $scope.email = '';
                $scope.emailErrorMsg = '';
                $scope.userNameError = false;
                $scope.userEmailError = false;
            };

            $scope.disableContents = function() {
                $scope.forgotUsernameInital = true;

                angular.element("#usernameLabel").removeClass("tb-disabled-grey");
                angular.element("#emailLabel").addClass("tb-disabled-grey");
                angular.element("#findUsrwMoreInfoLink").addClass("tb-disabled tb-disabled-grey");
                angular.element("#findUsrwMoreInfoLink").attr("tabindex", -1);
            };

            $scope.enableContents = function() {
                $scope.forgotUsernameInital = false;

                angular.element("#findUsrwMoreInfoLink").removeClass("tb-disabled tb-disabled-grey");
                angular.element("#findUsrwMoreInfoLink").removeAttr("tabindex");
                angular.element("#usernameLabel").addClass("tb-disabled-grey");
                angular.element("#emailLabel").removeClass("tb-disabled-grey");
            };

            $scope.setFieldDefaults = function() {
                // $scope.errorMessageModel.visible = false;
                $scope.userNameError = false;
                $scope.userEmailError = false;
                // $scope.errorMessageModel.content = '';
            };

            $scope.onUserEmailKeyup = function() {
                if ($scope.forgotCredentialForm.email) {
                    if (!$scope.userEmailError) {
                        $scope.userNameError = false;
                        $scope.userEmailError = false;
                    }
                }

                if ($scope.emailErrorMsg === '' || $scope.emailErrorMsg === undefined) {
                    $scope.userEmailError = false;
                }
            };

            $scope.onUserNameKeyup = function() {
                if ($scope.forgotCredentialForm.userName) {
                    if (!$scope.userNameError) {
                        $scope.userNameError = false;
                        $scope.userEmailError = false;
                    }
                }
            };

            $scope.setFieldValidity = function(inputid, spanid) {
                trustbrokerAriaService.setFieldValidity(inputid, spanid);
            };

            $scope.disableNextButton = function() {
                $scope.errorMessageModel.content = '<span translate="disablePageMsg"></span>';
                $scope.errorMessageModel.visible = true;
                $scope.disableNext = true;

                // For WCAG
                $timeout(function() {
                    angular.element('#errorMessage').focus();
                }, 300);

                // To enable the field after 2 mins
                $timeout(function() {
                    $state.reload();
                }, 120000);
            };

            $scope.disableNextButtonWarning = function() {
                $scope.errorMessageModel.content = '<span translate="disablePageWarningMsg"></span>';
                $scope.errorMessageModel.visible = true;
                // For WCAG
                $timeout(function() {
                    angular.element('#errorMessage').focus();
                }, 300);
            };

            $scope.setAriaInvalid = function() {
                trustbrokerAriaService.setAriaInvalid('emailText_input', null);
                trustbrokerAriaService.setAriaInvalid('userNameText_input', null);
            };

            $scope.nextScreen = function() {
                $scope.emailErrorMsg = '';
                $scope.usernameErrorMsg = '';
                $scope.validateProcess();
            };

            $scope.validateProcess = function() {
                if ($scope.email === '' || $scope.email === undefined) {
                    $scope.emailNotEntered();
                    $scope.ariaUpdate();
                    $rootScope.fireErrorTracker = true;
                }else{
                    $scope.findUser();
                }
            };

            $scope.findUser = function() {
                var recoveryType = $scope.getRecoveryType();
                var postData = {
                    'recoveryType': recoveryType,
                    'email': $scope.email,
                    'userName': $scope.userName
                };

                forgotAccessService.getUserEmailType(postData).then(function(response) {
                    var responseVO = response.data;
                    var status = responseVO.status;

                    if (status) {
                        if (responseVO.uniqueEmail) {
                            $state.go('forgotCredByIdentity', { userinfo: { 'userName': responseVO.userName } });
                        } else {
                            if ($scope.selectionChangedToRadio1) {
                                $state.go("forgotcredentialPage");
                            } else {
                                $state.go("findpwdwmoreinfo");
                            }
                        }
                    } else if (!status) {
                        if (responseVO.invalidRecoveryOptns) {
                            $state.go("norecoveryoption");
                        } else {
                            $scope.processErrMsgs(responseVO);
                            $rootScope.fireErrorTracker = true;
                        }
                    }
                });
            };

            $scope.processErrMsgs = function(responseVO) {
                var messages = responseVO.messages;

                $scope.errorMessageModel.content = '<span>' + messages.formerr + '</span>';
                $scope.errorMessageModel.visible = true;
                var emailErr = messages.emailerr;
                var usernameErr = messages.usernameerr;
                $scope.userEmailError = false;
                $scope.userNameError = false;

                if (emailErr !== '' && emailErr !== undefined) {
                    $scope.emailErrorMsg = emailErr;
                    $scope.userEmailError = true;
                } else {
                    // NEED TO VERIFY THIS WITH NEW DESIGN AND MAX CHARACTER LENGTH ERROR (FOR NOW WORKING FINE)
                    $('#emailText_input').removeAttr('aria-describedby');
                }

                if (usernameErr !== '' && usernameErr !== undefined) {
                    $scope.usernameErrorMsg = usernameErr;
                    $scope.userNameError = true;
                } else {
                    // NEED TO VERIFY THIS WITH NEW DESIGN AND MAX CHARACTER LENGTH ERROR (FOR NOW WORKING FINE)
                    $('#userNameText_input').removeAttr('aria-describedby');
                }
                
                if (!emailErr && !usernameErr) {
                    $scope.accountSearchCount++;
                    AnalyticsService.postErrorTrackInfo("wrong credentials entered", "");
                }
                
                $scope.ariaUpdate();
                
                if ($scope.accountSearchCount === 4) {
                    $scope.disableNextButtonWarning();
                }

                if ($scope.accountSearchCount >= 5) {
                    $scope.disableNextButton();
                }
            };

            $scope.ariaUpdate = function() {
                var FIELDS = [];

                if ($scope.userEmailError) {
                    FIELDS = [{
                        fld: "emailText_input",
                        msg: "emailId_err"
                    }];
                } else if ($scope.userNameError) {
                    FIELDS = [{
                        fld: "userNameText_input",
                        msg: "userNameId_err"
                    }];
                } else {
                    $timeout(function() {
                        angular.element('#errorMessage').focus();
                    }, 300);
                }

                if (FIELDS.length > 0) {
                    $timeout(function() {
                        trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                        $scope.formErrorIsHidden = false;
                    }, 300);
                }
                return;
            };

            $scope.emailNotEntered = function() {
                $scope.emailErrorMsg = 'FgtUsrPwdCreEmlRqdMsg';
                $scope.errorMessageModel.content = '<span translate="FgtUsrPwdCreUsrErrMsg"></span>';
                $scope.errorMessageModel.visible = true;
                $scope.userEmailError = true;
            };

            $scope.usernameNotEntered = function() {
                $scope.usernameErrorMsg = 'FgtUsrPwdCreUnmRqdMsg';
                $scope.errorMessageModel.content = '<span translate="FgtUsrPwdCrePwdErrMsg"></span>';
                $scope.errorMessageModel.visible = true;
                $scope.userNameError = true;
            };

            $scope.getRecoveryType = function() {
                return "ForgotUser";
            };

            $scope.navFindUsrwMoreInfo = function() {
                if (!$scope.selectionChangedToRadio2) {
                    $state.go("findusrwmoreinfo");
                }
            };

            $scope.cancelNav = function() {
                $state.go("login");
            };
        }
    ]);
})();
