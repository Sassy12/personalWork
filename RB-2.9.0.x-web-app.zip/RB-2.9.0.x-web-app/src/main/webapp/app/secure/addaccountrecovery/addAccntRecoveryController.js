'use strict';

var tbApp = angular.module('tbApp');

tbApp.controller("AddAccountRevoceryCtrl", ['$scope', 'recovInfo', '$window', 'addAccountRecoveryService', 'LanguageService', 'trustbrokerAriaService', '$timeout', '$rootScope', 'AnalyticsService', addAccountRecoveryCtrl]);

function addAccountRecoveryCtrl($scope, recovInfo, $window, addAccountRecoveryService, LanguageService, trustbrokerAriaService, $timeout, $rootScope, AnalyticsService) {

    LanguageService.doTranslate('addaccountrecovery');

    // initialising initial flags
    $scope.addMobilePhone = false;
    $scope.addSecQues = false;

    $scope.addAccountRecoveryErrorMsgModel = {
        animationTime: 1,
        content: '',
        headingLevel: '2',
        id: 'addAccountRecoveryFormLevelMsgID',
        messageRole: 'alert',
        messageType: 'error',
        position: 'inline',
        visible: false
    };

    var recovMethods = [];
    recovMethods = recovInfo.data.recoveryMethods;

    var select = {
        label: '--Select--',
        value: ''
    };

    if (recovMethods[0] === "phoneNumber" || recovMethods[1] === "phoneNumber") {
        $scope.addMobilePhone = true;
    } else {
        $scope.addMobilePhone = false;
    }

    if (recovMethods[0] === "securityQuestions" || recovMethods[1] === "securityQuestions") {
        $scope.addSecQues = true;
        var secQuestions = [];
        secQuestions = recovInfo.data.securityQuestionVO.questions;
        secQuestions.unshift(select);
        $scope.secList1 = angular.copy(secQuestions);
        $scope.secList2 = angular.copy(secQuestions);
        $scope.secList3 = angular.copy(secQuestions);
    } else {
        $scope.addSecQues = false;
    }

    $scope.validateSecAnsText = function(event) {
        return validators.validateSecAns(event);
    };

    $scope.skipAccRecovery = function() {
        addAccountRecoveryService.skipAccountRecovery().then(function() {
            $window.location.href = "/tb/app/secure/home.do";
        });
    };

    $scope.addAccountRecovMethod = function() {
        resetErrors();
        var count = 0;

        var FIELDS = [
            { fld: "mobilePhone_input", msg: "phoneFormatId_err" },
            { fld: "secQues1Id",        msg: "secQuestionOneId_err" },
            { fld: "secAnswerOneId",    msg: "secAnswerOneId_err" },
            { fld: "secAnswerOneId",    msg: "secAnswer1ValidationError" },
            { fld: "secQues2Id",        msg: "secQuestionTwoId_err" },
            { fld: "secAnswerTwoId",    msg: "secAnswerTwoId_err" },
            { fld: "secAnswerTwoId",    msg: "secAnswer2ValidationError" },
            { fld: "secQues3Id",        msg: "secQuestionThreeId_err" },
            { fld: "secAnswerThreeId",  msg: "secAnswerThreeId_err" },
            { fld: "secAnswerThreeId",  msg: "secAnswer3ValidationError" }
        ];

        if ($scope.addSecQues) {
            if ($scope.secQues1 === undefined || validators.checkIfEmpty($scope.secQues1)) {
                $scope.secQues1ReqErr = true;
                count++;
            } else {
                $scope.secQues1ReqErr = false;
            }

            if ($scope.secAnswerOne === undefined || validators.checkIfEmpty($scope.secAnswerOne)) {
                $scope.secAns1ReqErr = true;
                count++;
            } else {
                $scope.secAns1ReqErr = false;
            }

            if ($scope.secQues2 === undefined || validators.checkIfEmpty($scope.secQues2)) {
                $scope.secQues2ReqErr = true;
                count++;
            } else {
                $scope.secQues2ReqErr = false;
            }

            if ($scope.secAnswerTwo === undefined || validators.checkIfEmpty($scope.secAnswerTwo)) {
                $scope.secAns2ReqErr = true;
                count++;
            } else {
                $scope.secAns2ReqErr = false;
            }

            if ($scope.secQues3 === undefined || validators.checkIfEmpty($scope.secQues3)) {
                $scope.secQues3ReqErr = true;
                count++;
            } else {
                $scope.secQues3ReqErr = false;
            }

            if ($scope.secAnswerThree === undefined || validators.checkIfEmpty($scope.secAnswerThree)) {
                $scope.secAns3ReqErr = true;
                count++;
            } else {
                $scope.secAns3ReqErr = false;
            }
        }

        if ($scope.addMobilePhone && $scope.addSecQues) {
            if (!$scope.mobilePhoneNum && count === 6) {
                showNoInputMsg();
                return;
            }
        } else if ($scope.addMobilePhone && !$scope.addSecQues) {
            if (!$scope.mobilePhoneNum && count === 0) {
                showNoInputMsg();
                return;
            }
        } else if (!$scope.addMobilePhone && $scope.addSecQues) {
            if (count === 6) {
                showNoInputMsg();
                return;
            }
        }

        if (count < 6 && count > 0) {
            $scope.enableSecQAFieldError = true;
        } else {
            $scope.enableSecQAFieldError = false;
        }

        if ($scope.enableSecQAFieldError) {
            $scope.addAccountRecoveryErrorMsgModel.visible = true;
            $scope.addAccountRecoveryErrorMsgModel.content = "<span translate='correctFieldsMsg'></span>";
            $rootScope.fireErrorTracker = true;

            $timeout(function() {
                trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
            }, 300);

            return;
        } else {
            $scope.addAccountRecoveryErrorMsgModel.visible = false;
        }

        if ($scope.addAccountRecoveryForm.$valid) {
            var postData = {};
            var securityQuestionVO = {};

            if ($scope.addSecQues && count !== 6) {
                securityQuestionVO = {
                    "questionOne": $scope.secQues1.value,
                    "ansOne": $scope.secAnswerOne,
                    "questionTwo": $scope.secQues2.value,
                    "ansTwo": $scope.secAnswerTwo,
                    "questionThree": $scope.secQues3.value,
                    "ansThree": $scope.secAnswerThree
                };
            }

            if ($scope.addMobilePhone && !$scope.addSecQues) {
                postData = {
                    "mobilePhoneNum": $scope.mobilePhoneNum
                };
            } else if ($scope.addMobilePhone && $scope.addSecQues) {
                if (count === 6) {
                    postData = {
                        "mobilePhoneNum": $scope.mobilePhoneNum
                    };
                } else if (count === 0) {
                    postData = {
                        "mobilePhoneNum": $scope.mobilePhoneNum,
                        "securityQuestionVO": securityQuestionVO
                    };
                }
            } else if (!$scope.addMobilePhone && $scope.addSecQues) {
                postData = {
                    "securityQuestionVO": securityQuestionVO
                };
            }

            addAccountRecoveryService.updateUserRecoveryMethods(postData).then(function(response) {
                var errorMap = response.data.errorMap;

                if (errorMap !== null && errorMap !== undefined && Object.keys(errorMap).length > 0) {

                    $scope.addAccountRecoveryErrorMsgModel.visible = true;
                    $scope.addAccountRecoveryErrorMsgModel.content = "<span>The highlighted fields should be corrected first.</span>";

                    if ("phoneNo" in errorMap) {
                        $scope.phoneFormatError = errorMap.phoneNo;
                    }

                    if ("secAns1ErrorMsg" in errorMap) {
                        $scope.secAns1ErrorMsg = errorMap.secAns1ErrorMsg;
                    }

                    if ("secAns2ErrorMsg" in errorMap) {
                        $scope.secAns2ErrorMsg = errorMap.secAns2ErrorMsg;
                    }

                    if ("secAns3ErrorMsg" in errorMap) {
                        $scope.secAns3ErrorMsg = errorMap.secAns3ErrorMsg;
                    }

                    $rootScope.fireErrorTracker = true;

                    $timeout(function() {
                        trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    }, 300);
                } else {
                    $scope.addAccountRecoveryErrorMsgModel.visible = false;

                    if (response.data.nextState === "mobileNumVerification") {
                        console.log(response.data.nextState);
                        $window.location.href = "/tb/app/secure/home.do";
                    } else if (response.data.nextState === "noNextState") {
                        $window.location.href = "/tb/app/secure/home.do";
                    }
                }
            });
        }
    };

    function resetErrors() {
        $scope.enableSecQAFieldError = false;
        $scope.phoneFormatError = false;
        $scope.addAccountRecoveryErrorMsgModel.visible = false;
        $scope.secQues1ReqErr = false;
        $scope.secAns1ReqErr = false;
        $scope.secQues2ReqErr = false;
        $scope.secAns2ReqErr = false;
        $scope.secQues3ReqErr = false;
        $scope.secAns3ReqErr = false;
        $scope.secAns1ErrorMsg = false;
        $scope.secAns2ErrorMsg = false;
        $scope.secAns3ErrorMsg = false;
    }

    function showNoInputMsg() {
        $scope.enableSecQAFieldError = false;
        $scope.addAccountRecoveryErrorMsgModel.visible = true;
        $scope.addAccountRecoveryErrorMsgModel.content = "<span translate='bypassRecoveryProcessMsg'></span>";
        AnalyticsService.postErrorTrackInfo("no option selected", "");
    }
}
