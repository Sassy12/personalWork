package com.optum.trustbroker.managebean.widget;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.UserVO;

/**
 * @author nvaneps
 */
public class VerifyCodesContext implements Serializable{
	
	private static final long serialVersionUID = 1L;
	public static final String SESSION_NAME = "verify-codes-context";
	private List<CommunicationChannel> viewChannels;
	private List<CommunicationChannel> sendChannels;
	private CommunicationChannel updateChannel;
	private boolean hideUpdateButtons;
	private boolean hideResendButtons;
	private boolean showDeviceRegistration;
	private boolean skipAndContinue;
	private String nextView;
	private boolean autoVerify;
	private Map<CommunicationChannel, String> prePopulatedCodes;
	private UserVO userVO;
	private String verifyCodePgDimension = PAGE_6X4_DIMENSION;
	
	public static String PAGE_6X4_DIMENSION = "w-bodylayout6x4";
	public static String PAGE_6X5_DIMENSION = "w-bodylayout6x5";
	public static String PAGE_7X3_DIMENSION = "w-bodylayout7x3";
	
	public VerifyCodesContext() {
		prePopulatedCodes = new EnumMap<CommunicationChannel, String>(CommunicationChannel.class);
	}

	public List<CommunicationChannel> getViewChannels() {
		if (viewChannels == null) {
			viewChannels = new ArrayList<CommunicationChannel>();
		}
		return viewChannels;
	}

	public void setViewChannels(List<CommunicationChannel> viewChannels) {
		this.viewChannels = viewChannels;
	}

	public List<CommunicationChannel> getSendChannels() {
		if (sendChannels == null) {
			sendChannels = new ArrayList<CommunicationChannel>();
		}
		return sendChannels;
	}

	public void setSendChannels(List<CommunicationChannel> sendChannels) {
		this.sendChannels = sendChannels;
	}

	public boolean isHideUpdateButtons() {
		return hideUpdateButtons;
	}

	public void setHideUpdateButtons(boolean hideUpdateButtons) {
		this.hideUpdateButtons = hideUpdateButtons;
	}

	public String getNextView() {
		if (nextView == null) {
			nextView = "";
		}
		return nextView;
	}

	public void setNextView(String nextView) {
		this.nextView = nextView;
	}

	public boolean isAutoVerify() {
		return autoVerify;
	}

	public void setAutoVerify(boolean autoVerify) {
		this.autoVerify = autoVerify;
	}

	public Map<CommunicationChannel, String> getPrePopulatedCodes() {
		return prePopulatedCodes;
	}

	public void setPrePopulatedCodes(Map<CommunicationChannel, String> prePopulatedCodes) {
		this.prePopulatedCodes = prePopulatedCodes;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public CommunicationChannel getUpdateChannel() {
		return updateChannel;
	}

	public void setUpdateChannel(CommunicationChannel updateChannel) {
		this.updateChannel = updateChannel;
	}

	public boolean isShowDeviceRegistration() {
		return showDeviceRegistration;
	}

	public void setShowDeviceRegistration(boolean showDeviceRegistration) {
		this.showDeviceRegistration = showDeviceRegistration;
	}

	public boolean isHideResendButtons() {
		return hideResendButtons;
	}

	public void setHideResendButtons(boolean hideResendButtons) {
		this.hideResendButtons = hideResendButtons;
	}

	public String getVerifyCodePgDimension() {
		return verifyCodePgDimension;
	}

	public void setVerifyCodePgDimension(String verifyCodePgDimension) {
		this.verifyCodePgDimension = verifyCodePgDimension;
	}

	public boolean isSkipAndContinue() {
		return skipAndContinue;
	}

	public void setSkipAndContinue(boolean skipAndContinue) {
		this.skipAndContinue = skipAndContinue;
	}

}