package com.optum.trustbroker.controller.vo;

public class SiteminderVO {
	
	private String aboutToExpiredMsg;
	private String pwd;
	private String confirmPwd;
	private String userName;
	
	public String getAboutToExpiredMsg() {
		return aboutToExpiredMsg;
	}
	public void setAboutToExpiredMsg(String aboutToExpiredMsg) {
		this.aboutToExpiredMsg = aboutToExpiredMsg;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getConfirmPwd() {
		return confirmPwd;
	}
	public void setConfirmPwd(String confirmPwd) {
		this.confirmPwd = confirmPwd;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
