--------------------------------------------------------
--  File created - Thursday-Aug-18-2016   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Migration 
--------------------------------------------------------

CREATE SEQUENCE label_id 
  MINVALUE 1
  START WITH 101
  INCREMENT BY 1
  CACHE 20;
DECLARE
  file_description VARCHAR2(256) := 'RP Image Description';
  attribute_type VARCHAR2(30) := 'RP_IMAGE';
  content_type VARCHAR2(30):= 'img/css';
  active VARCHAR2(1):= 'Y';
  labelId_count INTEGER := 100;
BEGIN
    DELETE FROM RP_WHITE_LABEL WHERE RP_LBL_ID > labelId_count;
    INSERT INTO RP_WHITE_LABEL(RP_LBL_ID,RP_APP_ID,FILE_DESCRIPTION,ATTRIBUTE_TYPE,CONTENT_TYPE,FILE_CONTENT,ACTIVE,CREATED_BY, CREATED_TS,MODIFIED_TS)
    SELECT label_id.NEXTVAL , a.ID ,file_description,attribute_type,content_type, b.RP_LOGO ,active,a.created_by,b.CREATE_DATE,b.UPDATE_DATE FROM RP_APP_IMAGE b
    LEFT OUTER JOIN RP_APP a ON b.RP_APP_ID = a.ID;
    COMMIT;
    EXECUTE IMMEDIATE 'DROP SEQUENCE label_id';
END;
