'use strict';

var tbApp = angular.module('tbApp');

tbApp.service("addAccountRecoveryService", [ '$http', function($http) {

	this.getRecovInfo = function() {

		return $http.get("/tb/services/secure/rest/addAccountRecovery/recoveryInfo");

	};
	
	this.updateUserRecoveryMethods=function(postData){
		
		return $http.post("/tb/services/secure/rest/addAccountRecovery/updateRecoveryInfo",postData);
	};
	
	this.skipAccountRecovery=function(){
		
		return $http.get("/tb/services/secure/rest/addAccountRecovery/skipAccountRecovery");
		
	};

} ]);
