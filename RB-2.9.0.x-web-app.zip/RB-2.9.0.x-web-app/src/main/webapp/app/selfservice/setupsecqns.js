'use strict';

angular.module('indexApp').controller('setSecurityQuestionsController', setSecurityQuestionsController);

setSecurityQuestionsController.$inject = ['$scope', 'trustbrokerAriaService', '$state', '$stateParams', 'LanguageService', 'mainMessage', 'HelpObj'];

function setSecurityQuestionsController($scope, trustbrokerAriaService, $state, $stateParams, LanguageService, mainMessage, HelpObj) {
    $scope.setFieldValidity = function(inputid, spanid) {
        trustbrokerAriaService.setFieldValidity(inputid, spanid);
    };

    HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1029_Set_Up_Your_Security_Questions.htm' });

    pageDataLayer.content.pageName = "setupsecurityquestions";
    pageDataLayer.content.siteSectionL1 = "";

    if (typeof _satellite !== "undefined") {
        _satellite.track('trackPageView');
    }

    LanguageService.doTranslate("selfservice");
    // You should use the i18n en_US.json file for text - JT

    $scope.userName = $stateParams.userName;

    $scope.ssq = {};
    $scope.ssq.mainMsg = mainMessage.message;
    $scope.ssq.setSecQtnTitle = "SEC_QN_TITLE";
    $scope.ssq.nxtBtnLabel = "NXT_BTN";
    $scope.ssq.cancelBtnLabel = "CL_BTN";

    $scope.ssq.nxtBtnClick = function() {
        $state.go("forgotCredByIdentity", { userinfo: { 'userName': $scope.userName } });
    };

}
