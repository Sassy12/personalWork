(function() {
    'use strict';

    var module = angular.module('indexApp');

    module.controller('verifyUserNameCtrl', ['$scope', '$state', 'LanguageService', '$stateParams', '$timeout', 'forgotAccessService', 'trustbrokerAriaService', 'forgotAccessResponseVO', '$rootScope', 'AnalyticsService', 'HelpObj',
    function($scope, $state, LanguageService, $stateParams, $timeout, forgotAccessService, trustbrokerAriaService, forgotAccessResponseVO, $rootScope, AnalyticsService, HelpObj) {

        HelpObj.setHelpObj({ url: '../webHelp/Default_CSH.htm#Optum ID CSH/entry_1022_Find_Optum_ID_Verify_Your_Identity.htm' });

        var responseVO = forgotAccessResponseVO.data;
        var status = forgotAccessResponseVO.status;
        $scope.userName = forgotAccessResponseVO.data.userName;
        $scope.emailList = [];
        $scope.primaryEmailAddress = "";
        $scope.secondaryEmailAddress = "";
        $scope.sendEmailTo = "";
        $scope.sendSecEmailTo = "";
        $scope.primaryEmailAndSecEmailVerified = false;
        $scope.isPrimaryEmailDisplay = false;
        $scope.isSecondaryEmailDisplay = false;
        $scope.showEmailsInDropdown = false;
        $scope.showEmailOption = false;
        $scope.showSecEmailOption = false;
        $scope.showPhoneOption = false;
        $scope.showSecurityQuestionOption = false;
        $scope.showEmailOptionRadioButton = true;
        $scope.showSecEmailOptionRadioButton = true;
        $scope.showPhoneOptionRadioButton = true;
        $scope.showSecurityQuestionOptionRadioButton = true;
        $scope.defaultAccountRecovery = true;
        $scope.defaultAccountRecoveryOptions = "";
        $scope.setradioButtonCheckedForEmail = false;
        $scope.setradioButtonCheckedForSecEmail = false;
        $scope.setradioButtonCheckedForPhone = false;
        $scope.setradioButtonCheckedForSecQuestion = false;
        $scope.setradioButtonForEmailActive = false;
        $scope.setradioButtonForSecEmailActive = false;
        $scope.setradioButtonForPhoneActive = false;
        $scope.setradioButtonForSecQuestionActive = false;
        $scope.displaySQ1ErrorMessage = false;
        $scope.displaySQ2ErrorMessage = false;
        $scope.displaySQ3ErrorMessage = false;
        $scope.requestTypeForgotUserName = false;
        $scope.requestTypeForgotPwd = false;
        $scope.requestTypeSetupSecurityQuestions = false;
        $scope.requestTypeAccountUnlock = false;
        $scope.showSecQuestRadioButtonWhenEnable = true;
        $scope.requestType = "";
        $scope.data = {};
        $scope.showEmailOptionHeader = false;
        $scope.disableSQTextBox = true;
        $scope.hideContentForAutoRedirect = false;
        var secAnsLockedErrorFlag = forgotAccessService.errorFlag;
        
        $scope.errorMessageModel = {
            animationTime: 1,
            content: '',
            headingLevel: '2',
            id: 'errorMessage',
            messageRole: 'alert',
            messageType: 'error',
            position: 'inline',
            visible: false
        };
        
        if (secAnsLockedErrorFlag === true) {
            $scope.errorMessageModel.content = '<span translate="secAnswersLockErrorMessage"></span>';
            $scope.errorMessageModel.visible = true;
            AnalyticsService.postErrorTrackInfo("security questions locked due to exceeded attempts", "");
        }
        
        $scope.setMultipleEmailDetailsInThePage = function(responseVO) {
            $scope.showEmailOption = true;
            $scope.showEmailOptionHeader = true;
            $scope.showEmailsInDropdown = true;
            $scope.setradioButtonCheckedForEmail = true;
            $scope.setradioButtonCheckedForPhone = false;
            $scope.setradioButtonCheckedForSecQuestion = false;
            $scope.setradioButtonForEmailActive = true;
            $scope.primaryEmailAddress = responseVO.primaryEmail;
            $scope.secondaryEmailAddress = responseVO.secEmail;
            $scope.data.emailList = [
                { "label": responseVO.primaryEmailMask, "value": responseVO.primaryEmail },
                { "label": responseVO.secEmailMask,     "value": responseVO.secEmail }
            ];
        };

        $scope.setEmailDetailsInThePage = function(responseVO) {
            if (responseVO.primaryEmailVerified) {
                $scope.sendEmailTo = responseVO.primaryEmailMask;
                $scope.primaryEmailAddress = responseVO.primaryEmail;
                $scope.isPrimaryEmailDisplay = true;
                $scope.showEmailOption = true;
                $scope.showEmailOptionHeader = true;
                $scope.setradioButtonCheckedForEmail = true;
                $scope.setradioButtonForEmailActive = true;
            } else {
                $scope.isPrimaryEmailDisplay = false;
                $scope.showEmailOption = false;
                $scope.showEmailOptionHeader = false;
                $scope.setradioButtonCheckedForEmail = false;
                $scope.setradioButtonForEmailActive = false;
            }
        };

        $scope.setSecEmailDetailsInThePage = function(responseVO) {
            if (responseVO.secondaryEmailVerified) {
                $scope.sendSecEmailTo = responseVO.secEmailMask;
                $scope.secondaryEmailAddress = responseVO.secEmail;
                $scope.isSecondaryEmailDisplay = true;
                $scope.showSecEmailOption = true;
                $scope.showEmailOptionHeader = true;
                $scope.setradioButtonCheckedForSecEmail = true;
                $scope.setradioButtonForSecEmailActive = true;
            } else {
                $scope.isSecondaryEmailDisplay = false;
                $scope.showSecEmailOption = false;
                $scope.showEmailOptionHeader = false;
                $scope.setradioButtonCheckedForSecEmail = false;
                $scope.setradioButtonForSecEmailActive = false;
            }
        };

        $scope.setSQDetailsInThePage = function(responseVO) {
            $scope.showSecurityQuestionOption = true;
            $scope.question1 = responseVO.secQuestion1;
            $scope.question2 = responseVO.secQuestion2;
            $scope.question3 = responseVO.secQuestion3;
            $scope.setradioButtonCheckedForSecQuestion = true;
            $scope.setradioButtonForSecQuestionActive = true;
        };

        $scope.setPhoneDetailsInThePage = function(responseVO) {
            $scope.showPhoneOption = true;
            $scope.sendMsgTo = responseVO.phoneMask;
            $scope.setradioButtonCheckedForPhone = true;
            $scope.setradioButtonForPhoneActive = true;
        };

        $scope.displayAccountRecoveryradiobuttons = function() {
            if (!$scope.showSecEmailOption && !$scope.showPhoneOption && !$scope.showSecurityQuestionOption) {
                $scope.showEmailOptionRadioButton = true;
                $scope.showSecEmailOptionRadioButton = false;
                $scope.showPhoneOptionRadioButton = false;
                $scope.showSecurityQuestionOptionRadioButton = false;
                $scope.defaultAccountRecovery = true;
                $scope.defaultAccountRecoveryOptions = "email";
            }

            if (!$scope.showEmailOption && !$scope.showPhoneOption && !$scope.showSecurityQuestionOption) {
                $scope.showEmailOptionRadioButton = false;
                $scope.showSecEmailOptionRadioButton = true;
                $scope.showPhoneOptionRadioButton = false;
                $scope.showSecurityQuestionOptionRadioButton = false;
                $scope.defaultAccountRecovery = true;
                $scope.defaultAccountRecoveryOptions = "secEmail";
            }

            if (!$scope.showEmailOption && !$scope.showSecEmailOption && !$scope.showSecurityQuestionOption) {
                $scope.showEmailOptionRadioButton = false;
                $scope.showSecEmailOptionRadioButton = false;
                $scope.showPhoneOptionRadioButton = true;
                $scope.showSecurityQuestionOptionRadioButton = false;
                $scope.defaultAccountRecovery = true;
                $scope.defaultAccountRecoveryOptions = "phone";
            }

            if (!$scope.showEmailOption && !$scope.showSecEmailOption && !$scope.showPhoneOption) {
                $scope.showEmailOptionRadioButton = false;
                $scope.showSecEmailOptionRadioButton = false;
                $scope.showPhoneOptionRadioButton = false;
                $scope.showSecurityQuestionOptionRadioButton = false;
                $scope.defaultAccountRecovery = true;
                $scope.defaultAccountRecoveryOptions = "secQuestion";
                $scope.displaySecurityQuestionblock = true;
                $scope.disableSQTextBox = false;
            }
        };

        var invalidRecoveryOptns = responseVO.invalidRecoveryOptns;
        var skipAccountRecovery = responseVO.skipAccountRecovery;
        $scope.requestType = responseVO.requestType;
        $scope.recoveryType = responseVO.recoveryType;
        var resendData = {};

        if (status && invalidRecoveryOptns) {
            $state.go('norecoveryoption');
        } else if (status && skipAccountRecovery) {
            if ($scope.requestType === 'forgotUserName') {
                var successMessageKey = responseVO.successMessageKey;

                if (successMessageKey === "sendUserNameSuccessViaPrimaryEmail") {
                    resendData = { 'recoveryType': "primaryEmail", "userName": $scope.userName };
                    $state.go("login", { 'prevState': successMessageKey, 'resendInfo': resendData });
                } else if (successMessageKey === "sendUserNameSuccessViaSecondaryEmail") {
                    resendData = { 'recoveryType': "secondaryEmail", "userName": $scope.userName };
                    $state.go("login", { 'prevState': successMessageKey, 'resendInfo': resendData });
                } else if ("sendUserNameSuccessViaPhone" === successMessageKey) {
                    resendData = { 'recoveryType': "phone", "userName": $scope.userName };
                    $state.go("login", { 'prevState': successMessageKey, 'resendInfo': resendData });
                } else {
                    $state.go('login', { 'prevState': successMessageKey });
                }
            } else if ($scope.requestType === 'forgotPwd' || $scope.requestType === 'setUpSecurityQuestion' || $scope.requestType === 'unlockUserAccount') {
                if ($scope.recoveryType === 'phone') {
                    $state.go("mobileVerification", { 'userName': $scope.userName });
                } else {
                    $state.go("resetPwdVerificationLink", { userinfo: { 'recoveryType': $scope.recoveryType, 'userName': $scope.userName } });
                }
            }
        }
        
        if (!responseVO.primaryEmailVerified && !responseVO.secondaryEmailVerified && !responseVO.phoneVerified ) {
            if (responseVO.secQuestionAvailable) {
                $scope.hideContentForAutoRedirect = false;
                $state.go('verifyIdentityBySecurityQuestions',{userinfo: {'userName': $scope.userName}});
            }
        } else {
            $scope.hideContentForAutoRedirect = true;
        }
        
        $scope.primaryEmailAndSecEmailVerified = responseVO.primaryEmailAndSecEmailVerified;

        if (responseVO.primaryEmailVerified) {
            $scope.setEmailDetailsInThePage(responseVO);
        }

        if (responseVO.secondaryEmailVerified) {
            $scope.setSecEmailDetailsInThePage(responseVO);
        }

        if (responseVO.phoneVerified) {
            $scope.setPhoneDetailsInThePage(responseVO);
        }

        if (responseVO.secQuestionAvailable) {
            $scope.setSQDetailsInThePage(responseVO);
        }

        $scope.displayAccountRecoveryradiobuttons();

        if (responseVO.accountLockedStatus === "LOCKED") {
            $scope.showSecurityQuestionOption = false;
            $scope.displaySecurityQuestionblock = false;
        }

        if ($scope.showSecurityQuestionOption) {
            $scope.displaySecurityQuestionblock = true;
        }

        pageDataLayer.content.pageName = "verifyyouridentity";

        if ($scope.requestType === 'forgotUserName') {
            $scope.requestTypeForgotUserName = true;
            pageDataLayer.content.siteSectionL1 = "findoptumid";
        } else if ($scope.requestType === 'forgotPwd') {
            $scope.requestTypeForgotPwd = true;
            pageDataLayer.content.siteSectionL1 = "resetpassword";
        } else if ($scope.requestType === 'setUpSecurityQuestion') {
            $scope.requestTypeSetupSecurityQuestions = true;
            $scope.showSecurityQuestionOption = false;
            $scope.displaySecurityQuestionblock = false;
            pageDataLayer.content.siteSectionL1 = "setsecurityquestions";
        } else if ($scope.requestType === 'unlockUserAccount') {
            $scope.requestTypeAccountUnlock = true;
            pageDataLayer.content.siteSectionL1 = "accountlocked";
        }

        if (typeof _satellite !== "undefined") {
            _satellite.track('trackPageView');
        }

        // radio button default selection
        if ($scope.setradioButtonCheckedForEmail) {
            $scope.setradioButtonCheckedForSecEmail = false;
            $scope.setradioButtonCheckedForPhone = false;
            $scope.setradioButtonCheckedForSecQuestion = false;
            $scope.defaultAccountRecoveryOptions = "email";
        } else if ($scope.setradioButtonCheckedForSecEmail) {
            $scope.setradioButtonCheckedForEmail = false;
            $scope.setradioButtonCheckedForPhone = false;
            $scope.setradioButtonCheckedForSecQuestion = false;
            $scope.defaultAccountRecoveryOptions = "secEmail";
        } else if ($scope.setradioButtonCheckedForPhone) {
            $scope.setradioButtonCheckedForEmail = false;
            $scope.setradioButtonCheckedForSecEmail = false;
            $scope.setradioButtonCheckedForSecQuestion = false;
            $scope.defaultAccountRecoveryOptions = "phone";
        } else if ($scope.setradioButtonCheckedForSecQuestion) {
            $scope.setradioButtonCheckedForEmail = false;
            $scope.setradioButtonCheckedForSecEmail = false;
            $scope.setradioButtonCheckedForPhone = false;
            $scope.defaultAccountRecoveryOptions = "secQuestion";
        }
       
       
       
        
        // Controller initialization ends
        $scope.radioButtonOptionChanged = false;
        $scope.submittedWithError = false;
        $scope.accountRecoveryoptionChosed = 0;
        $scope.accountRecoveryRadioButtonClicked = false;
        var data = $scope.data;

        $scope.checkRadioClicked = function(i) {
            $scope.accountRecoveryoptionChosed = i;
            $scope.accountRecoveryRadioButtonClicked = true;
            $scope.errorMessageModel.visible = false;
            $scope.defaultAccountRecovery = false;

            if (i === 3) {
                $scope.securityQuestionsActivated = true;
                $scope.radioButtonOptionChanged = false;
                $scope.displaySQ1ErrorMessage = false;
                $scope.displaySQ2ErrorMessage = false;
                $scope.displaySQ3ErrorMessage = false;
                $scope.disableSQTextBox = false;
            } else {
                $scope.emailOrPhoneSelectedInAccountRecovery();
            }
        };

        $scope.emailOrPhoneSelectedInAccountRecovery = function() {
            $scope.securityQuestion1Error = false;
            $scope.securityQuestion2Error = false;
            $scope.securityQuestion3Error = false;
            data.securityQuestion1 = "";
            data.securityQuestion2 = "";
            data.securityQuestion3 = "";
            $scope.securityQuestionsActivated = false;
            $scope.submittedWithError = false;
            $scope.radioButtonOptionChanged = true;
            $scope.displaySQ1ErrorMessage = false;
            $scope.displaySQ2ErrorMessage = false;
            $scope.displaySQ3ErrorMessage = false;
            $scope.disableSQTextBox = true;
        };

        $scope.onKeyUp = function(fieldId, errorId, fldErrFlag, fldErrMsg) {
            var fldValue = angular.element("#" + fieldId).val();

            if (fldValue !== '' && fldValue !== undefined) {
                trustbrokerAriaService.removeDescribedByAttribute(fieldId, errorId);
                $scope[fldErrFlag] = false;
            } else if ($scope[fldErrMsg] !== "" && $scope[fldErrMsg] !== undefined) {
                trustbrokerAriaService.appendDescribedByAttribute(fieldId, errorId);
                $scope[fldErrFlag] = true;
            }
        };

        $scope.setFieldValidity = function(inputid, spanid) {
            trustbrokerAriaService.setFieldValidity(inputid, spanid);
        };

        LanguageService.doTranslate("selfservice");

        $scope.goToLogin = function() {
            $state.go('login');
        };

        $scope.nextScreen = function() {
            if ($scope.defaultAccountRecovery) {
                $scope.pageSubmitedWithoutRadioButtonSelection();
            } else {
                $scope.pageSubmitedWithRadioButtonSelection();
            }
        };

        $scope.pageSubmitedWithoutRadioButtonSelection = function() {
            if ($scope.defaultAccountRecoveryOptions === "email") {
                $scope.sendCreditialInformationToPrimaryEmail();
            } else if ($scope.defaultAccountRecoveryOptions === "secEmail") {
                $scope.sendCreditialInformationToSecondaryEmail();
            } else if ($scope.defaultAccountRecoveryOptions === "phone") {
                $scope.sendCreditialInformationToPhone();
            } else if ($scope.defaultAccountRecoveryOptions === "secQuestion") {
                //$scope.secQuestionValidationProcess();
                $state.go('verifyIdentityBySecurityQuestions',{userinfo: {'userName': $scope.userName}});
            }
        };

        $scope.pageSubmitedWithRadioButtonSelection = function() {
            if ($scope.accountRecoveryoptionChosed === 0) {
                $scope.errorMessageModel.content = '<span translate="selectOptionForVerifyIdentity"></span>';
                $scope.errorMessageModel.visible = true;
                AnalyticsService.postErrorTrackInfo("no recovery option selected", "");
            } else if ($scope.accountRecoveryoptionChosed === 1) {
                $scope.sendCreditialInformationToPrimaryEmail();
            } else if ($scope.accountRecoveryoptionChosed === 2) {
                $scope.sendCreditialInformationToPhone();
            } else if ($scope.accountRecoveryoptionChosed === 3) {
                //$scope.secQuestionValidationProcess();
                $state.go('verifyIdentityBySecurityQuestions',{userinfo: {'userName': $scope.userName}});
                
            } else if ($scope.accountRecoveryoptionChosed === 4) {
                $scope.sendCreditialInformationToSecondaryEmail();
            }
        };

        $scope.sendCreditialInformationToPrimaryEmail = function() {
            if ($scope.requestType === 'forgotUserName') {
                $scope.sendUserNameByPrimaryEmail();
            } else if ($scope.requestType === 'forgotPwd' || $scope.requestType === 'setUpSecurityQuestion' || $scope.requestType === 'unlockUserAccount') {
                $scope.sendResetPasswordByPrimaryEmail();
            }
        };

        $scope.sendCreditialInformationToSecondaryEmail = function() {
            if ($scope.requestType === 'forgotUserName') {
                $scope.sendUserNameBySecondaryEmail();
            } else if ($scope.requestType === 'forgotPwd' || $scope.requestType === 'setUpSecurityQuestion' || $scope.requestType === 'unlockUserAccount') {
                $scope.sendResetPasswordBySecondaryEmail();
            }
        };

        $scope.sendCreditialInformationToPhone = function() {
            if ($scope.requestType === 'forgotUserName') {
                $scope.sendUserNameByPhone();
            } else if ($scope.requestType === 'forgotPwd' || $scope.requestType === 'setUpSecurityQuestion' || $scope.requestType === 'unlockUserAccount') {
                $scope.sendPhoneOTP();
            }
        };

        $scope.sendUserNameByPrimaryEmail = function() {
            var postData = { 'recoveryType': "primaryEmail", "userName": $scope.userName };

            forgotAccessService.sendUserNameByAccountRecovery(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status) {
                    AnalyticsService.postRecoveryTypeInfo("username", "primaryEmail");
                    $state.go("login", { 'prevState': 'sendUserNameSuccessViaPrimaryEmail', 'resendInfo': postData });
                }
            });
        };

        $scope.sendResetPasswordByPrimaryEmail = function() {
            var postData = { 'recoveryType': "primaryEmail", "userName": $scope.userName };

            forgotAccessService.sendResetPasswordByEmail(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status) {
                    if ($scope.requestType === 'forgotPwd') {
                        AnalyticsService.postRecoveryTypeInfo("password", "primaryEmail");
                    }
                    $state.go("resetPwdVerificationLink", { 'userinfo': { 'recoveryType': "primaryEmail", 'userName': $scope.userName } });
                }
            });
        };

        $scope.sendUserNameBySecondaryEmail = function() {
            var postData = { 'recoveryType': "secondaryEmail", "userName": $scope.userName };

            forgotAccessService.sendUserNameByAccountRecovery(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status) {
                    AnalyticsService.postRecoveryTypeInfo("username", "secondaryEmail");
                    $state.go("login", { 'prevState': 'sendUserNameSuccessViaSecondaryEmail', 'resendInfo': postData });
                }
            });
        };

        $scope.sendResetPasswordBySecondaryEmail = function() {
            var postData = { 'recoveryType': "secondaryEmail", "userName": $scope.userName };

            forgotAccessService.sendResetPasswordByEmail(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status) {
                    if ($scope.requestType === 'forgotPwd') {
                        AnalyticsService.postRecoveryTypeInfo("password", "secondaryEmail");
                    }
                    $state.go("resetPwdVerificationLink", { userinfo: { 'recoveryType': "secondaryEmail", 'userName': $scope.userName } });
                }
            });
        };

        $scope.sendUserNameByPhone = function() {
            var postData = { 'recoveryType': "phone", "userName": $scope.userName };

            forgotAccessService.sendUserNameByAccountRecovery(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status) {
                    AnalyticsService.postRecoveryTypeInfo("username", "text");
                    $state.go("login", { 'prevState': 'sendUserNameSuccessViaPhone', 'resendInfo': postData });
                }
            });
        };

        $scope.sendPhoneOTP = function() {
            var postData = { "userName": $scope.userName };

            forgotAccessService.sendPhoneOTP(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status) {
                    if ($scope.requestType === 'forgotPwd') {
                        AnalyticsService.postRecoveryTypeInfo("password", "text");
                    }
                    $state.go("mobileVerification", { 'userName': $scope.userName });
                }
            });
        };

        $scope.verifySecurityQuestion = function() {
            var postData = { "recoveryType": "secQuestion", "userName": $scope.userName, "secAns1": data.securityQuestion1, "secAns2": data.securityQuestion2 };

            forgotAccessService.displayUserNameByVerifyingSecurityQuestion(postData).then(function(response) {
                var responseVO = response.data;
                var status = responseVO.status;

                if (status && $scope.requestType === 'forgotUserName') {
                    AnalyticsService.postRecoveryTypeInfo("username", "securityQuestions");
                    $state.go("login", { 'prevState': 'displayUserNameSuccessViaSQ', 'userName': $scope.userName });
                } else if (status && ($scope.requestType === 'forgotPwd' || $scope.requestType === 'unlockUserAccount')) {
                    if ($scope.requestType === 'forgotPwd') {
                        AnalyticsService.postRecoveryTypeInfo("password", "securityQuestions");
                    }

                    $state.go("resetPassword", { 'userName': $scope.userName });
                } else if (!status && responseVO.accountLockedStatus === "LOCKED") {
                    $scope.setradioButtonCheckedForEmail = false;
                    $scope.setradioButtonCheckedForSecEmail = false;
                    $scope.setradioButtonCheckedForPhone = false;
                    $scope.accountLockProcess(responseVO);
                } else {
                    $scope.processErrorMessages(responseVO);
                }
            });
        };

        $scope.accountLockProcess = function(responseVO) {
            if (!$scope.showEmailOption && !$scope.showSecEmailOption && !$scope.showPhoneOption) {
                $state.go('norecoveryoption');
            } else if ($scope.showEmailOption) {
                $scope.processErrorMessages(responseVO);
                $scope.setradioButtonCheckedForEmail = true;
            } else if ($scope.showSecEmailOption) {
                $scope.processErrorMessages(responseVO);
                $scope.setradioButtonCheckedForSecEmail = true;
            } else if ($scope.showPhoneOption) {
                $scope.processErrorMessages(responseVO);
                $scope.setradioButtonCheckedForPhone = true;
            }
        };

        $scope.processErrorMessages = function(responseVO) {
            var messages = responseVO.messages;
            var secAnswer1Req = messages.secAnswer1ReqErrorMsg,
                secAnswer2Req = messages.secAnswer2ReqErrorMsg,
                secAnswer3Req = messages.secAnswer3ReqErrorMsg,
                secAnswersMisMatch = messages.secAnswersMisMatch,
                secAnswersMisMatchAccLockedSamePage = messages.secAnswersMisMatchAccLockedSamepage;

            if (messages.formerr !== undefined) {
                $scope.errorMessageModel.content = '<span>' + messages.formerr + '</span>';
                $scope.errorMessageModel.visible = true;
                $rootScope.fireErrorTracker = true;
            }

            if (secAnswer1Req !== '' && secAnswer1Req !== undefined) {
                $scope.securityAnswer1IsRequired();
            }

            if (secAnswer2Req !== '' && secAnswer2Req !== undefined) {
                $scope.securityAnswer2IsRequired();
            }

            if (secAnswer3Req !== '' && secAnswer3Req !== undefined) {
                $scope.securityAnswer3IsRequired();
            }

            if (secAnswersMisMatch !== '' && secAnswersMisMatch !== undefined) {
                data.securityQuestion1 = "";
                data.securityQuestion2 = "";
                data.securityQuestion3 = "";
                $scope.errorMessageModel.content = '<span>' + secAnswersMisMatch + '</span>';
                $scope.errorMessageModel.visible = true;
                AnalyticsService.postErrorTrackInfo("wrong security answers provided", "");
            }

            if (secAnswersMisMatchAccLockedSamePage !== '' && secAnswersMisMatchAccLockedSamePage !== undefined) {
                $scope.errorMessageModel.content = '<span>' + secAnswersMisMatchAccLockedSamePage + '</span>';
                $scope.errorMessageModel.visible = true;
                $scope.displaySecurityQuestionblock = false;
                $scope.setradioButtonCheckedForSecQuestion = false;
                $scope.showSecQuestRadioButtonWhenEnable = false;
                $scope.isSQradioButtonDisabled = true;
                AnalyticsService.postErrorTrackInfo("security questions locked due to exceeded attempts", "");

                if ($scope.requestType === 'forgotUserName') {
                    document.getElementById("span_FindUsrDetailsSecQuestionOption").style.color = "grey";
                } else {
                    document.getElementById("span_FindPasswordDetailsSecQuestionOption").style.color = "grey";
                }
            }
            $scope.ariaUpdate();
        };

        $scope.securityAnswer1IsRequired = function() {
            $scope.securityQuestion1Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.displaySQ1ErrorMessage = true;
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.secAnswer1ReqErrorMsg = "secAnswer1ReqErrorMsg";
        };

        $scope.securityAnswer2IsRequired = function() {
            $scope.securityQuestion2Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.displaySQ2ErrorMessage = true;
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.secAnswer2ReqErrorMsg = "secAnswer2ReqErrorMsg";
        };

        $scope.securityAnswer3IsRequired = function() {
            $scope.securityQuestion3Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.displaySQ3ErrorMessage = true;
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.secAnswer3ReqErrorMsg = "secAnswer3ReqErrorMsg";
        };

        $scope.secQuestionValidationProcess = function() {
            $scope.noValidationError = true;

            if (data.securityQuestion1 === '' || data.securityQuestion1 === undefined) {
                $scope.securityQuestion1IsEmpty();
            }

            if (data.securityQuestion2 === '' || data.securityQuestion2 === undefined) {
                $scope.securityQuestion2IsEmpty();
            }

            if ($scope.displaySQ1ErrorMessage || $scope.displaySQ2ErrorMessage) {
                $scope.ariaUpdate();
            }

            if ($scope.displaySQ1ErrorMessage && $scope.displaySQ2ErrorMessage) {
                $scope.formLevelErrorMessagesForAllRequired();
                $rootScope.fireErrorTracker = true;
            }

            if ($scope.noValidationError) {
                $scope.verifySecurityQuestion();
            }
        };

        $scope.securityQuestion1IsEmpty = function() {
            $scope.securityQuestion1Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.formLevelErrorMessages();
            $scope.noValidationError = false;
            $scope.displaySQ1ErrorMessage = true;
            $scope.secAnswer1ReqErrorMsg = "secAnswer1ReqErrorMsg";
        };

        $scope.securityQuestion2IsEmpty = function() {
            $scope.securityQuestion2Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.formLevelErrorMessages();
            $scope.noValidationError = false;
            $scope.displaySQ2ErrorMessage = true;
            $scope.secAnswer2ReqErrorMsg = "secAnswer2ReqErrorMsg";
        };

        $scope.securityQuestion3IsEmpty = function() {
            $scope.securityQuestion3Error = true;
            $scope.verifyUserNameForm.submitted = true;
            $scope.formLevelErrorMessages();
            $scope.noValidationError = false;
            $scope.displaySQ3ErrorMessage = true;
            $scope.secAnswer3ReqErrorMsg = "secAnswer3ReqErrorMsg";
        };

        $scope.formLevelErrorMessages = function() {
            $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage1"></span>';
            $scope.errorMessageModel.visible = true;
            $scope.submittedWithError = true;
        };

        $scope.formLevelErrorMessagesForAllRequired = function() {
            if ($scope.requestType === 'forgotUserName') {
                $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessageForUserName"></span>';
            } else {
                $scope.errorMessageModel.content = '<span translate="FgtUsrFormLevelErrorMessage"></span>';
            }

            $scope.errorMessageModel.visible = true;
            $scope.submittedWithError = true;
        };

        $scope.ariaUpdate = function() {
            var FIELDS = [];
            var ind = 0;

            if ($scope.displaySQ1ErrorMessage) {
                FIELDS[ind] = { fld: "securityQuestion1_input", msg: "securityQuestion1Id_err" };
                ind++;
            }

            if ($scope.displaySQ2ErrorMessage) {
                FIELDS[ind] = { fld: "securityQuestion2_input", msg: "securityQuestion2Id_err" };
                ind++;
            }

            if ($scope.displaySQ3ErrorMessage) {
                FIELDS[ind] = { fld: "securityQuestion3_input", msg: "securityQuestion3Id_err" };
                ind++;
            }

            if (FIELDS.length > 0) {
                $timeout(function() {
                    trustbrokerAriaService.setAriaAttributesPostFormSubmit(FIELDS);
                    $scope.formErrorIsHidden = false;
                }, 300);
            }

            return;
        };
    }]);
})();
