-- Remove column in USER_AUTHORIZATION
alter table USER_AUTHORIZATION  DROP COLUMN PURPOSE;
-- Add column in ORG_ADDRESS
ALTER TABLE  ORG_ADDRESS add (ORG_ADDR_PHONE VARCHAR2(20),ORG_ADDR_FAX VARCHAR2(20));
--Drop column in irm_audit_logs
alter table irm_audit_logs DROP COLUMN EMAIL_ADDRESS;
alter table irm_audit_logs DROP COLUMN AUDIT_CONTENT;
-- Dropg newly created tables 
drop table ORG_PHONE_FAX;
-- Drop sequnce 
drop  SEQUENCE   ORG_PHONE_FAX_SEQ;
