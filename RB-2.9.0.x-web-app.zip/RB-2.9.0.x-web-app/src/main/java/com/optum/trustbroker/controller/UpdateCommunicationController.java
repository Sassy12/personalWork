package com.optum.trustbroker.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;

import com.optum.trustbroker.auditlogging.SecuritySubEventType;
import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContext;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.ErrorResponseVO;
import com.optum.trustbroker.controller.vo.ResponseVO;
import com.optum.trustbroker.controller.vo.VerifyCodesCtx;
import com.optum.trustbroker.controller.vo.VerifyCodesVO;
import com.optum.trustbroker.util.BaseLogger;
import com.optum.trustbroker.util.IrmLoggingUtil;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.util.TrustBrokerWebAppConstants;
import com.optum.trustbroker.util.TrustbrokerWebAppUtil;
import com.optum.trustbroker.vo.CommunicationChannel;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.RelyingPartyTierInfoVO;
import com.optum.trustbroker.vo.UserProfileServiceRequest;
import com.optum.trustbroker.vo.UserProfileServiceResponse;
import com.optum.trustbroker.vo.UserVO;
import com.optumx.sdk.logging.securityevent.SecurityEventResult;
import com.optumx.sdk.logging.securityevent.SecurityEventType;

@Path(TBConstants.VERIFY_CODES_UPDATE_CONTROLLER_PATH)
public class UpdateCommunicationController extends BaseController {

	private static final String EMAIL = "email";
	private static final String EMAIL_REQUIRED_KEY = "ifBlnkReqUniqEmOrShrMsg";
	private static final String EMAIL_UNALTERED_KEY = "emailUnalteredNextGen";
	private static final String PRIMARY_EMAIL = "primaryEmail";
	private static final String SECONDARY_EMAIL = "secondaryEmail";
	
	private static final BaseLogger LOGGER = new BaseLogger(UpdateCommunicationController.class);

	/**
	 * will update the communication channel which can be either primary
	 * email/secondary/phone
	 */
	@Path(TBConstants.VERIFY_CODES_UPDATE_FIELD)
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateCommunicationChannel(VerifyCodesVO vo, @Context HttpServletRequest req) {

		Response response = null;
		UserVO userVO = getCurrentUser();

		if (userVO == null) {
			if (vo != null && vo.getCtx() != null && vo.getCtx().getUserVO() != null) {
				userVO = vo.getCtx().getUserVO();
			}
		}

		CommunicationChannel channel = vo.getChannel();

		String email = vo.getEmail();
		ResponseVO responseVO = new ResponseVO();

		// getting rpAPPId from context
		String rpAppId = getSessionAttribute(TrustBrokerWebAppConstants.RELYING_APP_ID_PARAM);
		RelyingPartyTierInfoVO rpTierInfo = null;

		if (StringUtils.isNotEmpty(rpAppId)) {
			RelyingPartyAppVO relyingPartyAppVO = getRPContext();
			rpTierInfo = getRPTierInfo(relyingPartyAppVO.getAlias());
		}

		/* default to true as shared primary email is allowed in standalone */
		boolean allowSharedEmail = true;
		if(rpTierInfo != null){
			allowSharedEmail = rpTierInfo.isEmailShared();
		}

		if (CommunicationChannel.PRIMARY_EMAIL.equals(channel)
				|| CommunicationChannel.SECONDARY_EMAIL.equals(channel)) {
			Map<String, String> errorMap = validateEmail(email, userVO, channel, allowSharedEmail);
			if (!errorMap.isEmpty()) {
				responseVO.setErrorMap(errorMap);
				responseVO.setStatus(TrustBrokerWebAppConstants.ERROR);
				response = Response.status(TrustBrokerWebAppConstants.HTTP_BAD_REQUEST).entity(responseVO).build();
				return response;
			}
		}


		if ("tsa".equals(userVO.getRpId())) {
			userVO.setRpId(null);
		}

		UserVO essoUserVO = userService.fetchUserProfile(userVO.getUuId(), true, true).getUser();
		String emailToNotify = null;

		if (CommunicationChannel.PRIMARY_EMAIL == channel) {
			userVO.setEmailAddress(email);
			emailToNotify = essoUserVO.getEmailAddress();
		} else if (CommunicationChannel.SECONDARY_EMAIL == channel) {
			userVO.setSecEmailAddress(email);
			emailToNotify = essoUserVO.getSecEmailAddress();
		}

		/* To skip challenge questions as modified attributes in service layer */
		userVO.setUserChallengeQuestions(null);

		UserProfileServiceRequest userProfileServiceRequest = new UserProfileServiceRequest();
		userProfileServiceRequest.setUser(userVO);
		userProfileServiceRequest.setOldUser(essoUserVO);

		UserProfileServiceResponse serviceResponse = userService.modifyUser(userProfileServiceRequest, false);

		if (TrustbrokerWebAppUtil.checkResponseStatus(serviceResponse)) {

			/* send a notification to old email after update is success */
			userService.sendUserEmailUpdInfo(emailToNotify, userVO, rpAppId,
					getUrlLogoOptumId(req), getUrlLogoRelyingParty(req, rpAppId));
			logUserEmailUpdate(TrustBrokerWebAppConstants.REGN_CONF_EMAIL_UPD_MSG
							+ "UpdateCommunicationChannelController.updateCommunicationChannel()",
					userVO, emailToNotify,
					TrustBrokerConstants.CONFRM_EMAIL_UPD_ACTIVITY, req, rpAppId);

			responseVO.setStatus(TBConstants.STATUS_SUCCESS);
			response = Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(responseVO).build();

			/* clear workflow ID and attributes on successful update */
			WebApplicationContext webAppCtx = WebApplicationContextHolder.getContext();
			webAppCtx.removeCurrentWorkflowAndAttributes();

		}else{
			String errorMsg = serviceResponse.getReasonMessage();
			ErrorResponseVO errorResponse = new ErrorResponseVO();
			errorResponse.setErrorCode(serviceResponse.getReasonCode());
			errorResponse.setMessage(errorMsg);
			LOGGER.error("Unable to update email address for user {} in eSSO due to {} ",
					new String[] {userVO.getUserName(), errorMsg});
			response = Response.status(TrustBrokerWebAppConstants.HTTP_BAD_REQUEST).entity(errorResponse).build();
		}

		return response;
	}


	@Path(TBConstants.SET_UPDATE_EMAIL_CONTEXT)
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	public Response saveWorkFlow(@PathParam("channel") CommunicationChannel channel) {

		String attrValue = null;

		if (channel == CommunicationChannel.PRIMARY_EMAIL) {
			attrValue = PRIMARY_EMAIL;
		} else if (channel == CommunicationChannel.SECONDARY_EMAIL) {
			attrValue = SECONDARY_EMAIL;
		}

		WebApplicationContextHolder.getContext().setWorkflowAttribute(WorkflowConstants.WORKFLOW_UPDATE_EMAIL,
				WorkflowConstants.WORKFLOW_ATTRIBUTE_EMAIL, attrValue);

		return Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).build();
	}

	@Path(TBConstants.GET_UPDATE_EMAIL_CONTEXT)
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUpdateEmailContext() {

		WebApplicationContext webAppCtx = WebApplicationContextHolder.getContext();

		if (WorkflowConstants.WORKFLOW_UPDATE_EMAIL.equalsIgnoreCase(webAppCtx.getcurrentWorkflowId())) {

			String flowAttribute = webAppCtx.getWorkflowAttribute(WorkflowConstants.WORKFLOW_UPDATE_EMAIL, WorkflowConstants.WORKFLOW_ATTRIBUTE_EMAIL);
			String email = null;

			UserVO userVO = getCurrentUser();

			VerifyCodesVO verifyCodesVO = new VerifyCodesVO();
			VerifyCodesCtx codesCtx = new VerifyCodesCtx();
			codesCtx.setNextView(TBConstants.CONGRATULATIONS);
			verifyCodesVO.setCtx(codesCtx);

			if (PRIMARY_EMAIL.equals(flowAttribute)) {
				email = userVO.getEmailAddress();
				codesCtx.setChann(CommunicationChannel.PRIMARY_EMAIL);
			} else if (SECONDARY_EMAIL.equals(flowAttribute)) {
				email = userVO.getSecEmailAddress();
				codesCtx.setChann(CommunicationChannel.SECONDARY_EMAIL);
			}

			codesCtx.setOptionValue(email);
			boolean isEmailShared = userService.isEmailExists(email);
			verifyCodesVO.setEmailShared(isEmailShared);

			return Response.status(TrustBrokerWebAppConstants.HTTP_SUCCESS).entity(verifyCodesVO).build();
		}

		return Response.status(TrustBrokerWebAppConstants.HTTP_SERVER_ERROR).build();
	}

	private Map<String, String> validateEmail(String email, UserVO userVO,
			CommunicationChannel communicationChannel, boolean allowSharedEmail) {

		String primaryEmail = userVO.getEmailAddress();
		String secondaryEmail = userVO.getSecEmailAddress();

		Map<String, String> errorMap = new HashMap<>();
		String errorMsg;

		/* Check if email is blank */
		if(StringUtils.isBlank(email)){
			errorMsg = tbResources.getString(EMAIL_REQUIRED_KEY);
			errorMap.put(EMAIL, errorMsg);
			return errorMap;
		}

		/* Check if email is unaltered. Check if it matches previous value */
		if (isEmailUnaltered(email,primaryEmail,secondaryEmail,communicationChannel)) {
			errorMsg = tbResources.getString(EMAIL_UNALTERED_KEY);
			errorMap.put(EMAIL, errorMsg);
			return errorMap;
		}

		/* If shared primary email is not allowed in RP, throw an error.
		*  Secondary email can be shared irrespective of RP context.
		* */
		if(!allowSharedEmail){
			if (communicationChannel == CommunicationChannel.PRIMARY_EMAIL && userService.isEmailExists(email)) {
				errorMsg = tbResources.getString("rpNotAllwSharedEmailNextGen");
				errorMap.put(EMAIL, errorMsg);
				return errorMap;
			}
		}

		/* Check if email is same as secondary email when trying to update primary and vice-versa */
		if (CommunicationChannel.PRIMARY_EMAIL == communicationChannel) {
			if (StringUtils.isNotBlank(secondaryEmail) && StringUtils.equalsIgnoreCase(secondaryEmail,email)) {
				errorMsg = tbResources.getString("primaryEmailValidation");
				errorMap.put(EMAIL, errorMsg);
				return errorMap;
			}
		} else if (CommunicationChannel.SECONDARY_EMAIL == communicationChannel) {
			if (StringUtils.isNotBlank(primaryEmail) && StringUtils.equalsIgnoreCase(primaryEmail,email)) {
				errorMsg = tbResources.getString("secondaryEmailValidation");
				errorMap.put(EMAIL, errorMsg);
				return errorMap;
			}
		}

		/* Check if email is valid */
		if (!TBUtil.validateEmailId(email)) {
			errorMsg = tbResources.getString("formatErrorFormNextGen");
			errorMap.put(EMAIL, errorMsg);
			return errorMap;
		}

		return errorMap;
	}

	private void logUserEmailUpdate(String msg, UserVO userVO, String email, String activity, HttpServletRequest req,
			String rpAppId) {
		String logMsg = "Security Audit Event|" + msg + "## uuid: ^^" + userVO.getUuId() + "!!";
		IrmLoggingUtil.info(activity, SecurityEventType.E3_MODIFY, req.getRemoteAddr(), req.getLocalAddr(),
				req.getSession().getId(), userVO.getUserName(), logMsg, SecurityEventResult.SUCCESS, rpAppId, email, "",
				SecuritySubEventType.E3_MODIFY_EMAIL);
	}


	private boolean isEmailUnaltered(String email, String primaryEmail, String secondaryEmail ,CommunicationChannel channel){

		if(primaryEmail.equalsIgnoreCase(email) && channel == CommunicationChannel.PRIMARY_EMAIL){
			return true;
		}

		if(email.equalsIgnoreCase(secondaryEmail) && channel == CommunicationChannel.SECONDARY_EMAIL){
			return true;
		}

		return false;
	}

}
