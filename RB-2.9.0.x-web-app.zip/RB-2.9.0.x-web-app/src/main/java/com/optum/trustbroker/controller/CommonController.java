package com.optum.trustbroker.controller;


import java.util.ResourceBundle;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.trustbroker.constants.TBConstants;
import com.optum.trustbroker.constants.WorkflowConstants;
import com.optum.trustbroker.context.WebApplicationContextHolder;
import com.optum.trustbroker.controller.vo.ConsentVO;
import com.optum.trustbroker.controller.vo.ErrorResponseVO;
import com.optum.trustbroker.controller.vo.MessageVO;
import com.optum.trustbroker.controller.vo.UserInfoVO;
import com.optum.trustbroker.service.UserRelyingPartyRelationService;
import com.optum.trustbroker.service.UserService;
import com.optum.trustbroker.util.TBUtil;
import com.optum.trustbroker.util.TrustBrokerConstants;
import com.optum.trustbroker.vo.RelyingPartyAppVO;
import com.optum.trustbroker.vo.UserAuthorizationResponse;


@Path(TBConstants.COMMON_CONTROLLER_PATH)
public class CommonController extends BaseController {
	
	private static final Logger LOG = Logger.getLogger(CommonController.class);
	
	@Autowired
	private UserRelyingPartyRelationService userRelyingPartyRelationService;

	
	/**
	 * Get no account recovery message.
	 * @return CommonControllerVO
	 */
	@GET
	@Path(value = "/noAccountRecoveryMsg")
	@Produces(MediaType.APPLICATION_JSON)
    public MessageVO getNoAccountRecoveryMessageWithRPDetails() {
		MessageVO  recoveryMsg = new MessageVO();
		ResourceBundle bundle = getBundle();
		String currentWorkflowId = WebApplicationContextHolder.getContext().getcurrentWorkflowId();
		String message = "";
		
		if(WorkflowConstants.WORKFLOW_FORGOT_USER_NAME.equalsIgnoreCase(currentWorkflowId)){
			message = bundle.getString("acctNotVerifiedMsgForgotUsername");
		} else if(WorkflowConstants.WORKFLOW_FORGOT_PWD.equalsIgnoreCase(currentWorkflowId)){
			message = bundle.getString("acctNotVerifiedMsgForgotPassword");
		} else if(WorkflowConstants.WORKFLOW_SETUP_SECURITY_QUESTIONS.equalsIgnoreCase(currentWorkflowId)){
			message = bundle.getString("acctNotVerifiedMsgSetUpSQA");
		} else if(WorkflowConstants.WORKFLOW_UNLOCK_USER_ACCOUNT.equalsIgnoreCase(currentWorkflowId)){
			message = bundle.getString("acctNotVerifiedMsgUnlockAccnt");
		}
		
    	recoveryMsg.setMessage(TBUtil.formatMessage(message, new String[]{getWebApplicationCommonUtilities().getApplicationSupportContactInformation(false).getContactComboText()}));
    	   	
        return recoveryMsg;
    }
	
	@GET
	@Path(value = "/setupsecqnmessage")
	@Produces(MediaType.APPLICATION_JSON)
    public MessageVO getSetupSecQnMessage() {
		MessageVO  literalVal = new MessageVO();
		ResourceBundle bundle = getBundle();
		literalVal.setMessage(bundle.getString("setupSecQnMainMsg"));
        return literalVal;
    }
	@GET
	@Path(value = "/getAdobeAnalyticsJS")
	@Produces(MediaType.APPLICATION_JSON)
    public String getAdobeAnalyticsJS() {
        return TBUtil.getAdobeAnalyticsJS();
    }
	@GET
	@Path(value = "/getEnsightenJS")
	@Produces(MediaType.APPLICATION_JSON)
    public String getEnsightenJS() {
        return TBUtil.getEnsightenJS();
    }
	@GET
	@Path(value = "/linkExpMsg")
	@Produces(MediaType.APPLICATION_JSON)
    public MessageVO getLinkExpireMsg() {
		MessageVO  literalVal = new MessageVO();
		ResourceBundle bundle = getBundle();
		String literalStr = bundle.getString("verificationLinkExpired");
		literalVal.setMessage(TBUtil.formatMessage(literalStr, new String[]{getWebApplicationCommonUtilities().getApplicationSupportContactInformation(true).getContactComboText()}));
        return literalVal;
    }
	
	@GET
	@Path(value = "/consentInfo")
	@Produces(MediaType.APPLICATION_JSON)
    public ConsentVO getConsentInfo() {
		ConsentVO consent = new ConsentVO();
		RelyingPartyAppVO rpApp = getRPContext();
		consent.setRpAppName(rpApp.getApplicationName());
		consent.setShowDob(getConfigService().getTierInfoforRP(rpApp.getAlias()).isDobRequired());
        return consent;
    }
	
	@GET
	@Path(value = "/isRPContextExist")
    public Response checkRPContext() {
		final String contentType = "text/css";
		Response response;
		
		response = Response.ok(getWebApplicationCommonUtilities().checkRelyingPartyContext(),contentType).build();
		
        return response;
    }
 
	@POST
	@Path(value = "/getErrorMessage")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
    public MessageVO getErrorMessage(ErrorResponseVO errorResponseVO) {
		MessageVO messageVO = new MessageVO();
		ResourceBundle bundle = getBundle();
		String literalStr;
		//Coppa Case
		if(TrustBrokerConstants.OPT_00K000.equalsIgnoreCase(errorResponseVO.getErrorCode())){
			literalStr = bundle.getString("exceptionErrorMessageCoppa");
			messageVO.setMessage(TBUtil.formatMessage(literalStr, new String[]{
					getWebApplicationCommonUtilities().getApplicationSupportContactInformation(true).getContactComboTextHtml(),
					 errorResponseVO.getErrorCode()}));                                              
		}else{
			//General Error Case
			literalStr =bundle.getString("exceptionErrorMessageDefault");
			messageVO.setMessage(TBUtil.formatMessage(literalStr, new String[]{
					getWebApplicationCommonUtilities().getApplicationSupportContactInformation(true).getContactComboTextHtml(),
					errorResponseVO.getReferenceCode(), errorResponseVO.getErrorCode()}));
		}
        return messageVO;
    }
	
	/**
	 * Get no account recovery message.
	 * @return CommonControllerVO
	 */
	@GET
	@Path(value = "/getCurrentWorkflowId")
	@Produces(MediaType.TEXT_PLAIN)
    public String getCurrentWorkflowId() {
		return WebApplicationContextHolder.getContext().getcurrentWorkflowId();
    }
	
	/**
     * Get no account recovery message.
     * @return CommonControllerVO
     */
    @GET
    @Path(value = "/returnVerifyIdentityStatus")
    @Produces(MediaType.TEXT_PLAIN)
    public String returnVerifyIdentityStatus() {
        return WebApplicationContextHolder.getContext().getSessionAttribute(WorkflowConstants.WORKFLOW_RETURN_VERIFY_IDENTITY);
    }
	
	@POST
	@Path(value = "/getErrorMessageWithSupportInfo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
    public MessageVO getErrorMessageWithSupportInfo(String propertyKey) {
		MessageVO messageVO = new MessageVO();
		ResourceBundle bundle = getBundle();
		String literalStr = bundle.getString(propertyKey);
		messageVO.setMessage(TBUtil.formatMessage(literalStr, new String[]{
				getWebApplicationCommonUtilities().getApplicationSupportContactInformation(true).getContactComboTextHtml()}));
        return messageVO;
    }
	
	@GET
	@Path(value = "/getSupportInfo")
	@Produces(MediaType.APPLICATION_JSON)
    public String getSupportInfo() {		
		String info = getWebApplicationCommonUtilities().
                 getApplicationSupportContactInformation(true).getContactComboText();
		
		LOG.debug("getSupportInfo() returning "+info);		
		return info;
    }
	
	@POST
	@Path(value = "/getUsernameFromAuthCode")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public UserInfoVO getUsernameFromAuthCode(String authCode) {
		UserInfoVO userInfo = new UserInfoVO();
		// For getting user from an authcode from email
		if (StringUtils.isNotEmpty(authCode)) {
			UserAuthorizationResponse userAuthorizationResponse = userService.validateAuthCode(authCode);
			if (userAuthorizationResponse!=null && TrustBrokerConstants.SUCCESS_CODE_VALUE
					.equalsIgnoreCase(userAuthorizationResponse
							.getExecutionStatus().getStatusCd()) && !TrustBrokerConstants.AUTH_PROCESSED.equalsIgnoreCase(userAuthorizationResponse.getAuthStatus()) ) {
				userInfo.setUserName(userAuthorizationResponse.getUser().getUserName());
				userInfo.setAuthCodeValid(true);
			}
		}else{
			userInfo.setUserName(WebApplicationContextHolder.getContext().getWorkflowAttribute(WorkflowConstants.WORKFLOW_ATTRIBUTE_USERNAME));
		}
		return userInfo;

	}
	public UserRelyingPartyRelationService getUserRelyingPartyRelationService() {
		return userRelyingPartyRelationService;
	}

	public void setUserRelyingPartyRelationService(
			UserRelyingPartyRelationService userRelyingPartyRelationService) {
		this.userRelyingPartyRelationService = userRelyingPartyRelationService;
	}
    
}