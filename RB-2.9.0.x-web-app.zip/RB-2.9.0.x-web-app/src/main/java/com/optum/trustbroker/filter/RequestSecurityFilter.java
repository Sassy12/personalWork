package com.optum.trustbroker.filter;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

/**
 * Filter implementation class RequestSecurityFilter
 */
public class RequestSecurityFilter implements Filter {
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {
		
		if (servletRequest instanceof HttpServletRequest) {
			HttpServletRequest hsReq = (HttpServletRequest) servletRequest;

			//CSRF check is done only for POST calls
			if ("POST".equalsIgnoreCase(hsReq.getMethod())) {
				//check for custom header parameter in the request
				if (hsReq.getHeader("x-csrf") == null || hsReq.getHeader("X-CSRF") == null) {
					throw new WebApplicationException(Response.Status.BAD_REQUEST);
				}
				
				if (hsReq.getHeader("host") != null && hsReq.getHeader("origin") != null) {
					String hostName = hsReq.getHeader("host");
					String orgName = hsReq.getHeader("origin");
					boolean isSafe = orgName.contains(hostName);
					if(!isSafe){
						throw new WebApplicationException(Response.Status.BAD_REQUEST);
					}
				} else if (hsReq.getHeader("host") != null && hsReq.getHeader("referer") != null) {
					String hostName = hsReq.getHeader("host");
					String refName = hsReq.getHeader("referer");
					boolean isSafe = refName.contains(hostName);
					if(!isSafe){
						throw new WebApplicationException(Response.Status.BAD_REQUEST);
					}
				}
			}
		}

		filterChain.doFilter(servletRequest, servletResponse);

	}

	@Override
	public void destroy() {
	}
}
