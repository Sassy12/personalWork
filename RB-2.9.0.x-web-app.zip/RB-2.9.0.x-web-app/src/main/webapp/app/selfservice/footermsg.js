/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 *
 ***********************************************
 * Modification History
 * When          Who         Why
 * Apr 19, 2016  bmanna3	Initial version
 ****************************************************************/
(function () {

	'use strict';

	var module = angular.module('indexApp');
	module.controller('footerMsgCtlr', ['$scope', '$timeout' , 'GeneralService',
		function($scope , $timeout, GeneralService) {
			$scope.footer = {name: "footermsgurl", url: "/tb/app/selfservice/views/footermsg.html"};
			$timeout(function() {
				GeneralService.postData('/tb/services/rest/commonController/getErrorMessageWithSupportInfo', 'selfserviceSupportMsg')
					.then(function(response) {
						var getElement = angular.element('#footerMsgId');
						getElement.html(response.data.message);
					});
			}, 100);
		}]);
	
})();